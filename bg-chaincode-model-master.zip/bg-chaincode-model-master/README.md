# bg-chaincode-model
Data model for Bank Guarantees which will generate Java and JS packages and be used as model base for the chaincode.
