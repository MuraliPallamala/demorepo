package com.ibm.au.bgx.model.profile;

import com.google.protobuf.util.JsonFormat;
import com.ibm.au.bgx.model.profile.Organizations.Organization;
import com.ibm.au.bgx.model.profile.Organizations.Organization.Builder;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationEntityType;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationStatus;
import java.io.InputStreamReader;
import static org.junit.Assert.*;
import org.junit.Test;


/**
 * @author Peter Ilfrich
 */
public class OrganizationsTest {

  @Test
  public void testParseOrganization() throws Exception {
    InputStreamReader r = new InputStreamReader(
        OrganizationsTest.class.getResourceAsStream("/organization.json"));
    Builder b = Organization.newBuilder();
    JsonFormat.parser().ignoringUnknownFields().merge(r, b);
    Organization org = b.build();

    assertEquals("foobar", org.getId());
    assertEquals("1234566789", org.getBusinessId());
    assertEquals(OrganizationStatus.ORGANIZATION_INACTIVE, org.getStatus());
    assertEquals(OrganizationEntityType.ORGANIZATION_ISSUER, org.getEntityType());
    assertEquals("ANZ", org.getEntityName());
    assertEquals("Jane Doe", org.getCreatedBy());
    assertEquals("50 City Rd", org.getAddress().getStreetAddress());
    assertEquals(5, org.getCreatedAt().getSeconds());
  }

}
