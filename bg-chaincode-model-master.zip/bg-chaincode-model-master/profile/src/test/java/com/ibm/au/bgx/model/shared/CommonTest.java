package com.ibm.au.bgx.model.shared;

import com.google.protobuf.util.JsonFormat;
import java.io.InputStreamReader;
import org.junit.Assert;
import org.junit.Test;
import com.ibm.au.bgx.model.shared.Common.Address;
import com.ibm.au.bgx.model.shared.Common.Address.Builder;

/**
 * @author Peter Ilfrich
 */
public class CommonTest {

  @Test
  public void testParseAddress() throws Exception {
    InputStreamReader r = new InputStreamReader(
        CommonTest.class.getResourceAsStream("/address.json"));
    Builder b = Address.newBuilder();
    JsonFormat.parser().ignoringUnknownFields().merge(r, b);
    Address a = b.build();

    Assert.assertEquals(a.getAddressCountry(), "Australia");
    Assert.assertEquals(a.getAddressLocality(), "Southbank");
    Assert.assertEquals(a.getAddressRegion(), "VIC");
    Assert.assertEquals(a.getPostalCode(), "3006");
    Assert.assertEquals(a.getPostOfficeBoxNumber(), "");
    Assert.assertEquals(a.getStreetAddress(), "50 City Rd");
  }

}
