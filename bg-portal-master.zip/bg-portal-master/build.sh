#!/bin/bash

S_BUILD_MODE=${1:-parallel}




case ${S_BUILD_MODE} in

    parallel)

        echo "Building portals in parallel mode..."

        (PORTAL_TYPE=admin PORTAL_ORG=newco npm run build) &
        PIDS[0]=$!
        (PORTAL_TYPE=user PORTAL_ORG=newco npm run build) &
        PIDS[1]=$!
        (PORTAL_TYPE=issuer PORTAL_ORG=anz npm run build) &
        PIDS[2]=$!
        (PORTAL_TYPE=issuer PORTAL_ORG=commbank npm run build) &
        PIDS[3]=$!
        (PORTAL_TYPE=issuer PORTAL_ORG=testissuer npm run build) &
        PIDS[4]=$!
        (PORTAL_TYPE=issuer PORTAL_ORG=westpac npm run build) &
        PIDS[5]=$!

        for pid in ${PIDS[*]};
        do
          wait $pid;
        done

	;;

    serial)

	echo "Building portals in serial mode..."

	PORTAL_TYPE=admin PORTAL_ORG=newco npm run build
	PORTAL_TYPE=user PORTAL_ORG=newco npm run build
	PORTAL_TYPE=issuer PORTAL_ORG=anz npm run build
	PORTAL_TYPE=issuer PORTAL_ORG=commbank npm run build
	PORTAL_TYPE=issuer PORTAL_ORG=testissuer npm run build
	PORTAL_TYPE=issuer PORTAL_ORG=westpac npm run build

	;;

    *)
	echo "Unrecognised build mode: ${S_BUILD_MODE}."
	echo "usage: ${0} parallel|serial"
	echo ""

	exit 1
	;;

esac
