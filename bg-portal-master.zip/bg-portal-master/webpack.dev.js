const merge = require("webpack-merge")

const common = require("./webpack.common.js")

module.exports = merge(common, {
    devtool: "cheap-module-source-map",
    mode: "development",
    module: {
        strictExportPresence: true,
        rules: [
            // Disable require.ensure as it's not a standard language feature.
            { parser: { requireEnsure: false } }
        ]
    }
})
