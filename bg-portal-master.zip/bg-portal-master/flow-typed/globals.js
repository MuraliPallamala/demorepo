declare var PORTAL_TYPE: string
declare var PORTAL_ORG: string
declare var DEV: boolean
