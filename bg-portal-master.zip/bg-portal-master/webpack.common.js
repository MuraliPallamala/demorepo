const webpack = require("webpack")
// Lookup paths for module name resolution
const fs = require("fs")
const HtmlWebpackPlugin = require("html-webpack-plugin")
const CopyWebpackPlugin = require("copy-webpack-plugin")
const path = require("path")

const PORTAL_TYPE = process.env.PORTAL_TYPE || "user"
const PORTAL_ORG = process.env.PORTAL_ORG || "newco"
const DEV = process.env.DEV === "true"
const QA = process.env.QA === "true"
const BUILD_DIR = path.resolve(__dirname, "dist", PORTAL_TYPE, PORTAL_ORG)
const APP_DIR = path.resolve(__dirname, "app/src")
const PUBLIC_DIR = path.resolve(__dirname, "app/public")

let baseHostPort
let devServerPort
let apiUrl
let https = false
let proxy

if (QA) {
    https = true
    switch (process.env.PORTAL_TYPE) {
        case "admin":
            baseHostPort = "bg-pilot-qa.sl.cloud9.ibm.com:453"
            devServerPort = 453
            apiUrl = "https://9.192.210.54:453"
            break
        case "user":
            baseHostPort = "bg-pilot-qa.sl.cloud9.ibm.com:444"
            devServerPort = 444
            apiUrl = "https://9.192.210.54:444"
            break
        case "issuer":
            baseHostPort = "bg-pilot-qa.sl.cloud9.ibm.com:446"
            devServerPort = 446
            apiUrl = "https://9.192.210.54:446"
            break
        default:
            throw new Error("Error invalid PORTAL_TYPE")
    }
    proxy = {
        "/api/*": {
            target: {
                host: "9.192.210.54",
                port: devServerPort,
                protocol: "https:",
                key: fs.readFileSync("./cert/key.pem"),
                cert: fs.readFileSync("./cert/cert.pem")
            },
            secure: false
        }
    }
} else {
    switch (process.env.PORTAL_TYPE) {
        case "admin":
            baseHostPort = "admin.bank-guarantee.res.ibm.com"
            devServerPort = 3100
            break
        case "user":
            baseHostPort = "bank-guarantee.res.ibm.com"
            devServerPort = 3000
            break
        case "issuer":
            baseHostPort = "bank-guarantee.res.ibm.com:444"
            devServerPort = 4000
            break
        default:
            throw new Error("Error invalid PORTAL_TYPE")
    }
    apiUrl = `https://${baseHostPort}`
    proxy = {
        "/api/*": {
            target: apiUrl,
            secure: false
        }
    }
}
const DefinePluginConfig = new webpack.DefinePlugin({
    PORTAL_TYPE: JSON.stringify(PORTAL_TYPE),
    PORTAL_ORG: JSON.stringify(PORTAL_ORG),
    DEV: JSON.stringify(DEV)
})

const HTMLWebpackPluginConfig = new HtmlWebpackPlugin({
    template: `${PUBLIC_DIR}/index.html`,
    filename: "index.html",
    inject: true
})
module.exports = {
    context: process.cwd(),
    node: { __filename: true },
    entry: {
        index: ["babel-polyfill", `${APP_DIR}/index.js`]
    },
    output: {
        path: BUILD_DIR,
        filename: "[name].[hash].js",
        chunkFilename: "[name].[hash].bundle.js",
        publicPath: "/",
        globalObject: "this"
    },
    plugins: [
        HTMLWebpackPluginConfig,
        new webpack.ContextReplacementPlugin(
            /graphql-language-service-interface[\\/]dist$/,
            new RegExp("^\\./.*\\.js$")
        ),
        new CopyWebpackPlugin([{ from: `${__dirname}/mappings.json`, to: "ui" }]),
        DefinePluginConfig
    ],
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                include: APP_DIR,
                // babel loader for ES6 tranpilation and
                // react-hot for HMR of react components
                // config for babel-loader is in .babelrc
                use: ["babel-loader"]
            },
            // The "url" loader handles all assets specified by the test regex.
            // "url" loader embeds assets smaller than specified size as data URLs to avoid requests.
            // Otherwise, it acts like the "file" loader.
            {
                test: /\.(png|pdf|jpe?g|woff|woff2|ttf|eot)$/,
                loader: "url-loader",
                options: {
                    limit: 8192,
                    fallback: "file-loader",
                    quality: 85
                }
            },
            // "file" loader for svg
            {
                test: /\.svg$/,
                loader: "file-loader",
                query: {
                    name: "static/media/[name].[hash:8].[ext]"
                }
            },
            {
                test: /\.css$/,
                use: ["style-loader", "css-loader"]
            }
        ]
    },
    devServer: {
        // contentBase needs to point to same dir as `entry`
        contentBase: APP_DIR,
        https,

        // enable HMR
        hot: true,
        // automatic browser refresh
        inline: true,
        // automatically open in default browser
        open: true,

        // Display only errors to reduce the amount of output.
        stats: {
            // fallback value for stats options when an option is not defined (has precedence over local webpack defaults)
            // all: undefined,

            // Add build date and time information
            // builtAt: true,

            // Add chunk information (setting this to `false` allows for a less verbose output)
            // chunks: true,

            // `webpack --colors` equivalent
            colors: true,
            // Add errors
            errors: true
            // ,

            // Add details to errors (like resolving log)
            // errorDetails: true
            // ,

            // Add the hash of the compilation
            // hash: true,

            // Show performance hint when file size exceeds `performance.maxAssetSize`
            // performance: true,

            // Add timing information
            // timings: true,

            // Add warnings
            // warnings: true
        },

        // Enable history API fallback so HTML5 History API based
        // routing works. This is a good default that will come
        // in handy in more complicated setups
        historyApiFallback: true,

        // setup proxy for routing api calls to backend server
        proxy,
        // port to run the dev server on
        port: devServerPort,
        host: "0.0.0.0",
        disableHostCheck: true,
        public: baseHostPort
    }
}
