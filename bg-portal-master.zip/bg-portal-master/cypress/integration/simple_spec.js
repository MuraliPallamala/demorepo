describe("My First Test", function() {
    it("asdf", function() {
        cy.visit("https://docs.cypress.io/guides/guides/screenshots-and-videos.html#Screenshots")
        cy.screenshot()
    })
})
