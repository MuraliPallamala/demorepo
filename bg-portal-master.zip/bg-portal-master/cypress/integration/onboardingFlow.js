import OnboardingFactories from "./helpers/onboardingFactories"
import abnGenerator from "./util/abnGenerator"

describe("Self-onboarding flow", function() {
    const businessId = `${abnGenerator()}`
    const testOrg = OnboardingFactories({
        businessId
    })
    const {
        entityName,
        entityAddress: { streetAddress, postalCode, addressLocality, addressRegion },
        contacts
    } = testOrg
    it("Goes to URL", function() {
        cy.server()
        cy.route("/api/platform/terms-and-conditions?type=PLATFORM").as("getPlatformTerms")
        cy.route("/api/platform/terms-and-conditions?type=USER").as("getUserTerms")

        cy.visit("https://bank-guarantee.res.ibm.com")
        cy.get("[data-cy=register]").click()
        cy.url().should("include", "/register")
        cy.wait(["@getPlatformTerms", "@getUserTerms"]).then(xhrs => {
            cy.get("[data-cy=acceptNext]").click()
            cy.get("[data-cy=acceptNext]").click()
            cy.get("[data-cy=businessId]")
                .type(testOrg.businessId)
                .should("have.value", testOrg.businessId)
            cy.get("[data-cy=entityName]")
                .type(entityName)
                .should("have.value", entityName)
            cy.get("[data-cy=streetAddress]")
                .type(streetAddress)
                .should("have.value", streetAddress)
            cy.get("[data-cy=addressLocality]")
                .type(addressLocality)
                .should("have.value", addressLocality)
            cy.get("[data-cy=postalCode]")
                .type(postalCode)
                .should("have.value", postalCode)
            // Pretty Hacky fix to find the correct input to type into
            cy.get("#react-select-3-input").type(addressRegion, { force: true })
            cy.get("#react-select-3-input").type("{enter}", { force: true })
            cy.contains("Victoria").click({ force: true })
            cy.get("[data-cy=adminSameAsPrimaryContact]").click()
            cy.get("[data-cy=primary-firstName]")
                .type(contacts[0].firstName)
                .should("have.value", contacts[0].firstName)

            cy.get("[data-cy=primary-lastName]")
                .type(contacts[0].lastName)
                .should("have.value", contacts[0].lastName)
            cy.get("[data-cy=primary-email]")
                .type(contacts[0].email)
                .should("have.value", contacts[0].email)
            cy.get("[data-cy=primary-telephone]").type(contacts[0].phone)
            cy.get("[data-cy=submit]").click()
        })
    })
    //     it("Goes to ADMIN URL", function() {
    //         cy.visit("https://admin.bank-guarantee.res.ibm.com/logout/")
    //     })
    //     it("Attempts Login", function() {
    //         cy.server()
    //         cy.route("/api/platform/terms-and-conditions?type=PLATFORM").as("getPlatformTerms")
    //         cy.route("/api/platform/terms-and-conditions?type=USER").as("getUserTerms")
    //         cy.route("/api/profile/user").as("getRedirectKey")
    //         cy.get("[data-cy=loginbutton]").click()
    //         cy.url().should("include", "/login")
    //         cy.wait(["@getRedirectKey"]).then(xhrs => {
    //             console.log(xhrs)
    //             cy.visit(xhrs.response.body.redirectUri)
    //         })
    //     })
})
