export default function createExampleOnboardingRequest({ businessId, userTCId, platformTCId }) {
    const request = {
        entityName: `Mock Company ${businessId}`,
        entityType: "APPLICANT_OR_BENEFICIARY",
        entityAddress: {
            streetAddress: "60 City Road",
            addressLocality: "Southbank",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: "3006",
            postOfficeBoxNumber: ""
        },
        businessId,
        contacts: [
            {
                firstName: "Carole",
                lastName: "Smith",
                email: "carole@example.com",
                phone: "+6139456789",
                roles: ["PRIMARY"],
                agreement: {
                    tcId: userTCId
                }
            },
            {
                firstName: "John",
                lastName: "Smith",
                email: "john.smith@example.com",
                phone: "+6139456789",
                roles: ["ADMIN"],
                agreement: {
                    tcId: userTCId
                }
            }
        ],
        agreement: {
            tcId: platformTCId
        }
    }
    return request
}
