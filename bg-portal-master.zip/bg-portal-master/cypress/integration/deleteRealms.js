// describe("My First Test", function() {
//     it("Goes to URL", function() {
//         cy.server()
//         cy.visit("https://bg-keycloak.sl.cloud9.ibm.com:8443/auth/admin/master/console/#/realms")
//         cy.get("username")
//             .type("admin")
//             .click()

//         cy.contains("atargett-5WHx").click()
//         cy.url().should("include", "/atargett-5WHx")
//     })
// })
