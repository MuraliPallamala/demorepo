const usedAbns = []

export default function getRandomAbn() {
    let randomABN = ""

    for (let i = 0; i < 9; i++) {
        randomABN += Math.floor(Math.random() * 9)
    }
    const generateCheckValues = `10${randomABN}`
    let checkValues = 0
    if (generateCheckValues.length === 11) {
        const weights = [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
        let sum = 0
        weights.forEach((weight, position) => {
            const digit = generateCheckValues[position] - (position ? 0 : 1)
            sum += weight * digit
        })
        checkValues = 89 - (sum % 89) + 10
    }
    randomABN = checkValues + randomABN

    if (usedAbns.indexOf(randomABN) === -1) {
        // not found in list, simply add it to the list and return it later
        usedAbns.push(randomABN)
    } else {
        // entry in list already, re-generate new ABN
        return getRandomAbn()
    }

    return randomABN
}
