export const PORT = process.env.PORT ? +process.env.PORT : 3000
export const DEV = process.env.DEV === "true"

export const PORTAL_TYPE = process.env.PORTAL_TYPE || "user"
export const PORTAL_ORG = process.env.PORTAL_ORG || "newco"

if (!PORTAL_TYPE) {
    throw new Error("PORTAL_TYPE must be defined")
}

if (!PORTAL_ORG) {
    throw new Error("PORTAL_ORG must be defined")
}
