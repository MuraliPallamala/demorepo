import Koa from "koa"
import koaStatic from "koa-static"
import koaBodyParser from "koa-bodyparser"
import KoaRouter from "koa-router"
import koaSend from "koa-send"
import path from "path"
import { PORT, PORTAL_TYPE, PORTAL_ORG } from "./env"

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0" // TODO remove once we stop using self signed certificates

const app = new Koa()
const router = new KoaRouter()

const distDir = `dist/${PORTAL_TYPE}/${PORTAL_ORG}`

app.use(async (ctx, next) => {
    try {
        await next()
    } catch (err) {
        ctx.status = err.status || 500
        ctx.body = err.message
        ctx.app.emit("error", err, ctx)
    }
})

const maxage = 31536000 * 1000 // 1 year

// mount static frontend to koa
app.use(koaStatic(path.join(__dirname, "..", distDir), { maxage }))

// mount parser for applicaton/json content
app.use(koaBodyParser())

/*
 * API endpoints
 */
router.get("*", async ctx => {
    await koaSend(ctx, `${distDir}/index.html`, { maxage })
})

app.use(router.routes())

// Start the app
app.listen(PORT)
console.log(`Listening on port ${PORT}`)
