/* eslint-disable import/prefer-default-export */
// @flow
import firstLetter from "~/shared/firstLetter"
import { dateToShortString } from "~/util/helpers/text"

export const userDefaults = {
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    // TODO: remove when https://github.ibm.com/bank-guarantees/bg-issues/issues/318 is resolved
    roles: ["USER"],
    gxLimit: null
}
export const mapUsers = (users: any) => {
    const mappedUsers = users.map((user, i) => mapUser(user))
    return mappedUsers
}

export const mapRemovedUsers = (users: any) => {
    const mappedUsers = users.map((user, i) => mapRemovedUser(user))
    return mappedUsers
}

export const mapRemovedUser = (deleteUserEvent: any) => {
    // index is not used and should be removed the moment we deployed this...
    const {
        id,
        firstName,
        lastName,
        email,
        phone,
        userRoles,
        status,
        primaryOrgId,
        createdAt,
        gxLimit
    } = deleteUserEvent.data.user
    const { createdAt: removedOn, userName: removedBy } = deleteUserEvent
    let formattedStatus = "Pending"
    if (status === "ACTIVE") {
        formattedStatus = "Active"
    }
    if (status === "INACTIVE") {
        formattedStatus = "Blocked"
    }
    if (status === "DELETED") {
        formattedStatus = "Removed"
    }
    const userGxLimit = gxLimit[primaryOrgId]
    const formattedUser = {
        key: id,
        userId: id,
        id,
        name: `${firstName} ${lastName}`,
        firstName,
        lastName,
        email,
        phone,
        status: firstLetter(status),
        added: dateToShortString(createdAt),
        roles: userRoles[primaryOrgId],
        token: "",
        formattedStatus,
        orgId: primaryOrgId,
        removedOn: dateToShortString(removedOn),
        removedBy,
        gxLimit: userGxLimit === -1 ? null : userGxLimit / 100
    }
    return formattedUser
}

export const mapUser = (user: any, fromApi?: boolean = true) => {
    // index is not used and should be removed the moment we deployed this...
    const { id, firstName, lastName, email, phone, roles, status, createdAt, orgId, gxLimit } = user
    let formattedStatus = "Pending"
    if (status === "ACTIVE") {
        formattedStatus = "Active"
    }
    if (status === "INACTIVE") {
        formattedStatus = "Blocked"
    }
    if (status === "DELETED") {
        formattedStatus = "Removed"
    }
    let finalGxLimit = gxLimit
    if (gxLimit === -1) {
        finalGxLimit = null
    } else if (fromApi) {
        finalGxLimit = gxLimit / 100
    }

    const formattedUser = {
        key: id,
        userId: id,
        id,
        name: `${firstName} ${lastName}`,
        firstName,
        lastName,
        email,
        phone,
        status: firstLetter(status),
        added: dateToShortString(createdAt),
        roles,
        token: "",
        formattedStatus,
        orgId,
        gxLimit: finalGxLimit
    }
    return formattedUser
}

export const mapValuesToRequest = (user: any) => {
    // index is not used and should be removed the moment we deployed this...
    const { id, firstName, lastName, email, phone, roles, orgId } = user
    const { gxLimit } = user
    const formattedUser = {
        userId: id,
        firstName,
        lastName,
        email,
        phone,
        roles,
        token: "",
        orgId,
        gxLimit: !gxLimit || gxLimit === -1 ? -1 : gxLimit * 100
    }
    return formattedUser
}
