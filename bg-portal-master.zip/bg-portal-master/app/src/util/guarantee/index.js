/* eslint-disable import/prefer-default-export */
// @flow
// import _ from "lodash/fp"
import numeral from "numeral"
import _ from "lodash"
import { dateToShortString } from "~/util/helpers/text"
import { getHighestPriorityRequest, getFlagName } from "~/util/guarantee/activeRequests"

export const mapIssuerToPayload = (issuer: string) => {
    if (issuer === "Commonwealth Bank") {
        return "commbank"
    }
    // all other banks simply need to be lower case at the moment
    return issuer.toLowerCase()
}

export const guaranteeDefaultValues = {
    purposeType: "",
    purpose: {},
    termsConditions: "",
    termsAndConditionsDisplay: "",
    currency: "AUD",
    amount: null,
    dateChecked: false,
    expiresAt: null
}

export const partiesInvolvedDefaultValues = {
    applicant: null,
    beneficiary: null,
    issuer: "",
    actOnBehalf: null
}

export const locationDetailsDefaultValues = {
    streetAddress: "",
    addressLocality: "",
    addressRegion: "",
    addressCountry: { value: "Australia", label: "Australia" },
    postalCode: "",
    postOfficeBoxNumber: ""
}

export const propertyInformationDefaultValues = {
    propertyName: "",
    shopNo: ""
}

export const demandDefaultValues = {
    sliderValue: null,
    optionalComments: ""
}

export const cancelDefaultValues = {
    reason: ""
}

export const rejectDefaultValues = {
    reason: ""
}
export const novationDefaultValues = {
    reason: "",
    otherReason: ""
}

// export const issuerMapBGDetails = {
//     anz: "ANZ",
//     ANZ: "ANZ",
//     commbank: "Commonwealth Bank",
//     testissuer: "Test Issuer",
//     westpac: "Westpac"
// }

export const guaranteeStatusMap = {
    ACTIVE: "Active",
    PAYWALKED: "Pay and Walk",
    CANCELLED: "Cancelled",
    TRANSFERRED: "Transferred",
    EXPIRED: "Expired",
    DEMANDED: "Demanded"
}

const requestStatusMap = {
    REJECTED: "Rejected",
    ACTIVE: "Pending",
    PAYWALKED: "Pay and Walk",
    CANCELLED: "Cancelled",
    WITHDRAWN: "Withdrawn",
    ABANDONED: "Cancelled",
    TRANSFERRED: "Transferred",
    EXPIRED: "Expired",
    DEMANDED: "Demanded",
    APPROVED: "Approved",
    SUCCESSFUL: "Approved"
}

const requestTypeMap = {
    ISSUE: "Issue",
    AMEND: "Amend",
    CANCEL: "Cancel",
    DEMAND: "Demand",
    PAYWALK: "Pay and Walk",
    TRANSFER: "Transfer",
    EXPIRE: "Expire"
}

export const mapGxRequestToTableValues = (requests: any, myOrgId: string) => {
    const mappedRequests = requests.map(item => {
        const { id, gxId, type, guaranteeId, createdAt, createdBy, status } = item

        const formValues = {
            gxId: gxId || "-",
            guaranteeId,
            requestType: requestTypeMap[type],
            status: requestStatusMap[status],
            requestId: id,
            createdBy: createdBy.entityName,
            createdAt: dateToShortString(createdAt)
        }
        return formValues
    })
    return mappedRequests
}

export const mapRequestToTableValues = (requests: any, myOrgId: string) => {
    const mappedRequests = requests.map(item => {
        // eslint-disable-next-line one-var
        let id,
            type,
            createdAt,
            createdBy,
            status,
            issuer,
            bankReference,
            currency,
            outstanding,
            newBeneficiaries,
            beneficiaries,
            applicants,
            expiresAt,
            purpose,
            newExpiresAt,
            guaranteeId,
            reason,
            purposeType

        if (item.type === "ISSUE") {
            ;({
                id,
                type,
                createdAt,
                // createdBy,
                status,
                createdBy,
                payload: {
                    issuer,
                    bankReference,
                    amount: { outstanding, currency },
                    beneficiaries,
                    applicants,
                    expiresAt,
                    purpose,
                    purposeType
                }
            } = item)
        } else if (item.type === "TRANSFER") {
            // transfer
            ;({
                id,
                type,
                createdAt,
                createdBy,
                status,
                guaranteeId,
                payload: {
                    beneficiaries: newBeneficiaries,
                    gx: {
                        issuer,
                        bankReference,
                        amount: { outstanding, currency },
                        beneficiaries,
                        applicants,
                        expiresAt,
                        purpose
                    },
                    purposeType
                }
            } = item)
        } else {
            // amend, cancel, etc
            ;({
                id,
                type,
                createdAt,
                createdBy,
                status,
                guaranteeId,
                payload: { purpose, amount: outstanding, expiresAt: newExpiresAt, reason, purposeType }
            } = item)
            beneficiaries = null
            applicants = null
        }

        const formValues = {
            requestType: requestTypeMap[type],
            status: requestStatusMap[status],
            currency,
            createdBy: createdBy.entityName,
            requestId: id,
            guaranteeId,
            beneficiary: beneficiaries && beneficiaries[0] ? beneficiaries[0].entityName : null,
            applicant: applicants ? applicants[0].entityName : null,
            applicantId: applicants ? applicants[0].id : null,
            beneficiaryId: beneficiaries ? beneficiaries[0].id : null,
            // need to divide value by 100 because the server stores values of cents
            amount: outstanding || "",
            bankReference,
            createdAt: dateToShortString(createdAt),
            orginialCreatedAt: createdAt,
            issuer: issuer ? issuer.entityName : null,
            expiresAt: expiresAt ? dateToShortString(expiresAt) : "Open Ended",
            orginialExpiresAt: expiresAt,
            newExpiresAt: newExpiresAt ? dateToShortString(newExpiresAt) : null,
            purpose,
            newBeneficiaries,
            reason: reason || null,
            purposeType
        }
        return formValues
    })
    return mappedRequests
}

export const mapBGToTableValues = (requests: any) => {
    const mappedRequests = requests.map(item => {
        const {
            issuedAt,
            bankReference,
            status,
            type,
            issuer,
            amount: { outstanding, currency },
            id,
            beneficiaries,
            applicants,
            expiresAt,
            activeRequests
        } = item
        const formValues = {
            status: guaranteeStatusMap[status],
            type,
            currency,
            // requestId: id,
            beneficiary: beneficiaries[0].entityName,
            applicant: applicants[0].entityName,
            amount: `${currency} ${numeral(outstanding / 100).format("0,0.00")}`,
            bankReference,
            issuedAt: dateToShortString(issuedAt),
            issuer: issuer.entityName,
            expiresAt: expiresAt ? dateToShortString(expiresAt) : "Open Ended",
            id,
            highestPriorityActiveRequest: getFlagName(getHighestPriorityRequest(activeRequests))
        }
        return formValues
    })
    return mappedRequests
}

// gx payloads
export const mapGXPayloadToBGDetails = (values: Object) => {
    const {
        applicants,
        beneficiaries,
        issuer,
        purpose,
        purposeType,
        amount: { outstanding, currency, demanded },
        tcId,
        issuedAt,
        updatedAt,
        expiresAt,
        bankReference,
        prevGxId,
        status,
        id
    } = values
    const bgDetails = {
        id,
        applicant: {
            name: applicants[0].entityName,
            businessId: applicants[0].businessId,
            orgId: applicants[0].id
        },
        beneficiary: {
            name: beneficiaries[0].entityName,
            businessId: beneficiaries[0].businessId,
            orgId: beneficiaries[0].id
        },
        issuer: issuer
            ? {
                  name: issuer.entityName,
                  businessId: issuer.businessId,
                  orgId: issuer.id
              }
            : { name: "", businessId: "", orgId: "" },

        comments: "",
        type: {
            guaranteeType: purposeType,
            expiry: expiresAt ? dateToShortString(expiresAt) : "Open Ended",
            amount: { outstanding: outstanding / 100, demanded: demanded / 100 },
            currency,
            termsAndConditionsDisplay: "",
            tcId
        },
        purpose,
        purposeType,
        issuedAt: dateToShortString(issuedAt),
        updatedAt,
        bankReference,
        prevGxId,
        // TODO: what should status be in case of issuance request thats successful or unsucessful
        status
    }
    return bgDetails
}
// request payloads
export const mapPayloadToBGDetails = (values: Object) => {
    let res
    if (values.type === "TRANSFER") {
        res = mapGxInfo(values.payload.gx)
    } else if (values.type === "ISSUE") {
        res = mapGxInfo(values.payload)
    }
    const { status, id, guaranteeId } = values
    const bgDetails = {
        id,
        guaranteeId,
        status: status === "ACTIVE" ? "PENDING" : status,
        ...res
    }
    return bgDetails
}

export const mapGxInfo = (values: Object) => {
    const {
        applicants,
        beneficiaries,
        issuer,
        purpose,
        purposeType,
        amount: { outstanding, currency, demanded },
        tcId,
        issuedAt,
        updatedAt,
        expiresAt,
        bankReference
    } = values
    const bgDetails = {
        applicant: {
            name: applicants[0].entityName,
            businessId: applicants[0].businessId,
            orgId: applicants[0].id
        },
        beneficiary: {
            name: beneficiaries[0].entityName,
            businessId: beneficiaries[0].businessId,
            orgId: beneficiaries[0].id
        },
        issuer: issuer
            ? {
                  name: issuer.entityName,
                  businessId: issuer.businessId,
                  orgId: issuer.id
              }
            : { name: "", businessId: "", orgId: "" },
        comments: "",
        type: {
            guaranteeType: purposeType,
            expiry: expiresAt ? dateToShortString(expiresAt) : "Open Ended",
            amount: { outstanding: outstanding / 100, demanded: demanded / 100 },
            currency,
            tcId,
            termsAndConditionsDisplay: ""
        },
        purpose,
        purposeType,
        issuedAt: dateToShortString(issuedAt),
        updatedAt,
        bankReference
    }
    return bgDetails
}
export const mapAmendRequestToBGDetails = (values: Object) => {
    const {
        amount,
        purpose: {
            address: { addressCountry, addressLocality, addressRegion, postalCode, postOfficeBoxNumber, streetAddress },
            freeFormText,
            shopNumber,
            propertyName
        }
    } = values
    const bgDetails = {
        details: {
            name: propertyName,
            shopNo: shopNumber
        },
        location: {
            street: streetAddress,
            suburb: addressLocality,
            postcode: postalCode,
            state: addressRegion,
            country: addressCountry,
            postOfficeBoxNumber
        },
        type: {
            amount: {
                outstanding: amount
            },
            purpose: freeFormText
        }
    }
    return bgDetails
}

export const mapAmendFormValuesToRequest = (values: Object) => {
    const { purpose, amount, expiresAt, dateChecked } = values

    // only add values to request if they exist (they have been changed)
    const req = {}
    if (amount) {
        req.amount = parseFloat(amount) * 100
    }
    if (dateChecked) {
        req.expiresAtOpenEnded = true
        req.expiresAt = null
    } else if (expiresAt) {
        req.expiresAt = expiresAt
    }
    if (purpose) {
        _.set(req, "purpose", purpose)
    }

    return req
}
export const mapFormValuesToRequest = (values: Object) => {
    const {
        applicant,
        beneficiary,
        issuer,
        currency,
        amount,
        expiresAt,
        purposeType,
        dateChecked,
        purpose,
        termsConditions
    } = values
    const apiValues = {
        purposeType,
        applicants: [applicant.orgId],
        beneficiaries: [beneficiary.orgId],
        bankReference: "",
        issuer: issuer === "" ? null : issuer,
        purpose,
        amount: {
            // need to multiple value by 100 because the server stores the value in cents
            outstanding: parseFloat(amount) * 100,
            currency
        },
        expiresAt: null,
        tcId: termsConditions
    }
    if (!dateChecked) {
        apiValues.expiresAt = expiresAt
    }

    return apiValues
}

export const mapRequestToGuaranteeFormValues = (values: Object) => {
    const {
        applicant,
        beneficiary,
        addressCountry,
        addressLocality,
        addressRegion,
        streetAddress,
        postOfficeBoxNumber,
        propertyName,
        shopNo,
        postalCode,
        comments,
        issuer,
        currency,
        amount,
        expiresAt
    } = values

    const apiValues = {
        applicants: [applicant.orgId],
        beneficiaries: [beneficiary.orgId],
        bankReference: "",
        issuer,
        purpose: {
            address: {
                addressCountry: addressCountry.value,
                addressLocality,
                addressRegion: addressRegion.value,
                streetAddress,
                postOfficeBoxNumber,
                postalCode
            },
            propertyName,
            shopNumber: shopNo,
            freeFormText: comments
        },
        amount: {
            outstanding: amount,
            currency
        },
        expiresAt
    }
    return apiValues
}

export const mapGuaranteeToFormValues = (values: Object) => {
    const {
        applicants,
        beneficiaries,
        purpose,
        amount: { currency, outstanding },
        expiresAt,
        issuer,
        reason,
        purposeType,
        tcId,
        activeRequests
    } = values
    const todaysDate = new Date()
    const isNotOtherReason =
        reason === "Contract Transfer" ||
        reason === "Corporate Restructure" ||
        reason === "Sale" ||
        reason === "" ||
        !reason
    const reasonFields = {
        reason: isNotOtherReason ? reason : "Other",
        otherReason: isNotOtherReason ? "" : reason
    }
    const mappedValues = {
        applicant: {
            name: applicants[0].entityName,
            businessId: applicants[0].businessId,
            orgId: applicants[0].id
        },
        beneficiary: {
            name: beneficiaries[0].entityName,
            businessId: beneficiaries[0].businessId,
            orgId: beneficiaries[0].id
        },
        purpose,
        issuer: issuer
            ? {
                  name: issuer.entityName,
                  businessId: issuer.businessId,
                  orgId: issuer.id
              }
            : null,
        currency,
        termsConditions: tcId,
        termsAndConditionsDisplay: "",
        amount: outstanding / 100,
        expiresAt: expiresAt && new Date(expiresAt) > todaysDate ? expiresAt : null,
        purposeType,
        dateChecked: !expiresAt,
        highestPriorityActiveRequest: getFlagName(getHighestPriorityRequest(activeRequests)),
        ...reasonFields
    }
    return mappedValues
}
