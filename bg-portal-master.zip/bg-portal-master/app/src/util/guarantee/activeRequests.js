/* eslint no-bitwise:0 */

export const NONE = 0
export const AMEND = 1
export const CANCEL = 2
export const DEMAND = 4
export const PAY_WALK = 8
export const TRANSFER = 16

export const FLAG_NAMES = {
    [NONE]: "–",
    [AMEND]: "Amend",
    [CANCEL]: "Cancel",
    [DEMAND]: "Demand",
    [PAY_WALK]: "Pay and Walk",
    [TRANSFER]: "Transfer"
}

export const getHighestPriorityRequest = bitmask => {
    if ((bitmask & PAY_WALK) === PAY_WALK) {
        return PAY_WALK
    }
    if ((bitmask & DEMAND) === DEMAND) {
        return DEMAND
    }
    if ((bitmask & CANCEL) === CANCEL) {
        return CANCEL
    }
    if ((bitmask & AMEND) === AMEND) {
        return AMEND
    }
    if ((bitmask & TRANSFER) === TRANSFER) {
        return TRANSFER
    }
    return NONE
}

export const getFlagName = flag => FLAG_NAMES[flag]
