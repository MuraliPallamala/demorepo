/* eslint-disable import/prefer-default-export */
// @flow

export const mapOrgData = (orgData: any) => {
    const {
        entityName,
        businessId,
        entityAddress: {
            streetAddress,
            addressCountry,
            addressRegion,
            addressLocality,
            postOfficeBoxNumber,
            postalCode
        }
    } = orgData

    const mappedOrgData = {
        entityName,
        businessID: businessId.split("_").pop(),
        streetAddress,
        addressCountry: {
            value: addressCountry,
            label: addressCountry
        },
        addressRegion: {
            value: addressRegion,
            label: addressRegion
        },
        addressLocality,
        postOfficeBoxNumber,
        postalCode
    }
    return mappedOrgData
}

export const mapRequestData = (orgData: any) => {
    const {
        entityName,
        businessID,
        address: { streetAddress, addressCountry, addressRegion, addressLocality, postOfficeBoxNumber, postalCode }
    } = orgData

    const mappedOrgData = {
        entityName,
        businessID: businessID.split("_").pop(),
        streetAddress,
        addressCountry: {
            value: addressCountry,
            label: addressCountry
        },
        addressRegion: {
            value: addressRegion,
            label: addressRegion
        },
        addressLocality,
        postOfficeBoxNumber,
        postalCode
    }
    return mappedOrgData
}

export const mapPrimaryContact = (contacts: any) => {
    const primaryContact = {}
    for (let i = 0; i < contacts.length; i++) {
        if (contacts[i].roles.includes("PRIMARY")) {
            primaryContact.firstName = contacts[i].firstName
            primaryContact.lastName = contacts[i].lastName
            primaryContact.email = contacts[i].email
            primaryContact.phone = contacts[i].phone
            primaryContact.mobile = contacts[i].mobile
            primaryContact.dateAdded = "No date Added"
            break
        }
    }
    return primaryContact
}

export const mapValuesToRequest = ({
    entityName,
    streetAddress,
    addressLocality,
    addressRegion,
    postalCode,
    addressCountry,
    postOfficeBoxNumber
}: any) => {
    const submitValue = {
        entityName,
        address: {
            streetAddress,
            addressLocality,
            addressRegion: addressRegion.value,
            addressCountry: addressCountry.value,
            postalCode,
            postOfficeBoxNumber
        }
    }
    return submitValue
}

export const mapHistoryDataToValues = ({
    entityName,
    address: { streetAddress, addressLocality, addressRegion, addressCountry, postalCode, postOfficeBoxNumber }
}: any) => {
    const formattedValues = {
        entityName,
        streetAddress,
        addressLocality,
        postalCode,
        postOfficeBoxNumber,
        businessID: "",
        addressCountry: {
            value: "Australia",
            label: "Australia"
        },
        addressRegion: {
            value: addressRegion,
            label: addressRegion
        }
    }
    return formattedValues
}
