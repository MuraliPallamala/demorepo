// @flow

const BG = {
    UNLIMITED_GX_LIMIT: -1
}

export default BG
