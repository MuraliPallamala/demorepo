// From http://ecma-international.org/ecma-262/5.1/#sec-15.9.1.1
export const MAXIMUM_DATE = new Date(8640000000000000)
export const MINIMUM_DATE = new Date(-8640000000000000)
