// @flow

// Constants and Types for named entities/things

export const BANK = {
    ANZ: "ANZ",
    Westpac: "Westpac"
}

export const CURRENCY = {
    AUD: "AUD",
    NZD: "NZD",
    USD: "USD"
}
