/* eslint-disable import/prefer-default-export */
// @flow

export const mapFormValuesToRequest = ({
    entityName,
    streetAddress,
    addressLocality,
    addressRegion,
    addressCountry,
    postalCode,
    postOfficeBoxNumber,
    businessID,
    primaryFirstName,
    primaryLastName,
    primaryEmail,
    primaryPhone,
    primaryMobile,
    adminSameAsPrimaryContact,
    adminFirstName,
    adminLastName,
    adminEmail,
    adminPhone,
    adminMobile
}: any) => {
    const request = {
        entityName,
        entityType: "APPLICANT_OR_BENEFICIARY",
        entityAddress: {
            streetAddress,
            addressLocality,
            addressRegion: addressRegion.value,
            addressCountry: addressCountry.value,
            postalCode,
            postOfficeBoxNumber
        },
        businessId: businessID.replace(/\s/g, ""),
        contacts: []
    }

    const primary = {
        firstName: primaryFirstName,
        lastName: primaryLastName,
        email: primaryEmail,
        phone: primaryPhone.charAt(0) !== "+" ? `+${primaryPhone}` : primaryPhone,
        roles: ["PRIMARY", "USER"]
    }
    if (adminSameAsPrimaryContact) {
        primary.roles.push("ADMIN")
        request.contacts.push(primary)
    } else {
        request.contacts.push(primary)
        request.contacts.push({
            firstName: adminFirstName,
            lastName: adminLastName,
            email: adminEmail,
            phone: adminPhone.charAt(0) !== "+" ? `+${adminPhone}` : adminPhone,
            roles: ["ADMIN", "USER"]
        })
    }

    return request
}

export const mapFormValuesAndTCsToRequest = (values: Object, platformTCID: string, userTCID: string) => {
    const request: any = mapFormValuesToRequest(values)

    request.agreement = {
        tcId: platformTCID
    }

    request.contacts[0].agreement = {
        tcId: userTCID
    }

    return request
}

export const mapRequestToFormValues = ({
    entityName,
    entityAddress: { streetAddress, addressLocality, addressRegion, addressCountry, postalCode, postOfficeBoxNumber },
    businessId,
    contacts
}: any) => {
    const formValues = {
        entityName,
        streetAddress,
        addressLocality,
        addressRegion: { value: addressRegion, label: addressRegion },
        addressCountry: { value: addressCountry, label: addressCountry },
        postalCode,
        postOfficeBoxNumber,
        businessID: businessId,
        primaryFirstName: "",
        primaryLastName: "",
        primaryEmail: "",
        primaryPhone: "",
        primaryMobile: "",
        adminSameAsPrimaryContact: false,
        adminFirstName: "",
        adminLastName: "",
        adminEmail: "",
        adminPhone: "",
        adminMobile: ""
    }
    const primaryContact = contacts.find(contact => contact.roles.includes("PRIMARY"))
    const adminSameAsPrimaryContact = primaryContact.roles.includes("ADMIN")

    formValues.primaryFirstName = primaryContact.firstName
    formValues.primaryLastName = primaryContact.lastName
    formValues.primaryEmail = primaryContact.email
    formValues.primaryPhone = primaryContact.phone
    formValues.primaryMobile = primaryContact.mobile
    formValues.adminSameAsPrimaryContact = adminSameAsPrimaryContact

    if (!adminSameAsPrimaryContact) {
        const adminContact = contacts.find(contact => contact.roles.includes("ADMIN"))
        formValues.adminFirstName = adminContact.firstName
        formValues.adminLastName = adminContact.lastName
        formValues.adminEmail = adminContact.email
        formValues.adminPhone = adminContact.phone
        formValues.adminMobile = adminContact.mobile
    }

    return formValues
}

export const organizationDetailsDefaultValues = {
    entityName: "",
    streetAddress: "",
    addressLocality: "",
    addressRegion: "",
    addressCountry: { value: "Australia", label: "Australia" },
    postalCode: "",
    postOfficeBoxNumber: "",
    businessID: ""
}

export const primaryContactDefaultValues = {
    primaryFirstName: "",
    primaryLastName: "",
    primaryEmail: "",
    primaryPhone: "",
    primaryMobile: ""
}

export const adminContactDefaultValues = {
    adminFirstName: "",
    adminLastName: "",
    adminEmail: "",
    adminPhone: "",
    adminMobile: ""
}
export const verifyCheckboxes = {
    orgVerify: false,
    primaryVerify: false,
    adminVerify: false
}

export const optionalAdminContactDefaultValues = {
    ...adminContactDefaultValues,
    adminSameAsPrimaryContact: false
}

export const onboardingDefaultValues = {
    ...organizationDetailsDefaultValues,
    ...primaryContactDefaultValues,
    ...adminContactDefaultValues,
    ...optionalAdminContactDefaultValues,
    ...verifyCheckboxes
}
