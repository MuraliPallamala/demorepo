// @flow

import PdfJsLib from "pdfjs-dist"
import React, { Component } from "react"

type Props = {
    file: string | Object,
    page: number,
    onDocumentComplete: Function,
    scale: number,
    cMapUrl: string,
    cMapPacked: boolean,
    className?: string,
    customWidth: string
}

type State = {
    pdf: ?Object
}

export default class ReactPdfJs extends Component<Props, State> {
    static defaultProps = {
        page: 1,
        onDocumentComplete: null,
        scale: 2,
        cMapUrl: "../node_modules/pdfjs-dist/cmaps/",
        cMapPacked: false,
        customElements: "inherit"
    }

    state = {
        pdf: null
    }

    componentDidMount() {
        this.makePdf()
    }

    makePdf = () => {
        const { file, onDocumentComplete, page, cMapUrl, cMapPacked } = this.props
        PdfJsLib.GlobalWorkerOptions.workerSrc = "//cdnjs.cloudflare.com/ajax/libs/pdf.js/2.0.943/pdf.worker.js"
        PdfJsLib.getDocument({ url: file, cMapUrl, cMapPacked }).then(pdf => {
            this.setState({ pdf })
            if (onDocumentComplete) {
                onDocumentComplete(pdf._pdfInfo.numPages); // eslint-disable-line
            }
            pdf.getPage(page).then(p => this.drawPDF(p))
        })
    }

    componentDidUpdate(prevProps: Props) {
        const { page, scale, file } = this.props
        const { pdf } = this.state
        if (prevProps.page !== page && pdf) {
            pdf.getPage(page).then(p => this.drawPDF(p))
        }
        if (prevProps.scale !== scale && pdf) {
            pdf.getPage(page).then(p => this.drawPDF(p))
        }
        if (prevProps.file !== file && pdf) {
            this.makePdf()
            pdf.getPage(page).then(p => this.drawPDF(p))
        }
    }

    drawPDF = (page: Object) => {
        const { scale } = this.props
        const viewport = page.getViewport(scale)
        const { canvas } = this// eslint-disable-line
        const canvasContext = canvas.getContext("2d")
        canvas.height = viewport.height
        canvas.width = viewport.width
        const renderContext = {
            canvasContext,
            viewport
        }
        page.render(renderContext)
    }

    render() {
        const { className, customWidth } = this.props
        return (
            <canvas
                css={{ width: customWidth }}
                ref={canvas => {
                    this.canvas = canvas// eslint-disable-line
                }}
                className={className}
            />
        )
    }
}
