/* eslint-disable import/prefer-default-export */
// @flow

export const asicMap = (asicValues: Object) => {
    const { AddressPostcode, AddressState, EntityName } = asicValues
    const mappedValues = {
        streetAddress: "No Data",
        addressCountry: "Australia",
        addressLocality: "No Data",
        postalCode: AddressPostcode,
        addressRegion: AddressStateMap[AddressState.toLowerCase()],
        entityName: EntityName
    }
    return mappedValues
}

export const asicAutoFillMap = (asicValues: Object) => {
    const { AddressPostcode, AddressState, EntityName } = asicValues
    const addressRegion = AddressStateMap[AddressState.toLowerCase()]
    const mappedValues = {
        streetAddress: "",
        addressCountry: { value: "Australia", label: "Australia" },
        addressLocality: "",
        postalCode: AddressPostcode,
        addressRegion: { value: addressRegion, label: addressRegion },
        entityName: EntityName
    }
    return mappedValues
}
const AddressStateMap = {
    act: "Australian Capital Territory",
    qld: "Queensland",
    vic: "Victoria",
    sa: "South Australia",
    nt: "Northern Territory",
    tas: "Tasmania",
    wa: "Western Australia",
    nsw: "New South Wales"
}
