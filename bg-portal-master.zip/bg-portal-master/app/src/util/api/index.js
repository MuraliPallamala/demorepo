import axios from "axios"

axios.defaults.timeout = 60 * 1000

// eslint-disable-next-line
const api = require(`./${PORTAL_TYPE}`)

if (DEV) {
    // Allows any requests that have mocks that weren't defined to fallback to actual api
    const { mock, authMock } = require("./util/mock") // eslint-disable-line global-require
    mock.onAny().passThrough()
    authMock.onAny().passThrough()
}

export default api
