// @flow
import authAxios from "../util/authAxios"
/* eslint import/prefer-default-export:0 */

export const getAllRequests = () => authAxios.get(`/api/profile/requests`)

export const getOrgRequests = (orgId: string, filter: string) =>
    authAxios.get(`/api/profile/orgs/${orgId}/requests${filter}`)

export const actionManagement = (orgId: string, requestId: string, type: string, actionId?: string) =>
    authAxios.post(`/api/profile/orgs/${orgId}/requests/${requestId}/actions`, { type, actionId })
