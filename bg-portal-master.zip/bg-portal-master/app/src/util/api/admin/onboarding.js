import authAxios from "../util/authAxios"

// used below for all action endpoints
const actionUrl = id => `/api/profile/onboarding-requests/${id}/actions`

export * from "../base/onboarding"

export const approveOnboardingRequest = (id, actionId?) =>
    authAxios.post(actionUrl(id), {
        type: "APPROVE",
        actionId
    })

export const rejectOnboardingRequest = (id, reason, actionId?) =>
    authAxios.post(actionUrl(id), {
        type: "REJECT",
        actionId,
        payload: {
            reason
        }
    })

// TODO update request body once api spec is available
export const verifyOnboardingRequest = (id, type, actionId) =>
    authAxios.post(actionUrl(id), {
        type: "VERIFY",
        payload: {
            verifyObject: type
        }
    })

export const revokeOnboardingRequest = (id, type, actionId) =>
    authAxios.post(actionUrl(id), {
        type: "REVOKE",
        payload: {
            verifyObject: type
        },
        actionId
    })
