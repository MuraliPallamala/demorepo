import { authMock } from "../util/mock"

authMock.onPost(new RegExp("/api/profile/onboarding-requests/.+/actions")).reply(config => {
    const data = JSON.parse(config.data)

    switch (data.type) {
        case "Approve":
            return [200]
        case "Reject":
            return [200]
        case "Verify":
            return [200]
        default:
            return [500]
    }
})
