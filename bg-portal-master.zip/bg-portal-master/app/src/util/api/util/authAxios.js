import axios from "axios"
import { authStorage, isTokenSetExpired, logout } from "~/util/auth"

const authAxios = axios.create()

authAxios.interceptors.request.use(
    async config => {
        //  Add Auth Token
        let tokenSet = authStorage.getTokenSet()
        if (!tokenSet) {
            logout()
        }
        if (isTokenSetExpired(tokenSet)) {
            tokenSet = await authStorage.refreshTokenSet(tokenSet)
        }
        const actingOn = authStorage.getActingOn()
        if (actingOn && actingOn !== "undefined" && !config.removeParentHeader) {
            config.headers["X-DLT-Target-Org"] = actingOn
        }
        config.requestStartTime = Date.now()
        // Set headers
        config.headers.Authorization = `Bearer ${tokenSet.access_token}`

        return config
    },
    error => Promise.reject(error)
)

// Add a response interceptor
authAxios.interceptors.response.use(
    response => {
        response.config.requestTime = Date.now() - response.config.requestStartTime
        console.log(
            `API RESPONSE TIME: ${response.config.requestTime} API HEADER: ${response.config.url} API METHOD: ${
                response.config.method
            }`
        )
        return response
    },
    error => {
        if (error.response && error.response.status === 401) {
            // hard redirect, should not occur often as token will be refreshed when expired
            logout()
        }
        if (error.response && error.response.config) {
            console.error(`API HEADER: ${error.response.config.url} API METHOD: ${error.response.config.method}`)
            error.info = { url: error.response.config.url, method: error.response.config.method }
        } else {
            console.error(error)
        }
        // NOTE can't use Promise.reject with mock adapter. Mock adapter bugs out
        // TODO file issue against https://github.com/ctimmerm/axios-mock-adapter/issues/61
        throw error
    }
)

export default authAxios
