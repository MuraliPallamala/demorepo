import axios from "axios"
import MockAdapter from "axios-mock-adapter"
import authAxios from "./authAxios"

export const mock = new MockAdapter(axios)

export const authMock = new MockAdapter(authAxios)
