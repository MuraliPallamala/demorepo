import * as MOCK_DATA from "~/util/mock-data"
import { mock } from "../util/mock"

// Validates token and get existing onboarding request
// mock.onGet("/api/profile/new").reply(200, MOCK_DATA.onboarding.onboardingRequest)
// mock.onPost("/api/profile/new").reply(200, MOCK_DATA.onboarding.onboardingRequestResponse)

// Gets T&C by type
mock.onGet("/api/platform/terms-and-conditions").reply(200, {
    result: [MOCK_DATA.onboarding.TermsAndConditions]
})

// Validates token and gets organization profile
// mock.onGet("/api/profile/new/user").reply(200, MOCK_DATA.onboarding.primaryContactUserProfileRequest)
mock.onGet("/api/profile/new/user").reply(200, MOCK_DATA.onboarding.adminContactUserProfileRequest)

// Sets password
mock.onPut("/api/profile/new/user/password").reply(200)

// Sets TC
mock.onPut("/api/profile/new/user/tc").reply(200)
