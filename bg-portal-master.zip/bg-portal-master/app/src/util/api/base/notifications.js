// @flow
/* eslint import/prefer-default-export:0 */

import authAxios from "../util/authAxios"

export const getNotifications = (query: string = "") => authAxios.get(`/api/alerts${query}`)
export const getNotificationWithQuery = (query: string) => authAxios.get(`/api/alerts${query}`)

export const changeNotificationStatus = (notificationId: string) =>
    authAxios.put(`api/alerts/${notificationId}/status`, {
        value: "READ"
    })

export const dismissNotification = (notificationId: string) =>
    authAxios.put(`api/alerts/${notificationId}/status`, {
        value: "DISMISSED"
    })
