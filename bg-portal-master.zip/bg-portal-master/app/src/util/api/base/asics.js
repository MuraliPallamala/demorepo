// @flow
/* eslint import/prefer-default-export:0 */
import axios from "axios"

export const searchAsicsBusinessId = (businessId: string) =>
    axios.get(`/api/platform/services/asic?businessId=${businessId}`)

export const searchAsicsAbn = (abn: string) => axios.get(`/api/platform/services/asic?abn=${abn}`)

export const searchAsicsAcn = (acn: string) => axios.get(`/api/platform/services/asic?acn=${acn}`)
