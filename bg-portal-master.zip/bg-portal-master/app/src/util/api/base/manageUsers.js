// @flow
/* eslint import/prefer-default-export:0 */

import authAxios from "../util/authAxios"

export const addUser = (values: Object) => authAxios.post(`/api/profile/org/users`, values)
// body { firstName": "Bob", lastName: "Rollings", phone: "+61 03 5696 9392", email: "bob@powertown.com", roles: ["ADMIN", "PRIMARY"]}

export const getAllUsers = (value: string) =>
    authAxios.get(`/api/profile/org/users${value}`, { removeParentHeader: true })

// value: {?start}&limit={limit}&role={role}

export const getUser = (userId: string) => authAxios.get(`/api/profile/org/users/${userId}`)

export const getUserToken = (userId: string) => authAxios.get(`/api/profile/org/users/${userId}/token`)

export const updateUser = (values: Object, userId: string) => authAxios.put(`/api/profile/org/users/${userId}`, values)
// body { firstName": "Bob", lastName: "Rollings", phone: "+61 03 5696 9392", email: "bob@powertown.com", roles: ["ADMIN", "PRIMARY"]}

export const deleteUser = (userId: string) => authAxios.delete(`/api/profile/org/users/${userId}`)

export const setUserStatus = (values: Object, userId: string) =>
    authAxios.put(`/api/profile/org/users/${userId}/status`, values)
// body { status: "PENDING" }

export const addUserRoles = (values: Object, userId: string) =>
    authAxios.post(`/api/profile/org/users/${userId}/roles`, values)
// body { roles: ["ADMIN", "INITIATOR"]}

export const getUserRoles = (userId: string) => authAxios.get(`/api/profile/org/users/${userId}/roles`)

export const deleteUserRole = (userId: string, roleName: string) =>
    authAxios.delete(`/api/profile/org/users/${userId}/roles/${roleName}`)

export const updateStatus = (userId: string, status: string) =>
    authAxios.put(`/api/profile/org/users/${userId}/status`, { status })

export const updateParentUserRoles = (users: Array<Object>, orgId: string) => {
    const usersObject = users.reduce((acc, user) => {
        acc[user.id] = user.roles
        return acc
    }, {})
    const taskReq = {
        type: "UPDATE_USER_ROLES",
        async: false,
        payload: {
            task: {
                scope: {
                    role: "USER"
                },
                targetOrgId: orgId,
                method: "REPLACE",
                users: usersObject
            }
        }
    }

    return authAxios.post(`/api/profile/org/users/tasks`, taskReq)
}

export const updateAdminStatus = (user: Object, newRole: string) => {
    let newRoles = user.roles.filter(role => role !== "ADMIN")
    if (newRole) {
        newRoles = user.roles.push(newRole)
    }
    const userObject = {
        [user.id]: newRoles
    }
    const taskReq = {
        type: "UPDATE_USER_ROLES",
        async: false,
        payload: {
            task: {
                scope: {
                    role: "USER"
                },
                method: "REPLACE",
                users: userObject
            }
        }
    }

    return authAxios.post(`/api/profile/org/users/tasks`, taskReq)
}

export const updateParentUser = (userId: string, roles: Array<string>, gxLimit: number, orgId: string) => {
    const body = {
        gxLimit,
        roles
    }
    return authAxios.put(`/api/profile/org/users/${userId}`, body, {
        headers: { "X-DLT-Target-Org": orgId, "Content-Type": "application/json" }
    })
}

export const updateAdminAndPrimaryUser = (userId: string, roles: Array<string>, gxLimit: number) => {
    const body = {
        gxLimit,
        roles
    }
    return authAxios.put(`/api/profile/org/users/${userId}`, body)
}
