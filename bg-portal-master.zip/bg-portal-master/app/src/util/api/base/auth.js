// @flow
import axios from "axios"
import jwt from "jsonwebtoken"

const formatTokenSet = (requestKey, resp) => {
    resp.data.decodedID = jwt.decode(resp.data.id_token)
    resp.data.requestKey = requestKey
    resp.data.expires_at = new Date().valueOf() + resp.data.expires_in * 1000
    return resp
}

// NOTE can be any protected url
export const getAuthRedirect = (key?: string) =>
    axios.get("/api/profile/user", {
        headers: key
            ? {
                  "X-DLT-Request-Key": key
              }
            : {},
        validateStatus: status => status === 401
    })

type CbParams = {
    code: string,
    session_state: string
}
export const getTokenSet = ({ code, session_state: sessionState }: CbParams, key?: string) => {
    const baseHeaders = {
        "X-DLT-OIDC-Authorization-Code": code,
        "X-DLT-OIDC-Session-State": sessionState
    }
    const headers = key
        ? {
              ...baseHeaders,
              "X-DLT-Request-Key": key
          }
        : baseHeaders

    return axios
        .get("/api/auth/oidc/token", {
            headers
        })
        .then(resp => formatTokenSet(key, resp))
}

export const refreshTokenSet = (refreshToken: string, key?: string) => {
    const baseHeaders = {
        "X-DLT-OIDC-Refresh-Token": refreshToken
    }
    const headers = key
        ? {
              ...baseHeaders,
              "X-DLT-Request-Key": key
          }
        : baseHeaders

    return axios
        .get("/api/auth/oidc/token", {
            headers
        })
        .then(resp => formatTokenSet(key, resp))
}
