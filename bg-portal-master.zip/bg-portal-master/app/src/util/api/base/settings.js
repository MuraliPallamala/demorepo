// @flow
/* eslint import/prefer-default-export:0 */
import authAxios from "../util/authAxios"

export const getCurrentOrg = () => authAxios.get("/api/profile/org")

export const getOrgSettings = () => authAxios.get("/api/profile/org/settings", { removeParentHeader: true })

export const getOrgRelationships = () =>
    authAxios.get("/api/profile/org/settings/relationships", { removeParentHeader: true })

export const getOrgRoles = (parentId: string) =>
    authAxios.get("/api/profile/org/settings/roles", {
        targetOrgId: parentId || null,
        removeParentHeader: !parentId
    })

export const deleteBusinessAccount = (accountId: string) =>
    authAxios.delete(`/api/profile/org/settings/accounts/${accountId}`, { removeParentHeader: true })

export const updateBusinessAccount = (values: Object, accountId: string) =>
    authAxios.put(`/api/profile/org/settings/accounts/${accountId}`, { ...values, removeParentHeader: true })

export const changeRequest = (values: Object, requestType: string) =>
    authAxios.post("/api/profile/org/requests", { requestType, payload: values })

export const getRequests = () => authAxios.get("/api/profile/org/requests")

export const getConfirmedRequests = () => authAxios.get("/api/profile/org/requests?status=CONFIRMED")

export const getConfirmedChangeRequests = () =>
    authAxios.get("/api/profile/org/requests?status=CONFIRMED&type=CHANGE_DETAILS")

export const submitRequest = (requestId: string, type: string) =>
    authAxios.post(`/api/profile/org/requests/${requestId}/actions`, { type })

export const reacallRequest = (requestId: string, type: string, payload: Object) =>
    authAxios.post(`/api/profile/org/requests/${requestId}/actions`, { type, payload })
