// @flow
/* eslint import/prefer-default-export:0 */
import authAxios from "../util/authAxios"

export const getProfileSeed = () => authAxios.get("/api/profile/user/seed")

export const putProfileSeed = (values: Object) => authAxios.put("/api/profile/user/seed", values)

export const deleteProfileSeed = () => authAxios.delete("/api/profile/user/seed")
