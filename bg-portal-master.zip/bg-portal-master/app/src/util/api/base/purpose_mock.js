// @flow
import { authMock } from "../util/mock"

authMock.onGet("/api/getPurpose").reply(200, {
    name: "some-identifier",
    description: "string",
    version: "string",
    active: true,
    fields: [
        {
            name: "propertyAddress",
            type: "OBJECT",
            constraints: [],
            appearance: {
                label: "Address",
                width: 12,
                renderAs: "ADDRESS"
            },
            subFields: [
                {
                    name: "addressStreet",
                    type: "STRING",
                    constraints: [
                        {
                            constraintType: "PATTERN",
                            appliesTo: "STRING",
                            pattern: "<some-reg-exp>"
                        }
                    ],
                    appearance: {
                        label: "Street",
                        width: 1 // ignored as renderAs provided in parent
                    }
                },
                {
                    name: "addressPostcode",
                    type: "STRING",
                    constraints: [
                        {
                            constraintType: "PATTERN",
                            appliesTo: "STRING",
                            pattern: "<some-reg-exp>"
                        }
                    ],
                    appearance: {
                        label: "Postcode",
                        width: 1 // ignored
                    }
                },
                {
                    name: "addressState",
                    type: "STRING",
                    constraints: [
                        {
                            constraintType: "ONE_OF",
                            appliesTo: "STRING",
                            availableValues: ["Victoria", "New South Wales", "Queensland"]
                        }
                    ],
                    appearance: {
                        label: "Address",
                        width: 12,
                        renderAs: "ADDRESS"
                    }
                }
            ]
        },
        {
            name: "propertyName",
            type: "STRING",
            constraints: [],
            appearance: {
                label: "Property Name",
                width: 6
            }
        }
    ]
})
authMock.onGet("/api/getAllPurpose").reply(200, [
    {
        fields: [
            {
                name: "basicTextField",
                contraints: [],
                optional: false,
                type: "STRING",
                appearance: { width: "4", label: "What is this field for" },
                subFields: []
            },
            {
                name: "I am a basic Select",
                contraints: [],
                optional: false,
                type: "LIST",
                appearance: { width: "4", label: "plz be a select" },
                subFields: [],
                options: ["TEST", "WHOAMID"]
            }
        ],
        active: true,
        version: "1.2.1",
        name: "TestTemplate"
    },
    {
        fields: [
            {
                name: "Another TExtField",
                contraints: [],
                optional: false,
                type: "STRING",
                appearance: { width: "4", label: "What is this field for" },
                subFields: []
            },
            {
                name: "AnotherWeirdAssSelect",
                contraints: [],
                optional: false,
                type: "LIST",
                appearance: { width: "4", label: "plz be a select" },
                subFields: [],
                options: ["TEST", "WHOAMID"]
            }
        ],
        active: true,
        version: "1.2.1",
        name: "Another Test Template",
        label: "Template Display Name"
    },
    {
        name: "some-identifier",
        description: "string",
        version: "string",
        active: true,
        fields: [
            {
                name: "propertyAddress",
                type: "OBJECT",
                constraints: [],
                appearance: {
                    label: "Address",
                    width: 12,
                    renderAs: "ADDRESS"
                },
                subFields: [
                    {
                        name: "addressStreet",
                        type: "STRING",
                        constraints: [
                            {
                                constraintType: "PATTERN",
                                appliesTo: "STRING",
                                pattern: "<some-reg-exp>"
                            }
                        ],
                        appearance: {
                            label: "Street",
                            width: 1 // ignored as renderAs provided in parent
                        }
                    },
                    {
                        name: "addressPostcode",
                        type: "STRING",
                        constraints: [
                            {
                                constraintType: "PATTERN",
                                appliesTo: "STRING",
                                pattern: "<some-reg-exp>"
                            }
                        ],
                        appearance: {
                            label: "Postcode",
                            width: 1 // ignored
                        }
                    },
                    {
                        name: "addressState",
                        type: "STRING",
                        constraints: [
                            {
                                constraintType: "ONE_OF",
                                appliesTo: "STRING",
                                availableValues: ["Victoria", "New South Wales", "Queensland"]
                            }
                        ],
                        appearance: {
                            label: "Address",
                            width: 12,
                            renderAs: "ADDRESS"
                        }
                    }
                ]
            },
            {
                name: "propertyName",
                type: "STRING",
                constraints: [],
                appearance: {
                    label: "Property Name",
                    width: 6
                }
            }
        ]
    }
])
