// @flow
/* eslint import/prefer-default-export:0 */
import authAxios from "../util/authAxios"

// if (DEV) {
//     require("./manageOrgSettings_mock") // eslint-disable-line global-require
// }

export const retrieveDetails = () => authAxios.get("/api/profile/org")

export const retrieveSettings = () => authAxios.get("/api/profile/org/settings")

export const retrieveListOfApprovalModels = () => authAxios.get("/api/profile/org/settings/approvalModels")

export const getDetailsOfApprovalModel = (name: string) =>
    authAxios.get(`/api/profile/org/settings/approvalModels/${name}`)

export const retrieveAprovalModel = (orgId?: string) => {
    let headers = null
    if (orgId) {
        headers = { "X-DLT-Target-Org": orgId }
    }
    return authAxios.get("/api/profile/org/settings/approvalModel", { headers })
}

export const updateApprovalModel = (name: Object) => authAxios.put("/api/profile/org/settings/approvalModel", name)
// body: {name: "SOLE_APPROVER"}

export const retrieveOrgRelationships = () => authAxios.get("/api/profile/org/settings/relationships")

export const retrieveOrgRoles = () => authAxios.get("/api/profile/org/settings/roles")

export const retrieveBusinessAccounts = () => authAxios.get("/api/profile/org/settings/accounts")

export const retrieveBusinessAccount = (value: string) => authAxios.get(`/api/profile/org/settings/account/${value}`)

export const modifyBusinessAccount = (accountId: string, values: Object) =>
    authAxios.put(`/api/profile/org/settings/accounts/${accountId}`, values)
// body: {type: "SWIFT", description: "Main company account", accountNumber: "12345678" }

export const deleteBusinessAccount = (accountId: string) =>
    authAxios.delete(`/api/profile/org/settings/accounts/${accountId}`)

export const performTask = (body: Object) => authAxios.post(`/api/profile/org/users/tasks`, body)
// body: {type: "UPDATE_ROLES", async: false}

export const addUserRole = (uId: string, values: Object) =>
    authAxios.post(`/api/profile/org/users/${uId}/roles`, values)
// body: {roles: ["USER", ...]}

export const removeUserRole = (uId: string, role: string) =>
    authAxios.delete(`/api/profile/org/users/${uId}/roles/${role}`)
// body: {roles: ["USER", ...]}

export const retrieveListOfSubsidiaryApprovalModels = (orgId: string) =>
    authAxios.get(`/api/profile/orgs/${orgId}/settings/approvalModels`)
