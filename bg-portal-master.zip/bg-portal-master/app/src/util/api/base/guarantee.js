// @flow
import qs from "query-string"
import authAxios from "../util/authAxios"

if (DEV) {
    require("./guarantee_mock") // eslint-disable-line global-require
}

export type GxSearchRequest = {
    status?: string,
    limit?: number,
    orgId?: string,
    applicantId?: string,
    beneficiaryId?: string,
    issuerId?: string,
    issuedAfter?: string,
    issuedBefore?: string,
    expiredAfter?: string,
    expiredBefore?: string,
    orderBy?: string,
    order?: string,
    amountSmallerThan?: number,
    amountGreaterThan?: number,
    streetAddress?: string,
    addressLocality?: string,
    addressRegion?: string,
    addressCountry?: string,
    postalCode?: string,
    issuer?: string,
    requestType?: string,
    purpose?: Object,
    purposeType?: string
}

export type requestSearch = {
    status?: string,
    limit?: number,
    start?: string,
    guaranteeId?: string
}

// name deviations from API spec: retrieveX => getX or searchX

export const searchGuarantees = (searchRequest: GxSearchRequest) =>
    authAxios.post(`/api/guarantees/search`, searchRequest)

export const getGuarantee = (gxId: string) => authAxios.get(`/api/guarantees/${gxId}`)

export const submitRequest = (type: string, payload: Object, prefillId?: string) => {
    const request: Object = { type, payload }
    if (prefillId) {
        request.id = prefillId
    }
    return authAxios.post(`/api/guarantees/requests`, request)
}

export const searchRequests = (searchRequest: GxSearchRequest) =>
    authAxios.post(`/api/guarantees/search`, searchRequest)

export const getRequest = (requestId: string) => authAxios.get(`/api/guarantees/requests/${requestId}`)

export const getRequests = (searchRequest: any) =>
    authAxios.get(`/api/guarantees/requests?${qs.stringify((searchRequest: any))}`)

export const submitAction = (opts: Object) => {
    // actionId needs to be retrieved from the preceeding ledger or internal action. not needed for: DEFER
    const action = { ...opts }
    if (!action.scope) {
        action.scope = "INTERNAL"
    }
    return authAxios.post(`/api/guarantees/requests/${opts.requestId}/actions`, action)
}

export const getRequestActions = (requestId: string) => authAxios.get(`/api/guarantees/requests/${requestId}/actions`)

export const getRequestAction = (requestId: string, actionId: string) =>
    authAxios.get(`/api/guarantees/requests/${requestId}/actions/${actionId}`)

export const submitRequestForGuarantee = (gxId: string, type: string, payload: Object, prefillId?: string) => {
    const request: Object = { type, payload }
    if (prefillId) {
        request.id = prefillId
    }
    return authAxios.post(`/api/guarantees/${gxId}/requests`, request)
}

export const getRequestsForGuarantee = (gxId: string) => authAxios.get(`/api/guarantees/${gxId}/requests`)

export const getRequestForGuarantee = (gxId: string, requestId: string) =>
    authAxios.get(`/api/guarantees/${gxId}/requests/${requestId}`)

export const submitRequestActionForGuarantee = (
    gxId: string,
    requestId: string,
    type: string,
    scope: string,
    actionId: string
) => {
    // actionId needs to be retrieved from the preceeding ledger or internal action. not needed for: DEFER
    const action = { type, scope, requestId, payload: type === "PROPOSE" ? "APPROVE" : null }
    return authAxios.post(`/guarantees/${gxId}/requests/${requestId}/actions`, action)
}

export const getRequestActionsForGuarantee = (gxId: string, requestId: string) =>
    authAxios.get(`/api/guarantees/${gxId}/requests/${requestId}/actions`)

export const getRequestActionForGuarantee = (gxId: string, requestId: string, actionId: string) =>
    authAxios.get(`/api/guarantees/${gxId}/requests/${requestId}/actions/${actionId}`)

export const downloadGuarantees = (searchRequest: Object) => authAxios.post(`/api/guarantees/download`, searchRequest)
