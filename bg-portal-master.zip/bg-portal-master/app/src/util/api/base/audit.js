// @flow
/* eslint import/prefer-default-export:0 */
import authAxios from "../util/authAxios"

export const myOrgAudit = (queryString: string) => authAxios.get(`/api/profile/org/audit${queryString}`)

export const myUserAudit = () => authAxios.get(`/api/profile/user/audit`)

export const getOrgAudit = (orgId: string, queryString?: string) =>
    authAxios.get(`/api/profile/orgs/${orgId}/audit${queryString || ""}
`)

export const getUserAudit = (userId: string, orgId: string, queryString: string) =>
    authAxios.get(`/api/profile/orgs/${orgId}/users/${userId}/audit${queryString}`)

export const downloadUserAudit = (userId: string, orgId: string, queryString: string) => () =>
    authAxios.get(`/api/profile/orgs/${orgId}/users/${userId}/audit/download${queryString}`)

export const downloadUserPermissions = (orgId: string, queryString: string) =>
    authAxios.get(`/api/profile/orgs/${orgId}/users/permissions/download${queryString}`)

export const downloadOrgAudit = (orgId: string, queryString?: string) => () =>
    authAxios.get(`/api/profile/orgs/${orgId}/audit/download${queryString || ""}`)

export const getGuaranteeAudit = (gxId: string) => authAxios.get(`/api/guarantees/${gxId}/audit`)
export const downloadGuaranteeAudit = (gxId: string, queryString: string) => () =>
    authAxios.get(`/api/guarantees/${gxId}/audit/download${queryString}`)
export const downloadPdfGuarantee = (gxId: string) => () =>
    authAxios.get(`/api/guarantees/${gxId}`, {
        headers: { Accept: "application/pdf" },
        responseType: "arraybuffer"
    })
