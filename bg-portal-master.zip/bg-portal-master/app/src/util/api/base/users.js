/* eslint import/prefer-default-export:0 */
import * as MOCK_DATA from "~/util/mock-data"

export const getUsers = () => Promise.resolve([MOCK_DATA.data.USER_1, MOCK_DATA.data.USER_2])
