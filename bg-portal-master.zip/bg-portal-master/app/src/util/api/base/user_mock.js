import { authMock } from "../util/mock"

authMock.onGet("/api/profile/user").reply(200, {
    firstName: "isabell",
    lastName: "kiko",
    phone: "0422335797",
    email: "isabeki@au1.ibm.com",
    roles: ["ADMIN", "PRIMARY", "CATLADY"],
    id: "12345",
    orgID: "12344",
    key: "12344",
    token: "12344",
    status: "CONFIRMED",
    agreement: {
        tcId: "1234"
    }
})
