// @flow
import authAxios from "../util/authAxios"

if (DEV) {
    require("./purpose_mock") // eslint-disable-line global-require
}

export const getPurposeTempalate = (id: string) => authAxios.get(`/api/purpose-formats/${id}`)

export const getAllActivePurposeTemplates = () => authAxios.get(`/api/purpose-formats?active=true`)
export const getAllPurposeTemplates = () => authAxios.get(`/api/purpose-formats`)
