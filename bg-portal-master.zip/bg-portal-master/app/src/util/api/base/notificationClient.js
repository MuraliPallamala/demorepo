import { authStorage } from "~/util/auth"

const connect = (handlerFunction, handlerObject) => {
    const path = window.location.pathname
    const tokenSet = authStorage.getTokenSet()

    let baseUrl = window.location.href.replace("https://", "wss://")
    if (path !== "/") {
        baseUrl = baseUrl.replace(path, "")
    }

    const socket = new WebSocket(`${baseUrl}/service/ws/notify`)
    socket.onopen = () => {
        // send JWT token through established websocket connection
        socket.send(tokenSet.access_token)
        console.log("[WS] Connected to websocket")
    }

    socket.onmessage = message => {
        // parse the notification
        const msg = JSON.parse(message.data)
        // invoke the handler function
        if (handlerObject == null) {
            handlerFunction(msg)
        } else {
            handlerObject[handlerFunction](msg)
        }
    }

    socket.onclose = () => {
        console.log("[WS] Socket connection closed")
        // TODO: attempt to reconnect
    }

    socket.onerror = error => {
        console.error("[WS] Error during websocket communication", error)
    }
}

class NotificationSocketClient {
    constructor(handlerFunction, handlerObject) {
        this.handlerObject = handlerObject
        this.handlerFunction = handlerFunction
    }

    connect() {
        connect(
            this.handlerFunction,
            this.handlerObject
        )
    }
}

export default NotificationSocketClient
