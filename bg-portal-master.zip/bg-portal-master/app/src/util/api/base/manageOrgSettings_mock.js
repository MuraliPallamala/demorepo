import { authMock } from "../util/mock"

authMock.onGet("/api/profile/org/settings/approvalModel").reply(200, {
    name: "SOLE_APPROVER",
    updatedBy: "2da6a34a-7498-4689-9db4-030a92049df3",
    updatedAt: "2018-06-22T05:16:55.884Z"
})

authMock.onPut("/api/profile/org/settings/approvalModel").reply(200)
