import * as MOCK_DATA from "~/util/mock-data"
import { authMock } from "../util/mock"

authMock.onGet("/api/profile/onboarding-requests").reply(200, {
    result: [MOCK_DATA.onboarding.submittedOnboardingRequest]
})

// authMock
//     .onGet(new RegExp("/api/profile/onboarding-requests/.+"))
//     .reply(200, MOCK_DATA.onboarding.submittedOnboardingRequest)
