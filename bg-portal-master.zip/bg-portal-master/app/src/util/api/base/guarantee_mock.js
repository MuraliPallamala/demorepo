// @flow
/* eslint import/prefer-default-export:0 */
import { authMock } from "../util/mock"

// updated api - november 19
authMock.onGet("/api/guarantees/1").reply(200, {
    type: "COMMERCIAL_LEASE",
    issuer: { id: "2da6a34a-7498-4689-9db4-030a92049df3", entityName: "ANZ", businessId: "pee" },
    applicants: [{ id: "6767d616-cd07-4e28-aef8-b555ad89376a", entityName: "doggy org", businessId: "poop" }],
    beneficiaries: [{ id: "2da645a-7498-4689-9db4-030a92049df3", entityName: "catty org", businessId: "vomit" }],
    purpose: {
        propertyName: "Westfield Shopping Centre",
        shopNumber: "34A",
        address: {
            streetAddress: "123 Fake Street",
            addressLocation: "Melbourne",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: 3324
        },
        comment: "Uncle Joe"
    },
    amount: {
        outstanding: 3450000,
        demanded: 100000,
        currency: "AUD"
    },
    expiresAt: "2020-06-22T05:16:55.884Z",
    tcId: "4568de2a-7498-4689-9db4-030a92049df3",
    id: "2da6a34a-7498-4689-9db4-030a92049df3",
    status: "ACTIVE",
    issuedAt: "2018-06-22T05:16:55.884Z",
    updatedAt: "2018-07-22T05:16:55.884Z"
})

authMock.onGet("/api/guarantees/requests/").reply(200, [
    {
        result: [
            {
                type: "ISSUE",
                id: "11",
                status: "ACTIVE",
                createdAt: "2018-06-22T05:16:55.884Z",
                createdBy: "73072f4b-d032-4340-8e2e-aeec6d703778"
            },
            {
                type: "AMEND",
                id: "12",
                status: "ACTIVE",
                createdBy: "73072f4b-d032-4340-8e2e-aeec6d703778",
                createdAt: "2018-06-22T05:16:55.884Z"
            }
        ]
    }
])

authMock.onGet("/api/guarantees/requests/11").reply(200, {
    type: "ISSUE",
    id: "11",
    status: "ACTIVE",
    createdAt: "2018-06-22T05:16:55.884Z",
    createdBy: "73072f4b-d032-4340-8e2e-aeec6d703778",
    payload: {
        type: "COMMERCIAL_LEASE",
        issuer: { id: "1", entityName: "ANZ", businessId: "pee" },
        applicants: [{ id: "2", entityName: "doggy org", businessId: "poop" }],
        beneficiaries: [{ id: "3", entityName: "catty org", businessId: "vomit" }],
        purpose: {
            propertyName: "Westfield Shopping Centre",
            shopNumber: "34A",
            address: {
                streetAddress: "123 Fake Street",
                addressLocation: "Melbourne",
                addressRegion: "Victoria",
                addressCountry: "Australia",
                postalCode: 3324
            },
            comment: "Uncle Joe"
        },
        amount: {
            outstanding: 3450000,
            demanded: 100000,
            currency: "AUD"
        },
        expiresAt: "2020-06-22T05:16:55.884Z",
        tcId: "4568de2a-7498-4689-9db4-030a92049df3",
        id: "2da6a34a-7498-4689-9db4-030a92049df3",
        status: "ACTIVE",
        issuedAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-07-22T05:16:55.884Z"
    }
})
authMock.onGet("/api/guarantees/1/requests/11").reply(200, {
    type: "ISSUE",
    id: "11",
    status: "ACTIVE",
    createdAt: "2018-06-22T05:16:55.884Z",
    createdBy: "73072f4b-d032-4340-8e2e-aeec6d703778",
    payload: {
        type: "COMMERCIAL_LEASE",
        issuer: { id: "1", entityName: "ANZ", businessId: "pee" },
        applicants: [{ id: "2", entityName: "doggy org", businessId: "poop" }],
        beneficiaries: [{ id: "3", entityName: "catty org", businessId: "vomit" }],
        purpose: {
            propertyName: "Westfield Shopping Centre",
            shopNumber: "34A",
            address: {
                streetAddress: "123 Fake Street",
                addressLocation: "Melbourne",
                addressRegion: "Victoria",
                addressCountry: "Australia",
                postalCode: 3324
            },
            comment: "Uncle Joe"
        },
        amount: {
            outstanding: 3450000,
            demanded: 100000,
            currency: "AUD"
        },
        expiresAt: "2020-06-22T05:16:55.884Z",
        tcId: "4568de2a-7498-4689-9db4-030a92049df3",
        id: "2da6a34a-7498-4689-9db4-030a92049df3",
        status: "ACTIVE",
        issuedAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-07-22T05:16:55.884Z"
    }
})

authMock.onGet("/api/guarantees/requests/12").reply(200, [
    {
        type: "AMEND",
        id: "12",
        status: "ACTIVE",
        createdAt: "2018-06-22T05:16:55.884Z"
    }
])

authMock.onGet("/api/guarantees/requests/11/actions").reply(200, {
    result: [
        {
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "PROPOSE",
            scope: "INTERNAL",
            createdAt: "2018-11-21T03:58:09.122Z",
            createdBy: "5f508bd4-3e0a-4f47-8156-afedc301366c"
        },
        {
            id: "0",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "SUBMIT",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:09.233Z",
            createdBy: "5f508bd4-3e0a-4f47-8156-afedc301366c"
        },
        {
            id: "1",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "APPROVE",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:12.324Z",
            createdBy: "1189c80b-fb73-44a5-878f-758ac4798dc4"
        }
    ]
})
authMock.onGet("/api/guarantees/1/requests/11/actions").reply(200, {
    result: [
        {
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "PROPOSE",
            scope: "INTERNAL",
            createdAt: "2018-11-21T03:58:09.122Z",
            createdBy: "5f508bd4-3e0a-4f47-8156-afedc301366c"
        },
        {
            id: "0",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "SUBMIT",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:09.233Z",
            createdBy: "5f508bd4-3e0a-4f47-8156-afedc301366c"
        },
        {
            id: "1",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "APPROVE",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:12.324Z",
            createdBy: "1189c80b-fb73-44a5-878f-758ac4798dc4"
        }
    ]
})

authMock.onGet("/api/guarantees/1/requests/12/actions").reply(200, {
    result: [
        {
            id: "0",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "SUBMIT",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:09.233Z",
            createdBy: "5f508bd4-3e0a-4f47-8156-afedc301366c"
        },
        {
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "APPROVE",
            scope: "INTERNAL",
            createdAt: "2018-11-21T03:58:12.180Z",
            createdBy: "1189c80b-fb73-44a5-878f-758ac4798dc4"
        },
        {
            id: "1",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "APPROVE",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:12.324Z",
            createdBy: "1189c80b-fb73-44a5-878f-758ac4798dc4"
        },
        {
            id: "2",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "APPROVE",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:18.312Z",
            createdBy: "anz"
        }
    ]
})

authMock.onGet("/api/guarantees/requests/13/actions").reply(200, {
    result: [
        {
            id: "0",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "SUBMIT",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:09.233Z",
            createdBy: "5f508bd4-3e0a-4f47-8156-afedc301366c"
        },
        {
            id: "1",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "APPROVE",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:12.324Z",
            createdBy: "1189c80b-fb73-44a5-878f-758ac4798dc4"
        },
        {
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "APPROVE",
            scope: "INTERNAL",
            createdAt: "2018-11-21T03:58:18.163Z",
            createdBy: "anz"
        },
        {
            id: "2",
            gxRequestId: "f06e74e0-8582-4419-a337-1b9f8c6a33a5",
            type: "APPROVE",
            scope: "LEDGER",
            createdAt: "2018-11-21T03:58:18.312Z",
            createdBy: "anz"
        }
    ]
})
authMock.onGet("/api/guarantees/1/requests").reply(200, {
    result: [
        {
            type: "CANCEL",
            id: "11",
            status: "ACTIVE",
            createdBy: "6767d616-cd07-4e28-aef8-b555ad89376a",
            createdAt: "2018-06-22T05:16:55.884Z"
        },
        {
            type: "AMEND",
            id: "12",
            status: "ACTIVE",
            createdAt: "2018-06-22T05:16:55.884Z",
            createdBy: "2da645a-7498-4689-9db4-030a92049df3"
        }
    ]
})

authMock.onGet("/api/guarantees/1/requests/12").reply(200, [
    {
        type: "ISSUE",
        id: "12",
        status: "ACTIVE",
        createdAt: "2018-06-22T05:16:55.884Z"
    }
])

//
//
//
// authMock
//     .onGet("/api/e701544e97217de8f7314e839c046739/workflow")
//     .reply(200, [
//         { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionType: "START" },
//         { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionType: "REVOKE" },
//         { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionType: "START" },
//         { createdBy: "2da6a34a-7498-4689-9db4-030a92049df3", actionType: "APPROVE" },
//         { createdBy: "2da6a34a-7498-4689-9db4-030a92049df3", actionType: "REVOKE" }
//     ])
//
// authMock.onGet("/api/e701544e97217de8f7314e839c05b800/workflow").reply(200, [
//     {
//         createdBy: "2da23564-f606-4e41-b441-38bc885c6498",
//         actionType: "START"
//     }
// ])
//
// authMock.onGet("/api/e701544e97217de8f7314e839c05b800/actions").reply(200, [{ createdBy: "", actionTyp: "" }])
//
// authMock
//     .onGet("/api/e701544e97217de8f7314e839c046739/actions")
//     .reply(200, [{ createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionType: "APPROVE" }])
//
// authMock
//     .onGet(
//         "/api/westpac-channel_15378672571920000008a229e9b137bca10f8624604098fa872d328062af66e1ebf200011cbcee60c7f/actions"
//     )
//     .reply(200, [{ createdBy: "", actionTyp: "" }])
//
// authMock
//     .onGet(
//         "/api/westpac-channel_15378672571920000008a229e9b137bca10f8624604098fa872d328062af66e1ebf200011cbcee60c7f/workflow"
//     )
//     .reply(200, [])
//
// authMock.onGet("/api/e701544e97217de8f7314e839c045937/workflow").reply(200, [
//     { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionType: "START" },
//     { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionType: "REVOKE" }
//     // ,
//     // { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actions: "START" }
//     // ,
//     // { createdBy: "2da6a34a-7498-4689-9db4-030a92049df3", actions: "APPROVE" },
//     // { createdBy: "2da6a34a-7498-4689-9db4-030a92049df3", actions: "REVOKE" }
//     // ,
//     // { createdBy: "2da6a34a-7498-4689-9db4-030a92049df3", actions: "APPROVE" }
// ])
//
// authMock.onGet("/api/e701544e97217de8f7314e839c045937/actions").reply(200, [
//     // {}
//     { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionType: "APPROVE" },
//     { createdBy: "123", actionType: "APPROVE" },
//     { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionType: "RECALL" },
//     { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionType: "APPROVE" },
//     { createdBy: "123", actionType: "APPROVE" },
//     { createdBy: "123", actionType: "REVOKE" }
// ])
//
// authMock
//     .onGet(
//         "/api/anz-channel_1537917432793000000ef1f984599d89d13ca38132f3acfe6482b6f86b834879d886c3425f2cdff7aac/actions"
//     )
//     .reply(200, [
//         { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionTyp: "APPROVED" },
//         { createdBy: "0d819d34-dab0-4e8f-9e16-1353edb7633d", actionTyp: "APPROVED" }
//     ])
//
// authMock
//     .onGet(
//         "/api/anz-channel_1537917432793000000ef1f984599d89d13ca38132f3acfe6482b6f86b834879d886c3425f2cdff7aac/workflow"
//     )
//     .reply(200, [])
