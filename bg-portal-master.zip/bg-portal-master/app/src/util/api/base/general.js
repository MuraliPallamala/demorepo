// @flow
/* eslint import/prefer-default-export:0 */
import axios from "axios"
import authAxios from "../util/authAxios"

export const logout = (refreshToken: string) => {
    const headers = {
        "X-DLT-OIDC-Refresh-Token": refreshToken
    }
    return authAxios.delete("/api/auth/oidc/token", { headers })
}

export const multipleApis = (apiArray: Array<any>) => axios.all(apiArray)
