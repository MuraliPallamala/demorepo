import axios from "axios"
import authAxios from "../util/authAxios"
//
// if (DEV) {
//     require("./onboarding_mock") // eslint-disable-line global-require
// }

export const getOnboardingRequests = status => authAxios.get(`/api/profile/onboarding-requests${status}`)
export const getOnboardingToken = id => authAxios.get(`/api/profile/onboarding-requests/${id}/token`)

export const getOnboardingRequestsByStatus = status =>
    authAxios.get(`/api/profile/onboarding-requests?status=${status}`)

export const getOnboardingRequest = id => authAxios.get(`/api/profile/onboarding-requests/${id}`)

export const submitOnboardingRequest = values => {
    if (values.entityType == null) {
        values.entityType = "APPLICANT_OR_BENEFICIARY"
    }
    return authAxios.post("/api/profile/onboarding-requests", values)
}

export const getPrefilledOnboardingRequest = (requestKey, token) =>
    axios.get("/api/profile/new", {
        headers: {
            "X-DLT-Request-Key": requestKey,
            "X-DLT-Auth-Token": token
        }
    })

export const rejectReferralTC = (requestKey, token) =>
    axios.delete("/api/profile/new", {
        headers: {
            "X-DLT-Request-Key": requestKey,
            "X-DLT-Auth-Token": token
        }
    })

export const cancelApplication = (requestKey, token) =>
    axios.delete("/api/profile/new/user", {
        headers: {
            "X-DLT-Request-Key": requestKey,
            "X-DLT-Auth-Token": token
        }
    })

export const submitSelfOnboardingRequest = request => {
    const payload = {
        profile: request,
        agreement: request.agreement
    }
    delete payload.profile.agreement
    return axios.post("/api/profile/new", payload)
}

export const updateOnboardingRequest = (request, requestKey, token) =>
    axios.put("/api/profile/new", request, {
        headers: {
            "X-DLT-Request-Key": requestKey,
            "X-DLT-Auth-Token": token
        }
    })

export const updateOnboardingUserDetails = (request, requestKey, token) =>
    axios.put("/api/profile/new/user/details", request, {
        headers: {
            "X-DLT-Request-Key": requestKey,
            "X-DLT-Auth-Token": token
        }
    })

export const getTCByType = type =>
    axios.get(`/api/platform/terms-and-conditions`, {
        params: {
            type
        }
    })

// export const rejectReferralTC = () => axios.post("/api/platform/terms-and-conditions/REJECT_PLACEHOLDER")

// Available after admin has approved onboarding
export const getProfileAndUser = (requestKey, token) =>
    axios.get("/api/profile/new/user", {
        headers: {
            "X-DLT-Request-Key": requestKey,
            "X-DLT-Auth-Token": token
        }
    })

// Available after admin has approved onboarding
export const setUserPassword = (requestKey, token, password) =>
    axios.put(
        "/api/profile/new/user/password",
        { password },
        {
            headers: {
                "X-DLT-Request-Key": requestKey,
                "X-DLT-Auth-Token": token
            }
        }
    )

export const setUserTC = (requestKey, token, tcId) =>
    axios.put(
        "/api/profile/new/user/agreement",
        {
            tcId
        },
        {
            headers: {
                "X-DLT-Request-Key": requestKey,
                "X-DLT-Auth-Token": token
            }
        }
    )
