// @flow
/* eslint import/prefer-default-export:0 */

import authAxios from "../util/authAxios"

// if (DEV) {
//     require("./user_mock") // eslint-disable-line global-require
// }

//
export const getUser = () => authAxios.get("/api/profile/user")

export const updateUserDetails = (values: Object) => authAxios.put("/api/profile/user/details", values)

export const updatePassword = (password: Object) => authAxios.put("/api/profile/user/password", password)
