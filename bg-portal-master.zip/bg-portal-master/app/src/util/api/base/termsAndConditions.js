// @flow
/* eslint import/prefer-default-export:0 */

import axios from "axios"
import authAxios from "../util/authAxios"

// export const getGuaranteeTCs = () => authAxios.get("/api/platform/terms-and-conditions?type=BANK_GUARANTEE")

export const getAllTCs = () => authAxios.get("/api/platform/terms-and-conditions")

export const getTCsIdsByType = (type: string) => axios.get(`/api/platform/terms-and-conditions?type=${type}`)

export const getActiveTCsIdsByType = (type: string) =>
    axios.get(`/api/platform/terms-and-conditions/active?type=${type}`)

export const getTCsByType = async (type: string) => {
    const baseData = await axios.get(`/api/platform/terms-and-conditions?type=${type}`)
    return baseData.data.result
}
// type can be USER, PLATFORM, BANK_GUARANTEE

// This function returns the terms and conditions record and it is used to access the metadata associated
// with the terms and conditions, such as title, type, scope etc. If the terms and conditions is of type
// external, the blob associated with the terms and conditions will not be retrieved.
// Used in BGDetailsContainer
export const getTCById = (tcId: string) => authAxios.get(`/api/platform/terms-and-conditions/${tcId}`)

// This function retrieves the blob associated with a terms and conditions record identified by ID.
// It is expected that the blob is a pdf in base 64
export const getTCDocumentById = async (tcId: string, tcTitle: string) => {
    const data = await axios.get(`/api/platform/terms-and-conditions/${tcId}/document`)
    const binary = atob(data.data.payload.replace(/\s/g, ""))
    const len = binary.length
    const buffer = new ArrayBuffer(len)
    const view = new Uint8Array(buffer)
    for (let i = 0; i < len; i++) {
        view[i] = binary.charCodeAt(i)
    }

    // create the blob object with content-type "application/pdf"
    const blob = new Blob([view], { type: "application/pdf" })
    const url = URL.createObjectURL(blob)
    const returnData = { content: blob, url, type: "pdf", id: tcId, title: tcTitle }
    return returnData
}

// This is used to get one set of terms and conditions for display in a container (e.g. onboarding, settings)
// The function retrieves the TC record, checks the type and if external, also pulls the pdf blob
// This is used in TermsConditionsContainer and BGDetailsCardContent
export const getTCsById = (tcId: string) => async () => {
    let returnData
    const baseData = await authAxios.get(`/api/platform/terms-and-conditions/${tcId}`)
    if (baseData.data.content.type === "EXTERNAL") {
        const data = await authAxios.get(`/api/platform/terms-and-conditions/${tcId}/document`)
        // const res = data.data.payload
        const binary = atob(data.data.payload.replace(/\s/g, ""))
        const len = binary.length
        const buffer = new ArrayBuffer(len)
        const view = new Uint8Array(buffer)
        for (let i = 0; i < len; i++) {
            view[i] = binary.charCodeAt(i)
        }
        // create the blob object with content-type "application/pdf"
        const blob = new Blob([view], { type: "application/pdf" })
        const url = URL.createObjectURL(blob)
        returnData = { content: blob, url, type: "pdf" }
    } else if (baseData.data.content.type === "EMBEDDED") {
        returnData = { content: baseData.data.content.data.text, type: "markdown" }
    }
    return returnData
}
