// @flow
/* eslint import/prefer-default-export:0 */
import authAxios from "../util/authAxios"

export const getApiKeys = () => authAxios.get("/api/profile/user/keys")

export const addApiKey = (values: Object) => authAxios.post("/api/profile/user/keys", values)

export const deleteApiKey = (keyId: string) => authAxios.delete(`/api/profile/user/keys/${keyId}`)
