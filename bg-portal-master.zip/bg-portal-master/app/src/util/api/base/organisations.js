// @flow
import authAxios from "../util/authAxios"

export const getOrganisations = (value: string) => authAxios.get(`/api/profile/orgs/${value}`)
// value is the specific orgId

export const getOrgsWithQuery = (value: string) => authAxios.get(`/api/profile/orgs${value}`)

export const getOrgsMappings = () => authAxios.get(`/ui/mappings.json`)
