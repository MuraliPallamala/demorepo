// Error should show in the username field [eg. user empty/not found]
export default function UserError(message) {
    this.name = "UserError"
    this.message = message
    this.stack = new Error().stack
}
UserError.prototype = Object.create(Error.prototype)
UserError.prototype.constructor = UserError
