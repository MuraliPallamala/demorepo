// Error should show in the password field [eg. password empty]
// password incorrect should probably show as user error?...
export default function PasswordError(message) {
    this.name = "PasswordError"
    this.message = message
    this.stack = new Error().stack
}
PasswordError.prototype = Object.create(Error.prototype)
PasswordError.prototype.constructor = PasswordError
