import { ENTITIES } from "~/util/CONSTANTS"
import { GX_STATUS, GX_TYPE } from "~/util/logic/gx"

export const BANK_GUARANTEE_1 = {
    id: "12345678-87654321-asdfghjk-kjhgfdsa",
    status: GX_STATUS.ACTIVE,
    requestHistory: [
        {
            id: "12345iud",
            type: "issue",
            statusHistory: [
                {
                    status: "consentRequired",
                    timestamp: new Date(),
                    actor: "Landlord Holdings",
                    rationale: "Because it's required"
                }
            ]
        }
    ],
    bankReference: "ANZ12345",
    beneficiaryReference: "SCENTRE12367",
    type: GX_TYPE.rental,
    applicant: "Hello Corp",
    beneficiary: "Landlord Holdings",
    purpose: "For reasons",
    bank: ENTITIES.BANK.ANZ,
    currency: ENTITIES.CURRENCY.AUD,
    amount: 456,
    expiryDate: new Date(),
    additionalConditions: "Here are some conditions that are conditional"
}

export const BANK_GUARANTEE_2 = {
    id: "abc123",
    status: GX_STATUS.denied,
    requestHistory: [
        {
            id: "12345iud",
            type: "issue",
            statusHistory: [
                {
                    status: "consentRequired",
                    timestamp: new Date(),
                    actor: "Landlord Holdings",
                    rationale: "Because it's required"
                }
            ]
        }
    ],
    bankReference: "FOO",
    beneficiaryReference: "SCENTRE12367",
    type: GX_TYPE.rental,
    applicant: "Hello Corp",
    beneficiary: "Landlord Holdings",
    purpose: "For reasons",
    bank: ENTITIES.BANK.ANZ,
    currency: ENTITIES.CURRENCY.AUD,
    amount: 124124,
    expiryDate: new Date(),
    additionalConditions: "Here are some conditions that are conditional"
}

export const USER_1 = {
    id: "dain",
    name: "dain",
    role: "applicant",
    notifications: []
}

export const USER_2 = {
    id: "antony",
    name: "antony",
    role: "beneficiary",
    notifications: []
}

export const USER_3 = {
    firstName: "isabell",
    lastName: "kiko",
    phone: "0422335797",
    email: "isabeki@au1.ibm.com",
    roles: ["ADMIN", "PRIMARY", "CATLADY"],
    id: "12345",
    orgID: "12344",
    key: "12344",
    token: "12344",
    status: "CONFIRMED",
    agreement: {
        tcId: "1234"
    }
}

export const NeedsActionData = [
    {
        address: {
            streetAddress: "123 Fake Street",
            addressLocation: "Melbourne",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: 3324,
            postOfficeBoxNumber: 10
        },
        entityName: "Scentre Group",
        businessID: "example_ABN_or_ACN",
        businessContact: {
            firstName: "Felicity",
            lastName: "Storm",
            email: "felicity.storm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        businessAdmin: {
            firstName: "Felicity",
            lastName: "Storm",
            email: "felicity.storm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        id: "asfns1230912",
        status: "Drafted",
        createdAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-06-22T05:16:55.884Z"
    },
    {
        address: {
            streetAddress: "123 Fake Street",
            addressLocation: "Melbourne",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: 3324,
            postOfficeBoxNumber: 10
        },
        entityName: "IBM Research Group",
        businessID: "example_ABN_or_ACN",
        businessContact: {
            firstName: "Felicity",
            lastName: "Storm",
            email: "felicity.storm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        businessAdmin: {
            firstName: "CoolName",
            lastName: "Raindrops",
            email: "CoolName.Raindrops@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        id: "asfns1230912",
        status: "Drafted",
        createdAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-06-22T05:16:55.884Z"
    },
    {
        address: {
            streetAddress: "123 Fake Street",
            addressLocation: "Melbourne",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: 3324,
            postOfficeBoxNumber: 10
        },
        entityName: "Windfarmgroup Group",
        businessID: "example_ABN_or_ACN",
        businessContact: {
            firstName: "John",
            lastName: "WindFarm",
            email: "felicity.storm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        businessAdmin: {
            firstName: "Felicity",
            lastName: "Storm",
            email: "John.WindFarm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        id: "asfns1230912",
        status: "Drafted",
        createdAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-06-22T05:16:55.884Z"
    }
]

export const Organisations = [
    {
        address: {
            streetAddress: "123 Fake Street",
            addressLocation: "Melbourne",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: 3324,
            postOfficeBoxNumber: 10
        },
        entityName: "BlueGroup",
        businessID: "example_ABN_or_ACN",
        businessContact: {
            firstName: "Felicity",
            lastName: "Storm",
            email: "felicity.storm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        businessAdmin: {
            firstName: "Felicity",
            lastName: "Storm",
            email: "felicity.storm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        id: "asfns1230912",
        status: "Drafted",
        createdAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-06-22T05:16:55.884Z"
    },
    {
        address: {
            streetAddress: "123 Fake Street",
            addressLocation: "Melbourne",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: 3324,
            postOfficeBoxNumber: 10
        },
        entityName: "AntStudios",
        businessID: "example_ABN_or_ACN",
        businessContact: {
            firstName: "Felicity",
            lastName: "Storm",
            email: "felicity.storm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        businessAdmin: {
            firstName: "CoolName",
            lastName: "Raindrops",
            email: "CoolName.Raindrops@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        id: "asfns1230912",
        status: "Drafted",
        createdAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-06-22T05:16:55.884Z"
    },
    {
        address: {
            streetAddress: "123 Fake Street",
            addressLocation: "Melbourne",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: 3324,
            postOfficeBoxNumber: 10
        },
        entityName: "ThisIsAGroup",
        businessID: "example_ABN_or_ACN",
        businessContact: {
            firstName: "John",
            lastName: "WindFarm",
            email: "felicity.storm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        businessAdmin: {
            firstName: "Felicity",
            lastName: "Storm",
            email: "John.WindFarm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        id: "asfns1230912",
        status: "Drafted",
        createdAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-06-22T05:16:55.884Z"
    },
    {
        address: {
            streetAddress: "123 Fake Street",
            addressLocation: "Melbourne",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: 3324,
            postOfficeBoxNumber: 10
        },
        entityName: "Anotheeerrr1",
        businessID: "example_ABN_or_ACN",
        businessContact: {
            firstName: "John",
            lastName: "WindFarm",
            email: "felicity.storm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        businessAdmin: {
            firstName: "Felicity",
            lastName: "Storm",
            email: "John.WindFarm@me.com",
            telephone: "+61 03 57686682",
            mobile: "+61 449 567799",
            url: "http://me.com"
        },
        id: "asfns1230912",
        status: "Drafted",
        createdAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-06-22T05:16:55.884Z"
    }
]

export const NotificationData = [
    {
        payload: {},
        type: "ChangeDetails",
        id: "asfns1230912",
        status: "Submitted",
        createdAt: "2018-06-22T05:16:55.884Z"
    },
    {
        type: "Onboarding",
        id: "asfns14440912",
        payload: {},
        status: "Drafted",
        createdAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-06-22T05:16:55.884Z"
    },
    {
        type: "Onboarding",
        id: "aDFDs1230912",
        status: "Drafted",
        payload: {},
        createdAt: "2018-06-22T05:16:55.884Z",
        updatedAt: "2018-06-22T05:16:55.884Z"
    }
]
