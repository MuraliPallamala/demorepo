const primaryContactDetails = {
    firstName: "Carole",
    lastName: "Smith",
    email: "carole.smith@example.com",
    telephone: "+6139456789",
    mobile: "+61412345678"
}

const adminContactDetails = {
    firstName: "John",
    lastName: "Smith",
    email: "john.smith@example.com",
    telephone: "+6139456789",
    mobile: "+61412345678"
}

export const onboardingRequest = {
    id: "foo123",
    entityName: "Mock Company",
    entityAddress: {
        streetAddress: "60 City Road",
        addressLocality: "Southbank",
        addressRegion: "Victoria",
        addressCountry: "Australia",
        postalCode: "3006",
        postOfficeBoxNumber: ""
    },
    businessId: "ABN_123456789",
    contacts: [
        {
            ...primaryContactDetails,
            roles: ["PRIMARY"],
            credentials: {
                token: 1234
            }
        },
        {
            ...adminContactDetails,
            roles: ["ADMIN"],
            credentials: {
                token: 1234
            }
        }
    ]
}

export const primaryContactUserProfileRequest = {
    profile: onboardingRequest,
    user: primaryContactDetails
}

export const adminContactUserProfileRequest = {
    profile: onboardingRequest,
    user: adminContactDetails
}

export const submittedOnboardingRequest = {
    profile: {
        entityName: "Company 1123",
        entityAddress: {
            streetAddress: "3 Hello St",
            addressLocality: "Melbourne",
            addressRegion: "Victoria",
            addressCountry: "Australia",
            postalCode: "3000",
            postOfficeBoxNumber: ""
        },
        businessId: "48 504 029 210",
        contacts: [
            {
                firstName: "fasfd",
                lastName: "lname",
                email: "kimiko.wilson@au1.ibm.com",
                telephone: "1234567890",
                mobile: "",
                roles: ["PRIMARY", "ADMIN"],
                agreement: { tcId: "1bb49434-7471-43d7-94c3-ecac94100cfe" }
            }
        ],
        agreement: { tcId: "2097b57f-22c4-480d-8261-f14a2c609974" },
        attachments: []
    },
    credentials: {
        key: "ia456m58u6abuo4984r9rc7btq",
        token: "6788",
        expiresAt: "2018-07-20T01:11:56.782Z",
        createdAt: "2018-07-19T01:11:56.782Z"
    },
    id: "f1d1b22b-206b-4970-ad38-91fa1ba1a4ed",
    createdAt: "2018-07-19T01:09:52.648Z",
    updatedAt: "2018-07-19T01:27:03.260Z",
    attachments: [],
    requestType: "ON_BOARDING",
    approvals: [],
    actions: [
        {
            id: "36fe0b9a-4853-417e-9847-9a9c77e32d8c",
            actionType: "CONFIRM",
            payload: {
                profile: {
                    entityName: "Company 1123",
                    entityAddress: {
                        streetAddress: "3 Hello St",
                        addressLocality: "Melbourne",
                        addressRegion: "Victoria",
                        addressCountry: "Australia",
                        postalCode: "3000",
                        postOfficeBoxNumber: ""
                    },
                    businessId: "48 504 029 210",
                    contacts: [
                        {
                            firstName: "fasfd",
                            lastName: "lname",
                            email: "kimiko.wilson@au1.ibm.com",
                            telephone: "1234567890",
                            mobile: "",
                            roles: ["PRIMARY", "ADMIN"],
                            agreement: { tcId: "1bb49434-7471-43d7-94c3-ecac94100cfe" }
                        }
                    ],
                    agreement: { tcId: "2097b57f-22c4-480d-8261-f14a2c609974" },
                    attachments: []
                }
            },
            createdAt: "2018-07-19T01:11:56.725+0000"
        }
    ],
    status: "APPROVED"
}

export const onboardingRequestResponse = {
    id: "e2852585-3247-4327-9cfe-1d0b16321fea",
    token: "1275",
    status: "DRAFTED",
    createdAt: "2018-07-10T08:14:40.605Z"
}

export const TermsAndConditions = {
    id: "12345",
    title: "abc 123",
    text: `# Spicy jalapeno
bacon
## ipsum dolor
amet biltong venison cow, turducken tri-tip pork belly leberkas chuck shoulder flank meatloaf. Buffalo bresaola turducken cupim tail chicken pastrami, chuck beef doner filet mignon ground round shankle frankfurter ribeye. Sirloin meatball turducken spare ribs tri-tip. Meatball spare ribs frankfurter turducken. Meatball prosciutto short ribs sausage corned beef beef ribs. Turkey tenderloin porchetta ham hock kielbasa shankle. Tail pastrami cupim buffalo, kielbasa short loin jowl shank burgdoggen ribeye pancetta cow ham.

* Filet mignon ham hock pig boudin meatloaf beef ribs leberkas, capicola bacon kielbasa. Pancetta tri-tip frankfurter ham filet mignon prosciutto ball tip turducken. Ground round beef turkey leberkas. Ribeye drumstick picanha beef ribs. Drumstick corned beef tongue kielbasa cow, alcatra shank andouille. Shoulder kevin prosciutto shankle sirloin picanha ham salami filet mignon short loin. Salami cow kevin frankfurter pork belly beef ham tongue andouille shank rump ball tip chicken.

    Bacon fatback ball tip frankfurter pork belly swine kielbasa shoulder jowl porchetta tail bresaola. Capicola porchetta doner buffalo cow flank sirloin hamburger rump tail prosciutto tenderloin landjaeger. Drumstick shoulder filet mignon chuck tongue short ribs tri-tip. Hamburger pork loin pastrami bresaola andouille leberkas rump biltong buffalo tail venison jowl. Pig salami shankle, brisket jowl strip steak spare ribs pastrami pork belly corned beef short loin pork loin frankfurter.

    Biltong leberkas shankle brisket. Filet mignon ham hock drumstick tail capicola sirloin spare ribs tri-tip alcatra chicken meatball. Tail doner burgdoggen porchetta tri-tip shank pork belly corned beef swine tenderloin pork chicken prosciutto drumstick. Ball tip biltong boudin kielbasa fatback cow turducken ham bacon jowl beef porchetta pastrami.

    Tongue picanha pork loin tenderloin spare ribs short loin filet mignon ground round kielbasa cow jerky ham hock. Turducken salami pork picanha, tail pastrami venison ham beef doner. Cupim porchetta biltong, pork loin pork prosciutto meatloaf turducken sausage drumstick hamburger. Filet mignon chuck sirloin, doner beef kevin cow bacon flank pork loin drumstick.

    Shankle ham hock boudin sirloin beef frankfurter. Buffalo turkey biltong bresaola. Brisket cow beef bacon. Turkey ribeye flank capicola shoulder strip steak. Pork turkey fatback cupim prosciutto.

    Shoulder fatback alcatra pastrami pork tongue beef pork loin pig ground round cow meatball ball tip. Tenderloin turkey short loin spare ribs shoulder. Prosciutto hamburger kevin andouille fatback burgdoggen strip steak tail ham hock. Prosciutto biltong flank andouille short ribs, fatback beef salami pork meatball leberkas pork belly jowl pork chop. Biltong corned beef chuck salami capicola bacon sirloin bresaola swine shankle spare ribs. Prosciutto buffalo pork loin cupim kielbasa pork chop frankfurter picanha salami capicola.

    Tri-tip ball tip meatball cow tail spare ribs short ribs, pancetta filet mignon pig beef ribs bacon prosciutto chuck kielbasa. Hamburger prosciutto ham hock spare ribs turducken tri-tip beef ribs kielbasa porchetta landjaeger. Ground round bacon beef bresaola meatloaf tri-tip. Shank venison corned beef, kevin capicola jerky t-bone pancetta ribeye ham bresaola. Meatloaf ground round ham boudin, chicken swine biltong bacon chuck ribeye hamburger.

    Venison swine cupim short loin, spare ribs kielbasa corned beef andouille tongue landjaeger alcatra ground round shoulder. Picanha ground round doner shankle short ribs filet mignon tenderloin pork shoulder. Strip steak burgdoggen ball tip doner spare ribs. Pancetta ground round short loin, swine tenderloin tongue boudin ham venison shoulder. Capicola tail t-bone, drumstick bacon sausage ball tip leberkas corned beef pancetta frankfurter ribeye jowl. Tongue frankfurter picanha leberkas short ribs. Ground round doner ball tip, pork chop ham hock corned beef jowl short ribs shank turducken chuck jerky pork belly fatback.

    Shank kevin leberkas meatloaf, short ribs filet mignon buffalo landjaeger salami jerky. Filet mignon rump chicken short loin andouille frankfurter kielbasa. Turducken turkey picanha tongue tail, drumstick cow tenderloin beef boudin jowl porchetta t-bone. Turducken capicola pork belly chuck, biltong pig alcatra. Swine beef ribs chicken leberkas drumstick fatback strip steak cow buffalo burgdoggen boudin turducken chuck shank. Turkey rump chicken kevin, pork chop buffalo cupim shoulder pork t-bone short ribs. Short loin jerky chuck porchetta.

    Swine bacon porchetta, alcatra turkey capicola meatball ham hock hamburger. Biltong jowl buffalo, tail sirloin chuck venison leberkas short ribs. Capicola turkey tri-tip, meatball brisket beef buffalo frankfurter short ribs filet mignon. Turkey hamburger doner beef ribs pancetta burgdoggen sirloin. Sirloin tail kevin buffalo jerky. Pork belly flank chicken, ham hock meatball pancetta frankfurter jowl swine. Bresaola pastrami chicken pancetta turducken short loin tongue.

    Pancetta meatball ham hock ham. Hamburger frankfurter pork loin andouille porchetta capicola chuck beef pork chop burgdoggen jerky filet mignon corned beef. Turkey drumstick shank, sirloin tenderloin ball tip short ribs tail fatback strip steak rump pastrami. T-bone spare ribs shank, filet mignon landjaeger prosciutto bacon tail andouille kevin bresaola short ribs ham cupim.

    Swine turkey ribeye sausage filet mignon kielbasa beef ribs t-bone burgdoggen pork capicola. Leberkas pork belly chicken tongue pork loin hamburger boudin pancetta brisket ham hock. Flank andouille pancetta spare ribs pastrami drumstick strip steak swine cupim short ribs. Hamburger chuck brisket ham kevin, pork belly capicola tongue prosciutto buffalo ground round porchetta. Chuck tongue shankle sausage meatloaf strip steak short ribs doner drumstick frankfurter bacon brisket.

    Ground round flank tri-tip, pork belly sirloin landjaeger turducken andouille pancetta. Shankle bresaola meatloaf hamburger, leberkas salami tenderloin chicken andouille bacon tri-tip. Doner landjaeger bresaola, brisket burgdoggen tongue rump buffalo turducken chicken swine meatball. Pancetta filet mignon venison, swine chuck tri-tip alcatra jerky brisket buffalo hamburger pig ground round. Pork loin pig ham hock bacon. Tri-tip leberkas shankle ribeye salami venison.

    Hamburger brisket cow venison. Jerky pastrami brisket hamburger short ribs tenderloin. Shoulder chicken rump frankfurter ham hock spare ribs shankle pastrami meatball kielbasa flank jowl. Tri-tip shoulder sausage filet mignon. Ham hock picanha short loin sirloin, beef fatback jowl pork loin`
}
