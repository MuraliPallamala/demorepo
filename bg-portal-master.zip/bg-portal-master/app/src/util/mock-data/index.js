import * as data from "./data"
import * as onboarding from "./onboarding"

export { data, onboarding }
