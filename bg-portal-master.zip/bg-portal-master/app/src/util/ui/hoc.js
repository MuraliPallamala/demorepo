// @flow

import React from "react"

type With = (component: any) => any
type Condition = (props: Object) => boolean

export const withMaybe = (conditionF: Condition): With => Component => props =>
    conditionF(props) ? <Component {...props} /> : null

export const withEither = (conditionF: Condition, EitherComponent: any): With => Component => props =>
    conditionF(props) ? <EitherComponent /> : <Component {...props} />
