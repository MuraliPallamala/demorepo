/* eslint import/prefer-default-export: 0 */

const re = /([\d.]+)un/g

export const createReplaceUn = unit => arg =>
    typeof arg === "string" ? arg.replace(re, (match, p1) => `${+p1 * unit}px`) : arg
