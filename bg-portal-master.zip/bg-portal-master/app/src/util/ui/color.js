// @flow

type Color = { type: string, values: Array<number> }

export function clamp(value: number, min: number, max: number): number {
    if (value < min) return min
    if (value > max) return max
    return value
}

export function convertColorToString(color: Color) {
    const { type, values } = color

    if (type.indexOf("rgb") > -1) {
        // Only convert the first 3 values to int (i.e. not alpha)
        for (let i = 0; i < 3; i++) {
            values[i] = parseInt(values[i], 10)
        }
    }

    let colorString

    if (type.indexOf("hsl") > -1) {
        colorString = `${color.type}(${values[0]}, ${values[1]}%, ${values[2]}%`
    } else {
        colorString = `${color.type}(${values[0]}, ${values[1]}, ${values[2]}`
    }

    if (values.length === 4) {
        colorString += `, ${color.values[3]})`
    } else {
        colorString += ")"
    }

    return colorString
}

export function convertHexToRGB(color: string): string {
    const parse = (c: string): string => {
        const values = {
            r: parseInt(c.substr(1, 2), 16),
            g: parseInt(c.substr(3, 2), 16),
            b: parseInt(c.substr(5, 2), 16)
        }
        return `rgb(${values.r}, ${values.g}, ${values.b})`
    }
    if (color.length === 4) {
        let extendedColor = "#"
        for (let i = 1; i < color.length; i++) {
            extendedColor += color.charAt(i) + color.charAt(i)
        }
        return parse(extendedColor)
    }
    return parse(color)
}

export function decomposeColor(color: string): Color {
    if (color.charAt(0) === "#") {
        return decomposeColor(convertHexToRGB(color))
    }
    const marker = color.indexOf("(")
    if (marker <= 0) {
        console.log(`The ${color} color was not parsed correctly, it has an unsupported format (color name or RGB %).`)
    }
    const type = color.substring(0, marker)
    let values = color.substring(marker + 1, color.length - 1).split(",")
    values = values.map(value => parseFloat(value))
    return { type, values }
}

export function getLuminance(color: string): number {
    const c = decomposeColor(color)
    if (c.type.indexOf("rgb") > -1) {
        const rgb = c.values.map(value => {
            const val = value / 255 // normalized
            return val <= 0.03928 ? val / 12.92 : ((val + 0.055) / 1.055) ** 2.4
        })
        return Number((0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]).toFixed(3))
        // Truncate at 3 digits
    } else if (c.type.indexOf("hsl") > -1) {
        return c.values[2] / 100
    }
    console.log(`The ${color} color was not parsed correctly, it has an unsupported format (color name or RGB %).`)
    return 0
}

export function emphasize(color: string, coefficient: number = 0.15): string {
    return getLuminance(color) > 0.5 ? darken(color, coefficient) : lighten(color, coefficient)
}

export function fade(color: string, value: number): string {
    const c = decomposeColor(color)
    if (c.type === "rgb" || c.type === "hsl") c.type += "a"
    c.values[3] = clamp(value, 0, 1)
    return convertColorToString(c)
}

export function darken(color: string, coefficient: number): string {
    const c = decomposeColor(color)
    if (c.type.indexOf("hsl") > -1) {
        c.values[2] *= 1 - clamp(coefficient, 0, 1)
    } else if (c.type.indexOf("rgb") > -1) {
        for (let i = 0; i < 3; i++) {
            c.values[i] *= 1 - clamp(coefficient, 0, 1)
        }
    }
    return convertColorToString(c)
}

export function lighten(color: string, coefficient: number): string {
    const c = decomposeColor(color)
    if (c.type.indexOf("hsl") > -1) {
        c.values[2] += (100 - c.values[2]) * clamp(coefficient, 0, 1)
    } else if (c.type.indexOf("rgb") > -1) {
        for (let i = 0; i < 3; i++) {
            c.values[i] += (255 - c.values[i]) * clamp(coefficient, 0, 1)
        }
    }
    return convertColorToString(c)
}
