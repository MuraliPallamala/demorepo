// @flow
import { createMuiTheme } from "@material-ui/core/styles"

const gxStatusColor = {
    notIssued: "#01AEC0",
    active: "#01C062",
    cancelled: "#E45B20",
    demanded: "#E45B20",
    expired: "#E45B20",
    denied: "#E45B20"
}
const fontFamily = '"Roboto", "Helvetica", "Arial", sans-serif'
const commonFontWeights = {
    medium: 500,
    regular: 400,
    light: 300
}
const commonFontSizes = {
    large: "1.375rem",
    medium: "1.125rem",
    small: "0.875rem"
}
const commonPalette = {
    black: "#000",
    white: "#fff",
    lightBlue: "#006CC5",
    darkBlue: "#455977",
    defaultGreen: "#1E7E45",
    defaultRed: "#AC0825",
    defaultGrey: "#959595",
    defaultHover: "#F4FEFD",
    disabledDark: "#2F5573",
    statusGreen: "#01C062",
    highlightGreen: "#F4FAFE",
    statusRed: "#E45B20",
    highlightRed: "#FEF9F4",
    statusRedBackground: "#FEF9F4",
    statusBlue: "#01AEC0",
    notificationBlue: "#0366FD",
    bgStatusBlue: "#00799A",
    bgStatusGreen: "#008644",
    bgStatusRed: "#C90E2F",
    bgSubstatusGreen: "#004C27",
    bgSubstatusOrange: "#DF6000",
    bgSubstatusDarkOrange: "#562900",
    bgHighlight: "#FFF48B",
    searchBackground: "#FDFDFD",
    transparent: "rgba(0, 0, 0, 0)",
    fullBlack: "rgba(0, 0, 0, 1)",
    darkBlack: "rgba(0, 0, 0, 0.87)",
    lightBlack: "rgba(0, 0, 0, 0.54)",
    minBlack: "rgba(0, 0, 0, 0.26)",
    faintBlack: "rgba(0, 0, 0, 0.12)",
    lightGrey: "#68727b",
    defaultYellow: "#E8B708",
    pageTitle: "rgba(80,91,102,0.87)",
    fullWhite: "rgba(255, 255, 255, 1)",
    darkWhite: "rgba(255, 255, 255, 0.87)",
    lightWhite: "rgba(255, 255, 255, 0.54)",
    backgroundGrey: "#F1F3F5",
    sidebarText: "#365371",
    gxStatusColor,
    getGxStatusColor: (s: string) => {
        if (gxStatusColor[s]) {
            return gxStatusColor[s]
        }
        return "#000000"
    },
    actionable: "#F4FFFC",
    nonactionable: "#FFFFFF",
    notification: "#AC0825",
    graphLine: "#3E4EB8",
    graphMarker: "#C4C8E9",
    loginSection: "#455977",
    completedStep: "#1E7E45",
    activeStep: "#1B74BD",
    errorStep: "#2F5573",
    completedStepText: "#2F5573",
    confirmationButtonBackground: "#EDF2F9",
    confirmationButtonText: "#455977",
    buttonHover: "#F4FEFD",
    stepConnector: "#A8B2C2",
    buttonGreen: "#1E7E45",
    messageGreen: "#1E7E45"
}

export default function getUserTheme(config: Object) {
    const { primary, secondary } = config.colors
    const tabActive = {
        marginRight: "3rem",
        marginTop: ".5rem",
        marginBottom: ".5rem",
        color: commonPalette.white,
        backgroundColor: commonPalette.lightBlue,
        borderRadius: "2px",
        border: `1.4px solid ${commonPalette.lightBlue}`,
        "&:hover": {
            backgroundColor: commonPalette.lightBlue
        },
        "&:disabled": {
            color: commonPalette.white,
            backgroundColor: commonPalette.lightBlue,
            border: `1.4px solid ${commonPalette.lightBlue}`
            // backgroundColor: theme.palette.action.disabledBackground
        },
        padding: "none",
        paddingTop: ".9em",
        paddingBottom: ".9em",
        width: "450px",
        textTransform: "none",
        fontSize: commonFontSizes.small,
        fontWeight: commonFontWeights.medium
    }
    const tabInactive = {
        marginRight: "3rem",
        marginTop: ".5rem",
        marginBottom: ".5rem",
        color: commonPalette.lightBlue,
        borderRadius: "2px",
        border: `1.4px solid ${commonPalette.lightBlue}`,
        "&:hover": {
            backgroundColor: commonPalette.buttonHover
        },
        "&:disabled": {
            border: `1.4px solid ${commonPalette.minBlack}`
        },
        padding: "none",
        paddingTop: ".9em",
        paddingBottom: ".9em",
        width: "450px",
        textTransform: "none",
        fontSize: commonFontSizes.small,
        fontWeight: commonFontWeights.medium
    }
    const stepper = {
        flex: 1,
        maxWidth: 800,
        backgroundColor: "transparent"
    }
    const icon = {
        color: commonPalette.darkBlue,
        justifySelf: "center",
        width: "1.5em",
        height: "1.5em"
    }
    const buttonContainer = {
        display: "flex",
        flexDirection: "row",
        justifyContent: "flex-end"
    }
    const typography = {
        fontFamily,
        fontSize: commonFontSizes.small,
        fontSizeSmall: commonFontSizes.small,
        typography: commonFontSizes.medium,
        fontSizeMedium: commonFontSizes.medium,
        fontSizeLarge: commonFontSizes.large,
        fontWeightLight: commonFontWeights.light,
        fontWeightRegular: commonFontWeights.regular,
        fontWeightMedium: commonFontWeights.medium,
        timelineIcon: {
            color: commonPalette.darkBlue,
            height: "26px",
            width: "26px"
        },
        logoSubheading: {
            fontSize: "0.7em",
            color: primary.contrastText,
            fontStyle: "italic",
            letterSpacing: "0.72px"
        },
        amendCard: {
            backgroundColor: commonPalette.defaultHover
        },
        footerText: {
            color: commonPalette.darkBlue,
            fontSize: commonFontSizes.medium,
            fontStyle: "italic"
        },
        formTitle: {
            color: commonPalette.darkBlue,
            fontFamily,
            fontSize: commonFontSizes.medium,
            fontWeight: commonFontWeights.medium
        },
        cardTitle: {
            color: commonPalette.darkBlue,
            fontFamily,
            fontSize: commonFontSizes.medium,
            fontWeight: commonFontWeights.medium,
            paddingBottom: "1.5rem"
        },
        tableTitle: {
            color: commonPalette.disabledDark,
            fontSize: commonFontSizes.large,
            fontWeight: 300,
            fontFamily,
            lineHeight: "24px"
        },
        button: {
            fontSize: commonFontSizes.medium,
            textTransform: "uppercase",
            fontWeight: commonFontWeights.regular,
            fontFamily,
            color: commonPalette.lightBlue
        },
        display4: {
            fontSize: "7rem",
            fontWeight: commonFontWeights.light,
            fontFamily,
            letterSpacing: "-.04em",
            lineHeight: "1.14286em",
            marginLeft: "-.06em",
            color: "rgba(0, 0, 0, 0.54)"
        },
        display3: {
            fontSize: "3.5rem",
            fontWeight: 400,
            fontFamily,
            letterSpacing: "-.02em",
            lineHeight: "1.30357em",
            marginLeft: "-.04em",
            color: "rgba(0, 0, 0, 0.54)"
        },
        display2: {
            fontSize: "2.8125rem",
            fontWeight: 400,
            fontFamily,
            lineHeight: "1.06667em",
            marginLeft: "-.04em",
            color: "rgba(0, 0, 0, 0.54)"
        },
        display1: {
            fontSize: "2.125rem",
            fontWeight: 400,
            fontFamily,
            lineHeight: "1.20588em",
            marginLeft: "-.04em",
            color: "rgba(0, 0, 0, 0.54)"
        },
        headline: {
            fontSize: "1.375rem",
            fontWeight: 400,
            fontFamily,
            lineHeight: "1.35417em",
            color: "rgba(65, 94, 140, 1)"
        },
        title: {
            fontSize: commonFontSizes.large,
            fontWeight: commonFontWeights.medium,
            fontFamily,
            lineHeight: "1.16667em",
            color: "rgba(0, 0, 0, 0.87)"
        },
        subheading: {
            fontSize: commonFontSizes.medium,
            fontWeight: commonFontWeights.light,
            fontFamily,
            lineHeight: undefined,
            color: commonPalette.darkBlue
        },
        body3: {
            fontSize: commonFontSizes.medium,
            fontWeight: commonFontWeights.medium,
            fontFamily,
            lineHeight: "1.71429em",
            color: commonPalette.darkBlue
        },
        body2: {
            fontSize: commonFontSizes.small,
            fontWeight: commonFontWeights.medium,
            fontFamily,
            lineHeight: "1.71429em",
            color: commonPalette.darkBlue
        },
        body1: {
            fontSize: commonFontSizes.small,
            fontWeight: commonFontWeights.regular,
            fontFamily,
            lineHeight: "1.46429em",
            color: commonPalette.darkBlue
        },
        caption: {
            fontSize: "0.75rem",
            fontWeight: commonFontWeights.regular,
            fontFamily,
            lineHeight: "1.375em",
            color: "rgba(0, 0, 0, 0.54)"
        },
        confirmMessage: {
            marginLeft: "1rem",
            fontSize: commonFontSizes.medium,
            fontStyle: "italic",
            fontWeight: 400,
            fontFamily,
            lineHeight: "1.5em",
            color: commonPalette.messageGreen
        },
        linkMessage: {
            fontSize: commonFontSizes.medium,
            fontStyle: "italic",
            fontWeight: commonFontWeights.regular,
            fontFamily,
            lineHeight: "1.5em",
            color: commonPalette.pageTitle
        },
        link: {
            p: {
                fontSize: commonFontSizes.medium,
                fontStyle: "italic",
                fontWeight: commonFontWeights.regular,
                fontFamily,
                lineHeight: "1.5em",
                color: `${commonPalette.lightBlue}!important`
            },
            textDecoration: "none"
        },
        tableStyle: {
            color: "#455977",
            fontSize: "0.875rem",
            fontWeight: "400",
            fontFamily: '"Roboto", "Helvetica", "Arial", "sans-serif"',
            lineHeight: "1.46429em"
        }
    }

    const overrides = {
        MuiButton: {
            root: {
                "&$disabled": { color: `${commonPalette.defaultGrey}` }
            }
        },
        MuiChip: {
            deleteIcon: {
                color: primary[500],
                "&:hover": {
                    color: primary[200]
                },
                transition: "color 0.3s"
            }
        },
        MuiInputAdornment: {
            root: {
                height: null
            }
        },
        MuiBadge: {
            colorAccent: {
                backgroundColor: commonPalette.notification,
                color: commonPalette.white
            }
        },
        MuiGrid: {
            typeContainer: {
                margin: 0
            }
        },
        MuiTab: {
            root: {
                textTransform: "default"
            }
        },
        MuiTabIndicator: {},
        MuiInput: {
            root: {
                width: "100%",
                color: `${commonPalette.darkBlue}`,
                fontSize: `${commonFontSizes.small}`,
                "&$disabled": {
                    color: `${commonPalette.defaultGrey}`
                }
            }
        },
        MuiStepLabel: {
            label: {
                color: commonPalette.disabledDark,
                "&$completed": {
                    color: commonPalette.completedStepText,
                    fontWeight: commonFontWeights.regular
                }
            },
            completed: {
                fontWeight: 300,
                color: `${commonPalette.completedStepText}`
            },
            active: {
                // color: `${commonPalette.lightBlue}!important`
                color: `${commonPalette.activeStep}!important`
            }
        },
        MuiStepIcon: {
            root: {
                color: commonPalette.disabledDark
            },
            text: {
                fill: "#FFFFFF"
            },
            completed: {
                // color: `${commonPalette.completedStep}!important`
                color: `${commonPalette.completedStep}!important`
            },
            active: {
                // color: `${commonPalette.lightBlue}!important`
                color: `${commonPalette.activeStep}!important`
            },
            error: {
                // color: `${commonPalette.defaultRed}!important`
                color: `${commonPalette.errorStep}!important`
            }
        },
        MuiStepConnector: {
            line: {
                borderColor: commonPalette.stepConnector
            }
        },
        MuiSlider: {
            track: { backgroundColor: commonPalette.lightBlue },
            thumb: { backgroundColor: commonPalette.lightBlue, height: "22px", width: "22px" }
        },
        MuiTable: {
            root: {
                minWidth: "0 !important",
                overflow: "visible !important"
            }
        },
        MuiList: {
            root: {
                paddingTop: "0px !important",
                paddingBottom: "0px !important"
            }
        },
        MuiDivider: {
            root: {
                backgroundColor: "#D3DCE3"
            }
        },
        MuiTableCell: {
            body: {
                color: commonPalette.darkBlue
            }
        },
        MuiCheckbox: {
            root: {
                "&$disabled": { color: `${commonPalette.defaultGrey}` },
                "&$checked": {
                    color: `${commonPalette.darkBlue}`
                }
            },
            colorSecondary: {
                "&$checked": {
                    color: `${commonPalette.darkBlue}`
                }
            }
        },
        MuiRadio: {
            root: {
                "&$checked": {
                    color: `${commonPalette.darkBlue}`
                }
            }
        },
        MuiDialogContentText: {
            root: {
                color: commonPalette.darkBlue
            }
        },
        imgWidth: "100px",
        sideBarHighlight: "#035277 !important",
        MuiCardActionArea: {
            focusHighlight: {
                backgroundColor: "#48fbe9"
            }
        },
        ...config.overrides
    }

    return createMuiTheme({
        palette: {
            primary,
            secondary,
            common: commonPalette,
            success: "#28ae6b",
            required: "#fff9e9"
        },
        typography,
        stepper,
        overrides,
        tabActive,
        tabInactive,
        icon,
        commonFontSizes,
        commonFontWeights,
        buttonContainer
    })
}
