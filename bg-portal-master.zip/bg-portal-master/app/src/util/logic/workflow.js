// @flow

// Constants and Types regarding Request Workflows
// i.e. the processes that each request type goes through

import type { UserRole, Gx, Rx, RxType, Workflow } from "../flow_types"
import { capitalise } from "../helpers/text"
import { RX_STATUS } from "./rx"
import { USER_ROLE } from "./user"

/* ----- CONSTANTS: Action objects ----- */
export const approveRejectAction = {
    yesName: "approve",
    noName: "reject",
    yesForm: "approve",
    yesStatus: RX_STATUS.approved,
    noStatus: RX_STATUS.denied
}

export const consentRejectAction = {
    yesName: "consent",
    noName: "reject",
    yesForm: "consent to",
    yesStatus: RX_STATUS.pending,
    noStatus: RX_STATUS.denied
}

export const applicantConsentSteps = ["Request Created", "Applicant Consent", "Bank Approval"]

/* ----- CONSTANTS Messages ----- */
export const errorMessage = "This message is being shown in error"
export const applicantChooseBankMessage = `A bank guarantee was created for you. To
    complete it, please select a bank and hit submit.
    This will be submitted to the bank you selected for final approval.`

export const beneficiaryIssuedMessage = `You created a guarantee on behalf of your applicant.
    To complete it, they need to select a bank. This request will then be submitted
    to the bank for final approval.`

export const applicantSubmittedBankMessage = `Your bank guarantee has been submitted to
    the bank and is awaiting approval.`

export const bankSelectedApproveRejectMessage = `The applicant has selected a bank and this
    request has been submitted to the bank for approval. Please add a reference number
    before approval.`

/* ----- FUNCTIONS Messages ----- */
export const createBeneficiaryDemandMessage = (
    currency: string,
    amount: number
) => `You have submitted a demand against the guarantee for ${currency} ${amount} and
    this request has been submitted to the bank for fulfilment.`

export const createBankDemandMessage = (
    currency: string,
    amount: number
) => `The beneficiary has demanded payment of ${currency} ${amount} on this guarantee and is
    awaiting approval.`
// AMEND messages
export const createAmendConsentMessage = (instigator: string) =>
    `The ${instigator} has proposed an amendment to the guarantee as shown below.
    Please consent or reject this request.`
export const createAmendedPendingConsentMessage = (signatory: string) =>
    `You have proposed an amendment to the guarantee as shown below.  Pending approval by ${signatory}.`
export const createAmendedPendingConsentBankMessage = (signatory: string) =>
    `An amendment to the guarantee has been proposed as shown below.  Pending approval by ${signatory}.`
export const amendedPendingBankMessage = `An amendment to the guarantee
    has been proposed and consented to.  Pending approval by bank.`
export const amendedApproveRejectMessage = `An amendment to the guarantee
    has been proposed and consented to.  Please approve or reject the amendment.`
// CANCELLED messages
export const createCancelConsentMessage = (instigator: string) =>
    `The ${instigator} has proposed cancellation of this guarantee.
    Please consent or reject this request.`
export const createCancelledPendingConsentMessage = (signatory: string) =>
    `You have requested cancellation of this guarantee.  Pending approval by ${signatory}.`
export const createCancelledPendingConsentBankMessage = (signatory: string) =>
    `Cancellation of this guarantee has been requested.  Pending approval by ${signatory}.`
export const cancelledPendingBankMessage = `Cancellation of this guarantee
    has been requested and consented to.  Pending approval by bank.`
export const cancelledApproveRejectMessage = `Cancellation of this guarantee
    has been requested and consented to.  Please approve or reject this request.`

/* ----- CONSTANTS: Rx Workflow Steps ----- */

export const noConsentSteps = ["Request Created", "Bank Approval"]

export const createSomeoneConsentSteps = (signatory: string) => [
    "Request Created",
    `${capitalise(signatory)} Consent`,
    "Bank Approval"
]

/* ----- CONSTANTS: workflow definitions ----- */
export const issueFlows = {
    instigatorBeneficiary: {
        actorApplicant: {
            steps: applicantConsentSteps,
            currentStep: 1,
            nextActor: USER_ROLE.applicant,
            nextAction: {
                ...consentRejectAction,
                requiredField: "bank"
            },
            messages: {
                applicant: applicantChooseBankMessage,
                bank: errorMessage,
                beneficiary: beneficiaryIssuedMessage
            }
        },
        actorBank: {
            steps: applicantConsentSteps,
            currentStep: 2,
            nextActor: USER_ROLE.bank,
            nextAction: {
                ...approveRejectAction,
                requiredField: "bankReference"
            },
            messages: {
                applicant: applicantSubmittedBankMessage,
                bank: bankSelectedApproveRejectMessage,
                beneficiary: bankSelectedApproveRejectMessage
            }
        }
    },
    instigatorApplicant: {
        steps: noConsentSteps,
        currentStep: 1,
        nextActor: USER_ROLE.bank,
        nextAction: {
            ...approveRejectAction,
            requiredField: "bankReference"
        },
        messages: {
            applicant: applicantSubmittedBankMessage,
            bank: bankSelectedApproveRejectMessage,
            beneficiary: bankSelectedApproveRejectMessage
        }
    }
}

export const demandFlow = (r: Rx) => {
    const gxba = r.gxBeforeApproval || { currency: "ERR", amount: 0 }
    const gxaa = r.gxAfterApproval || { amount: 1 }
    const gxbaAmount = gxba.amount
    const gxaaAmount = gxaa.amount
    if (typeof gxbaAmount !== "number") {
        throw new Error("Error: gxba.amount is not a number")
    }
    if (typeof gxaaAmount !== "number") {
        throw new Error("Error: gxaa.amount is not a number")
    }
    return {
        steps: noConsentSteps,
        currentStep: 1,
        nextActor: USER_ROLE.bank,
        nextAction: approveRejectAction,
        messages: {
            applicant: errorMessage,
            bank: createBankDemandMessage(gxba.currency, gxbaAmount - gxaaAmount),
            beneficiary: createBeneficiaryDemandMessage(gxba.currency, gxbaAmount - gxaaAmount)
        }
    }
}

export const amendFlow = {
    actorSignatory: ({ instigator, signatory }: Roles) => {
        const messages: { [UserRole]: string } = {
            bank: createAmendedPendingConsentBankMessage(signatory)
        }
        messages[instigator] = createAmendedPendingConsentMessage(signatory)
        messages[signatory] = createAmendConsentMessage(instigator)
        return {
            steps: createSomeoneConsentSteps(signatory),
            currentStep: 1,
            nextActor: signatory,
            nextAction: {
                ...consentRejectAction,
                extraDetail: "amend"
            },
            messages
        }
    },
    actorBank: ({ signatory }: Roles) => ({
        steps: createSomeoneConsentSteps(signatory),
        currentStep: 2,
        nextActor: USER_ROLE.bank,
        nextAction: {
            ...approveRejectAction,
            extraDetail: "amend"
        },
        messages: {
            applicant: amendedPendingBankMessage,
            bank: amendedApproveRejectMessage,
            beneficiary: amendedPendingBankMessage
        }
    })
}

export const cancelFlow = {
    actorSignatory: ({ instigator, signatory }: Roles) => {
        const messages: { [UserRole]: string } = {
            bank: createCancelledPendingConsentBankMessage(signatory)
        }
        messages[instigator] = createCancelledPendingConsentMessage(signatory)
        messages[signatory] = createCancelConsentMessage(instigator)
        return {
            steps: createSomeoneConsentSteps(signatory),
            currentStep: 1,
            nextActor: signatory,
            nextAction: consentRejectAction,
            messages
        }
    },
    actorBank: ({ signatory }: Roles) => ({
        steps: createSomeoneConsentSteps(signatory),
        currentStep: 2,
        nextActor: USER_ROLE.bank,
        nextAction: approveRejectAction,
        messages: {
            applicant: cancelledPendingBankMessage,
            bank: cancelledApproveRejectMessage,
            beneficiary: cancelledPendingBankMessage
        }
    })
}

/* ----- FUNCS: helpers ----- */
type NonBankUser = typeof USER_ROLE.beneficiary | typeof USER_ROLE.applicant
type Roles = { instigator: NonBankUser, signatory: NonBankUser }
export const findRoles = (r: Rx, g: Gx): Roles => {
    if (r.statusHistory[0].actor === g.beneficiary) {
        return {
            instigator: USER_ROLE.beneficiary,
            signatory: USER_ROLE.applicant
        }
    } else if (r.statusHistory[0].actor === g.applicant) {
        return {
            instigator: USER_ROLE.applicant,
            signatory: USER_ROLE.beneficiary
        }
    }
    throw Error("Instigator of rx doesn't match applicant or beneficiary")
}

/* ----- FUNCS: workflow getters ----- */
export const instigatorBeneficiary = (r: Rx) =>
    r.currentStatus.status === RX_STATUS.consentRequired
        ? issueFlows.instigatorBeneficiary.actorApplicant
        : issueFlows.instigatorBeneficiary.actorBank

export const consentStepFlow = (r: Rx, g: Gx, flow: Object): Workflow =>
    r.currentStatus.status === RX_STATUS.consentRequired
        ? flow.actorSignatory(findRoles(r, g))
        : flow.actorBank(findRoles(r, g))

export const flows: { [RxType]: (Rx, Gx) => Workflow } = {
    issue: (r, g) =>
        findRoles(r, g).instigator === USER_ROLE.beneficiary
            ? instigatorBeneficiary(r)
            : issueFlows.instigatorApplicant,
    demand: (r, g) => demandFlow(r),
    amend: (r, g) => consentStepFlow(r, g, amendFlow),
    cancel: (r, g) => consentStepFlow(r, g, cancelFlow)
}

export const getWorkflow = (r: Rx, g: Gx): Workflow => flows[r.type](r, g)
