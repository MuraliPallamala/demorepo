// @flow

import type { Gx } from "../flow_types"
import * as rx from "./rx"

/* eslint-disable */
type $Object<V> = { +[key: string]: V };
type _$Values<V, O: $Object<V>> = V;
type $Values<O: Object> = _$Values<*, O>;
/* eslint-enable */

type Enumerables = { [key: string]: any }

export const TYPE: Enumerables = {
    issue: "Issue",
    demand: "Demand",
    cancel: "Cancel",
    expire: "Expire"
}

export type Type = $Values<typeof TYPE>

export type Event = {
    type: Type,
    amount: number,
    gx: Gx
}

export const createEvent = (type: Type, amount: number, gx: Gx): Event => ({
    type,
    amount,
    gx
})

export type Datapoint = {
    date: Date,
    amount: number,
    events: Array<Event>
}

export type Datapoints = { [key: string]: Datapoint }

export type DateAmount = {
    date: Date,
    amount: number
}

export const getDemands = (guarantee: Gx): Array<DateAmount> =>
    guarantee.requestHistory.reduce((prev, curr) => {
        const gxBefore = curr.gxBeforeApproval
        const gxAfter = curr.gxAfterApproval
        if (curr.type === rx.RX_TYPE.demand && gxBefore && gxAfter) {
            const approvedDate = rx.getApprovedDate(curr)
            if (approvedDate && gxBefore.amount && gxAfter.amount) {
                prev.push({
                    date: approvedDate,
                    amount: gxBefore.amount - gxAfter.amount
                })
            }
        }
        return prev
    }, [])

export const getAmendments = (guarantee: Gx): Array<DateAmount> =>
    guarantee.requestHistory.reduce((prev, curr) => {
        const gxBefore = curr.gxBeforeApproval
        const gxAfter = curr.gxAfterApproval
        if (curr.type === rx.RX_TYPE.amend && gxBefore && gxAfter) {
            const approvedDate = rx.getApprovedDate(curr)
            if (approvedDate && gxBefore.amount && gxAfter.amount) {
                if (gxBefore.amount !== gxAfter.amount) {
                    prev.push({
                        date: approvedDate,
                        amount: gxBefore.amount - gxAfter.amount
                    })
                }
            }
        }
        return prev
    }, [])

export const createDatapoint = (date: Date): Datapoint => ({
    date,
    amount: 0,
    events: []
})
