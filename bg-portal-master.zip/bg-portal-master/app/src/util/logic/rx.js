// @flow

// Constants and Types regarding Guarantee Requests
import type { Rx } from "../flow_types"
import { last } from "../helpers/text"

export const RX_TYPE = {
    issue: "issue",
    demand: "demand",
    amend: "amend",
    cancel: "cancel",
    expire: "expire"
}

export const RX_STATUS = {
    consentRequired: "consentRequired",
    pending: "pending",
    approved: "approved",
    denied: "denied",
    cancelled: "cancelled"
}

export const parse = (inRx: Rx): Rx => {
    const rx = inRx
    const cs = last(rx.statusHistory)
    if (cs) {
        rx.currentStatus = cs
    }
    rx.statusHistory = rx.statusHistory.map(sh => Object.assign(sh, { timestamp: new Date(sh.timestamp) }))
    rx.active =
        rx.currentStatus.status !== "approved" &&
        rx.currentStatus.status !== "denied" &&
        rx.currentStatus.status !== "cancelled"
    return rx
}

export const getApprovedDate = (request: Rx): ?Date =>
    request.statusHistory.reduce((prev, curr) => {
        if (curr.status === RX_STATUS.approved) return curr.timestamp
        return prev
    }, null)
