// @flow

// Constants and Types regarding Search Filters

import type { User, Bank, Currency, Gx, GxStatus, GxType } from "../flow_types"

// Must defined at least one of Start/End
export type DateRange = { start?: Date, end?: Date }

// Must defined at least one of Start/End
export type AmountRange = { low: number } | { high: number } | { low: number, high: number }

export type OrderFilter = {
    field: string,
    ascending: boolean
}

export type GxFilter = {
    id?: string,
    status?: GxStatus,
    bankReference?: string,
    type?: GxType,
    applicant?: string,
    beneficiary?: string,
    bank?: Bank,
    currency?: Currency,
    amount?: AmountRange,
    issueDate?: DateRange,
    expiryDate?: DateRange,
    closedDate?: DateRange,
    purpose?: string,
    additionalConditions?: string,
    notifications?: boolean,
    activeRequest?: boolean,
    needsAction?: boolean,
    order?: OrderFilter
}

export type GxReport = {
    label: string,
    route?: string,
    indent: boolean,
    search?: string,
    filter?: GxFilter,
    count: (user: User, list: Array<Gx>) => number
}

export const daysFromNow = (days: number): DateRange => ({
    end: new Date(new Date().getTime() + days * 24 * 60 * 60 * 1000)
})

export const newDateRange = (): DateRange => ({
    end: new Date()
})

export const dateInRange = (date: ?Date, range?: DateRange): boolean => {
    if (date !== undefined && date !== null && range !== undefined) {
        const rangeStart = range.start
        const rangeEnd = range.end
        if (rangeStart !== undefined && rangeEnd !== undefined) {
            return rangeStart.getTime() <= date.getTime() && date.getTime() <= rangeEnd.getTime()
        } else if (rangeStart !== undefined) {
            return rangeStart.getTime() <= date.getTime()
        } else if (rangeEnd !== undefined) {
            return date.getTime() <= rangeEnd.getTime()
        }
    } else if (date === undefined && range !== undefined) {
        return false
    }
    return true
}

export const newGxFilter = (): GxFilter => ({
    id: "",
    // status: GX_STATUS.ACTIVE,
    bankReference: "",
    // type: gx.type.rental,
    applicant: "",
    beneficiary: "",
    // bank: entities.bank.ANZ,
    // currency: entities.currency.AUD,
    // amount: 0,
    // issueDate: newDateRange(),
    // expiryDate: newDateRange(),
    // closedDate: newDateRange(),
    text: ""
    // notifications: false,
    // activeRequest: false,
    // needsAction: false
    // order: OrderFilter
})
