// @flow

import type { User } from "../flow_types"

export const USER_ROLE = {
    bank: "bank",
    beneficiary: "beneficiary",
    applicant: "applicant"
}

export const parseUser = (json: string): User => {
    const u = JSON.parse(json)
    return {
        id: u.id,
        name: u.name,
        role: u.role,
        notifications: u.notifications,
        gxLimit: u.gxLimit
    }
}
