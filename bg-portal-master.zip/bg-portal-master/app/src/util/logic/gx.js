// @flow

// Constants and Types regarding Guarantees

import type { User, Gx, GxDetails, AmendChange } from "../flow_types"
import { ENTITIES } from "../CONSTANTS"
import { last } from "../helpers/text"
import { USER_ROLE } from "./user"
import * as rx from "./rx"

export const GX_STATUS = {
    ACTIVE: "ACTIVE",
    CANCELLED: "CANCELLED",
    DEMANDED: "DEMANDED",
    EXPIRED: "EXPIRED",
    TRANSFERRED: "TRANSFERRED",
    PAYWALKED: "PAYWALKED"
}

export const GX_STATUS_DISPLAY_MAP = {
    ACTIVE: "Active",
    CANCELLED: "Cancelled",
    DEMANDED: "Demanded",
    EXPIRED: "Expired",
    TRANSFERRED: "Transferred",
    PAYWALKED: "Pay and Walk"
}

export const getGxStatusDisplay = (status: string) => GX_STATUS_DISPLAY_MAP[status]

export const GX_TYPE = {
    rental: "rental"
    // customs: "customs",
    // electricity: "electricity",
    // performance: "performance"
}

export const GX_STANDARD_CONDITIONS = {
    rental: [
        "This is the first standard condition for a rental bond",
        "This is a second condition for a rental bond",
        "This is the final condition for a rental bond"
    ],
    customs: ["customs condition 1", "customs condition 2", "customs condition 3", "customs condition 4"],
    electricity: [
        "electricity condition 1",
        "electricity condition 2",
        "electricity condition 3",
        "electricity condition 4"
    ],
    performance: ["performance condition 1", "performance condition 2", "performance condition 3"]
}

export const SAMPLE_GX_DATA = {
    id: "12345678-87654321-asdfghjk-kjhgfdsa",
    status: GX_STATUS.ACTIVE,
    requestHistory: [
        {
            id: "12345iud",
            type: "issue",
            statusHistory: [
                {
                    status: "consentRequired",
                    timestamp: new Date(),
                    actor: "Landlord Holdings",
                    rationale: "Because it's required"
                }
            ]
        }
    ],
    bankReference: "ANZ12345",
    beneficiaryReference: "SCENTRE12367",
    type: GX_TYPE.rental,
    applicant: "Hello Corp",
    beneficiary: "Landlord Holdings",
    purpose: "For reasons",
    bank: ENTITIES.BANK.ANZ,
    currency: ENTITIES.CURRENCY.AUD,
    amount: 456,
    expiryDate: new Date(),
    additionalConditions: "Here are some conditions that are conditional"
}

export const newGx = (): GxDetails => ({
    bankReference: "",
    beneficiaryReference: "",
    type: GX_TYPE.rental,
    applicant: "",
    beneficiary: "",
    purpose: "",
    currency: ENTITIES.CURRENCY.AUD,
    additionalConditions: ""
})

export const gxParse = (json: Object): Gx => {
    const gx = json
    gx.requestHistory = json.requestHistory.map(r => rx.parse(r))
    const lastRequest = last(gx.requestHistory)
    if (lastRequest && lastRequest.active) {
        gx.activeRequest = lastRequest
    }

    if (gx.expiryDate && gx.expiryDate !== "") {
        gx.expiryDate = new Date(gx.expiryDate)
    } else {
        delete gx.expiryDate
    }

    return gx
}

export const sampleGx = (): Gx => gxParse(SAMPLE_GX_DATA)

export const needsAction = (gx: Gx, user: User): boolean => {
    if (gx.requestHistory.length === 0) return false
    // Examine the status of the currentStatus of the
    // last request in the requestHistory...
    const rH = gx.requestHistory
    const currentStatus = rH[rH.length - 1].currentStatus.status
    // If pending it will be an action if user is bank
    if (currentStatus === rx.RX_STATUS.pending && user.role === USER_ROLE.bank) {
        return true
    }
    // If consent is required then it is an action for the applicant
    if (currentStatus === rx.RX_STATUS.consentRequired && user.role === USER_ROLE.applicant) {
        return true
    }
    return false
}

export const getIssueDate = (guarantee: Gx): ?Date => rx.getApprovedDate(guarantee.requestHistory[0])

export const getIssueAmount = (guarantee: Gx): ?number => {
    const request = guarantee.requestHistory[0]
    if (request && request.gxAfterApproval) {
        return request.gxAfterApproval.amount
    }
    return null
}

export const getDemandDate = (guarantee: Gx): ?Date => {
    const demanded = guarantee.status === GX_STATUS.DEMANDED
    guarantee.requestHistory.reduce((prev, curr) => {
        if (curr.type === rx.RX_TYPE.demand && demanded) {
            return rx.getApprovedDate(curr)
        }
        return prev
    }, null)
}

export const getCancelDate = (guarantee: Gx): ?Date =>
    guarantee.requestHistory.reduce((prev, curr) => {
        if (curr.type === rx.RX_TYPE.cancel) {
            return rx.getApprovedDate(curr)
        }
        return prev
    }, null)

export const getExpireDate = (guarantee: Gx): ?Date => guarantee.expiryDate

// Comparing GxBefore and GxAfterApproval on request to find the changes
export const findChanges = (gx1: GxDetails, gx2: GxDetails): Array<AmendChange> => {
    const changes = []
    // keys must be defined manually as gx1 and gx2 may have some of these missing
    const keys: Array<$Keys<GxDetails>> = [
        "bankReference",
        "beneficiaryReference",
        "type",
        "applicant",
        "beneficiary",
        "bank",
        "purpose",
        "currency",
        "amount",
        "expiryDate",
        "additionalConditions"
    ]

    keys.forEach(key => {
        const bv = gx1[key]
        const av = gx2[key]
        if (bv !== av) {
            changes.push({ key, bv, av })
        }
    })
    return changes
}
