// @flow
const sortByDate = (a: Object, b: Object, dataName: string) => {
    const dateA = new Date(a[dataName])
    const dateB = new Date(b[dataName])
    if (dateA > dateB) {
        return 1
    } else if (dateA < dateB) {
        return -1
    }
    return 0
}
export default sortByDate
