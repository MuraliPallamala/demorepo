import { transform, isEqual, isObject } from "lodash/fp"

const cappedTransform = transform.convert({
    cap: false
})

const iteratee = baseObj => (result, value, key) => {
    if (!isEqual(value, baseObj[key])) {
        const valIsObj = isObject(value) && isObject(baseObj[key])
        result[key] = valIsObj === true ? differenceObject(value, baseObj[key]) : value
    }
}

export function differenceObject(targetObj, baseObj) {
    return cappedTransform(iteratee(baseObj), null, targetObj)
}
export default differenceObject
