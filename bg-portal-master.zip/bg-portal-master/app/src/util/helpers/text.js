// @flow
import moment from "moment"

export const capitalise = (s: string): string => s.replace(/(?:^|\s)\S/g, a => a.toUpperCase())
export const capitaliseFirst = (s: string): string => (s[0] ? s[0].toUpperCase() + s.slice(1) : "")

export const split = (s: string): string =>
    capitalise(s)
        .split(/(?=[A-Z])/)
        .join(" ")

export function first<T>(a: Array<T>): T | void {
    return a[0]
}
export function firstLetter(s: string) {
    return s.toLowerCase().replace(/^.{1}/g, s[0].toUpperCase())
}

export function last<T>(a: Array<T>): T | void {
    return a[a.length - 1]
}

export function addressToString({
    addressCountry,
    addressLocality,
    addressRegion,
    postOfficeBoxNumber,
    postalCode,
    streetAddress
}: Object) {
    return `${streetAddress}, ${addressLocality}, ${postalCode}, ${
        addressRegion != null && addressRegion.value ? addressRegion.value : addressRegion
    }, ${addressCountry != null && addressCountry.value ? addressCountry.value : addressCountry}`
}

export function dateToString(dateIn: Object) {
    return moment(dateIn).format("LLL")
}

export function dateToShortString(dateIn: Object) {
    return moment(dateIn).format("L")
}

export function numberWithSpaces(x: number) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ")
}

export const parseAccountDetails = (account: Object) => {
    let bankString = ""
    switch (account.type) {
        case "BANK_ACCOUNT_AU_NZ": {
            bankString = `Account Name: ${account.description}, BSB: ${account.accountNumber.slice(
                0,
                6
            )}, Account Number: ${account.accountNumber.slice(6)}`
            break
        }
        case "SWIFT": {
            bankString = `Account Number: ${account.accountNumber} (${account.type})`
            break
        }
        case "IBAN": {
            bankString = `Account Number: ${account.accountNumber} (${account.type})`
            break
        }
        default: {
            bankString = ""
        }
    }
    return bankString
}

export const parseAccountNumber = (account: Object) => {
    let bankString = ""
    switch (account.account.type) {
        case "BANK_ACCOUNT_AU_NZ": {
            bankString = `BSB: ${account.account.accountNumber.slice(0, 6)}, Acc: ${account.account.accountNumber.slice(
                6
            )}`
            break
        }
        case "SWIFT": {
            bankString = `Account Number: ${account.account.accountNumber} (${account.account.type})`
            break
        }
        case "IBAN": {
            bankString = `Account Number: ${account.account.accountNumber} (${account.account.type})`
            break
        }
        default: {
            bankString = ""
        }
    }
    return bankString
}
