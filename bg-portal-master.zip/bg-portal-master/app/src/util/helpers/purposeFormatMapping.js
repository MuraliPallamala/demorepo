// @flow
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import { dateToShortString } from "~/util/helpers/text"

type PurposeFormatMappingTypes = {
    purposeType: string,
    purposeTemplates: Templates,
    purpose: Object
}

const purposeFormatMapping = ({ purposeType, purposeTemplates, purpose }: PurposeFormatMappingTypes) => {
    const purposeArray = []
    if (purpose == null) {
        return purposeArray
    }
    const selectedTemplate = purposeTemplates.find(template => template.id === purposeType)
    if (selectedTemplate) {
        selectedTemplate.fields.forEach(field => {
            if (field.subFields && field.subFields.length >= 1) {
                field.subFields.forEach(subField => {
                    if (purpose[field.name] && purpose[field.name][subField.name] !== undefined) {
                        addFieldToPurposeArray(
                            purposeArray,
                            purpose[field.name][subField.name].type,
                            subField.appearance.label,
                            purpose[field.name][subField.name]
                        )
                    }
                })
            } else if (purpose[field.name] != null) {
                addFieldToPurposeArray(purposeArray, field.type, field.appearance.label, purpose[field.name])
            }
        })
    }
    return purposeArray
}

const addFieldToPurposeArray = (arr, fieldType, fieldKey, fieldValue) => {
    if (fieldType === "DATE") {
        arr.push({
            key: fieldKey,
            value: fieldValue === "" ? "N/A" : dateToShortString(fieldValue)
        })
    } else if (fieldType === "BOOLEAN") {
        arr.push({
            key: fieldKey,
            value: fieldValue ? "Yes" : "No"
        })
    } else {
        arr.push({
            key: fieldKey,
            value: fieldValue === "" ? "N/A" : fieldValue
        })
    }
}

export default purposeFormatMapping
