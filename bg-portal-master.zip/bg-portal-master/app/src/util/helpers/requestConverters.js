// @flow
import * as React from "react"
import TimeIcon from "@material-ui/icons/AccessTime"
import SettingsIcon from "@material-ui/icons/Settings"
import RemoveIcon from "@material-ui/icons/Clear"
import CancelledIcon from "@material-ui/icons/Block"
import { css } from "emotion"

type TitleTextProps = {
    requestType: string,
    requestStatus: string,
    status: string
}

type IconConverterProps = {
    requestType: string,
    requestStatus: string,
    status: string,
    theme: Object
}

const getClasses = ({ theme }) => {
    const icon = css({
        color: theme.typography.timelineIcon.color,
        marginTop: "8px",
        height: "26px",
        width: "26px"
    })
    return { icon }
}

export const OrgRequestConverter = ({ requestType, requestStatus, status }: TitleTextProps) => {
    if (requestType === "CHANGE_DETAILS" && status === "CONFIRMED") {
        return "Organisation Change Request Pending"
    }
    if (requestType === "CHANGE_DETAILS" && status === "ABANDONED") {
        return "Organisation Change Request Cancelled"
    }
    if (requestType === "CHANGE_DETAILS" && status === "APPROVED") {
        return "Organisation Change Request Approved"
    }
    if (requestType === "CHANGE_DETAILS" && status === "REJECTED") {
        return "Organisation Change Request Rejected"
    }
    if (requestType === "LINK_ORGANIZATION" && status === "CONFIRMED") {
        return "Parent & Subsidiary Relationship Initiated"
    }
    if (requestType === "UNLINK_ORGANIZATION" && status === "APPROVED") {
        return "Parent & Subsidiary Relationship Unlink Successful"
    }
    if (requestType === "UNLINK_ORGANIZATION" && status === "CONFIRMED") {
        return "Parent & Subsidiary Relationship Unlink Initiated"
    }
    if (requestType === "LINK_ORGANIZATION" && status === "ABANDONED") {
        return "Parent & Subsidiary Relationship Cancelled"
    }
    return "Unknown"
}

export const OrgRequestIconConverter = ({ requestType, requestStatus, status, theme }: IconConverterProps) => {
    const classes = getClasses({ theme })
    return (
        <React.Fragment>
            {(requestStatus === "LINK_PENDING" ||
                requestStatus === "UNLINK_PENDING" ||
                requestType === "CHANGE_DETAILS") && <TimeIcon className={classes.icon} />}
            {(requestStatus === "Test" || requestStatus === "Test3" || requestType === "Test") && (
                <SettingsIcon className={classes.icon} />
            )}
            {(requestStatus === "Test1" || requestStatus === "Test3" || requestType === "Test1") && (
                <RemoveIcon className={classes.icon} />
            )}
            {(requestStatus === "Test2" || requestStatus === "Test4" || requestType === "Test2") && (
                <CancelledIcon className={classes.icon} />
            )}
        </React.Fragment>
    )
}
