// @flow
import type { Templates, Template } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

type getCurrentTemplateTypes = {
    purposeTemplates: Templates,
    selectedTemplate: Template
}

const getCurrentTemplate = ({ purposeTemplates, selectedTemplate }: getCurrentTemplateTypes) => {
    const currentTemplate = purposeTemplates.find(template => template.id === selectedTemplate)

    return (currentTemplate && currentTemplate.fields) || []
}

export default getCurrentTemplate
