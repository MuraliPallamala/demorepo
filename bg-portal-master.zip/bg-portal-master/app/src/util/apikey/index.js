/* eslint-disable import/prefer-default-export */
// @flow

export const apiKeyDefaultValues = {
    description: ""
}
export const mapRequestData = (orgData: any) => {
    const {
        entityName,
        businessID,
        address: { streetAddress, addressCountry, addressRegion, addressLocality, postOfficeBoxNumber, postalCode }
    } = orgData

    const mappedOrgData = {
        entityName,
        businessID: businessID.split("_").pop(),
        streetAddress,
        addressCountry: {
            value: addressCountry,
            label: addressCountry
        },
        addressRegion: {
            value: addressRegion,
            label: addressRegion
        },
        addressLocality,
        postOfficeBoxNumber,
        postalCode
    }
    return mappedOrgData
}

export const mapValuesToRequest = ({
    entityName,
    streetAddress,
    addressLocality,
    addressRegion,
    postalCode,
    addressCountry,
    postOfficeBoxNumber
}: any) => {
    const submitValue = {
        entityName,
        address: {
            streetAddress,
            addressLocality,
            addressRegion: addressRegion.value,
            addressCountry: addressCountry.value,
            postalCode,
            postOfficeBoxNumber
        }
    }
    return submitValue
}
