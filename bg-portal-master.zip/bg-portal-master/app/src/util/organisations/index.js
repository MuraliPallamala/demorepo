/* eslint-disable import/prefer-default-export */
// @flow
import { firstLetter } from "~/util/helpers/text"

export const organisationsMap = (list: any) => {
    const formattedList = list.map(item => {
        const formattedItem = item
        formattedItem.status = firstLetter(formattedItem.status)

        if (formattedItem.entityType === "APPLICANT_OR_BENEFICIARY") {
            formattedItem.entityType = "Organisation"
        }
        formattedItem.entityType = firstLetter(formattedItem.entityType.split("_").join(" "))
        formattedItem.businessId = formattedItem.businessId.split("_").pop()
        return formattedItem
    })
    return formattedList
}
