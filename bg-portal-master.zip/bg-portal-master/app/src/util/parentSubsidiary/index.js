/* eslint-disable import/prefer-default-export */
// @flow
import { dateToShortString } from "~/util/helpers/text"

export const relationshipDefaults = {
    relationship: "",
    permission: "",
    organisation: null
}

export const Parent = "PARENT_OF"
export const Subsidiary = "SUBSIDIARY_OF"
export const relationshipTypes = [
    { value: Parent, label: "Parent", key: 2 },
    { value: Subsidiary, label: "Subsidiary", key: 0 }
]
export const permissionTypes = [
    { value: ["READ", "WRITE"], label: "View & Action Guarantees", key: 0 },
    { value: ["READ"], label: "Read Only Guarantees", key: 1 }
]
export const permissionTypesSubsidiary = [
    { value: ["READ", "WRITE"], label: "view & action my guarantees", key: 0 },
    { value: ["READ"], label: "only read my guarantees", key: 1 }
]

export const permissionTypesParent = [
    { value: ["READ", "WRITE"], label: "view & action their guarantees", key: 0 },
    { value: ["READ"], label: "only read their guarantees", key: 1 }
]
export const mapRelationships = (relationships: any) => {
    const mappedRelationship = relationships.map((user, i) => mapRelationship(user))
    return mappedRelationship
}

export const mapRelationship = (orgRelationship: any) => {
    const {
        relatedEntityName,
        id,
        createdAt,
        status,
        initiatorFlag,
        relationship,
        permission,
        requestId,
        organisation
    } = orgRelationship
    const formattedRelationship = {
        relatedEntityName: organisation ? organisation.label : relatedEntityName,
        organisation: id,
        displayRelationship: relationship === Parent ? "Parent" : "Subsidiary",
        relationship,
        isThe: "is the",
        of: "of",
        whichCan: "which can",
        id,
        addedOn: dateToShortString(createdAt),
        initiatorFlag,
        displayPermissions: permission.join(" and "),
        permission,
        status,
        myOrg: "",
        requestId
    }
    return formattedRelationship
}
