// @flow

export default function businessIDValidation(values: string) {
    // Removes spaces as textfield allows entering values, spaces also removed when sent to the api
    const number = values.replace(/[^0-9]/g, "")
    // If ABN
    // Weights and algorithm defined by ASIC https://asic.gov.au/for-business/registering-a-company/steps-to-register-a-company/australian-company-numbers/australian-company-number-digit-check/
    if (number.length === 11) {
        const weights = [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
        let sum = 0
        weights.forEach((weight, position) => {
            const digit = parseInt(number[position], 10) - (position ? 0 : 1)
            sum += weight * digit
        })
        return sum % 89 === 0
    }
    // If ACN
    if (number.length === 9) {
        const weights = [8, 7, 6, 5, 4, 3, 2, 1]
        let acnValue = 0
        weights.forEach((weight, position) => {
            const digit = parseInt(number[position], 10)
            acnValue += weight * digit
        })
        let finalValue = 10 - (acnValue % 10)
        if (finalValue === 10) {
            finalValue = 0
        }
        return finalValue === parseInt(number[number.length - 1], 10)
    }
    return false
}
