/* eslint import/prefer-default-export:0 */
import * as authAPI from "~/util/api/base/auth"

const tokenSetKey = "tokenSet"
const redirectURLKey = "redirectURL"
const actingOn = "actingOn"
const errorQueue = "errorQueue"
export const authStorage = {
    hasTokenSet: () => window.sessionStorage.getItem(tokenSetKey) != null,

    getTokenSet: () => JSON.parse(window.sessionStorage.getItem(tokenSetKey)),

    setTokenSet: tokenSet => {
        window.sessionStorage.setItem(tokenSetKey, JSON.stringify(tokenSet))
    },
    setRequestKey: redirectURL => {
        window.localStorage.setItem(redirectURLKey, redirectURL)
    },
    getRequestKey: () => window.localStorage.getItem(redirectURLKey),
    getActingOn: () => window.sessionStorage.getItem(actingOn),
    setActingOn: orgActingOn => window.sessionStorage.setItem(actingOn, orgActingOn),
    removeActingOn: () => {
        window.sessionStorage.removeItem(actingOn)
    },
    removeTokenSet: () => {
        window.sessionStorage.removeItem(tokenSetKey)
    },
    addLogToErrorQueue: error => {
        let currentErrorArray = authStorage.getErrorQueueLogs()
        if (currentErrorArray && currentErrorArray.length >= 50) {
            currentErrorArray.pop()
        }
        if (currentErrorArray) {
            currentErrorArray.unshift(error)
        } else {
            currentErrorArray = [error]
        }
        window.sessionStorage.setItem(errorQueue, JSON.stringify(currentErrorArray))
    },
    getErrorQueueLogs: () => JSON.parse(window.sessionStorage.getItem(errorQueue)),
    getFormattedErrorQueueLogs: () => {
        const errorStackLogs = authStorage.getErrorQueueLogs()
        let formattedString = ""
        if (errorStackLogs) {
            errorStackLogs.forEach(error => {
                formattedString += `Log: ${error} \n`
            })
        }

        return formattedString
    },
    refreshTokenSet: tokenSet =>
        authAPI
            .refreshTokenSet(tokenSet.refresh_token, tokenSet.requestKey)
            .then(({ data: newTokenSet }) => {
                window.sessionStorage.setItem(tokenSetKey, JSON.stringify(newTokenSet))
                return newTokenSet
            })
            .catch(error => {
                console.error("Failure to refresh token", error)
                logout()
            }),
    setGuaranteeTCIds: tcs => window.sessionStorage.setItem("GuaranteeTCs", JSON.stringify(tcs)),
    getGuaranteeTC: () => JSON.parse(window.sessionStorage.getItem("GuaranteeTCs"))
}

// Gives 2 minutes leeway
export const isTokenSetExpired = tokenSet => tokenSet.expires_at - 2 * 60000 < new Date().getTime()

export const authRedirect = (username, twoFactor) =>
    authAPI.getAuthRedirect(username, twoFactor).then(({ data: { redirectUri } }) => {
        window.location.href = redirectUri
    })

export const logout = (requestKey = "") => {
    authStorage.removeTokenSet()
    authStorage.removeActingOn()
    window.location.href = `/logout/${requestKey}`
}
