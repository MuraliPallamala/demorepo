// @flow

export type UserRole = "bank" | "beneficiary" | "applicant"

export type User = {
    id: string,
    name: string,
    gxLimit: number,
    role: UserRole,
    notifications: Array<Notification>
}

export type Notification = {
    gxId: string,
    requestIds: Array<string>
}

export type Bank = "ANZ" | "Westpac"

export type Currency = "AUD" | "NZD" | "USD"

export type RxType = "issue" | "demand" | "amend" | "cancel" | "expire"
export type RxStatus = "consentRequired" | "pending" | "approved" | "denied" | "cancelled"

export type StatusHistory = {
    status: RxStatus,
    timestamp: Date,
    actor: string,
    rationale: string,
    bank?: Bank,
    bankReference?: string
}

export type Rx = {
    id: string,
    type: RxType,
    gxBeforeApproval?: GxDetails,
    gxAfterApproval?: GxDetails,
    statusHistory: Array<StatusHistory>,
    currentStatus: StatusHistory,
    active: boolean
}

export type GxStatus = "notIssued" | "denied" | "active" | "cancelled" | "demanded" | "expired"
export type GxType = "rental" | "customs" | "electricity" | "performance"

export type GxMetadata = {
    id: string,
    status: GxStatus,
    requestHistory: Array<Rx>,
    activeRequest?: Rx
}

export type GxDetails = {
    bankReference: string,
    beneficiaryReference: string,
    type: GxType,
    applicant: string,
    beneficiary: string,
    bank?: Bank,
    purpose: string,
    currency: Currency,
    amount?: number,
    expiryDate?: Date,
    additionalConditions: string
}

export type Gx = GxMetadata & GxDetails

export type AmendChange = {
    key: $Keys<GxDetails>,
    bv: any, // don't think $PropertyType works for this yet...
    av: any
}

export type Workflow = {
    steps: Array<string>,
    currentStep: number,
    nextActor: UserRole,
    nextAction: Action,
    messages: { [UserRole]: string }
}
export type Action = {
    yesName: string,
    noName: string,
    yesForm: string, // consent to, not consent!
    yesStatus: RxStatus, // which status it enters after
    noStatus?: RxStatus,
    requiredField?: string, // any field which must be filled in first
    extraDetail?: string // any extra details to display
    // OPTIONAL CUSTOM TEXT FIELDS
}

export type NewRx = {
    type: RxType,
    rationale: string,
    gxAfterApproval?: GxDetails
}

// types used by BGStepperContainer and ButtonContainer

export type ButtonType = {
    text: string,
    color: string,
    onClick: Function,
    disabled: boolean
}

export type DropdownList = {
    selected: string,
    onChange: Function,
    items: Array<Object>
}

export type EditableText = {
    defaultText: string,
    text: string,
    onChange: Function
}
