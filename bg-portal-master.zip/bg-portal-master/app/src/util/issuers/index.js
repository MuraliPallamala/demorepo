/* eslint-disable import/prefer-default-export */
// @flow

export const mapIssuers = (issuers: any) => {
    const issuerMap = issuers.map(item => ({ value: item.id, label: item.entityName }))
    return issuerMap
}
