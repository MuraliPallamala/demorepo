export default imagePath => require(`../../public/${PORTAL_TYPE}/${PORTAL_ORG}/assets/` + imagePath) // eslint-disable-line
