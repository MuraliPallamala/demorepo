## Folder/file structure


- public
	- Assets for each portal type
- index.js
- login
	- login-form
	- title.js
- app
	- main-content
		- gx-detail-screen
			- actions
			- gx-details
			- current-request
				- breakdown at dev discretion
			- request-history
			- request-amend-dialog
			- request-confirmation-dialog (cancel, demand)
		- gx-list-screen
			- gx-filter
			- gx-list
				- breakdown at dev discretion
		- create-gx-screen
			- gx-search
		- OnboardContainer
			- OnboardContainer (Without header, stepper, T&C)
		- header
			- header-form
				- search-bar
				- other menu items
			- header title (Now used for titles of each page)

- OnboardingFlow
	- NewPasswordContainer
		- NewPasswordContainer
		- NewPasswordForm
	- OnboardDetails
		- OnboardDetailsContainer
	- T&CContainer
	- OnboardingFlowStepper
	- OnboardingFlowContainer
	- OnboardingFlowHeader
	- SelfOnboardingFlowContainer (Full flow of self onboarding)


- portalSpecificImport
	- Themes for each portal type


- shared-components
	- theme
	- forms
		- organisation forms
		- contact details forms


## Component Interfaces

Current user is a global

### search-bar

props:
	- searchHandler

### header

props:
	- searchHandler
	- logoutHandler
	- showNotificationsHandler
	- homeClickHandler
	- createNewGxHandler

### sidebar

props:
	- showReportHandler

### gx-detail-screen-container

props:
	- gx details

### gx-list-screen-container

props:
	- gx list results
	- selectGxHandler

### create-gx-screen-container

props:
	- NOTHING!
