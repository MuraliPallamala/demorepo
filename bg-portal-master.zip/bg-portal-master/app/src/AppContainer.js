// @flow

// Flow for lazy and suspense for some reason doesn't exist -.-, once fixed un-comment flowfixme
// $FlowFixMe
import React, { lazy, Suspense } from "react"
import { BrowserRouter as Router, Switch } from "react-router-dom"
import JssProvider from "react-jss/lib/JssProvider"
import { ThemeProvider as EmotionThemeProvider } from "emotion-theming"
import { create } from "jss"
import preset from "jss-preset-default"
import moment from "moment"
import MuiPickersUtilsProvider from "material-ui-pickers/MuiPickersUtilsProvider"
import MomentUtils from "@date-io/moment"
// $FlowFixMe createGenerateClassName is not in material-ui definitions yet
import { createGenerateClassName, MuiThemeProvider } from "@material-ui/core/styles"
import ErrorDialogProvider from "~/shared/Context/ErrorDialog/ErrorDialogProvider"
import * as MOCK_DATA from "~/util/mock-data"
// import type { User } from "~/util/flow_types"
import portal from "~/portalSpecificImport/normal"
import PrivateRoute from "~/shared/Router/PrivateRoute"
import LoggedOutRoute from "~/shared/Router/LoggedOutRoute"
import Loading from "~/shared/Loading"
import { Flex } from "~/shared/layout"

const LogoutView = lazy(() => import("~/shared/Logout/LogoutView"))
const LoginContainer = lazy(() => import("./LoginContainer/LoginContainer"))
const CallbackContainer = lazy(() => import("./CallbackContainer/CallbackContainer"))
const HomeContainer = lazy(() => import("./HomeContainer/HomeContainer"))
const SelfOnboardingContainer = lazy(() => import("./SelfOnboardingContainer/SelfOnboardingContainer"))
const PinReferredSelfOnboardingContainer = lazy(() =>
    import("./SelfOnboardingContainer/PinReferredSelfOnboardingContainer")
)
const PinUserOnboardingContainer = lazy(() => import("./UserOnboardingContainer/PinUserOnboardingContainer"))

// Applies different theme based on PORTAL_TYPE

const generateClassName = createGenerateClassName()
const jss = create(preset())
jss.options.insertionPoint = "insertion-point-jss"

let cachedUstring
let theme = {}

moment.locale("en-AU")

const AppContainer = () => {
    const ustring = MOCK_DATA.data.USER_1.id
    if (cachedUstring !== ustring) {
        const pageType = "TODO"
        theme = portal.generateTheme(pageType)
        cachedUstring = ustring
    } else {
        const pageType = "TODO"
        theme = portal.generateTheme(pageType)
    }

    // console.log("VERSION FOR TESTING: 0.0.9")

    return (
        <JssProvider jss={jss} generateClassName={generateClassName}>
            <MuiThemeProvider theme={theme}>
                <EmotionThemeProvider theme={theme}>
                    <MuiPickersUtilsProvider utils={MomentUtils} locale="en-AU" moment={moment}>
                        <ErrorDialogProvider>
                            <Router>
                                <Switch>
                                    <LoggedOutRoute path="/cb" render={WaitingComponent(CallbackContainer)} />
                                    <LoggedOutRoute
                                        exact
                                        path="/login/:requestKey?"
                                        render={WaitingComponent(LoginContainer)}
                                    />
                                    <LoggedOutRoute
                                        exact
                                        portalType="user"
                                        path="/register"
                                        render={WaitingComponent(SelfOnboardingContainer)}
                                    />
                                    <LoggedOutRoute
                                        exact
                                        path="/register/:requestKey"
                                        render={props =>
                                            props.match.params.requestKey.length === 4
                                                ? waitForChild(<PinReferredSelfOnboardingContainer {...props} />)
                                                : waitForChild(<PinUserOnboardingContainer {...props} />)
                                        }
                                    />
                                    <LoggedOutRoute
                                        exact
                                        portalType={["user", "issuer"]}
                                        path="/register/:requestKey/:userid"
                                        render={WaitingComponent(PinUserOnboardingContainer)}
                                    />
                                    <LoggedOutRoute
                                        exact
                                        path="/logout/:requestKey?"
                                        render={WaitingComponent(LogoutView)}
                                    />
                                    <PrivateRoute path="/" render={WaitingComponent(HomeContainer)} />
                                </Switch>
                            </Router>
                        </ErrorDialogProvider>
                    </MuiPickersUtilsProvider>
                </EmotionThemeProvider>
            </MuiThemeProvider>
        </JssProvider>
    )
}

function WaitingComponent(Component) {
    return props => (
        <Suspense
            fallback={
                <Flex justifyContent="center" alignItems="center">
                    <Loading show />
                </Flex>
            }
        >
            <Component {...props} />
        </Suspense>
    )
}

function waitForChild(children) {
    // const LazyFunction = () => renderFunction()
    return (
        <Suspense
            fallback={
                <Flex justifyContent="center" alignItems="center">
                    <Loading show />
                </Flex>
            }
        >
            {children}
        </Suspense>
    )
}

export default AppContainer
