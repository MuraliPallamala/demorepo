// @flow

import React from "react"

import FreshOnboardingForm from "~/shared/Forms/Onboarding/FreshOnboardingForm"
import PrefilledOnboardingForm from "~/shared/Forms/Onboarding/PrefilledOnboardingForm"
import ConfirmationPinStage from "~/shared/Onboarding/Flow/Stages/ConfirmationPinStage"
import TCStageContainer from "~/shared/Onboarding/Flow/Stages/TCStageContainer"

type Props = {
    referred: boolean,
    rejectTC: Function,
    stage: number,
    values: Object,
    onNext: Function,
    onPrev: Function,
    onSubmit: Function,
    exitToLogin: Function,
    pin: string,
    platformTC: ?Object,
    userTC: ?Object,
    emailsError: Function,
    submitting: boolean
}

const SelfOnboarding = ({
    referred,
    rejectTC,
    stage,
    values,
    onNext,
    onPrev,
    onSubmit,
    exitToLogin,
    pin,
    platformTC,
    userTC,
    emailsError,
    submitting
}: Props) =>
    [
        () => (
            <TCStageContainer
                title="Confirm Rejection"
                tc={userTC}
                onExit={rejectTC()}
                onNext={() => onNext()}
                submitting={submitting}
            />
        ),
        () => (
            <TCStageContainer
                title="Confirm Rejection"
                tc={platformTC}
                onExit={rejectTC()}
                onNext={() => onNext()}
                submitting={submitting}
            />
        ),
        () =>
            referred ? (
                <PrefilledOnboardingForm
                    emailsError={emailsError}
                    initialValues={values}
                    onCancel={rejectTC()}
                    onSubmit={onSubmit}
                />
            ) : (
                <FreshOnboardingForm emailsError={emailsError} onCancel={exitToLogin} onSubmit={onSubmit} />
            ),
        () => <ConfirmationPinStage pin={pin} referred={referred} />
    ][stage]()

export default SelfOnboarding
