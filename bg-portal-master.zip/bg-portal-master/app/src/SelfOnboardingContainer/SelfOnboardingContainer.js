// @flow

import * as React from "react"

import api from "~/util/api"
import { mapFormValuesAndTCsToRequest, onboardingDefaultValues } from "~/util/onboarding"
// import OnboardingHeader from "~/shared/Onboarding/OnboardingHeader"
import OnboardingHeader from "~/HomeContainer/HeaderContainer/HeaderContainer"
import OnboardingFlowStepper from "~/shared/Onboarding/Flow/OnboardingFlowStepper"
import { Block } from "~/shared/layout"
import withError from "~/shared/Context/ErrorDialog/withError"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"

import SelfOnboarding from "./SelfOnboarding"

type Props = {
    history: Object,
    initialValues?: Object,
    referred: boolean,
    requestKey: string,
    pin: string,
    match: Object,
    handleErrorOpen: Function
}

type State = {
    stage: number,
    values: Object,
    pin: string,
    platformTC: ?Object,
    userTC: ?Object,
    submitting: boolean
}

const onboardingFlows = ["Consent Form", "Platform User Terms", "Enter Details", "Receive your Confirmation PIN"]
const referredFlows = ["Consent Form", "Platform User Terms", "Verify Details", "Receive your Confirmation PIN"]

class SelfOnboardingContainer extends React.Component<Props, State> {
    static defaultProps = {
        initialValues: {},
        referred: false
    }

    constructor(props: Props) {
        super(props)
        this.state = {
            stage: 0,
            values: {
                ...onboardingDefaultValues,
                ...props.initialValues
            },
            pin: "0",
            platformTC: null,
            userTC: null,
            submitting: false
        }
    }

    componentDidMount() {
        Promise.all(
            ["PLATFORM", "USER"].map(tcType =>
                api.termsAndConditions.getTCsByType(tcType).then(data => {
                    const termsAndConditions = data.filter(
                        tc => tc.title.includes("Platform User Terms") || tc.title.includes("Consent Form")
                    )
                    if (termsAndConditions.length > 0) {
                        const tcRecord = termsAndConditions[0]
                        return api.termsAndConditions.getTCDocumentById(tcRecord.id, tcRecord.title)
                    }
                    throw new Error("Error: Unable to retrieve TC")
                })
            )
        )
            .then(([platformTC, userTC]) => {
                this.setState({
                    platformTC,
                    userTC
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting T&C Error`,
                    title: "Getting T&C Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
        window.addEventListener("beforeunload", this.onUnload)
    }
    componentWillUnmount() {
        window.removeEventListener("beforeunload", this.onUnload)
    }
    onUnload = event => {
        // the method that will be used for both add and remove event
        event.returnValue = "Data will be lost if you leave the page, are you sure?"
    }

    onPrev = () => {
        this.setState({
            stage: this.state.stage - 1
        })
    }

    onNext = (values?: Object = {}) => {
        this.setState({
            values: {
                ...this.state.values,
                ...values
            },
            stage: this.state.stage + 1
        })
    }

    submitSelfOnboardingRequest = (values: Object) => {
        const { requestKey, pin } = this.props
        const endpoint = this.props.referred
            ? api.onboarding.updateOnboardingRequest
            : api.onboarding.submitSelfOnboardingRequest
        const { platformTC, userTC } = this.state
        if (!platformTC || !userTC) {
            throw new Error("Error: Unable to retrieve TC")
        }
        // submitOnboardingRequest (^) will ignore requestKey and pin
        return endpoint(mapFormValuesAndTCsToRequest(values, platformTC.id, userTC.id), requestKey, pin)
            .then(({ data }) => {
                this.setState({
                    pin: data.token,
                    stage: this.state.stage + 1
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: this.props.referred
                        ? "Error Updating Onboarding Request"
                        : "Error Submitting Onboarding Request",
                    title: "Getting Onboarding Error",
                    error: err,
                    extraDetails: {
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    rejectTC = () => {
        const { referred, pin } = this.props
        const { requestKey } = this.props.match.params
        this.setState({
            submitting: true
        })

        if (referred) {
            api.onboarding
                .rejectReferralTC(requestKey, pin)
                .then(resp => this.exitToLogin())
                .catch(err => {
                    console.log(err)
                    this.setState({
                        submitting: false
                    })
                })
        } else {
            this.exitToLogin()
        }
    }

    exitToLogin = () => {
        const { history } = this.props
        history.push("/login")
    }

    render() {
        const { referred } = this.props
        const { stage, pin, values, platformTC, userTC, submitting } = this.state
        return (
            <React.Fragment>
                <LoadingDialog open={submitting} loading={submitting} title="Rejecting Terms and Conditions..." />
                <OnboardingHeader onboarding />
                <Block padding="3un">
                    <OnboardingFlowStepper labels={referred ? referredFlows : onboardingFlows} stage={stage} />
                    <SelfOnboarding
                        stage={stage}
                        onPrev={this.onPrev}
                        onNext={this.onNext}
                        rejectTC={() => this.rejectTC}
                        referred={referred}
                        exitToLogin={this.exitToLogin}
                        onSubmit={this.submitSelfOnboardingRequest}
                        pin={pin}
                        values={values}
                        platformTC={platformTC}
                        userTC={userTC}
                        submitting={submitting}
                        emailsError={this.props.handleErrorOpen}
                    />
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(SelfOnboardingContainer)
