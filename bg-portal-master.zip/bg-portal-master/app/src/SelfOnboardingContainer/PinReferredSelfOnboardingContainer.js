// @flow

import React from "react"

import api from "~/util/api"
import { mapRequestToFormValues } from "~/util/onboarding"
import EnterPin from "~/EnterPin/EnterPin"
import withError from "~/shared/Context/ErrorDialog/withError"
import SelfOnboardingContainer from "./SelfOnboardingContainer"

type Props = {
    match: Object,
    history: Object,
    handleErrorOpen: Function
}

type State = {
    initialValues: ?Object,
    pin: string
}

class PinReferredSelfOnboardingContainer extends React.Component<Props, State> {
    state = {
        initialValues: null,
        pin: "0"
    }

    getInitialValues = (pin: string) => {
        const { requestKey } = this.props.match.params
        return api.onboarding
            .getPrefilledOnboardingRequest(requestKey, pin)
            .then(({ data: onboardingRequest }) => {
                this.setState({
                    initialValues: mapRequestToFormValues(onboardingRequest),
                    pin
                })
            })
            .catch(error => {
                if (error.response && error.response.status !== 401) {
                    // Unknown error so opening error dialog
                    this.props.handleErrorOpen({
                        errorMessage: `Could not get onboarding request`,
                        title: "Get Onboarding Request Error",
                        error,
                        extraDetails: {
                            CurrentUrl: this.props.history.location.pathname,
                            Payload: this.props.match.params.requestID,
                            ErrorResponse: error
                        }
                    })
                }
                throw error
            })
    }

    render() {
        const { initialValues } = this.state
        return (
            <React.Fragment>
                {!initialValues ? (
                    <EnterPin
                        verify={this.getInitialValues}
                        title="Enter your Confirmation PIN"
                        message="Your referrer shared this PIN with you"
                    />
                ) : (
                    <SelfOnboardingContainer
                        referred
                        initialValues={initialValues}
                        history={this.props.history}
                        requestKey={this.props.match.params.requestKey}
                        pin={this.state.pin}
                        match={this.props.match}
                        handleErrorOpen={this.props.handleErrorOpen}
                    />
                )}
            </React.Fragment>
        )
    }
}

export default withError(PinReferredSelfOnboardingContainer)
