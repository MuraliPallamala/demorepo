// @flow

import React from "react"
import Typography from "@material-ui/core/Typography"
import api from "~/util/api"
import { authStorage } from "~/util/auth"
import queryString from "query-string"
import withError from "~/shared/Context/ErrorDialog/withError"
import LoginView from "~/shared/Login/LoginView"
import Loading from "~/shared/Loading"

type Props = {
    history: Object,
    handleErrorOpen: Function
}
type State = {
    errorOpen: boolean,
    errorMessage: string
}

class CallbackContainer extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)

        /** checks if there is a URL to redirect to, else defaults to root.
         * @see LandingPage */
        const redirectUrl = window.sessionStorage.getItem("redirectUrl")
            ? window.sessionStorage.getItem("redirectUrl")
            : "/"
        window.sessionStorage.removeItem("redirectUrl")

        const hrefArray = window.location.pathname.split("/cb/")
        const requestKey = hrefArray.length === 2 ? hrefArray[1] : null
        const queryParams = queryString.parse(window.location.search)
        api.auth
            .getTokenSet(queryParams, requestKey)
            .then(({ data: tokenSet }) => {
                authStorage.setTokenSet(tokenSet)
                authStorage.setRequestKey(requestKey)
                props.history.push(redirectUrl)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Error getting tokenset`,
                    title: "TokenSet Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    render() {
        return (
            <LoginView>
                <Typography>Authenticating...</Typography>
                <Loading show />
            </LoginView>
        )
    }
}

export default withError(CallbackContainer)
