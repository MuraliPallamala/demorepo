// @flow

import * as React from "react"
import { css } from "emotion"
import ReactCodeInput from "react-code-input"
import { withTheme } from "@material-ui/core/styles"
import CircularProgress from "@material-ui/core/CircularProgress"
import Typography from "@material-ui/core/Typography"

import LoginView from "~/shared/Login/LoginView"
import { Flex } from "~/shared/layout"

type Props = {
    theme: Object,
    verify: (pin: string) => Promise<any>,
    title: string,
    message: string
}
type State = {
    isLoading: boolean,
    isValid: boolean,
    value: string
}

const getClasses = ({ theme }) => {
    const textField = css({
        width: 256,
        margin: "10px"
    })
    const register = css({
        textDecoration: "none"
    })
    const progress = css({
        margin: theme.spacing.unit * 2,
        color: theme.palette.common.lightBlue
    })
    const errorMessage = css({
        color: theme.palette.common.defaultRed
    })
    const pinTitle = css({
        color: theme.palette.common.lightBlue,
        fontSize: "1em",
        margin: theme.spacing.unit * 1,
        display: "inline"
    })
    const verifying = css(pinTitle, {
        fontSize: "18px"
    })
    const pin = css({
        padding: `${3 * theme.spacing.unit}px 0px 0px 0px`
    })
    const messageStyle = css({
        color: "#8B9CAF",
        fontStyle: "italic",
        fontSize: "14px",
        paddingTop: theme.spacing.unit
    })
    return {
        register,
        textField,
        progress,
        errorMessage,
        pinTitle,
        pin,
        messageStyle,
        verifying
    }
}

class EnterPin extends React.Component<Props, State> {
    static defaultProps = {
        title: "Enter your PIN",
        message: "Enter your PIN"
    }
    state = {
        isLoading: false,
        isValid: true,
        value: ""
    }

    checkPin = (value: string) => {
        this.setState({
            value,
            isValid: true
        })
        if (value.length === 4) {
            this.setState({ isLoading: true })

            // Assumes redirect on success so no need to set loading to true on success
            this.props.verify(value).catch(error => {
                this.setState({
                    isLoading: false,
                    isValid: false,
                    value: ""
                })
            })
        }
    }

    render() {
        const { theme, title, message } = this.props
        const { isLoading, isValid, value } = this.state
        const classes = getClasses({ theme })
        const reactCodeInputStyle = {
            fontFamily: "monospace",
            MozAppearance: "textfield",
            border: `1px solid ${theme.palette.common.darkBlue}`,
            boxShadow: "0px 0px 10px 0px rgba(0,0,0,.10)",
            margin: "4px",
            paddingLeft: "10px",
            width: "44px",
            height: "55px",
            fontSize: "40px",
            boxSizing: "border-box"
        }
        const reactCodeInputInvalidStyle = {
            ...reactCodeInputStyle,
            color: "#b94a48",
            backgroundColor: "#f2dede",
            borderColor: "#eed3d7"
        }

        return (
            <LoginView>
                <Flex justifyContent="center" alignItems="center">
                    <div>
                        {isLoading ? (
                            <div>
                                <Typography className={classes.verifying}>Verifying...</Typography>
                                <CircularProgress variant="indeterminate" className={classes.progress} size={31} />
                            </div>
                        ) : (
                            <Typography className={classes.pinTitle}>{isValid ? title : "Retry"}</Typography>
                        )}
                        <ReactCodeInput
                            className={classes.pin}
                            value={value} // NOTE this is currently not working due to https://github.com/40818419/react-code-input/issues/40
                            onChange={this.checkPin}
                            disabled={isLoading}
                            autoFocus
                            fields={4}
                            isValid={isValid}
                            type="password"
                            inputStyle={reactCodeInputStyle}
                            inputStyleInvalid={reactCodeInputInvalidStyle}
                        />
                        <Typography className={classes.errorMessage}>
                            {isValid ? "" : "The entered PIN is incorrect or no longer valid."}
                        </Typography>

                        <Typography className={classes.messageStyle}>{message}</Typography>
                    </div>
                </Flex>
            </LoginView>
        )
    }
}

export default withTheme()(EnterPin)
