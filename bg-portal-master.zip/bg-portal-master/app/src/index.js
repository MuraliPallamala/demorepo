// @flow

import React from "react"
import { render } from "react-dom"
import { BrowserRouter as Router } from "react-router-dom"
import CssBaseline from "@material-ui/core/CssBaseline"
// import "react-notifications-component/dist/theme.css"
import CardErrorBoundary from "~/shared/CardErrorBoundary"
import AppContainer from "./AppContainer"
import "./index.css"
import * as serviceWorker from "./serviceWorker"

import fingerprint from "./fingerprint.json"

// log the fingerprint
console.log("Fingerprint", fingerprint)

const root = document.getElementById("root")
if (!root) {
    throw new Error("Error could not find root element")
}

render(
    <Router>
        <CardErrorBoundary message="Something went wrong">
            <CssBaseline />
            <AppContainer />
        </CardErrorBoundary>
    </Router>,
    root
)

serviceWorker.unregister()
