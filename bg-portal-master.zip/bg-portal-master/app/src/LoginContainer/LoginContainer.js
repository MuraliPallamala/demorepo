// @flow

import * as React from "react"

import withError from "~/shared/Context/ErrorDialog/withError"
import LoginView from "~/shared/Login/LoginView"
import FIPRedirectContainer from "./FIPRedirectContainer/FIPRedirectContainer"
import LandingPage from "./LandingPage"

type Props = {
    history: Object,
    match: Object
}

type State = {}

class LoginContainer extends React.Component<Props, State> {
    componentDidMount() {
        /** saves the URL to redirect to after keycloak authentication in session storage.
        Known bug: if the user leaves this page before getting redirected, any post-authentication
        redirection in the same tab will take them to this saved URL, as it is only removed in
        CallbackContainer. Unlikely to be an issue.
        */
        let redirectUrl = ""
        try {
            redirectUrl = this.props.history.location.state.from.pathname
        } catch (err) {
            console.log(`LOOK HERE: ${err}`)
            redirectUrl = `LOOK HERE: ${err}`
        } finally {
            window.sessionStorage.setItem("redirectUrl", redirectUrl)
        }
    }
    static renderPage(requestKey?: string, history: Object) {
        if (PORTAL_TYPE !== "user" || requestKey) {
            return (
                <LoginView>
                    <FIPRedirectContainer requestKey={requestKey} />
                </LoginView>
            )
        }
        return (
            <LoginView>
                <LandingPage history={history} />
            </LoginView>
        )
    }

    render() {
        const { requestKey } = this.props.match.params
        return <React.Fragment>{LoginContainer.renderPage(requestKey, this.props.history)}</React.Fragment>
    }
}

export default withError(LoginContainer)
