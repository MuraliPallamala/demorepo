// @flow

import React from "react"
import Typography from "@material-ui/core/Typography"
import Loading from "~/shared/Loading"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"

type Props = {
    requestKey?: string,
    handleErrorOpen: Function
}
type State = {}

class FIPRedirectContainer extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)

        api.auth
            .getAuthRedirect(props.requestKey)
            .then(({ data: { redirectUri, ...test } }) => {
                if (redirectUri && redirectUri !== "undefined") {
                    window.location = redirectUri
                } else {
                    this.props.handleErrorOpen({
                        errorMessage: "redirectURI was not valid, check your key and try again",
                        title: "Redirect Key Error"
                    })
                }
            })
            .catch(error => {
                console.log("error", error)
                this.props.handleErrorOpen({
                    errorMessage: "There was an error redirecting",
                    alternateDetails: "Connection error",
                    title: "Redirect Error"
                })
            })
    }

    render() {
        return (
            <React.Fragment>
                <div>
                    <Typography>Redirecting..</Typography>
                    <Loading show />
                </div>
            </React.Fragment>
        )
    }
}

export default withError(FIPRedirectContainer)
