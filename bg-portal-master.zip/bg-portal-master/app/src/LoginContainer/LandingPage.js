// @flow

import * as React from "react"
import { css } from "emotion"
import { Link } from "react-router-dom"
import { withTheme } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import withError from "~/shared/Context/ErrorDialog/withError"
import EnterRedirectKey from "~/shared/EnterRedirectKey/EnterRedirectKey"
import api from "~/util/api"

type Props = {
    theme: Object,
    history: Object,
    handleErrorOpen: Function
}

type State = {}

const getClasses = ({ theme }) => {
    const logo = css({
        height: 44,
        margin: theme.spacing.unit * 2
    })
    const center = css({
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column"
    })

    const register = css({
        textDecoration: "none"
    })
    const textStyle = css({
        color: theme.palette.common.lightBlue,
        fontSize: "0.8em",
        margin: theme.spacing.unit * 1,
        display: "inline"
    })
    return {
        logo,
        textStyle,
        center,
        register
    }
}

class LandingPage extends React.Component<Props, State> {
    componentDidMount() {
        if (this.props.history.location.search === "?nokey") {
            this.props.handleErrorOpen({
                errorMessage: "No redirect key was found. Please use the URL given to you.",
                title: "No Key Error"
            })
        }
    }
    redirect = value =>
        api.auth
            .getAuthRedirect(value)
            .then(({ data: { redirectUri, ...test } }) => {
                if (redirectUri && redirectUri !== "undefined") {
                    window.location = redirectUri
                } else {
                    this.props.handleErrorOpen({
                        errorMessage: "Redirect key was not valid. Please check your key and try again.",
                        title: "Valid Key Error"
                    })
                    throw redirectUri
                }
            })
            .catch(error => {
                this.props.handleErrorOpen({
                    errorMessage: "There was an error redirecting",
                    title: "Redirect Error",
                    error
                })
                throw error
            })

    render() {
        const { theme } = this.props
        const classes = getClasses({ theme })
        return (
            <div className={classes.center}>
                <EnterRedirectKey verify={this.redirect} title="Enter your organisation PIN" />
                <Link to="/register" className={classes.register}>
                    <Typography className={classes.textStyle}>Don&#39;t have a PIN? Create an account</Typography>
                </Link>
            </div>
        )
    }
}
export default withError(withTheme()(LandingPage))
