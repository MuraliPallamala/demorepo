import React from "react"
import TextField from "@material-ui/core/TextField"
import PhoneNumberMask from "~/shared/PhoneNumberMask"
import { Col, WrappedRow } from "~/shared/layout"

const createFullName = (prefix, name) => (prefix ? `${prefix}${name.charAt(0).toUpperCase() + name.slice(1)}` : name)

const createFields = prefix => ({
    firstName: createFullName(prefix, "firstName"),
    lastName: createFullName(prefix, "lastName"),
    email: createFullName(prefix, "email"),
    phone: createFullName(prefix, "phone"),
    mobile: createFullName(prefix, "mobile")
})

export const createValidate = prefix => (values, referer) => {
    const { firstName, lastName, email, phone } = createFields(prefix)
    const errors = {}
    if (!values[email]) {
        errors[email] = "Required"
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values[email])) {
        errors[email] = "Invalid"
    }
    if (!values[phone] && !referer) {
        errors[phone] = "Required"
    } else if (values[phone] && !/\(?(^[1-9][0-9.+()-]{9,}$)/i.test(values[phone])) {
        errors[phone] = "Invalid"
    }
    if (!values[firstName]) {
        errors[firstName] = "Required"
    } else if (
        !/^[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]+$/u.test(
            values[firstName]
        )
    ) {
        errors[firstName] = "Invalid"
    }
    if (!values[lastName]) {
        errors[lastName] = "Required"
    } else if (
        !/^[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]+$/u.test(
            values[lastName]
        )
    ) {
        errors[lastName] = "Invalid"
    }
    return errors
}

const returnError = (regularError, matchError) => {
    if (matchError) {
        return matchError
    }
    return regularError
}

const Column = ({ ...props }) => <Col style={{ marginLeft: "16px" }} {...props} />

const createContactDetailsFieldSet = prefix => {
    const { firstName, lastName, email, phone } = createFields(prefix)
    return ({ formik, disabled, prefilled, primary, referer, ...otherProps }) => (
        <WrappedRow {...otherProps} flex={1}>
            <WrappedRow flex={1}>
                <Column minWidth="150px" flex={1}>
                    <TextField
                        disabled={disabled}
                        placeholder="First Name"
                        label={`First Name${primary || !referer ? "*" : ""}`}
                        name={firstName}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values[firstName]}
                        error={formik.touched[firstName] ? !!formik.errors[firstName] : false}
                        helperText={formik.errors[firstName] ? formik.errors[firstName] : " "}
                        inputProps={{ "data-cy": `${prefix}-firstName` }}
                        autoComplete="new-password"
                    />
                </Column>
                <Column minWidth="150px" flex={1}>
                    <TextField
                        disabled={disabled}
                        placeholder="Last Name"
                        label={`Last Name${primary || !referer ? "*" : ""}`}
                        name={lastName}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values[lastName]}
                        error={formik.touched[lastName] ? !!formik.errors[lastName] : false}
                        helperText={formik.errors[lastName] ? formik.errors[lastName] : " "}
                        autoComplete="new-password"
                        inputProps={{ "data-cy": `${prefix}-lastName` }}
                    />
                </Column>
            </WrappedRow>
            <WrappedRow flex={1}>
                <Column minWidth="150px" flex={1}>
                    <TextField
                        key={formik.finalFormText}
                        disabled={disabled || prefilled}
                        placeholder="Email"
                        label={`Email${primary || !referer ? "*" : ""}`}
                        name={email}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values[email]}
                        error={formik.touched[email] ? !!formik.errors[email] || !!formik.errors.emailMatch : false}
                        helperText={
                            formik.errors[email] || formik.errors.emailMatch
                                ? returnError(formik.errors[email], formik.errors.emailMatch)
                                : " "
                        }
                        autoComplete="new-password"
                        inputProps={{ "data-cy": `${prefix}-email` }}
                    />
                </Column>
                <Column minWidth="150px" flex={1}>
                    <TextField
                        disabled={disabled}
                        placeholder="Telephone"
                        label={`Telephone${primary || !referer ? "*" : ""}`}
                        name={phone}
                        onBlur={formik.handleBlur}
                        value={formik.values[phone]}
                        error={formik.touched[phone] ? !!formik.errors[phone] : false}
                        helperText={formik.errors[phone] ? formik.errors[phone] : " "}
                        InputProps={{
                            inputComponent: PhoneNumberMask,
                            inputProps: { "data-cy": `${prefix}-telephone` },
                            onChange: e => {
                                formik.setFieldValue(phone, e.target.value)
                            }
                        }}
                        autoComplete="new-password"
                    />
                </Column>
            </WrappedRow>
        </WrappedRow>
    )
}

export default createContactDetailsFieldSet
