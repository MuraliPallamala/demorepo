// @flow
/* eslint-disable import/prefer-default-export */
// const maintenance = "MAINTENANCE"
const BatchTaskComplete = "BATCH_TASK_COMPLETE"

// refereceType = "GX_REQUEST"
const GxPayWalk = "GX_PAYWALK"
const StartGxIssue = "START_GX_ISSUE"
const RejectGxIssue = "REJECT_GX_ISSUE"
const WithdrawGxIssue = "WITHDRAW_GX_ISSUE"
const ApproveGxIssue = "APPROVE_GX_ISSUE"
const StartGxTransfer = "START_GX_TRANSFER"
const ApproveGxTransfer = "APPROVE_GX_TRANSFER"
const RejectGxTransfer = "REJECT_GX_TRANSFER"
const StartGxDemand = "START_GX_DEMAND"
const ApproveGxDemand = "APPROVE_GX_DEMAND"
const DeferGxDemand = "DEFER_GX_DEMAND"
const StartGxCancel = "START_GX_CANCEL"
const ApproveGxCancel = "APPROVE_GX_CANCEL"
const RejectGxCancel = "REJECT_GX_CANCEL"
const ApproveGxAmend = "APPROVE_GX_AMEND"
const StartGxAmend = "START_GX_AMEND"
const WithdrawGxAmend = "WITHDRAW_GX_AMEND"
const CancelGxIssue = "CANCEL_GX_ISSUE"
const RevokeGxIssue = "REVOKE_GX_ISSUE"
const CancelGxTransfer = "CANCEL_GX_TRANSFER"
const RevokeGxTransfer = "REVOKE_GX_TRANSFER"
const CancelGxDemand = "CANCEL_GX_DEMAND"
const RevokeGxDemand = "REVOKE_GX_DEMAND"
const CancelGxCancel = "CANCEL_GX_CANCEL"
const RevokeGxCancel = "REVOKE_GX_CANCEL"
const RejectGxAmend = "REJECT_GX_AMEND"
const CancelGxAmend = "CANCEL_GX_AMEND"
const RevokeGuaranteeAmend = "REVOKE_GX_AMEND"
const GxExpire = "GX_EXPIRE"

// refereceType = "PREFILL_REQUEST"
const PrefillStartGxIssue = "PREFILL_START_GX_ISSUE"
const PrefillStartGxAmend = "PREFILL_START_GX_AMEND"
const PrefillStartGxCancel = "PREFILL_START_GX_CANCEL"

// refereceType = "ORG_LINK_REQUEST"
const LinkCreate = "LINK_CREATE"
const LinkRecject = "LINK_REJECT"
const LinkApprove = "LINK_APPROVE"
const LinkCancel = "LINK_CANCEL"
const LinkFinishApprovalRoles = "LINK_FINISH_APPROVAL_ROLES"
const UnlinkCreate = "UNLINK_CREATE"
const UnlinkApprove = "UNLINK_APPROVE"
const UnlinkReject = "UNLINK_REJECT"
const UnlinkCancel = "UNLINK_CANCEL"

// refereceType = "ORG_UPDATE_REQUEST"
const OrgDetailsUpdated = "ORG_DETAILS_UPDATED"
const OrgChangeApprove = "ORG_CHANGE_APPROVE"
const OrgChangeReject = "ORG_CHANGE_REJECT"
const OrgChangeSubmit = "ORG_CHANGE_SUBMIT"
const UpdateApprovalRoles = "UPDATE_APPROVAL_ROLES"

// refereceType = "ORG_ONBOARDING_REQUEST"
const OrgSetupIncomplete = "FRESH_ORG_ONBOARDED"
const OnboardingCreate = "ONBOARDING_CREATE"
const OnboardingConfirm = "ONBOARDING_CONFIRM"
const OnboardingApprove = "ONBOARDING_APPROVE"
const OnboardingReject = "ONBOARDING_REJECT"
const OnboardingVoid = "ONBOARDING_VOID"
const UserOnboardingComplete = "USER_ONBOARDING_COMPLETE"
const UserOnboardingReject = "USER_ONBOARDING_REJECT"
const AdminOnboardingReject = "PRIMARY_ADMIN_ROLE"

// const OrgOnboardingReference = "ORG_ONBOARDING_REQUEST"
// const OrgUpdateRequestReference = "ORG_UPDATE_REQUEST"
// const OrgLinkRequestReference = "ORG_LINK_REQUEST"
// const GxRequestReference = "GX_REQUEST"

const isOrgChangeSubmit = (type: string) => type === OrgChangeSubmit
const isGxExpire = (type: string) => type === GxExpire
const isLinkFinishApprovalRoles = (type: string) => type === LinkFinishApprovalRoles
const isOrgDetailsUpdated = (type: string) => type === OrgDetailsUpdated
const isUpdateApprovalRoles = (type: string) => type === UpdateApprovalRoles
const isRevokeGuaranteeAmend = (type: string) => type === RevokeGuaranteeAmend
const isOrgChangeApprove = (type: string) => type === OrgChangeApprove
const isCancelGxIssue = (type: string) => type === CancelGxIssue
const isCancelGxTransfer = (type: string) => type === CancelGxTransfer
const isRevokeGxIssue = (type: string) => type === RevokeGxIssue
const isRevokeGxTransfer = (type: string) => type === RevokeGxTransfer
const isCancelGxDemand = (type: string) => type === CancelGxDemand
const isRevokeGxDemand = (type: string) => type === RevokeGxDemand
const isRevokeGxCancel = (type: string) => type === RevokeGxCancel
const isRejectGxAmend = (type: string) => type === RejectGxAmend
const isCancelGxAmend = (type: string) => type === CancelGxAmend
const isOrgChangeReject = (type: string) => type === OrgChangeReject
const isCancelGxCancel = (type: string) => type === CancelGxCancel

const isPrefillStartGxIssue = (type: string) => type === PrefillStartGxIssue
const isPrefillStartGxCancel = (type: string) => type === PrefillStartGxCancel
const isPrefillStartGxAmend = (type: string) => type === PrefillStartGxAmend

const isLinkCreate = (type: string) => type === LinkCreate
const isLinkApprove = (type: string) => type === LinkApprove
const isLinkRecject = (type: string) => type === LinkRecject
const isLinkCancel = (type: string) => type === LinkCancel
const isUnlinkCreate = (type: string) => type === UnlinkCreate
const isUnlinkApprove = (type: string) => type === UnlinkApprove
const isUnlinkReject = (type: string) => type === UnlinkReject
const isUnlinkCancel = (type: string) => type === UnlinkCancel

const isOnboardingVoid = (type: string) => type === OnboardingVoid
const isBatchTaskComplete = (type: string) => type === BatchTaskComplete

const isOnboardingReject = (type: string) => type === OnboardingReject
const isUserOnboardingReject = (type: string) => type === UserOnboardingReject
const isAdminOnboardingReject = (type: string) => type === AdminOnboardingReject
const isOnboardingCreate = (type: string) => type === OnboardingCreate

const isUserOnboardingComplete = (type: string) => type === UserOnboardingComplete

const isStartGxIssue = (type: string) => type === StartGxIssue
const isRejectGxIssue = (type: string) => type === RejectGxIssue
const isGxPayWalk = (type: string) => type === GxPayWalk
const isApproveGxIssue = (type: string) => type === ApproveGxIssue
const isStartGxTransfer = (type: string) => type === StartGxTransfer
const isApproveGxTransfer = (type: string) => type === ApproveGxTransfer
const isRejectGxTransfer = (type: string) => type === RejectGxTransfer
const isStartGxDemand = (type: string) => type === StartGxDemand
const isApproveGxDemand = (type: string) => type === ApproveGxDemand
const isDeferGxDemand = (type: string) => type === DeferGxDemand
const isStartGxCancel = (type: string) => type === StartGxCancel
const isApproveGxCancel = (type: string) => type === ApproveGxCancel
const isOnboardingConfirm = (type: string) => type === OnboardingConfirm
const isRejectGxCancel = (type: string) => type === RejectGxCancel
const isApproveGxAmend = (type: string) => type === ApproveGxAmend
const isStartGxAmend = (type: string) => type === StartGxAmend
const isOnboardingApprove = (type: string) => type === OnboardingApprove

const isOrgSetupIncomplete = (type: string) => type === OrgSetupIncomplete

const isWithdrawGxIssue = (type: string) => type === WithdrawGxIssue
const isWithdrawGxAmend = (type: string) => type === WithdrawGxAmend

type Props = {
    notification: Object
}

export const NotificationToDisplayDataMap = ({ notification }: Props, currentOrgId: string) => {
    const { messageType, referenceId, payload, actionRequired } = notification
    let { message, secondMessage, extraText, url } = {
        message: "",
        extraText: "",
        url: "",
        secondMessage: ""
    }
    const subsidiaryEntityName = payload && payload.subsidiaryOrg ? payload.subsidiaryOrg.entityName : null
    const subsidiaryOrgId = payload && payload.subsidiaryId ? payload.subsidiaryId : null

    if (isOrgSetupIncomplete(messageType)) {
        message = "Organisation Setup Initiated"
        url = `settings/approvalflow`
        extraText = ""
        if (actionRequired) {
            message = "Admin to set up Approval Model and User Roles"
        }
    }
    if (isUpdateApprovalRoles(messageType)) {
        message = "Your Approval Model roles have been updated"
        url = `settings/usermanagement`
        extraText = ""
    }
    if (isGxExpire(messageType)) {
        message = "Guarantee Expired"
        url = `gx/details/${payload.gxId}`
    }
    if (isLinkFinishApprovalRoles(messageType)) {
        message = "Organisation Link Complete, Set up Approval Roles"
        extraText = ""
        url = `settings/usermanagement`
    }
    if (isOrgDetailsUpdated(messageType)) {
        message = "Organisation Details Updated"
        extraText = ""
        url = `organisations/${referenceId}`
    }

    if (isRevokeGuaranteeAmend(messageType)) {
        message = "Guarantee Amendment Revoked"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isOrgChangeApprove(messageType)) {
        message = "Organisation Change Request Approved"
        extraText = ""
        url = `settings/organisationdetails`
    }
    if (isOrgChangeSubmit(messageType)) {
        message = "Organisation Change Request Initiated"
        extraText = ""
        url = `settings/organisationdetails`

        if (actionRequired) {
            url = `organisations/${payload.organizationId}`
            extraText = ""
            message = "Organisation Change Request Requires Action"
        }
    }
    if (isOrgChangeReject(messageType)) {
        message = "Organisation Change Request Rejected"
        extraText = ""
        url = `settings/organisationdetails`
    }
    if (isCancelGxIssue(messageType)) {
        message = "Guarantee Issuance Cancelled"
        extraText = ""
        url = `gx/guarantee-requests/${referenceId}`
    }
    if (isCancelGxTransfer(messageType)) {
        message = "Guarantee Transfer Cancelled"
        extraText = ""
        if (payload.newBeneficiaryId === currentOrgId) {
            url = `gx/guarantee-requests/${referenceId}`
        } else {
            url = `gx/details/${payload.gxId}`
        }
    }
    if (isRevokeGxIssue(messageType)) {
        message = "Guarantee Issuance Revoked"
        extraText = ""
        url = `gx/guarantee-requests/${referenceId}`
    }
    if (isRevokeGxTransfer(messageType)) {
        message = "Guarantee Transfer Revoked"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isCancelGxDemand(messageType)) {
        message = "Guarantee Demand Cancelled"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isRevokeGxDemand(messageType)) {
        message = "Guarantee Demand Revoked"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isRevokeGxCancel(messageType)) {
        message = "Guarantee Cancellation Revoked"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isRejectGxAmend(messageType)) {
        message = "Guarantee Amendment Rejected"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isWithdrawGxAmend(messageType)) {
        message = "Guarantee Amendment Withdrawn"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isCancelGxAmend(messageType)) {
        message = "Guarantee Amendment Cancelled"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isCancelGxCancel(messageType)) {
        message = "Guarantee Cancellation Cancelled"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }

    if (isPrefillStartGxIssue(messageType)) {
        message = `Issuer Initiated Guarantee Issuance Request`
        extraText = ""
        // url = `gx/new/${referenceId}/prefill?prefillRequest=true`
        url = `gx/guarantee-requests/${referenceId}`
    }
    if (isPrefillStartGxCancel(messageType)) {
        message = `Issuer Initiated Guarantee Cancellation Request`
        extraText = ""
        url = `gx/details/${payload.gxId}?cancelNotification=true&masterFlowId=${
            payload.masterFlowId
        }&id=${referenceId}`
    }
    if (isPrefillStartGxAmend(messageType)) {
        message = `Issuer Initiated Guarantee Amendment Request`
        extraText = ""
        url = `gx/details/${payload.gxId}?amendNotification=true`
    }

    if (isOnboardingVoid(messageType)) {
        message = `Onboarding T&C rejected by the Organisation`
        extraText = ""
        // url = `onboardinglist/${referenceId}`
    }
    if (isOnboardingReject(messageType)) {
        message = `Organisation Onboarding Rejected`
        extraText = ""
        // url = `onboardinglist/${referenceId}`
    }
    if (isUserOnboardingReject(messageType)) {
        message = `Onboarding T&C rejected by the User`
        extraText = ""
        // url = `onboardinglist/${referenceId}`
    }
    if (isAdminOnboardingReject(messageType)) {
        message = `You have been assigned the Administrator role`
        extraText = "Administrator rejected T&Cs"
        // url = `onboardinglist/${referenceId}`
    }

    if (isBatchTaskComplete(messageType)) {
        message = `Batch Task Completed`
        extraText = ""
        url = `settings/organisationdetails`
    }
    if (isOnboardingCreate(messageType)) {
        message = `Onboarding Initiated`
        extraText = ""
        // url = `onboardinglist/${referenceId}`
        if (actionRequired) {
            message = `Onboarding Approval Required`
            extraText = ""
            url = `onboardinglist/${referenceId}`
        }
    }
    if (isOnboardingApprove(messageType)) {
        message = "Onboarding Approved"
        extraText = ""
        url = `onboardinglist/${referenceId}`
    }
    if (isUserOnboardingComplete(messageType)) {
        message = `User Onboarding Completed`
        extraText = ""
        url = `onboardinglist/${referenceId}`
    }
    if (isRejectGxIssue(messageType)) {
        message = "Guarantee Issuance Rejected"
        extraText = ""
        url = `gx/guarantee-requests/${referenceId}`
    }
    if (isWithdrawGxIssue(messageType)) {
        message = "Guarantee Issuance Withdrawn"
        extraText = ""
        if (payload.gxId) {
            url = `gx/details/${payload.gxId}`
        }
    }
    if (isStartGxIssue(messageType)) {
        message = "Guarantee Issuance Initiated"
        extraText = ""
        url = `gx/guarantee-requests/${referenceId}`
    }
    if (isStartGxTransfer(messageType)) {
        message = "Guarantee Transfer Initiated"
        extraText = ""
        if (payload.newBeneficiaryId === currentOrgId) {
            url = `gx/guarantee-requests/${referenceId}`
        } else {
            url = `gx/details/${payload.gxId}`
        }
    }
    if (isStartGxDemand(messageType)) {
        message = "Guarantee Demand Initiated"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isApproveGxDemand(messageType)) {
        message = "Guarantee Demand Approved"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isDeferGxDemand(messageType)) {
        message = "Guarantee Demand Deferred"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isStartGxCancel(messageType)) {
        message = "Guarantee Cancellation Initiated"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isApproveGxCancel(messageType)) {
        message = "Guarantee Cancellation Approved"
        extraText = ""
        url = `gx/details/${payload.gxId}`
        if (actionRequired) {
            message = "Guarantee Cancellation Requires Action"
        }
    }
    if (isOnboardingConfirm(messageType)) {
        message = "Onboarding Confirmed"
        extraText = ""
        url = `onboardinglist/${referenceId}`
        if (actionRequired) {
            message = "Onboarding Approval Required"
        }
    }
    if (isRejectGxCancel(messageType)) {
        message = "Guarantee Cancellation Rejected"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isRejectGxTransfer(messageType)) {
        message = "Guarantee Transfer Rejected"
        extraText = ""
        if (payload.newBeneficiaryId === currentOrgId) {
            url = `gx/guarantee-requests/${referenceId}`
        } else {
            url = `gx/details/${payload.gxId}`
        }
    }
    if (isGxPayWalk(messageType)) {
        message = "Guarantee Pay and Walk Completed"
        extraText = ""
        url = `gx/details/${payload.gxId}`
    }
    if (isApproveGxTransfer(messageType)) {
        message = "Guarantee Transfer Approved"
        extraText = ""
        if (actionRequired) {
            url = `gx/details/${payload.gxId}`
            message = "Guarantee Transfer Requires Approval"
        } else if (payload.oldBeneficiaryId === currentOrgId) {
            url = `gx/details/${payload.gxId}`
        } else {
            url = `gx/details/${payload.newGxId}`
        }
    }

    if (isApproveGxAmend(messageType)) {
        message = "Guarantee Amendment Approved"
        extraText = ""
        url = `gx/details/${payload.gxId}`
        if (actionRequired) {
            message = "Amendment Guarantee Request Initiated"
        }
    }
    if (isApproveGxIssue(messageType)) {
        message = "Guarantee Issuance Approved"
        extraText = ""
        if (actionRequired) {
            url = `gx/guarantee-requests/${referenceId}`
            message = "Guarantee Issuance Requires Approval"
        } else {
            url = `gx/details/${payload.gxId}`
        }
    }
    if (isStartGxAmend(messageType)) {
        extraText = ""
        message = "Guarantee Amendment Initiated"
        url = `gx/details/${payload.gxId}`
    }
    if (isLinkCreate(messageType)) {
        extraText = ""
        message = "Organisation Link Created"
        url = `settings/organisationdetails`
        if (actionRequired) {
            message = "Organisation Link Requested with your Organisation"
        }
    }
    if (isLinkApprove(messageType)) {
        extraText = ""
        message = "Organisation Link Approved"
        url = `settings/organisationdetails`
    }
    if (isLinkRecject(messageType)) {
        extraText = ""
        message = "Organisation Link Rejected"
        url = `settings/organisationdetails`
    }
    if (isLinkCancel(messageType)) {
        extraText = ""
        message = "Organisation Link Cancelled"
        url = `settings/organisationdetails`
    }
    if (isUnlinkCreate(messageType)) {
        extraText = ""
        message = "Organisation Unlink Initiated"
        url = `settings/organisationdetails`
    }
    if (isUnlinkApprove(messageType)) {
        extraText = ""
        message = "Organisation Unlink Approved"
        url = `settings/organisationdetails`
    }
    if (isUnlinkReject(messageType)) {
        extraText = ""
        message = "Organisation Unlink Rejected"
        url = `settings/organisationdetails`
    }
    if (isUnlinkCancel(messageType)) {
        extraText = ""
        message = "Organisation Unlink Cancelled"
        url = `settings/organisationdetails`
    }
    if (subsidiaryEntityName && subsidiaryOrgId !== currentOrgId) {
        secondMessage = `Subsidiary ${subsidiaryEntityName} Notification`
    }
    return { ...notification, message, extraText, url, subsidiaryOrgId, secondMessage }
}
