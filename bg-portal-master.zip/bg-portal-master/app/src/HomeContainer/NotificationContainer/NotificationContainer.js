// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import { withTheme } from "@material-ui/core/styles"
import Select from "@material-ui/core/Select"
import FormControl from "@material-ui/core/FormControl"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import Button from "@material-ui/core/Button"
import { css } from "emotion"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import api from "~/util/api"
import PageTitle from "~/shared/PageTitle"
import MyDatePicker from "~/shared/DatePicker/DatePicker"
import {
    Grid
    // Flex
} from "~/shared/layout"
import generateKey from "~/util/helpers/generateKey"
import NoResultsCard from "~/shared/BasicCards/NoResultsCard"
import NotificationCard from "./NotificationCards/NotificationCard"
import { NotificationToDisplayDataMap } from "./NotificationMap"

const getClasses = ({ theme }) => {
    const buttonStyle = css(theme.typography.button)
    const selectEmpty = css({
        // marginTop: theme.spacing.unit * 2
    })
    return {
        buttonStyle,
        selectEmpty
    }
}

type Props = {
    // match: Object,
    history: Object,
    needsAction: boolean,
    title: string,
    ariaLabel: string,
    theme: Object,
    notifications: Array<Object>,
    dismissNotification: Function,
    getNotifications: Function,
    notificationsLoading: boolean,
    getNotificationsWithCount: Function,
    currentOrgId: string,
    impersonnatingSub: boolean,
    updateCount: Function,
    user: Object
}

type State = {
    topic: string,
    startDate: any,
    status: string
}

const topicList = [
    { value: "", label: "All", portal: ["issuer", "user", "admin"] },
    { value: "ORG_ONBOARDING_REQUEST", label: "Onboarding Requests", portal: ["issuer", "user", "admin"] },
    { value: "ORG_UPDATE_REQUEST", label: "Update Requests", portal: ["issuer", "user", "admin"] },
    { value: "ORG_LINK_REQUEST", label: "Linking Requests", portal: ["user"] },
    { value: "GX_REQUEST", label: "Guarantee Requests", portal: ["issuer", "user"] },
    { value: "PREFILL_REQUEST", label: "Prefill Request", portal: ["issuer", "user"] }
]
const statusList = [
    { value: "", label: "All" },
    { value: "NEW", label: "New" },
    { value: "READ", label: "Viewed" },
    { value: "DISMISSED", label: "Dismissed" }
]
const needsActionStatusList = [
    { value: "", label: "All" },
    { value: "NEW", label: "New" },
    { value: "READ", label: "Viewed" },
    { value: "ACTIONED", label: "Actioned" }
]
class NotificationContainer extends React.Component<Props, State> {
    static defaultProps = {
        needsAction: false
    }
    constructor(props: Props) {
        super(props)
        this.state = {
            topic: "",
            startDate: null,
            status: props.needsAction ? "" : "NEW"
        }
    }

    componentDidMount() {
        this.props.getNotificationsWithCount()
    }
    componentDidUpdate(prevProps, prevState) {
        if (prevProps.needsAction !== this.props.needsAction) {
            this.setState({
                topic: "",
                startDate: null,
                status: this.props.needsAction ? "" : "NEW"
            })
            this.props.getNotificationsWithCount()
        }
        if (
            prevState.topic !== this.state.topic ||
            prevState.status !== this.state.status ||
            prevState.startDate !== this.state.startDate
        ) {
            const { topic, startDate, status } = this.state
            const statusValue = status !== "ACTIONED" ? status : ""
            const mappedValues = { topic, start: startDate, status: statusValue }
            // Filters out items that have a falsy value and then structures them to be a query string
            let queryString = Object.keys(mappedValues)
                .filter(key => mappedValues[key])
                .map(key => `${key}=${mappedValues[key]}`)
                .join("&")
            queryString = `?${queryString}`
            this.props.getNotifications(queryString, status === "ACTIONED")
        }
    }
    onRowSelection = async (value: Object) => {
        // The idea here is that when a user clicks on their subsidiaries notification it will automagically make them acting on behalf so they can view the information
        // On the reverse side will remove any acting on behalf when clicking on any other notification
        if (value.subsidiaryOrgId && value.subsidiaryOrgId !== this.props.currentOrgId) {
            await this.props.user.updateActingOrg({ value: value.subsidiaryOrgId })
        } else {
            await this.props.user.updateActingOrg({ value: null })
        }
        if (value.status === "READ" || value.status === "DISMISSED") {
            if (value.url) {
                this.props.history.push(value.url)
            }
        } else {
            api.notifications
                .changeNotificationStatus(value.id)
                .then(({ data }) => {
                    this.props.dismissNotification(value)
                    if (value.url) {
                        this.props.history.push(value.url)
                    }
                })
                .catch(err => console.log("err", err))
        }
    }

    setDates = (name, date: any) => {
        this.setState({ [name]: date })
    }

    dismissAll = () => this.props.notifications.map(notification => this.dismiss(notification))

    dismissNotification = (notification: Object) => api.notifications.dismissNotification(notification.id)

    dismiss = (notification: Object) => {
        this.dismissNotification(notification).then(() =>
            this.props.dismissNotification(notification, notification.status !== "READ")
        )
    }
    handleChange = event => {
        this.setState({ [event.target.name]: event.target.value })
    }
    returnList = () => {
        if (this.props.needsAction) {
            return needsActionStatusList
        }
        return statusList
    }

    renderCards = (filteredNotifications: Array<any>) => {
        if (filteredNotifications.length === 0) {
            return <NoResultsCard />
        }
        return (
            <React.Fragment>
                {filteredNotifications.map(notification => {
                    const notificationMap = NotificationToDisplayDataMap({ notification }, this.props.currentOrgId)

                    return (
                        <NotificationCard
                            notification={notificationMap}
                            key={generateKey(notification.id)}
                            needsAction={
                                this.props.needsAction ||
                                notification.status === "DISMISSED" ||
                                this.state.status === "DISMISSED"
                            }
                            dismiss={this.dismiss}
                            onSelection={() => this.onRowSelection(notificationMap)}
                        />
                    )
                })}
            </React.Fragment>
        )
    }

    render() {
        const { title, ariaLabel, theme, notifications, notificationsLoading, needsAction } = this.props
        const { topic, status } = this.state
        const classes = getClasses({ theme })

        return (
            <Grid gridGap="3un">
                <Card>
                    <PageTitle
                        title={
                            // $FlowFixMe
                            <span
                                // eslint-disable-next-line
                                tabIndex="0"
                                id="main-content"
                            >
                                {title}
                            </span>
                        }
                        aria-label={ariaLabel}
                    />
                    <CardContent>
                        <Grid gridGap="3un" gridTemplateColumns="30% 15% 30%">
                            <FormControl>
                                <InputLabel htmlFor="topic">Topics</InputLabel>

                                <Select
                                    value={topic}
                                    name="topic"
                                    id="topic"
                                    onChange={this.handleChange}
                                    inputProps={{
                                        name: "topic",
                                        id: "topic"
                                    }}
                                    className={classes.selectEmpty}
                                >
                                    {topicList
                                        .filter(t => t.portal.includes(PORTAL_TYPE))
                                        .map(aTopic => (
                                            <MenuItem key={generateKey(aTopic.value)} value={aTopic.value}>
                                                {aTopic.label}
                                            </MenuItem>
                                        ))}
                                </Select>
                            </FormControl>
                            <FormControl>
                                <InputLabel shrink htmlFor="status">
                                    Status
                                </InputLabel>

                                <Select
                                    value={status}
                                    name="status"
                                    id="status"
                                    displayEmpty
                                    onChange={this.handleChange}
                                    inputProps={{
                                        name: "status",
                                        id: "status"
                                    }}
                                    className={classes.selectEmpty}
                                >
                                    {this.returnList().map(aStatus => (
                                        <MenuItem key={generateKey(aStatus.value)} value={aStatus.value}>
                                            {aStatus.label}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                            <MyDatePicker
                                fieldName="startDate"
                                label="Since"
                                dateValue={this.state.startDate}
                                setDate={this.setDates}
                            />
                            {!needsAction && (
                                <Button
                                    className={classes.buttonStyle}
                                    onClick={this.dismissAll}
                                    style={{ gridColumn: "end-line" }}
                                >
                                    Dismiss All
                                </Button>
                            )}
                        </Grid>
                    </CardContent>
                </Card>

                {notificationsLoading ? <LoadingCard /> : this.renderCards(notifications)}
            </Grid>
        )
    }
}
export default withTheme()(NotificationContainer)
