// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import ArrowRight from "@material-ui/icons/KeyboardArrowRight"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import { Grid, Flex } from "~/shared/layout"
import { dateToString } from "~/util/helpers/text"
import numeral from "numeral"
import TimelineItemDetails from "~/shared/TimelineContainer/SharedComponents/TimelineItemDetails"
import ButtonField from "~/shared/Fields/ButtonField/ButtonField"

const getClasses = ({ theme }) => {
    const headerStyle = css({
        fontSize: "1em"
    })

    const buttonStyle = css(theme.typography.button, {
        alignSelf: "baseline",
        paddingTop: "0px"
    })

    const title = css({
        fontSize: theme.commonFontSizes.medium,
        color: `${theme.palette.common.darkBlue}!important`
    })

    const subtitle = css({
        fontSize: theme.commonFontSizes.medium,
        fontWeight: theme.commonFontWeights.light,
        color: `${theme.palette.common.darkBlue}!important`
    })

    const body1 = css(theme.typography.body1)
    const body2 = css(theme.typography.body2)
    // const subtitle = css(theme.typography.subtitle)

    const updatesCard = css({
        border: "2px solid",
        borderColor: "transparent",
        "&:hover": {
            borderColor: theme.palette.primary.headerBottom,
            backgroundColor: "#F4FEFD",
            cursor: "pointer"
        }
    })

    return {
        title,
        subtitle,
        headerStyle,
        buttonStyle,
        updatesCard,
        body1,
        body2
    }
}

type Props = {
    theme: Object,
    notification: Object,
    onSelection: Function,
    needsAction: boolean,
    dismiss: Function
}

const NotificationCard = ({ theme, notification, onSelection, needsAction, dismiss }: Props) => {
    const classes = getClasses({ theme })
    const {
        message,
        secondMessage,
        referenceType,
        payload,
        createdAt,
        messageType,
        user,
        extraText,
        actionDone,
        link
    } = notification

    return (
        <React.Fragment>
            <Grid gridGap="3un">
                <Card className={classes.updatesCard} onClick={onSelection}>
                    <CardContent>
                        <Flex>
                            <Flex flex="1">
                                <Flex flexDirection="column">
                                    {secondMessage ? (
                                        <Typography className={classes.title}>{secondMessage}</Typography>
                                    ) : null}
                                    <Typography className={classes.title}>
                                        {message} - {dateToString(createdAt)} {actionDone && "(ACTIONED)"}
                                    </Typography>
                                    {(referenceType === "GX_REQUEST" ||
                                        referenceType === "PREFILL_REQUEST" ||
                                        messageType === "GX_EXPIRE") && (
                                        <TimelineItemDetails
                                            title=""
                                            theme={theme}
                                            rows={[
                                                [
                                                    {
                                                        key: "Applicant",
                                                        value: payload ? payload.applicantEntityName : null
                                                    },
                                                    {
                                                        key: "Beneficiary",
                                                        value: payload ? payload.beneficiaryEntityName : null
                                                    },
                                                    {
                                                        key: "Current Beneficiary",
                                                        value: payload ? payload.oldBeneficiaryEntityName : null
                                                    },
                                                    {
                                                        key: "New Beneficiary",
                                                        value: payload ? payload.newBeneficiaryEntityName : null
                                                    },
                                                    {
                                                        key: "Issuer",
                                                        value: payload ? payload.issuerEntityName : null
                                                    },
                                                    {
                                                        key: "Value",
                                                        value: payload
                                                            ? `AUD ${numeral(payload.outstandingAmount / 100).format(
                                                                  "$0,0"
                                                              )}`
                                                            : null
                                                    }
                                                ],
                                                [
                                                    {
                                                        key: "Reason",
                                                        value: payload ? payload.reason : null
                                                    }
                                                ]
                                            ]}
                                        />
                                    )}
                                    {(referenceType === "ORG_ONBOARDING_REQUEST" ||
                                        referenceType === "ORG_UPDATE_REQUEST") &&
                                        messageType !== "PRIMARY_ADMIN_ROLE" &&
                                        payload && (
                                            <TimelineItemDetails
                                                title=""
                                                theme={theme}
                                                rows={[
                                                    [
                                                        {
                                                            key: "Organisation",
                                                            value: payload.org ? `${payload.org.entityName}` : undefined
                                                        },
                                                        {
                                                            key:
                                                                payload.org &&
                                                                payload.org.businessId &&
                                                                payload.org.businessId.length === 9
                                                                    ? "ACN"
                                                                    : "ABN",
                                                            value: payload.org ? `${payload.org.businessId}` : undefined
                                                        }
                                                    ],
                                                    [
                                                        {
                                                            key: "User",
                                                            value: user
                                                                ? `${user.firstName} ${user.lastName}`
                                                                : undefined
                                                        },
                                                        {
                                                            key: "Phone number",
                                                            value: user ? user.phone : undefined
                                                        },
                                                        {
                                                            key: "Email",
                                                            value: user ? user.email : undefined
                                                        }
                                                    ],
                                                    [
                                                        {
                                                            key: "Roles Added",
                                                            value:
                                                                payload.rolesAdded && payload.rolesAdded.length > 0
                                                                    ? payload.rolesAdded.join(", ")
                                                                    : undefined
                                                        }
                                                    ],
                                                    [
                                                        {
                                                            key: "Roles Removed",
                                                            value:
                                                                payload.rolesRemoved && payload.rolesRemoved.length > 0
                                                                    ? payload.rolesRemoved.join(", ")
                                                                    : undefined
                                                        }
                                                    ],
                                                    [
                                                        {
                                                            key: "Additional Information",
                                                            value: extraText || undefined
                                                        }
                                                    ]
                                                ]}
                                            />
                                        )}
                                    {referenceType === "ORG_ONBOARDING_REQUEST" &&
                                        messageType === "PRIMARY_ADMIN_ROLE" &&
                                        payload && (
                                            <TimelineItemDetails
                                                title=""
                                                theme={theme}
                                                rows={[[{ key: "Reason", value: extraText }]]}
                                            />
                                        )}
                                    {referenceType === "ORG_LINK_REQUEST" && payload && (
                                        <TimelineItemDetails
                                            title=""
                                            theme={theme}
                                            rows={[
                                                [
                                                    {
                                                        key:
                                                            payload.linkType && payload.linkType === "PARENT_OF"
                                                                ? "Subsidiary Organisation"
                                                                : "Parent Organisation",
                                                        value: payload.org ? `${payload.org.entityName}` : null
                                                    },
                                                    {
                                                        key:
                                                            payload.org && payload.org.businessId.length === 9
                                                                ? "ACN"
                                                                : "ABN",
                                                        value:
                                                            payload && payload.org ? `${payload.org.businessId}` : null
                                                    }
                                                ]
                                            ]}
                                        />
                                    )}
                                    {(messageType === "USER_ONBOARDING_REJECT" ||
                                        messageType === "USER_ONBOARDING_COMPLETE") &&
                                        payload && (
                                            <TimelineItemDetails
                                                title=""
                                                theme={theme}
                                                rows={[
                                                    [
                                                        {
                                                            key: "User",
                                                            value: payload.user
                                                                ? `${payload.user.firstName} ${payload.user.lastName}`
                                                                : undefined
                                                        },
                                                        {
                                                            key: "Phone number",
                                                            value: payload.user ? payload.user.phone : undefined
                                                        },
                                                        {
                                                            key: "Email",
                                                            value: payload.user ? payload.user.email : undefined
                                                        }
                                                    ]
                                                ]}
                                            />
                                        )}
                                </Flex>
                            </Flex>
                            {!needsAction && (
                                <ButtonField
                                    buttonText="Dismiss"
                                    submitFunction={dismiss}
                                    submitValues={notification}
                                />
                            )}
                            {link ? <ArrowRight /> : null}
                        </Flex>
                    </CardContent>
                </Card>
            </Grid>
        </React.Fragment>
    )
}

export default withTheme()(NotificationCard)
