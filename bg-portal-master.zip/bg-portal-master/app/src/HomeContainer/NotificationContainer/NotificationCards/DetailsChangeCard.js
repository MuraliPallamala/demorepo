// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import Button from "@material-ui/core/Button"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import { Grid, Flex } from "~/shared/layout"

const getClasses = ({ theme }) => {
    const headerStyle = css({
        fontSize: "1em"
    })

    const buttonStyle = css(theme.typography.button)
    const title = css({
        fontSize: "1.2em",
        color: `${theme.palette.common.darkBlue}!important`
    })
    const updatesCard = css({
        border: "2px solid",
        borderColor: "transparent",
        "&:hover": {
            borderColor: theme.palette.primary.headerBottom,
            backgroundColor: "#F4FEFD"
        }
    })

    return {
        title,
        headerStyle,
        buttonStyle,
        updatesCard
    }
}

type Props = {
    theme: Object,
    notification: Object,
    onSelection: Function
}

const DetailsChangeCard = ({ theme, notification, onSelection }: Props) => {
    const classes = getClasses({ theme })
    return (
        <React.Fragment>
            <Grid gridGap="3un">
                <Card className={classes.updatesCard} onClick={() => onSelection()}>
                    <CardContent>
                        <Flex>
                            <Flex flex="1">
                                <Typography className={classes.title}>
                                    {notification.type} {notification.status}
                                </Typography>
                            </Flex>
                            <Button
                                onClick={() => onSelection()}
                                className={classes.buttonStyle}
                                aria-label="Dismiss this notification"
                            >
                                Dismiss
                            </Button>
                        </Flex>
                    </CardContent>
                </Card>
            </Grid>
        </React.Fragment>
    )
}

export default withTheme()(DetailsChangeCard)
