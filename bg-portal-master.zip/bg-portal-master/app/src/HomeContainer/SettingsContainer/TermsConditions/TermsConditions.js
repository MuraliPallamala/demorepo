// @flow

import * as React from "react"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import PageTitle from "~/shared/PageTitle"
import CardContent from "@material-ui/core/CardContent"
import ReactMarkdown from "react-markdown"
import Paper from "@material-ui/core/Paper"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import { Flex, Block } from "~/shared/layout"
import { withTheme } from "@material-ui/core/styles"
import Divider from "@material-ui/core/Divider"
import print from "print-js"
import IconButton from "@material-ui/core/IconButton"
import DownloadIcon from "@material-ui/icons/GetApp"

const getClasses = theme => {
    const loadingContainer = css({
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "inherit"
    })

    const title = css({
        borderBottom: "solid 1px"
    })

    const linkStyle = css({
        textDecoration: "none"
    })
    const paperStyle = css({
        maxHeight: 500,
        overflow: "auto",
        boxShadow: "none"
    })
    const iconStyle = css({
        color: theme.palette.common.lightBlue,
        marginRight: theme.spacing.unit * 3
    })

    return {
        loadingContainer,
        title,
        paperStyle,
        linkStyle,
        iconStyle
    }
}
type Props = {
    theme: Object,
    title?: string,
    tcTextElem: React.Node,
    loading: boolean,
    type: string
}

class TermsConditions extends React.Component<Props> {
    static defaultProps = {
        title: "View Terms and Conditions"
    }

    ScrollTop = () => {
        window.scrollTo(0, 0)
    }

    render() {
        const { theme, title, tcTextElem, loading } = this.props
        const classes = getClasses(theme)

        return (
            <React.Fragment>
                <Flex>
                    <Flex flex={1}>
                        <PageTitle
                            path="Settings/"
                            title={
                                // $FlowFixMe
                                <React.Fragment>
                                    <span>{title}</span>
                                </React.Fragment>
                            }
                        />
                    </Flex>
                    <Flex>
                        <IconButton
                            className={classes.iconStyle}
                            onClick={e => {
                                e.preventDefault()
                                e.stopPropagation()
                                print({
                                    printable: "myDIV",
                                    type: "html"
                                })
                            }}
                        >
                            <DownloadIcon />
                        </IconButton>
                    </Flex>
                </Flex>

                <Block padding="3un">
                    {loading ? (
                        <LoadingCard />
                    ) : (
                        <Card>
                            <CardContent>
                                <Paper id="myDIV" className={classes.paperStyle}>
                                    <ReactMarkdown escapeHtml={false}>{tcTextElem}</ReactMarkdown>
                                </Paper>
                                <Divider />
                            </CardContent>
                        </Card>
                    )}
                </Block>
            </React.Fragment>
        )
    }
}

export default withTheme()(TermsConditions)
