// @flow

import * as React from "react"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import PageTitle from "~/shared/PageTitle"
import CardContent from "@material-ui/core/CardContent"
import Paper from "@material-ui/core/Paper"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import { Flex, Block } from "~/shared/layout"
import { withTheme } from "@material-ui/core/styles"
import Divider from "@material-ui/core/Divider"
import saveAs from "file-saver/src/FileSaver"
import IconButton from "@material-ui/core/IconButton"
import DownloadIcon from "@material-ui/icons/GetApp"
import PDF from "~/util/PDFViewer"

const getClasses = theme => {
    const loadingContainer = css({
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "inherit"
    })

    const title = css({
        borderBottom: "solid 1px"
    })

    const linkStyle = css({
        textDecoration: "none"
    })
    const paperStyle = css({
        overflow: "auto",
        boxShadow: "none"
    })
    const iconStyle = css({
        color: theme.palette.common.lightBlue,
        marginRight: theme.spacing.unit * 3
    })

    const buttonStyle = css({
        verticalAlign: "unset",
        paddingLeft: "24px",
        paddingRight: "24px"
    })

    const outerTCStyle = css({
        overflowY: "scroll",
        height: window.innerHeight * 0.6,
        padding: "0px"
    })

    const innerTCStyle = css({
        width: "90%",
        margin: "auto"
    })

    return {
        loadingContainer,
        title,
        paperStyle,
        linkStyle,
        iconStyle,
        buttonStyle,
        outerTCStyle,
        innerTCStyle
    }
}
type Props = {
    theme: Object,
    title?: string,
    loading: boolean,
    type?: string,
    data: Object,
    onboarding?: boolean,
    isTcRead?: Function
}
type State = {
    page: number,
    pages: number
}

class TermsConditionsPDF extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        this.state = {
            page: 1,
            pages: 1
        }
    }
    static defaultProps = {
        title: "View Terms and Conditions",
        type: "",
        onboarding: false
    }

    componentDidMount() {
        if (this.props.isTcRead) {
            this.props.isTcRead(false)
        }
        const element = document.getElementById("outerTC")
        if (element) {
            element.addEventListener("scroll", this.onScroll, false)
        }
    }

    componentWillUnmount() {
        const element = document.getElementById("outerTC")
        if (element) {
            element.removeEventListener("scroll", this.onScroll, false)
        }
    }

    onDocumentComplete = pages => {
        this.setState({ page: 1, pages })
        const element = document.getElementById("outerTC")
        if (element) {
            element.scrollTop = 0
        }
    }

    onScroll = () => {
        const el = document.getElementById("outerTC")
        if (this.props.isTcRead && el && el.offsetHeight + el.scrollTop + el.scrollHeight * 0.1 >= el.scrollHeight) {
            this.props.isTcRead(true)
        }
    }

    incrementPage = () => {
        const page = this.state.page + 1
        this.setState({ page })
    }

    decrementPage = () => {
        const page = this.state.page - 1
        this.setState({ page })
    }

    render() {
        const { theme, loading, title, data, onboarding } = this.props
        const { pages } = this.state
        const classes = getClasses(theme)
        const pageArray = []
        for (let i = 1; i <= pages; i++) {
            pageArray.push(
                <PDF page={i} file={data.url} onDocumentComplete={this.onDocumentComplete} customWidth="100%" />
            )
        }

        return (
            <React.Fragment>
                <Flex justifyContent={onboarding ? "flex-end" : "space-between"}>
                    {!onboarding && (
                        <Flex flex={1}>
                            <PageTitle
                                path="Settings/"
                                title={
                                    // $FlowFixMe
                                    <React.Fragment>
                                        <span>{title}</span>
                                    </React.Fragment>
                                }
                            />
                        </Flex>
                    )}
                    <Flex>
                        <IconButton
                            className={classes.iconStyle}
                            onClick={e => {
                                e.preventDefault()
                                e.stopPropagation()
                                saveAs(data.content, "Terms and Conditions.pdf")
                            }}
                        >
                            <DownloadIcon />
                        </IconButton>
                    </Flex>
                </Flex>

                <Block padding="3un">
                    {loading && <LoadingCard />}{" "}
                    {!onboarding && !loading && (
                        <Card>
                            <CardContent>
                                <div id="outerTC" className={classes.outerTCStyle}>
                                    <div className={classes.innerTCStyle}>
                                        <Paper id="myDIV" className={classes.paperStyle}>
                                            <div>{pageArray}</div>
                                        </Paper>
                                    </div>
                                </div>

                                <Divider />
                            </CardContent>
                        </Card>
                    )}
                    {onboarding && !loading && (
                        <React.Fragment>
                            <div id="outerTC" className={classes.outerTCStyle}>
                                <div className={classes.innerTCStyle}>
                                    <div>{pageArray}</div>
                                </div>
                            </div>
                            <Divider />
                        </React.Fragment>
                    )}
                </Block>
            </React.Fragment>
        )
    }
}

export default withTheme()(TermsConditionsPDF)
