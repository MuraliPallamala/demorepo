// @flow

import * as React from "react"
import marked from "marked"
import api from "~/util/api"

// import OnboardingHeader from "~/shared/Onboarding/OnboardingHeader"
import withError from "~/shared/Context/ErrorDialog/withError"
import TermsConditions from "./TermsConditions"
import TermsConditionsPDF from "./TermsConditionsPDF"

type Props = {
    history: Object,
    match: Object,
    type: string,
    title: string,
    handleErrorOpen: Function
}

type State = {
    termsAndConditions: Object,
    loading: boolean,
    dataType: string
}

class TermsConditionsContainer extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        this.state = {
            termsAndConditions: {},
            loading: true,
            dataType: ""
        }
    }

    componentDidMount() {
        this.getAndSetTC()
    }
    componentDidUpdate(prevProps) {
        if (prevProps.type !== this.props.type) {
            this.setState({ loading: true })
            this.getAndSetTC()
        }
    }
    getAndSetTC = async () => {
        let data
        try {
            const baseData = await api.termsAndConditions.getTCsByType(this.props.type)
            console.log(JSON.stringify(baseData))
            const termsAndConditions = baseData.filter(tc => tc.title.includes(this.props.title))
            if (termsAndConditions.length > 0) {
                const tcRecord = termsAndConditions[0]
                console.log(JSON.stringify(tcRecord))
                data = await api.termsAndConditions.getTCDocumentById(tcRecord.id, tcRecord.title)
                if (data.type === "pdf") {
                    this.setState({
                        termsAndConditions: data,
                        dataType: "pdf",
                        loading: false
                    })
                } else {
                    this.setState({
                        termsAndConditions: marked(data.content),
                        dataType: "markdown",
                        loading: false
                    })
                }
            } else {
                throw new Error("Error: could not retrieve T&Cs")
            }
        } catch (err) {
            this.props.handleErrorOpen({
                errorMessage: `Error downloading Terms and Conditions`,
                title: "Download T&C Error",
                error: err,
                extraDetails: {
                    Info: err.info,
                    CurrentUrl: this.props.history.location.pathname,
                    Payload: {},
                    ErrorResponse: err
                }
            })
            throw err
        }
    }

    render() {
        const { type, title } = this.props
        const { termsAndConditions, loading, dataType } = this.state
        return (
            <React.Fragment>
                {dataType === "markdown" && (
                    <TermsConditions tcTextElem={termsAndConditions} title={title} type={type} loading={loading} />
                )}
                {dataType === "pdf" && (
                    <TermsConditionsPDF type={type} title={title} loading={loading} data={termsAndConditions} />
                )}
            </React.Fragment>
        )
    }
}

export default withError(TermsConditionsContainer)
