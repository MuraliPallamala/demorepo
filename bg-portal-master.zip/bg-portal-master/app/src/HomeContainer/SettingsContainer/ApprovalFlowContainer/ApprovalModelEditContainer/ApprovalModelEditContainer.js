// @flow

import * as React from "react"
import api from "~/util/api"
import { dateToShortString } from "~/util/helpers/text"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import CardActions from "@material-ui/core/CardActions"
import { withTheme } from "@material-ui/core/styles"
import { Grid, Flex } from "~/shared/layout"
import { Link } from "react-router-dom"
import Button from "@material-ui/core/Button"
import numeral from "numeral"
import Typography from "@material-ui/core/Typography"
import { BG } from "~/util/CONSTANTS"
import withError from "~/shared/Context/ErrorDialog/withError"
import ApprovalDescriptionForm from "./ApprovalDescriptionForm"
import ApprovalModelButton from "../ApprovalModelButton"
// import RoleSettingTableForm from "./RoleSettingTableForm"
import RoleTableForm from "./RoleTableForm"

type Props = {
    history: Object,
    theme: Object,
    model: string,
    updateApprovalModel: Function,
    userHasWritePermission: boolean,
    cancelUpdate: Function,
    handleErrorOpen: Function,
    currentUserInformation: Object
}

type State = {
    orgDescription: Object,
    displayModel: string,
    // rolesSet: boolean,
    orgUsers: Array<Object>,
    loading: boolean,
    enoughUsers: boolean
}

const getClasses = ({ theme }) => {
    const formTitle = css(theme.typography.formTitle)
    const tableTitle = css(theme.typography.tableTitle)
    const button = css(theme.typography.button, { backgroundColor: theme.palette.common.white })
    const tableHeader = css(theme.typography.body1, { fontStyle: "italic", paddingLeft: "24px", paddingTop: "24px" })
    const tabActive = css(theme.tabActive)
    const tabInactive = css(theme.tabInactive)
    const linkMessage = css(theme.typography.linkMessage)
    const link = css(theme.typography.link, { p: { paddingLeft: "0.3rem", paddingRight: "0.3rem", display: "inline" } })
    const margin = css({
        height: "1.5rem"
    })
    const buttonContainer = css({
        justifyContent: "space-between",
        width: "100%"
    })

    return {
        formTitle,
        tableTitle,
        button,
        tabInactive,
        tabActive,
        margin,
        buttonContainer,
        tableHeader,
        link,
        linkMessage
    }
}

class ApprovalModelEditContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            orgDescription: {},
            displayModel: "unset",
            // rolesSet: false,
            orgUsers: [],
            loading: true,
            enoughUsers: false
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.model !== this.props.model) {
            this.getOrgDescription()
            this.setState({
                displayModel: nextProps.model
            })
            this.retrieveUsers(nextProps.model, nextProps.model)
        }
    }

    setRole = (id, role, source) => {
        let updatedUsers
        if (source === "checkbox") {
            updatedUsers = this.state.orgUsers.map(user => {
                if (user.id === id) {
                    const currentRoles = user.newRole
                    if (currentRoles.includes(role)) {
                        user.newRole = currentRoles.filter(r => r !== role)
                    } else {
                        user.newRole = currentRoles.concat(role)
                    }
                }
                return user
            })
        }
        this.setState({ orgUsers: updatedUsers })
        // this.rolesSet(updatedUsers) ? this.setState({ rolesSet: true }) : this.setState({ rolesSet: false })
    }

    getOrgDescription = () => {
        api.manageUsers
            .getAllUsers("")
            .then(res => {
                const numberInitiators = res.data.result.filter(d => d.roles.includes("PROPOSER")).length
                const numberApprovers = res.data.result.filter(d => d.roles.includes("APPROVER")).length
                const numberBusinessUsers = res.data.result.filter(d => d.roles.includes("USER")).length
                const numberUsers = res.data.result.length
                this.setState({
                    orgDescription: {
                        numberUsers,
                        numberInitiators,
                        numberApprovers,
                        numberBusinessUsers
                    }
                })
            })
            .catch(err => `failed to retrieve users (role=initiator): ${err}`)
    }

    getManageUsersUrl = () => `usermanagement`

    mapUsers = isParentUser => item => {
        const isAdmin = item.roles.includes("ADMIN")
        const isPrimary = item.roles.includes("PRIMARY")
        const currentRole = item.roles
        const currentRoleDisplay =
            item.roles.filter(r => r !== "USER" && r !== "ADMIN" && r !== "PRIMARY").length === 0
                ? "READ ONLY"
                : this.mapRoleDisplay(item.roles)
        let deletePossible
        const newRole = item.roles.filter(r => r !== "USER" && r !== "ADMIN" && r !== "PRIMARY")
        if (!isAdmin && !isPrimary && !isParentUser) {
            deletePossible = true
        } else {
            deletePossible = false
        }
        return {
            name: `${item.firstName} ${item.lastName}`,
            email: item.email,
            currentRole,
            currentRoleDisplay,
            newRole,
            threshold:
                item.gxLimit === BG.UNLIMITED_GX_LIMIT
                    ? "Unlimited"
                    : `AUD ${numeral(item.gxLimit / 100).format("0,0")}`,
            addedOn: dateToShortString(item.createdAt),
            isAdmin,
            isPrimary,
            delete: deletePossible,
            id: item.id,
            parentUser: isParentUser
        }
    }

    retrieveUsers = async (prevModel, newModel) => {
        this.setState({ loading: true })

        // get parent users if applicable
        const parent = this.props.currentUserInformation.relationships.filter(
            org => org.relationship === "SUBSIDIARY_OF"
        )
        let parentUsers = []
        if (parent[0]) {
            parentUsers = await api.manageUsers.getAllUsers(`?parentOrgId=${parent[0].id}`)
        }
        // eslint-disable-next-line
        const mappedParentRows = parentUsers.length === 0 ? [] : parentUsers.data.result.map(this.mapUsers(true))

        const myUsers = await api.manageUsers.getAllUsers("")

        const mappedMyRows = myUsers.data.result.map(this.mapUsers(false))

        // we want to show all users on the one table, so concat my orgs users with parent users
        const allUsers = mappedMyRows.concat(mappedParentRows)

        let enoughUsers
        // const nonAP = rows.filter(u => !u.isAdmin && !u.isPrimary).length
        if (newModel === "SOLE_APPROVER" && allUsers.length > 0) {
            enoughUsers = true
        } else if (newModel === "FOUR_EYE" && allUsers.length > 1) {
            enoughUsers = true
        } else enoughUsers = false

        this.setState({
            orgUsers: allUsers,
            loading: false,
            enoughUsers
        })
    }

    mapRoleDisplay = roles => {
        const displayRoles = roles.map(role => {
            let display
            switch (role) {
                case "APPROVER": {
                    display = "APPROVER"
                    break
                }
                case "PROPOSER": {
                    display = "PROPOSER"
                    break
                }
                case "MANAGER": {
                    display = "MANAGER"
                    break
                }
                default: {
                    display = ""
                }
            }
            return display
        })
        return displayRoles.filter(Boolean).join()
    }

    // rolesSet = updatedUsers => {
    //     const userUsers = updatedUsers.filter(
    //         user => !user.currentRole.includes("ADMIN") && !user.currentRole.includes("PRIMARY")
    //     )
    //     const adminUsers = updatedUsers.filter(user => user.currentRole.includes("ADMIN"))
    //     const primaryUsers = updatedUsers.filter(user => user.currentRole.includes("PRIMARY"))
    //     const initUsers = updatedUsers.filter(user => user.newRole.includes("INITIATOR"))
    //     const apprUsers = updatedUsers.filter(user => user.newRole.includes("APPROVER"))
    //     if (
    //         this.state.displayModel === "SOLE_APPROVER" &&
    //         // eslint-disable-next-line
    //         (userUsers.length > 0 || adminUsers.newRole === "INIT&APPRV" || primaryUsers.newRole === "INIT&APPRV")
    //     ) {
    //         return true
    //     } else if (
    //         this.state.displayModel === "FOUR_EYE" &&
    //         userUsers.filter(user => user.newRole === "").length === 0 &&
    //         apprUsers.length > 0 &&
    //         initUsers.length
    //     ) {
    //         return true
    //     }
    //     return false
    // }

    displayTwoEyeModel = () => {
        this.setState({ displayModel: "SOLE_APPROVER", loading: true })
        this.retrieveUsers(this.props.model, "SOLE_APPROVER")
    }

    displayFourEyeModel = () => {
        this.setState({ displayModel: "FOUR_EYE", loading: true })
        this.retrieveUsers(this.props.model, "FOUR_EYE")
    }

    deleteUser = (rowToDelete: number) => {
        const { id } = this.state.orgUsers[rowToDelete]
        api.manageUsers
            .deleteUser(id)
            .then(data => {
                this.getOrgDescription()
                this.retrieveUsers()
            })
            .catch(err => {
                console.log(err)
                this.props.handleErrorOpen(`Rejecting the relationship was unsuccessful: ${err.response.data.message}`)
            })
    }

    render() {
        const { displayModel, orgUsers, loading, orgDescription, enoughUsers } = this.state
        const { theme, model, history, userHasWritePermission, currentUserInformation } = this.props
        const classes = getClasses({ theme })
        let buttonText
        if (displayModel === model && model === "SOLE_APPROVER") {
            buttonText = "Update Sole Approver Approval Model"
        } else if (displayModel === model && model === "FOUR_EYE") {
            buttonText = "Update 4 EYE Approval Model"
        } else if (displayModel !== model && displayModel === "SOLE_APPROVER") {
            buttonText = "Set Approval Model as Sole Approver"
        } else if (displayModel !== model && displayModel === "FOUR_EYE") {
            buttonText = "Set Approval Model as 4 EYE"
        } else {
            buttonText = "Set Approval Model"
        }

        // get parent org id
        const parent = this.props.currentUserInformation.relationships.filter(
            org => org.relationship === "SUBSIDIARY_OF"
        )
        const parentId = parent.length > 0 ? parent[0].id : null

        return (
            <React.Fragment>
                <Grid gridGap="3un">
                    <Card>
                        <CardContent>
                            <Flex flexDirection="column">
                                <Typography className={classes.tableTitle}>
                                    The Approval Model Determines User Rights for Bank Guarantees Operations
                                </Typography>
                                <Typography className={classes.margin} />
                                <Typography className={classes.formTitle}>Compare Approval Models:</Typography>
                                <Flex flexDirection="row">
                                    <ApprovalModelButton
                                        model="SOLE_APPROVER"
                                        selected={displayModel === "SOLE_APPROVER"}
                                        onClick={() => this.displayTwoEyeModel()}
                                    />
                                    <ApprovalModelButton
                                        model="FOUR_EYE"
                                        selected={displayModel === "FOUR_EYE"}
                                        onClick={() => this.displayFourEyeModel()}
                                    />
                                </Flex>
                                <ApprovalDescriptionForm model={displayModel} />
                            </Flex>
                        </CardContent>
                    </Card>
                    <Card hidden={displayModel === "unset" || loading}>
                        <CardContent>
                            <Typography className={classes.formTitle} hidden={displayModel !== "SOLE_APPROVER"}>
                                <span hidden={enoughUsers}>
                                    The &#39;Bank Guarantee Manager&#39; role can be held by an Administrator, a Primary
                                    user, or a Business user
                                </span>
                            </Typography>
                            <Typography className={classes.formTitle} hidden={displayModel !== "SOLE_APPROVER"}>
                                <span hidden={!enoughUsers}>
                                    Your organisation currently has {orgDescription.numberUsers} active or pending
                                    users. In order for your organisation to be able to execute Bank Guarantee Lifecycle
                                    operations, you will need to assign at least one Bank Guarantee Manager. You can
                                    assign or change roles below before setting the Approval Model or under
                                    <Link className={classes.link} to="usermanagement">
                                        <Typography>User Management.</Typography>
                                    </Link>
                                </span>
                            </Typography>
                            <Typography className={classes.formTitle} hidden={displayModel !== "FOUR_EYE"}>
                                <span hidden={enoughUsers}>
                                    The &#39;Bank Guarantee Proposer&#39; and &#39;Bank Guarantee Approver&#39; roles
                                    can be held by Administrators, Primary users, or Business users.
                                </span>
                            </Typography>{" "}
                            <Typography className={classes.formTitle} hidden={displayModel !== "FOUR_EYE"}>
                                <span hidden={enoughUsers}>
                                    Currently, your company does not have enough users to support this Approval Model.
                                    You can add more users under
                                    <Link className={classes.link} to="usermanagement">
                                        <Typography>User Management.</Typography>
                                    </Link>
                                </span>
                            </Typography>
                            <Typography className={classes.formTitle} hidden={displayModel !== "FOUR_EYE"}>
                                <span hidden={!enoughUsers}>
                                    Your organisation currently has {orgDescription.numberUsers} active or pending
                                    users. In order for your organisation to be able to execute Bank Guarantee Lifecycle
                                    operations, you will need to assign at least one Bank Guarantee Proposer and one
                                    Bank Guarantee Approver. You can assign or change these roles below before setting
                                    the Approval Model or under
                                    <Link className={classes.link} to="usermanagement">
                                        <Typography>User Management.</Typography>
                                    </Link>
                                </span>
                            </Typography>
                            <Typography className={classes.tableHeader}>
                                {orgUsers.length === 1 ? `${orgUsers.length} Result` : `${orgUsers.length} Results`}
                            </Typography>
                            <RoleTableForm
                                version="users"
                                loading={loading}
                                orgUsers={orgUsers}
                                history={history}
                                theme={theme}
                                currentModel={model}
                                newModel={displayModel}
                                deleteRow={this.deleteUser}
                                setRole={this.setRole}
                            />
                        </CardContent>
                    </Card>
                    <Card>
                        <CardActions>
                            <Flex className={classes.buttonContainer}>
                                <Button onClick={this.props.cancelUpdate} className={classes.button}>
                                    CANCEL
                                </Button>
                                <Button
                                    onClick={() =>
                                        this.props.updateApprovalModel(
                                            displayModel,
                                            this.state.orgUsers,
                                            displayModel === model,
                                            currentUserInformation.update,
                                            parentId
                                        )
                                    }
                                    disabled={!userHasWritePermission || displayModel === "unset"}
                                    className={classes.button}
                                >
                                    {buttonText}
                                </Button>
                            </Flex>
                        </CardActions>
                    </Card>
                </Grid>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(ApprovalModelEditContainer))
