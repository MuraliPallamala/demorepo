// @flow

import * as React from "react"
import Paper from "@material-ui/core/Paper"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import Checkbox from "@material-ui/core/Checkbox"
import { Flex } from "~/shared/layout"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import { css } from "emotion"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import ActionButtons from "~/shared/TableComponent/Components/ActionButtons"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"

type Props = {
    // loading: boolean,
    orgUsers: Array<Object>,
    theme: Object,
    newModel: string,
    setRole: Function,
    deleteRow: Function
}

type State = {
    rows: Array<Object>,
    deleteDialogOpen: boolean,
    rowToDelete: number
}

const getClasses = ({ theme }) => {
    const tableRow = css({
        cursor: "pointer",
        textTransform: "none",
        "&:hover": {
            backgroundColor: theme.palette.common.buttonHover
        }
    })
    const backgroundRedCell = css({
        height: "47px",
        display: "flex",
        alignItems: "center",
        backgroundColor: theme.palette.common.highlightRed
    })
    const backgroundGreenCell = css({
        height: "47px",
        display: "flex",
        alignItems: "center",
        backgroundColor: theme.palette.common.highlightGreen
    })
    const buttonStyle = css(theme.typography.button)
    const body1 = css(theme.typography.body1)
    const body2 = css(theme.typography.body2)
    const adminLabel = css(theme.typography.body2, {
        padding: ".2rem",
        marginLeft: ".3rem",
        backgroundColor: "#E8F1F9",
        borderRadius: "4px"
    })
    const primaryLabel = css(adminLabel, { backgroundColor: "#F6EFFC" })

    const parentLabel = css(adminLabel, { backgroundColor: "#FEF9F4" })

    const cellPadding = css({ padding: "0px 10px" })
    const table = css({
        boxShadow: "none"
    })
    const deleteIcons = css({
        color: theme.palette.common.defaultRed
    })
    const editIcon = css({
        color: theme.palette.common.mainBlue
    })
    return {
        tableRow,
        table,
        buttonStyle,
        deleteIcons,
        editIcon,
        backgroundRedCell,
        backgroundGreenCell,
        cellPadding,
        body1,
        body2,
        adminLabel,
        primaryLabel,
        parentLabel
    }
}

const defaultSort = { dataName: "delete", order: "asc" }

class RowTableForm extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        this.state = {
            rowToDelete: -1,
            deleteDialogOpen: false,
            rows: []
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            rows: nextProps.orgUsers
        })
    }

    makeColumns = classes => [
        {
            columnHeader: { dataName: "name", displayName: "Name" },
            sort: true,
            cellValue: rowData => {
                if (rowData.isAdmin || rowData.isPrimary) {
                    return (
                        <div css={classes.cellPadding}>
                            <span> {rowData.name}</span>
                            <span className={classes.adminLabel} hidden={!rowData.isAdmin}>
                                ADMIN
                            </span>
                            <span className={classes.primaryLabel} hidden={!rowData.isPrimary}>
                                PRIMARY
                            </span>
                        </div>
                    )
                } else if (rowData.parentUser) {
                    return (
                        <div css={classes.cellPadding}>
                            <span> {rowData.name}</span>
                            <span className={classes.parentLabel}>PARENT</span>
                        </div>
                    )
                }
                return <div css={classes.cellPadding}>{rowData.name}</div>
            }
        },
        {
            columnHeader: { dataName: "email", displayName: "Email" },
            sort: true,
            cellValue: rowData => <div css={classes.cellPadding}>{rowData.email}</div>
        },
        {
            columnHeader: { dataName: "currentRoleDisplay", displayName: "Previous Role" },
            sort: true,
            hideTooltip: true,
            cellValue: rowData => (
                <div css={[classes.backgroundRedCell, classes.cellPadding]}>{rowData.currentRoleDisplay}</div>
            )
        },
        {
            columnHeader: { dataName: "newRole", displayName: "New Role" },
            sort: true,
            hideTooltip: true,
            colWidthProportion: 1.2,
            cellValue: rowData => {
                if (this.props.newModel === "FOUR_EYE") {
                    return (
                        <div css={[classes.backgroundGreenCell, classes.cellPadding]}>
                            <FormControlLabel
                                label="PROPOSER"
                                control={
                                    <Checkbox
                                        checked={rowData.newRole.includes("PROPOSER")}
                                        value="PROPOSER"
                                        onChange={event => this.roleChange(event, rowData, "checkbox")}
                                    />
                                }
                            />
                            <FormControlLabel
                                label="APPROVER"
                                control={
                                    <Checkbox
                                        checked={rowData.newRole.includes("APPROVER")}
                                        value="APPROVER"
                                        onChange={event => this.roleChange(event, rowData, "checkbox")}
                                    />
                                }
                            />
                            <span
                                css={{ fontStyle: "italic" }}
                                hidden={rowData.newRole.filter(r => r === "APPROVER" || r === "PROPOSER").length !== 0}
                            >
                                Read Only
                            </span>
                        </div>
                    )
                }
                // if not FOUR_EYE, then its SOLE_APPROVER
                return (
                    <div css={[classes.backgroundGreenCell, classes.cellPadding]}>
                        <FormControlLabel
                            label="MANAGER"
                            control={
                                <Checkbox
                                    checked={rowData.newRole.includes("MANAGER")}
                                    value="MANAGER"
                                    onChange={event => this.roleChange(event, rowData, "checkbox")}
                                />
                            }
                        />
                        <span
                            css={{ fontStyle: "italic" }}
                            hidden={rowData.newRole.filter(r => r === "MANAGER").length !== 0}
                        >
                            Read Only
                        </span>
                    </div>
                )
            }
        },
        {
            columnHeader: { dataName: "threshold", displayName: "Guarantee Limit" },
            sort: true,
            cellValue: rowData => <div css={classes.cellPadding}>{rowData.threshold}</div>
        },
        {
            columnHeader: { dataName: "addedOn", displayName: "Added on" },
            sort: true,
            colWidthProportion: 0.7,
            cellValue: rowData => <div css={classes.cellPadding}>{rowData.addedOn}</div>
        },
        {
            columnHeader: { dataName: "delete", displayName: "Actions" },
            hideTooltip: true,
            colWidthProportion: 0.5,
            sort: true,
            cellValue: rowData => {
                if (rowData.delete) {
                    return (
                        <ActionButtons
                            css={classes.cellPadding}
                            rowId={rowData.rowId}
                            changeEditingRowIds={() => this.openDeleteDialog(rowData.rowId)}
                            deleteRows={() => this.openDeleteDialog(rowData.rowId)}
                            openDialog={() => this.openDeleteDialog(rowData.rowId)}
                            disabled={false}
                            actionButtons={["delete"]}
                            otherAction={() => this.openDeleteDialog(rowData.rowId)}
                        />
                    )
                }
                return <div />
            }
        }
    ]

    openDeleteDialog = rowId => {
        this.setState({ deleteDialogOpen: true, rowToDelete: rowId })
    }

    deleteRows = () => {
        const rows = this.state.rows.slice()
        const index = this.state.rowToDelete
        this.props.deleteRow(index)
        this.setState({ rows, deleteDialogOpen: false })
    }

    closeDialog = () => {
        this.setState({ deleteDialogOpen: false })
    }

    roleChange = (event, row, source) => {
        this.props.setRole(row.id, event.target.value, source)
    }

    render() {
        const { rows } = this.state
        const { theme } = this.props
        const classes = getClasses({ theme })
        const columns = this.makeColumns(classes)
        return (
            <React.Fragment>
                <Paper className={classes.table}>
                    <Flex>
                        <Flex flex="1" />
                    </Flex>
                    <FlexAccordionTable
                        data={rows}
                        columns={columns}
                        className={css(
                            theme.typography.tableStyle,
                            {
                                ".table-row-item": { padding: "0px" }
                            },
                            `.table-header-row { div:nth-child(3) {
                                background-color: ${theme.palette.common.highlightRed};
                                height: 47px;
                             }
                             div:nth-child(4) {
                                 background-color: ${theme.palette.common.highlightGreen};
                                 height: 47px;
                             }
                             }`
                        )}
                        defaultSort={defaultSort}
                    />
                </Paper>
                <CustomRequestDialog
                    renderTitle={() => "Delete user"}
                    renderContent={() => <Typography>Are you sure that you want to delete this user?</Typography>}
                    onSubmit={() => this.deleteRows()}
                    handleClose={this.closeDialog}
                    open={this.state.deleteDialogOpen}
                    submitText="Yes"
                    cancelText="No"
                />
            </React.Fragment>
        )
    }
}

export default withTheme()(RowTableForm)
