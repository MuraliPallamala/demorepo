// @flow
import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Typography from "@material-ui/core/Typography"
import { Flex, Row, Col, CenteredCol } from "~/shared/layout"

import { AccountCircle, ArrowForward } from "@material-ui/icons"

const getClasses = ({ theme }) => {
    const body2 = css(theme.typography.body2)
    const lightbody2 = css(theme.typography.body2, { color: theme.palette.common.bgStatusGreen })
    const body1 = css(theme.typography.body1)
    const header = css(theme.typography.formTitle, { marginBottom: ".5em" })
    const darkFooter = css(theme.typography.body1, { justifySelf: "center" })
    const lightFooter = css(theme.typography.body1, {
        justifySelf: "center",
        color: theme.palette.common.bgStatusGreen
    })
    const greyFooter = css(theme.typography.body1, { justifySelf: "center", color: theme.palette.common.defaultGrey })
    const formTitle = css(theme.typography.formTitle)
    const darkIcon = css(theme.icon, {
        width: "48px",
        height: "48px"
    })
    const lightIcon = css(theme.icon, {
        fill: theme.palette.common.bgStatusGreen,
        width: "48px",
        height: "48px"
    })
    const greyIcon = css(theme.icon, { fill: theme.palette.common.defaultGrey })
    const link = css(theme.typography.link, { p: { paddingLeft: "0.5rem", display: "inline" } })

    const lightArrowIcon = css(theme.icon, {
        width: "36px",
        height: "36px",
        margin: "6px 12px",
        color: theme.palette.common.bgStatusGreen
    })
    const arrowIcon = css(theme.icon, {
        width: "36px",
        height: "36px",
        margin: "6px 12px"
    })
    const column = css({ width: "160px" })
    const margin = css({
        height: "1.5rem"
    })
    return {
        body2,
        body1,
        darkIcon,
        lightIcon,
        greyIcon,
        header,
        lightFooter,
        darkFooter,
        greyFooter,
        formTitle,
        arrowIcon,
        column,
        lightArrowIcon,
        link,
        lightbody2,
        margin
    }
}

type Props = {
    model: string,
    theme: Object
}

const Role = withTheme()(({ theme, text }: { theme: Object, text: string }) => {
    const classes = getClasses({ theme })
    return <span className={classes.body2}>&nbsp;&#39;{text}&#39;</span>
})
// const Manager = () => <Role text="Bank Guarantee Manager" />
// const Proposer = () => <Role text="Bank Guarantee Proposer" />
// const Approver = () => <Role text="Bank Guarantee Approver" />
const Manager = () => <Role text="Manager" />
const Proposer = () => <Role text="Proposer" />
const Approver = () => <Role text="Approver" />
const Default = () => <Role text="read-only" />

type StepProps = {
    iconClassName: string,
    textClassName: string,
    theme: Object
}
const Step = withTheme()(({ iconClassName, textClassName, theme, ...props }: StepProps) => {
    // const { iconClassName, textClassName, theme, ...props } = props
    const classes = getClasses({ theme })
    return (
        <CenteredCol className={classes.column}>
            <AccountCircle className={iconClassName} />
            <Typography align="center" className={textClassName} {...props} />
        </CenteredCol>
    )
})

type TransitionProps = {
    className: string,
    theme: Object
}
const Transition = withTheme()(({ className, ...props }: TransitionProps) => (
    <CenteredCol>
        <ArrowForward className={className} {...props} />
    </CenteredCol>
))

const ApprovalDescriptionForm = ({ theme, model }: Props) => {
    const classes = getClasses({ theme })
    let content

    if (model === "SOLE_APPROVER") {
        content = (
            <Flex flexDirection="column">
                <Typography className={classes.body1}>
                    In the Sole Approver model, a business operation that results in a financial commitment is a
                    one-step process.
                </Typography>
                <Typography className={classes.body1}>
                    Thus, the Sole Approver model has one role: <Manager />.
                </Typography>
                <Typography className={classes.body1}>
                    Users who hold the role <Manager /> can manage requests on behalf of the organisation.
                </Typography>
                <Typography hidden className={classes.body1}>
                    Bank Guarantee Lifecycle: Issue, Amend, Cancel, Demand.
                </Typography>
                <Typography className={classes.body1}>
                    Users who do not hold the <Manager /> role will have <Default /> privileges for Bank Guarantee
                    operations.
                </Typography>
                <Typography className={classes.margin} />
                <Col>
                    <Typography className={classes.header}>Example:</Typography>
                    <Row>
                        <Step iconClassName={classes.darkIcon} textClassName={classes.darkFooter}>
                            Other company issues a Bank Guarantee Lifecycle request
                        </Step>
                        <Transition className={classes.arrowIcon} />
                        <Step iconClassName={classes.lightIcon} textClassName={classes.lightFooter}>
                            Carole, a <Manager />, approves the request
                        </Step>
                        <Transition className={classes.arrowIcon} />
                        <Step iconClassName={classes.darkIcon} textClassName={classes.darkFooter}>
                            Other company gets notified of approval
                        </Step>
                    </Row>
                </Col>
            </Flex>
        )
    } else if (model === "FOUR_EYE") {
        content = (
            <Flex flexDirection="column">
                <Typography className={classes.body1}>
                    In the 4 Eye model, any business operation that results in a financial commitment is a two-step
                    process.
                </Typography>
                <Typography className={classes.body1}>
                    Thus, the 4 Eye model has two roles role: <Proposer /> and <Approver />.
                </Typography>
                <Typography className={classes.body1}>
                    Users who hold the role <Proposer /> can review and reject Bank Guarantee requests made by another
                    organisation.
                </Typography>
                <Typography className={classes.body1}>
                    Users who hold the role <Approver /> can reject and approve requests previously reviewed within the
                    organisation.
                </Typography>
                <Typography className={classes.body1}>
                    Users with both the <Proposer /> and the <Approver /> roles can review and reject requests initiated
                    by other organisations, and approve or reject requests that have been reviewed by another user
                    within the organisation.
                </Typography>
                <Typography hidden className={classes.body1}>
                    Bank Guarantee Lifecycle: Issue, Amend, Cancel, Demand.
                </Typography>
                <Typography className={classes.body1}>
                    Users who do not hold the <Proposer /> or the <Approver /> role will have <Default /> privileges for
                    Bank Guarantee operations.
                </Typography>
                <Typography className={classes.margin} />
                <Col>
                    <Typography className={classes.header}>Example 1:</Typography>
                    <Row>
                        <Step iconClassName={classes.darkIcon} textClassName={classes.darkFooter}>
                            Other company issues a Bank Guarantee Lifecycle request.
                        </Step>
                        <Transition className={classes.arrowIcon} />
                        <Step iconClassName={classes.lightIcon} textClassName={classes.lightFooter}>
                            Bob, a <Proposer />, reviews the request.
                        </Step>
                        <Transition className={classes.lightArrowIcon} />
                        <Step iconClassName={classes.lightIcon} textClassName={classes.lightFooter}>
                            Alice, an <Approver />, approves the request.
                        </Step>
                        <Transition className={classes.arrowIcon} />
                        <Step iconClassName={classes.darkIcon} textClassName={classes.darkFooter}>
                            Other company gets notified of approval.
                        </Step>
                    </Row>
                </Col>
                <Typography className={classes.margin} />
                <Col>
                    <Typography className={classes.header}>Example 2:</Typography>
                    <Row>
                        <Step iconClassName={classes.darkIcon} textClassName={classes.darkFooter}>
                            Other company issues a Bank Guarantee Lifecycle request.
                        </Step>
                        <Transition className={classes.arrowIcon} />
                        <Step iconClassName={classes.lightIcon} textClassName={classes.lightFooter}>
                            Bob, a <Proposer />, rejects the request.
                        </Step>
                        <Transition className={classes.arrowIcon} />
                        <Step iconClassName={classes.darkIcon} textClassName={classes.darkFooter}>
                            Other company gets notified of rejection.
                        </Step>
                    </Row>
                </Col>
            </Flex>
        )
    } else {
        content = <React.Fragment />
    }

    return (
        <React.Fragment>
            <span style={{ padding: ".5rem" }} />
            {content}
        </React.Fragment>
    )
    // return content
}

export default withTheme()(ApprovalDescriptionForm)
