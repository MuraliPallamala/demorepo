// @flow

import * as React from "react"
import api from "~/util/api"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import { withTheme } from "@material-ui/core/styles"
import withError from "~/shared/Context/ErrorDialog/withError"
import DataCacheContext from "~/shared/Context/DataCache/DataCacheContext"

import { Grid, Block, Col, Row, ReversedRow } from "~/shared/layout"
import CardErrorBoundary from "~/shared/CardErrorBoundary"
import PageTitle from "~/shared/PageTitle"
import Loading from "~/shared/Loading"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import Button from "@material-ui/core/Button"
import { Link } from "react-router-dom"
import ApprovalModelEditContainer from "./ApprovalModelEditContainer/ApprovalModelEditContainer"
import ApprovalDescriptionForm from "./ApprovalModelEditContainer/ApprovalDescriptionForm"
import ApprovalModelButton from "./ApprovalModelButton"

type Props = {
    match: Object,
    history: Object,
    theme: Object,
    approvalModel: Object,
    handleErrorOpen: Function
}

type State = {
    model: string,
    edit: boolean,
    preferencesUpdated: boolean,
    userHasWritePermission: boolean,
    noChangingBecauseActiveRequests: boolean,
    loading: boolean
}

const getClasses = ({ theme }) => {
    const cardTitle = css(theme.typography.cardTitle)
    const formTitle = css(theme.typography.formTitle)
    const tableTitle = css(theme.typography.tableTitle)
    const footerText = css(theme.typography.footerText)
    const button = css(theme.typography.button)
    const buttonContainer = css({
        marginTop: theme.spacing.unit,
        marginBottom: theme.spacing.unit
    })
    const body1 = css(theme.typography.body1)
    const body2 = css(theme.typography.body2)
    const subheading = css(theme.typography.subheading)
    const confirmMessage = css(theme.typography.confirmMessage)
    const linkMessage = css(theme.typography.linkMessage)
    const link = css(theme.typography.link)
    const paddingRight = css({
        paddingRight: "24px"
    })
    const tabActive = css(theme.tabActive)
    const tabInactive = css(theme.tabInactive)
    const margin = css({
        height: "1.5rem"
    })

    return {
        formTitle,
        cardTitle,
        tableTitle,
        button,
        footerText,
        buttonContainer,
        body1,
        body2,
        subheading,
        confirmMessage,
        linkMessage,
        link,
        paddingRight,
        tabActive,
        tabInactive,
        margin
    }
}

class ApprovalFlowContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            model: "unset",
            edit: false,
            preferencesUpdated: false,
            userHasWritePermission: false,
            noChangingBecauseActiveRequests: true,
            loading: true
        }
    }

    componentDidMount() {
        this.getApprovalModel()
        this.getUserRights()
        this.decideIfEditable()
    }

    componentDidUpdate(prevProps) {
        if (
            (this.props.approvalModel && !prevProps.approvalModel) ||
            (this.props.approvalModel &&
                prevProps.approvalModel &&
                prevProps.approvalModel.name !== this.props.approvalModel.name) ||
            !prevProps
        ) {
            this.getApprovalModel()
            this.getUserRights()
            this.decideIfEditable()
        }
    }

    setEdit = () => {
        this.state.edit ? this.setState({ edit: false }) : this.setState({ edit: true })
        this.setState({ preferencesUpdated: false })
    }

    decideIfEditable = async () => {
        const openRequests = await api.guarantee.getRequests()
        const relevantRequests = openRequests.data.result.filter(request => request.status === "ACTIVE")
        if (this.props.approvalModel && this.props.approvalModel.name && relevantRequests.length > 0) {
            this.setState({ noChangingBecauseActiveRequests: true, loading: false })
            // this.setState({ noChangingBecauseActiveRequests: false, loading: false })
        } else {
            this.setState({ noChangingBecauseActiveRequests: false, loading: false })
        }
    }

    getApprovalModel = () => {
        if (this.props.approvalModel == null) {
            this.setState({
                model: "unset"
            })
            return
        }
        this.setState({
            model: this.props.approvalModel.name
        })
    }

    getUserRights = async () => {
        const user = await api.user.getUser()
        this.setState({
            userHasWritePermission: user.data.userRoles[Object.keys(user.data.userRoles)[0]].includes("ADMIN")
        })
    }

    getManageUsersUrl = () => `usermanagement`

    cancelUpdate = () => {
        this.setState({ edit: false })
        this.setState({ preferencesUpdated: false })
    }

    updateApprovalModel = async (newModel, updatedUsers, roleOnly, update, parentId) => {
        // if not just the role (also approval model) is being changed, need to update model first
        if (!roleOnly) {
            await api.manageOrgSettings.updateApprovalModel({ name: newModel })
        }
        // separate my users and parent users from updated users for the two ajax calls
        const myUsers = updatedUsers.filter(user => !user.parentUser)
        const parentUsers = updatedUsers.filter(user => user.parentUser)
        // build up users object for perform task payload
        const myUsersPayload = {}
        myUsers.forEach(u => {
            if (roleOnly) {
                myUsersPayload[u.id] = u.newRole
            } else {
                myUsersPayload[u.id] =
                    newModel === "SOLE_APPROVER"
                        ? u.newRole.filter(r => r === "MANAGER")
                        : u.newRole.filter(r => r === "APPROVER" || r === "PROPOSER")
            }
        })
        // if parent users are present, update theirs role too
        const parentUsersPayload = {}
        if (parentUsers.length > 0) {
            parentUsers.forEach(u => {
                if (roleOnly) {
                    parentUsersPayload[u.id] = u.newRole
                } else {
                    parentUsersPayload[u.id] =
                        newModel === "SOLE_APPROVER"
                            ? u.newRole.filter(r => r === "MANAGER")
                            : u.newRole.filter(r => r === "APPROVER" || r === "PROPOSER")
                }
            })
        }
        // perform ajax call to update my users and my parent users (if any)
        try {
            await api.manageOrgSettings.performTask({
                type: "UPDATE_USER_ROLES",
                async: false,
                payload: {
                    task: {
                        scope: {
                            role: "USER"
                        },
                        method: "REPLACE",
                        users: myUsersPayload
                    }
                }
            })
            if (parentUsers.length > 0) {
                await api.manageOrgSettings.performTask({
                    type: "UPDATE_USER_ROLES",
                    async: false,
                    payload: {
                        task: {
                            scope: {
                                role: "USER"
                            },
                            method: "REPLACE",
                            targetOrgId: parentId,
                            users: parentUsersPayload
                        }
                    }
                })
            }
        } catch (err) {
            this.props.handleErrorOpen({
                errorMessage: `Approval Model Error`,
                title: "Update Approval Model Error",
                error: err,
                extraDetails: {
                    Info: err.info,
                    CurrentUrl: this.props.history.location.pathname,
                    Payload: {},
                    ErrorResponse: err
                }
            })
            throw err
        }
        this.setState({
            // model: newModel,
            model: newModel,
            preferencesUpdated: true,
            edit: false
        })
        update()
    }

    render() {
        const { theme, history, match } = this.props
        const {
            edit,
            model,
            preferencesUpdated,
            userHasWritePermission,
            loading,
            noChangingBecauseActiveRequests
        } = this.state
        const classes = getClasses({ theme })

        return (
            <React.Fragment>
                <Grid>
                    <PageTitle path="Settings/" title="Approval Model" theme={theme} />
                    <Block hidden={edit} padding="3un">
                        <CardErrorBoundary message="Error loading approval model">
                            <Card>
                                <CardContent>
                                    <Grid
                                        gridGap="3un"
                                        css={`
                                            & > div:nth-child(2) {
                                                overflow-x: auto;
                                            }
                                        `}
                                    >
                                        <Col>
                                            <Row>
                                                <Row flex="1">
                                                    <Typography className={classes.tableTitle}>
                                                        The Approval Model Determines User Rights for Bank Guarantees
                                                        Operations
                                                    </Typography>
                                                </Row>
                                                <Button
                                                    disabled={!userHasWritePermission}
                                                    hidden={
                                                        !userHasWritePermission ||
                                                        noChangingBecauseActiveRequests ||
                                                        loading
                                                    }
                                                    className={classes.button}
                                                    onClick={() => this.setEdit()}
                                                >
                                                    Edit
                                                </Button>
                                            </Row>
                                            <Typography className={classes.margin} />
                                            <Typography
                                                hidden={!preferencesUpdated}
                                                className={classes.confirmMessage}
                                                style={{ marginLeft: 0 }}
                                            >
                                                Your preferences have been saved.
                                            </Typography>
                                            <Typography
                                                className={classes.body1}
                                                hidden={userHasWritePermission || loading}
                                            >
                                                <i>
                                                    Your user privileges do not allow you to change the approval model.
                                                </i>
                                            </Typography>
                                            <Typography
                                                className={classes.body1}
                                                hidden={
                                                    !noChangingBecauseActiveRequests ||
                                                    !userHasWritePermission ||
                                                    loading
                                                }
                                            >
                                                <i>
                                                    Approval model cannot be changed while there are open requests on a
                                                    Bank Guarantee. Please resolve all open requests.
                                                </i>
                                            </Typography>
                                            <Typography
                                                hidden={model === "unset" || loading}
                                                className={classes.formTitle}
                                            >
                                                Current Approval Model:
                                            </Typography>
                                            <Typography
                                                hidden={model !== "unset" || loading}
                                                className={classes.cardTitle}
                                            >
                                                <span> No approval model has been set.</span>
                                            </Typography>
                                            <Typography hidden={!loading} className={classes.cardTitle}>
                                                <Loading show />
                                            </Typography>
                                            <Row hidden={model === "unset" || loading} flexWrap="wrap">
                                                <ApprovalModelButton
                                                    disabled
                                                    model="SOLE_APPROVER"
                                                    selected={model === "SOLE_APPROVER"}
                                                />
                                                <ApprovalModelButton
                                                    disabled
                                                    model="FOUR_EYE"
                                                    selected={model === "FOUR_EYE"}
                                                />
                                            </Row>
                                            <ApprovalDescriptionForm model={model} />
                                            <ReversedRow>
                                                <Row className={classes.paddingRight}>
                                                    <Typography className={classes.linkMessage}>
                                                        To see and manage all users, go to:&nbsp;
                                                    </Typography>
                                                    <Link className={classes.link} to={this.getManageUsersUrl()}>
                                                        <Typography> User Management </Typography>
                                                    </Link>
                                                </Row>
                                            </ReversedRow>
                                        </Col>
                                    </Grid>
                                </CardContent>
                            </Card>
                        </CardErrorBoundary>
                    </Block>
                    <Block hidden={!edit} padding="3un">
                        <DataCacheContext.Consumer>
                            {currentUser => (
                                <ApprovalModelEditContainer
                                    updateApprovalModel={this.updateApprovalModel}
                                    cancelUpdate={this.cancelUpdate}
                                    model={model}
                                    history={history}
                                    match={match}
                                    currentUserInformation={currentUser}
                                    userHasWritePermission={userHasWritePermission}
                                    edit={edit}
                                />
                            )}
                        </DataCacheContext.Consumer>
                    </Block>
                </Grid>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(ApprovalFlowContainer))
