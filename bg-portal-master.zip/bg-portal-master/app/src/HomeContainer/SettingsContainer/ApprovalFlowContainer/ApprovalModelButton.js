// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"

type Props = {
    theme: Object,
    model: string,
    disabled?: boolean,
    selected: boolean,
    onClick?: () => void
}

const getClasses = ({ theme }) => {
    const tabActive = css(theme.tabActive)
    const tabInactive = css(theme.tabInactive)

    return {
        tabActive,
        tabInactive
    }
}

const buttonText = {
    SOLE_APPROVER: "Sole Approver - A single user can Manage Bank Guarantees",
    FOUR_EYE: "4 Eye Approval - One user Proposes and another user Approves"
}

const ApprovalModelButton = ({ theme, model, disabled, selected, onClick }: Props) => {
    const { tabActive, tabInactive } = getClasses({ theme })
    return (
        <Button disabled={disabled} className={selected ? tabActive : tabInactive} onClick={onClick}>
            {buttonText[model]}
        </Button>
    )
}

ApprovalModelButton.defaultProps = {
    disabled: false,
    onClick: () => {}
}

export default withTheme()(ApprovalModelButton)
