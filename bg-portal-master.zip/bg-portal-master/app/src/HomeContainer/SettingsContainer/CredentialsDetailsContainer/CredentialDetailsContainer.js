// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import { withTheme } from "@material-ui/core/styles"
import { Grid, Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import SetPasswordForm from "~/shared/Forms/SetPasswordForm"
import ProfileDetailsFormContainer from "~/shared/Forms/ProfileDetailsFormContainer/ProfileDetailsFormContainer"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import DataCacheContext from "~/shared/Context/DataCache/DataCacheContext"

type Props = {
    match: Object,
    history: Object,
    theme: Object,
    handleErrorOpen: Function
}

type State = {
    primaryInitialValues: Object,
    passwordEditDisabled: boolean,
    hideEdit: boolean,
    loading: boolean,
    pwUpdated: boolean
}

class CredentialDetailsContainer extends React.Component<Props, State> {
    static defaultProps = {
        initialValues: {}
    }
    constructor(props) {
        super(props)
        this.state = {
            pwUpdated: false,
            loading: true,
            passwordEditDisabled: true,
            hideEdit: true,
            primaryInitialValues: {
                primaryFirstName: "",
                primaryLastName: "",
                primaryEmail: "",
                primaryPhone: ""
            }
        }
    }

    componentDidMount() {
        api.user
            .getUser()
            .then(resp => {
                this.setState({
                    hideEdit:
                        resp.data.userRoles[Object.keys(resp.data.userRoles)[0]].includes("PRIMARY") ||
                        resp.data.userRoles[Object.keys(resp.data.userRoles)[0]].includes("ADMIN"),
                    primaryInitialValues: {
                        primaryFirstName: resp.data.firstName,
                        primaryLastName: resp.data.lastName,
                        primaryEmail: resp.data.email,
                        primaryPhone: resp.data.phone
                    }
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Get user error`,
                    title: "Error Getting User",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: this.props.match.params.requestID,
                        ErrorResponse: err
                    }
                })
                throw err
            })
            .then(() => this.setState({ loading: false }))
    }

    edit = () => {
        // this.setState({passwordEditDisabled:false})
        this.state.passwordEditDisabled
            ? this.setState({ passwordEditDisabled: false })
            : this.setState({ passwordEditDisabled: true })
    }

    submitPasswordForm = ({ password }: Object) =>
        api.user
            .updatePassword({ password })
            .then(resp => {
                this.setState({
                    passwordEditDisabled: false,
                    pwUpdated: true
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Password needs to differs from your last 3 passwords`,
                    title: "Error Setting Password",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: this.props.match.params.requestID,
                        ErrorResponse: err
                    }
                })
                throw err
            })

    submitForm = (values, updateContext) =>
        api.user
            .updateUserDetails({
                firstName: values.primaryFirstName,
                lastName: values.primaryLastName,
                phone: `+${values.primaryPhone}`
            })
            .then(() => {
                this.setState({ primaryInitialValues: values })
                updateContext()
            })
            .catch(err => {
                // Error Handled by form
                throw err
            })

    render() {
        const { theme, history } = { ...this.props }
        const { primaryInitialValues, hideEdit, loading } = this.state
        return (
            <div>
                <Grid gridGap="3un">
                    <PageTitle path="Settings/" title="My Username and Password" theme={theme} />
                    <Block padding="3un">
                        <Grid gridGap="3un">
                            <DataCacheContext.Consumer>
                                {currentUser => (
                                    <React.Fragment>
                                        <ProfileDetailsFormContainer
                                            hideEdit={hideEdit}
                                            initialValues={primaryInitialValues}
                                            onSubmit={values => this.submitForm(values, currentUser.update)}
                                            loading={loading}
                                            isAdmin={currentUser.isAdmin}
                                            isPrimary={currentUser.isPrimary}
                                        />
                                        <Card>
                                            <CardContent>
                                                <SetPasswordForm
                                                    setMode={false}
                                                    edit={this.edit}
                                                    passwordSet={this.state.passwordEditDisabled}
                                                    headerText="Update password"
                                                    history={history}
                                                    onSubmit={this.submitPasswordForm}
                                                    userEmail={currentUser.email}
                                                    pwUpdated={this.state.pwUpdated}
                                                />
                                            </CardContent>
                                        </Card>
                                    </React.Fragment>
                                )}
                            </DataCacheContext.Consumer>
                        </Grid>
                    </Block>
                </Grid>
            </div>
        )
    }
}

export default withError(withTheme()(CredentialDetailsContainer))
