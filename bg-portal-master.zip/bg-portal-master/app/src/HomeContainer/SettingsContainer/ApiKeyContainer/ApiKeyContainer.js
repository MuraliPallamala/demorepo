// @flow

import * as React from "react"
import { Formik } from "formik"
import { withTheme } from "@material-ui/core/styles"
import CardContent from "@material-ui/core/CardContent"
import Card from "@material-ui/core/Card"
import { css } from "emotion"
import api from "~/util/api"
import ActionButtons from "~/shared/TableComponent/Components/ActionButtons"
import { Block, Flex } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import withError from "~/shared/Context/ErrorDialog/withError"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import { validate as apiKeyValidation } from "~/shared/Fields/ApiKeyFieldSet/ApiKeyFieldSet"
import sortByDate from "~/util/helpers/sortByDate"
import { apiKeyDefaultValues } from "~/util/apikey"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"
import { dateToShortString } from "~/util/helpers/text"

import ApikeyEditRow from "./ApiKeyTableComponents/ApiKeyEditRow"

const getClasses = ({ theme }) => {
    const cell = css({
        overflowWrap: "break-word"
    })
    const buttonStyle = css(theme.typography.button)

    const titleRow = css({ height: "64px", alignItems: "center" })
    const titleStyle = css({ fontSize: "24px" })
    const dialogStyle = css({ width: "500px" })
    return {
        cell,
        buttonStyle,
        titleRow,
        titleStyle,
        dialogStyle
    }
}

type State = {
    rows: Array<any>,
    loading: boolean,
    addDialogOpen: boolean,
    deleteDialogOpen: boolean,
    apiKeyToDelete: string
}

type Props = { theme: Object, handleErrorOpen: Function, history: Object }
const tableSortDefault = { dataName: "description", order: "asc" }

class ApiKeyTableContainer extends React.PureComponent<Props, State> {
    constructor(props) {
        super(props)

        this.state = {
            rows: [],
            loading: true,
            addDialogOpen: false,
            deleteDialogOpen: false,
            apiKeyToDelete: ""
        }
    }
    buildColumns = () => [
        {
            columnHeader: { displayName: "Account Name", dataName: "description" },
            sort: true
        },
        {
            columnHeader: { displayName: "API Key", dataName: "key" },
            sort: true
        },
        {
            columnHeader: { displayName: "Added On", dataName: "createdAt" },
            cellValue: row => dateToShortString(row.createdAt),
            sort: (a, b) => sortByDate(a, b, "added")
        },
        {
            columnHeader: { displayName: "Actions", dataName: "actions" },
            sort: true,
            hideTooltip: true,
            cellValue: row => (
                <ActionButtons
                    rowId={row.id}
                    changeEditingRowIds={this.changeAddDialogState}
                    openDialog={() => this.changeDeleteDialogState(row.id)}
                    actionButtons={["delete"]}
                    deleteTooltip="Remove an API Key"
                />
            )
        }
    ]
    componentDidMount() {
        this.getApikeys()
    }

    onSubmit = (values: Object, update: boolean, cancelAdd: Function) =>
        api.apikey
            .addApiKey(values)
            .then(({ data }) => {
                console.log(data)
                let { rows } = this.state
                rows = [data, ...rows]
                this.setState({
                    rows
                })

                cancelAdd()
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Add API Key error`,
                    title: "Add API Key  Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: values,
                        ErrorResponse: err
                    }
                })
                throw err
            })

    getApikeys = () => {
        this.setState({ loading: true })
        api.apikey
            .getApiKeys()
            .then(({ data }) => {
                const ApiKeys = Object.values(data)
                this.setState({ rows: ApiKeys, loading: false })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting all API Keys error`,
                    title: "Error Getting API Keys",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                this.setState({ loading: false })
                throw err
            })
    }
    deleteAccount = () => {
        const { apiKeyToDelete } = this.state
        return api.apikey
            .deleteApiKey(apiKeyToDelete)
            .then(({ data }) => {
                this.getApikeys()
                this.changeDeleteDialogState("")
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Deleting API Key error `,
                    title: "Error Deleting API Key",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err,
                        Payload: apiKeyToDelete
                    }
                })
                throw err
            })
    }
    changeAddDialogState = () => {
        this.setState(prevState => ({ addDialogOpen: !prevState.addDialogOpen }))
    }
    changeDeleteDialogState = (rowId: string) => {
        this.setState(prevState => ({ deleteDialogOpen: !prevState.deleteDialogOpen, apiKeyToDelete: rowId }))
    }

    render() {
        const { theme } = this.props
        const { loading, addDialogOpen, deleteDialogOpen } = this.state
        const classes = getClasses({ theme })

        return (
            <React.Fragment>
                <Flex>
                    <PageTitle
                        path="Settings/" // TODO use match.path
                        title="API Key"
                    />
                </Flex>
                <Block padding="3un">
                    <Card>
                        <CardContent>
                            <Flex className={classes.titleRow}>
                                <Flex flex="1">
                                    <Typography className={classes.titleStyle}>Manage API Keys</Typography>
                                </Flex>
                                <Button className={classes.buttonStyle} onClick={this.changeAddDialogState}>
                                    + Add API Key
                                </Button>
                            </Flex>
                            <FlexAccordionTable
                                data={this.state.rows}
                                columns={this.buildColumns()}
                                loading={loading}
                                defaultSort={tableSortDefault}
                                className={css(theme.typography.tableStyle)}
                            />
                        </CardContent>
                    </Card>
                    <Formik
                        initialValues={{
                            ...apiKeyDefaultValues
                        }}
                        validate={values => ({ ...apiKeyValidation(values) })}
                        onSubmit={(values, { setSubmitting, setErrors, resetForm }) => {
                            setSubmitting(true)
                            this.onSubmit(values, false, this.changeAddDialogState)
                                .then(() => {
                                    resetForm()
                                    setSubmitting(false)
                                })
                                .catch(() => setSubmitting(false))
                        }}
                        render={formikProps => (
                            <CustomRequestDialog
                                renderTitle={() => "Add API Key"}
                                renderContent={() => (
                                    <div className={classes.dialogStyle}>
                                        <ApikeyEditRow
                                            formikProps={formikProps}
                                            cancelAdd={this.changeAddDialogState}
                                        />
                                    </div>
                                )}
                                onSubmit={formikProps.submitForm}
                                handleClose={() => {
                                    formikProps.handleReset()
                                    this.changeAddDialogState()
                                }}
                                open={addDialogOpen}
                            />
                        )}
                    />
                    <CustomRequestDialog
                        renderTitle={() => "Remove API Key"}
                        renderContent={() => (
                            <div className={classes.dialogStyle}>
                                <Typography>Are you sure you want to remove this API Key?</Typography>
                            </div>
                        )}
                        onSubmit={this.deleteAccount}
                        handleClose={() => this.changeDeleteDialogState("")}
                        open={deleteDialogOpen}
                    />
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(ApiKeyTableContainer))
