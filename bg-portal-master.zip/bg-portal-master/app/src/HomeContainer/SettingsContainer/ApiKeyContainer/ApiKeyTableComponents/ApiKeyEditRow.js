// @flow
import React from "react"
import { withTheme } from "@material-ui/core/styles"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import TextField from "@material-ui/core/TextField"

type Props = {
    theme: Object,
    formikProps: Object,
    cancelAdd: Function
}
const BankEditRowCells = ({ tableRow, formikProps, cancelAdd, theme }: Props) => (
    <React.Fragment>
        <LoadingDialog
            open={formikProps.isSubmitting}
            loading={formikProps.isSubmitting}
            title="Submitting API Key Details request..."
        />
        <TextField
            fullWidth
            style={{ flexDirection: "unset !important" }}
            placeholder="Account Name"
            label="Account Name"
            name="description"
            id="description"
            onChange={formikProps.handleChange}
            value={formikProps.values.description}
            error={formikProps.touched.description ? !!formikProps.errors.description : false}
            helperText={formikProps.errors.description ? formikProps.errors.description : " "}
        />
    </React.Fragment>
)

export default withTheme()(BankEditRowCells)
