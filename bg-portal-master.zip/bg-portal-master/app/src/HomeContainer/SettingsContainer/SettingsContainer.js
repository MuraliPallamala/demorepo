// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import Button from "@material-ui/core/Button"
import CardContent from "@material-ui/core/CardContent"
import { withTheme } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import Arrow from "@material-ui/icons/KeyboardArrowRight"
import { css } from "emotion"
import CardActionArea from "@material-ui/core/CardActionArea"

import type { User } from "~/util/flow_types"
import { Block, Grid, Flex } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import firstLetter from "~/shared/firstLetter"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"
import Loading from "~/shared/Loading"

type Props = {
    user: User,
    match: Object,
    theme: Object,
    history: Object,
    currentUserInformation: Object,
    handleErrorOpen: Function
}
type State = {
    requestId: string,
    isSubmitting: boolean,
    dialogOpen: boolean
}
const getClasses = theme => {
    const formTitle = css(theme.typography.formTitle)
    const cardContentStyle = css({
        paddingBottom: "16px!important"
    })
    const cardHover = css({
        "&:hover": {
            cursor: "pointer",
            backgroundColor: "#F4FEFD"
        }
    })
    const sectionTitle = css(theme.typography.formTitle, {
        lineHeight: "28px",
        color: theme.palette.common.disabledDark
    })
    const buttonStyle = css({
        color: theme.palette.common.defaultRed
    })
    return {
        formTitle,
        cardHover,
        sectionTitle,
        cardContentStyle,
        buttonStyle
    }
}
type SettingsCardProps = {
    title: string,
    link: string,
    classes: Object,
    history: Object,
    extraText: string,
    requestId: string,
    cancelFunction: Function
}

const SettingsCard = ({ title, link, classes, history, extraText, requestId, cancelFunction }: SettingsCardProps) => (
    <Card square onClick={() => history.push(`/settings/${link}`)} key={link}>
        <CardActionArea>
            <CardContent>
                <Flex>
                    <Flex flex="1">
                        <Typography className={classes.formTitle}>
                            {title}
                            {extraText}
                        </Typography>
                    </Flex>
                    {requestId && (
                        <Button
                            className={classes.buttonStyle}
                            onClick={e => {
                                e.preventDefault()
                                e.stopPropagation()
                                cancelFunction(requestId)
                            }}
                        >
                            Cancel Request
                        </Button>
                    )}
                    <Flex>
                        <Arrow />
                    </Flex>
                </Flex>
            </CardContent>
        </CardActionArea>
    </Card>
)
SettingsCard.defaultProps = {
    extraText: "",
    requestId: "",
    cancelFunction: () => console.log("")
}

class SettingsContainer extends React.Component<Props, State> {
    state = {
        requestId: "",
        isSubmitting: false,
        dialogOpen: false
    }
    componentDidMount() {
        this.getChangeRequests()
        this.props.currentUserInformation.update()
    }

    closeDialog = () => {
        this.setState({ dialogOpen: false })
    }
    openDialog = () => {
        this.setState({ dialogOpen: true })
    }

    getChangeRequests = () => {
        api.settings
            .getConfirmedChangeRequests()
            .then(({ data }) => {
                if (data.result.length >= 1 && data.result[0].requestType === "CHANGE_DETAILS") {
                    const ChangeData = data.result[0]
                    const requestId = ChangeData.id
                    this.setState({ requestId })
                } else {
                    // remove cancel button by removing the request id from the state
                    const requestId = ""
                    this.setState({ requestId })
                }
            })
            .catch(err => {
                this.setState({ isSubmitting: false })

                this.props.handleErrorOpen({
                    errorMessage: `Error getting Change requests`,
                    title: "Error Getting Change Requests",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    cancelRequest = (requestId: string) => {
        this.setState({ isSubmitting: true, dialogOpen: false })
        api.settings
            .submitRequest(requestId, "CANCEL")
            .then(data => {
                this.getChangeRequests()
                this.setState({ isSubmitting: false })
            })
            .catch(err => {
                this.setState({ isSubmitting: false })

                this.props.handleErrorOpen({
                    errorMessage: `Error cancelling request`,
                    title: "Error cancelling request",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: requestId,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    displayModel = (approvalName: string) => {
        if (approvalName === "FOUR_EYE") {
            return " (4 Eye)"
        }
        return ` (${firstLetter(approvalName.replace("_", " "))})`
    }
    render() {
        const { history, theme, currentUserInformation } = this.props
        const classes = getClasses(theme)
        const { requestId, dialogOpen, isSubmitting } = this.state
        return (
            <React.Fragment>
                <LoadingDialog
                    open={this.state.isSubmitting}
                    loading={this.state.isSubmitting}
                    title="Submitting Confirmation request..."
                />
                <PageTitle theme={theme} title="Settings" />
                <Block padding="0un 3un 3un 3un">
                    <Grid gridGap="3un">
                        <Typography className={classes.sectionTitle}>Organisation</Typography>
                        <Block>
                            <SettingsCard
                                title="Organisation Details and Primary User"
                                link="organisationdetails"
                                classes={classes}
                                history={history}
                                requestId={requestId}
                                cancelFunction={this.openDialog}
                            />
                            <SettingsCard
                                title="Administrator"
                                link="administrator"
                                classes={classes}
                                history={history}
                            />
                            {PORTAL_TYPE !== "admin" && (
                                <SettingsCard
                                    title="Approval Model"
                                    link="approvalflow"
                                    classes={classes}
                                    history={history}
                                    extraText={
                                        currentUserInformation.approvalModel &&
                                        currentUserInformation.approvalModel.name
                                            ? this.displayModel(currentUserInformation.approvalModel.name)
                                            : ` (No Model Set)`
                                    }
                                />
                            )}
                            <SettingsCard
                                title="User Management"
                                link="usermanagement"
                                classes={classes}
                                history={history}
                            />
                        </Block>
                        <Typography className={classes.sectionTitle}>My Profile</Typography>
                        <Block>
                            <SettingsCard
                                title="My Username and Password"
                                link="credentials"
                                classes={classes}
                                history={history}
                            />
                            <SettingsCard
                                title="Configure 2 Factor Authentication"
                                link="twofactor"
                                classes={classes}
                                history={history}
                            />
                            <SettingsCard title="API Key" link="apikey" classes={classes} history={history} />
                        </Block>
                        <Typography className={classes.sectionTitle}>Terms and Conditions</Typography>
                        <Block>
                            <SettingsCard
                                title="Platform User Terms"
                                link="platformUserTC"
                                classes={classes}
                                history={history}
                            />
                            <SettingsCard
                                title="Platform Participant Rules"
                                link="platformParticipantRules"
                                classes={classes}
                                history={history}
                            />
                            <SettingsCard
                                title="Form of Bank Guarantee Deed"
                                link="bgdeed"
                                classes={classes}
                                history={history}
                            />
                        </Block>
                    </Grid>
                </Block>
                <CustomRequestDialog
                    renderTitle={() => (isSubmitting ? "Cancelling Request" : "Cancel Request")}
                    renderContent={() =>
                        isSubmitting ? (
                            <Flex justifyContent="center">
                                <Loading show />
                            </Flex>
                        ) : (
                            <Typography>Are you sure you want to cancel this request?</Typography>
                        )
                    }
                    onSubmit={() => this.cancelRequest(requestId)}
                    handleClose={this.closeDialog}
                    open={dialogOpen}
                    submitting={isSubmitting}
                    cancelText="NO"
                    submitText="YES"
                />
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(SettingsContainer))
