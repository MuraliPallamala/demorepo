// @flow

import * as React from "react"
import CardContent from "@material-ui/core/CardContent"
import Card from "@material-ui/core/Card"
import { withTheme } from "@material-ui/core/styles"
import numeral from "numeral"
import Typography from "@material-ui/core/Typography"
import PhoneNumberTextMask from "~/shared/PhoneNumberTextMask"
import { BG } from "~/util/CONSTANTS"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import { mapRemovedUsers } from "~/util/manageUser/manageUser"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import Loading from "~/shared/Loading"
import { Flex } from "~/shared/layout"
import sortByDate from "~/util/helpers/sortByDate"
import UserTimelineDialog from "../ManageUserTableContainer/UserTableComponents/UserTimelineDialog"

type State = {
    rows: Array<Object>,
    loading: boolean
}

type Props = {
    // theme: Object,
    handleErrorOpen: Function,
    currentUserInformation: Object,
    history: Object,
    currentTab: number
}

class ManageUserTableContainer extends React.PureComponent<Props, State> {
    constructor(props) {
        super(props)

        this.state = {
            rows: [{}],
            loading: true
        }
    }
    componentDidMount() {
        this.getAllUsers()
    }
    componentDidUpdate(prevProps) {
        if (prevProps.currentTab !== this.props.currentTab) {
            this.setState({ loading: true })
            this.getAllUsers()
        }
    }

    getAllUsers = () => {
        api.audit
            .myOrgAudit("?topic=user")
            .then(({ data }) => {
                const removedUsers = data.result.filter(
                    event => event.type === "CANCEL_USER_ONBOARDING" || event.type === "DELETE_USER"
                )
                this.setState({ rows: mapRemovedUsers(removedUsers), loading: false })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting all users/Roles was unsuccessful`,
                    title: "Manage Users Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    render() {
        const { currentUserInformation } = this.props
        const { rows, loading } = this.state

        return (
            <React.Fragment>
                <Card>
                    <CardContent>
                        {loading ? (
                            <Flex justifyContent="center">
                                <Loading show />
                            </Flex>
                        ) : (
                            <FlexAccordionTable
                                data={rows}
                                columns={buildColumns(PORTAL_TYPE, currentUserInformation.isAdmin)}
                                header="Removed Users"
                            />
                        )}
                    </CardContent>
                </Card>
            </React.Fragment>
        )
    }
}

const buildColumns = (portalType, isAdmin) => {
    const baseColumns = [
        { columnHeader: { displayName: "Status", dataName: "status" }, cellValue: row => row.status, sort: true },
        {
            columnHeader: { displayName: "Name", dataName: "name" },
            cellValue: row => row.name,
            colWidthProportion: 1.5,
            sort: true
        },
        { columnHeader: { displayName: "Email", dataName: "email" }, cellValue: row => row.email, sort: true },
        {
            columnHeader: {
                displayName: "Phone",
                dataName: "phone"
            },
            cellValue: row => (
                <Typography>
                    <PhoneNumberTextMask value={row.phone} />
                </Typography>
            ),
            sort: true
        },
        {
            columnHeader: { displayName: "Added On", dataName: "added" },
            cellValue: row => row.added,
            sort: (a, b) => sortByDate(a, b, "added")
        },
        {
            columnHeader: { displayName: "Removed On", dataName: "removedOn" },
            cellValue: row => row.removedOn,
            sort: (a, b) => sortByDate(a, b, "removedOn")
        },
        {
            columnHeader: { displayName: "Removed By", dataName: "removedBy" },
            cellValue: row => row.removedBy,
            sort: true
        }
    ]
    // add userRoles and gxlimit columns when not in the admin portal
    if (PORTAL_TYPE !== "admin") {
        baseColumns.splice(
            4,
            0,
            {
                columnHeader: { displayName: "Roles", dataName: "roles" },
                cellValue: row =>
                    row.roles.filter(role => role !== "USER" && role !== "ADMIN" && role !== "PRIMARY").join(", ")
            },
            {
                columnHeader: { displayName: "Guarantee Limit", dataName: "gxLimit" },
                cellValue: row =>
                    row.gxLimit === BG.UNLIMITED_GX_LIMIT || row.gxLimit === null
                        ? "Unlimited"
                        : `AUD ${numeral(row.gxLimit).format("0,0")}`,
                sort: true
            }
        )
    }
    // Add the actions column when the user is an admin
    const columns = isAdmin
        ? [
              ...baseColumns,
              {
                  columnHeader: { displayName: "Actions", dataName: "actions" },
                  cellValue: row => <UserTimelineDialog userInfo={row} />
              }
          ]
        : baseColumns

    return columns
}

export default withError(withTheme()(ManageUserTableContainer))
