// @flow

import * as React from "react"
import TabsContainer from "~/shared/TabsContainer/TabsContainer"
import ManageUserTableContainer from "./ManageUserTableContainer/ManageUserTableContainer"
import RemovedUsersContainer from "./RemovedUsersContainer/RemovedUsersContainer"

type Props = {
    history: Object,
    currentUserInformation: Object
}
type State = {
    selectedTab: number
}
class UsersContainer extends React.PureComponent<Props, State> {
    constructor() {
        super()
        this.state = {
            selectedTab: 0
        }
    }

    handleChange = (event: SyntheticEvent<>, selectedTab: number) => {
        this.setState({ selectedTab })
    }
    handleChangeIndex = (index: number) => {
        this.setState({ selectedTab: index })
    }
    hasParent = (relationships: Array<Object>) => {
        const parents = relationships.filter(
            org => org.relationship === "SUBSIDIARY_OF" && (org.status === "LINKED" || org.status === "UNLINK_PENDING")
        )
        const hasParent = parents.length === 1
        const parent = parents[0]
        return { hasParent, parent }
    }
    buildTabs = (hasParent: boolean, isAdmin: boolean, parent: Object) => {
        const { selectedTab } = this.state
        const { history, currentUserInformation } = this.props

        const tabs = {
            manageUsers: {
                component: (
                    <ManageUserTableContainer history={history} currentUserInformation={currentUserInformation} />
                ),
                label: "MANAGE ACTIVE USERS"
            },
            manageParentUsers: {
                component: (
                    <ManageUserTableContainer
                        history={history}
                        currentUserInformation={currentUserInformation}
                        hasParent
                        parent={parent}
                    />
                ),
                label: "MANAGE PARENT USERS"
            },
            removedUsers: {
                component: (
                    <RemovedUsersContainer
                        history={history}
                        currentTab={selectedTab}
                        currentUserInformation={currentUserInformation}
                    />
                ),
                label: "REMOVED USERS"
            }
        }
        if (isAdmin && hasParent) {
            return [tabs.manageUsers, tabs.manageParentUsers, tabs.removedUsers]
        } else if (isAdmin) {
            return [tabs.manageUsers, tabs.removedUsers]
        }

        return [tabs.manageUsers]
    }
    render() {
        const { currentUserInformation } = this.props
        const { isAdmin } = currentUserInformation
        const { selectedTab } = this.state
        const { hasParent, parent } = this.hasParent(currentUserInformation.relationships)

        return (
            <TabsContainer
                labels={this.buildTabs(hasParent, isAdmin, parent).map(tab => tab.label)}
                pageTitle="Users"
                handleChangeIndex={this.handleChangeIndex}
                handleChange={this.handleChange}
                selectedTab={selectedTab}
            >
                {this.buildTabs(hasParent, isAdmin, parent).map(tab => tab.component)}
            </TabsContainer>
        )
    }
}

export default UsersContainer
