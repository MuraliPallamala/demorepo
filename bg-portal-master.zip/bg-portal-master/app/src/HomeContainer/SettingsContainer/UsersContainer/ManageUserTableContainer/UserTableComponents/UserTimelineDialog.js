// @flow
import * as React from "react"
import Tooltip from "@material-ui/core/Tooltip"
import IconButton from "@material-ui/core/IconButton"
import TimeIcon from "@material-ui/icons/AccessTime"
import { withTheme, Typography } from "@material-ui/core"
import { css } from "emotion"
import Select from "@material-ui/core/Select"
import FormControl from "@material-ui/core/FormControl"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import Button from "@material-ui/core/Button"
import DialogActions from "@material-ui/core/DialogActions"
import Dialog from "@material-ui/core/Dialog"
import DialogContent from "@material-ui/core/DialogContent"
import DialogTitle from "@material-ui/core/DialogTitle"
import Timeline from "~/shared/TimelineContainer/TimelineContainer"
import Loading from "~/shared/Loading"
import { Flex, Row } from "~/shared/layout"
import api from "~/util/api"
import DownloadButton from "~/shared/DownloadButton"
import MyDatePicker from "~/shared/DatePicker/DatePicker"

type Props = {
    disabled: boolean,
    theme: Object,
    userInfo: Object
}
type State = {
    open: boolean,
    data: Array<any>,
    loading: boolean,
    startDate: any,
    endDate: any,
    queryString: string,
    topic: string
}

const getClasses = ({ theme }) => {
    const iconStyle = css({
        color: theme.palette.common.lightBlue
    })
    const selectStyle = css({
        fontSize: "0.5em"
    })
    const dialogStyle = css({ width: "800px", minHeight: "300px", textAlign: "center" })
    const titleStyle = css({ h2: { color: `${theme.palette.common.darkBlue}!important` } })
    const button = css(theme.typography.button)
    return {
        iconStyle,
        dialogStyle,
        titleStyle,
        button,
        selectStyle
    }
}

const topicList = [
    { value: "", label: "All" },
    { value: "user", label: "User Actions" },
    { value: "org", label: "Organisation Actions" },
    { value: "gx", label: "Guarantee Related Actions" }
]
class UserTimelineDialog extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            open: false,
            data: [],
            loading: true,
            startDate: null,
            endDate: null,
            queryString: "",
            topic: ""
        }
    }

    static defaultProps = {
        disabled: false
    }

    componentDidUpdate(prevProps, prevState) {
        if (
            prevState.topic !== this.state.topic ||
            prevState.startDate !== this.state.startDate ||
            prevState.endDate !== this.state.endDate ||
            prevState.open !== this.state.open
        ) {
            const { startDate, endDate, topic } = this.state

            const mappedValues = { after: startDate, before: endDate, topic }
            let queryString = Object.keys(mappedValues)
                .filter(key => mappedValues[key])
                .map(key => `${key}=${mappedValues[key]}`)
                .join("&")
            queryString = `?${queryString}`
            this.setState({ queryString })
            this.getUserAudit(queryString)
        }
    }
    getUserAudit = (queryString: string) => {
        api.audit.getUserAudit(this.props.userInfo.userId, this.props.userInfo.orgId, queryString).then(({ data }) => {
            this.setState({ data: data.result.reverse(), loading: false })
        })
    }
    setDates = (name, date: any) => {
        this.setState({ [name]: date })
    }
    changeDialogState = () => {
        if (this.state.open === false) {
            this.setState({ open: true })

            if (this.state.data.length === 0) {
                this.getUserAudit("")
            } else {
                this.setState({ loading: false })
            }
        } else {
            this.setState({
                open: false,
                loading: true,
                queryString: "",
                topic: "",
                startDate: null,
                endDate: null
            })
        }
    }
    handleChange = event => {
        this.setState({ [event.target.name]: event.target.value })
    }
    hasData = (data: Array<any>) => {
        if (data.length === 0) {
            return <Typography>No data</Typography>
        }
        return <Timeline hideActions data={data} />
    }

    render() {
        const { disabled, theme, userInfo } = this.props
        const { open, data, loading, queryString, topic } = this.state
        const classes = getClasses({ theme })
        return (
            <React.Fragment>
                <Tooltip title="User Timeline" enterDelay={300} leaveDelay={200} disableFocusListener>
                    <IconButton
                        className={classes.iconStyle}
                        onClick={e => {
                            e.preventDefault()
                            e.stopPropagation()
                            this.changeDialogState()
                        }}
                        disabled={disabled}
                    >
                        <TimeIcon />
                    </IconButton>
                </Tooltip>
                <Dialog open={open} maxWidth="md" onClose={this.changeDialogState}>
                    <DialogTitle className={classes.titleStyle} variant="h2">
                        <Flex>
                            <Flex flex={1}>
                                {userInfo.name} ({userInfo.roles.join(", ")})
                            </Flex>
                            <Flex>
                                <DownloadButton
                                    downloadCsv={api.audit.downloadUserAudit(
                                        this.props.userInfo.userId,
                                        this.props.userInfo.orgId,
                                        queryString
                                    )}
                                />
                            </Flex>
                        </Flex>
                        <Row>
                            <Typography flex={1} style={{ margin: "auto 24px 0px 24px" }}>
                                Filter:{" "}
                            </Typography>
                            <MyDatePicker
                                flex={1}
                                styles={{ fontSize: "0.5em", margin: "auto 24px" }}
                                dateValue={this.state.startDate}
                                label="Beginning Date"
                                fieldName="startDate"
                                setDate={this.setDates}
                            />
                            <MyDatePicker
                                flex={1}
                                styles={{ fontSize: "0.5em", margin: "auto 24px" }}
                                dateValue={this.state.endDate}
                                label="Ending Date"
                                fieldName="endDate"
                                setDate={this.setDates}
                            />
                            <FormControl flex={1} style={{ margin: "auto 24px", minWidth: "250px" }}>
                                <InputLabel htmlFor="topic" className={classes.selectStyle}>
                                    Topics
                                </InputLabel>
                                <Select
                                    value={topic}
                                    name="topic"
                                    id="topic"
                                    onChange={this.handleChange}
                                    inputProps={{
                                        name: "topic",
                                        id: "topic"
                                    }}
                                    className={classes.selectStyle}
                                >
                                    {topicList.map(aTopic => (
                                        <MenuItem key={aTopic.value} value={aTopic.value}>
                                            {aTopic.label}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Row>
                    </DialogTitle>
                    <DialogContent className={classes.dialogStyle}>
                        {loading ? <Loading show /> : this.hasData(data)}
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.changeDialogState} className={classes.button}>
                            Ok
                        </Button>
                    </DialogActions>
                </Dialog>
            </React.Fragment>
        )
    }
}

export default withTheme()(UserTimelineDialog)
