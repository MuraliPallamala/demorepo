// @flow

import * as React from "react"
import { Formik } from "formik"
import CardContent from "@material-ui/core/CardContent"
import Card from "@material-ui/core/Card"
import userFieldSetValidate from "~/shared/Fields/User/UserFieldValidation"
import axios from "axios"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import { Flex } from "~/shared/layout"
import numeral from "numeral"
import Typography from "@material-ui/core/Typography"
import PhoneNumberTextMask from "~/shared/PhoneNumberTextMask"
import { BG } from "~/util/CONSTANTS"
import { css } from "emotion"
import ConfirmationCodeSmart from "~/shared/ConfirmationCodeSmart"
import ActionButtons from "~/shared/TableComponent/Components/ActionButtons"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"
import IconButton from "@material-ui/core/IconButton"
import DownloadDialog from "~/shared/Dialogs/DownloadDialog"
import { userDefaults, mapUser, mapValuesToRequest } from "~/util/manageUser/manageUser"
import DownloadIcon from "@material-ui/icons/GetApp"
import UserTimelineDialog from "./UserTableComponents/UserTimelineDialog"
import UserEditRowCells from "./UserTableComponents/UserEditRowCells"

type State = {
    rows: Array<Object>,
    loading: boolean,
    roleList: Array<Object>,
    dialogOpen: boolean,
    userIdToDelete: string,
    editDialogOpen: boolean,
    editUserData: ?Object,
    downloadDialogOpen: boolean
}

type Props = {
    theme: Object,
    handleErrorOpen: Function,
    currentUserInformation: Object,
    history: Object,
    hasParent: boolean,
    parent: ?Object
}

const getClasses = ({ theme }) => {
    const adminLabel = css(theme.typography.body2, {
        padding: ".2rem",
        marginLeft: ".3rem",
        backgroundColor: "#E8F1F9",
        borderRadius: "4px"
    })
    const iconStyle = css({
        color: theme.palette.common.lightBlue
    })

    const buttonStyle = css(theme.typography.button)
    const primaryLabel = css(adminLabel, { backgroundColor: "#F6EFFC" })
    const titleRow = css({ height: "64px", alignItems: "center", fontSize: "24px" })
    return {
        adminLabel,
        primaryLabel,
        titleRow,
        buttonStyle,
        iconStyle
    }
}

const tableSortDefault = { dataName: "name", order: "asc" }

class ManageUserTableContainer extends React.PureComponent<Props, State> {
    static defaultProps = {
        hasParent: false,
        parent: null
    }
    constructor(props) {
        super(props)

        this.state = {
            rows: [{}],
            loading: true,
            roleList: [{ value: "USER", label: "User", key: 2 }],
            dialogOpen: false,
            userIdToDelete: "",
            editDialogOpen: false,
            editUserData: null,
            downloadDialogOpen: false
        }
    }
    componentDidMount() {
        if (!this.props.hasParent || (this.props.hasParent && this.props.currentUserInformation.isLoaded)) {
            this.getAllUsers()
        }
    }
    componentDidUpdate(prevProps) {
        if (prevProps.currentUserInformation.isLoaded !== this.props.currentUserInformation.isLoaded) {
            this.getAllUsers()
        }
    }

    buildColumns = (portalType, isAdmin, currentUserInformation) => {
        const cellClasses = getClasses({ theme: this.props.theme })
        const baseColumns = [
            {
                columnHeader: { displayName: "Status", dataName: "formattedStatus" },
                cellValue: row => row.status,
                sort: true
            },
            {
                columnHeader: { displayName: "Name", dataName: "name" },
                cellValue: row => {
                    if (row.roles.includes("ADMIN") || row.roles.includes("PRIMARY")) {
                        return (
                            <div>
                                <span> {row.name}</span>
                                <span className={cellClasses.adminLabel} hidden={!row.roles.includes("ADMIN")}>
                                    ADMIN
                                </span>
                                <span className={cellClasses.primaryLabel} hidden={!row.roles.includes("PRIMARY")}>
                                    PRIMARY
                                </span>
                            </div>
                        )
                    }
                    return <div>{row.name}</div>
                },
                colWidthProportion: 1.5,
                sort: true
            },
            { columnHeader: { displayName: "Email", dataName: "email" }, cellValue: row => row.email, sort: true },
            {
                columnHeader: {
                    displayName: "Phone",
                    dataName: "phone"
                },
                cellValue: row => <PhoneNumberTextMask value={row.phone} />,
                sort: true
            },
            {
                columnHeader: { displayName: "Added On", dataName: "added" },
                cellValue: row => row.added,
                sort: true
            },
            {
                columnHeader: { displayName: "Actions", dataName: "actions" },
                hideTooltip: true,
                minWidth: 200,
                cellValue: row => {
                    if (isAdmin) {
                        if (
                            row.status &&
                            row.status.toLowerCase() !== "pending" &&
                            this.props.hasParent &&
                            this.props.parent &&
                            this.props.parent.permission.includes("WRITE")
                        ) {
                            return (
                                <ActionButtons
                                    changeEditingRowIds={() => this.changeEditDialogState(row)}
                                    openDialog={() => this.changeDialogState("")}
                                    actionButtons={PORTAL_TYPE !== "admin" ? ["edit"] : [""]}
                                />
                            )
                        }
                        if (
                            row.status &&
                            (row.status.toLowerCase() === "pending" ||
                                (this.props.parent && !this.props.parent.permission.includes("WRITE"))) &&
                            this.props.hasParent
                        ) {
                            return <div />
                        }
                        if (row.status && row.status.toLowerCase() === "pending") {
                            return (
                                <div>
                                    <ConfirmationCodeSmart
                                        text="Pass On: Onboarding PIN"
                                        confirmationCode={row.token}
                                        onRequestCode={this.getUserToken}
                                        id={row.userId}
                                    />
                                    <ActionButtons
                                        changeEditingRowIds={blah => console.log("changerows?", blah)}
                                        openDialog={() => this.changeDialogState(row.userId)}
                                        actionButtons={["delete"]}
                                    />
                                </div>
                            )
                        }
                        if (
                            row.status !== "pending" &&
                            (row.roles.includes("ADMIN") || row.roles.includes("PRIMARY"))
                        ) {
                            return (
                                <div>
                                    <UserTimelineDialog userInfo={row} />
                                    <ActionButtons
                                        changeEditingRowIds={() => this.changeEditDialogState(row)}
                                        openDialog={() => this.changeDialogState("")}
                                        actionButtons={PORTAL_TYPE !== "admin" ? ["edit"] : []}
                                    />
                                </div>
                            )
                        }
                        if (
                            row.status !== "pending" &&
                            !row.roles.includes("ADMIN") &&
                            !row.roles.includes("PRIMARY")
                        ) {
                            return (
                                <div>
                                    <UserTimelineDialog userInfo={row} />
                                    <ActionButtons
                                        changeEditingRowIds={() => this.changeEditDialogState(row)}
                                        openDialog={() => this.changeDialogState(row.userId)}
                                        actionButtons={["edit", "delete"]}
                                    />
                                </div>
                            )
                        }

                        if (row.status !== "pending") {
                            return (
                                <div>
                                    <UserTimelineDialog userInfo={row} />
                                </div>
                            )
                        }
                    }
                    if (
                        row.status &&
                        row.status.toLowerCase() === "pending" &&
                        (row.roles.includes("ADMIN") || row.roles.includes("PRIMARY")) &&
                        currentUserInformation.userRoles[currentUserInformation.primaryOrgId].includes("PRIMARY")
                    ) {
                        return (
                            <ConfirmationCodeSmart
                                text="Pass On: Onboarding PIN"
                                confirmationCode={row.token}
                                onRequestCode={this.getUserToken}
                                id={row.userId}
                            />
                        )
                    }
                    if (
                        row.status !== "pending" &&
                        row.userId === currentUserInformation.id &&
                        !row.roles.includes("PRIMARY")
                    ) {
                        return (
                            <ActionButtons
                                changeEditingRowIds={() => this.changeEditDialogState(row)}
                                openDialog={() => this.changeDialogState("")}
                                actionButtons={["edit"]}
                            />
                        )
                    }
                    return <div />
                }
            }
        ]
        // add userRoles and gxlimit columns when not in the admin portal
        if (PORTAL_TYPE !== "admin") {
            baseColumns.splice(
                4,
                0,
                {
                    columnHeader: { displayName: "Roles", dataName: "userRoles" },
                    cellValue: row =>
                        row.roles.filter(role => role !== "USER" && role !== "ADMIN" && role !== "PRIMARY").join(", ")
                },
                {
                    columnHeader: { displayName: "Guarantee Limit", dataName: "gxLimit" },
                    cellValue: row =>
                        row.gxLimit === BG.UNLIMITED_GX_LIMIT || row.gxLimit === null || row.gxLimit === ""
                            ? "Unlimited"
                            : `AUD ${numeral(row.gxLimit).format("0,0")}`,
                    sort: true
                }
            )
        }

        return baseColumns
    }
    onSubmit = (values: Object, update: boolean, changeEditDialogState: Function) => {
        const apiValue = mapValuesToRequest(values)
        // TODO: Remove this once the backend fixes their user issues
        apiValue.roles.push("USER")
        apiValue.roles = apiValue.roles.concat(["USER"])
        const userID = values.userId
        if (!update) {
            return api.manageUsers
                .addUser(apiValue)
                .then(({ data }) => {
                    this.addUserRow(data)
                    changeEditDialogState(null)
                })
                .catch(err => {
                    // Handled by LoadingWithError
                    err.CustomMessage = `Adding a user was unsuccessful`
                    err.Payload = apiValue
                    throw err
                })
        } else if (this.props.hasParent && update) {
            const parentId = this.props.parent && this.props.hasParent ? this.props.parent.id : ""
            return api.manageUsers
                .updateParentUser(userID, apiValue.roles, apiValue.gxLimit, parentId)
                .then(() => {
                    this.updateUserRow(values)
                    changeEditDialogState(null)
                })
                .catch(err => {
                    // Handled by LoadingWithError
                    err.CustomMessage = `Updating user details was unsuccessful`
                    err.Payload = apiValue
                    throw err
                })
        } else if (apiValue.roles.includes("ADMIN") || (apiValue.roles.includes("PRIMARY") && update)) {
            return api.manageUsers
                .updateAdminAndPrimaryUser(
                    userID,
                    apiValue.roles.filter(role => role !== "ADMIN" && role !== "PRIMARY"),
                    apiValue.gxLimit
                )
                .then(() => {
                    this.updateUserRow(values)
                    this.props.currentUserInformation.update()
                    changeEditDialogState(null)
                })
                .catch(err => {
                    // Handled by LoadingWithError
                    err.CustomMessage = `Updating user details was unsuccessful`
                    err.Payload = apiValue
                    throw err
                })
        } else if (apiValue.userId === this.props.currentUserInformation.id) {
            return api.user
                .updateUserDetails(apiValue)
                .then(() => {
                    this.updateUserRow(values)
                    this.props.currentUserInformation.update()
                    changeEditDialogState(null)
                })
                .catch(err => {
                    // Handled by LoadingWithError
                    err.CustomMessage = `Updating your details was unsuccessful`
                    err.Payload = apiValue
                    throw err
                })
        }
        return api.manageUsers
            .updateUser(apiValue, userID)
            .then(({ data }) => {
                this.updateUserRow(values)
                changeEditDialogState(null)
            })
            .catch(err => {
                // Handled by LoadingWithError
                err.CustomMessage = `Updating user details was unsuccessful`
                err.Payload = apiValue
                throw err
            })
    }

    getParentQueryString = (parent: ?Object) => {
        const queryString = parent && this.props.hasParent ? `?parentOrgId=${parent.id}` : ""
        return queryString
    }
    getAllUsers = () => {
        api.general
            .multipleApis([
                api.manageUsers.getAllUsers(this.getParentQueryString(this.props.parent)),
                api.settings.getOrgRoles(this.props.parent ? this.props.parent.id : null)
            ])
            .then(
                axios.spread((acct, roles) => {
                    // Both requests are now complete
                    const newRoles = roles.data.filter(
                        role => role.roleName !== "ADMIN" && role.roleName !== "PRIMARY" && role.roleName !== "USER"
                    )
                    const roleList = newRoles.map(role => ({ value: role.roleName, label: role.roleName }))
                    // const isRoleInList = (role, list) => list.filter(item => item.value === role).length >= 1

                    const userList = acct.data.result.map((user, index) => {
                        const userRoles = user.roles // .filter(role => isRoleInList(role, roleList))
                        user.roles = userRoles

                        return mapUser(user)
                    })

                    this.setState({ rows: userList, loading: false, roleList })

                    // this.setState({ rows: userList, loading: false, roleList })
                })
            )
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting all users/Roles was unsuccessful`,
                    title: "Manage Users Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    getUserToken = (userId: string) => api.manageUsers.getUserToken(userId)

    updateUserRow = (userInfo: Object) => {
        let { rows } = this.state
        rows = rows.map(row => (userInfo.userId === row.userId ? mapUser({ ...row, ...userInfo }, false) : row))
        this.setState({
            rows
        })
    }
    addUserRow = (userInfo: Object) => {
        let { rows } = this.state
        rows = [mapUser(userInfo), ...rows]
        this.setState({
            rows
        })
    }
    deleteRow = () => {
        const { userIdToDelete } = this.state
        this.setState({ loading: true })
        this.changeDialogState("")
        return api.manageUsers
            .deleteUser(userIdToDelete)
            .then(data => {
                this.getAllUsers()
                this.setState({ loading: false })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Deleting user was unsuccessful`,
                    title: `Deleting user Error`,
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err,
                        Payload: userIdToDelete
                    }
                })
                throw err
            })
    }

    updateStatus = (rowToUpdate: number) => {
        let newStatus = "pending"
        // const { userId, status } = this.state.rows[rowToUpdate]
        const row = this.state.rows.filter(currentRow => currentRow.id === rowToUpdate).pop()
        const { status } = row
        if (status.toLowerCase() === "active" && status.toLowerCase !== "pending") {
            newStatus = "INACTIVE"
        } else if (status.toLowerCase !== "pending") {
            newStatus = "ACTIVE"
        }
        return api.manageUsers
            .updateStatus(rowToUpdate, newStatus)
            .then(data => {
                this.getAllUsers()
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Updating the status was unsuccessful`,
                    title: `Updating User Status Error`,
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err,
                        Payload: { UserID: rowToUpdate, NewStatus: newStatus }
                    }
                })
                throw err
            })
    }

    downloadUsers = (queryString: string) =>
        api.audit.downloadUserPermissions(this.props.currentUserInformation.currentOrgId, queryString)
    changeDialogState = (userId: string) => {
        this.setState(prevState => ({ dialogOpen: !prevState.dialogOpen, userIdToDelete: userId }))
    }
    changeEditDialogState = (row: ?Object) => {
        this.setState(prevState => ({ editDialogOpen: !prevState.editDialogOpen, editUserData: row }))
    }
    changeDownloadDialogState = () => {
        this.setState(prevState => ({ downloadDialogOpen: !prevState.downloadDialogOpen }))
    }
    render() {
        const { loading, dialogOpen, editDialogOpen, editUserData, downloadDialogOpen } = this.state
        const {
            hasParent,
            // parent,
            currentUserInformation,
            theme
        } = this.props
        const { isAdmin, currentOrgId, userRoles } = currentUserInformation
        const classes = getClasses({ theme })
        return (
            <React.Fragment>
                <Card>
                    <CardContent>
                        <Flex className={classes.titleRow}>
                            <Flex flex="1">Registered Users</Flex>
                            {/* Only show download button for the admin user because non-admin users aren't authorised to download User audit */}
                            {userRoles && currentOrgId && userRoles[currentOrgId].includes("ADMIN") ? (
                                <IconButton
                                    className={classes.iconStyle}
                                    onClick={e => {
                                        e.preventDefault()
                                        e.stopPropagation()
                                        this.changeDownloadDialogState()
                                    }}
                                >
                                    <DownloadIcon />
                                </IconButton>
                            ) : null}
                            {isAdmin && !hasParent && (
                                <Button
                                    className={classes.buttonStyle}
                                    onClick={() => this.changeEditDialogState(null)}
                                >
                                    + Add User
                                </Button>
                            )}
                        </Flex>
                        <FlexAccordionTable
                            data={this.state.rows}
                            columns={this.buildColumns(PORTAL_TYPE, isAdmin, currentUserInformation)}
                            loading={loading}
                            defaultSort={tableSortDefault}
                            defaultMinWidth={120}
                        />
                        <CustomRequestDialog
                            renderTitle={() => "Remove User"}
                            renderContent={() => <Typography>Are you sure you want to remove this user?</Typography>}
                            onSubmit={this.deleteRow}
                            handleClose={() => this.changeDialogState("")}
                            open={dialogOpen}
                        />
                        <Formik
                            initialValues={{
                                ...userDefaults,
                                ...editUserData
                            }}
                            enableReinitialize
                            validate={values => ({
                                ...userFieldSetValidate(values, !!editUserData, this.state.roleList)
                            })}
                            onSubmit={(values, { setSubmitting, setErrors, setStatus, resetForm }) => {
                                setSubmitting(true)
                                setStatus()
                                // Assumes that on success component unmounts so no need to call setSubmitting
                                this.onSubmit(values, !!editUserData, () => this.changeEditDialogState(null))
                                    .then(() => {
                                        resetForm()
                                        setSubmitting(false)
                                    })
                                    .catch(err => {
                                        setStatus(err)
                                        setSubmitting(false)
                                    })
                            }}
                            render={formikProps => (
                                <CustomRequestDialog
                                    renderTitle={() => (editUserData ? "Edit User" : "Add User")}
                                    renderContent={() => (
                                        <UserEditRowCells
                                            formikProps={formikProps}
                                            update={!!editUserData}
                                            row={formikProps.values}
                                            roleList={this.state.roleList}
                                            isAdmin={this.props.currentUserInformation.isAdmin}
                                            history={this.props.history}
                                            hasParent={this.props.hasParent}
                                        />
                                    )}
                                    onSubmit={formikProps.submitForm}
                                    handleClose={() => this.changeEditDialogState(null)}
                                    open={editDialogOpen}
                                />
                            )}
                        />
                        <DownloadDialog
                            open={downloadDialogOpen}
                            handleClose={this.changeDownloadDialogState}
                            onSubmit={this.downloadUsers}
                            parentOrgId={this.props.hasParent && this.props.parent ? this.props.parent.id : ""}
                        />
                    </CardContent>
                </Card>
            </React.Fragment>
        )
    }
}
export default withError(withTheme()(ManageUserTableContainer))
