// @flow
import React from "react"
import { withTheme } from "@material-ui/core/styles"
import LoadingWithErrorDialog from "~/shared/Dialogs/LoadingWithErrorDialog"
import FormControl from "@material-ui/core/FormControl"
import FormHelperText from "@material-ui/core/FormHelperText"
import TextField from "@material-ui/core/TextField"
import MenuItem from "@material-ui/core/MenuItem"
import Select from "@material-ui/core/Select"
import InputLabel from "@material-ui/core/InputLabel"
import ListItemText from "@material-ui/core/ListItemText"
import Checkbox from "@material-ui/core/Checkbox"
import Input from "@material-ui/core/Input"
import NumberTextIntegerField from "~/shared/NumberTextIntegerField"
import PhoneNumberMask from "~/shared/PhoneNumberMask"
import { Grid } from "~/shared/layout"

type Props = {
    row: Object,
    theme: Object,
    formikProps: Object,
    update: boolean,
    history: Object,
    roleList: Array<any>,
    isAdmin: boolean,
    hasParent: boolean
}
const UserEditRowCells = ({ row, formikProps, theme, update, history, roleList, isAdmin, hasParent }: Props) => {
    const { roles } = row
    return (
        <div style={{ width: "800px" }}>
            <LoadingWithErrorDialog
                open={formikProps.isSubmitting && !formikProps.isValidating && formikProps.isValid}
                loading={formikProps.isSubmitting && !formikProps.isValidating}
                isError={formikProps.status ? !!formikProps.status : false}
                errorMessage={formikProps.status ? formikProps.status.CustomMessage : ""}
                errorTitle="User Management Error"
                error={formikProps.status ? formikProps.status : {}}
                extraDetails={{
                    Info: formikProps.status ? formikProps.status.info : "",
                    CurrentUrl: history.location.pathname,
                    ErrorResponse: formikProps.status,
                    Payload: formikProps.status ? formikProps.status.Payload : ""
                }}
                title="Submitting User request..."
            />
            <Grid gridTemplateRows="auto auto auto" gridTemplateColumns="auto auto" gridColumnGap="24px">
                <TextField
                    fullWidth
                    placeholder="First Name"
                    label="First Name"
                    name="firstName"
                    id="firstName"
                    disabled={hasParent || (roles && (roles.includes("ADMIN") || roles.includes("PRIMARY")))}
                    onChange={formikProps.handleChange}
                    value={formikProps.values.firstName}
                    error={formikProps.touched.firstName ? !!formikProps.errors.firstName : false}
                    helperText={formikProps.errors.firstName ? formikProps.errors.firstName : " "}
                />
                <TextField
                    fullWidth
                    placeholder="Last Name"
                    label="Last Name"
                    name="lastName"
                    id="lastName"
                    disabled={hasParent || (roles && (roles.includes("ADMIN") || roles.includes("PRIMARY")))}
                    onChange={formikProps.handleChange}
                    value={formikProps.values.lastName}
                    error={formikProps.touched.lastName ? !!formikProps.errors.lastName : false}
                    helperText={formikProps.errors.lastName ? formikProps.errors.lastName : " "}
                />

                <TextField
                    fullWidth
                    placeholder="Email"
                    label="Email"
                    disabled={update}
                    name="email"
                    onChange={formikProps.handleChange}
                    onBlur={formikProps.handleBlur}
                    value={formikProps.values.email}
                    error={formikProps.touched.email ? !!formikProps.errors.email : false}
                    helperText={formikProps.errors.email ? formikProps.errors.email : " "}
                />

                <TextField
                    placeholder="Phone"
                    fullWidth
                    label="Phone"
                    name="phone"
                    id="phone"
                    disabled={hasParent || (roles && (roles.includes("ADMIN") || roles.includes("PRIMARY")))}
                    value={formikProps.values.phone}
                    error={formikProps.touched.phone ? !!formikProps.errors.phone : false}
                    helperText={formikProps.errors.phone ? formikProps.errors.phone : " "}
                    InputProps={{
                        inputComponent: PhoneNumberMask,
                        onChange: e => formikProps.setFieldValue("phone", e.target.value)
                    }}
                />
                {PORTAL_TYPE !== "admin" && (
                    <FormControl
                        style={{ width: "100%" }}
                        error={formikProps.touched.roles ? !!formikProps.errors.roles : false}
                    >
                        <InputLabel htmlFor="roles">Select Roles</InputLabel>
                        <Select
                            multiple
                            value={formikProps.values.roles}
                            renderValue={selected =>
                                selected
                                    .filter(role => role !== "ADMIN" && role !== "PRIMARY" && role !== "USER")
                                    .join(", ")
                            }
                            // {formikProps.values.roles.filter(
                            //     role => role !== "ADMIN" && role !== "PRIMARY" && role !== "USER"
                            // )}
                            name="roles"
                            id="roles"
                            onChange={formikProps.handleChange}
                            input={<Input name="roles" id="roles" />}
                            // renderValue={selected => selected.join(", ")}
                            disabled={!isAdmin || roleList.length === 0}
                        >
                            {roleList.map(role => (
                                <MenuItem key={role.value} value={role.value}>
                                    <Checkbox checked={formikProps.values.roles.indexOf(role.value) > -1} />
                                    <ListItemText primary={role.label} />
                                </MenuItem>
                            ))}
                        </Select>
                        <FormHelperText>{formikProps.errors.roles ? formikProps.errors.roles : ""}</FormHelperText>
                    </FormControl>
                )}
                {PORTAL_TYPE !== "admin" && (
                    <TextField
                        // className={classes.formControl}
                        fullWidth
                        label="Threshold"
                        placeholder="Unlimited"
                        value={formikProps.values.gxLimit}
                        name="gxLimit"
                        onChange={e => formikProps.setFieldValue("gxLimit", e.target.value)}
                        id="gxLimit"
                        disabled={!isAdmin}
                        error={formikProps.touched.gxLimit ? !!formikProps.errors.gxLimit : false}
                        helperText={formikProps.errors.gxLimit ? formikProps.errors.gxLimit : " "}
                        InputProps={{
                            inputComponent: NumberTextIntegerField
                        }}
                    />
                )}
            </Grid>
        </div>
    )
}

export default withTheme()(UserEditRowCells)
