// @flow

import * as React from "react"

import { withTheme } from "@material-ui/core/styles"
import { Formik } from "formik"
import parentSubsidiaryFieldValidation from "~/shared/Fields/ParentSubsidiary/parentSubsidiaryFieldValidation"
import { relationshipDefaults, mapRelationship, mapRelationships } from "~/util/parentSubsidiary"

import { css } from "emotion"
import Typography from "@material-ui/core/Typography"
import CardContent from "@material-ui/core/CardContent"
import { Flex } from "~/shared/layout"

import Button from "@material-ui/core/Button"

import Card from "@material-ui/core/Card"
import ActionButtons from "~/shared/TableComponent/Components/ActionButtons"
import sortByDate from "~/util/helpers/sortByDate"
import api from "~/util/api"
import ParentRelationshipButton from "~/shared/TableComponent/Components/ParentRelationshipButton"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"

import withError from "~/shared/Context/ErrorDialog/withError"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import ParentSubEditRow from "./ParentSubTableComponents/ParentSubEditRow"

type State = {
    rows: Array<Object>,
    loading: boolean,
    myOrg: string,
    loadingDialog: boolean,
    addDialogOpen: boolean
}

type Props = {
    theme: Object,
    loading: boolean,
    orgName: string,
    handleErrorOpen: Function,
    currentUserInformation: Object,
    updateTimeline: Function,
    history: Object,
    update: number
}

const getClasses = ({ theme }) => {
    const buttonStyle = css(theme.typography.button)
    const awaitingApproval = css({ color: theme.palette.common.buttonGreen, fontStyle: "italic" })
    const title = css(theme.typography.cardTitle)

    return {
        buttonStyle,
        awaitingApproval,
        title
    }
}
const tableSortDefault = { dataName: "displayRelationship", order: "asc" }

class ParentSubsidaryTableContainer extends React.PureComponent<Props, State> {
    constructor(props) {
        super(props)

        this.state = {
            rows: [],
            loading: true,
            myOrg: "",
            loadingDialog: false,
            addDialogOpen: false
        }
    }
    componentDidMount() {
        this.getOrganisationRelationships()
    }
    componentWillReceiveProps(nextProps) {
        if (
            nextProps.orgName !== this.state.myOrg &&
            this.state.rows.length > 0 &&
            this.props.orgName !== nextProps.orgName
        ) {
            const updateRows = this.state.rows
            for (let i = 0; i < updateRows.length; i++) {
                updateRows[i].myOrg = nextProps.orgName
            }
            this.setState({ myOrg: nextProps.orgName, rows: updateRows })
        }
        if (nextProps.update !== this.props.update) {
            this.getOrganisationRelationships()
        }
    }

    buildColumns = (portalType, isAdmin) => {
        const classes = getClasses({ theme: this.props.theme })
        const baseColumns = [
            {
                columnHeader: { displayName: "My Organisation", dataName: "myOrg" },
                cellValue: () => this.props.orgName,
                sort: true
            },
            {
                columnHeader: { displayName: "", dataName: "isThe" },
                cellValue: row => "is the",
                colWidthProportion: 0.3
            },
            {
                columnHeader: { displayName: "Relationship", dataName: "displayRelationship" },
                sort: true
            },
            {
                columnHeader: { displayName: "", dataName: "of" },
                cellValue: row => "of",
                colWidthProportion: 0.3
            },
            {
                columnHeader: { displayName: "Organisation", dataName: "relatedEntityName" },
                sort: true
            },
            {
                columnHeader: { displayName: "", dataName: "whichCan" },
                cellValue: row => "which can",
                colWidthProportion: 0.5
            },
            {
                columnHeader: { displayName: "Rights", dataName: "displayPermissions" },
                sort: true
            },
            {
                columnHeader: { displayName: "Added On", dataName: "addedOn" },
                cellValue: row => row.addedOn,
                sort: (a, b) => sortByDate(a, b, "addedOn"),
                colWidthProportion: 0.8
            },
            {
                columnHeader: { displayName: "Status", dataName: "status" },
                cellValue: row => row.status.split("_").join(" "),
                sort: true
            },
            {
                columnHeader: { displayName: "Actions", dataName: "actions" },
                hideTooltip: true,
                colWidthProportion: 1.2,
                cellValue: row => {
                    if (isAdmin) {
                        if ((row.status === "LINK_PENDING" || row.status === "UNLINK_PENDING") && !row.initiatorFlag) {
                            return (
                                <ParentRelationshipButton
                                    rowId={row.id}
                                    row={row}
                                    reject={this.deleteRow}
                                    approve={this.approve}
                                />
                            )
                        } else if (
                            (row.status === "LINK_PENDING" || row.status === "UNLINK_PENDING") &&
                            row.initiatorFlag
                        ) {
                            return <Typography className={classes.awaitingApproval}>Awaiting approval</Typography>
                        }
                        return <ActionButtons rowId={row.id} actionButtons={["revoke"]} otherAction={this.deleteRow} />
                    }

                    return <div />
                }
            }
        ]

        return baseColumns
    }

    onRowSelection = row => {
        this.props.history.push(`/organisations/${row.id}`)
    }
    onSubmit = (values: Object, cancelAdd: Function) => {
        this.setState({ loadingDialog: true })
        const submitValue = {
            id: values.organisation.orgId,
            relationship: values.relationship,
            permission: values.permission
        }
        return api.settings
            .changeRequest(submitValue, "LINK_ORGANIZATION")
            .then(({ data }) => {
                let { rows } = this.state
                const newRow = mapRelationship(values)
                newRow.myOrg = this.state.myOrg
                newRow.status = data.payload.status
                newRow.initiatorFlag = true
                rows = [...rows, newRow]
                this.setState({
                    rows,
                    loadingDialog: false
                })

                this.props.updateTimeline("")

                cancelAdd()
            })
            .catch(err => {
                this.setState({
                    loadingDialog: false
                })
                this.props.handleErrorOpen({
                    errorMessage: `Adding the relationship was unsuccessful`,
                    title: "Linking Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: submitValue,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    getOrganisationRelationships = () => {
        api.settings
            .getOrgRelationships()
            .then(({ data }) => {
                const newRows = mapRelationships(data)

                this.setState({ loading: false, rows: newRows })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `There was an error getting the relationships`,
                    title: "Get Organisation Relationships Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    approve = (row: Object) => {
        this.setState({ loadingDialog: true })

        api.settings
            .submitRequest(row.requestId, "APPROVE")
            .then(data => {
                this.props.updateTimeline("")
                this.getOrganisationRelationships()
                this.setState({ loadingDialog: false })
                this.props.currentUserInformation.update()
                return data
            })
            .catch(err => {
                this.setState({ loadingDialog: false })

                this.props.handleErrorOpen({
                    errorMessage: `Approving the relationship was unsuccessful`,
                    title: "Approving Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: row.requestId,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    deleteRow = (rowToDelete: Object) => {
        this.setState({ loadingDialog: true })
        const rowId = rowToDelete.id ? rowToDelete.id : rowToDelete
        const rowsToDelete = this.state.rows.filter(row => rowId === row.id)
        const values = rowsToDelete.pop()
        const { status } = values
        const submitValue = {
            id: values.organisation
        }
        let action = "REJECT"
        if (status === "LINKED") {
            action = "UNLINK_ORGANIZATION"
            // $FlowFixMe
            submitValue.relationship = values.relationship
            // $FlowFixMe
            submitValue.permission = values.permission
            return api.settings
                .changeRequest(submitValue, action)
                .then(data => {
                    this.props.updateTimeline("")
                    this.getOrganisationRelationships()
                    this.setState({ loadingDialog: false })
                })
                .catch(err => {
                    this.setState({ loadingDialog: false })

                    this.props.handleErrorOpen({
                        errorMessage: `Rejecting was unsuccessful`,
                        title: "Rejecting Error",
                        error: err,
                        extraDetails: {
                            Info: err.info,
                            CurrentUrl: this.props.history.location.pathname,
                            Payload: submitValue,
                            ErrorResponse: err
                        }
                    })
                    throw err
                })
        }
        return api.settings
            .submitRequest(values.requestId, "REJECT")
            .then(data => {
                this.props.updateTimeline("")
                this.getOrganisationRelationships()
                this.setState({ loadingDialog: false })
            })
            .catch(err => {
                this.setState({ loadingDialog: false })

                this.props.handleErrorOpen({
                    errorMessage: `Rejecting the request was unsuccessful`,
                    title: "Rejecting Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: values.requestId,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    changeAddDialogState = () => {
        this.setState(prevState => ({ addDialogOpen: !prevState.addDialogOpen }))
    }
    render() {
        const { loading, rows, loadingDialog, addDialogOpen } = this.state
        const {
            theme,
            orgName,
            currentUserInformation: { isAdmin }
        } = this.props
        const classes = getClasses({ theme })
        if (this.props.loading) {
            return <LoadingCard />
        }
        return (
            <React.Fragment>
                <Card>
                    <CardContent>
                        <LoadingDialog open={loadingDialog} loading={loadingDialog} title="Submitting action..." />
                        <Flex>
                            <Flex flex="1">
                                <Typography className={classes.title}>Parent Subsidiary</Typography>
                            </Flex>
                            {isAdmin && (
                                <Button className={classes.buttonStyle} onClick={this.changeAddDialogState}>
                                    + Add Relationship
                                </Button>
                            )}
                        </Flex>
                        <FlexAccordionTable
                            data={rows}
                            columns={this.buildColumns(PORTAL_TYPE, isAdmin)}
                            loading={loading}
                            defaultSort={tableSortDefault}
                            className={css(theme.typography.tableStyle)}
                            onRowSelection={this.onRowSelection}
                        />
                    </CardContent>
                </Card>
                <Formik
                    initialValues={{
                        ...relationshipDefaults
                    }}
                    validate={values => ({ ...parentSubsidiaryFieldValidation(values) })}
                    onSubmit={(values, { setSubmitting, setErrors, resetForm }) => {
                        setSubmitting(true)
                        // Assumes that on success component unmounts so no need to call setSubmitting
                        this.onSubmit(values, this.changeAddDialogState)
                            .then(() => {
                                setSubmitting(false)
                                resetForm()
                            })
                            .catch(() => {
                                setSubmitting(false)
                            })
                    }}
                    render={formikProps => (
                        <CustomRequestDialog
                            renderTitle={() => "Add Relationship"}
                            renderContent={() => (
                                <div style={{ width: "500px" }}>
                                    {console.log(formikProps.errors)}{" "}
                                    <ParentSubEditRow
                                        formikProps={formikProps}
                                        onSubmit={this.onSubmit}
                                        orgName={orgName}
                                        cancelAdd={this.changeAddDialogState}
                                    />
                                </div>
                            )}
                            onSubmit={formikProps.submitForm}
                            handleClose={this.changeAddDialogState}
                            open={addDialogOpen}
                        />
                    )}
                />
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(ParentSubsidaryTableContainer))
