// @flow
import React from "react"

import { withTheme } from "@material-ui/core"
import Select from "@material-ui/core/Select"
import FormControl from "@material-ui/core/FormControl"
import FormHelperText from "@material-ui/core/FormHelperText"
import TextField from "@material-ui/core/TextField"
import InputLabel from "@material-ui/core/InputLabel"
import OrgSearchComponent from "~/shared/OrgSearchComponent/OrgSearchComponent"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import MenuItem from "@material-ui/core/MenuItem"

import {
    relationshipTypes,
    Parent,
    Subsidiary,
    permissionTypes,
    permissionTypesSubsidiary,
    permissionTypesParent
} from "~/util/parentSubsidiary"

const getRelationshipTypes = (targetOrgName: string) => {
    if (targetOrgName) {
        // $FlowFixMe
        return relationshipTypes.map(type => ({ ...type, label: `${type.label} of ${targetOrgName}` }))
    }
    return relationshipTypes
}
const getPermissionTypes = (relationship: string, myOrg: string, otherOrg: string) => {
    if (relationship === Parent) {
        return permissionTypesParent.map(option => (
            <MenuItem key={option.key} value={option.value}>
                {`${myOrg} can ${option.label}`}
            </MenuItem>
        ))
    }
    if (relationship === Subsidiary) {
        return permissionTypesSubsidiary.map(option => (
            <MenuItem key={option.key} value={option.value}>
                {`${otherOrg} can ${option.label}`}
            </MenuItem>
        ))
    }
    return permissionTypes.map(option => (
        <MenuItem key={option.key} value={option.value}>
            {option.label}
        </MenuItem>
    ))
}

type Props = { formikProps: Object, cancelAdd: Function, onSubmit: Function, theme: Object, orgName: string }

const EditRow = ({ formikProps, cancelAdd, update, onSubmit, theme, orgName }: Props) => (
    <React.Fragment>
        <LoadingDialog
            open={formikProps.isSubmitting && !formikProps.isValidating && formikProps.isValid}
            loading={formikProps.isSubmitting}
            title="Submitting Parent Subsidiary request..."
        />
        <TextField
            style={{ flexDirection: "unset !important" }}
            placeholder="name"
            fullWidth
            label="My Organisation"
            name="name"
            id="name"
            value={orgName}
            helperText=" "
            disabled
        />

        <FormControl
            fullWidth
            error={formikProps.touched.organisation ? !!formikProps.errors.organisation : false}
            style={{ marginTop: "18px" }}
        >
            <OrgSearchComponent
                formik={formikProps}
                value={formikProps.values.organisation}
                name="organisation"
                placeholder="Create Relationship With*"
            />

            <FormHelperText>{formikProps.errors.organisation ? formikProps.errors.organisation : " "}</FormHelperText>
        </FormControl>
        <FormControl
            error={formikProps.touched.relationship ? !!formikProps.errors.relationship : false}
            style={{ flexDirection: "unset !important" }}
            fullWidth
        >
            <InputLabel htmlFor="roles">Relationship Type*</InputLabel>
            <Select
                value={formikProps.values.relationship}
                onChange={formikProps.handleChange}
                label="Relationship Type*"
                placeholder="Relationship Type"
                inputProps={{
                    name: "relationship",
                    id: "relationship"
                }}
            >
                <MenuItem value="">None</MenuItem>
                {getRelationshipTypes(
                    formikProps.values.organisation ? formikProps.values.organisation.entityName : ""
                ).map(option => (
                    <MenuItem key={option.value} value={option.value}>
                        {option.label}
                    </MenuItem>
                ))}
            </Select>
            <FormHelperText>{formikProps.errors.relationship ? formikProps.errors.relationship : " "}</FormHelperText>
        </FormControl>
        <FormControl
            error={formikProps.touched.permission ? !!formikProps.errors.permission : false}
            style={{ flexDirection: "unset !important" }}
            fullWidth
        >
            <InputLabel htmlFor="roles">Permissions*</InputLabel>

            <Select
                value={formikProps.values.permission}
                onChange={formikProps.handleChange}
                label="Permission*"
                placeholder="Permission"
                inputProps={{
                    name: "permission",
                    id: "permission"
                }}
            >
                <MenuItem value="">None</MenuItem>
                {getPermissionTypes(
                    formikProps.values.relationship,
                    orgName,
                    formikProps.values.organisation ? formikProps.values.organisation.entityName : ""
                )}
            </Select>
            <FormHelperText>{formikProps.errors.permission ? formikProps.errors.permission : " "}</FormHelperText>
        </FormControl>
    </React.Fragment>
)

export default withTheme()(EditRow)
