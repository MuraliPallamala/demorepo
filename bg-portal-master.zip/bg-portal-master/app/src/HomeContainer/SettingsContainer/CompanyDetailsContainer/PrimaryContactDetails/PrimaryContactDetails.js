// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import { css } from "emotion"
import { Grid, Flex } from "~/shared/layout"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
// import { dateToShortString } from "~/util/helpers/text"
import PhoneNumberTextMask from "~/shared/PhoneNumberTextMask"

const getClasses = ({ theme }) => {
    const title = css(theme.typography.cardTitle)
    const body2 = css(theme.typography.body2)
    const subheading = css(theme.typography.subheading)
    const textContainer = css({
        overflowWrap: "break-word"
    })
    return {
        title,
        body2,
        subheading,
        textContainer
    }
}

type Props = {
    contactValues: Object,
    theme: Object,
    loading: boolean,
    title: string
}

const PrimaryContactForm = ({ loading, theme, title, contactValues }: Props) => {
    const classes = getClasses({ theme })
    const { firstName, lastName, email, phone } = contactValues
    return loading ? (
        <LoadingCard />
    ) : (
        <Card>
            <CardContent>
                <Flex flex="1">
                    <Typography className={classes.title}>{title}</Typography>
                </Flex>
                <Flex>
                    <React.Fragment>
                        <Grid
                            width="100%"
                            gridGap="0un 3un"
                            gridTemplateColumns="repeat(3, minmax(180px, 20%))"
                            className={classes.textContainer}
                        >
                            <Typography className={classes.body2}> Name </Typography>
                            <Typography className={classes.body2}> Email </Typography>
                            <Typography className={classes.body2}> Phone </Typography>
                            <Typography
                                className={classes.subheading}
                                name="firstAndLastName"
                                label="First and Last Name"
                            >
                                {`${firstName} ${lastName}`}
                            </Typography>
                            <Typography className={classes.subheading} name="emailAddress" label="Email Address">
                                {email}
                            </Typography>
                            <Typography className={classes.subheading} name="phone" label="Telephone Number">
                                <PhoneNumberTextMask value={phone} />
                            </Typography>
                        </Grid>
                    </React.Fragment>
                </Flex>
            </CardContent>
        </Card>
    )
}

// {dateAdded ? <Typography className={classes.body2}> Added on </Typography> : <div />}
// {dateAdded ? (
//     <Typography className={classes.subheading}>{dateToShortString(dateAdded)}</Typography>
// ) : (
//     <div />
// )}
export default withTheme()(PrimaryContactForm)
