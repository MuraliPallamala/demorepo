// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import { Formik } from "formik"
import { Flex } from "~/shared/layout"
import OrganizationFieldSet, {
    validate as organizationFieldSetValidate
} from "~/shared/Fields/OrganizationDetails/OrganizationFieldSet"
import { onboardingDefaultValues } from "~/util/onboarding"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import OrganizationDetailFormDisabled from "./OrganizationDetailFormDisabled"

const getClasses = ({ theme }) => {
    const cardTitle = css(theme.typography.cardTitle)
    const formTitle = css(theme.typography.formTitle)
    const footerText = css(theme.typography.footerText)
    const button = css(theme.typography.button)
    const buttonContainer = css({
        marginTop: theme.spacing.unit,
        marginBottom: theme.spacing.unit
    })
    const pendingRequest = css(theme.typography.confirmMessage, {
        marginLeft: "50px"
    })
    const body1 = css(theme.typography.body1)
    return {
        formTitle,
        cardTitle,
        button,
        footerText,
        buttonContainer,
        body1,
        pendingRequest
    }
}

type Props = {
    initialValues: Object,
    orgUpdatedValues: Object,
    orgResubmitValues: Object,
    orgResubmit: boolean,
    onSubmit: Function,
    theme: Object,
    loading: boolean,
    pendingRequests: boolean,
    isAdmin: boolean,
    user: Object,
    edit: boolean,
    setEdit: Function,
    formReset: Function
}

type State = {}

class OrganizationDetailsFormContainer extends React.Component<Props, State> {
    static defaultProps = {
        initialValues: {}
    }

    getInitialValues = () => {
        const { orgUpdatedValues, orgResubmit, initialValues, pendingRequests, orgResubmitValues } = this.props
        if (orgResubmitValues && orgResubmit) {
            return {
                ...onboardingDefaultValues,
                ...orgResubmitValues
            }
        }
        if (pendingRequests) {
            return {
                ...onboardingDefaultValues,
                ...orgUpdatedValues
            }
        }
        return {
            ...onboardingDefaultValues,
            ...initialValues
        }
    }
    hasAccess = () => {
        const { user } = this.props
        if (user && user.entityType !== "APPLICANT_OR_BENEFICIARY") {
            return false
        }
        if (!user) {
            return false
        }
        return true
    }

    render() {
        const { onSubmit, orgUpdatedValues, initialValues, loading, theme, pendingRequests, isAdmin, edit } = this.props
        const classes = getClasses({ theme })
        const prefilled = true
        return loading ? (
            <LoadingCard />
        ) : (
            <Formik
                enableReinitialize
                initialValues={this.getInitialValues()}
                validate={values => ({
                    ...organizationFieldSetValidate({ values, prefilled })
                })}
                onSubmit={(values, { setSubmitting, setErrors }) => {
                    setSubmitting(true)
                    // Assumes that on success component unmounts so no need to call setSubmitting
                    onSubmit(values)
                        .then(data => {
                            this.props.setEdit()
                            setSubmitting(false)
                        })
                        .catch(() => {
                            setSubmitting(false)
                        })
                }}
                render={formikProps => (
                    <form onSubmit={formikProps.handleSubmit}>
                        <Card style={{ overflow: "visible" }}>
                            <CardContent>
                                <LoadingDialog
                                    open={formikProps.isSubmitting}
                                    loading={formikProps.isSubmitting}
                                    title="Submitting Confirmation request..."
                                />
                                <Flex>
                                    <Flex flex="1">
                                        <Typography hidden={!edit} className={classes.formTitle}>
                                            Organisation Details{" "}
                                            <span className={classes.pendingRequest} hidden={!pendingRequests}>
                                                {" "}
                                                Changes made to these details while a request is in progress will update
                                                the initial request.{" "}
                                            </span>
                                        </Typography>
                                        <Typography hidden={edit} className={classes.cardTitle}>
                                            Organisation Details{" "}
                                            <span className={classes.pendingRequest} hidden={!pendingRequests}>
                                                {" "}
                                                Changes submitted for review{" "}
                                            </span>
                                        </Typography>
                                    </Flex>
                                    {isAdmin && this.hasAccess() && (
                                        <Flex>
                                            <Button
                                                className={classes.button}
                                                disabled={loading}
                                                hidden={edit}
                                                onClick={() => this.props.setEdit()}
                                            >
                                                Edit
                                            </Button>
                                            <Button
                                                disabled={formikProps.isSubmitting}
                                                className={classes.button}
                                                type="submit"
                                                hidden={!edit}
                                            >
                                                Save
                                            </Button>
                                            <Button
                                                className={classes.button}
                                                onClick={() => this.props.formReset(formikProps.handleReset)}
                                                hidden={!edit}
                                            >
                                                Cancel
                                            </Button>
                                        </Flex>
                                    )}
                                </Flex>
                                <div hidden={!edit}>
                                    <Typography className={classes.body1}>
                                        Please complete the following details.
                                    </Typography>
                                </div>
                                <div hidden={!edit}>
                                    <OrganizationFieldSet prefilled formik={formikProps} />
                                </div>
                                <div hidden={edit}>
                                    <OrganizationDetailFormDisabled
                                        originalValues={initialValues}
                                        orgUpdatedValues={orgUpdatedValues}
                                        pendingRequests={pendingRequests}
                                    />
                                </div>
                            </CardContent>
                        </Card>
                    </form>
                )}
            />
        )
    }
}

export default withTheme()(OrganizationDetailsFormContainer)
