// @flow

import React from "react"
import Typography from "@material-ui/core/Typography"
import api from "~/util/api"
import { withTheme } from "@material-ui/core/styles"
import { Grid } from "~/shared/layout"
import { css } from "emotion"
import { addressToString } from "~/util/helpers/text"

type Props = {
    orgUpdatedValues: Object,
    theme: Object,
    originalValues: Object,
    pendingRequests: boolean
}

type State = {
    keyLoaded: boolean,
    key: string
}

const getClasses = ({ theme }) => {
    const body2 = css(theme.typography.body2)
    const subheading = css(theme.typography.subheading, { overflowWrap: "break-word" })
    const updating = css(theme.typography.body2, { color: theme.palette.common.defaultRed })
    return {
        body2,
        subheading,
        updating
    }
}
const Updating = withTheme()(({ theme, newValue, ...props }) => {
    const classes = getClasses({ theme })
    return (
        <span>
            <span className={classes.updating} {...props}>
                Updating to:
            </span>
            {` ${newValue}`}
        </span>
    )
})

class OrganizationDetailFormDisabled extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            keyLoaded: false,
            key: ""
        }
    }

    componentDidMount() {
        api.settings.getOrgSettings().then(res => this.setState({ keyLoaded: true, key: res.data.key }))
    }
    isUpdated = (compareA, compareB) => {
        if (compareA !== compareB) {
            return true
        }
        return false
    }

    render() {
        const { orgUpdatedValues, theme, originalValues, pendingRequests } = this.props
        const { key, keyLoaded } = this.state
        const classes = getClasses({ theme })
        const updatingName = this.isUpdated(orgUpdatedValues.entityName, originalValues.entityName)
        const updatingAddress = this.isUpdated(addressToString(orgUpdatedValues), addressToString(originalValues))
        return (
            <React.Fragment>
                <Grid gridGap="1un" gridTemplateColumns="20% 40% 20%">
                    <Typography className={classes.body2}> Legal Entity Name </Typography>
                    <Typography className={classes.body2}> Registered Address </Typography>
                    <Typography className={classes.body2}>
                        {originalValues.businessID.replace(/\s/g, "") === 9 ? "ACN" : "ABN"}{" "}
                    </Typography>
                    <Typography className={classes.subheading} name="entityName" label="Legal Entity Name">
                        {originalValues.entityName}
                    </Typography>
                    <Typography className={classes.subheading} name="streetAddress" label="Street Address">
                        {addressToString(originalValues)}
                    </Typography>
                    <Typography className={classes.subheading} name="businessID" label="ABN/ACN">
                        {originalValues.businessID}
                    </Typography>
                    <Typography className={classes.body2}>
                        {pendingRequests && updatingName && <Updating newValue={orgUpdatedValues.entityName} />}
                    </Typography>
                    <Typography className={classes.body2}>
                        {pendingRequests && updatingAddress && (
                            <Updating newValue={addressToString(orgUpdatedValues)} />
                        )}
                    </Typography>
                    <Typography className={classes.body2} />
                    {keyLoaded && <Typography className={classes.body2} css={{ gridColumn: "1/4" }} />}
                    {keyLoaded && (
                        <Typography className={classes.body2} css={{ gridColumn: "1/4" }}>
                            Your Organisation Login
                        </Typography>
                    )}
                    {keyLoaded && (
                        <Typography className={classes.subheading} css={{ gridColumn: "1/4" }}>
                            {`${window.location.protocol}//${window.location.hostname}${
                                window.location.port !== "" ? `:${window.location.port}` : ""
                            }/login/${key}`}
                        </Typography>
                    )}
                </Grid>
            </React.Fragment>
        )
    }
}

export default withTheme()(OrganizationDetailFormDisabled)
