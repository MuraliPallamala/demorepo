// @flow
/* eslint-disable react/sort-comp */

import * as React from "react"
import Typography from "@material-ui/core/Typography"
import Card from "@material-ui/core/Card"
import Select from "@material-ui/core/Select"
import FormControl from "@material-ui/core/FormControl"
import InputLabel from "@material-ui/core/InputLabel"
import CardContent from "@material-ui/core/CardContent"
import { withTheme } from "@material-ui/core/styles"
import MenuItem from "@material-ui/core/MenuItem"
import { css } from "emotion"
import withError from "~/shared/Context/ErrorDialog/withError"
import api from "~/util/api"
import axios from "axios"
import { Grid, Block, Flex, Row } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"
import Loading from "~/shared/Loading"
import CardErrorBoundary from "~/shared/CardErrorBoundary"
import {
    mapOrgData,
    mapPrimaryContact,
    mapValuesToRequest,
    mapRequestData,
    mapHistoryDataToValues
} from "~/util/companyDetails"
import MyDatePicker from "~/shared/DatePicker/DatePicker"
import TimelineContainer from "~/shared/TimelineContainer/TimelineContainer"
import DownloadButton from "~/shared/DownloadButton"
import OrganizationDetailsFormContainer from "./OrganizationDetailsForm/OrganizationDetailsFormContainer"
import PrimaryContactDetails from "./PrimaryContactDetails/PrimaryContactDetails"
import ParentSubsidiaryTableContainer from "./ParentSubsidiaryTableContainer/ParentSubsidiaryTableContainer"

const getClasses = ({ theme }) => {
    const title = css(theme.typography.cardTitle)
    const iconStyle = css({
        color: theme.palette.common.lightBlue
    })
    const datePicker = css({
        overflow: "visible",
        marginLeft: "15px",
        paddingBottom: "8px",
        width: "170px"
    })
    const selectStyle = css({
        minWidth: "150px"
    })
    return { title, iconStyle, datePicker, selectStyle }
}
type Props = {
    // match: Object,
    history: Object,
    theme: Object,
    user: Object,
    handleErrorOpen: Function
}
type State = {
    orgInitialValues: Object,
    orgUpdatedValues: Object,
    orgResubmitValues: Object,
    primaryInitialValues: Object,
    loading: boolean,
    pendingRequests: boolean,
    update: number,
    requestId: string,
    timelineData: Array<Object>,
    dialogOpen: boolean,
    dialogLoading: boolean,
    loadingOrgDetails: boolean,
    edit: boolean,
    orgResubmit: boolean,
    startDate: any,
    endDate: any,
    queryString: string,
    topic: string
}
const topicList = [
    { value: "", label: "All", portal: ["issuer", "user", "admin"] },
    { value: "user", label: "User Actions", portal: ["issuer", "user", "admin"] },
    { value: "org", label: "Organisation Actions", portal: ["issuer", "user", "admin"] },
    { value: "gx", label: "Guarantee Related Actions", portal: ["issuer", "user"] }
]

class CompanyDetailsContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            orgInitialValues: {
                entityName: "",
                streetAddress: "",
                addressLocality: "",
                addressRegion: "",
                addressCountry: { value: "Australia", label: "Australia" },
                postalCode: "",
                postOfficeBoxNumber: "",
                businessID: ""
            },
            orgResubmitValues: {
                entityName: "",
                streetAddress: "",
                addressLocality: "",
                addressRegion: "",
                addressCountry: { value: "Australia", label: "Australia" },
                postalCode: "",
                postOfficeBoxNumber: "",
                businessID: ""
            },
            orgUpdatedValues: {
                entityName: "",
                streetAddress: "",
                addressLocality: "",
                addressRegion: "",
                addressCountry: { value: "Australia", label: "Australia" },
                postalCode: "",
                postOfficeBoxNumber: "",
                businessID: ""
            },
            primaryInitialValues: {
                firstName: "",
                lastName: "",
                email: "",
                phone: "",
                mobile: "",
                dateAdded: ""
            },
            loading: true,
            loadingOrgDetails: false,
            pendingRequests: false,
            update: 0,
            requestId: "",
            timelineData: [],
            dialogOpen: false,
            dialogLoading: false,
            startDate: null,
            endDate: null,
            edit: false,
            orgResubmit: false,
            queryString: "",
            topic: ""
        }
    }
    componentDidMount() {
        this.getCurrentOrgDetails()
        this.getTimelineData("")
    }
    componentDidUpdate(prevProps, prevState) {
        if (
            prevState.topic !== this.state.topic ||
            prevState.startDate !== this.state.startDate ||
            prevState.endDate !== this.state.endDate
        ) {
            const { topic, startDate, endDate } = this.state

            const mappedValues = { after: startDate, before: endDate, topic }
            let queryString = Object.keys(mappedValues)
                .filter(key => mappedValues[key])
                .map(key => `${key}=${mappedValues[key]}`)
                .join("&")
            queryString = `?${queryString}`
            this.setState({ queryString })
            this.getTimelineData(queryString)
        }
    }
    getCurrentOrgDetails = () =>
        api.settings
            .getCurrentOrg()
            .then(({ data }) => {
                this.setState({
                    orgInitialValues: mapOrgData(data),
                    primaryInitialValues: mapPrimaryContact(data.contacts)
                })
                this.getConfirmedRequests()
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Get Current Organisation Error`,
                    title: "Get Current Organisation Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })

    getConfirmedRequests = () => {
        api.settings
            .getConfirmedChangeRequests()
            .then(({ data }) => {
                if (data.result.length >= 1 && data.result[0].requestType === "CHANGE_DETAILS") {
                    const ChangeData = data.result[0]
                    let Payload = ChangeData.payload
                    // Goes through actions to get most up to date information to render form (Being the last recall action)
                    if (ChangeData.actions.length >= 1) {
                        for (let i = 0; i < ChangeData.actions.length; i++) {
                            if (ChangeData.actions[i] && ChangeData.actions[i].actionType === "RECALL") {
                                Payload = ChangeData.actions[i].payload
                            }
                        }
                    }
                    Payload.businessID = this.state.orgInitialValues.businessID
                    const formattedData = mapRequestData(Payload)
                    const requestId = ChangeData.id
                    this.setState({
                        pendingRequests: true,
                        orgUpdatedValues: formattedData,
                        loading: false,
                        requestId,
                        loadingOrgDetails: false
                    })
                } else {
                    this.setState({
                        loading: false,
                        pendingRequests: false,
                        loadingOrgDetails: false
                    })
                }
                this.getTimelineData("")
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Get Confirmed Requests Error`,
                    title: "Error getting Confirmed Requests",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    getTimelineData = (queryString: string) => {
        const { user } = this.props
        let sortedFilteredTimelineData = []
        // Joins the array of both the audit trail and requests end point to construct the required timeline
        api.general.multipleApis([api.audit.myOrgAudit(queryString), api.settings.getRequests()]).then(
            axios.spread((orgAudit, requests) => {
                // Filtering is required for the date ranges and for requests that are also audit events
                const filteredRequests = requests.data.result.filter(request => {
                    // Requests that are also audit events should not be displayed
                    if (
                        (request.status === "CONFIRMED" && request.requestType === "CHANGE_DETAILS") ||
                        (request.status === "ABANDONED" && request.requestType === "CHANGE_DETAILS") ||
                        (request.orgId === user.primaryOrgId &&
                            request.requestType === "LINK_ORGANIZATION" &&
                            request.status !== "REJECTED" &&
                            request.status !== "APPROVED") ||
                        (request.orgId === user.primaryOrgId &&
                            request.requestType === "UNLINK_ORGANIZATION" &&
                            request.status !== "REJECTED" &&
                            request.status !== "APPROVED")
                    ) {
                        return false
                    }
                    // Client side filtering is required for the requests end point as the api does not support a before/after
                    let isInRange = true
                    if (this.state.startDate) {
                        isInRange =
                            new Date(request.updatedAt || request.createdAt) - new Date(this.state.startDate) > 0
                        if (!isInRange) {
                            return isInRange
                        }
                    }
                    if (this.state.endDate) {
                        isInRange = new Date(this.state.endDate) - new Date(request.updatedAt || request.createdAt) > 0
                        if (!isInRange) {
                            return isInRange
                        }
                    }
                    return isInRange
                })
                // changes the created at to equal the updatedAt as that is what it is being sorted by
                const mappedRequests = filteredRequests.map(item => {
                    const updatedItem = item
                    updatedItem.createdAt = updatedItem.updatedAt ? updatedItem.updatedAt : updatedItem.createdAt
                    return updatedItem
                })
                const timelineData = orgAudit.data.result.concat(mappedRequests)
                sortedFilteredTimelineData = this.sortAndFilter(timelineData)
                this.setState({ timelineData: sortedFilteredTimelineData })
            })
        )
    }
    setDates = (name, date: any) => {
        this.setState({ [name]: date })
    }
    submitForm = values => {
        const submitValue = mapValuesToRequest(values)
        this.setState({ loadingOrgDetails: true })
        if (this.state.pendingRequests) {
            return api.settings
                .reacallRequest(this.state.requestId, "RECALL", submitValue)
                .then(data => {
                    this.getConfirmedRequests()
                })
                .catch(err => {
                    this.props.handleErrorOpen({
                        errorMessage: `Recall Request Error`,
                        title: "Error Recalling Change Request",
                        error: err,
                        extraDetails: {
                            Info: err.info,
                            CurrentUrl: this.props.history.location.pathname,
                            ErrorResponse: err,
                            Payload: { id: this.state.requestId, type: "RECALL", submitValue }
                        }
                    })
                    throw err
                })
        }
        return api.settings
            .changeRequest(submitValue, "CHANGE_DETAILS")
            .then(data => {
                this.getConfirmedRequests()
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Change Details Request Failed`,
                    title: "Error Changing Details",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err,
                        Payload: submitValue
                    }
                })
                throw err
            })
    }
    handleChange = event => {
        this.setState({ [event.target.name]: event.target.value })
    }
    cancelRequest = (requestId: string) => {
        this.setState({ dialogLoading: true, loading: true })
        api.settings
            .submitRequest(requestId, "CANCEL")
            .then(data => {
                this.getCurrentOrgDetails().then(() => this.setState({ loading: false }))
                this.getTimelineData("")
                this.setState(prevState => ({ dialogLoading: false, dialogOpen: false, update: prevState.update + 1 }))
            })
            .catch(err => {
                // :et timeline Handle it
                throw err
            })
    }
    closeDialog = () => {
        this.setState({ dialogOpen: false })
    }
    openDialig = () => {
        this.setState({ dialogOpen: true })
    }
    companyDetailsActionHandler = (historyItem: Object) => {
        this.setState({ requestId: historyItem.id })
        if (historyItem.action === "CANCEL_REQUEST") {
            return this.openDialig()
        } else if (historyItem.action === "RESUBMIT_REQUEST") {
            const formattedValues = mapHistoryDataToValues(historyItem.payload)
            formattedValues.businessID = this.state.orgInitialValues.businessID
            this.setState(
                {
                    orgResubmitValues: formattedValues,
                    edit: true,
                    orgResubmit: true
                },
                () => {
                    // $FlowFixMe
                    document.getElementById("entity-name").focus()
                }
            )
            window.scrollTo(0, 0)
            return console.log("WoooH :D ", mapHistoryDataToValues(historyItem.payload))
        }
        return () => console.log("Well that wasnt right")
    }
    setEdit = () => {
        if (this.state.edit === false) {
            this.setState({
                edit: true
            })
        } else {
            this.setState({
                edit: false
            })
        }
    }
    sortAndFilter = (timelineData: Array<Object>) => {
        // Slow Sort, enhancement change to a merge :P
        const sortedData = timelineData.sort((a, b) => {
            const dateA = new Date(a.updatedAt ? a.updatedAt : a.createdAt)
            const dateB = new Date(b.updatedAt ? b.updatedAt : b.createdAt)
            return dateB - dateA
        })
        return sortedData
    }

    formReset = func => {
        func()
        this.setState({
            edit: false,
            orgResubmitValues: {
                entityName: "",
                streetAddress: "",
                addressLocality: "",
                addressRegion: "",
                addressCountry: { value: "Australia", label: "Australia" },
                postalCode: "",
                postOfficeBoxNumber: "",
                businessID: ""
            },
            orgResubmit: false
        })
    }
    render() {
        const { theme, history, user } = this.props
        const classes = getClasses({ theme })
        const {
            orgInitialValues,
            orgUpdatedValues,
            orgResubmitValues,
            primaryInitialValues,
            update,
            loading,
            pendingRequests,
            timelineData,
            dialogOpen,
            requestId,
            dialogLoading,
            loadingOrgDetails,
            edit,
            orgResubmit,
            queryString,
            topic
        } = this.state
        return (
            <React.Fragment>
                <PageTitle path="Settings/" title="Organisation Details and Primary User" theme={theme} />

                <Block padding="3un">
                    <Grid gridGap="3un">
                        <React.Fragment>
                            <CardErrorBoundary message="Error retrieving organisation details">
                                <OrganizationDetailsFormContainer
                                    initialValues={orgInitialValues}
                                    orgUpdatedValues={orgUpdatedValues}
                                    orgResubmitValues={orgResubmitValues}
                                    orgResubmit={orgResubmit}
                                    onSubmit={values => this.submitForm(values)}
                                    loading={loading || loadingOrgDetails}
                                    pendingRequests={pendingRequests}
                                    isAdmin={user.isAdmin}
                                    user={user}
                                    edit={edit}
                                    setEdit={this.setEdit}
                                    formReset={this.formReset}
                                />
                            </CardErrorBoundary>
                            <CardErrorBoundary message="Error retrieving primary contact details">
                                <PrimaryContactDetails
                                    contactValues={primaryInitialValues}
                                    loading={loading}
                                    title="Primary Contact"
                                    dateAdded={false}
                                />
                            </CardErrorBoundary>

                            {PORTAL_TYPE !== "issuer" && PORTAL_TYPE !== "admin" && (
                                <CardErrorBoundary message="Error retrieving parent subsidiary relationships">
                                    <ParentSubsidiaryTableContainer
                                        updateTimeline={this.getTimelineData}
                                        orgName={user.entityName}
                                        currentUserInformation={user}
                                        loading={loading}
                                        history={history}
                                        update={update}
                                    />
                                </CardErrorBoundary>
                            )}

                            {timelineData ? ( // removed check for length bigger than 0 - resulted in the timeline disappearing altogether. the timelineContainer seems to handle this case well enough.
                                <CardErrorBoundary message="Error retrieving events timeline">
                                    <Card>
                                        <CardContent>
                                            <Row flexWrap="wrap" marginBottom="24px">
                                                <Row flex={1}>
                                                    <Typography className={classes.title}>Events Recorded</Typography>
                                                </Row>
                                                <Row flex={1} justifyContent="flex-end">
                                                    <FormControl>
                                                        <InputLabel htmlFor="topic">Topics</InputLabel>

                                                        <Select
                                                            value={topic}
                                                            name="topic"
                                                            id="topic"
                                                            onChange={this.handleChange}
                                                            inputProps={{
                                                                name: "topic",
                                                                id: "topic"
                                                            }}
                                                            className={classes.selectStyle}
                                                        >
                                                            {topicList
                                                                .filter(t => t.portal.includes(PORTAL_TYPE))
                                                                .map(aTopic => (
                                                                    <MenuItem key={aTopic.value} value={aTopic.value}>
                                                                        {aTopic.label}
                                                                    </MenuItem>
                                                                ))}
                                                        </Select>
                                                    </FormControl>
                                                    <MyDatePicker
                                                        fieldName="startDate"
                                                        label="Beginning Date"
                                                        dateValue={this.state.startDate}
                                                        setDate={this.setDates}
                                                        className={classes.datePicker}
                                                    />
                                                    <MyDatePicker
                                                        fieldName="endDate"
                                                        label="Ending Date"
                                                        dateValue={this.state.endDate}
                                                        setDate={this.setDates}
                                                        className={classes.datePicker}
                                                    />
                                                    <DownloadButton
                                                        downloadCsv={api.audit.downloadOrgAudit(
                                                            user.primaryOrgId,
                                                            queryString
                                                        )}
                                                    />
                                                </Row>
                                            </Row>
                                            <TimelineContainer
                                                data={timelineData}
                                                actionFunction={this.companyDetailsActionHandler}
                                            />
                                        </CardContent>
                                    </Card>
                                </CardErrorBoundary>
                            ) : null}
                        </React.Fragment>
                    </Grid>
                </Block>
                <CustomRequestDialog
                    renderTitle={() => (dialogLoading ? "Cancelling Request" : "Cancel Request")}
                    renderContent={() =>
                        dialogLoading ? (
                            <Flex justifyContent="center">
                                <Loading show />
                            </Flex>
                        ) : (
                            <Typography>Are you sure you want to cancel this request?</Typography>
                        )
                    }
                    onSubmit={() => this.cancelRequest(requestId)}
                    handleClose={this.closeDialog}
                    open={dialogOpen}
                    submitting={dialogLoading}
                    cancelText="NO"
                    submitText="YES"
                />
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(CompanyDetailsContainer))
