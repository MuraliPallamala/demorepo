// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import Typography from "@material-ui/core/Typography"
import CardContent from "@material-ui/core/CardContent"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import { Grid, Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import CardErrorBoundary from "~/shared/CardErrorBoundary"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import { mapUsers } from "~/util/manageUser/manageUser"
import sortByDate from "~/util/helpers/sortByDate"
import PhoneNumberTextMask from "~/shared/PhoneNumberTextMask"

type Props = {
    history: Object,
    theme: Object,
    handleErrorOpen: Function
}

type State = {
    rows: Array<Object>,
    loading: boolean
}

const getClasses = theme => {
    const tableTitle = css(theme.typography.tableTitle)
    const textStyle = css({ color: theme.palette.common.darkBlue })
    return {
        tableTitle,
        textStyle
    }
}

const columns = [
    { columnHeader: { dataName: "formattedStatus", displayName: "Status" }, sort: true },
    { columnHeader: { dataName: "name", displayName: "Name" }, sort: true },
    { columnHeader: { dataName: "email", displayName: "Email" }, sort: true },
    {
        columnHeader: { dataName: "phone", displayName: "Phone" },
        cellValue: row => (
            <Typography>
                <PhoneNumberTextMask value={row.phone} />
            </Typography>
        ),
        sort: true
    },
    { columnHeader: { dataName: "added", displayName: "Added On" }, sort: (a, b) => sortByDate(a, b, "added") }
]
class AdministratorDetailsContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            rows: [],
            loading: true
        }
    }
    componentDidMount() {
        this.getAllUsers()
    }
    getAllUsers = () => {
        api.manageUsers
            .getAllUsers("")
            .then(({ data }) => {
                const admins = data.result.filter(row => row.roles.includes("ADMIN"))
                this.setState({ rows: mapUsers(admins), loading: false })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting all users/Roles was unsuccessful`,
                    title: "Manage Users Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    makeAdmin = (userId: string) => api.manageUsers.updateAdminStatus(userId, "ADMIN")

    removeAdmin = (userId: string) => api.manageUsers.updateAdminStatus(userId, "")

    render() {
        const { theme } = this.props
        const { loading, rows } = this.state
        const classes = getClasses(theme)
        return (
            <React.Fragment>
                <PageTitle path="Settings/" title="Administrator Details" theme={theme} />
                <Block padding="3un">
                    <CardErrorBoundary message="Error retrieving administrators">
                        <Card>
                            <CardContent>
                                <Grid gridGap="3un">
                                    <Typography className={classes.tableTitle}> List of Administrators </Typography>
                                    <FlexAccordionTable
                                        columns={columns}
                                        data={rows}
                                        loading={loading}
                                        className={css(theme.typography.tableStyle)}
                                    />
                                </Grid>
                            </CardContent>
                        </Card>
                    </CardErrorBoundary>
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(AdministratorDetailsContainer))
