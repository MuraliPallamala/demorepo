// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import { Formik } from "formik"
import { Grid, Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import LoadingWithErrorDialog from "~/shared/Dialogs/LoadingWithErrorDialog"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import TwoFactorCard from "./TwoFactorCards/TwoFactorCard"
import AuthenticateCard from "./TwoFactorCards/AuthenticateCard"

type Props = {
    match: Object,
    history: Object,
    theme: Object,
    handleErrorOpen: Function
}
type State = {
    enabled: boolean,
    superSecretKey: string,
    initialValues: Object,
    codeType: boolean,
    encodedSecretKey: string,
    loading: boolean
}

const twoFactorValidation = (values: Object) => {
    const errors = {}
    if (!values.code) {
        errors.code = "Required"
    } else if (values.code.length !== 6) {
        errors.code = "Code of Length 6 is required"
    }

    return errors
}

const twoFactorDefaultValues = {
    superSecretKey: "",
    code: ""
}

class TwoFactorContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            enabled: false,
            superSecretKey: "",
            initialValues: {},
            codeType: true,
            encodedSecretKey: "",
            loading: true
        }
    }
    componentDidMount = () => {
        this.getProfileSeed()
    }

    onSubmit = (values: Object) => {}
    getProfileSeed = () => {
        api.twofactor
            .getProfileSeed()
            .then(({ data }) => {
                this.setState({
                    loading: false,
                    enabled: data.enabled,
                    encodedSecretKey: data.totpSecretEncoded,
                    superSecretKey: data.totpSecretQrCode
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Get Profile Seed Error`,
                    title: "Error Getting Profile Seed",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
            })
    }
    submitProfileSeed = (token: string, secret: string) =>
        api.twofactor.putProfileSeed({ token, secret }).catch(err => {
            err.CustomMessage = "Check your Authenticator app and make sure you are using the correct code"
            throw err
        })

    handleChange = (event: Object, name: string) => {
        if (!event.target.checked) {
            api.twofactor
                .deleteProfileSeed()
                .then(({ data }) => {
                    this.setState({
                        enabled: data.enabled
                    })
                })
                .catch(err => {
                    this.props.handleErrorOpen({
                        errorMessage: `Get Profile Seed Error`,
                        title: "Error Getting Profile Seed",
                        error: err,
                        extraDetails: {
                            Info: err.info,
                            CurrentUrl: this.props.history.location.pathname,
                            ErrorResponse: err
                        }
                    })
                })
        }
        this.setState({ [name]: event.target.checked })
    }
    handleTypeChange = (event: Object, name) => {
        this.setState({ [name]: event.target.checked })
    }

    render() {
        const { enabled, superSecretKey, initialValues, codeType, encodedSecretKey, loading } = this.state
        return (
            <React.Fragment>
                <PageTitle path="Settings/" title="Two-Factor Settings" />
                <Block padding="3un">
                    {loading ? (
                        <LoadingCard />
                    ) : (
                        <Grid gridGap="1un">
                            <TwoFactorCard enabled={enabled} handleChange={this.handleChange} />
                            <Formik
                                initialValues={{
                                    ...twoFactorDefaultValues,
                                    ...initialValues
                                }}
                                validate={values => ({ ...twoFactorValidation(values) })}
                                onSubmit={(values, { setSubmitting, setErrors, setStatus }) => {
                                    setStatus()
                                    setSubmitting(true)
                                    this.submitProfileSeed(values.code, encodedSecretKey)
                                        .then(() => setSubmitting(false))
                                        .catch(err => {
                                            setStatus(err)
                                            setSubmitting(false)
                                        })
                                }}
                                render={formikProps => (
                                    <React.Fragment>
                                        <LoadingWithErrorDialog
                                            open={formikProps.isSubmitting}
                                            loading={formikProps.isSubmitting}
                                            isError={formikProps.status ? !!formikProps.status : false}
                                            errorMessage={formikProps.status ? formikProps.status.CustomMessage : ""}
                                            errorTitle="Error setting profile seed"
                                            error={formikProps.status ? formikProps.status : {}}
                                            extraDetails={{
                                                Info: formikProps.status ? formikProps.status.info : "",
                                                CurrentUrl: this.props.history.location.pathname,
                                                ErrorResponse: formikProps.status,
                                                Payload: formikProps.status ? formikProps.status.Payload : ""
                                            }}
                                            title="Verifying Code"
                                        />
                                        <AuthenticateCard
                                            superSecretKey={superSecretKey}
                                            formikProps={formikProps}
                                            enabled={enabled}
                                            codeType={codeType}
                                            encodedSecretKey={encodedSecretKey}
                                            handleCodeTypeChange={this.handleTypeChange}
                                        />
                                    </React.Fragment>
                                )}
                            />
                        </Grid>
                    )}
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(TwoFactorContainer))
