// @flow
import React from "react"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Switch from "@material-ui/core/Switch"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import { Grid, Flex } from "~/shared/layout"

const getClasses = ({ theme }) => {
    const title = css(theme.typography.cardTitle)

    const body2 = css(theme.typography.body2)
    const subheading = css(theme.typography.subheading)
    return {
        body2,
        subheading,
        title
    }
}
type Props = {
    theme: Object,
    enabled: boolean,
    handleChange: Function
}

const TwoFactorCard = ({ theme, enabled, handleChange }: Props) => {
    const classes = getClasses({ theme })
    return (
        <Card>
            <CardContent>
                <Flex>
                    <Flex flex="1">
                        <Grid>
                            <Typography className={classes.title}> Configure Two Factor </Typography>
                            <Typography> Using Two Factor will increase your security </Typography>
                        </Grid>
                    </Flex>
                    <Flex>
                        <FormControlLabel
                            control={
                                <Switch
                                    checked={enabled}
                                    onChange={event => handleChange(event, "enabled")}
                                    value="enabled"
                                />
                            }
                            label={enabled ? "On" : "Off"}
                        />
                    </Flex>
                </Flex>
            </CardContent>
        </Card>
    )
}

export default withTheme()(TwoFactorCard)
