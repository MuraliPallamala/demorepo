// @flow

import * as React from "react"
import api from "~/util/api"
import { withTheme } from "@material-ui/core/styles"
import { Block, Grid } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import withError from "~/shared/Context/ErrorDialog/withError"
import OrgDetailsMemberCards from "./OrgDetailsMemberCards"

type Props = {
    theme: Object,
    match: Object,
    handleErrorOpen: Function,
    history: Object
}

type State = {
    loading: boolean,
    orgDetails: Object,
    primaryContactValues: Object,
    historyRequests: Array<Object>,
    adminContactValues: Object,
    startDate: any,
    endDate: any,
    queryString: string,
    topic: string
}

class MemberOrganizationDetailsContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            loading: true,
            orgDetails: {},
            primaryContactValues: {},
            adminContactValues: {},
            historyRequests: [],
            startDate: null,
            endDate: null,
            queryString: "",
            topic: ""
        }
    }

    componentDidMount() {
        this.getAuditData("")
        api.organisations
            .getOrganisations(this.props.match.params.orgID)
            .then(({ data }) => {
                let primaryContact = {}
                let adminContact = {}
                if (data.profile.contacts) {
                    for (let i = 0; i < data.profile.contacts.length; i++) {
                        if (data.profile.contacts[i].roles.includes("PRIMARY")) {
                            primaryContact = data.profile.contacts[i]
                            break
                        }
                    }
                    for (let i = 0; i < data.profile.contacts.length; i++) {
                        if (data.profile.contacts[i].roles.includes("ADMIN")) {
                            adminContact = data.profile.contacts[i]
                            break
                        }
                    }
                    this.setState({
                        orgDetails: data.profile,
                        primaryContactValues: {
                            firstName: primaryContact.firstName,
                            lastName: primaryContact.lastName,
                            email: primaryContact.email,
                            phone: primaryContact.phone,
                            dateAdded: data.createdAt
                        },
                        adminContactValues: {
                            firstName: adminContact.firstName,
                            lastName: adminContact.lastName,
                            email: adminContact.email,
                            phone: adminContact.phone,
                            dateAdded: data.createdAt
                        }
                    })
                } else {
                    this.setState({
                        orgDetails: data.profile,
                        loading: false
                    })
                }
            })
            .catch(err => console.log(`error ${err}`))
            .then(() => {
                this.setState({ loading: false })
            })
    }
    componentDidUpdate(prevProps, prevState) {
        if (
            prevState.topic !== this.state.topic ||
            prevState.startDate !== this.state.startDate ||
            prevState.endDate !== this.state.endDate
        ) {
            const { topic, startDate, endDate } = this.state

            const mappedValues = { after: startDate, before: endDate, topic }
            let queryString = Object.keys(mappedValues)
                .filter(key => mappedValues[key])
                .map(key => `${key}=${mappedValues[key]}`)
                .join("&")
            queryString = `?${queryString}`
            this.setState({ queryString })
            this.getAuditData(queryString)
        }
    }

    getAuditData = (queryString: string) => {
        api.audit
            .getOrgAudit(this.props.match.params.orgID, queryString)
            .then(({ data }) => {
                this.setState({ historyRequests: data.result.reverse() })
            })
            .catch(err => {
                throw err
            })
    }
    setDates = (name, date: any) => {
        this.setState({ [name]: date })
    }
    handleChange = event => {
        this.setState({ [event.target.name]: event.target.value })
    }

    render() {
        const {
            theme,
            match: {
                params: { orgID }
            }
        } = this.props
        const {
            loading,
            orgDetails,
            primaryContactValues,
            adminContactValues,
            historyRequests,
            startDate,
            endDate,
            queryString,
            topic
        } = this.state
        console.log(historyRequests)
        return (
            <React.Fragment>
                <PageTitle link="/organisations" theme={theme} path="Organisations/" title="Details" />
                <Block padding="0un 3un 3un 3un">
                    <Grid gridGap="3un">
                        <OrgDetailsMemberCards
                            theme={theme}
                            orgID={orgID}
                            primaryContactValues={primaryContactValues}
                            adminContactValues={adminContactValues}
                            orgDetails={orgDetails}
                            loading={loading}
                            setDates={this.setDates}
                            handleChange={this.handleChange}
                            startDate={startDate}
                            endDate={endDate}
                            topic={topic}
                            queryString={queryString}
                            historyRequests={historyRequests}
                        />
                    </Grid>
                </Block>
            </React.Fragment>
        )
    }
}

export default withTheme()(withError(MemberOrganizationDetailsContainer))
