// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import CardActions from "@material-ui/core/CardActions"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import Select from "@material-ui/core/Select"
import FormControl from "@material-ui/core/FormControl"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import { css } from "emotion"
import CardContent from "@material-ui/core/CardContent"
import { Grid, Flex } from "~/shared/layout"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import { addressToString } from "~/util/helpers/text"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import Checkbox from "@material-ui/core/Checkbox"
import DownloadButton from "~/shared/DownloadButton"
import OrganizationDetailsFormContainer from "~/HomeContainer/SettingsContainer/CompanyDetailsContainer/PrimaryContactDetails/PrimaryContactDetails"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import Timeline from "~/shared/TimelineContainer/TimelineContainer"
import api from "~/util/api"
import MyDatePicker from "~/shared/DatePicker/DatePicker"

const getClasses = ({ theme, verified }) => {
    const loadingContainer = css({
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "inherit"
    })

    const dividerStyle = css({
        width: "80%"
    })
    const buttonStyle = css(theme.typography.button)
    const body2 = css(theme.typography.body2)
    const subheading = css(theme.typography.subheading)
    const button = css(theme.typography.button)
    const updated = css({ color: theme.palette.common.defaultRed, marginRight: "1rem" })
    const buttonContainer = css({
        textAlign: "right",
        marginTop: theme.spacing.unit * 2
    })
    const title = css(theme.typography.cardTitle)
    const margin = css({ margin: ".5rem" })
    const submitActionsTitle = css({
        display: "inline",
        fontStyle: "italic"
    })
    const checkbox = css({ paddingLeft: "24px", backgroundColor: verified ? undefined : "#F0FFFD" })
    const selectStyle = css({
        minWidth: "150px"
    })
    const datePicker = css({
        overflow: "visible",
        marginLeft: "15px",
        width: "170px"
    })
    return {
        loadingContainer,
        dividerStyle,
        title,
        buttonContainer,
        buttonStyle,
        body2,
        subheading,
        updated,
        margin,
        button,
        submitActionsTitle,
        checkbox,
        selectStyle,
        datePicker
    }
}

type Props = {
    theme: Object,
    orgID: string,
    match: Object,
    orgDetails: Object,
    orgDetailsAddressUpdate: boolean,
    orgDetailsNameUpdate: boolean,
    orgDetailsNameNew: string,
    orgDetailsAddressNew: Object,
    loading: boolean,
    historyRequests: Array<Object>,
    primaryContactValues: Object,
    adminContactValues: Object,
    requestId: string,
    verified: boolean,
    submitting: boolean,
    checkAccept: Function,
    reject: Function,
    approve: Function,
    startDate: any,
    endDate: any,
    queryString: string,
    topic: string,
    handleChange: Function,
    setDates: Function
}
const topicList = [
    { value: "", label: "All" },
    { value: "user", label: "User Actions" },
    { value: "org", label: "Organisation Actions" },
    { value: "gx", label: "Guarantee Related Actions" }
]
const OrganisationDetailsAdminCards = ({
    theme,
    orgDetailsNameUpdate,
    orgDetailsAddressUpdate,
    orgDetailsNameNew,
    orgDetailsAddressNew,
    primaryContactValues,
    adminContactValues,
    loading,
    orgDetails,
    verified,
    submitting,
    checkAccept,
    reject,
    approve,
    historyRequests,
    startDate,
    endDate,
    queryString,
    topic,
    handleChange,
    setDates,
    orgID
}: Props) => {
    const classes = getClasses({ theme, verified })
    let orgDetailCards
    console.log(orgDetails)
    if ((orgDetailsNameUpdate || orgDetailsAddressUpdate) && !loading) {
        orgDetailCards = (
            <Grid gridGap="3un">
                <Card>
                    <CardContent>
                        <LoadingDialog
                            open={submitting}
                            loading={submitting}
                            title="Submitting Confirmation request..."
                        />
                        <Flex flex="1">
                            <Typography className={classes.title}>
                                {`Review the Following Details for ${orgDetails.entityName}`}
                            </Typography>
                        </Flex>
                        <Grid gridGap="1un">
                            <Grid gridGap="1un 3un" gridTemplateColumns="15% 30% 15%">
                                <Typography className={classes.body2}>Legal Entity Name</Typography>
                                <Typography className={classes.body2}>Registered Address</Typography>
                                <Typography className={classes.body2}>
                                    {orgDetails.businessId.length === 9 ? "ACN" : "ABN"}
                                </Typography>
                                <Typography className={classes.subheading}>{orgDetails.entityName}</Typography>
                                <Typography className={classes.subheading}>
                                    {addressToString(orgDetails.entityAddress)}
                                </Typography>
                                <Typography className={classes.subheading}>{orgDetails.businessId}</Typography>
                            </Grid>
                            <Grid gridGap="1un 3un" gridTemplateColumns="15% 30%">
                                <Typography className={classes.body2}>
                                    {orgDetailsNameUpdate ? (
                                        <React.Fragment>
                                            <span className={classes.updated}>Updated</span>
                                            <span>Legal Entity Name</span>
                                        </React.Fragment>
                                    ) : null}
                                </Typography>
                                <Typography className={classes.body2}>
                                    {orgDetailsAddressUpdate ? (
                                        <React.Fragment>
                                            {" "}
                                            <span className={classes.updated}>Updated</span>
                                            <span>Registered Address</span>
                                        </React.Fragment>
                                    ) : null}
                                </Typography>

                                <Typography className={classes.subheading}>
                                    {orgDetailsNameUpdate ? <span>{orgDetailsNameNew}</span> : null}
                                </Typography>
                                <Typography className={classes.subheading}>
                                    {orgDetailsAddressUpdate ? (
                                        <span>{addressToString(orgDetailsAddressNew)}</span>
                                    ) : null}
                                </Typography>
                            </Grid>
                        </Grid>
                    </CardContent>
                    <CardActions className={classes.checkbox}>
                        <FormControlLabel
                            className={classes.checkbox}
                            control={
                                <Checkbox
                                    disabled={submitting}
                                    name="Accept"
                                    onChange={checkAccept}
                                    checked={verified}
                                />
                            }
                            label="I confirm I have reviewed the request"
                        />
                    </CardActions>
                </Card>
                <Card>
                    <CardContent className={classes.buttonContainer}>
                        <Typography className={classes.submitActionsTitle}>
                            Approve after verifying the details
                        </Typography>
                        <Button disabled={!verified || submitting} onClick={reject} className={classes.button}>
                            Reject
                        </Button>
                        <Button disabled={!verified || submitting} onClick={approve} className={classes.button}>
                            Approve
                        </Button>
                    </CardContent>
                </Card>
            </Grid>
        )
    } else if (!loading && orgDetails.businessId) {
        orgDetailCards = (
            <Card>
                <CardContent>
                    <Flex flex="1">
                        <Typography className={classes.title}>Organisation Details</Typography>
                    </Flex>
                    <Grid gridGap="1un 3un" gridTemplateColumns="15% 30% 15%">
                        <Typography className={classes.body2}>Legal Entity Name</Typography>
                        <Typography className={classes.body2}>Registered Address</Typography>
                        <Typography className={classes.body2}>
                            {orgDetails.businessId.length === 9 ? "ACN" : "ABN"}
                        </Typography>
                        <Typography className={classes.subheading}>{orgDetails.entityName}</Typography>
                        <Typography className={classes.subheading}>
                            {addressToString(orgDetails.entityAddress)}
                        </Typography>
                        <Typography className={classes.subheading}>{orgDetails.businessId}</Typography>
                    </Grid>
                </CardContent>
            </Card>
        )
    } else {
        orgDetailCards = <LoadingCard />
    }
    return (
        <React.Fragment>
            <Grid gridGap="3un">
                {orgDetailCards}
                {primaryContactValues.firstName && (
                    <OrganizationDetailsFormContainer
                        title="Primary Contact"
                        theme={theme}
                        loading={loading}
                        contactValues={primaryContactValues}
                        dateAdded
                    />
                )}
                {adminContactValues.firstName && (
                    <OrganizationDetailsFormContainer
                        title="Administrator"
                        theme={theme}
                        loading={loading}
                        contactValues={adminContactValues}
                        dateAdded
                    />
                )}
                {!loading ? (
                    <Card>
                        <CardContent>
                            <Flex>
                                <Flex flex="1">
                                    <Typography className={classes.title}>Events Recorded</Typography>
                                </Flex>
                                <Flex>
                                    <FormControl>
                                        <InputLabel htmlFor="topic">Topics</InputLabel>

                                        <Select
                                            value={topic}
                                            name="topic"
                                            id="topic"
                                            onChange={handleChange}
                                            inputProps={{
                                                name: "topic",
                                                id: "topic"
                                            }}
                                            className={classes.selectStyle}
                                        >
                                            {topicList.map(aTopic => (
                                                <MenuItem key={aTopic.value} value={aTopic.value}>
                                                    {aTopic.label}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                    <MyDatePicker
                                        dateValue={startDate}
                                        label="Beginnning Date"
                                        fieldName="startDate"
                                        setDate={setDates}
                                    />
                                    <MyDatePicker
                                        dateValue={endDate}
                                        label="Ending Date"
                                        fieldName="endDate"
                                        setDate={setDates}
                                    />

                                    <DownloadButton downloadCsv={api.audit.downloadOrgAudit(orgID, queryString)} />
                                </Flex>
                            </Flex>
                            <Timeline hideActions data={historyRequests} />
                        </CardContent>
                    </Card>
                ) : (
                    <div />
                )}
            </Grid>
        </React.Fragment>
    )
}

export default withTheme()(OrganisationDetailsAdminCards)

// api.adminOrgManagement
//       .actionManagement(this.props.orgID, this.props.requestId, "REVOKE")
//       .then(() => this.setState({ verified: false }))
//       .catch(err => console.log("error ", err))
