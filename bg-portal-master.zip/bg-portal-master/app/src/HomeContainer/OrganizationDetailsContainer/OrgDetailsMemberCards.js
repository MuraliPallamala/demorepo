// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Select from "@material-ui/core/Select"
import FormControl from "@material-ui/core/FormControl"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import CardContent from "@material-ui/core/CardContent"
import DownloadButton from "~/shared/DownloadButton"
import { Grid, Flex } from "~/shared/layout"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import { addressToString } from "~/util/helpers/text"
import OrganizationDetailsFormContainer from "~/HomeContainer/SettingsContainer/CompanyDetailsContainer/PrimaryContactDetails/PrimaryContactDetails"
import Timeline from "~/shared/TimelineContainer/TimelineContainer"
import api from "~/util/api"
import MyDatePicker from "~/shared/DatePicker/DatePicker"

const getClasses = ({ theme }) => {
    const body2 = css(theme.typography.body2)
    const subheading = css(theme.typography.subheading)
    const title = css(theme.typography.cardTitle)
    const selectStyle = css({
        minWidth: "150px"
    })
    const datePicker = css({
        overflow: "visible",
        marginLeft: "15px",
        width: "170px"
    })
    return {
        title,
        body2,
        subheading,
        selectStyle,
        datePicker
    }
}

type Props = {
    theme: Object,
    orgDetails: Object,
    loading: boolean,
    primaryContactValues: Object,
    adminContactValues: Object,
    historyRequests: Array<Object>,
    topic: string,
    handleChange: Function,
    startDate: any,
    setDates: Function,
    endDate: any,
    orgID: string,
    queryString: string
}
const topicList = [
    { value: "", label: "All" },
    { value: "user", label: "User Actions" },
    { value: "org", label: "Organisation Actions" },
    { value: "gx", label: "Guarantee Related Actions" }
]
const OrganisationDetailsMemberCards = ({
    theme,
    loading,
    orgDetails,
    primaryContactValues,
    adminContactValues,
    historyRequests,
    topic,
    handleChange,
    startDate,
    setDates,
    endDate,
    orgID,
    queryString
}: Props) => {
    const classes = getClasses({ theme })
    let orgDetailCards
    if (!loading && orgDetails.businessId) {
        orgDetailCards = (
            <Card>
                <CardContent>
                    <Flex flex="1">
                        <Typography className={classes.title}>Organisation Details</Typography>
                    </Flex>
                    <Grid gridGap="1un 3un" gridTemplateColumns="15% 30% 15%">
                        <Typography className={classes.body2}>Legal Entity Name</Typography>
                        <Typography className={classes.body2}>Registered Address</Typography>
                        <Typography className={classes.body2}>
                            {orgDetails.businessId.length === 9 ? "ACN" : "ABN"}
                        </Typography>
                        <Typography className={classes.subheading}>{orgDetails.entityName}</Typography>
                        <Typography className={classes.subheading}>
                            {addressToString(orgDetails.entityAddress)}
                        </Typography>
                        <Typography className={classes.subheading}>{orgDetails.businessId}</Typography>
                    </Grid>
                </CardContent>
            </Card>
        )
    } else {
        orgDetailCards = <LoadingCard />
    }

    return (
        <React.Fragment>
            <Grid gridGap="3un">
                <React.Fragment>
                    {orgDetailCards}
                    {primaryContactValues.firstName && (
                        <React.Fragment>
                            <OrganizationDetailsFormContainer
                                title="Primary Contact"
                                theme={theme}
                                loading={loading}
                                contactValues={primaryContactValues}
                                dateAdded
                            />
                            <OrganizationDetailsFormContainer
                                title="Administrator"
                                theme={theme}
                                loading={loading}
                                contactValues={adminContactValues}
                                dateAdded
                            />
                        </React.Fragment>
                    )}
                    {historyRequests.length > 0 ? (
                        <Card>
                            <CardContent>
                                <Flex paddingBottom="24px">
                                    <Flex flex="1">
                                        <Typography className={classes.title}>Events Recorded</Typography>
                                    </Flex>
                                    <Flex paddingBottom="36px">
                                        <FormControl>
                                            <InputLabel htmlFor="topic">Topics</InputLabel>
                                            <Select
                                                value={topic}
                                                name="topic"
                                                id="topic"
                                                onChange={handleChange}
                                                inputProps={{
                                                    name: "topic",
                                                    id: "topic"
                                                }}
                                                className={classes.selectStyle}
                                            >
                                                {topicList.map(aTopic => (
                                                    <MenuItem key={aTopic.value} value={aTopic.value}>
                                                        {aTopic.label}
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>
                                        <MyDatePicker
                                            dateValue={startDate}
                                            label="Beginning Date"
                                            fieldName="startDate"
                                            setDate={setDates}
                                        />
                                        <MyDatePicker
                                            dateValue={endDate}
                                            label="Ending Date"
                                            fieldName="endDate"
                                            setDate={setDates}
                                        />

                                        <DownloadButton downloadCsv={api.audit.downloadOrgAudit(orgID, queryString)} />
                                    </Flex>
                                </Flex>
                                <Timeline hideActions data={historyRequests} />
                            </CardContent>
                        </Card>
                    ) : (
                        <div />
                    )}
                </React.Fragment>
            </Grid>
        </React.Fragment>
    )
}

export default withTheme()(OrganisationDetailsMemberCards)
