let OrganizationDetailsContainer // eslint-disable-line import/no-mutable-exports

if (PORTAL_TYPE === "admin") {
    OrganizationDetailsContainer = require("./AdminOrganizationDetailsContainer").default // eslint-disable-line global-require
} else {
    OrganizationDetailsContainer = require("./MemberOrganizationDetailsContainer").default // eslint-disable-line global-require
}

export default OrganizationDetailsContainer
