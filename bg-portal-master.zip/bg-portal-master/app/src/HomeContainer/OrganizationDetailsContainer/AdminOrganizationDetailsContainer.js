// @flow
/* eslint-disable react/sort-comp */

import * as React from "react"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import { withTheme } from "@material-ui/core/styles"
import { Block, Grid } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import OrgDetailsAdminCards from "./OrgDetailsAdminCards"

type Props = {
    theme: Object,
    match: Object,
    handleErrorOpen: Function,
    history: Object
}

type State = {
    loading: boolean,
    orgDetailsAddressUpdate: boolean,
    orgDetailsNameUpdate: boolean,
    orgDetailsName: string,
    orgDetailsAddress: Object,
    orgDetailsAddressNew: Object,
    orgDetailsNameNew: string,
    orgDetails: Object,
    historyRequests: Array<Object>,
    primaryContactValues: Object,
    adminContactValues: Object,
    requestId: string,
    verified: boolean,
    submitting: boolean,
    startDate: any,
    endDate: any,
    queryString: string,
    topic: string,
    verifyActionId: string,
    recallVerifyId: string
}

function isEquivalent(a, b) {
    const aProps = Object.getOwnPropertyNames(a)
    const bProps = Object.getOwnPropertyNames(b)

    if (aProps.length !== bProps.length) {
        return false
    }

    for (let i = 0; i < aProps.length; i++) {
        const propName = aProps[i]

        if (a[propName] !== b[propName]) {
            return false
        }
    }
    return true
}

class AdminOrganizationDetailsContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            loading: true,
            orgDetailsAddressUpdate: false,
            orgDetailsNameUpdate: false,
            verified: false,
            orgDetailsAddress: {},
            orgDetailsName: "",
            orgDetailsAddressNew: {},
            orgDetailsNameNew: "",
            orgDetails: {},
            historyRequests: [],
            adminContactValues: {},
            primaryContactValues: {},
            requestId: "",
            submitting: false,
            startDate: null,
            endDate: null,
            queryString: "",
            topic: "",
            verifyActionId: "",
            recallVerifyId: ""
        }
    }

    componentDidMount() {
        this.getOrganisationChanges()
        this.getAuditData("")
    }
    componentDidUpdate(prevProps, prevState) {
        if (
            prevState.topic !== this.state.topic ||
            prevState.startDate !== this.state.startDate ||
            prevState.endDate !== this.state.endDate
        ) {
            const { topic, startDate, endDate } = this.state

            const mappedValues = { after: startDate, before: endDate, topic }
            let queryString = Object.keys(mappedValues)
                .filter(key => mappedValues[key])
                .map(key => `${key}=${mappedValues[key]}`)
                .join("&")
            queryString = `?${queryString}`
            this.setState({ queryString })
            this.getAuditData(queryString)
        }
    }
    getAuditData = (queryString: string) => {
        api.audit
            .getOrgAudit(this.props.match.params.orgID, queryString)
            .then(({ data }) => {
                this.setState({ historyRequests: data.result.reverse() })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Error getting History`,
                    title: `Error getting Audit data for organisation`,
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: this.props.match.params.orgID,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    getOrganisationChanges = () => {
        api.organisations
            .getOrganisations(this.props.match.params.orgID)
            .then(({ data }) => {
                const primaryContact = data.profile.contacts.find(contact => contact.roles.includes("PRIMARY"))
                const adminContact = data.profile.contacts.find(contact => contact.roles.includes("ADMIN"))

                this.setState({
                    orgDetailsName: data.profile.entityName,
                    orgDetailsAddress: data.profile.entityAddress,
                    orgDetails: data.profile,
                    primaryContactValues: {
                        firstName: primaryContact.firstName,
                        lastName: primaryContact.lastName,
                        email: primaryContact.email,
                        phone: primaryContact.phone,
                        dateAdded: data.createdAt
                    },
                    adminContactValues: {
                        firstName: adminContact.firstName,
                        lastName: adminContact.lastName,
                        email: adminContact.email,
                        phone: adminContact.phone,
                        dateAdded: data.createdAt
                    }
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Get Organisation Changes Error`,
                    title: `Get Organisation Changes Error`,
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: this.props.match.params.orgID,
                        ErrorResponse: err
                    }
                })
                throw err
            })
            .then(res => {
                api.adminOrgManagement
                    .getOrgRequests(this.props.match.params.orgID, "?status=CONFIRMED")
                    .then(({ data }) => {
                        if (data.result.length > 0) {
                            const lastEntry = data.result[data.result.length - 1]
                            let details = lastEntry.payload
                            // overload details for change request, if recall action is provided
                            let verified = false
                            let verifyActionId = ""
                            let recallVerifyId = ""
                            if (lastEntry.actions != null) {
                                lastEntry.actions.forEach(action => {
                                    if (action.actionType === "RECALL") {
                                        details = action.payload
                                        verified = false
                                        recallVerifyId = action.id
                                    }
                                    if (action.actionType === "VERIFY") {
                                        verified = true
                                        verifyActionId = action.id
                                    }
                                })
                            }
                            const lastAction = lastEntry.actions.pop()
                            if (lastAction && lastAction.actionType === "REVOKE") {
                                verified = false
                            }
                            this.setState({ requestId: data.result[data.result.length - 1].id })
                            this.state.orgDetailsName !== details.entityName
                                ? this.setState({
                                      orgDetailsNameUpdate: true,
                                      orgDetailsNameNew: details.entityName,
                                      verified,
                                      verifyActionId,
                                      recallVerifyId
                                  })
                                : this.setState({ orgDetailsNameNew: this.state.orgDetailsName })
                            !isEquivalent(this.state.orgDetailsAddress, details.address)
                                ? this.setState({
                                      orgDetailsAddressUpdate: true,
                                      orgDetailsAddressNew: details.address,
                                      verified,
                                      verifyActionId,
                                      recallVerifyId
                                  })
                                : this.setState({ orgDetailsAddressNew: this.state.orgDetailsAddress })
                        } else {
                            this.setState({
                                orgDetailsAddressUpdate: false,
                                orgDetailsNameUpdate: false
                            })
                        }
                    })
                    .catch(err => {
                        this.props.handleErrorOpen({
                            errorMessage: `Get Organisation Requests Error`,
                            title: `Get Organisation Requests Error`,
                            error: err,
                            extraDetails: {
                                Info: err.info,
                                CurrentUrl: this.props.history.location.pathname,
                                Payload: this.props.match.params.orgID,
                                ErrorResponse: err
                            }
                        })
                        this.setState({
                            orgDetailsAddressUpdate: false,
                            orgDetailsNameUpdate: false
                        })
                        throw err
                    })
            })
            .then(() => {
                this.setState({ loading: false })
            })
    }

    checkAccept = () => {
        const { orgID } = this.props.match.params

        this.state.verified
            ? api.adminOrgManagement
                  .actionManagement(orgID, this.state.requestId, "REVOKE", this.state.verifyActionId)
                  .then(() => this.setState({ verified: false }))
                  .catch(err => console.log("error ", err))
            : api.adminOrgManagement
                  .actionManagement(orgID, this.state.requestId, "VERIFY", this.state.recallVerifyId)
                  .then(({ data }) => this.setState({ verified: true, verifyActionId: data.id }))
                  .catch(err => console.log("error ", err))
    }

    reject = () => {
        const { orgID } = this.props.match.params

        this.setState({ submitting: true })
        api.adminOrgManagement
            .actionManagement(orgID, this.state.requestId, "REJECT")
            .then(() => {
                this.getOrganisationChanges()
                this.setState({ submitting: false })
                window.location.reload()
            })
            .catch(err => {
                console.log(`error, ${err}`)
                this.setState({ submitting: false })
            })
    }
    approve = () => {
        const { orgID } = this.props.match.params

        this.setState({ submitting: true })
        api.adminOrgManagement
            .actionManagement(orgID, this.state.requestId, "APPROVE", this.state.verifyActionId)
            .then(() => {
                this.getOrganisationChanges()
                this.setState({ submitting: false })
                window.location.reload()
            })
            .catch(err => {
                console.log(`error, ${err}`)
                this.setState({ submitting: false })
            })
    }
    setDates = (name, date: any) => {
        this.setState({ [name]: date })
    }
    handleChange = event => {
        this.setState({ [event.target.name]: event.target.value })
    }

    render() {
        const { theme, match } = this.props
        const {
            loading,
            orgDetailsAddressUpdate,
            orgDetailsNameUpdate,
            orgDetails,
            orgDetailsNameNew,
            orgDetailsAddressNew,
            historyRequests,
            adminContactValues,
            primaryContactValues,
            requestId,
            verified,
            submitting,
            startDate,
            endDate,
            queryString,
            topic
        } = this.state
        const { orgID } = match.params
        return (
            <React.Fragment>
                <PageTitle theme={theme} path="Organisations/" link="/organisations" title="Details" />
                <Block padding="0un 3un 3un 3un">
                    <Grid gridGap="3un">
                        <OrgDetailsAdminCards
                            match={match}
                            orgID={orgID}
                            requestId={requestId}
                            orgDetails={orgDetails}
                            orgDetailsAddressUpdate={orgDetailsAddressUpdate}
                            orgDetailsNameUpdate={orgDetailsNameUpdate}
                            orgDetailsNameNew={orgDetailsNameNew}
                            orgDetailsAddressNew={orgDetailsAddressNew}
                            loading={loading}
                            historyRequests={historyRequests}
                            primaryContactValues={primaryContactValues}
                            adminContactValues={adminContactValues}
                            verified={verified}
                            checkAccept={this.checkAccept}
                            reject={this.reject}
                            approve={this.approve}
                            submitting={submitting}
                            setDates={this.setDates}
                            handleChange={this.handleChange}
                            startDate={startDate}
                            endDate={endDate}
                            topic={topic}
                            queryString={queryString}
                        />
                    </Grid>
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(AdminOrganizationDetailsContainer))
