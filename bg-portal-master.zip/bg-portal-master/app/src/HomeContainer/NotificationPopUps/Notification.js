// // @flow
// import React from "react"
// import { withTheme } from "@material-ui/core/styles"
// import { css } from "emotion"
// import ReactNotification from "react-notifications-component"
// import { Link } from "react-router-dom"

// const getClasses = ({ theme }) => {
//     const notification = css({
//         backgroundColor: theme.palette.primary.main,
//         borderLeft: "8px solid",
//         borderColor: theme.palette.primary.headerMain
//     })

//     return {
//         notification
//     }
// }
// type Props = {
//     theme: Object,
//     reference: any
// }
// const Notification = ({ theme, reference }: Props) => {
//     const classes = getClasses({ theme })
//     return (
//         <div style={{ zIndex: "100" }} className="app-content">
//             <Link to="/notifications">
//                 <ReactNotification
//                     className={classes.notification}
//                     types={[
//                         {
//                             htmlClasses: [classes.notification],
//                             name: "custom"
//                         }
//                     ]}
//                     // eslint-disable-next-line
//                     ref={reference}
//                 />
//             </Link>
//         </div>
//     )
// }

// export default withTheme()(Notification)
