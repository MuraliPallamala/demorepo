// @flow

import * as React from "react"
import moment from "moment"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import CardHeader from "@material-ui/core/CardHeader"
import { withTheme } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import Arrow from "@material-ui/icons/KeyboardArrowRight"
import CardActionArea from "@material-ui/core/CardActionArea"
import PhoneNumberTextMask from "~/shared/PhoneNumberTextMask"
import api from "~/util/api"
import { Grid, Flex } from "~/shared/layout"
import ConfirmationCodeSmart from "~/shared/ConfirmationCodeSmart"

const getClasses = ({ theme }) => {
    const headerStyle = css({
        fontSize: "1em"
    })

    const tabContainer = css({
        display: "inline-block",
        marginLeft: "30%"
    })
    const title = css({
        paddingBottom: "0px",
        span: {
            fontSize: "1.2rem",
            color: `${theme.palette.common.darkBlue}!important`
        }
    })
    const updatesCard = css({
        border: "2px solid",
        borderColor: "transparent",
        cursor: "pointer",
        "&:hover": {
            borderColor: theme.palette.primary.headerBottom,
            backgroundColor: "#F4FEFD"
        }
    })
    const textContainer = css({
        overflowWrap: "break-word"
    })

    return {
        headerStyle,
        tabContainer,
        title,
        updatesCard,
        textContainer
    }
}

type Props = {
    theme: Object,
    request: Object,
    onSelection: () => void
}

class OnboardingListCard extends React.Component<Props> {
    statusConverter = (status: string) => {
        if (status === "DRAFTED") {
            return "(In Progress)"
        } else if (status === "REJECTED") {
            return "(Rejected)"
        } else if (status === "ABANDONED") {
            return "(Abandoned)"
        } else if (status === "CONFIRMED") {
            return "(In Progress)"
        } else if (status === "APPROVED") {
            return "(Completed)"
        }
        return ""
    }

    render() {
        const {
            theme,
            onSelection,
            request: { profile, createdAt, status, id }
        } = this.props
        const primaryContact = profile.contacts.find(contact => contact.roles.includes("PRIMARY"))
        const classes = getClasses({ theme })
        return (
            <Card square>
                <CardActionArea onClick={() => onSelection()} className={classes.updatesCard}>
                    <CardHeader
                        title={`Onboarding Request - ${this.statusConverter(status)} -'${
                            profile.entityName
                        }'  Sent on: ${moment(createdAt).format("LLLL")} `}
                        className={classes.title}
                    />
                    <CardContent>
                        <Flex>
                            <Flex flex="1">
                                {primaryContact ? (
                                    <Grid
                                        gridTemplateColumns="repeat(3, minmax(220px, 20%))"
                                        className={classes.textContainer}
                                    >
                                        <Typography>Primary Contact </Typography>
                                        <Typography>Email </Typography>
                                        <Typography>Phone Number </Typography>
                                        <Typography>{`${primaryContact.firstName} ${
                                            primaryContact.lastName
                                        }`}</Typography>
                                        <Typography>{primaryContact.email}</Typography>
                                        <Typography>
                                            <PhoneNumberTextMask value={primaryContact.phone} />
                                        </Typography>
                                    </Grid>
                                ) : null}
                            </Flex>
                            <Flex>
                                <ConfirmationCodeSmart
                                    text="Confirmation PIN"
                                    onRequestCode={api.onboarding.getOnboardingToken}
                                    id={id}
                                />
                                <Arrow titleAccess="This notification is selectable  and will link to relevant page" />
                            </Flex>
                        </Flex>
                    </CardContent>
                </CardActionArea>
            </Card>
        )
    }
}

export default withTheme()(OnboardingListCard)
