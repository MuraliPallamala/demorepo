// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import { withTheme } from "@material-ui/core/styles"
import axios from "axios"
import api from "~/util/api"
import { Grid } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import withError from "~/shared/Context/ErrorDialog/withError"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import NoResultsCard from "~/shared/BasicCards/NoResultsCard"
import generateKey from "~/util/helpers/generateKey"
import OnboardingListCard from "./OnboardingListCard"

function onRowSelection(history, value) {
    history.push(`onboardinglist/${value.id}`)
}

type Props = {
    history: Object,
    theme: Object,
    handleErrorOpen: Function,
    location: Object
}

type State = {
    requests: Array<Object>,
    loading: boolean
}

class OnboardingListContainer extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        this.state = {
            requests: [],
            loading: true
        }
    }

    componentDidMount() {
        if (this.props.location.search && this.props.location.search !== "") {
            this.getOnboardingRequests(this.props.location.search)
        } else {
            this.getOnboardingRequests("")
        }
    }
    // componentDidUpdate(prevProps) {
    //     // Typical usage (don't forget to compare props):
    //     if (this.props.userID !== prevProps.userID) {
    //       this.fetchData(this.props.userID);
    //     }
    //   }
    componentDidUpdate(prevProps, prevState) {
        if (this.props.location.search !== prevProps.location.search) {
            this.getOnboardingRequests(this.props.location.search)
        }
    }
    getOnboardingRequests = (search: string) => {
        this.setState({ loading: true })
        if (search === "?status=DRAFTED") {
            api.general
                .multipleApis([
                    api.onboarding.getOnboardingRequests(search),
                    api.onboarding.getOnboardingRequests("?status=CONFIRMED")
                ])
                .then(
                    axios.spread((Drafted, Confirmed) => {
                        const returnData = [...Drafted.data.result, ...Confirmed.data.result]
                        const sortedData = this.sortOnboardingList(returnData)

                        this.setState({ requests: sortedData, loading: false })
                    })
                )
                .catch(err => {
                    this.props.handleErrorOpen({
                        errorMessage: `Getting onboarding requests failed`,
                        title: "Get Onboarding Request Error",
                        error: err,
                        extraDetails: {
                            Info: err.info,
                            CurrentUrl: this.props.history.location.pathname,
                            Payload: search,
                            ErrorResponse: err
                        }
                    })
                    this.setState({ loading: false })
                    throw err
                })
        } else if (search === "?status=REJECTED") {
            api.general
                .multipleApis([
                    api.onboarding.getOnboardingRequests(search),
                    api.onboarding.getOnboardingRequests("?status=ABANDONED")
                ])
                .then(
                    axios.spread((Rejected, Abandoned) => {
                        const returnData = [...Rejected.data.result, ...Abandoned.data.result]
                        const sortedData = this.sortOnboardingList(returnData)
                        this.setState({ requests: sortedData, loading: false })
                    })
                )
                .catch(err => {
                    this.props.handleErrorOpen({
                        errorMessage: `Getting onboarding requests failed`,
                        title: "Get Onboarding Request Error",
                        error: err,
                        extraDetails: {
                            Info: err.info,
                            CurrentUrl: this.props.history.location.pathname,
                            Payload: search,
                            ErrorResponse: err
                        }
                    })
                    this.setState({ loading: false })
                    throw err
                })
        } else {
            api.onboarding
                .getOnboardingRequests(search)
                .then(({ data: { result } }) => {
                    const sortedData = this.sortOnboardingList(result)

                    this.setState({
                        requests: sortedData,
                        loading: false
                    })
                })
                .catch(err => {
                    this.props.handleErrorOpen({
                        errorMessage: `Getting onboarding requests failed`,
                        title: "Get Onboarding Request Error",
                        error: err,
                        extraDetails: {
                            Info: err.info,
                            CurrentUrl: this.props.history.location.pathname,
                            Payload: search,
                            ErrorResponse: err
                        }
                    })
                    this.setState({ loading: false })
                    throw err
                })
        }
    }

    sortOnboardingList = (historyData: Array<any>) => {
        // Slow Sort, enhancement change to a merge :P
        const sortedData = historyData.sort((a, b) => {
            const dateA = new Date(a.createdAt)
            const dateB = new Date(b.createdAt)
            return dateB - dateA
        })
        return sortedData
    }

    titleText = (search: string) => {
        if (search === "?status=APPROVED") {
            return "Onboarding List: Completed"
        } else if (search === "?status=REJECTED") {
            return "Onboarding List: Rejected"
        } else if (search === "?status=DRAFTED") {
            return "Onboarding List: In Progress"
        }
        return "Onboarding List"
    }
    renderList = (loading, requests) => {
        if (loading) {
            return <LoadingCard />
        }
        if (requests.length === 0) {
            return <NoResultsCard />
        }
        return requests.map(request => (
            <OnboardingListCard
                request={request}
                key={generateKey(request.id)}
                onSelection={() => onRowSelection(this.props.history, request)}
            />
        ))
    }

    render() {
        const { history, theme } = this.props
        const { requests, loading } = this.state
        return (
            <Grid gridGap="3un">
                <Card>
                    <PageTitle
                        title={
                            // $FlowFixMe
                            <span
                                // eslint-disable-next-line
                                tabIndex="0"
                                id="main-content"
                            >
                                {this.titleText(history.location.search)}
                            </span>
                        }
                        theme={theme}
                    />
                </Card>
                {this.renderList(loading, requests)}
            </Grid>
        )
    }
}
export default withError(withTheme()(OnboardingListContainer))
