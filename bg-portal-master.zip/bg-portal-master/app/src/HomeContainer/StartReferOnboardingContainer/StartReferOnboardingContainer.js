// @flow

import * as React from "react"
import api from "~/util/api"
import { withTheme } from "@material-ui/core/styles"
import { mapFormValuesToRequest } from "~/util/onboarding"
import withError from "~/shared/Context/ErrorDialog/withError"
import { Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import FreshOnboardingForm from "~/shared/Forms/Onboarding/FreshOnboardingForm"

type Props = {
    history: Object,
    theme: Object,
    previousPage: Function,
    handleErrorOpen: Function
}

type State = {}

class StartReferOnboardingContainer extends React.Component<Props, State> {
    componentDidMount() {
        window.addEventListener("beforeunload", this.onUnload)
    }
    componentWillUnmount() {
        window.removeEventListener("beforeunload", this.onUnload)
    }
    onUnload = event => {
        // the method that will be used for both add and remove event
        event.returnValue = "Data will be lost if you leave the page, are you sure?"
    }
    submitOnboardingRequest = (values: Object) =>
        api.onboarding
            .submitOnboardingRequest(mapFormValuesToRequest(values))
            .then(({ data }) => {
                this.props.history.push(`/OnboardingSubmission/${data.id}`)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Submit Onboarding Request Error`,
                    title: "Submit Onboarding Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: mapFormValuesToRequest(values),
                        ErrorResponse: err
                    }
                })
                throw err
            })

    render() {
        const { theme, previousPage } = this.props
        return (
            <React.Fragment>
                <PageTitle title="Onboard a New Entity" theme={theme} />
                <Block padding="1un 3un 3un 3un">
                    <FreshOnboardingForm
                        referer
                        onCancel={() => previousPage()}
                        onSubmit={this.submitOnboardingRequest}
                    />
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(StartReferOnboardingContainer))
