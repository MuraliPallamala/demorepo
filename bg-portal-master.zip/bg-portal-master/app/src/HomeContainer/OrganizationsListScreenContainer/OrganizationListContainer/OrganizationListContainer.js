// @flow

import * as React from "react"

import { withTheme } from "@material-ui/core/styles"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import { css } from "emotion"

import type { User, Gx } from "~/util/flow_types"

const tableColumns = [
    {
        columnHeader: {
            dataName: "status",
            displayName: "Status"
        },
        sort: true
    },
    {
        columnHeader: {
            dataName: "entityName",
            displayName: "Entity Name"
        },
        sort: true
    },
    {
        columnHeader: {
            dataName: "businessId",
            displayName: "Business ID"
        },
        sort: true
    },
    {
        columnHeader: {
            dataName: "entityType",
            displayName: "Entity Type"
        },
        sort: true
    }
]

const tableSortDefault = { dataName: "entityName", order: "asc" }

type Props = {
    loading: boolean,
    list: Array<Gx>,
    history: Object,
    match: Object,
    user: User,
    theme: Object
}

const OrganizationListContainer = ({ loading, list, history, match, user, theme }: Props) => {
    const rows = list

    const onRowSelection = row => {
        history.push(`/organisations/${row.id}`)
    }
    return (
        <FlexAccordionTable
            onRowSelection={onRowSelection}
            columns={tableColumns}
            data={rows}
            defaultSort={tableSortDefault}
            className={css(theme.typography.tableStyle)}
            loading={loading}
        />
    )
}

export default withTheme()(OrganizationListContainer)
