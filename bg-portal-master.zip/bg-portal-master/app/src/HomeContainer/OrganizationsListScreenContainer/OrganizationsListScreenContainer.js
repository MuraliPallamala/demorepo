// @flow
/* eslint-disable react/sort-comp */
import * as React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import { withTheme } from "@material-ui/core/styles"
import debounce from "lodash/debounce"
import api from "~/util/api"
import { Grid, Block, Flex } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import withError from "~/shared/Context/ErrorDialog/withError"
import type { User } from "~/util/flow_types"
import makeCancelable from "~/util/helpers/makeCancelable"
import { organisationsMap } from "~/util/organisations"
import SearchContainer from "~/shared/SearchContainer/SearchContainer"
import OrganizationListContainer from "./OrganizationListContainer/OrganizationListContainer"

type Props = {
    match: Object,
    history: Object,
    className: string,
    theme: Object,
    user: User,
    handleErrorOpen: Function,
    location: Object
}
type State = {
    list: Array<Object>,
    searchValue: string,
    loading: boolean
}

class OrganisationsContainer extends React.Component<Props, State> {
    cancelablePromise: Object
    cancelableQuery: Object
    constructor(props) {
        super(props)
        this.state = {
            list: [],
            searchValue: "",
            loading: true
        }
        this.searchQuery = debounce(this.searchQuery, 1000)
        this.cancelablePromise = { cancel: () => console.log("cancel") }
        this.cancelableQuery = { cancel: () => console.log("cancel") }
    }

    componentDidMount() {
        if (this.props.location.search && this.props.location.search !== "") {
            this.cancelablePromise = makeCancelable(this.getOrganisationsByStatus(this.props.history.location.search))
        } else {
            this.cancelablePromise = makeCancelable(this.getOrganisationsByStatus(""))
        }
    }
    componentDidUpdate(prevProps) {
        console.log("Prev", prevProps, "Current", this.props)
        if (prevProps.location.search !== this.props.location.search) {
            this.setState({ loading: true })
            if (this.props.location.search !== "") {
                this.cancelablePromise = makeCancelable(
                    this.getOrganisationsByStatus(this.props.history.location.search)
                )
            } else {
                this.cancelablePromise = makeCancelable(this.getOrganisationsByStatus(""))
            }
        }
    }
    componentWillUnmount() {
        this.cancelablePromise.cancel()
        this.searchQuery.cancel()
        this.cancelableQuery.cancel()
    }
    onSearch = searchValue => {
        this.setState({
            searchValue,
            loading: true
        })
        this.searchQuery(searchValue)
    }

    getOrganisationsByStatus = (searchQuery = "") =>
        api.organisations
            .getOrgsWithQuery(searchQuery)
            .then(({ data }) => {
                const params = new URLSearchParams(this.props.location.search)
                const filterStatus = params.get("status")
                let filteredOrgs = data.result
                if (filterStatus) {
                    filteredOrgs = data.result.filter(item => item.status === filterStatus)
                }

                this.setState({ list: organisationsMap(filteredOrgs), loading: false })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Error getting organisations`,
                    title: "Get Organisations Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: searchQuery,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    getOrganisations = (searchQuery = "") =>
        api.organisations
            .getOrganisations(searchQuery)
            .then(({ data }) => {
                this.setState({ list: organisationsMap(data.result), loading: false })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Error getting organisations`,
                    title: "Get Organisations Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: searchQuery,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    searchQuery = searchValue => {
        if (searchValue !== "") {
            if (searchValue.match(/^\d/) && searchValue.length >= 3) {
                this.cancelableQuery = makeCancelable(this.getOrganisations(`?businessId=${searchValue}`))
            } else {
                this.cancelableQuery = makeCancelable(this.getOrganisations(`?entityName=${searchValue}`))
            }
        } else {
            this.cancelableQuery = makeCancelable(this.getOrganisations())
        }
    }
    render() {
        const { theme, match, history, user, className } = this.props
        const { list, searchValue, loading } = this.state
        return (
            <Grid gridGap="3un" className={className}>
                <Card>
                    <PageTitle
                        title={
                            // $FlowFixMe
                            <span
                                // eslint-disable-next-line
                                tabIndex="0"
                                id="main-content"
                            >
                                Organisations
                            </span>
                        }
                        theme={theme}
                    />
                    <CardContent>
                        <Flex>
                            <Flex flex="1" />
                            <Flex>
                                <SearchContainer
                                    match={match}
                                    placeholder="Search organisation"
                                    onChange={this.onSearch}
                                    searchValue={searchValue}
                                />
                            </Flex>
                        </Flex>
                    </CardContent>
                    <Block padding="3un">
                        <OrganizationListContainer
                            history={history}
                            match={match}
                            loading={loading}
                            list={list}
                            user={user}
                        />
                    </Block>
                </Card>
            </Grid>
        )
    }
}

export default withError(withTheme()(OrganisationsContainer))
