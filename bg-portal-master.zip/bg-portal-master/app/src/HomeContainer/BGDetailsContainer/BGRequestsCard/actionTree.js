import soleApproverStartStandard from "./flows/soleApprover/startStandard"
import soleApproverStartTwoStep from "./flows/soleApprover/startTwoStep"
import soleApproverCounterPartyReceiveStandard from "./flows/soleApprover/counterPartyReceiveStandard"
import soleApproverStartTransferApplicant from "./flows/soleApprover/startTransferApplicant"
import soleApproverStartTransferBen from "./flows/soleApprover/startTransferBen"
import soleApproverCounterPartyReceiveTransferApplicantOldBen from "./flows/soleApprover/counterPartyReceiveTransferApplicantOldBen"
import soleApproverCounterPartyReceiveTransferApplicantNewBen from "./flows/soleApprover/counterPartyReceiveTransferApplicantNewBen"
import soleApproverReceiveTransferAsNewBenFromOldBen from "./flows/soleApprover/receiveTransferAsNewBenFromOldBen"
import soleApproverReceiveTransferAsIssuerFromOldBen from "./flows/soleApprover/receiveTransferAsIssuerFromOldBen"
import soleApproverReceiveTransferAsIssuerFromApplicant from "./flows/soleApprover/receiveTransferAsIssuerFromApplicant"
import soleApproverIssuerReceiverStandard from "./flows/soleApprover/issuerReceiverStandard"
import soleApproverIssuerReceiverTwoStep from "./flows/soleApprover/issuerReceiverTwoStep"
import soleApproverIssuerReceiverDemand from "./flows/soleApprover/issuerReceiverDemand"

import fourEyeStartStandard from "./flows/fourEye/startStandard"
import fourEyeStartTwoStep from "./flows/fourEye/startTwoStep"
import fourEyeStartTransferApplicant from "./flows/fourEye/startTransferApplicant"
import fourEyeStartTransferBen from "./flows/fourEye/startTransferBen"
import fourEyeCounterPartyReceiveTransferApplicantOldBen from "./flows/fourEye/counterPartyReceiveTransferApplicantOldBen"
import fourEyeCounterPartyReceiveTransferApplicantNewBen from "./flows/fourEye/counterPartyReceiveTransferApplicantNewBen"
import fourEyeReceiveTransferAsNewBenFromOldBen from "./flows/fourEye/receiveTransferAsNewBenFromOldBen"
import fourEyeReceiveTransferAsIssuerFromOldBen from "./flows/fourEye/receiveTransferAsIssuerFromOldBen"
import fourEyeReceiveTransferAsIssuerFromApplicant from "./flows/fourEye/receiveTransferAsIssuerFromApplicant"
import fourEyeCounterPartyReceiveStandard from "./flows/fourEye/counterPartyReceiveStandard"
import fourEyeIssuerReceiverStandard from "./flows/fourEye/issuerReceiverStandard"
import fourEyeIssuerReceiverTwoStep from "./flows/fourEye/issuerReceiverTwoStep"
import fourEyeIssuerReceiverDemand from "./flows/fourEye/issuerReceiverDemand"
import fourEyeIssuerStartPayWalk from "./flows/fourEye/issuerStartPayWalk"

import recieveTransferAsApplicantFromBen from "./flows/recieveTransferAsApplicantFromBen"
import receiveCancelAsApplicantFromBen from "./flows/receiveCancelAsApplicantFromBen"

const actionsTree = {
    // who am i
    issuer: {
        SOLE_APPROVER: {
            TRANSFER: {
                applicant: soleApproverReceiveTransferAsIssuerFromApplicant,
                beneficiary: soleApproverReceiveTransferAsIssuerFromOldBen
            },
            ISSUE: {
                applicant: soleApproverIssuerReceiverStandard,
                beneficiary: soleApproverIssuerReceiverStandard
            },
            CANCEL: {
                applicant: soleApproverIssuerReceiverStandard,
                beneficiary: soleApproverIssuerReceiverTwoStep
            },
            AMEND: {
                applicant: soleApproverIssuerReceiverStandard,
                beneficiary: soleApproverIssuerReceiverStandard
            },
            DEMAND: {
                beneficiary: soleApproverIssuerReceiverDemand
            },
            PAYWALK: {}
        },
        FOUR_EYE: {
            PAYWALK: {
                // whoStarted it
                issuer: fourEyeIssuerStartPayWalk
            },
            DEMAND: {
                beneficiary: fourEyeIssuerReceiverDemand
            },
            TRANSFER: {
                applicant: fourEyeReceiveTransferAsIssuerFromApplicant,
                beneficiary: fourEyeReceiveTransferAsIssuerFromOldBen
            },
            ISSUE: {
                // who started it
                issuer: fourEyeIssuerReceiverStandard,
                applicant: fourEyeIssuerReceiverStandard,
                beneficiary: fourEyeIssuerReceiverStandard
            },
            CANCEL: {
                // who started it
                issuer: fourEyeIssuerReceiverStandard,
                applicant: fourEyeIssuerReceiverStandard,
                beneficiary: fourEyeIssuerReceiverTwoStep
            },
            AMEND: {
                // who started it
                issuer: fourEyeIssuerReceiverStandard,
                applicant: fourEyeIssuerReceiverStandard,
                beneficiary: fourEyeIssuerReceiverStandard
            }
        }
    },
    applicant: {
        SOLE_APPROVER: {
            TRANSFER: {
                applicant: soleApproverStartTransferApplicant,
                beneficiary: recieveTransferAsApplicantFromBen
            },
            ISSUE: {
                applicant: soleApproverStartStandard,
                beneficiary: soleApproverCounterPartyReceiveStandard
            },
            AMEND: {
                applicant: soleApproverStartStandard,
                beneficiary: soleApproverCounterPartyReceiveStandard
            },
            CANCEL: {
                applicant: soleApproverStartStandard,
                beneficiary: receiveCancelAsApplicantFromBen
            }
        },
        FOUR_EYE: {
            TRANSFER: {
                applicant: fourEyeStartTransferApplicant,
                beneficiary: recieveTransferAsApplicantFromBen
            },
            ISSUE: {
                applicant: fourEyeStartStandard,
                beneficiary: fourEyeCounterPartyReceiveStandard,
                issuer: fourEyeStartStandard
            },
            CANCEL: {
                applicant: fourEyeStartStandard,
                beneficiary: receiveCancelAsApplicantFromBen,
                issuer: fourEyeStartStandard
            },
            AMEND: {
                applicant: fourEyeStartStandard,
                beneficiary: fourEyeCounterPartyReceiveStandard,
                issuer: fourEyeStartStandard
            }
        }
    },
    beneficiary: {
        SOLE_APPROVER: {
            TRANSFER: {
                applicant: soleApproverCounterPartyReceiveTransferApplicantOldBen,
                beneficiary: soleApproverStartTransferBen
            },
            ISSUE: {
                applicant: soleApproverCounterPartyReceiveStandard,
                beneficiary: soleApproverStartStandard
            },
            CANCEL: {
                applicant: soleApproverCounterPartyReceiveStandard,
                beneficiary: soleApproverStartStandard
            },
            AMEND: {
                applicant: soleApproverCounterPartyReceiveStandard,
                beneficiary: soleApproverStartStandard
            },
            DEMAND: {
                beneficiary: soleApproverStartTwoStep
            }
        },
        FOUR_EYE: {
            TRANSFER: {
                applicant: fourEyeCounterPartyReceiveTransferApplicantOldBen,
                beneficiary: fourEyeStartTransferBen
            },
            ISSUE: {
                applicant: fourEyeCounterPartyReceiveStandard,
                beneficiary: fourEyeStartStandard
            },
            CANCEL: {
                applicant: fourEyeCounterPartyReceiveStandard,
                beneficiary: fourEyeStartTwoStep
            },
            AMEND: {
                applicant: fourEyeCounterPartyReceiveStandard,
                beneficiary: fourEyeStartStandard
            },
            DEMAND: {
                beneficiary: fourEyeStartTwoStep
            }
        }
    },
    beneficiary2: {
        SOLE_APPROVER: {
            TRANSFER: {
                applicant: soleApproverCounterPartyReceiveTransferApplicantNewBen,
                beneficiary: soleApproverReceiveTransferAsNewBenFromOldBen
            }
        },
        FOUR_EYE: {
            TRANSFER: {
                applicant: fourEyeCounterPartyReceiveTransferApplicantNewBen,
                beneficiary: fourEyeReceiveTransferAsNewBenFromOldBen
            }
        }
    }
}

export default actionsTree
