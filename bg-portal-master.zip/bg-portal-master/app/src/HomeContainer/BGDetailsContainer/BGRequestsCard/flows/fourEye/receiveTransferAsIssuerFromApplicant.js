export default {
    START: {
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_OLD_BENEFICIARY"
                },
                REJECT_OLD_BEN: {
                    nextState: "REJECTED_BY_OLD_BENEFICIARY"
                },
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_NEW_BENEFICIARY"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_BY_NEW_BENEFICIARY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_BY_OLD_BENEFICIARY: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "SUBMITTED"
                },
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_BOTH_BENEFICIARIES"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_BY_NEW_BENEFICIARY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_OLD_BENEFICIARY: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_NEW_BENEFICIARY: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED"
                },
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_BOTH_BENEFICIARIES"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_NEW_BENEFICIARY: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_BOTH_BENEFICIARIES: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_PROPOSER_INTERNAL",
                    roles: ["PROPOSER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_PROPOSER_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "APPROVED_BY_NEW_BENEFICIARY"
                },
                REVOKE_NEW_BEN: {
                    nextState: "APPROVED_BY_OLD_BENEFICIARY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_BY_PROPOSER_INTERNAL: {
        stepper: 4,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED",
                    roles: ["APPROVER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "APPROVED_BY_BOTH_BENEFICIARIES",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "APPROVED_BY_NEW_BENEFICIARY"
                },
                REVOKE_NEW_BEN: {
                    nextState: "APPROVED_BY_OLD_BENEFICIARY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_PROPOSER_INTERNAL: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED_BY_PROPOSER"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_PROPOSER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REJECTED_BY_APPROVER_INTERNAL: {
        stepper: -5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED_BY_APPROVER"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_APPROVER: {
        stepper: -5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED: {
        stepper: 5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
