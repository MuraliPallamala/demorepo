export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "SUBMITTED_APPROVED_BY_PROPOSER_INTERNAL",
                    roles: ["PROPOSER"]
                },
                REJECT: {
                    nextState: "SUBMITTED_REJECTED_INTERNAL",
                    roles: ["PROPOSER"]
                }
            },
            EXTERNAL: {
                REJECT_OLD_BEN: {
                    nextState: "REJECTED_BY_OLD_BEN"
                },
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_OLD_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_OLD_BEN: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REVOKED_INTERNAL_SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED_EXTERNAL"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    SUBMITTED_REJECTED_INTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT_OLD_BEN: {
                    nextState: "SUBMITTED_REJECTED_EXTERNAL"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    SUBMITTED_REJECTED_EXTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_APPROVED_BY_PROPOSER_INTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "SUBMITTED_APPROVED_BY_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                REJECT: {
                    nextState: "SUBMITTED_REJECTED_BY_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "SUBMITTED_EXTERNAL",
                    roles: ["APPROVER", "PROPOSER"]
                }
            },
            EXTERNAL: {
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_BOTH_BY_PROPOSER_INTERNAL"
                },
                REJECT_OLD_BEN: {
                    nextState: "REJECTED_BY_OLD_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    SUBMITTED_REJECTED_BY_APPROVER_INTERNAL: {
        INTERNAL: {},
        EXTERNAL: {
            REJECT_OLD_BEN: {
                nextState: "SUBMITTED_REJECTED_EXTERNAL"
            },
            CANCEL: {
                nextState: "CANCELLED_EXTERNAL"
            }
        }
    },
    SUBMITTED_APPROVED_BY_APPROVER_INTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_NEW_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_BY_NEW_BEN: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                REVOKE: {
                    nextState: "REVOKED_INTERNAL_SUBMITTED",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_BOTH_BEN"
                },
                REJECT_OLD_BEN: {
                    nextState: "APPROVED_BY_NEW_BEN_REJECTED_BY_OLD_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_BY_OLD_BEN: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_BOTH_BY_PROPOSER_INTERNAL",
                    roles: ["PROPOSER"]
                },
                REJECT: {
                    nextState: "APPROVED_BY_OLD_BEN_REJECTED_BY_NEW_BEN_INTERNAL",
                    roles: ["PROPOSER"]
                }
            },
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "SUBMITTED_EXTERNAL"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REVOKE_INTERNAL_APPROVED_BY_OLD_BEN: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "APPROVED_BY_OLD_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_BY_OLD_BEN_REJECTED_BY_NEW_BEN_INTERNAL: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT_NEW_BEN: {
                    nextState: "APPROVED_BY_OLD_BEN_REJECTED_BY_NEW_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_BY_BOTH_BY_PROPOSER_INTERNAL: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_BOTH_BY_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                REJECT: {
                    nextState: "APPROVED_BY_OLD_BEN_REJECTED_BY_NEW_BEN_INTERNAL",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "APPROVED_BY_OLD_BEN",
                    roles: ["APPROVER", "PROPOSER"]
                }
            },
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "SUBMITTED_APPROVED_BY_PROPOSER_INTERNAL"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_BY_BOTH_BY_APPROVER_INTERNAL: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_BOTH_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_BY_OLD_BEN_REJECTED_BY_NEW_BEN: {
        stepper: -4,
        INTERNAL: {},
        EXTERNAL: {}
    },
    APPROVED_BY_NEW_BEN_REJECTED_BY_OLD_BEN: {
        stepper: -4,
        INTERNAL: {},
        EXTERNAL: {}
    },
    APPROVED_BY_BOTH_BEN: {
        stepper: 4,
        nextActions: {
            INTERNAL: {
                REVOKE: {
                    nextState: "REVOKE_INTERNAL_APPROVED_BY_OLD_BEN",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "APPROVED_BY_NEW_BEN"
                },
                APPROVE: {
                    nextState: "APPROVED_BY_ISSUER"
                },
                REJECT: {
                    nextState: "REJECTED_BY_ISSUER"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_ISSUER: {
        stepper: -5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_ISSUER: {
        stepper: 5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
