export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_MANAGER",
                    roles: ["MANAGER"]
                },
                DEFER: {
                    nextState: "DEFER_BY_MANAGER",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_BY_MANAGER: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED"
                }
            }
        }
    },
    APPROVED: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    DEFER_BY_MANAGER: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                DEFER: {
                    nextState: "DEFERRED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    DEFERRED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_MANAGER",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    CANCELLED: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
