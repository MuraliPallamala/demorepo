export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_COUNTERPARTY"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_BY_COUNTERPARTY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_BY_COUNTERPARTY: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_PROPOSER",
                    roles: ["PROPOSER"]
                },
                REJECT: {
                    nextState: "REJECTED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_COUNTERPARTY: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    CANCELLED: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_PROPOSER: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED",
                    roles: ["APPROVER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "APPROVED_BY_COUNTERPARTY",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_PROPOSER_INTERNAL: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED_BY_PROPOSER"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_PROPOSER: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_APPROVER_INTERNAL: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_BY_APPROVER"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_APPROVER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
