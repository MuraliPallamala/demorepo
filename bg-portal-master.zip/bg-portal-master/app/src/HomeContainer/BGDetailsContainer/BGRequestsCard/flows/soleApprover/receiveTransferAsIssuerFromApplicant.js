export default {
    START: {
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_OLD_BENEFICIARY"
                },
                REJECT_OLD_BEN: {
                    nextState: "REJECTED_BY_OLD_BENEFICIARY"
                },
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_NEW_BENEFICIARY"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_BY_NEW_BENEFICIARY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_BY_OLD_BENEFICIARY: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "SUBMITTED"
                },
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_BOTH_BENEFICIARIES"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_BY_NEW_BENEFICIARY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_OLD_BENEFICIARY: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_NEW_BENEFICIARY: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED"
                },
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_BOTH_BENEFICIARIES"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_NEW_BENEFICIARY: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_BOTH_BENEFICIARIES: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_MANAGER",
                    roles: ["MANAGER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_MANAGER",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "APPROVED_BY_NEW_BENEFICIARY"
                },
                REVOKE_NEW_BEN: {
                    nextState: "APPROVED_BY_OLD_BENEFICIARY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_BY_MANAGER: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED"
                }
            }
        }
    },
    REJECTED_BY_MANAGER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED"
                }
            }
        }
    },
    CANCELLED: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REJECTED: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
