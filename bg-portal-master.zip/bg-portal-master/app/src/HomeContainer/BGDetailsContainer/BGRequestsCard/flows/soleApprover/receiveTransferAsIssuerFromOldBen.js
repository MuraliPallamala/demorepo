export default {
    START: {
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_COUNTERPARTY"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_BY_COUNTERPARTY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_BY_COUNTERPARTY: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_MANAGER",
                    roles: ["MANAGER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_MANAGER",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_COUNTERPARTY: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    CANCELLED: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_MANAGER: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED"
                }
            }
        }
    },
    REJECTED_BY_MANAGER: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED"
                }
            }
        }
    },
    APPROVED: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REJECTED: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
