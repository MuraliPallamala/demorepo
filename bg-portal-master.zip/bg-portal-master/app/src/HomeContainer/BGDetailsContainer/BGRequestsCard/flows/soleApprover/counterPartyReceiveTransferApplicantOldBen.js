export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "SUBMITTED_APPROVED_INTERNAL",
                    roles: ["MANAGER"]
                },
                REJECT: {
                    nextState: "SUBMITTED_REJECTED_INTERNAL",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_BY_NEW_BEN"
                },
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_NEW_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_NEW_BEN: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REVOKED_INTERNAL_SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    SUBMITTED_REJECTED_INTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT_OLD_BEN: {
                    nextState: "SUBMITTED_REJECTED_EXTERNAL",
                    roles: ["MANAGER"]
                }
            }
        }
    },
    SUBMITTED_REJECTED_EXTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_APPROVED_INTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_OLD_BEN"
                }
            }
        }
    },
    APPROVED_BY_OLD_BEN: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                REVOKE: {
                    nextState: "REVOKED_INTERNAL_SUBMITTED",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_BOTH_BEN"
                },
                REJECT_NEW_BEN: {
                    nextState: "APPROVED_BY_OLD_BEN_REJECTED_BY_NEW_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_BY_NEW_BEN: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_BOTH_INTERNAL",
                    roles: ["MANAGER"]
                },
                REJECT: {
                    nextState: "APPROVED_BY_NEW_BEN_REJECTED_BY_OLD_BEN_INTERNAL",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED_EXTERNAL"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REVOKE_INTERNAL_APPROVED_BY_NEW_BEN: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "APPROVED_BY_NEW_BEN"
                }
            }
        }
    },
    APPROVED_BY_NEW_BEN_REJECTED_BY_OLD_BEN_INTERNAL: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT_OLD_BEN: {
                    nextState: "APPROVED_BY_NEW_BEN_REJECTED_BY_OLD_BEN"
                }
            }
        }
    },
    APPROVED_BY_BOTH_INTERNAL: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_BOTH_BEN"
                }
            }
        }
    },
    APPROVED_BY_OLD_BEN_REJECTED_BY_NEW_BEN: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_NEW_BEN_REJECTED_BY_OLD_BEN: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_BOTH_BEN: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                REVOKE: {
                    nextState: "REVOKE_INTERNAL_APPROVED_BY_NEW_BEN",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "APPROVED_BY_OLD_BEN"
                },
                APPROVE: {
                    nextState: "APPROVED_BY_ISSUER"
                },
                REJECT: {
                    nextState: "REJECTED_BY_ISSUER"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_ISSUER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_ISSUER: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
