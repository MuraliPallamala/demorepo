export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_NEW_BEN"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_EXTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_NEW_BEN: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED_EXTERNAL",
                    roles: []
                },
                APPROVE: {
                    nextState: "APPROVED_BY_ISSUER",
                    roles: []
                },
                REJECT: {
                    nextState: "REJECTED_BY_ISSUER",
                    roles: []
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_ISSUER: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_ISSUER: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
