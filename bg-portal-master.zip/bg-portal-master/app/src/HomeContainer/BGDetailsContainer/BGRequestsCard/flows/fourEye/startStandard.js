const prefill = {
    P_PREFILL_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                SUBMIT: {
                    nextState: "P_SUBMITTED_INTERNAL"
                },
                REJECT: {
                    nextState: "P_REJECTED_INTERNAL"
                }
            },
            EXTERNAL: {}
        }
    },
    P_SUBMITTED_INTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "P_SUBMITTED_INTERNAL_APPROVED",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "P_CANCELLED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                },
                REJECT: {
                    nextState: "P_REJECTED_INTERNAL",
                    roles: ["APPROVER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "P_SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    P_SUBMITTED_INTERNAL_APPROVED: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "P_SYSTEM_CANCELLED_EXTERNAL"
                },
                SUBMIT: {
                    nextState: "P_SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    P_CANCELLED_INTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "P_SELF_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    P_REJECTED_INTERNAL: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "P_SELF_REJECTED_EXTERNAL"
                }
            }
        }
    },
    P_SELF_CANCELLED_EXTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_SELF_REJECTED_EXTERNAL: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_SYSTEM_CANCELLED_EXTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_SUBMITTED_EXTERNAL: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "P_CANCELLED_INTERNAL",
                    roles: ["PROPOSER"]
                }
            },
            EXTERNAL: {
                APPROVE: {
                    nextState: "P_APPROVED_BY_COUNTER_PARTY"
                },
                REJECT: {
                    nextState: "P_REJECTED_BY_COUNTER_PARTY"
                },
                WITHDRAW: {
                    nextState: "P_REJECTED_BY_COUNTER_PARTY"
                },
                CANCEL: {
                    nextState: "P_SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    P_REJECTED_BY_COUNTER_PARTY: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_APPROVED_BY_COUNTER_PARTY: {
        stepper: 4,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "P_CANCELLED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE: {
                    nextState: "P_SUBMITTED_EXTERNAL",
                    roles: []
                },
                APPROVE: {
                    nextState: "P_APPROVED_BY_ISSUER",
                    roles: []
                },
                REJECT: {
                    nextState: "P_REJECTED_BY_ISSUER",
                    roles: []
                },
                WITHDRAW: {
                    nextState: "P_REJECTED_BY_COUNTER_PARTY"
                },
                CANCEL: {
                    nextState: "P_SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    P_REJECTED_BY_ISSUER: {
        stepper: -5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_APPROVED_BY_ISSUER: {
        stepper: 5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}

export default {
    ...prefill,
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_INTERNAL"
                }
            },
            EXTERNAL: {
                PREFILL: {
                    nextState: "P_PREFILL_EXTERNAL"
                }
            }
        }
    },
    SUBMITTED_INTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "SUBMITTED_INTERNAL_APPROVED",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                },
                REJECT: {
                    nextState: "REJECTED_INTERNAL",
                    roles: ["APPROVER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    SUBMITTED_INTERNAL_APPROVED: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                },
                SUBMIT: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    CANCELLED_INTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "SELF_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_INTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "SELF_REJECTED_EXTERNAL"
                }
            }
        }
    },
    SELF_CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SELF_REJECTED_EXTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SYSTEM_CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_EXTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_COUNTER_PARTY"
                },
                REJECT: {
                    nextState: "REJECTED_BY_COUNTER_PARTY"
                },
                WITHDRAW: {
                    nextState: "REJECTED_BY_COUNTER_PARTY"
                },
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_COUNTER_PARTY: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_COUNTER_PARTY: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED_EXTERNAL",
                    roles: []
                },
                APPROVE: {
                    nextState: "APPROVED_BY_ISSUER",
                    roles: []
                },
                REJECT: {
                    nextState: "REJECTED_BY_ISSUER",
                    roles: []
                },
                WITHDRAW: {
                    nextState: "REJECTED_BY_COUNTER_PARTY"
                },
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_ISSUER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_ISSUER: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
