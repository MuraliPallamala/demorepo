export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    WITHDRAW_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                REJECT: {
                    nextState: "REJECTED_PROPOSER_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                },
                APPROVE: {
                    nextState: "APPROVED_PROPOSER_INTERNAL",
                    roles: ["PROPOSER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                },
                WITHDRAW: {
                    nextState: "WITHDRAW_EXTERNAL"
                }
            }
        }
    },
    REVOKED_INTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                },
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_PROPOSER_INTERNAL: {
        stepper: -2,
        nextActions: {
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_PROPOSER"
                }
            }
        }
    },
    REJECTED_PROPOSER: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_PROPOSER_INTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                REJECT: {
                    nextState: "REJECTED_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "SUBMITTED_EXTERNAL",
                    roles: ["APPROVER", "PROPOSER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_APPROVER_INTERNAL: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_APPROVER"
                }
            }
        }
    },
    REJECTED_APPROVER: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_APPROVER_INTERNAL: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_APPROVER"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_APPROVER: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                REVOKE: {
                    nextState: "REVOKED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_ISSUER",
                    roles: []
                },
                REJECT: {
                    nextState: "REJECTED_BY_ISSUER",
                    roles: []
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                },
                WITHDRAW: {
                    nextState: "WITHDRAW_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_ISSUER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_ISSUER: {
        stepper: 4,
        INTERNAL: {},
        EXTERNAL: {}
    }
}
