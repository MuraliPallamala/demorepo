export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_INTERNAL"
                }
            },
            EXTERNAL: {}
        }
    },
    SUBMITTED_INTERNAL: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    CANCELLED_INTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "SELF_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    SELF_CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SYSTEM_CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_OLD_BEN"
                },
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_NEW_BEN"
                },
                REJECT_OLD_BEN: {
                    nextState: "REJECT_BY_OLD_BEN"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECT_BY_NEW_BEN"
                },
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_OLD_BEN: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REJECTED_BY_NEW_BEN: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_OLD_BEN: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "SUBMITTED_EXTERNAL"
                },
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_BOTH_BEN"
                },
                REJECT_NEW_BEN: {
                    nextState: "APPROVED_BY_OLD_BEN_REJECTED_BY_NEW_BEN"
                },
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_BY_NEW_BEN: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED_EXTERNAL"
                },
                APPROVE_OLD_BEN: {
                    nextState: "APPROVED_BY_BOTH_BEN"
                },
                REJECT_OLD_BEN: {
                    nextState: "APPROVED_BY_NEW_BEN_REJECTED_BY_OLD_BEN"
                },
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    APPROVED_BY_OLD_BEN_REJECTED_BY_NEW_BEN: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_NEW_BEN_REJECTED_BY_OLD_BEN: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_BOTH_BEN: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REVOKE_OLD_BEN: {
                    nextState: "APPROVED_BY_NEW_BEN"
                },
                REVOKE_NEW_BEN: {
                    nextState: "APPROVED_BY_OLD_BEN"
                },
                APPROVE: {
                    nextState: "APPROVED_BY_ISSUER"
                },
                REJECT: {
                    nextState: "REJECTED_BY_ISSUER"
                },
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_ISSUER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_ISSUER: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
