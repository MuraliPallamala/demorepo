export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    WITHDRAW_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED_BY_ISSUER"
                },
                APPROVE: {
                    nextState: "APPROVED_BY_ISSUER"
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                },
                WITHDRAW: {
                    nextState: "WITHDRAW_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_ISSUER: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_ISSUER: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
