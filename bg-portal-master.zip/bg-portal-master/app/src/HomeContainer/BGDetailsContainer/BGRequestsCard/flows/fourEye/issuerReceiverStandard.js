const prefill = {
    P_PREFILL_SUBMITTED_INTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                PREFILL: {
                    nextState: "P_PREFILL_SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    P_PREFILL_SUBMITTED_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "P_SUBMITTED"
                }
            }
        }
    },
    P_SUBMITTED: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "P_APPROVED_BY_COUNTERPARTY"
                },
                REJECT: {
                    nextState: "P_REJECTED_BY_COUNTERPARTY"
                },
                CANCEL: {
                    nextState: "P_CANCELLED"
                }
            }
        }
    },
    P_APPROVED_BY_COUNTERPARTY: {
        // here
        stepper: 3,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "P_APPROVED_BY_PROPOSER",
                    roles: ["PROPOSER"]
                },
                REJECT: {
                    nextState: "P_REJECTED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE: {
                    nextState: "P_SUBMITTED"
                },
                CANCEL: {
                    nextState: "P_CANCELLED"
                }
            }
        }
    },
    P_REJECTED_BY_COUNTERPARTY: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_CANCELLED: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_APPROVED_BY_PROPOSER: {
        stepper: 4,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "P_APPROVED",
                    roles: ["APPROVER"]
                },
                REJECT: {
                    nextState: "P_REJECTED_BY_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "P_APPROVED_BY_COUNTERPARTY",
                    roles: ["APPROVER", "PROPOSER"]
                }
            },
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    P_REJECTED_BY_PROPOSER_INTERNAL: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED_BY_PROPOSER"
                }
            }
        }
    },
    P_REJECTED_BY_PROPOSER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_REJECTED_BY_APPROVER_INTERNAL: {
        stepper: -5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED"
                },
                REJECT: {
                    nextState: "REJECTED_BY_APPROVER"
                }
            }
        }
    },
    P_REJECTED_BY_APPROVER: {
        stepper: -5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_APPROVED: {
        stepper: 5,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}

export default {
    ...prefill,
    START: {
        nextActions: {
            INTERNAL: {
                PREFILL: {
                    nextState: "P_PREFILL_SUBMITTED_INTERNAL",
                    roles: ["PROPOSER"]
                }
            },
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_COUNTERPARTY"
                },
                REJECT: {
                    nextState: "REJECTED_BY_COUNTERPARTY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_BY_COUNTERPARTY: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_PROPOSER_INTERNAL",
                    roles: ["PROPOSER"]
                },
                REJECT: {
                    nextState: "REJECTED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_COUNTERPARTY: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    CANCELLED: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_PROPOSER_INTERNAL: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "APPROVED_BY_COUNTERPARTY",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_PROPOSER_INTERNAL: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED_BY_PROPOSER"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_PROPOSER: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REJECTED_BY_APPROVER_INTERNAL: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED"
                },
                REJECT: {
                    nextState: "REJECTED_BY_APPROVER"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_APPROVER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_APPROVER_INTERNAL: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
