const prefill = {
    P_PREFILL_SUBMITTED_INTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                PREFILL: {
                    nextState: "P_PREFILL_SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    P_PREFILL_SUBMITTED_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "P_SUBMITTED"
                }
            }
        }
    },
    P_SUBMITTED: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "P_APPROVED_BY_BENEFICIARY"
                },
                REJECT: {
                    nextState: "P_REJECTED_BY_BENEFICIARY"
                },
                CANCEL: {
                    nextState: "P_CANCELLED"
                }
            }
        }
    },
    P_APPROVED_BY_BENEFICIARY: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "P_APPROVED_BY_MANAGER",
                    roles: ["MANAGER"]
                },
                REJECT: {
                    nextState: "P_REJECTED_BY_MANAGER",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REVOKE: {
                    nextState: "P_SUBMITTED"
                },
                CANCEL: {
                    nextState: "P_CANCELLED"
                }
            }
        }
    },
    P_REJECTED_BY_BENEFICIARY: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_CANCELLED: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_APPROVED_BY_MANAGER: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "P_APPROVED"
                }
            }
        }
    },
    P_REJECTED_BY_MANAGER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "P_REJECTED"
                }
            }
        }
    },
    P_APPROVED: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    P_REJECTED: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}

export default {
    ...prefill,
    START: {
        nextActions: {
            INTERNAL: {
                PREFILL: {
                    nextState: "P_PREFILL_SUBMITTED_INTERNAL",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_COUNTERPARTY"
                },
                REJECT: {
                    nextState: "REJECTED_BY_COUNTERPARTY"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_BY_COUNTERPARTY: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_MANAGER",
                    roles: ["MANAGER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_MANAGER",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_COUNTERPARTY: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    CANCELLED: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_MANAGER: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED"
                }
            }
        }
    },
    REJECTED_BY_MANAGER: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED"
                }
            }
        }
    },
    APPROVED: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REJECTED: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
