export default {
    START: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_MANAGER",
                    roles: ["MANAGER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_MANAGER",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    CANCELLED: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_MANAGER: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED"
                }
            }
        }
    },
    REJECTED_BY_MANAGER: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED"
                }
            }
        }
    },
    APPROVED: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REJECTED: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
