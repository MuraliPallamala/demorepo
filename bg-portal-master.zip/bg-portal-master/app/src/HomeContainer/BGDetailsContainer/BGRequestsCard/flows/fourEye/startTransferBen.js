export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_INTERNAL"
                }
            },
            EXTERNAL: {}
        }
    },
    SUBMITTED_INTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "SUBMITTED_INTERNAL_APPROVED",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                },
                REJECT: {
                    nextState: "REJECTED_INTERNAL",
                    roles: ["APPROVER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    SUBMITTED_INTERNAL_APPROVED: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                },
                SUBMIT: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    CANCELLED_INTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "SELF_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_INTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                CANCEL: {
                    nextState: "SELF_REJECTED_EXTERNAL"
                }
            }
        }
    },
    SELF_CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SYSTEM_CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SELF_REJECTED_EXTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_EXTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                APPROVE_NEW_BEN: {
                    nextState: "APPROVED_BY_COUNTER_PARTY"
                },
                REJECT_NEW_BEN: {
                    nextState: "REJECTED_BY_COUNTER_PARTY"
                },
                WITHDRAW: {
                    nextState: "REJECTED_BY_COUNTER_PARTY"
                },
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_COUNTER_PARTY: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_COUNTER_PARTY: {
        stepper: 3,
        nextActions: {
            INTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                REVOKE_NEW_BEN: {
                    nextState: "SUBMITTED_EXTERNAL",
                    roles: []
                },
                APPROVE: {
                    nextState: "APPROVED_BY_ISSUER",
                    roles: []
                },
                REJECT: {
                    nextState: "REJECTED_BY_ISSUER",
                    roles: []
                },
                WITHDRAW: {
                    nextState: "REJECTED_BY_COUNTER_PARTY"
                },
                CANCEL: {
                    nextState: "SYSTEM_CANCELLED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_ISSUER: {
        stepper: -4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_ISSUER: {
        stepper: 4,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
