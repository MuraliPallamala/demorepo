export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    CANCELLED_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    WITHDRAW_EXTERNAL: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    SUBMITTED_EXTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                REJECT: {
                    nextState: "REJECTED_INTERNAL",
                    roles: ["MANAGER"]
                },
                APPROVE: {
                    nextState: "APPROVED_INTERNAL",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                },
                WITHDRAW: {
                    nextState: "WITHDRAW_EXTERNAL"
                }
            }
        }
    },
    REVOKED_INTERNAL: {
        stepper: 1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_INTERNAL: {
        stepper: -2,
        nextActions: {
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED_EXTERNAL"
                }
            }
        }
    },
    REJECTED_EXTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_INTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_SELF",
                    roles: []
                }
            }
        }
    },
    APPROVED_SELF: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                REVOKE: {
                    nextState: "REVOKED_INTERNAL",
                    roles: ["MANAGER"]
                }
            },
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_ISSUER",
                    roles: []
                },
                REJECT: {
                    nextState: "REJECTED_BY_ISSUER",
                    roles: []
                },
                CANCEL: {
                    nextState: "CANCELLED_EXTERNAL"
                },
                WITHDRAW: {
                    nextState: "WITHDRAW_EXTERNAL"
                }
            }
        }
    },
    REJECTED_BY_ISSUER: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED_BY_ISSUER: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
