export default {
    START: {
        stepper: 0,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                },
                DEFER: {
                    nextState: "DEFERRED_BY_PROPOSER_INTERNAL",
                    roles: ["PROPOSER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    APPROVED_INTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                APPROVE: {
                    nextState: "APPROVED"
                }
            }
        }
    },
    APPROVED: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    DEFERRED_BY_PROPOSER_INTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "DEFERRED_BY_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                },
                REJECT: {
                    nextState: "SUBMITTED",
                    roles: ["APPROVER"]
                },
                CANCEL: {
                    nextState: "SUBMITTED",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    DEFERRED_BY_APPROVER_INTERNAL: {
        stepper: 2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                DEFER: {
                    nextState: "DEFERRED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    DEFERRED: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    CANCELLED: {
        stepper: -1,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
