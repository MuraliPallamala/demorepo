export default {
    START: {
        stepper: 1,
        nextActions: {
            EXTERNAL: {
                SUBMIT: {
                    nextState: "SUBMITTED"
                }
            }
        }
    },
    SUBMITTED: {
        stepper: 1,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED_BY_PROPOSER",
                    roles: ["PROPOSER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_PROPOSER_INTERNAL",
                    roles: ["PROPOSER", "APPROVER"]
                }
            },
            EXTERNAL: {
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    CANCELLED: {
        stepper: -1
    },
    APPROVED_BY_PROPOSER: {
        stepper: 2,
        nextActions: {
            INTERNAL: {
                APPROVE: {
                    nextState: "APPROVED",
                    roles: ["APPROVER"]
                },
                REJECT: {
                    nextState: "REJECTED_BY_APPROVER_INTERNAL",
                    roles: ["APPROVER"]
                }
                // ,
                // REVOKE: {
                //     nextState: "?",
                //     roles: ["PROPOSER", "APPROVER"]
                // }
            },
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_PROPOSER_INTERNAL: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REJECT: {
                    nextState: "REJECTED_BY_PROPOSER"
                }
            }
        }
    },
    REJECTED_BY_PROPOSER: {
        stepper: -2,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    REJECTED_BY_APPROVER_INTERNAL: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {
                REVOKE: {
                    nextState: "SUBMITTED"
                },
                REJECT: {
                    nextState: "REJECTED_BY_APPROVER"
                },
                CANCEL: {
                    nextState: "CANCELLED"
                }
            }
        }
    },
    REJECTED_BY_APPROVER: {
        stepper: -3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    },
    APPROVED: {
        stepper: 3,
        nextActions: {
            INTERNAL: {},
            EXTERNAL: {}
        }
    }
}
