// @flow

import * as React from "react"
import { css } from "emotion"
import Stepper from "@material-ui/core/Stepper"
import Step from "@material-ui/core/Step"
import StepLabel from "@material-ui/core/StepLabel"
import { withTheme } from "@material-ui/core/styles"
import ErrorIcon from "@material-ui/icons/Cancel"
import { Flex } from "~/shared/layout"
import generateKey from "~/util/helpers/generateKey"

type Props = {
    whoAmI: string,
    orgToWho: Object,
    approvalModel: Object,
    whoStartedIt: string,
    activeRequest: Object,
    activeRequestActions: Array<Object>,
    activeStep: number,
    theme: Object
}

const getClasses = theme => {
    const body2 = css(theme.typography.body2)
    const errorIcon = css({ fontSize: "30px", transform: "translateY(2px)", color: theme.palette.common.defaultRed })
    const stepper = css(theme.stepper, { maxWidth: "1200" })
    const redButton = css(theme.button, {
        color: theme.palette.common.defaultRed,
        fontWeight: theme.commonFontWeights.regular,
        fontSize: theme.commonFontSizes.small
    })

    return {
        body2,
        errorIcon,
        stepper,
        redButton
    }
}
const getSteps = (
    activeStep,
    approvalModelName,
    activeRequest,
    activeRequestActions,
    whoAmI,
    orgToWho,
    whoStartedIt,
    theme,
    classes
) => {
    const stepperText = getStepperText(
        approvalModelName,
        activeRequest,
        activeRequestActions,
        whoAmI,
        orgToWho,
        whoStartedIt
    )
    let steps = []
    // check if the request has been terminated
    const absoluteActiveStep = Math.abs(activeStep)
    if (activeStep < 0) {
        for (let i = 0; i < absoluteActiveStep; i++) {
            if (i === absoluteActiveStep) {
                let errorText
                if (
                    activeStep === -1 &&
                    activeRequest.type === "ISSUE" &&
                    whoAmI === "beneficiary" &&
                    (whoStartedIt === "applicant" || whoStartedIt === "issuer")
                ) {
                    errorText = "Withdrawn"
                } else {
                    errorText = stepperText[i].replace("Approval", "Rejected by")
                }
                steps.push(
                    <Step key={stepperText[i]}>
                        <StepLabel
                            css={{ color: theme.palette.common.darkBlue }}
                            icon={<ErrorIcon className={classes.errorIcon} />}
                        >
                            {errorText}
                        </StepLabel>
                    </Step>
                )
            } else {
                steps.push(
                    <Step key={stepperText[i]}>
                        <StepLabel css={{ svg: { text: { fill: "#fff !important" } } }}>{stepperText[i]}</StepLabel>
                    </Step>
                )
            }
        }
    } else {
        steps = stepperText.map(label => (
            <Step key={generateKey(label)}>
                <StepLabel css={{ svg: { text: { fill: "#fff !important" } } }} key={`${label}_label`}>
                    {label}
                </StepLabel>
            </Step>
        ))
    }
    return steps
}

const getStepperText = (approvalModel, activeRequest, activeRequestActions, whoAmI, orgToWho, whoStartedIt) => {
    let stepperText = []
    switch (activeRequest.type) {
        case "PAYWALK": {
            stepperText = ["Pay and Walk proposed internally", "Approve Pay and Walk"]
            break
        }
        case "DEMAND": {
            switch (whoAmI) {
                case "beneficiary": {
                    if (approvalModel === "SOLE_APPROVER") {
                        if (
                            activeRequestActions.some(action => action.type === "DEFER" && action.scope === "EXTERNAL")
                        ) {
                            stepperText = ["Initiate Demand", "Demand Deferred by Issuer", "Approval Issuer"]
                        } else {
                            stepperText = ["Initiate Demand", "Approval Issuer"]
                        }
                    } else if (
                        activeRequestActions.some(action => action.type === "DEFER" && action.scope === "EXTERNAL")
                    ) {
                        stepperText = [
                            "Initiate Demand",
                            "Internal Approval",
                            "Demand Deferred by Issuer",
                            "Approval Issuer"
                        ]
                    } else {
                        stepperText = ["Initiate Demand", "Internal Approval", "Approval Issuer"]
                    }
                    break
                }
                case "issuer": {
                    if (approvalModel === "SOLE_APPROVER") {
                        if (
                            activeRequestActions.some(action => action.type === "DEFER" && action.scope === "EXTERNAL")
                        ) {
                            stepperText = ["Demand initiated by Beneficiary", "Demand Deferred"]
                        } else {
                            stepperText = ["Demand initiated by Beneficiary", "Approve Demand"]
                        }
                    } else {
                        const lastAction = activeRequestActions[activeRequestActions.length - 1]
                        if (lastAction.type === "DEFER" && lastAction.scope === "INTERNAL") {
                            stepperText = [
                                "Demand initiated by Beneficiary",
                                "Internal Review",
                                "Review Suggested Deferral"
                            ]
                        } else if (
                            activeRequestActions.some(action => action.type === "DEFER" && action.scope === "EXTERNAL")
                        ) {
                            stepperText = ["Demand initiated by Beneficiary", "Demand Deferred", "Approve Demand"]
                        } else {
                            stepperText = ["Demand initiated by Beneficiary", "Approve Demand"]
                        }
                    }
                    break
                }
                default: {
                    //
                }
            }
            break
        }
        case "TRANSFER": {
            switch (whoStartedIt) {
                case "applicant": {
                    switch (whoAmI) {
                        case "applicant": {
                            const order = getExternalApproveWhoOrder(orgToWho, activeRequestActions)
                            if (approvalModel === "SOLE_APPROVER") {
                                if (order.length === 0 || order[0] === "beneficiary") {
                                    stepperText = [
                                        "Request Initiated",
                                        "Approval Current Beneficiary",
                                        "Approval New Beneficiary",
                                        "Approval Issuer"
                                    ]
                                } else {
                                    stepperText = [
                                        "Request Initiated",
                                        "Approval New Beneficiary",
                                        "Approval Current Beneficiary",
                                        "Approval Issuer"
                                    ]
                                }
                            } else if (order.length === 0 || order[0] === "beneficiary") {
                                stepperText = [
                                    "Request Initiated",
                                    "Approve Request",
                                    "Approval Current Beneficiary",
                                    "Approval New Beneficiary",
                                    "Approval Issuer"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated",
                                    "Approve Request",
                                    "Approval New Beneficiary",
                                    "Approval Current Beneficiary",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "beneficiary": {
                            const order = getExternalApproveWhoOrder(orgToWho, activeRequestActions)
                            if (approvalModel === "SOLE_APPROVER") {
                                if (order.length === 0 || order[0] === "beneficiary") {
                                    stepperText = [
                                        "Request Initiated by Applicant",
                                        "Approve Request",
                                        "Approval New Beneficiary",
                                        "Approval Issuer"
                                    ]
                                } else {
                                    stepperText = [
                                        "Request Initiated by Applicant",
                                        "Approval New Beneficiary",
                                        "Approve Request",
                                        "Approval Issuer"
                                    ]
                                }
                            } else if (order.length === 0 || order[0] === "beneficiary") {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Internal Review",
                                    "Approve Request",
                                    "Approval New Beneficiary",
                                    "Approval Issuer"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Approval New Beneficiary",
                                    "Internal Review",
                                    "Approve Request",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "beneficiary2": {
                            const order = getExternalApproveWhoOrder(orgToWho, activeRequestActions)
                            if (approvalModel === "SOLE_APPROVER") {
                                if (order.length === 0 || order[0] === "beneficiary2") {
                                    stepperText = [
                                        "Request Initiated by Applicant",
                                        "Approve Request",
                                        "Approval Current Beneficiary",

                                        "Approval Issuer"
                                    ]
                                } else {
                                    stepperText = [
                                        "Request Initiated by Applicant",
                                        "Approval Current Beneficiary",
                                        "Approve Request",

                                        "Approval Issuer"
                                    ]
                                }
                            } else if (order.length === 0 || order[0] === "beneficiary2") {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Internal Review",
                                    "Approve Request",
                                    "Approval Current Beneficiary",
                                    "Approval Issuer"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Approval Current Beneficiary",
                                    "Internal Review",
                                    "Approve Request",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "issuer": {
                            const order = getExternalApproveWhoOrder(orgToWho, activeRequestActions)
                            if (approvalModel === "SOLE_APPROVER") {
                                if (order.length === 0 || order[0] === "beneficiary") {
                                    stepperText = [
                                        "Request Initiated by Applicant",
                                        "Approval Current Beneficiary",
                                        "Approval New Beneficiary",
                                        "Approve Request"
                                    ]
                                } else {
                                    stepperText = [
                                        "Request Initiated by Applicant",
                                        "Approval New Beneficiary",
                                        "Approval Current Beneficiary",
                                        "Approve Request"
                                    ]
                                }
                            } else if (order.length === 0 || order[0] === "beneficiary") {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Approval Current Beneficiary",
                                    "Approval New Beneficiary",
                                    "Internal Review",
                                    "Approve Request"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Approval New Beneficiary",
                                    "Approval Current Beneficiary",
                                    "Internal Review",
                                    "Approve Request"
                                ]
                            }
                            break
                        }
                        default: {
                            //
                        }
                    }
                    break
                }
                case "beneficiary": {
                    switch (whoAmI) {
                        case "applicant": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = [
                                    "Request Initiated by Current Beneficiary",
                                    "Approval New Beneficiary",
                                    "Approval Issuer"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated by Current Beneficiary",
                                    "Approval New Beneficiary",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "beneficiary": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = ["Request Initiated", "Approval New Beneficiary", "Approval Issuer"]
                            } else {
                                stepperText = [
                                    "Request Initiated",
                                    "Approve Request",
                                    "Approval New Beneficiary",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "beneficiary2": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = [
                                    "Request Initiated by Current Beneficiary",
                                    "Approve Request",
                                    "Approval Issuer"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated by Current Beneficiary",
                                    "Review Request",
                                    "Approve Request",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "issuer": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = [
                                    "Request Initiated by Current Beneficiary",
                                    "Approval New Beneficiary",
                                    "Approve Request"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated by Current Beneficiary",
                                    "Approval New Beneficiary",
                                    "Internal Review",
                                    "Approve Request"
                                ]
                            }
                            break
                        }
                        default: {
                            //
                        }
                    }
                    break
                }
                default: {
                    //
                }
            }
            break
        }
        case "CANCEL": {
            switch (whoStartedIt) {
                case "applicant": {
                    switch (whoAmI) {
                        case "applicant": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = ["Request Initiated", "Approval Beneficiary", "Approval Issuer"]
                            } else {
                                stepperText = [
                                    "Request Initiated",
                                    "Approve Request",
                                    "Approval Beneficiary",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "beneficiary": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = ["Request Initiated by Applicant", "Approve Request", "Approval Issuer"]
                            } else {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Internal Review",
                                    "Approve Request",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "issuer": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Approval Beneficiary",
                                    "Approve Request"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Approval Beneficiary",
                                    "Internal Review",
                                    "Approve Request"
                                ]
                            }
                            break
                        }
                        default: {
                            break
                        }
                    }
                    break
                }
                case "beneficiary": {
                    switch (whoAmI) {
                        case "applicant": {
                            stepperText = ["Request Initiated by Beneficiary", "Awaiting Issuer's Approval"]
                            return stepperText
                        }
                        case "beneficiary": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = ["Request Initiated", "Approval Issuer"]
                            } else {
                                stepperText = ["Request Initiated", "Approve Request", "Approval Issuer"]
                            }
                            return stepperText
                        }
                        case "issuer": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = ["Request Initiated by Beneficiary", "Approve Request"]
                            } else {
                                stepperText = ["Request Initiated by Beneficiary", "Internal Review", "Approve Request"]
                            }
                            return stepperText
                        }
                        default: {
                            break
                        }
                    }
                    break
                }
                case "issuer": {
                    if (approvalModel === "FOUR_EYE") {
                        return ["Request Initiated", "Approve Request"]
                    }
                    break
                }
                default: {
                    break
                }
            }
            break
        }
        case "ISSUE":
        case "AMEND": {
            switch (whoStartedIt) {
                case "applicant": {
                    switch (whoAmI) {
                        case "applicant": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = ["Request Initiated", "Approval Beneficiary", "Approval Issuer"]
                            } else {
                                stepperText = [
                                    "Request Initiated",
                                    "Approve Request",
                                    "Approval Beneficiary",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "beneficiary": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = ["Request Initiated by Applicant", "Approve Request", "Approval Issuer"]
                            } else {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Internal Review",
                                    "Approve Request",
                                    "Approval Issuer"
                                ]
                            }
                            break
                        }
                        case "issuer": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Approval Beneficiary",
                                    "Approve Request"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated by Applicant",
                                    "Approval Beneficiary",
                                    "Internal Review",
                                    "Approve Request"
                                ]
                            }
                            break
                        }
                        default: {
                            break
                        }
                    }
                    break
                }
                case "beneficiary": {
                    switch (whoAmI) {
                        case "applicant": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = ["Request Initiated by Beneficiary", "Approve Request", "Approval Issuer"]
                            } else {
                                stepperText = [
                                    "Request Initiated by Beneficiary",
                                    "Internal Review",
                                    "Approve Request",
                                    "Approval Issuer"
                                ]
                            }
                            return stepperText
                        }
                        case "beneficiary": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = ["Request Initiated", "Approval Applicant", "Approval Issuer"] // "External Approval"]
                            } else {
                                stepperText = [
                                    "Request Initiated",
                                    "Approve Request",
                                    "Approval Applicant",
                                    "Approval Issuer"
                                ] // "External Approval"]
                            }
                            return stepperText
                        }
                        case "issuer": {
                            if (approvalModel === "SOLE_APPROVER") {
                                stepperText = [
                                    "Request Initiated by Beneficiary",
                                    "Approval Applicant",
                                    "Approve Request"
                                ]
                            } else {
                                stepperText = [
                                    "Request Initiated by Beneficiary",
                                    "Approval Applicant",
                                    "Internal Review",
                                    "Approve Request"
                                ]
                            }
                            return stepperText
                        }
                        default: {
                            break
                        }
                    }
                    break
                }
                case "issuer": {
                    if (approvalModel === "FOUR_EYE") {
                        return ["Request Initiated", "Approve Request"]
                    }
                    break
                }
                default: {
                    break
                }
            }
            break
        }
        default: {
            break
        }
    }
    if (activeRequestActions.length > 0 && activeRequestActions[0].type === "PREFILL") {
        let prefillText
        switch (whoAmI) {
            case "issuer": {
                prefillText = "Prefill Request"
                break
            }
            default: {
                prefillText = "Prefill by Issuer"
            }
        }
        return [prefillText, ...stepperText]
    }

    return stepperText
}

const checkOrgApproved = (orgId: string, activeRequestActions: Array<Object>) => {
    let count = 0
    activeRequestActions
        .filter(action => action.scope === "EXTERNAL")
        .forEach(action => {
            if (action.createdBy.id === orgId) {
                if (action.type === "APPROVE") {
                    count += 1
                } else if (action.type === "REVOKE") {
                    count -= 1
                }
            }
        })
    return count > 0
}

const getExternalApproveWhoOrder = (orgToWho: Object, activeRequestActions: Array<Object>) => {
    const seen = {}
    const whoOrder = []
    const externalApproveActions = activeRequestActions.filter(
        action => action.type === "APPROVE" && action.scope === "EXTERNAL"
    )
    for (let i = externalApproveActions.length - 1; i >= 0; i--) {
        const action = externalApproveActions[i]
        const orgId = action.createdBy.id
        if (!seen[orgId]) {
            seen[orgId] = true
            if (checkOrgApproved(orgId, activeRequestActions)) {
                whoOrder.unshift(orgToWho[orgId])
            }
        }
    }
    return whoOrder
}

const BGRequestCardStepper = (props: Props) => {
    const {
        whoAmI,
        orgToWho,
        activeRequest,
        activeRequestActions,
        activeStep,
        theme,
        approvalModel,
        whoStartedIt
    } = props
    const classes = getClasses(theme)

    const steps = getSteps(
        activeStep,
        approvalModel.name,
        activeRequest,
        activeRequestActions,
        whoAmI,
        orgToWho,
        whoStartedIt,
        theme,
        classes
    )
    return (
        <Flex alignItems="center">
            <Stepper className={classes.stepper} activeStep={Math.abs(activeStep)}>
                {steps}
            </Stepper>
        </Flex>
    )
}

export default withTheme()(BGRequestCardStepper)
