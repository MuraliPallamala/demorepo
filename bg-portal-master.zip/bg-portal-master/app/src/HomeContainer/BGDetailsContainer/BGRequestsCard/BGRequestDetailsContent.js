// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import numeral from "numeral"
import { css } from "emotion"
import Typography from "@material-ui/core/Typography"
import { dateToShortString } from "~/util/helpers/text"
import { Col } from "~/shared/layout"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

const getClasses = ({ theme }) => {
    const body1 = css(theme.typography.body1)
    const body2 = css(theme.typography.body2)
    const body3 = css(theme.typography.body3)
    const boldRed = css(theme.typography.body2, { color: theme.palette.common.defaultRed })
    const indented = css(theme.typography.body1, { marginLeft: "12px" })
    return {
        body1,
        body2,
        body3,
        boldRed,
        indented
    }
}
type Props = {
    activeRequest: Object,
    bgDetails: Object,
    deferReason: string,
    theme: Object,
    purposeType: string,
    purposeTemplates: Templates
}

const fromTo = (label, oldValue, newValue) => {
    // if value being displayed is a boolean, need to display "Yes" and "No" instead
    if (typeof oldValue === "boolean") {
        return (
            <span>
                - The <Bold>{label}</Bold> from <Bold>{oldValue ? "Yes" : "No"}</Bold> to{" "}
                <Bold>{newValue ? "Yes" : "No"}</Bold>
            </span>
        )
    }
    return (
        <span>
            - The <Bold>{label} </Bold>
            {oldValue !== "" ? <span>from {<Bold>{oldValue}</Bold>}</span> : ""} to <Bold>{newValue}</Bold>
        </span>
    )
}
const Reason = withTheme()(({ theme, reason, ...props }) => {
    const classes = getClasses({ theme })
    return (
        <Typography hidden={!reason} className={classes.indented} {...props}>
            - The <Bold>reason</Bold> given is <Bold>{reason}</Bold>
        </Typography>
    )
})
const Item = withTheme()(({ theme, ...props }) => {
    const classes = getClasses({ theme })
    return <Typography className={classes.indented} {...props} />
})
const Bold = withTheme()(({ theme, ...props }) => {
    const classes = getClasses({ theme })
    return <span className={classes.body2} {...props} />
})
const BoldRed = withTheme()(({ theme, ...props }) => {
    const classes = getClasses({ theme })
    return <span className={classes.boldRed} {...props} />
})
const formatExpiry = expiry => {
    if (expiry === "Open Ended") return expiry
    return expiry ? dateToShortString(expiry) : "Open Ended"
}
const buildAmendText = (request, bgDetails, classes, purposeTemplates, purposeType) => {
    const selectedTemplate = purposeTemplates.find(template => template.id === purposeType)

    return (
        <Col>
            <Typography className={classes.body3}>Guarantee Amendment in Progress</Typography>
            <Typography className={classes.body1}>Amendment details:</Typography>
            {request.payload.amount
                ? buildAmountLine(request.payload.amount / 100, bgDetails.type.amount.outstanding, classes)
                : null}
            {request.payload.expiresAt || request.payload.expiresAtOpenEnded
                ? buildExpiresAtLine(bgDetails.type.expiry, request.payload.expiresAt, classes)
                : null}
            {request.payload.purpose && selectedTemplate && buildPurposeAmend({ selectedTemplate, bgDetails, request })}
        </Col>
    )
}
const buildPurposeAmend = ({ selectedTemplate, bgDetails, request }) =>
    selectedTemplate.fields.map(field => {
        // Accounts for nested objects of one level deep
        if (field.subFields && field.subFields.length >= 1) {
            // only build this line if there have been changes to the address
            if (field.appearance.renderAs === "ADDRESS" && request.payload.purpose[field.name]) {
                return buildAddressLine({ bgDetails, request, field })
            }
            return buildPurposeSubFieldLines({ field, bgDetails, request })
        } else if (request.payload.purpose[field.name] !== undefined) {
            // This if statement handles the case when there are no subfields, and the value exists. Will also format if the item is a date object
            let from = bgDetails.purpose[field.name]
            let to = request.payload.purpose[field.name]
            if (field.type === "DATE" && from) {
                from = dateToShortString(from)
            }
            if (field.type === "DATE" && to) {
                to = dateToShortString(to)
            }
            return <Item>{fromTo(field.appearance.label, from, to)}</Item>
        }
        return null
    })

const buildPurposeSubFieldLines = ({ field, bgDetails, request }) =>
    // This second check is because flow does not realise that the check for subFields actually occurs before this function call
    field.subFields &&
    field.subFields.map(subField => {
        if (request.payload.purpose[field.name] && request.payload.purpose[field.name][subField.name] !== undefined) {
            let from = "N/A"
            let to = "N/A"
            if (bgDetails.purpose[field.name] && bgDetails.purpose[field.name][subField.name]) {
                from = bgDetails.purpose[field.name][subField.name]
                if (field.type === "DATE" && from) {
                    from = dateToShortString(from)
                }
            }
            if (request.payload.purpose[field.name] && request.payload.purpose[field.name][subField.name]) {
                to = request.payload.purpose[field.name][subField.name]
                if (field.type === "DATE" && to) {
                    to = dateToShortString(to)
                }
            }
            return <Item>{fromTo(subField.appearance.label, from, to)}</Item>
        }
        return null
    })

const buildAddressLine = ({ field, bgDetails, request }) => {
    let newValue = ""
    let oldValue = ""
    field.subFields.forEach((subField, i) => {
        const notLastKey = field.subFields.length - 1 !== i
        if (bgDetails.purpose[field.name] && bgDetails.purpose[field.name][subField.name] !== undefined) {
            if (notLastKey) {
                oldValue += `${bgDetails.purpose[field.name][subField.name]}, `
            } else {
                oldValue += `${bgDetails.purpose[field.name][subField.name]}`
            }
        } else {
            oldValue += ""
        }
    })
    field.subFields.forEach((subField, i) => {
        const notLastKey = field.subFields.length - 1 !== i
        if (request.payload.purpose[field.name] && request.payload.purpose[field.name][subField.name] !== undefined) {
            if (notLastKey) {
                newValue += `${request.payload.purpose[field.name][subField.name]}, `
            } else {
                newValue += `${request.payload.purpose[field.name][subField.name]}`
            }
        } else if (
            notLastKey &&
            bgDetails.purpose[field.name] &&
            bgDetails.purpose[field.name][subField.name] !== undefined
        ) {
            newValue += `${bgDetails.purpose[field.name][subField.name]}, `
        } else if (bgDetails.purpose[field.name] && bgDetails.purpose[field.name][subField.name] !== undefined) {
            newValue += `${bgDetails.purpose[field.name][subField.name]}`
        }
    })
    return <Item>{fromTo(field.appearance.label, oldValue, newValue)}</Item>
}

const buildExpiresAtLine = (oldExpiry, newExpiry, classes) => {
    // old expiry already gets formatted when loaded from the API during mapping
    const newValue = formatExpiry(newExpiry)
    if (oldExpiry !== newValue) {
        return <Item>{fromTo("expiry date", oldExpiry, newValue)}</Item>
    }
    return null
}

// THIS came from a merge, maybe we still need it?
// const buildBusinessPurposeLine = (oldPurpose, newPurpose, classes) => {
//     if (oldPurpose !== newPurpose) {
//         const oldValue = oldPurpose === "" ? "N/A" : `${oldPurpose}`
//         const newValue = newPurpose === "" ? "N/A" : `${newPurpose}`
//         return <Item>{fromTo("purpose", oldValue, newValue)}</Item>
//     }
//     return null
// }

const buildAmountLine = (newAmount, oldAmount, classes) => {
    if (newAmount !== oldAmount) {
        const oldValue = `AUD ${numeral(oldAmount).format("0,0.00")}`
        const newValue = `AUD ${numeral(newAmount).format("0,0.00")}`
        return <Item>{fromTo("Amount", oldValue, newValue)}</Item>
    }
    return null
}

const buildTransferText = (request, bgDetails, classes) => {
    const oldValue = bgDetails.beneficiary.name
    const newValue = request.payload.beneficiaries[0].entityName
    return (
        <Col>
            <Typography className={classes.body3}>Guarantee Transfer in Progress</Typography>
            <Typography className={classes.indented}>
                - <Bold>Transfer</Bold> from <Bold>{oldValue}</Bold> to <Bold>{newValue}</Bold>
            </Typography>
            <Reason reason={request.payload.reason} />
        </Col>
    )
}

const BGRequestCardStepper = (props: Props) => {
    const { activeRequest, bgDetails, deferReason, theme, purposeTemplates, purposeType } = props
    const classes = getClasses({ theme })

    if (activeRequest.type === "ISSUE") {
        return (
            <Col>
                <Typography className={classes.body3}>
                    Guarantee Issue Request in Progress (See Request Details Above)
                </Typography>
            </Col>
        )
    } else if (activeRequest.type === "AMEND") {
        return buildAmendText(activeRequest, bgDetails, classes, purposeTemplates, purposeType)
    } else if (activeRequest.type === "CANCEL") {
        return (
            <Col>
                <Typography className={classes.body3}>Guarantee Cancellation in Progress</Typography>
                <Reason reason={activeRequest.payload.reason} />
            </Col>
        )
    } else if (activeRequest.type === "TRANSFER") {
        return buildTransferText(activeRequest, bgDetails, classes)
    } else if (activeRequest.type === "DEMAND") {
        return (
            <Col>
                <Typography className={classes.body3}>Guarantee Demand in Progress</Typography>
                <Typography className={classes.indented}>
                    - <Bold>Demanded AUD {numeral(activeRequest.payload.amount / 100).format("0,0.00")}</Bold>
                </Typography>
                <Reason reason={activeRequest.payload.reason} />
                <Typography hidden={deferReason === ""} className={classes.indented}>
                    - The <BoldRed>reason for deferral</BoldRed> is <Bold>{deferReason}</Bold>
                </Typography>
            </Col>
        )
    } else if (activeRequest.type === "PAYWALK") {
        return (
            <Col>
                <Typography className={classes.body3}>Guarantee Pay and Walk in Progress</Typography>
                <Reason reason={activeRequest.payload.reason} />
            </Col>
        )
    }
    return (
        <Col>
            <Typography className={classes.body1}>Unknown request type. This should never happen.</Typography>
        </Col>
    )
}

export default withTheme()(BGRequestCardStepper)
