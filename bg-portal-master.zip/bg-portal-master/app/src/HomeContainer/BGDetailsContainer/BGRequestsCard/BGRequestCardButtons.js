// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"

import Button from "@material-ui/core/Button"
import TextField from "@material-ui/core/TextField"
import { Flex } from "~/shared/layout"
// import type { ButtonType, EditableText, DropdownList } from "~/util/flow_types"
import { Formik } from "formik"
import FormControl from "@material-ui/core/FormControl"
import Typography from "@material-ui/core/Typography"
import FormHelperText from "@material-ui/core/FormHelperText"
import Select from "@material-ui/core/Select"
import MenuItem from "@material-ui/core/MenuItem"
import InputLabel from "@material-ui/core/InputLabel"
// import { issuerMapBGDetails } from "~/util/guarantee"
import generateKey from "~/util/helpers/generateKey"

type Props = {
    primaryActionButtons: Array<Object>,
    primaryActionButtonsText: string,
    secondaryActionButtons: Array<Object>,
    whoAmI: string,
    issuers: Array<Object>,
    hasSufficientGxLimit: boolean,
    currentActionState: Object,
    activeRequestType: string,
    currentUserRoles: Array<string>,
    bankReference: string,
    selectedIssuer: string,
    selectedBankReference: string,
    updateBankReference: Function,
    approvalModelName: string,
    theme: Object,
    activeRequestActions: Array<Object>,
    updateSelectedIssuer: Function
}

type State = {}

const getClasses = ({ theme }) => {
    const body1 = css(theme.typography.body1)
    const buttonContainer = css(theme.buttonContainer)
    const buttonContainerPadding = css(theme.buttonContainer, { paddingRight: "1rem" })
    const footerContainer = css({
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between"
    })
    return {
        body1,
        buttonContainer,
        buttonContainerPadding,
        footerContainer
    }
}

class ButtonContainer extends React.Component<Props, State> {
    // determine if component should update to prevent constant reloading
    shouldComponentUpdate(nextProps, nextState) {
        // generally, the logic should be reversed. but this works for now.
        if (
            this.props.selectedIssuer &&
            this.props.selectedIssuer !== "" &&
            nextProps.selectedIssuer === this.props.selectedIssuer &&
            this.props.whoAmI === "applicant"
        ) {
            return false
        }
        return true
    }

    makePrimaryActionButtonRow = (
        hasSufficientGxLimit,
        whoAmI,
        currentActionState,
        approvalModelName,
        activeRequestType,
        currentUserRoles,
        primaryActionButtons,
        issuers,
        selectedIssuer,
        selectedBankReference,
        activeRequestActions
    ) => {
        // The dropdown needs to be shown for issue requests to allow the issuer to be
        // selected when I'm the applicant, the approve/reject actions can currently be performed,
        // I am a manager (in 2 eye) or proposer (in 4 eye) and I have sufficientGxLimit
        if (
            ((approvalModelName === "SOLE_APPROVER" && currentUserRoles.includes("MANAGER")) ||
                (approvalModelName === "FOUR_EYE" &&
                    currentUserRoles.includes("PROPOSER") &&
                    currentActionState.nextActions.INTERNAL.APPROVE &&
                    currentActionState.nextActions.INTERNAL.APPROVE.nextState === "APPROVED_PROPOSER_INTERNAL")) &&
            hasSufficientGxLimit &&
            activeRequestType === "ISSUE" &&
            whoAmI === "applicant" &&
            currentActionState.nextActions.INTERNAL.APPROVE &&
            // check if this has already been approved with a given issuer. can't reset them then.
            activeRequestActions &&
            activeRequestActions[activeRequestActions.length - 1].type !== "REVOKE"
        ) {
            let submitFunction
            return (
                <Formik
                    initialValues={{
                        issuer: ""
                    }}
                    enableReinitialize
                    validate={values => {
                        const errors = {}
                        if (!values.issuer) {
                            errors.issuer = "Required"
                        }
                        return errors
                    }}
                    onSubmit={(values, { setSubmitting, setErrors }) => {
                        setSubmitting(true)
                        // Assumes that on success component unmounts so no need to call setSubmitting
                        submitFunction(values)
                            .then(() => setSubmitting(false))
                            .catch(() => {
                                setSubmitting(false)
                            })
                    }}
                    render={formikProps => (
                        <form onSubmit={formikProps.handleSubmit}>
                            <Flex justifyContent="space-between">
                                <FormControl error={formikProps.touched.issuer ? !!formikProps.errors.issuer : false}>
                                    <InputLabel shrink>Issuer</InputLabel>
                                    <Select
                                        id="issuer"
                                        css={{ width: "300px" }}
                                        value={formikProps.values.issuer}
                                        onChange={formikProps.handleChange}
                                        inputProps={{
                                            name: "issuer"
                                        }}
                                    >
                                        {issuers.map((item, index) => (
                                            <MenuItem key={generateKey(item.label)} value={item.value}>
                                                {item.label}
                                            </MenuItem>
                                        ))}
                                    </Select>

                                    <FormHelperText>
                                        {formikProps.errors.issuer ? formikProps.errors.issuer : ""}
                                    </FormHelperText>
                                </FormControl>

                                <Flex>
                                    {primaryActionButtons.map((button, index) => {
                                        if (button.name === "APPROVE") {
                                            submitFunction = button.onClick
                                            return (
                                                <Button
                                                    type="submit"
                                                    key={generateKey(button.name)}
                                                    disabled={button.disabled}
                                                    css={{ color: button.color }}
                                                >
                                                    {button.name}
                                                </Button>
                                            )
                                        }
                                        return (
                                            <Button
                                                key={generateKey(button.name)}
                                                disabled={button.disabled}
                                                onClick={button.onClick}
                                                css={{ color: button.color }}
                                            >
                                                {button.name}
                                            </Button>
                                        )
                                    })}
                                </Flex>
                            </Flex>
                        </form>
                    )}
                />
            )
        }
        // all other cases can be handled within the same render block since they don't need to be wrapped in formik
        return (
            <Flex justifyContent="space-between">
                {this.buildNestedBit(
                    whoAmI,
                    currentActionState,
                    approvalModelName,
                    activeRequestType,
                    currentUserRoles,
                    selectedIssuer,
                    selectedBankReference,
                    hasSufficientGxLimit,
                    activeRequestActions
                )}
                <Flex justifyContent="flex-end">
                    {primaryActionButtons.map((button, index) => (
                        <Button
                            key={generateKey(button.name)}
                            disabled={button.disabled}
                            onClick={button.onClick}
                            css={{ color: button.color }}
                        >
                            {button.name}
                        </Button>
                    ))}
                </Flex>
            </Flex>
        )
    }

    // depending on certain conditions, this function will generate jsx for the buttons and optionally
    // for the bankReference input field, or grey out issuer or bankReference
    buildNestedBit = (
        whoAmI,
        currentActionState,
        approvalModelName,
        activeRequestType,
        currentUserRoles,
        selectedIssuer,
        selectedBankReference,
        hasSufficientGxLimit,
        activeRequestActions
    ) => {
        // The bank reference input needs to be shown for issue requests to allow the issuer to
        // enter it when I'm the issuer, the approve/reject actions can currently be performed,
        // I am a manager (in 2 eye) or proposer (in 4 eye)

        if (
            ((approvalModelName === "SOLE_APPROVER" && currentUserRoles.includes("MANAGER")) ||
                (approvalModelName === "FOUR_EYE" &&
                    currentUserRoles.includes("PROPOSER") &&
                    currentActionState.nextActions.INTERNAL.APPROVE &&
                    (currentActionState.nextActions.INTERNAL.APPROVE.nextState === "APPROVED_PROPOSER_INTERNAL" ||
                        currentActionState.nextActions.INTERNAL.APPROVE.nextState === "P_APPROVED_BY_PROPOSER"))) &&
            hasSufficientGxLimit &&
            activeRequestType === "ISSUE" &&
            whoAmI === "issuer" &&
            currentActionState.nextActions.INTERNAL.APPROVE
        ) {
            return (
                <TextField
                    label="Issuer Reference Number (Optional)"
                    placeholder="Issuer Reference Number"
                    value={this.props.bankReference}
                    margin="none"
                    onChange={this.props.updateBankReference}
                    css={{ width: "300px !important" }}
                />
            )
        } else if (
            // TODO: test in four eye etc.. this is supposed to work after revokation and after revokation only. (ben - app acc - app rev - app tries to resubmit)
            // approvalModelName === "SOLE_APPROVER" &&
            // currentUserRoles.includes("MANAGER") &&
            hasSufficientGxLimit &&
            activeRequestType === "ISSUE" &&
            whoAmI === "applicant" &&
            currentActionState.nextActions.INTERNAL.APPROVE &&
            activeRequestActions &&
            activeRequestActions[activeRequestActions.length - 1].type === "REVOKE"
        ) {
            this.props.updateSelectedIssuer(selectedIssuer)
            return <TextField label="Issuer" disabled shrink value={selectedIssuer} />
        } else if (
            // if you are the applicant in four eye and you are a acting as the approver, show the selected issuer
            approvalModelName === "FOUR_EYE" &&
            currentUserRoles.includes("APPROVER") &&
            activeRequestType === "ISSUE" &&
            whoAmI === "applicant" &&
            currentActionState.nextActions.INTERNAL.APPROVE &&
            currentActionState.nextActions.INTERNAL.APPROVE.nextState === "APPROVED_APPROVER_INTERNAL"
        ) {
            return <TextField label="Issuer" disabled shrink value={selectedIssuer} />
        } else if (
            // if you are the issuer in four eye and you are a acting as the approver, show the bank reference
            approvalModelName === "FOUR_EYE" &&
            currentUserRoles.includes("APPROVER") &&
            activeRequestType === "ISSUE" &&
            whoAmI === "issuer" &&
            currentActionState.nextActions.INTERNAL.APPROVE &&
            (currentActionState.nextActions.INTERNAL.APPROVE.nextState === "APPROVED_APPROVER_INTERNAL" ||
                currentActionState.nextActions.INTERNAL.APPROVE.nextState === "P_APPROVED") && // HERE
            selectedBankReference
        ) {
            return (
                <TextField
                    tooltip={selectedBankReference}
                    label="Issuer Reference Number"
                    disabled
                    value={selectedBankReference}
                    css={{ width: "300px !important" }}
                />
            )
        }
        return <div />
    }

    render() {
        const {
            theme,
            primaryActionButtons,
            primaryActionButtonsText,
            secondaryActionButtons,
            currentActionState,
            hasSufficientGxLimit,
            whoAmI,
            approvalModelName,
            activeRequestType,
            currentUserRoles,
            issuers,
            selectedIssuer,
            selectedBankReference,
            activeRequestActions
        } = this.props
        const classes = getClasses({ theme })

        return (
            <React.Fragment>
                <Flex>
                    {secondaryActionButtons.map(button => (
                        <Button
                            key={button.name}
                            disabled={button.disabled}
                            onClick={button.onClick}
                            css={{ color: button.color }}
                        >
                            {button.name}
                        </Button>
                    ))}
                </Flex>
                {this.makePrimaryActionButtonRow(
                    hasSufficientGxLimit,
                    whoAmI,
                    currentActionState,
                    approvalModelName,
                    activeRequestType,
                    currentUserRoles,
                    primaryActionButtons,
                    issuers,
                    selectedIssuer,
                    selectedBankReference,
                    activeRequestActions
                )}
                <Flex className={classes.buttonContainerPadding}>
                    <Typography>
                        <i>{primaryActionButtonsText}</i>
                    </Typography>
                </Flex>
            </React.Fragment>
        )
    }
}

export default withTheme()(ButtonContainer)
