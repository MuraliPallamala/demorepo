// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Card from "@material-ui/core/Card"
import Button from "@material-ui/core/Button"
import CardContent from "@material-ui/core/CardContent"
import { authStorage } from "~/util/auth"

import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import { Flex } from "~/shared/layout"
import { firstLetter } from "~/util/helpers/text"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import actionsTree from "./actionTree"
import BGRequestCardStepper from "./BGRequestCardStepper"
import BGRequestCardButtons from "./BGRequestCardButtons"
import BGRequestDetailsContent from "./BGRequestDetailsContent"
import StepperErrorBoundary from "./StepperErrorBoundary"

type Props = {
    activeRequests: Array<Object>,
    orgToWho: Object,
    whoAmI: string,
    whoStartedRequests: Object,
    hasSufficientGxLimit: boolean,
    userContext: Object,
    currentOrgId: string,
    approvalModel: Object,
    actions: Object,
    bgDetails: Object,
    theme: Object,
    onPrefillIssue: Function,
    onPrefillAmend: Function,
    onPrefillCancel: Function,
    history: Object,
    handleErrorOpen: Function,
    onRejectRequest: Function,
    onApproveRequest: Function,
    onCancelRequest: Function,
    onCancelAndPrefill: Function,
    onRevoke: Function,
    onDefer: Function,
    purposeType: string,
    purposeTemplates: Templates
}

type State = {
    activeIndex: number,
    issuers: Array<Object>,
    bankReference: string,
    selectedIssuer: string,
    loading: boolean
}

const getClasses = ({ theme }) => {
    const bgTitleMedium = css(theme.typography.formTitle, {
        color: "#fff",
        fontSize: theme.commonFontSizes.large
    })
    const bgTitleRegular = css(theme.typography.formTitle, {
        color: "#fff",
        fontWeight: theme.commonFontWeights.regular,
        fontSize: theme.commonFontSizes.large
    })

    const chipStyling = css(theme.typography.body1, {
        fontSize: theme.commonFontSizes.medium,
        fontWeight: theme.commonFontWeights.medium,
        color: "#fff",
        // border: `${theme.palette.common.bgStatusGreen} 3px solid`,
        borderRadius: "3px",
        padding: "0.125rem",
        paddingRight: "0.5rem",
        paddingLeft: "0.5rem",
        marginLeft: "1rem",
        textTransform: "none"
    })
    const labelButton = css(chipStyling, {
        backgroundColor: theme.palette.common.bgSubstatusDarkOrange,
        color: "#fff",
        ":hover": {
            backgroundColor: theme.palette.common.bgSubstatusDarkOrange
        }
    })

    const activeLabelButton = css(chipStyling, {
        color: theme.palette.common.bgSubstatusDarkOrange,
        backgroundColor: "#fff",
        ":hover": {
            backgroundColor: "#fff"
        }
    })
    const header = css({
        backgroundColor: theme.palette.common.bgSubstatusOrange,
        padding: "0.5rem",
        paddingLeft: "24px"
    })

    return {
        bgTitleMedium,
        bgTitleRegular,
        header,
        labelButton,
        chipStyling,
        activeLabelButton
    }
}

class BGRequestsCard extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            activeIndex: 0,
            issuers: [],
            bankReference: "",
            selectedIssuer: "",
            loading: true
        }
    }

    async componentDidMount() {
        await this.initialiseDropdown()
    }

    initialiseDropdown = async () => {
        try {
            this.setState(() => ({ loading: true }))
            const { data } = await api.organisations.getOrgsWithQuery("?entityType=ISSUER")
            this.setState(() => ({
                issuers: [{ value: "", label: "" }].concat(
                    data.result.map(issuer => ({ label: issuer.entityName, value: issuer.id }))
                ),
                loading: false
            }))
        } catch (err) {
            this.props.handleErrorOpen({
                errorMessage: `Getting Organisation Info error`,
                title: "Organisation Error",
                error: err,
                extraDetails: {
                    Info: err.info,
                    CurrentUrl: this.props.history.location.pathname,
                    Payload: {},
                    ErrorResponse: err
                }
            })
            this.setState({ loading: false })
            throw err
        }
    }

    updateBankReference = event => {
        this.setState({
            bankReference: event.target.value
        })
    }

    updateSelectedIssuer = issuer => {
        this.setState({
            selectedIssuer: issuer
        })
    }

    buildRequestButtons = (
        orgToWho,
        whoAmI,
        availableActions,
        userContext,
        activeRequestActions,
        theme,
        activeIndex,
        whoStartedIt,
        currentOrgId,
        approvalModel
    ) => {
        const activeRequest = this.props.activeRequests[this.state.activeIndex]

        // primary buttons
        const rejectButton = {
            name: "REJECT",
            color: theme.palette.common.defaultRed,
            disabled: true,
            onClick: () => this.props.onRejectRequest(activeRequest.id)
        }

        const deferButton = {
            name: "DEFER",
            color: theme.palette.common.defaultRed,
            disabled: true,
            onClick: () => this.props.onDefer(activeRequest.id)
        }

        const approveButton = {
            name: "APPROVE",
            disabled: true,
            color: theme.palette.common.lightBlue,
            onClick: values =>
                this.props.onApproveRequest(
                    activeRequest.id,
                    availableActions.APPROVE.nextState,
                    values.issuer ? values.issuer : this.state.selectedIssuer,
                    this.state.bankReference,
                    "You are about to approve this request."
                )
        }

        // secondary buttons

        const cancelAndTemplateButton = {
            name: "CANCEL REQUEST AND USE AS A TEMPLATE",
            disabled: false,
            color: theme.palette.common.defaultRed,
            onClick: () => this.props.onCancelAndPrefill(activeRequest.id, activeRequest.type)
        }

        const revokeButton = {
            name: "REVOKE",
            disabled: false,
            color: theme.palette.common.defaultRed,
            onClick: () => {
                // get last active approve action id
                const approveActions = this.props.actions[activeRequest.id].filter(
                    action => action.type === "APPROVE" && action.createdBy.id === currentOrgId
                )
                const lastApproveAction = approveActions[approveActions.length - 1]
                return this.props.onRevoke(activeRequest.id, lastApproveAction.id)
            }
        }

        const cancelButton = {
            name: "CANCEL REQUEST",
            disabled: false,
            color: theme.palette.common.defaultRed,
            onClick: () => this.props.onCancelRequest(activeRequest.id, "cancel this request.")
        }

        const rejectIssuePrefillButton = {
            name: "REJECT ISSUE PREFILL",
            disabled: false,
            color: theme.palette.common.defaultRed,
            onClick: () => this.props.onRejectRequest(activeRequest.id)
        }
        const rejectAmendPrefillButton = {
            name: "REJECT AMEND PREFILL",
            disabled: false,
            color: theme.palette.common.defaultRed,
            onClick: () => this.props.onRejectRequest(activeRequest.id)
        }
        const rejectCancelPrefillButton = {
            name: "REJECT CANCEL PREFILL",
            disabled: false,
            color: theme.palette.common.defaultRed,
            onClick: () => this.props.onRejectRequest(activeRequest.id)
        }
        const acceptIssuePrefillButton = {
            name: "ACCEPT ISSUE PREFILL",
            disabled: false,
            color: theme.palette.common.lightBlue,
            onClick: () => this.props.onPrefillIssue(activeRequest.id, true)
        }
        const acceptAmendPrefillButton = {
            name: "ACCEPT AMEND PREFILL",
            disabled: false,
            color: theme.palette.common.lightBlue,
            onClick: () => this.props.onPrefillAmend(activeRequest.id, true)
        }
        const acceptCancelPrefillButton = {
            name: "ACCEPT CANCEL PREFILL",
            disabled: false,
            color: theme.palette.common.lightBlue,
            onClick: () => this.props.onPrefillCancel(activeRequest.id, activeRequest.payload.reason)
        }

        const secondaryActionButtons = []
        let primaryActionButtons = []
        let primaryActionButtonsText = ""

        // set primaryActionButtons and primaryActionButtonsText
        if (availableActions && availableActions.SUBMIT) {
            primaryActionButtons = []
            // PREFILL
            if (activeRequest.type === "ISSUE") {
                primaryActionButtons.push(rejectIssuePrefillButton)
                primaryActionButtons.push(acceptIssuePrefillButton)
                primaryActionButtonsText = "Respond to Issue Prefill"
            } else if (activeRequest.type === "AMEND") {
                primaryActionButtons.push(rejectAmendPrefillButton)
                primaryActionButtons.push(acceptAmendPrefillButton)
                primaryActionButtonsText = "Respond to Amend Prefill"
            } else if (activeRequest.type === "CANCEL") {
                primaryActionButtons.push(rejectCancelPrefillButton)
                primaryActionButtons.push(acceptCancelPrefillButton)
                primaryActionButtonsText = "Respond to Cancel Prefill"
            }
        } else if (availableActions && availableActions.APPROVE && availableActions.REJECT) {
            primaryActionButtons = [rejectButton, approveButton]

            // find out if primaryActionButtons should be greyed out

            for (let i = 0; i < primaryActionButtons.length; ++i) {
                if (
                    (primaryActionButtons[i].name === "APPROVE" &&
                        availableActions.APPROVE &&
                        availableActions.APPROVE.roles.length > 0 &&
                        !userContext.userRoles[currentOrgId].some(r => availableActions.APPROVE.roles.includes(r))) ||
                    (primaryActionButtons[i].name === "REJECT" &&
                        availableActions.REJECT &&
                        availableActions.REJECT.roles.length > 0 &&
                        !userContext.userRoles[currentOrgId].some(r => availableActions.REJECT.roles.includes(r)))
                ) {
                    primaryActionButtons[i].disabled = true
                    primaryActionButtonsText = "Some actions require additional approval model roles."
                } else {
                    primaryActionButtons[i].disabled = false
                }
            }

            if (activeRequest.type === "DEMAND" && whoAmI === "issuer") {
                approveButton.name = "APPROVE DEFER"
                approveButton.onClick = values =>
                    this.props.onApproveRequest(
                        activeRequest.id,
                        availableActions.APPROVE.nextState,
                        values.issuer,
                        this.state.bankReference,
                        "You are about to approve the deferral of this demand request."
                    )
                rejectButton.name = "REJECT DEFER"
            }
        } else if (activeRequest.type === "DEMAND") {
            // DEMAND
            // only issuers have primary actions
            if (PORTAL_TYPE === "issuer") {
                primaryActionButtons = [deferButton, approveButton]
                if (
                    availableActions.DEFER &&
                    userContext.userRoles[currentOrgId].some(r => availableActions.DEFER.roles.includes(r))
                ) {
                    deferButton.disabled = false
                }
                if (
                    availableActions.APPROVE &&
                    userContext.userRoles[currentOrgId].some(r => availableActions.APPROVE.roles.includes(r))
                ) {
                    approveButton.name = "MARK AS PAID"
                    approveButton.disabled = false
                    approveButton.onClick = values =>
                        this.props.onApproveRequest(
                            activeRequest.id,
                            availableActions.APPROVE.nextState,
                            values.issuer,
                            this.state.bankReference,
                            "You are about to mark this demand as paid."
                        )
                }
            }
        }

        if (activeIndex !== 0) {
            for (let i = 0; i < primaryActionButtons.length; ++i) {
                primaryActionButtons[i].disabled = true
            }
            primaryActionButtonsText = "Requests of higher priority need to be resolved first."
        } else if (primaryActionButtons && primaryActionButtons.length === 2) {
            if (
                (this.hasAuthoredInternalApprove(activeRequestActions, userContext.id) ||
                    this.hasAuthoredInternalSubmit(activeRequestActions, userContext.id) ||
                    this.hasAuthoredInternalDefer(activeRequestActions, userContext.id)) &&
                approvalModel.name === "FOUR_EYE"
            ) {
                primaryActionButtons[0].disabled = true
                primaryActionButtons[1].disabled = true
                primaryActionButtonsText = "This request needs to be processed by another person in your organisation."
                // mark as paid button should not be disabled based on who did other actions previously
                if (primaryActionButtons[1].name === "MARK AS PAID") {
                    primaryActionButtons = [approveButton]
                    // primaryActionButtons[0].name = "MARK AS PAID"
                    primaryActionButtons[0].disabled = false
                    primaryActionButtonsText = ""
                }
            }

            if (!this.props.hasSufficientGxLimit) {
                primaryActionButtons[0].disabled = true
                primaryActionButtons[1].disabled = true
                primaryActionButtonsText = "The value of this Guarantee exceeds your threshold."
            }
        } else if (activeRequest.status === "APPROVED") {
            primaryActionButtonsText = "This request had been approved."
        } else {
            primaryActionButtonsText = "This request is currently being processed by another organisation."
        }

        // setting secondary action buttons
        if (
            availableActions.CANCEL &&
            availableActions.CANCEL.roles.length > 0 &&
            userContext.userRoles[currentOrgId].some(r => availableActions.CANCEL.roles.includes(r))
            // && this.hasAuthoredInternalApprove(activeRequestActions, userContext.id, approvalModel.name)
        ) {
            if (activeRequest.type === "DEMAND" && whoAmI === "issuer") {
                cancelButton.name = "CANCEL DEFER"
                cancelButton.onClick = () =>
                    this.props.onCancelRequest(activeRequest.id, "cancel the deferral process.")
            }
            if (whoAmI !== whoStartedIt) {
                cancelButton.name = "REVOKE INTERNAL APPROVAL"
                cancelButton.onClick = () =>
                    this.props.onCancelRequest(activeRequest.id, "revoke approval for this request.")
            }
            secondaryActionButtons.push(cancelButton)
        }

        if (
            availableActions.REVOKE &&
            availableActions.REVOKE.roles.length > 0 &&
            userContext.userRoles[currentOrgId].some(r => availableActions.REVOKE.roles.includes(r))
        ) {
            revokeButton.name = "REVOKE ORGANISATION'S APPROVAL"
            secondaryActionButtons.push(revokeButton)
        }

        if (
            activeRequest.createdBy.id === currentOrgId &&
            availableActions.CANCEL &&
            availableActions.CANCEL.roles.length > 0 &&
            ["ISSUE", "AMEND", "TRANSFER", "DEMAND"].includes(activeRequest.type) &&
            userContext.userRoles[currentOrgId].some(r => availableActions.CANCEL.roles.includes(r)) &&
            ((approvalModel.name === "FOUR_EYE" && userContext.userRoles[currentOrgId].includes("PROPOSER")) ||
                (approvalModel.name === "SOLE_APPROVER" && userContext.userRoles[currentOrgId].includes("MANAGER")))
        ) {
            secondaryActionButtons.push(cancelAndTemplateButton)
        }

        // disable secondary action buttons if the person's gx limit is too low.
        if (!this.props.hasSufficientGxLimit) {
            secondaryActionButtons.forEach(button => {
                button.disabled = true
            })
        }

        return { primaryActionButtons, secondaryActionButtons, primaryActionButtonsText }
    }

    hasAuthoredInternalApprove = (actions, userId) => {
        const lastAction = actions[actions.length - 1]
        if (lastAction.type === "APPROVE" && lastAction.scope === "INTERNAL" && lastAction.authoredBy.id === userId) {
            return true
        }
        // catch the case where we are in a transfer and in 4 eye approval, the internal approval flow is 'interrupted' by the other org approving externally
        if (actions.length >= 2) {
            const secondLastAction = actions[actions.length - 2]
            if (
                lastAction.type === "APPROVE" &&
                lastAction.scope === "EXTERNAL" &&
                secondLastAction.type === "APPROVE" &&
                secondLastAction.scope === "INTERNAL" &&
                secondLastAction.authoredBy.id === userId
            ) {
                return true
            }
        }
        return false
    }

    hasAuthoredInternalSubmit = (actions, userId) => {
        const submitCount = actions.filter(action => {
            if (action.type === "SUBMIT" && action.scope === "INTERNAL" && action.authoredBy.id === userId) {
                return true
            }
            return false
        })
        return submitCount.length > 0
    }

    hasAuthoredInternalDefer = (actions, userId) => {
        const approveCount = actions.reduce((acc, action) => {
            if (action.type === "DEFER" && action.scope === "INTERNAL" && action.authoredBy.id === userId) {
                return acc + 1
            }
            if (action.type === "CANCEL" && action.scope === "INTERNAL" && action.authoredBy.id === userId) {
                return acc - 1
            }
            if (action.type === "REJECT" && action.scope === "INTERNAL") {
                return acc - 1
            }
            return acc
        }, 0)
        return approveCount > 0
    }

    getAvailableActionsandActiveStepFromTree = (
        tree,
        approvalModelName,
        orgToWho,
        whoAmI,
        whoStartedIt,
        activeRequest,
        actions
    ) => {
        authStorage.addLogToErrorQueue(
            `\nWhoAmI:${whoAmI}
            ApprovalModelName: ${JSON.stringify(approvalModelName)}
            activeRequest: ${JSON.stringify(activeRequest)}
            WhoStartedIt: ${JSON.stringify(whoStartedIt)}
            orgToWho: ${JSON.stringify(orgToWho)}`
        )
        const stateMachineBranch = tree[whoAmI][approvalModelName][activeRequest.type][whoStartedIt]

        // return empty action if organisation can't act
        if (stateMachineBranch === null) {
            return {
                currentActionState: {
                    stepper: -99,
                    nextActions: {
                        INTERNAL: {}
                    }
                }
            }
        }
        let currentState = stateMachineBranch.START
        authStorage.addLogToErrorQueue(`\nstateMachineBranch start: ${JSON.stringify(stateMachineBranch.START)}`)
        // iterate through actions to determine the current state

        for (let i = 0; i < actions.length; ++i) {
            const currentAction = actions[i]
            authStorage.addLogToErrorQueue(`\nCurrentAction: ${JSON.stringify(currentAction)}`)
            authStorage.addLogToErrorQueue(`\nNew CurrentState In For Loop: ${JSON.stringify(currentState)}`)
            const nextStateKey =
                currentState.nextActions[currentAction.scope][
                    this.getActionType(orgToWho, activeRequest, currentAction)
                ].nextState
            // get the new current state
            currentState = stateMachineBranch[nextStateKey]
        }
        authStorage.addLogToErrorQueue(`\nFinal State: ${JSON.stringify(currentState)}`)
        return { currentActionState: currentState }
    }

    // Map api action types to action tree types
    getActionType = (orgToWho, activeRequest, currentAction) => {
        const currentActionWho = orgToWho[currentAction.createdBy.id]
        if (
            activeRequest.type === "TRANSFER" &&
            currentAction.scope === "EXTERNAL" &&
            currentActionWho.includes("beneficiary") &&
            ["APPROVE", "REJECT", "REVOKE"].includes(currentAction.type)
        ) {
            const name = currentActionWho === "beneficiary" ? "OLD_BEN" : "NEW_BEN"
            return `${currentAction.type}_${name}`
        }
        return currentAction.type
    }

    updateIndex = index => {
        this.setState(() => ({ activeIndex: index }))
    }

    buildActiveRequestChips = (activeRequests, classes) => {
        const { activeIndex } = this.state
        return activeRequests.map(({ id, type }, index) => (
            // const xxxx = 111
            // const yyy = xxxx + 22
            <Button
                className={index === activeIndex ? classes.activeLabelButton : classes.labelButton}
                key={id}
                onClick={() => {
                    this.updateIndex(index)
                }}
            >
                <span key={`${id}_text`}>{firstLetter(type)}</span>
            </Button>
        ))
    }

    getSelectedReferenceNumber = activeRequestActions => {
        const a = activeRequestActions.filter(action => action.type === "APPROVE" && action.scope === "INTERNAL")
        if (a.length > 0 && a[a.length - 1].payload && a[a.length - 1].payload.bankReference) {
            return a[a.length - 1].payload.bankReference
        }
        return ""
    }

    render() {
        const {
            activeRequests,
            orgToWho,
            whoAmI,
            theme,
            userContext,
            whoStartedRequests,
            actions,
            hasSufficientGxLimit,
            bgDetails,
            currentOrgId,
            approvalModel,
            purposeType,
            purposeTemplates
        } = this.props

        const { activeIndex, loading, issuers, bankReference } = this.state
        const classes = getClasses({ theme })
        const whoStartedIt = whoStartedRequests[activeRequests[activeIndex].id]
        const activeRequest = activeRequests[activeIndex]
        const activeRequestActions = actions[activeRequests[activeIndex].id]
        const { currentActionState } = this.getAvailableActionsandActiveStepFromTree(
            actionsTree,
            approvalModel.name,
            orgToWho,
            whoAmI,
            whoStartedIt,
            activeRequest,
            activeRequestActions
        )
        const { primaryActionButtons, secondaryActionButtons, primaryActionButtonsText } = this.buildRequestButtons(
            orgToWho,
            whoAmI,
            currentActionState.nextActions.INTERNAL,
            userContext,
            activeRequestActions,
            theme,
            activeIndex,
            whoStartedIt,
            currentOrgId,
            approvalModel
        )

        const lastAction = activeRequestActions[activeRequestActions.length - 1]
        const deferReason = lastAction.type === "DEFER" && lastAction.payload ? lastAction.payload.reason : ""
        authStorage.addLogToErrorQueue(`Bank Guarantee Details: ${JSON.stringify(bgDetails)}`)
        authStorage.addLogToErrorQueue(`Requests: ${JSON.stringify(activeRequests)}`)

        return (
            <React.Fragment>
                <Card css={{ marginBottom: "24px" }}>
                    <Flex className={classes.header} justifyContent="flex-start" alignItems="center">
                        <span className={classes.bgTitleMedium}>
                            View Current Request{activeRequests.length > 1 ? "s" : ""}
                        </span>
                        {this.buildActiveRequestChips(activeRequests, classes)}
                    </Flex>
                    <CardContent>
                        <BGRequestDetailsContent
                            activeRequest={activeRequest}
                            bgDetails={bgDetails}
                            deferReason={deferReason}
                            purposeType={purposeType}
                            purposeTemplates={purposeTemplates}
                        />
                        <StepperErrorBoundary message="An error occurred while retrieving request actions">
                            <BGRequestCardStepper
                                approvalModel={approvalModel}
                                whoAmI={whoAmI}
                                orgToWho={orgToWho}
                                activeRequest={activeRequest}
                                activeRequestActions={activeRequestActions}
                                activeStep={currentActionState.stepper}
                                whoStartedIt={whoStartedIt}
                            />
                            <BGRequestCardButtons
                                primaryActionButtons={primaryActionButtons}
                                secondaryActionButtons={secondaryActionButtons}
                                primaryActionButtonsText={primaryActionButtonsText}
                                issuers={issuers}
                                whoAmI={whoAmI}
                                hasSufficientGxLimit={hasSufficientGxLimit}
                                activeRequestType={activeRequest.type}
                                currentUserRoles={userContext.userRoles[currentOrgId]}
                                currentActionState={currentActionState}
                                approvalModelName={approvalModel.name}
                                bankReference={bankReference}
                                selectedIssuer={bgDetails.issuer ? bgDetails.issuer.name : ""}
                                selectedBankReference={this.getSelectedReferenceNumber(activeRequestActions)}
                                updateBankReference={this.updateBankReference}
                                updateSelectedIssuer={this.updateSelectedIssuer}
                                activeRequestActions={activeRequestActions}
                            />
                        </StepperErrorBoundary>
                    </CardContent>
                </Card>
                <LoadingDialog open={loading} />
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(BGRequestsCard))
