// @flow

import React from "react"
import DialogContentText from "@material-ui/core/DialogContentText"
// import TextField from "@material-ui/core/TextField"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
// import Divider from "@material-ui/core/Divider"

type Props = {
    onSubmit: Function,
    handleClose: Function,
    open: boolean,
    theme: Object
}

type State = {
    reason: string
}
const getClasses = theme => {
    const dialogContentStyle = css({ maxWidth: "500px" })
    const buttonStyle = css({
        color: theme.palette.common.defaultRed
    })

    return {
        buttonStyle,
        dialogContentStyle
    }
}

class RejectDialog extends React.Component<Props, State> {
    state = {
        reason: ""
    }

    onReasonChange = (e: SyntheticInputEvent<>) => {
        this.setState({
            reason: e.target.value
        })
    }

    render() {
        const { onSubmit, theme, ...otherProps } = this.props
        const classes = getClasses(theme)
        return (
            <CustomRequestDialog
                {...otherProps}
                onSubmit={() => onSubmit(this.state)}
                submitText="Pay and Walk"
                renderTitle={() => "Are you sure you want to Pay and Walk this guarantee?"}
                buttonType="red"
                renderContent={() => (
                    <div>
                        <DialogContentText className={classes.dialogContentStyle}>
                            <Typography>
                                This irreversible action will pay the amount of the guarantee to the beneficiary and
                                this will result in the closure of this guarantee. The applicant and beneficiary will be
                                informed once this process is complete.
                            </Typography>
                        </DialogContentText>
                    </div>
                )}
            />
        )
    }
}

export default withTheme()(RejectDialog)

// removed reason for pay and walk
// <TextField
//     name="reason"
//     onChange={this.onReasonChange}
//     placeholder="Optional Explanation"
//     label="Optional Explanation"
//     fullWidth
// />
