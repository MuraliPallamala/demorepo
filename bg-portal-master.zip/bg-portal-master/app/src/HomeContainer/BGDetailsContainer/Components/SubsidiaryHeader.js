// @flow
import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import { Flex } from "~/shared/layout"
import Typography from "@material-ui/core/Typography"

const getClasses = ({ theme }) => {
    const subsidiaryHeader = css({
        backgroundColor: "#78FFC8",
        height: "54px"
    })
    const textStyle = css({
        fontSize: theme.typography.fontSizeLarge
    })
    return {
        subsidiaryHeader,
        textStyle
    }
}
type Props = {
    userInfo: Object,
    theme: Object
}

const SubsidiaryHeader = ({ userInfo, theme }: Props) => {
    const classes = getClasses({ theme })
    if (userInfo && userInfo.actingOnBehalf) {
        return (
            <Flex className={classes.subsidiaryHeader} alignItems="center" justifyContent="center">
                <Typography className={classes.textStyle}>
                    You are acting on behalf of {userInfo.actingOnBehalf.label}
                </Typography>
            </Flex>
        )
    }
    return <div />
}

export default withTheme()(SubsidiaryHeader)
