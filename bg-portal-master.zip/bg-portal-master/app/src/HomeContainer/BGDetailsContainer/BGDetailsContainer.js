// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"

import { Block } from "~/shared/layout"
import withError from "~/shared/Context/ErrorDialog/withError"
import CardErrorBoundary from "~/shared/CardErrorBoundary"
import api from "~/util/api"
import { authStorage } from "~/util/auth"

import moment from "moment"
import * as momentTimezone from "moment-timezone"

import PageTitle from "~/shared/PageTitle"
import { mapPayloadToBGDetails, mapGXPayloadToBGDetails, mapIssuerToPayload } from "~/util/guarantee"
import DemandDialog from "~/shared/Dialogs/DemandDialog/DemandDialog"
import CancelOrRejectDialog from "~/shared/Dialogs/CancelDialog"
import GenericCard from "~/shared/BasicCards/GenericCard"
import ActionConfirmationDialog from "~/shared/Dialogs/RequestDialog"
import CancelPrefillDialog from "~/shared/Dialogs/CancelPrefillDialog"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

import PayAndWalkDialog from "./Components/PayWalkDialog"
import BGDetailsCard from "./BGDetailsCard/BGDetailsCard"
import BGRequestsCard from "./BGRequestsCard/BGRequestsCard"
import BGTimelineCard from "./BGTimelineCard/BGTimelineCard"
import SubsidiaryHeader from "./Components/SubsidiaryHeader"

type Props = {
    theme: Object,
    userContext: Object,
    hasGuarantee: boolean,
    location: Object,
    history: Object,
    match: Object,
    handleErrorOpen: Function,
    approvalModel: Object,
    currentOrgId: string
}

type State = {
    loading: boolean,
    bgDetails: Object,
    requests: Array<Object>,
    actions: Object,
    demandPrefill: Object,
    submitting: boolean,
    openCancel: boolean,
    openReject: boolean,
    openDefer: boolean,
    openDemand: boolean,
    openPayAndWalk: boolean,
    openPrefillCancel: boolean,
    openDialogRequestId: string,
    openApproveDialog: boolean,
    openCancelRequestDialog: boolean,
    openRevokeDialog: boolean,
    openCancelAndPrefillDialog: boolean,
    cancelReason: string,
    issuer: string,
    bankReference: string,
    nextApproveState: string,
    approveDialogText: string,
    approveActionId: string,
    cancelDialogText: string,
    dialogRequestType: string,
    purposeTemplates: Templates
}

class BGDetailsContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            loading: true,
            bgDetails: {},
            requests: [],
            actions: {},
            demandPrefill: {},
            submitting: false,
            openCancel: false,
            openReject: false,
            openDefer: false,
            openDemand: false,
            openPayAndWalk: false,
            openPrefillCancel: false,
            openApproveDialog: false,
            openCancelRequestDialog: false,
            openRevokeDialog: false,
            approveActionId: "",
            openCancelAndPrefillDialog: false,
            openDialogRequestId: "",
            cancelReason: "",
            issuer: "",
            bankReference: "",
            nextApproveState: "",
            approveDialogText: "",
            cancelDialogText: "",
            dialogRequestType: "",
            purposeTemplates: []
        }
    }

    async componentDidMount() {
        await this.loadData()
    }
    async componentDidUpdate(prevProps) {
        if (prevProps.match.params.gxId !== this.props.match.params.gxId) {
            await this.loadData()
        }
    }
    // retrieve all the data required by the page
    loadData = async () => {
        try {
            this.setState(() => ({
                loading: true
            }))
            // retrieve guarantee if hasGuarantee is true
            if (this.props.hasGuarantee) {
                const { actions, bgDetails, requests, purposeTemplates } = await this.getGuaranteeData()
                this.setState(() => ({
                    bgDetails,
                    requests,
                    actions,
                    loading: false,
                    purposeTemplates
                }))
            } else {
                const { bgDetails, actions, requests, purposeTemplates } = await this.getRequestData()
                this.setState(() => ({
                    bgDetails,
                    actions,
                    requests,
                    loading: false,
                    purposeTemplates
                }))
            }
        } catch (err) {
            this.props.handleErrorOpen({
                errorMessage: `Error getting data for details page`,
                title: `Detail Page Error`,
                error: err,
                extraDetails: {
                    CurrentUrl: this.props.history.location.pathname,
                    ErrorResponse: err
                }
            })
            throw err
        }
    }

    // getGuaranteeData gets all the data required for the guarantee
    getGuaranteeData = async () => {
        const gxId = this.props.match.params.gxId
        const gxPayload = await api.guarantee.getGuarantee(gxId)
        // map guarantee response and put in state
        const bgDetails = mapGXPayloadToBGDetails(gxPayload.data)
        const purposeTemplates = await api.purpose.getAllPurposeTemplates()

        // get tcId from session storage. if it's not there, get it through
        let termsAndConditionsTitle
        let termsAndConditions = authStorage.getGuaranteeTC()
        if (termsAndConditions && termsAndConditions[bgDetails.type.tcId]) {
            termsAndConditionsTitle = termsAndConditions[bgDetails.type.tcId].title
        }

        if (!termsAndConditionsTitle) {
            console.log("terms and conditions not available for id:", bgDetails.type.tcId)
            termsAndConditions = await api.termsAndConditions.getTCById(bgDetails.type.tcId)
            termsAndConditionsTitle = termsAndConditions.data.title
        }
        bgDetails.type.termsAndConditionsDisplay = termsAndConditionsTitle

        const requestsPayload = await api.guarantee.getRequestsForGuarantee(gxId)
        const activeRequests = requestsPayload.data.result.filter(request => request.status === "ACTIVE")
        const actions = await this.getActionsForActiveRequests(activeRequests, gxId)

        return {
            actions,
            bgDetails,
            requests: requestsPayload.data.result,
            purposeTemplates: purposeTemplates.data.result
        }
    }

    // getRequestData gets all the data required for the request
    getRequestData = async () => {
        const requestID = this.props.match.params.requestID
        const requestPayload = await api.guarantee.getRequest(requestID)
        const actions = await api.guarantee.getRequestActions(requestID)
        const bgDetails = mapPayloadToBGDetails(requestPayload.data)
        const purposeTemplates = await api.purpose.getAllPurposeTemplates()

        // get tcId from session storage. if it's not there, get it through
        let termsAndConditionsTitle
        let termsAndConditions = authStorage.getGuaranteeTC()
        if (termsAndConditions && termsAndConditions[bgDetails.type.tcId]) {
            termsAndConditionsTitle = termsAndConditions[bgDetails.type.tcId].title
        }
        if (!termsAndConditionsTitle) {
            console.log("terms and conditions not available for id:", bgDetails.type.tcId)
            termsAndConditions = await api.termsAndConditions.getTCById(bgDetails.type.tcId)
            termsAndConditionsTitle = termsAndConditions.data.title
        }
        bgDetails.type.termsAndConditionsDisplay = termsAndConditionsTitle

        return {
            bgDetails,
            actions: { [requestID]: actions.data.result },
            requests: [requestPayload.data],
            purposeTemplates: purposeTemplates.data.result
        }
    }

    // getActionsForActiveRequests takes an array of request objects and returns
    // all the actions for each request of the specific guarantee
    getActionsForActiveRequests = async (activeRequests, gxId) => {
        const actions = {}
        const promises = []
        // for each request, retrieve the actions and key by requestID on actions obj
        for (let i = 0; i < activeRequests.length; ++i) {
            promises.push(api.guarantee.getRequestActionsForGuarantee(gxId, activeRequests[i].id))
        }
        const results = await Promise.all(promises)
        for (let j = 0; j < results.length; ++j) {
            const id = activeRequests[j].id
            actions[id] = results[j].data.result
        }
        return actions
    }

    getWhoStartedRequests = (bgDetails, requests) => {
        const whoStartedRequest = {}
        for (let j = 0; j < requests.length; ++j) {
            const currentReq = requests[j]
            const { id, createdBy } = currentReq
            let whoStartedIt
            if (createdBy.id === bgDetails.applicant.orgId) {
                whoStartedIt = "applicant"
            } else if (createdBy.id === bgDetails.beneficiary.orgId) {
                whoStartedIt = "beneficiary"
            } else if (createdBy.id === bgDetails.issuer.orgId) {
                whoStartedIt = "issuer"
            } else {
                whoStartedIt = "unknown"
            }
            whoStartedRequest[id] = whoStartedIt
        }
        return whoStartedRequest
    }

    breadcrumbMap = qsParam => {
        if (qsParam === "guarantee-requests") {
            return "Guarantee Requests/"
        }
        return "Pending Guarantees/"
    }

    createOrgToWho = (bgDetails, sortedAndFilteredRequests) => {
        const orgToWho: Object = {
            [bgDetails.applicant.orgId]: "applicant",
            [bgDetails.beneficiary.orgId]: "beneficiary",
            [bgDetails.issuer.orgId]: "issuer"
        }
        sortedAndFilteredRequests
            .filter(request => request.type === "TRANSFER")
            .forEach(request => {
                orgToWho[request.payload.beneficiaries[0].id] = "beneficiary2"
            })

        return orgToWho
    }

    calculateWhoAmI = (orgToWho, currentOrgId) => orgToWho[currentOrgId]

    // sortRequests sorts a requests array by requestType priority
    sortAndFilterRequests = (requestsArr, currentOrgId) => {
        const ordering = {}
        const sortOrder = ["ISSUE", "EXPIRED", "PAYWALK", "DEMAND", "CANCEL", "AMEND", "TRANSFER"]
        for (let i = 0; i < sortOrder.length; i++) ordering[sortOrder[i]] = i
        const prioritiseParallelRequests = (a, b) => {
            if (a.createdBy.id === currentOrgId) {
                return 1
            }
            return -1
        }
        return requestsArr
            .sort((a, b) => {
                const value = ordering[a.type] - ordering[b.type]
                if (value !== 0) {
                    return value
                }
                return prioritiseParallelRequests(a, b)
            })
            .filter(req => req.status === "ACTIVE")
    }

    onPayAndWalk = () => this.setState({ openPayAndWalk: true })
    onDemand = () => this.setState({ openDemand: true })
    onCancel = () => this.setState({ openCancel: true })
    onTransfer = gxId => this.props.history.push(`/gx/Transfer/${gxId}`)
    onAmend = gxId => this.props.history.push(`/gx/Amend/${gxId}`)
    onUseTemplate = () => {
        // $FlowFixMe
        this.props.history.push(`/gx/New/${this.state.bgDetails.id}/prefill?isRequest=${!this.props.hasGuarantee}`)
    }
    onPrefillIssue = (requestId, prefillRequest) =>
        this.props.history.push(
            // $FlowFixMe
            `/gx/New/${requestId}/prefill?isRequest=${!this.props.hasGuarantee}&prefillRequest=${prefillRequest}`
        )
    onPrefillAmend = (requestId, prefillRequest) =>
        this.props.history.push(
            // $FlowFixMe
            `/gx/Amend/${this.state.bgDetails.id}/prefill?requestId=${requestId}&prefillRequest=${prefillRequest}`
        )
    onPrefillTransfer = (requestId, prefillRequest) =>
        this.props.history.push(
            // $FlowFixMe
            `/gx/Transfer/${this.state.bgDetails.id}/prefill?requestId=${requestId}&prefillRequest=${prefillRequest}`
        )
    onPrefillDemand = async (requestId, prefillRequest) => {
        const res = await api.guarantee.getRequest(requestId)
        this.setState({
            openDemand: true,
            demandPrefill: {
                sliderValue: res.data.payload.amount / 100,
                optionalComments: res.data.payload.reason
            }
        })
    }
    onPrefillCancel = (requestId, reason) =>
        this.setState({ openDialogRequestId: requestId, openPrefillCancel: true, cancelReason: reason })

    onRejectRequest = requestId => {
        this.setState({ openDialogRequestId: requestId, openReject: true })
    }

    onDefer = requestId => {
        this.setState({ openDialogRequestId: requestId, openDefer: true })
    }

    onApproveRequest = (requestId, nextApproveState, issuer, bankReference, approveDialogText) => {
        this.setState({
            openDialogRequestId: requestId,
            openApproveDialog: true,
            issuer,
            bankReference,
            nextApproveState,
            approveDialogText
        })
    }

    onCancelRequest = (requestId, text) => {
        this.setState({
            openDialogRequestId: requestId,
            openCancelRequestDialog: true,
            cancelDialogText: text
        })
    }

    onCancelAndPrefill = (requestId, dialogRequestType) => {
        this.setState({
            openDialogRequestId: requestId,
            openCancelAndPrefillDialog: true,
            dialogRequestType
        })
    }

    onCancelAndPrefillSubmit = (requestId, dialogRequestType) => {
        this.setState({ submitting: true, openCancelAndPrefillDialog: false })
        api.guarantee
            .submitAction({
                requestId,
                type: "CANCEL"
            })
            .then(() => {
                // reload data from the server
                this.setState({
                    submitting: false,
                    openCancelAndPrefillDialog: false
                })
                this.setState(() => ({ loading: false }))
                // reload data from the server
                switch (dialogRequestType) {
                    case "ISSUE":
                        return this.onPrefillIssue(requestId, false)
                    case "AMEND":
                        return this.onPrefillAmend(requestId, false)
                    case "TRANSFER":
                        return this.onPrefillTransfer(requestId, false)
                    case "DEMAND":
                        return this.onPrefillDemand(requestId, false)
                    default:
                        throw new Error("Request Not supported")
                }
            })
            .catch(err => {
                this.setState({ submitting: false })
                this.props.handleErrorOpen({
                    errorMessage: `Cancel Request error`,
                    title: "Cancel Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {
                            id: requestId
                        },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    onRevoke = (requestId, approveActionId) => {
        this.setState({
            openDialogRequestId: requestId,
            openRevokeDialog: true,
            approveActionId
        })
    }

    onRevokeSubmit = (requestId, approveActionId) => {
        this.setState({ submitting: true, openRevokeDialog: false })
        api.guarantee
            .submitAction({
                actionId: approveActionId,
                requestId,
                type: "REVOKE"
            })
            .then(() => {
                // reload data from the server
                this.setState({
                    submitting: false,
                    openRevokeDialog: false
                })
                this.setState(() => ({ loading: false }))
                // reload data from the server
                this.loadData()
            })
            .catch(err => {
                this.setState({ submitting: false })
                this.props.handleErrorOpen({
                    errorMessage: `Cancel Request error`,
                    title: "Cancel Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {
                            id: requestId
                        },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    onCancelRequestSubmit = requestId => {
        this.setState({ submitting: true, openCancelRequestDialog: false })
        api.guarantee
            .submitAction({
                requestId,
                type: "CANCEL"
            })
            .then(() => {
                // reload data from the server
                this.setState({
                    submitting: false,
                    openCancelRequestDialog: false
                })
                this.setState(() => ({ loading: false }))
                // reload data from the server
                this.loadData()
            })
            .catch(err => {
                this.setState({ submitting: false })
                this.props.handleErrorOpen({
                    errorMessage: `Cancel Request error`,
                    title: "Cancel Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {
                            id: requestId
                        },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    onApproveSubmit = requestId => {
        const issuer = this.state.issuer
        const bankReference = this.state.bankReference
        const nextApproveState = this.state.nextApproveState
        this.setState({ submitting: true, openApproveDialog: false })

        let tmp = {
            requestId,
            type: "APPROVE"
        }
        // if the dropdownList has a value selected, it needs to be in the payload
        if (issuer) {
            tmp = {
                ...tmp,
                payload: {
                    issuer: mapIssuerToPayload(issuer)
                }
            }
        } else if (this.state.bankReference !== "") {
            // it will be impossible to have a bankReference value and issuer value at the same time
            // when bankReference is set, it needs to be in the payload
            tmp = {
                ...tmp,
                payload: {
                    bankReference
                }
            }
        }

        api.guarantee
            .submitAction(tmp)
            .then(async () => {
                // reload data from the server
                this.setState({
                    submitting: false,
                    openApproveDialog: false
                })
                this.setState(() => ({ loading: false }))
                // reload data from the server
                await this.loadData()
            })
            .then(() => {
                const { guaranteeId } = this.state.bgDetails
                // if the request has been fully approved, redirect to gx page instead of refreshing guarantee-requests page
                if (
                    PORTAL_TYPE === "issuer" &&
                    (nextApproveState === "APPROVED_BY_MANAGER" ||
                        nextApproveState === "APPROVED_APPROVER_INTERNAL" ||
                        nextApproveState === "P_APPROVED_BY_MANAGER" ||
                        nextApproveState === "P_APPROVED_APPROVER_INTERNAL")
                ) {
                    // redirects to guarantee details page as the request has been completed and a guarantee has officially been created at this point
                    if (guaranteeId) {
                        this.props.history.push(`/gx/details/${guaranteeId}`)
                    }
                }
            })
            .catch(err => {
                this.setState({ submitting: false })
                this.props.handleErrorOpen({
                    errorMessage: `Approve Request error`,
                    title: "Approve Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {
                            id: requestId
                        },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    onRejectSubmit = requestId => values => {
        this.setState({ submitting: true })
        api.guarantee
            .submitAction({
                requestId,
                type: "REJECT",
                payload: { reason: values.reason === "Other" ? values.otherReason : values.reason }
            })
            .then(() => {
                // reload data from the server
                this.loadData()
                this.setState({
                    submitting: false,
                    openReject: false
                })
            })
            .catch(err => {
                this.setState({ submitting: false })
                this.props.handleErrorOpen({
                    errorMessage: `Rejecting Request error`,
                    title: "Reject Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {
                            id: requestId
                        },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    onDeferSubmit = requestId => values => {
        this.setState({ submitting: true })
        api.guarantee
            .submitAction({
                requestId,
                type: "DEFER",
                payload: { reason: values.reason }
            })
            .then(() => {
                // reload data from the server
                this.loadData()
                this.setState({
                    submitting: false,
                    openDefer: false
                })
            })
            .catch(err => {
                this.setState({ submitting: false })
                this.props.handleErrorOpen({
                    errorMessage: `Defer Request error`,
                    title: "Defer Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {
                            id: requestId
                        },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    genericCancelBG = requestId => values => {
        const gxId = this.state.bgDetails.id
        this.setState({ submitting: true })
        api.guarantee
            .submitRequestForGuarantee(
                gxId,
                "CANCEL",
                {
                    reason: values.reason
                },
                requestId
            )
            .then(() => {
                // reload data from the server
                this.loadData()
                this.setState({
                    submitting: false,
                    openCancel: false,
                    openPrefillCancel: false
                    // // only show the prefill dialog when cancel comes from issuer
                    // openPrefillConfirmationDialog: PORTAL_TYPE === "issuer" && approvalModelName !== "FOUR_EYE"
                })
            })
            // .then(res => this.triggerPageReload())
            .catch(err => {
                this.setState({ submitting: false })
                this.props.handleErrorOpen({
                    errorMessage: `Submitting Request error`,
                    title: "Cancel Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {
                            id: gxId
                        },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    demandBG = values => {
        const gxId = this.state.bgDetails.id
        this.setState({ submitting: true })
        api.guarantee
            .submitRequestForGuarantee(gxId, "DEMAND", {
                // need to multiple value by 100 because the server stores the value in cents
                amount: values.sliderValue * 100,
                reason: values.optionalComments,
                account: values.bankAccount
            })
            .then(() => {
                // reload data from the server
                this.loadData()
                this.setState({ submitting: false, openDemand: false })
            })
            // .then(res => this.triggerPageReload())
            .catch(err => {
                this.setState({ submitting: false })
                this.props.handleErrorOpen({
                    errorMessage: `Submitting Request error`,
                    title: "Demand Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {
                            id: gxId,
                            amount: values.sliderValue,
                            comments: values.optionalComments,
                            account: values.bankAccount
                        },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    paywalkBG = values => {
        const gxId = this.state.bgDetails.id
        this.setState({ submitting: true })
        api.guarantee
            .submitRequestForGuarantee(gxId, "PAYWALK", {
                reason: values.reason
            })
            .then(() => {
                // reload data from the server
                this.loadData()
                this.setState({ submitting: false, openPayAndWalk: false })
            })
            // .then(res => this.triggerPageReload())
            .catch(err => {
                this.setState({ submitting: false })
                this.props.handleErrorOpen({
                    errorMessage: `Submitting Request error`,
                    title: "Pay and Walk Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {
                            id: gxId
                        },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    buildActionButtons = (
        bgDetails,
        highestPriorityRequestType,
        userHasCorrectRole,
        userHasSufficientGxLimit,
        whoAmI,
        approvalModel,
        isExpiredButOpen
    ) => {
        const payAndWalkButton = {
            name: "PAY AND WALK",
            tooltip: "Start a Pay and Walk request for this Bank Guarantee",
            onClick: () => this.onPayAndWalk()
        }
        const amendButton = {
            name: "AMEND",
            tooltip: "Start an Amend request for this Bank Guarantee",
            onClick: () => this.onAmend(bgDetails.id)
        }
        const cancelButton = {
            name: "CANCEL",
            tooltip: "Start a Cancel request for this Bank Guarantee",

            onClick: () => this.onCancel()
        }
        const useAsTemplateButton = {
            name: "Use as Template",

            tooltip: "Use this Bank Guarantee as a template to start a new Issue request with the same details",
            onClick: () => this.onUseTemplate()
        }
        const demandButton = {
            name: "DEMAND",
            tooltip: "Start a Demand request for this Bank Guarantee",
            onClick: () => this.onDemand()
        }
        const transferButton = {
            name: "TRANSFER",
            tooltip: "Start a Transfer request for this Bank Guarantee",
            onClick: () => this.onTransfer(bgDetails.id)
        }

        let actionButtons = [useAsTemplateButton]
        let actionBarText = ""
        const issuerActionButtons = [payAndWalkButton, amendButton, cancelButton, useAsTemplateButton]
        const applicantActionButtons = [amendButton, cancelButton, transferButton, useAsTemplateButton]
        const beneficiaryActionButtons = [demandButton, amendButton, cancelButton, transferButton, useAsTemplateButton]
        let disabled = []
        switch (bgDetails.status) {
            case "CANCELLED":
            case "DEMANDED":
            case "PAID":
            case "EXPIRED":
            case "TRANSFERRED":
            case "PENDING": {
                actionButtons = [useAsTemplateButton]
                disabled = [false]
                break
            }
            case "ACTIVE": {
                if (highestPriorityRequestType) {
                    switch (highestPriorityRequestType) {
                        case "DEMAND": {
                            switch (whoAmI) {
                                case "issuer": {
                                    actionButtons = issuerActionButtons
                                    disabled = [true, true, true, false]
                                    break
                                }
                                case "applicant": {
                                    actionButtons = applicantActionButtons
                                    disabled = [true, true, true, false]
                                    break
                                }
                                case "beneficiary": {
                                    actionButtons = beneficiaryActionButtons
                                    disabled = [true, true, true, true, false]
                                    break
                                }
                                default: {
                                    //
                                }
                            }
                            break
                        }
                        case "CANCEL": {
                            switch (whoAmI) {
                                case "issuer": {
                                    actionButtons = issuerActionButtons
                                    disabled = [false, true, true, false]
                                    break
                                }
                                case "applicant": {
                                    actionButtons = applicantActionButtons
                                    disabled = [true, true, true, false]
                                    break
                                }
                                case "beneficiary": {
                                    actionButtons = beneficiaryActionButtons
                                    disabled = [false, true, true, true, false]
                                    break
                                }
                                default: {
                                    //
                                }
                            }
                            break
                        }
                        case "AMEND": {
                            switch (whoAmI) {
                                case "issuer": {
                                    actionButtons = issuerActionButtons
                                    disabled = [false, true, false, false]
                                    break
                                }
                                case "applicant": {
                                    actionButtons = applicantActionButtons
                                    disabled = [true, false, true, false]
                                    break
                                }
                                case "beneficiary": {
                                    actionButtons = beneficiaryActionButtons
                                    disabled = [false, true, false, true, false]
                                    break
                                }
                                default: {
                                    //
                                }
                            }

                            break
                        }
                        case "TRANSFER": {
                            switch (whoAmI) {
                                case "issuer": {
                                    actionButtons = issuerActionButtons
                                    disabled = [false, true, false, false]
                                    break
                                }
                                case "applicant": {
                                    actionButtons = applicantActionButtons
                                    disabled = [true, false, true, false]
                                    break
                                }
                                case "beneficiary": {
                                    actionButtons = beneficiaryActionButtons
                                    disabled = [false, true, false, true, false]
                                    break
                                }
                                default: {
                                    //
                                }
                            }
                            break
                        }
                        case "PAYWALK": {
                            switch (whoAmI) {
                                case "issuer": {
                                    actionButtons = issuerActionButtons
                                    disabled = [true, true, true, false]
                                    break
                                }
                                default: {
                                    //
                                }
                            }
                            break
                        }
                        default: {
                            //
                        }
                    }
                } else {
                    switch (whoAmI) {
                        case "issuer": {
                            actionButtons = issuerActionButtons
                            disabled = [false, false, false, false]
                            break
                        }
                        case "applicant": {
                            actionButtons = applicantActionButtons
                            disabled = [false, false, false, false]
                            break
                        }
                        case "beneficiary": {
                            actionButtons = beneficiaryActionButtons
                            disabled = [false, false, false, false, false]
                            break
                        }
                        default: {
                            //
                        }
                    }
                }
                break
            }
            default: {
                console.log("Unknown bg details status:", bgDetails.status)
            }
        }
        if (isExpiredButOpen) {
            if (whoAmI === "applicant") {
                actionBarText =
                    "This Bank Guarantee is expired. Please contact the issuing organisation for further detail."
                disabled = this.disableButtonsForText(disabled, false)
            } else {
                actionBarText =
                    "This Bank Guarantee is expired and only kept open until the Demand process is resolved. In this state, no other actions can be initiated."
                disabled = this.disableButtonsForText(disabled, false)
            }
        } else if (!userHasCorrectRole && PORTAL_TYPE !== "issuer") {
            actionBarText = "You don't have the right approval role to start requests."
            disabled = this.disableButtonsForText(disabled, true)
        } else if (!userHasSufficientGxLimit && PORTAL_TYPE !== "issuer") {
            actionBarText = "The value of this Bank Guarantee exceeds your threshold."
            disabled = this.disableButtonsForText(disabled, false)
        } else if (!approvalModel && PORTAL_TYPE !== "issuer") {
            actionBarText = "The administrator of your organisation has not set an Approval Model, yet."
            disabled = this.disableButtonsForText(disabled, true)
            // in case of a past request, the issuer will see one use as template button, which shouldn't be disabled. in any other case there will be more than one button.
        } else if (PORTAL_TYPE === "issuer" && disabled.length > 1) {
            if (!userHasCorrectRole) {
                actionBarText = "You don't have the right approval role to start Pay and Walk requests."
                disabled[0] = true
            } else if (!userHasSufficientGxLimit) {
                actionBarText =
                    "The value of this Bank Guarantee exceeds your threshold. You cannot start a Pay and Walk request."
                disabled[0] = true
            } else if (!approvalModel) {
                actionBarText =
                    "The administrator of your organisation has not set an Approval Model, yet. Pay and Walk requests can not be started."
                disabled[0] = true
            }
        }
        return { actionButtons, disabled, actionBarText }
    }

    disableButtonsForText = (disabledArr, all) => {
        const temp = []
        for (let i = 0; i < disabledArr.length; ++i) {
            if (i === disabledArr.length - 1 && !all) {
                temp.push(false)
            }
            temp.push(true)
        }
        return temp
    }

    userHasCorrectRole = (approvalModel, userRoles, currentOrgId) => {
        if (approvalModel) {
            if (approvalModel.name === "SOLE_APPROVER" && userRoles[currentOrgId].includes("MANAGER")) {
                return true
            } else if (approvalModel.name === "FOUR_EYE" && userRoles[currentOrgId].includes("PROPOSER")) {
                return true
            }
        }
        return false
    }

    userHasSufficientGxLimit = (gxLimit, approvalModel, currentOrgId, bgDetails) => {
        // if the limit is unlimited or limit is bigger than outstanding amount, return true
        if (gxLimit[currentOrgId] === -1) {
            return true
        } else if (
            approvalModel &&
            Object.keys(bgDetails).length > 0 &&
            bgDetails.type.amount.outstanding <= gxLimit[currentOrgId] / 100
        ) {
            return true
        }
        return false
    }

    getDateString = date => {
        const dateSplit = date.split("/")
        return dateSplit[2] + dateSplit[1] + dateSplit[0]
    }

    isExpiredButOpen = bgDetails => {
        if (bgDetails && bgDetails.type) {
            const expiration = bgDetails.type.expiry
            const status = bgDetails.status
            if (expiration === "Open Ended") {
                return false
            }
            console.log("expiration", expiration, status)

            const rightNow = momentTimezone.tz(new Date(), "Australia/Sydney").format()
            const expFourPMSydney = momentTimezone
                .tz(this.getDateString(expiration), "Australia/Sydney")
                .add(16, "hours")
                .format()

            const isExpired = moment(expFourPMSydney).isBefore(moment(rightNow))

            if (isExpired && status === "ACTIVE") {
                return true
            }
            return false
        }
        return false
    }

    hasReason = (sortedAndFilteredRequests, openDialogRequestId, whoStartedIt, whoAmI) => {
        if (
            PORTAL_TYPE === "issuer" &&
            sortedAndFilteredRequests.filter(request => request.id === openDialogRequestId)[0] &&
            sortedAndFilteredRequests.filter(request => request.id === openDialogRequestId)[0].type === "DEMAND"
        ) {
            return false
        } else if (whoStartedIt === whoAmI) {
            return false
        }
        return true
    }

    giveReasonOptions = (sortedAndFilteredRequests, openDialogRequestId, whoAmI) => {
        if (
            PORTAL_TYPE === "issuer" &&
            sortedAndFilteredRequests.filter(request => request.id === openDialogRequestId)[0] &&
            (sortedAndFilteredRequests.filter(request => request.id === openDialogRequestId)[0].type === "AMEND" ||
                sortedAndFilteredRequests.filter(request => request.id === openDialogRequestId)[0].type === "ISSUE")
        ) {
            return true
        }
        return false
    }

    render() {
        const { theme, location, hasGuarantee, userContext, history, match, approvalModel, currentOrgId } = this.props
        const {
            loading,
            bgDetails,
            actions,
            requests,
            openDialogRequestId,
            submitting,
            approveDialogText,
            approveActionId,
            dialogRequestType,
            purposeTemplates
        } = this.state

        const sortedAndFilteredRequests = this.sortAndFilterRequests(requests, currentOrgId)
        let orgToWho = {}
        let whoAmI = ""
        if (!loading) {
            orgToWho = this.createOrgToWho(bgDetails, sortedAndFilteredRequests)
            whoAmI = this.calculateWhoAmI(orgToWho, currentOrgId)
        }
        const hasSufficientGxLimit = this.userHasSufficientGxLimit(
            userContext.gxLimit,
            approvalModel,
            currentOrgId,
            bgDetails
        )
        const { actionButtons, disabled, actionBarText } = this.buildActionButtons(
            bgDetails,
            sortedAndFilteredRequests.length > 0 ? sortedAndFilteredRequests[0].type : null,
            this.userHasCorrectRole(approvalModel, userContext.userRoles, currentOrgId),
            hasSufficientGxLimit,
            whoAmI,
            approvalModel,
            this.isExpiredButOpen(bgDetails)
        )

        // calculate stuff for breadcrumbs
        const params = new URLSearchParams(location.search)
        const breadcrumbLink = params.get("breadcrumb")
        const breadcrumbTitle = this.breadcrumbMap(breadcrumbLink)

        const hasReason = this.hasReason(
            sortedAndFilteredRequests,
            openDialogRequestId,
            this.getWhoStartedRequests(bgDetails, requests)[openDialogRequestId],
            whoAmI
        )
        console.log("bgDetails", bgDetails.purposeType, hasGuarantee)
        return (
            <React.Fragment>
                <SubsidiaryHeader userInfo={userContext} />
                {hasGuarantee ? (
                    <PageTitle
                        path={breadcrumbLink ? "Pending Guarantees/" : "Guarantees/"}
                        // history={history}
                        link={breadcrumbLink ? `/${breadcrumbLink}` : "/gx"}
                        title="Guarantee Details"
                        theme={theme}
                    />
                ) : (
                    <PageTitle
                        path={breadcrumbTitle}
                        link={breadcrumbLink ? `/${breadcrumbLink}` : "/pending-gx"}
                        // history={history}
                        title="Request Details"
                        theme={theme}
                    />
                )}
                <Block padding="3un">
                    {loading ? (
                        <LoadingCard />
                    ) : (
                        <React.Fragment>
                            <CardErrorBoundary
                                customStyle={{ marginBottom: "24px" }}
                                message="An error occurred while retrieving the guarantee details."
                            >
                                <BGDetailsCard
                                    bgDetails={bgDetails}
                                    hasGuarantee={hasGuarantee}
                                    whoAmI={whoAmI}
                                    userContext={userContext}
                                    buttons={actionButtons}
                                    actionBarText={actionBarText}
                                    disabled={disabled}
                                    purposeTemplates={purposeTemplates}
                                />
                            </CardErrorBoundary>
                            {sortedAndFilteredRequests.length > 0 && approvalModel && approvalModel.name && (
                                <CardErrorBoundary
                                    customStyle={{ marginBottom: "24px" }}
                                    message="An error occurred while retrieving the request actions."
                                >
                                    <BGRequestsCard
                                        loadData={this.loadData}
                                        hasSufficientGxLimit={hasSufficientGxLimit}
                                        activeRequests={sortedAndFilteredRequests}
                                        orgToWho={orgToWho}
                                        whoAmI={whoAmI}
                                        actions={actions}
                                        bgDetails={bgDetails}
                                        userContext={userContext}
                                        approvalModel={approvalModel}
                                        currentOrgId={currentOrgId}
                                        whoStartedRequests={this.getWhoStartedRequests(bgDetails, requests)}
                                        onPrefillIssue={this.onPrefillIssue}
                                        onPrefillAmend={this.onPrefillAmend}
                                        onPrefillCancel={this.onPrefillCancel}
                                        onPrefillTransfer={this.onPrefillTransfer}
                                        onPrefillDemand={this.onPrefillDemand}
                                        onRejectRequest={this.onRejectRequest}
                                        onApproveRequest={this.onApproveRequest}
                                        onCancelRequest={this.onCancelRequest}
                                        onCancelAndPrefill={this.onCancelAndPrefill}
                                        onRevoke={this.onRevoke}
                                        onDefer={this.onDefer}
                                        history={history}
                                        match={match}
                                        purposeTemplates={purposeTemplates}
                                        purposeType={hasGuarantee ? bgDetails.purposeType : ""}
                                    />
                                </CardErrorBoundary>
                            )}
                            {sortedAndFilteredRequests.length > 0 && (!approvalModel || !approvalModel.name) && (
                                <GenericCard text="There are active requests on this Bank Guarantee. Your organisation's Adminstrator needs to set Approval Model in order for these requests to be processed." />
                            )}
                            <CardErrorBoundary message="An error occurred while retrieving bank guarantee history details.">
                                <BGTimelineCard
                                    requests={requests}
                                    currentGxId={bgDetails.id}
                                    isOpen
                                    isGuarantee={hasGuarantee}
                                    currentOrgId={currentOrgId}
                                    whoAmI={whoAmI}
                                    purposeTemplates={purposeTemplates}
                                    purposeType={hasGuarantee ? bgDetails.purposeType : ""}
                                />
                            </CardErrorBoundary>
                            <CancelOrRejectDialog
                                theme={theme}
                                open={this.state.openCancel}
                                onSubmit={this.genericCancelBG()}
                                closeDialog={() => this.setState({ openCancel: false })}
                                currentUserInformation={userContext}
                                text="You are about to request the cancellation of this Bank Guarantee."
                                submitButtonText="Proceed to cancel"
                            />
                            <DemandDialog
                                theme={theme}
                                open={this.state.openDemand}
                                onSubmit={this.demandBG}
                                closeDialog={() => this.setState({ openDemand: false })}
                                maxValue={bgDetails.type.amount.outstanding}
                                minValue={0.01}
                                initialValues={this.state.demandPrefill}
                            />
                            <PayAndWalkDialog
                                onSubmit={this.paywalkBG}
                                handleClose={() => this.setState({ openPayAndWalk: false })}
                                open={this.state.openPayAndWalk}
                                theme={theme}
                            />
                            <CancelPrefillDialog
                                theme={theme}
                                open={this.state.openPrefillCancel}
                                onSubmit={this.genericCancelBG(openDialogRequestId)}
                                closeDialog={() => this.setState({ openPrefillCancel: false })}
                                text="You are about to request the cancellation of this Bank Guarantee."
                                submitButtonText="Proceed to cancel"
                                initialValues={{ reason: this.state.cancelReason }}
                            />
                            <CancelOrRejectDialog
                                theme={theme}
                                open={this.state.openReject}
                                onSubmit={this.onRejectSubmit(openDialogRequestId)}
                                closeDialog={() => this.setState({ openReject: false })}
                                currentUserInformation={userContext}
                                text={
                                    hasReason
                                        ? "You are about to reject this request. Please enter a rejection reason (optional)."
                                        : "You are about to reject this request"
                                }
                                submitButtonText="Proceed to reject"
                                noReason={!hasReason}
                                reasonOptions={this.giveReasonOptions(
                                    sortedAndFilteredRequests,
                                    openDialogRequestId,
                                    whoAmI
                                )}
                            />
                            <ActionConfirmationDialog
                                open={this.state.openApproveDialog}
                                title="Confirm Action"
                                message={approveDialogText}
                                submitText="Proceed"
                                cancelText="Exit"
                                hasCancelButton
                                handleClose={() => this.setState({ openApproveDialog: false })}
                                onSubmit={() => this.onApproveSubmit(openDialogRequestId)}
                            />
                            <CancelOrRejectDialog
                                theme={theme}
                                open={this.state.openDefer}
                                onSubmit={this.onDeferSubmit(openDialogRequestId)}
                                closeDialog={() => this.setState({ openDefer: false })}
                                currentUserInformation={userContext}
                                text="You are about to defer this request."
                                submitButtonText="Proceed to defer"
                            />
                            <ActionConfirmationDialog
                                title="Cancel Request"
                                open={this.state.openCancelRequestDialog}
                                onSubmit={() => this.onCancelRequestSubmit(openDialogRequestId)}
                                handleClose={() => this.setState({ openCancelRequestDialog: false })}
                                currentUserInformation={userContext}
                                message={`You are about to ${this.state.cancelDialogText}`}
                                submitText="Proceed"
                                cancelText="Exit"
                            />
                            <ActionConfirmationDialog
                                title="Revoke Approval"
                                open={this.state.openRevokeDialog}
                                onSubmit={() => this.onRevokeSubmit(openDialogRequestId, approveActionId)}
                                handleClose={() => this.setState({ openRevokeDialog: false })}
                                currentUserInformation={userContext}
                                message="You are about to revoke approval for this request."
                                submitText="Proceed"
                                cancelText="Exit"
                            />
                            <ActionConfirmationDialog
                                title="Cancel request and resubmit"
                                open={this.state.openCancelAndPrefillDialog}
                                onSubmit={() => this.onCancelAndPrefillSubmit(openDialogRequestId, dialogRequestType)}
                                handleClose={() => this.setState({ openCancelAndPrefillDialog: false })}
                                currentUserInformation={userContext}
                                message="You are about to cancel this request. You will then be forwarded to a prefilled form to resubmit the request."
                                submitText="Proceed"
                                cancelText="Exit"
                            />
                        </React.Fragment>
                    )}
                </Block>
                <LoadingDialog open={submitting} />
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(BGDetailsContainer))
