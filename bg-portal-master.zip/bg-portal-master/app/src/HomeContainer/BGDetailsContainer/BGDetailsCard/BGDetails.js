// @flow

import * as React from "react"
import { css } from "emotion"
import numeral from "numeral"
import { withTheme } from "@material-ui/core/styles"
import { Grid, Flex } from "~/shared/layout"
import Typography from "@material-ui/core/Typography"
import { numberWithSpaces } from "~/util/helpers/text"
import purposeFormatMapping from "~/util/helpers/purposeFormatMapping"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

const getClasses = ({ theme }) => {
    const grid = css({
        gridTemplateRows: "repeat(6, auto)",
        gridColumnGap: "2fr",
        // gridGap: "23un",
        minWidth: "325px",
        marginBottom: "1rem",
        flex: "1"
    })
    const gridContent = css(theme.typography.body1, {
        padding: "5px 5px 0px 0px",
        marginRight: "5px"
    })
    const largeLabel = css(theme.typography.body2, {
        fontSize: theme.commonFontSizes.large,
        alignSelf: "end",
        marginTop: "1rem",
        paddingBottom: "10px"
    })
    const smallLabel = css(theme.typography.body2, {
        alignSelf: "end",
        padding: "5px 5px 0px 0px",
        marginLeft: "0px",
        marginRight: "5px"
    })
    return {
        grid,
        largeLabel,
        smallLabel,
        gridContent
    }
}

type GridProps = {
    theme: Object,
    row: string,
    col: string
}
const SmallLabel = withTheme()(({ theme, row, col, ...props }: GridProps) => {
    const classes = getClasses({ theme })
    const rowCol = { gridRow: row, gridColumn: col }
    return <Typography className={classes.smallLabel} css={rowCol} {...props} />
})
const GridContent = withTheme()(({ theme, row, col, ...props }: GridProps) => {
    const classes = getClasses({ theme })
    const rowCol = { gridRow: row, gridColumn: col }
    return <Typography className={classes.gridContent} css={rowCol} {...props} />
})

type PartiesInvolvedProps = { theme: Object, bgDetails: Object, whoAmI: string, hasGuarantee: boolean }
const PartiesInvolved = withTheme()(({ theme, bgDetails, whoAmI, hasGuarantee }: PartiesInvolvedProps) => {
    const classes = getClasses({ theme })
    const { applicant, beneficiary, issuer } = bgDetails
    return (
        <Flex flexDirection="column" flex={1}>
            <Typography className={classes.largeLabel}>Parties Involved</Typography>
            <Grid className={classes.grid}>
                <SmallLabel row="1" col="1">
                    Applicant Name
                </SmallLabel>
                <GridContent row="2" col="1">
                    {applicant.name}
                </GridContent>
                <SmallLabel row="1" col="2">
                    {applicant.businessId.length === 9 ? "ACN" : "ABN"}
                </SmallLabel>
                <GridContent row="2" col="2">
                    {numberWithSpaces(applicant.businessId)}
                </GridContent>
                <SmallLabel row="3" col="1">
                    Beneficiary Name
                </SmallLabel>
                <GridContent row="4" col="1">
                    {beneficiary.name}
                </GridContent>
                <SmallLabel row="3" col="2">
                    {beneficiary.businessId.length === 9 ? "ACN" : "ABN"}
                </SmallLabel>
                <GridContent row="4" col="2">
                    {numberWithSpaces(beneficiary.businessId)}
                </GridContent>
                <SmallLabel row="5" col="1">
                    Issuer Name
                </SmallLabel>
                <GridContent row="6" col="1">
                    {!(
                        (bgDetails.status === "Not issued" || bgDetails.status === "Withdrawn") &&
                        whoAmI === "beneficiary"
                    )
                        ? issuer.name
                        : ""}
                </GridContent>
                {hasGuarantee && (
                    <SmallLabel row="5" col="2">
                        Issuer Reference Number
                    </SmallLabel>
                )}
                {hasGuarantee && (
                    <GridContent row="6" col="2">
                        {bgDetails.bankReference ? bgDetails.bankReference : "N/A"}
                    </GridContent>
                )}
            </Grid>
        </Flex>
    )
})

type PurposeDisplayProps = { theme: Object, bgDetails: Object, purposeTemplates: Templates }
const PurposeDisplay = withTheme()(({ theme, bgDetails, purposeTemplates }: PurposeDisplayProps) => {
    const classes = getClasses({ theme })
    const { purpose, purposeType } = bgDetails
    const renderRows = []
    purposeFormatMapping({ purposeTemplates, purposeType, purpose }).forEach(item => {
        renderRows.push(item)
    })
    return (
        <Flex flexDirection="column" flex={1}>
            <Typography className={classes.largeLabel}>Purpose</Typography>
            <Grid className={classes.grid} style={{ gridAutoFlow: "column" }}>
                {renderRows.map((item, i) => (
                    <React.Fragment>
                        <Typography className={classes.smallLabel}>{item.key}</Typography>
                        <Typography className={classes.gridContent}>
                            {/* This code looks like this to allow the rendering of booleans */}
                            {item.value == null ? "N/A" : `${item.value}`}
                        </Typography>
                    </React.Fragment>
                ))}
            </Grid>
        </Flex>
    )
})

type GuaranteeDetailsProps = { theme: Object, bgDetails: Object, purposeTemplates: Templates, isRequest: boolean }
const GuaranteeDetails = withTheme()(({ theme, bgDetails, purposeTemplates, isRequest }: GuaranteeDetailsProps) => {
    const classes = getClasses({ theme })
    const guaranteeType = purposeTemplates.find(item => item.id === bgDetails.type.guaranteeType)

    return (
        <Flex flexDirection="column" flex={1}>
            <Typography className={classes.largeLabel}> Guarantee Details</Typography>

            <Grid className={classes.grid}>
                <SmallLabel row="1" col="1">
                    Guarantee Type
                </SmallLabel>
                <GridContent row="2" col="1">
                    {guaranteeType ? guaranteeType.label : "N/A"}
                </GridContent>
                <SmallLabel row="1" col="2">
                    Expiry
                </SmallLabel>
                <GridContent row="2" col="2">
                    {bgDetails.type.expiry}
                </GridContent>
                <SmallLabel row="3" col="1">
                    Current Amount
                </SmallLabel>
                <GridContent row="4" col="1">
                    {`${bgDetails.type.currency} ${numeral(bgDetails.type.amount.outstanding).format("0,0.00")}`}
                </GridContent>
                {bgDetails.issuedAt !== "" &&
                    bgDetails.status !== "PENDING" &&
                    bgDetails.status !== "WITHDRAWN" &&
                    bgDetails.status !== "REJECTED" &&
                    !(bgDetails.status === "CANCELLED" && isRequest) && (
                        // HERE check for isRequest, also, propagate in bgdetails card content
                        <SmallLabel row="3" col="2">
                            Issued On
                        </SmallLabel>
                    )}
                {bgDetails.issuedAt !== "" &&
                    bgDetails.status !== "PENDING" &&
                    bgDetails.status !== "WITHDRAWN" &&
                    bgDetails.status !== "REJECTED" &&
                    !(bgDetails.status === "CANCELLED" && isRequest) && (
                        <GridContent row="4" col="2">
                            {bgDetails.issuedAt}
                        </GridContent>
                    )}
                <SmallLabel row="5" col="1/3">
                    Terms and Conditions
                </SmallLabel>
                <GridContent row="6" col="1/3">
                    {bgDetails.type.termsAndConditionsDisplay
                        ? bgDetails.type.termsAndConditionsDisplay
                        : "None chosen"}
                </GridContent>
            </Grid>
        </Flex>
    )
})

export { PartiesInvolved, PurposeDisplay, GuaranteeDetails }
