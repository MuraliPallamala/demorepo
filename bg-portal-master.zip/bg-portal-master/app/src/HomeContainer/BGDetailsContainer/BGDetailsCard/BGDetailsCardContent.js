// @flow

import * as React from "react"
import { Link } from "react-router-dom"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import { Row, WrappedRow } from "~/shared/layout"
import RequestDialog from "~/shared/Dialogs/RequestDialog"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import DownloadButton from "~/shared/DownloadButton"
import api from "~/util/api"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import { PartiesInvolved, PurposeDisplay, GuaranteeDetails } from "./BGDetails"

type Props = {
    theme: Object,
    bgDetails: Object,
    whoAmI: string,
    hasGuarantee: boolean,
    purposeTemplates: Templates
}

type State = {
    openViewIDDialog: boolean
}

const getClasses = ({ theme }) => {
    const bgTitleMedium = css(theme.typography.formTitle, {
        color: "#fff",
        fontSize: theme.commonFontSizes.large
    })
    const bgTitleRegular = css(theme.typography.formTitle, {
        color: "#fff",
        fontWeight: theme.commonFontWeights.regular,
        fontSize: theme.commonFontSizes.large
    })
    const whiteButton = css({
        color: "#fff",
        margin: "0px",
        minHeight: "unset",
        minWidth: "unset",
        textTransform: "uppercase",
        fontWeight: theme.commonFontWeights.regular,
        cursor: "pointer",
        paddingLeft: "0.9rem",
        paddingRight: "0.9rem",
        marginTop: "4px",
        fontSize: theme.commonFontSizes.medium,
        span: { lineHeight: "25%" }
    })
    const viewIdButton = css(whiteButton, {
        borderRight: "1px #fff solid",
        borderRadius: "0px",
        fontSize: theme.commonFontSizes.medium,
        fontWeight: theme.commonFontWeights.regular
    })
    const viewIdButtonNoBorder = css(whiteButton, {
        fontSize: theme.commonFontSizes.medium,
        fontWeight: theme.commonFontWeights.regular
    })
    const transferred = css(theme.typography.body1, {
        padding: "5px 5px 0px 0px",
        marginRight: "5px"
    })
    const linkMessage = css(theme.typography.linkMessage)
    const link = css(theme.typography.link)
    const header = css({ display: "table-cell", alignSelf: "center" })
    return {
        bgTitleMedium,
        bgTitleRegular,
        whiteButton,
        viewIdButton,
        transferred,
        linkMessage,
        link,
        header,
        viewIdButtonNoBorder
    }
}

class BGDetailsForm extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            openViewIDDialog: false
        }
    }

    getBackgroundColour = status => {
        const commonPalette = this.props.theme.palette.common
        const bg = {
            APPROVED: commonPalette.bgStatusGreen,
            ACTIVE: commonPalette.bgStatusGreen,
            TRANSFERRED: commonPalette.bgStatusRed,
            PENDING: commonPalette.bgStatusBlue,
            WITHDRAWN: commonPalette.bgStatusRed,
            CANCELLED: commonPalette.bgStatusRed,
            UNKNOWN: commonPalette.bgStatusRed
        }
        return css({
            backgroundColor: bg[status] ? bg[status] : bg.UNKNOWN,
            padding: "0.5rem",
            paddingLeft: "24px",
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between"
        })
    }

    showViewIDDialog = () => {
        this.setState({
            openViewIDDialog: true
        })
    }

    dismissViewIDDialog = () => {
        this.setState({
            openViewIDDialog: false
        })
    }

    render() {
        const { theme, bgDetails, hasGuarantee, purposeTemplates } = this.props
        const classes = getClasses({ theme })
        const backgroundClass = this.getBackgroundColour(bgDetails.status)

        let headerLine
        // NOTE: This includes both request and guarantee statuses
        switch (bgDetails.status) {
            case "PENDING": {
                headerLine = (
                    <div className={classes.header}>
                        <span className={classes.bgTitleMedium}>Bank Guarantee Details</span>
                        <span className={classes.bgTitleRegular}>&nbsp;-&nbsp;Status&nbsp;</span>
                        <span className={classes.bgTitleMedium}>Pending&nbsp;</span>
                    </div>
                )
                break
            }
            case "WITHDRAWN": {
                headerLine = (
                    <div className={classes.header}>
                        <span className={classes.bgTitleMedium}>Bank Guarantee</span>
                        <span className={classes.bgTitleRegular}>&nbsp;-&nbsp;Status&nbsp;</span>
                        <span className={classes.bgTitleMedium}>Withdrawn&nbsp;</span>
                    </div>
                )
                break
            }

            case "CANCELLED": {
                headerLine = (
                    <div className={classes.header}>
                        <span className={classes.bgTitleMedium}>Bank Guarantee {hasGuarantee ? "" : "Request"}</span>
                        <span className={classes.bgTitleRegular}>&nbsp;-&nbsp;Status&nbsp;</span>
                        <span className={classes.bgTitleMedium}>Cancelled&nbsp;</span>
                    </div>
                )
                break
            }
            case "PAYWALKED": {
                headerLine = (
                    <div className={classes.header}>
                        <span className={classes.bgTitleMedium}>Bank Guarantee</span>
                        <span className={classes.bgTitleRegular}>&nbsp;-&nbsp;Status&nbsp;</span>
                        <span className={classes.bgTitleMedium}>Pay and Walk&nbsp;</span>
                    </div>
                )
                break
            }
            case "TRANSFERRED": {
                headerLine = (
                    <div className={classes.header}>
                        <span className={classes.bgTitleMedium}>Bank Guarantee</span>
                        <span className={classes.bgTitleRegular}>&nbsp;-&nbsp;</span>
                        <span className={classes.bgTitleMedium}>
                            {bgDetails.status}
                            &nbsp;
                        </span>
                    </div>
                )
                break
            }
            default: {
                headerLine = (
                    <div className={classes.header}>
                        <span className={classes.bgTitleMedium}>Bank Guarantee</span>
                        <span className={classes.bgTitleRegular}>&nbsp;-&nbsp;Status&nbsp;</span>
                        <span className={classes.bgTitleMedium}>
                            {bgDetails.status}
                            &nbsp;
                        </span>
                    </div>
                )
            }
        }
        return (
            <React.Fragment>
                <RequestDialog
                    title="ID"
                    message={this.props.bgDetails.id}
                    submitText="Ok"
                    onSubmit={this.dismissViewIDDialog}
                    handleClose={this.dismissViewIDDialog}
                    open={this.state.openViewIDDialog}
                    hasCancelButton={false}
                />
                <Row id="header" className={backgroundClass}>
                    {headerLine}
                    {hasGuarantee && (
                        <div>
                            <Button
                                onClick={this.showViewIDDialog}
                                css={{ verticalAlign: "unset" }}
                                className={
                                    bgDetails.status !== "Not issued" &&
                                    bgDetails.status !== "Transfer requested" &&
                                    bgDetails.status !== "Prefill request"
                                        ? classes.viewIdButton
                                        : classes.viewIdButtonNoBorder
                                }
                            >
                                VIEW ID
                            </Button>
                            {bgDetails.status !== "Not issued" &&
                                bgDetails.status !== "Transfer requested" &&
                                bgDetails.status !== "Prefill request" && (
                                    <DownloadButton
                                        className={classes.whiteButton}
                                        css={{
                                            verticalAlign: "unset!important",
                                            paddingBottom: "13px!important"
                                        }}
                                        downloadTCPdf={api.termsAndConditions.getTCsById(
                                            this.props.bgDetails.type.tcId
                                            // "b0d7cb76-4c3c-40c0-bd0b-ff300eb03d03" //testing markdown
                                        )}
                                        downloadPdf={api.audit.downloadPdfGuarantee(this.props.bgDetails.id)}
                                        buttonText="Download"
                                    />
                                )}
                        </div>
                    )}
                    {!hasGuarantee && (
                        <div>
                            <DownloadButton
                                className={classes.whiteButton}
                                css={{
                                    verticalAlign: "unset!important",
                                    paddingBottom: "13px!important"
                                }}
                                downloadTCPdf={api.termsAndConditions.getTCsById(this.props.bgDetails.type.tcId)}
                                buttonText="Download T&Cs"
                            />
                        </div>
                    )}
                </Row>
                <WrappedRow css={{ padding: "16px 24px", justifyContent: "space-between" }}>
                    <PartiesInvolved bgDetails={bgDetails} whoAmI={this.props.whoAmI} hasGuarantee={hasGuarantee} />
                    <GuaranteeDetails
                        bgDetails={bgDetails}
                        purposeTemplates={purposeTemplates}
                        isRequest={!hasGuarantee}
                    />
                    <PurposeDisplay bgDetails={bgDetails} purposeTemplates={purposeTemplates} />
                </WrappedRow>
                <WrappedRow css={{ padding: "0px 24px 16px 24px" }}>
                    {bgDetails.prevGxId &&
                        this.props.bgDetails.status !== "WITHDRAWN" &&
                        this.props.bgDetails.status !== "CANCELLED" &&
                        this.props.whoAmI !== "beneficiary" &&
                        this.props.whoAmI !== "beneficiary2" && (
                            <React.Fragment>
                                <Typography className={classes.linkMessage}>
                                    This Bank Guarantee was transferred to the current beneficiary.&nbsp;
                                </Typography>
                                <Link className={classes.link} to={bgDetails.prevGxId}>
                                    <Typography> View original Bank Guarantee.</Typography>
                                </Link>
                            </React.Fragment>
                        )}
                </WrappedRow>
            </React.Fragment>
        )
    }
}

export default withTheme()(BGDetailsForm)
