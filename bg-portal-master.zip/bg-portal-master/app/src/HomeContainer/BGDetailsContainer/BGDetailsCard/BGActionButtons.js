// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import Tooltip from "@material-ui/core/Tooltip"
import Button from "@material-ui/core/Button"
import { Flex } from "~/shared/layout"
import generateKey from "~/util/helpers/generateKey"

type Props = {
    buttons: Array<Object>,
    text: string,
    disabled: Array<boolean>,
    theme: Object
}

const getClasses = ({ theme }) => {
    const formTitle = css(theme.typography.formTitle)
    const body1 = css(theme.typography.body1)
    const button = css(theme.typography.button)

    return {
        formTitle,
        body1,
        button
    }
}
const BGActionButtons = (props: Props) => {
    const { theme, buttons, text, disabled } = props
    const classes = getClasses({ theme })
    return (
        <div css={{ padding: "16px 24px" }}>
            <Typography className={classes.formTitle}>Available Actions</Typography>
            <Flex justifyContent="flex-start">
                {buttons.map((button, index) => (
                    <Tooltip key={generateKey(index * 2)} title={button.tooltip} disableFocusListener>
                        <Button
                            key={generateKey(index)}
                            className={classes.button}
                            onClick={button.onClick}
                            css={index === 0 ? { paddingLeft: "0px" } : {}}
                            disabled={disabled[index]}
                        >
                            {button.name}
                        </Button>
                    </Tooltip>
                ))}
            </Flex>
            <Typography className={classes.body1}>
                <i>{text}</i>
            </Typography>
        </div>
    )
}

export default withTheme()(BGActionButtons)
