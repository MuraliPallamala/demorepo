// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import Divider from "@material-ui/core/Divider"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

import BGDetailsCardContent from "./BGDetailsCardContent"
import BGActionButtons from "./BGActionButtons"

type Props = {
    bgDetails: Object,
    whoAmI: string,
    hasGuarantee: boolean,
    userContext: Object,
    buttons: Array<Object>,
    disabled: Array<boolean>,
    actionBarText: string,
    purposeTemplates: Templates
}

const BGDetailsCard = (props: Props) => {
    const { bgDetails, whoAmI, userContext, buttons, actionBarText, disabled, hasGuarantee, purposeTemplates } = props

    return (
        <Card css={{ marginBottom: "24px" }}>
            {userContext.isLoaded && (
                <BGDetailsCardContent
                    bgDetails={bgDetails}
                    whoAmI={whoAmI}
                    hasGuarantee={hasGuarantee}
                    purposeTemplates={purposeTemplates}
                />
            )}
            <Divider />
            {userContext.isLoaded && buttons.length > 0 && (
                <BGActionButtons buttons={buttons} text={actionBarText} disabled={disabled} />
            )}
        </Card>
    )
}

export default BGDetailsCard
