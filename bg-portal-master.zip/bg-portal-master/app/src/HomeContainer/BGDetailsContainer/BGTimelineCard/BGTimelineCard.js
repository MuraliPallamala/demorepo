// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Card from "@material-ui/core/Card"
import Button from "@material-ui/core/Button"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import DownIcon from "@material-ui/icons/KeyboardArrowDown"
import UpIcon from "@material-ui/icons/KeyboardArrowUp"
import DialogActions from "@material-ui/core/DialogActions"
import Dialog from "@material-ui/core/Dialog"
import DialogTitle from "@material-ui/core/DialogTitle"
import DialogContent from "@material-ui/core/DialogContent"
import Timeline from "~/shared/TimelineContainer/TimelineContainer"
import { Flex } from "~/shared/layout"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import Loading from "~/shared/Loading"
import api from "~/util/api"
import MyDatePicker from "~/shared/DatePicker/DatePicker"
import DownloadButton from "~/shared/DownloadButton"
import { mapActions } from "~/shared/TimelineContainer/Converters/GuaranteeMapping"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

type Props = {
    theme: Object,
    isOpen: boolean,
    requests: Array<Object>,
    isGuarantee: boolean,
    // gxId: string,
    currentOrgId: string,
    whoAmI: string,
    currentGxId: string,
    purposeType: string,
    purposeTemplates: Templates
}

type State = {
    loading: boolean,
    guaranteeDialogOpen: boolean,
    dialogLoading: boolean,
    dialogData: Array<any>,
    title: string,
    startDate: any,
    endDate: any,
    queryString: string
}

const getClasses = ({ theme }) => {
    const cardHeader = css(theme.typography.formTitle, {
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between"
    })
    const iconStyle = css({
        color: theme.palette.common.lightBlue
    })
    const datePicker = css({
        overflow: "visible",
        marginLeft: "15px",
        paddingBottom: "8px",
        width: "170px"
    })
    const dialogStyle = css({ width: "800px", minHeight: "300px", textAlign: "center" })
    const titleStyle = css({ h2: { color: `${theme.palette.common.darkBlue}!important` } })
    const button = css(theme.typography.button)
    return {
        iconStyle,
        dialogStyle,
        titleStyle,
        button,
        cardHeader,
        datePicker
    }
}

class BGTimeline extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            loading: false,
            guaranteeDialogOpen: false,
            dialogLoading: true,
            dialogData: [],
            title: "",
            startDate: null,
            endDate: null,
            queryString: ""
        }
    }
    componentDidMount() {
        if (!this.props.isGuarantee) {
            // api.guarantee
            //     .getGuaranteeRequest(this.props.gxId)
            //     .then(({ data }) => this.setState({ allRequests: data.result }))
            //     .catch(err => console.log(err))
        }
    }
    componentDidUpdate(prevProps, prevState) {
        if (prevState.startDate !== this.state.startDate || prevState.endDate !== this.state.endDate) {
            const { startDate, endDate } = this.state

            const mappedValues = { after: startDate, before: endDate }
            let queryString = Object.keys(mappedValues)
                .filter(key => mappedValues[key])
                .map(key => `${key}=${mappedValues[key]}`)
                .join("&")
            queryString = `?${queryString}`
            this.setState({ queryString })
        }
    }

    setDates = (name, date: any) => {
        this.setState({ [name]: date })
    }
    changeDialogState = (historyItem: Object) => {
        if (this.state.guaranteeDialogOpen === false) {
            this.setState({ guaranteeDialogOpen: true })

            if (this.state.dialogData.length === 0) {
                // api.guarantee.getWorkflows(hisotryItem.masterFlowId).then(data => console.log(data))
                api.guarantee.getRequestActions(historyItem.id).then(({ data }) => {
                    // Filter out external scope action when internal actions are visible
                    const filteredActions = data.result.filter(
                        action =>
                            !(
                                action.scope === "EXTERNAL" &&
                                action.createdBy &&
                                action.createdBy.id &&
                                action.createdBy.id === this.props.currentOrgId
                            )
                    )
                    // Map the actions to match data structure
                    const formattedGuaranteeActions = filteredActions.map(action => mapActions(action))
                    // Could be cleaner, handles case of Issuer deferral rejection
                    if (historyItem.type === "DEMAND" && PORTAL_TYPE === "issuer") {
                        let previousStartDemand = false
                        formattedGuaranteeActions.map(action => {
                            if (action.type === "REJECT" && action.scope === "INTERNAL") {
                                action.type = "REJECT_DEFER"
                                previousStartDemand = false
                            } else if (action.type === "DEFER_DEMAND_GUARANTEE") {
                                previousStartDemand = true
                            } else if (previousStartDemand && action.type === "APPROVE") {
                                action.type = "APPROVE_DEFER"
                            } else {
                                previousStartDemand = false
                            }
                            return action
                        })
                    }

                    const sortedDialogData = this.sortHistoryItems(formattedGuaranteeActions)
                    sortedDialogData.slice(-1)[0].status = "INITIATED"
                    this.setState({ dialogData: sortedDialogData, title: historyItem.title, dialogLoading: false })
                })
            } else {
                this.setState({ dialogLoading: false })
            }
        } else {
            this.setState({ guaranteeDialogOpen: false, dialogLoading: true, title: "", dialogData: [] })
        }
    }

    sortHistoryItems = (historyData: Array<any>) => {
        // Slow Sort, enhancement change to a merge :P
        const sortedData = historyData.sort((a, b) => {
            const dateA = new Date(a.createdAt)
            const dateB = new Date(b.createdAt)
            return dateB - dateA
        })
        return sortedData
    }
    sortAndFilter = (timelineData: Array<Object>) => {
        // Slow Sort, enhancement change to a merge :P
        const filteredRequests = timelineData.filter(request => {
            let isInRange = true
            if (this.state.startDate) {
                isInRange = new Date(request.updatedAt || request.createdAt) - new Date(this.state.startDate) > 0
                if (!isInRange) {
                    return isInRange
                }
            }
            if (this.state.endDate) {
                isInRange = new Date(this.state.endDate) - new Date(request.updatedAt || request.createdAt) > 0
                if (!isInRange) {
                    return isInRange
                }
            }

            return isInRange
        })
        const sortedData = filteredRequests.sort((a, b) => {
            const dateA = new Date(a.updatedAt ? a.updatedAt : a.createdAt)
            const dateB = new Date(b.updatedAt ? b.updatedAt : b.createdAt)
            return dateB - dateA
        })
        return sortedData
    }
    hasData = (data: Array<any>) => {
        if (data.length === 0) {
            return <Typography>No data</Typography>
        }
        return (
            <Timeline
                hideActions
                guarantee
                data={data}
                whoAmI={this.props.whoAmI}
                currentGxId={this.props.currentGxId}
                purposeType={this.props.purposeType}
                purposeTemplates={this.props.purposeTemplates}
            />
        )
    }

    render() {
        const { theme, isOpen, requests, whoAmI, currentGxId, isGuarantee } = this.props
        const { guaranteeDialogOpen, dialogData, dialogLoading, queryString } = this.state
        const classes = getClasses({ theme })
        const historyData = this.sortAndFilter(requests)
        return (
            <React.Fragment>
                {this.state.loading ? (
                    <LoadingCard />
                ) : (
                    <React.Fragment>
                        <Card>
                            <CardContent css={{ paddingBottom: "16px!important" }}>
                                <Flex>
                                    <Flex flex="1">
                                        <Typography className={classes.cardHeader}>
                                            Timeline {isOpen ? <UpIcon hidden /> : <DownIcon hidden />}
                                        </Typography>
                                    </Flex>
                                    <MyDatePicker
                                        fieldName="startDate"
                                        label="Beginning Date"
                                        dateValue={this.state.startDate}
                                        setDate={this.setDates}
                                        className={classes.datePicker}
                                    />
                                    <MyDatePicker
                                        fieldName="endDate"
                                        label="Ending Date"
                                        dateValue={this.state.endDate}
                                        setDate={this.setDates}
                                        className={classes.datePicker}
                                    />
                                    {isGuarantee && currentGxId && (
                                        <DownloadButton
                                            downloadCsv={api.audit.downloadGuaranteeAudit(currentGxId, queryString)}
                                        />
                                    )}
                                </Flex>
                                {isOpen && (
                                    <Timeline
                                        actionFunction={this.changeDialogState}
                                        guarantee
                                        data={historyData}
                                        whoAmI={whoAmI}
                                        currentGxId={currentGxId}
                                        purposeType={this.props.purposeType}
                                        purposeTemplates={this.props.purposeTemplates}
                                    />
                                )}
                            </CardContent>
                        </Card>
                    </React.Fragment>
                )}
                <Dialog open={guaranteeDialogOpen} maxWidth="md" onClose={this.changeDialogState}>
                    <DialogTitle classes={{ root: classes.titleStyle }}>
                        <Flex>
                            <Flex flex={1}>{this.state.title}</Flex>
                        </Flex>
                    </DialogTitle>
                    <DialogContent className={classes.dialogStyle}>
                        {dialogLoading ? <Loading show /> : this.hasData(dialogData)}
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.changeDialogState} className={classes.button}>
                            Ok
                        </Button>
                    </DialogActions>
                </Dialog>
            </React.Fragment>
        )
    }
}

export default withTheme()(BGTimeline)
