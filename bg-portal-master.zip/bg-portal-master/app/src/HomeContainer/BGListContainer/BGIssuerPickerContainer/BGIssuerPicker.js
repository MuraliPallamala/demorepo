// @flow

import * as React from "react"

import { withTheme } from "@material-ui/core/styles"
import { cx, css } from "emotion"
import { Flex } from "~/shared/layout"
import Button from "@material-ui/core/Button"
import Tooltip from "@material-ui/core/Tooltip"

const getClasses = ({ theme }) => {
    const baseButtonStyle = css({
        border: `0.8px solid ${theme.palette.common.lightBlue}`,
        borderRadius: "2px",
        textTransform: "none",
        padding: "0px",
        marginLeft: theme.spacing.unit / 2,
        minWidth: 50,
        minHeight: "0px",
        height: 30,
        color: theme.palette.common.lightBlue,

        "&:first-child": {
            marginLeft: 0
        }
    })
    const selectedButtonStyle = cx(
        baseButtonStyle,
        css({
            background: theme.palette.common.lightBlue,
            color: theme.palette.common.white,

            "&:hover": {
                color: theme.palette.common.lightBlue
            }
        })
    )

    const buttonStyle = selected => (selected ? selectedButtonStyle : baseButtonStyle)

    const iconText = css({
        fontWeight: theme.typography.fontWeightMedium
    })
    const icon = css({
        width: "28px",
        height: "28px",
        paddingRight: theme.spacing.unit,
        fill: theme.palette.common.lightBlue
    })

    return {
        buttonStyle,
        iconText,
        icon
    }
}

export type Issuer = {
    id: string,
    display: string
}

type Props = {
    theme: Object,
    issuers: Array<Issuer>,
    value: string,
    onChange: Function
}

const BGIssuerPicker = ({ issuers, theme, value, onChange }: Props) => {
    const classes = getClasses({ theme })
    return (
        <React.Fragment>
            {issuers.map(({ id, display }) => (
                <Button
                    key={id}
                    className={classes.buttonStyle(value === id)}
                    onClick={() => {
                        if (id !== value) {
                            onChange(id)
                        }
                    }}
                    value={id}
                >
                    <Flex>
                        <Tooltip title="Select Issuer" disableFocusListener>
                            <Flex className={classes.iconText} alignItems="center">
                                {display}
                            </Flex>
                        </Tooltip>
                    </Flex>
                </Button>
            ))}
        </React.Fragment>
    )
}

export default withTheme()(BGIssuerPicker)
