// @flow

import * as React from "react"
import withError from "~/shared/Context/ErrorDialog/withError"
import Typography from "@material-ui/core/Typography"
import api from "~/util/api"
import GxIssuerPicker from "./BGIssuerPicker"
import type { Issuer } from "./BGIssuerPicker"

type Props = { onChange: Function, value: string, handleErrorOpen: Function, history: any }
type State = { issuers: Array<Issuer>, loading: boolean }

class BGIssuerPickerContainer extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        this.state = {
            loading: true,
            issuers: []
        }
    }
    async componentDidMount() {
        await this.getIssuers()
    }

    getIssuers = async () => {
        try {
            this.setState(() => ({ loading: true }))
            const orgMapping = await api.organisations.getOrgsMappings()
            const { data } = await api.organisations.getOrgsWithQuery("?entityType=ISSUER&status=ACTIVE")
            this.setState(() => ({
                issuers: data.result.map(issuer => ({ display: orgMapping.data[issuer.id], id: issuer.id })),
                loading: false
            }))
        } catch (err) {
            this.props.handleErrorOpen({
                errorMessage: `Getting Organisation Info error`,
                title: "Organisation Error",
                error: err,
                extraDetails: {
                    Info: err.info,
                    CurrentUrl: this.props.history.location.pathname,
                    Payload: {},
                    ErrorResponse: err
                }
            })
            this.setState({ loading: false })
            throw err
        }
    }
    render() {
        const { onChange, value } = this.props
        const { loading, issuers } = this.state
        if (loading) {
            return <Typography>Loading</Typography>
        }
        return <GxIssuerPicker issuers={issuers} onChange={onChange} value={value} />
    }
}

export default withError(BGIssuerPickerContainer)
