// @flow

import * as React from "react"
import moment from "moment"
import Card from "@material-ui/core/Card"
import { Grid, Flex, Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import withError from "~/shared/Context/ErrorDialog/withError"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import RequestDialog from "~/shared/Dialogs/RequestDialog"
// import SearchContainer from "~/shared/SearchContainer/SearchContainer"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import api from "~/util/api"
import type { GxSearchRequest } from "~/util/api/base/guarantee"
import sortByDate from "~/util/helpers/sortByDate"
import { mapBGToTableValues } from "~/util/guarantee"
import { withFilter } from "~/shared/Context/Filter/FilterContext"
import { GX_STATUS } from "~/util/logic/gx"
import DownloadButton from "~/shared/DownloadButton"
import ParentSubDropdown from "~/shared/ParentSubDropdown/ParentSubDropdown"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import BGIssuerPickerContainer from "./BGIssuerPickerContainer/BGIssuerPickerContainer"
import BGFilterContainer from "./BGFilterContainer/BGFilterContainer"

type Props = {
    history: Object,
    className: string,
    handleErrorOpen: Function,
    filters: Object,
    replaceFilters: Function,
    addFilter: Function,
    removeFilter: Function,
    removeFilters: Function,
    location: Object,
    user: Object,
    theme: Object
}

type State = {
    rows: Array<Object>,
    selectedIssuer: string,
    loading: boolean,
    sorting: Object,
    openPrefillConfirmationDialog: boolean,
    purposeTemplates: Templates
}
const issuerKey = "SAVED_ISSUER"

const defaultSort = { dataName: "issuedAt", order: "desc" }
const columns = [
    { columnHeader: { dataName: "status", displayName: "Status" }, sort: true },
    { columnHeader: { dataName: "applicant", displayName: "Applicant" }, sort: true },
    { columnHeader: { dataName: "beneficiary", displayName: "Beneficiary" }, sort: true },
    { columnHeader: { dataName: "issuer", displayName: "Issuer" } },
    { columnHeader: { dataName: "amount", displayName: "Current Amount" }, sort: true },
    { columnHeader: { dataName: "expiresAt", displayName: "Expiry" }, sort: (a, b) => sortByDate(a, b, "expiresAt") },
    { columnHeader: { dataName: "issuedAt", displayName: "Issued" }, sort: true },
    { columnHeader: { dataName: "highestPriorityActiveRequest", displayName: "Active Request" } },
    { columnHeader: { dataName: "bankReference", displayName: "Reference" } }
]

class BGListContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            rows: [],
            selectedIssuer: window.localStorage.getItem(issuerKey) || "anz",
            // searchValue: "",
            loading: true,
            sorting: defaultSort,
            openPrefillConfirmationDialog: false,
            purposeTemplates: []
        }
    }

    componentDidMount() {
        // see if we came here from an issuer prefill request
        const params = new URLSearchParams(this.props.location.search)
        const issuerPrefillRequest = params.get("issuerPrefillRequest")
        api.purpose.getAllPurposeTemplates().then(({ data }) => {
            this.setState({ purposeTemplates: data.result })
        })
        if (issuerPrefillRequest) {
            // eslint-disable-next-line
            this.setState({
                openPrefillConfirmationDialog: true
            })
        }
        const gxSearchRequest = this.createGxSearchRequest()
        this.searchGuarantees(gxSearchRequest)
    }

    componentDidUpdate(prevProps, prevState) {
        let searchChange = false

        if (this.props.filters !== prevProps.filters) {
            searchChange = true
        }

        if (this.state.sorting !== prevState.sorting) {
            searchChange = true
        }

        if (this.state.selectedIssuer !== prevState.selectedIssuer) {
            searchChange = true
        }

        if (searchChange) {
            const gxSearchRequest = this.createGxSearchRequest()
            this.searchGuarantees(gxSearchRequest)
        }
    }

    onIssuerChange = issuer => {
        window.localStorage.setItem(issuerKey, issuer)
        this.setState({
            selectedIssuer: issuer
        })
    }

    onRowSelection = row => {
        this.props.history.push(`/gx/details/${row.id}`)
    }

    onSortingChange = sorting => {
        this.setState({
            sorting,
            loading: true
        })
    }

    createGxSearchRequest() {
        const { props, state } = this

        const gxSearchRequest: GxSearchRequest = {}
        if (props.filters) {
            if (props.filters.status) {
                // Note api will accept an array of statuses in the future
                gxSearchRequest.status = props.filters.status[0] // eslint-disable-line
            }
            if (props.filters.expiryMonths) {
                const futureMonth = moment().add(props.filters.expiryMonths, "M")
                gxSearchRequest.expiredBefore = futureMonth.toISOString()
                gxSearchRequest.status = GX_STATUS.ACTIVE
            }
            // $FlowFixMe
            gxSearchRequest.amountGreaterThan = props.filters.amountGreaterThan
                ? Math.floor(props.filters.amountGreaterThan * 100)
                : null
            // $FlowFixMe
            gxSearchRequest.amountSmallerThan = props.filters.amountSmallerThan
                ? Math.floor(props.filters.amountSmallerThan * 100)
                : null

            if (props.filters.openEndedOnly) {
                gxSearchRequest.expiredAfter = moment("3000-01-01").toISOString()
            } else {
                if (props.filters.expiredAfter) {
                    gxSearchRequest.expiredAfter = moment(props.filters.expiredAfter)
                        .endOf("day")
                        .toISOString()
                }
                if (props.filters.expiredBefore) {
                    gxSearchRequest.expiredBefore = moment(props.filters.expiredBefore).toISOString()
                }
            }

            if (props.filters.issuedAfter) {
                gxSearchRequest.issuedAfter = moment(props.filters.issuedAfter)
                    .endOf("day")
                    .toISOString()
            }
            if (props.filters.issuedBefore) {
                gxSearchRequest.issuedBefore = moment(props.filters.issuedBefore).toISOString()
            }
            if (props.filters.applicant) {
                gxSearchRequest.applicantId = props.filters.applicant.orgId
            }
            if (props.filters.beneficiary) {
                gxSearchRequest.beneficiaryId = props.filters.beneficiary.orgId
            }
            if (props.filters.purpose) {
                gxSearchRequest.purpose = props.filters.purpose
            }
            if (props.filters.purposeType) {
                gxSearchRequest.purposeType = props.filters.purposeType
            }
        }
        if (PORTAL_TYPE !== "issuer") {
            gxSearchRequest.issuerId = state.selectedIssuer
        }

        if (state.sorting) {
            const sort = state.sorting
            if (sort.dataName) {
                if (sort.dataName === "expiresAt") {
                    gxSearchRequest.orderBy = "expiredAt"
                } else {
                    gxSearchRequest.orderBy = sort.dataName
                }

                if (sort.order === "desc") {
                    gxSearchRequest.order = "DESC"
                }
            }
        }
        return gxSearchRequest
    }

    searchGuaranteesCSVApiCall = () => {
        const searchRequest = this.createGxSearchRequest()
        return api.guarantee.downloadGuarantees(
            {
                limit: 10000,
                ...searchRequest
            },
            {
                headers: {
                    Accept: "text/csv"
                }
            }
        )
    }

    searchGuarantees = (searchRequest?: GxSearchRequest = {}) => {
        this.setState({
            loading: true
        })
        return api.guarantee
            .searchGuarantees({
                limit: 10000,
                ...searchRequest
            })
            .then(resp => {
                const rows = mapBGToTableValues(resp.data.result)
                this.setState({ rows, loading: false })
            })

            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `There was an error getting your guarantee requests`,
                    title: "Guarantee Requests Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    dismissPrefillConfirmationDialog = () => this.setState({ openPrefillConfirmationDialog: false })

    render() {
        const { className, filters, replaceFilters, addFilter, removeFilter, removeFilters, user, theme } = this.props
        const {
            selectedIssuer,
            loading,
            rows,
            purposeTemplates
            // sorting,
        } = this.state

        return (
            <Grid gridGap="3un" className={className}>
                <RequestDialog
                    title="Request forwarded"
                    message="Prefill Request has been forwarded"
                    submitText="Ok"
                    onSubmit={this.dismissPrefillConfirmationDialog}
                    handleClose={this.dismissPrefillConfirmationDialog}
                    open={this.state.openPrefillConfirmationDialog}
                    hasCancelButton={false}
                />
                <Card>
                    <PageTitle
                        title={
                            // $FlowFixMe
                            <React.Fragment>
                                <Flex>
                                    <Flex flex="1">
                                        {user.actingOnBehalf ? `${user.actingOnBehalf.label} ` : ""}
                                        <span
                                            // eslint-disable-next-line
                                            tabIndex="0"
                                            id="main-content"
                                            style={user.actingOnBehalf ? { paddingLeft: "5px" } : null}
                                        >
                                            Guarantees
                                        </span>
                                        {PORTAL_TYPE === "user" ? (
                                            <Block inline paddingLeft="1un">
                                                <BGIssuerPickerContainer
                                                    value={selectedIssuer}
                                                    onChange={this.onIssuerChange}
                                                />
                                            </Block>
                                        ) : null}
                                        <BGFilterContainer
                                            filters={filters}
                                            replaceFilters={replaceFilters}
                                            addFilter={addFilter}
                                            purposeTemplates={purposeTemplates}
                                            removeFilter={removeFilter}
                                            removeFilters={removeFilters}
                                        />
                                    </Flex>
                                    <Flex>
                                        <ParentSubDropdown
                                            user={user}
                                            onChange={() => {
                                                const gxSearchRequest = this.createGxSearchRequest()
                                                return this.searchGuarantees(gxSearchRequest)
                                            }}
                                        />
                                    </Flex>
                                </Flex>
                            </React.Fragment>
                        }
                    />
                    <Block padding="0 3un 3un">
                        <FlexAccordionTable
                            onRowSelection={this.onRowSelection}
                            columns={columns}
                            data={rows}
                            loading={loading}
                            // defaultHiddenColumns={[]}
                            headerCustomContent={<DownloadButton downloadCsv={this.searchGuaranteesCSVApiCall} />}
                            defaultSort={defaultSort}
                            onSortingChange={this.onSortingChange}
                            className={css(theme.typography.tableStyle)}
                        />
                    </Block>
                </Card>
            </Grid>
        )
    }
}

export default withError(withFilter(withTheme()(BGListContainer)))
