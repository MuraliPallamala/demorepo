// @flow
import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import TextField from "@material-ui/core/TextField"
import IconButton from "@material-ui/core/IconButton"
import SearchIcon from "@material-ui/icons/Search"
import InputAdornment from "@material-ui/core/InputAdornment"

const getClasses = ({ theme }) => {
    const searchStyle = css({
        display: "inline-block",
        backgroundColor: theme.palette.common.backgroundSearchGrey,
        paddingLeft: theme.spacing.unit * 1,
        border: "solid 0.5px #D2D6DE"
    })
    const detailsSpacing = css({
        marginTop: theme.spacing.unit * 2,
        p: {
            marginBottom: theme.spacing.unit * 2
        }
    })
    const onboardingStyle = css({
        margin: "auto 0 0 0"
    })
    const iconSearch = css({
        color: theme.palette.common.darkBlue,
        display: "inline-block"
    })

    return {
        detailsSpacing,
        searchStyle,
        onboardingStyle,
        iconSearch
    }
}

type Props = {
    theme: Object,
    match: Object
}

type State = {
    searchValue: string
}

class BGSearchContainer extends React.Component<Props, State> {
    state = {
        searchValue: ""
    }

    handleChange = name => event => {
        this.setState({ [name]: event.target.value })
    }

    render() {
        const { theme } = this.props
        const classes = getClasses({ theme })
        return (
            <TextField
                className={classes.searchStyle}
                InputProps={{
                    endAdornment: (
                        <InputAdornment position="end">
                            <IconButton className={classes.iconSearch} tooltip="Search" type="submit">
                                <SearchIcon titleAccess="Search" />
                            </IconButton>
                        </InputAdornment>
                    ),
                    disableUnderline: true
                }}
                onChange={this.handleChange("searchValue")}
                value={this.state.searchValue}
                id="searchValue"
                placeholder="Search Guarantees"
            />
        )
    }
}

export default withTheme()(BGSearchContainer)
