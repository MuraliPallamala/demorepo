// @flow

import React from "react"
import { css } from "emotion"
// import moment from "moment"
// import numeral from "numeral"
import Chip from "@material-ui/core/Chip"
import { withTheme } from "@material-ui/core/styles"
// import { split } from "~/util/helpers/text"

const createClasses = theme => {
    const chip = css({
        backgroundColor: "#CEE5FF",
        margin: 4,
        height: "25px",
        span: {
            color: "#035277",
            fontWeight: "500",
            fontSize: `14px !important`
        }
    })
    return {
        chip
    }
}

type Props = { theme: Object, tag: string, value: any, onDelete: Function }

// Note we will need to create our own custom component instead of relying on Chip to properly match design
const BGFilterChip = ({ theme, tag, value, onDelete }: Props) => {
    const text = value !== null ? `${tag}: ${value}` : tag
    const classes = createClasses(theme)
    return <Chip label={text} onDelete={onDelete} className={classes.chip} />
}

export default withTheme()(BGFilterChip)
