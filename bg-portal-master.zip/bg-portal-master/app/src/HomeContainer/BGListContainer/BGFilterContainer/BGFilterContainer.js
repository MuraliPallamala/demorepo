// @flow

import * as React from "react"
import { css } from "emotion"

import numeral from "numeral"
import { withTheme } from "@material-ui/core/styles"
import moment from "moment"
import Tooltip from "@material-ui/core/Tooltip"

import Button from "@material-ui/core/Button"
import FilterListIcon from "@material-ui/icons/FilterList"

import { Flex } from "~/shared/layout"
import { capitalise, split, dateToShortString } from "~/util/helpers/text"
import { getGxStatusDisplay } from "~/util/logic/gx"
import type { Templates, Field } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import _ from "lodash"
import BGFilterPopover from "./BGFilterPopover"
import BGFilterChip from "./BGFilterChip"

const getClasses = ({ theme }) => {
    const iconText = css({
        color: theme.palette.common.lightBlue,
        fontWeight: theme.typography.fontWeightMedium
    })
    const icon = css({
        width: "28px",
        height: "28px",
        paddingRight: theme.spacing.unit,
        fill: theme.palette.common.lightBlue
    })

    const buttonStyle = css({
        border: `0.8px solid ${theme.palette.common.lightBlue}`,
        borderRadius: "2px",
        textTransform: "none",
        padding: "0px 4px",
        height: 30,
        marginLeft: theme.spacing.unit * 2,
        minHeight: "0px"
    })

    return {
        icon,
        buttonStyle,
        iconText
    }
}

type Props = {
    theme: Object,
    filters: Object,
    replaceFilters: Function,
    removeFilter: Function,
    removeFilters: Function,
    pendingGx: boolean,
    issuers: Array<Object>,
    purposeTemplates: Templates
}
type State = { anchorEl: any }

// Used to map the object to the chips
const mapFiltersObjectToArray = (filterValues, dotName, purposeTemplates) =>
    // Flattens out the nested arrays that get created when mapObject is recursively called when digging into the Object
    _.flattenDeep(
        Object.entries(filterValues).map(([key, value]: any) => {
            let tmpDotName = dotName || ""
            // need to ignore this for the applicant and beneficiary objects
            if (_.isPlainObject(value) && !["applicant", "beneficiary"].includes(key)) {
                tmpDotName += `${key}.`
                return mapFiltersObjectToArray(value, tmpDotName)
            } else if (tmpDotName) {
                tmpDotName += `${key}`
            }
            let displayKey = capitalise(split(key))
            let displayValue = value
            // Format filter display
            if (key === "status") {
                displayValue = value.map(status => getGxStatusDisplay(status))[0]
            } else if (key === "expiryMonths") {
                displayKey = "Expires in"
                displayValue = `${value} Months`
            } else if (["issuedAfter", "issuedBefore", "expiredAfter", "expiredBefore"].includes(key)) {
                if (key === "expiredAfter") {
                    displayKey = "Expires After"
                } else if (key === "expiredBefore") {
                    displayKey = "Expires Before"
                }
                displayValue = dateToShortString(value)
            } else if (["applicant", "beneficiary"].includes(key)) {
                displayValue = value.entityName
            } else if (key === "amountSmallerThan" || key === "amountGreaterThan") {
                // need to divide value by 100 because the server stores values of cents
                displayValue = `AUD $${numeral(value).format("0,0.00")}`
            } else if (key === "addressRegion") {
                displayValue = value.label
            } else if (key === "openEndedOnly") {
                displayValue = null
            } else if (key === "purposeType") {
                const selectedTemplate = purposeTemplates
                    ? purposeTemplates.find(template => template.id === value)
                    : undefined
                displayValue = selectedTemplate ? selectedTemplate.label : value
            } else if (!moment(value).isValid() || Number(value)) {
                displayValue = value
            } else if (moment(value).isValid()) {
                // need to pretty display dates that can be in the purpose object
                displayValue = dateToShortString(value)
            }

            // display Yes and No for boolean values
            if (typeof displayValue === "boolean") {
                if (displayValue) {
                    displayValue = "Yes"
                } else {
                    displayValue = "No"
                }
            }
            return {
                data: { key, value, dotName: tmpDotName },
                display: { displayKey, displayValue }
            }
        })
    )
const recursivelyAddKeysToRemove = (field: Field, fieldName: string, keysToRemove: Array<string>) => {
    if (field.subFields && field.subFields.length >= 1) {
        field.subFields.forEach(subField => {
            const newName = `${fieldName}.${subField.name}`
            recursivelyAddKeysToRemove(subField, newName, keysToRemove)
        })
    } else {
        keysToRemove.push(fieldName)
    }
}

const renderChips = (filters, removeFilter, removeFilters, purposeTemplates) => {
    const tmp = mapFiltersObjectToArray(filters, "", purposeTemplates)
    return tmp.map(({ data, display }: any) => (
        <BGFilterChip
            key={data.key}
            tag={display.displayKey}
            value={display.displayValue}
            onDelete={() => {
                if (data.key === "purposeType") {
                    const keysToRemove = [data.dotName || data.key]
                    const selectedTemplate = purposeTemplates.find(template => template.id === data.value)
                    if (selectedTemplate) {
                        selectedTemplate.fields.forEach(field => {
                            recursivelyAddKeysToRemove(field, `purpose.${field.name}`, keysToRemove)
                        })
                    }
                    removeFilters(keysToRemove)
                } else {
                    removeFilter(data.dotName || data.key)
                }
            }}
        />
    ))
}

class BGFilterContainer extends React.Component<Props, State> {
    static defaultProps = {
        pendingGx: false,
        issuers: []
    }
    constructor(props: Props) {
        super(props)
        this.state = {
            anchorEl: null
        }
    }
    handleClick = event => {
        this.setState({
            anchorEl: event.currentTarget
        })
    }

    handleClose = () => {
        this.setState({
            anchorEl: null
        })
    }

    handlePopoverChanges = (popoverValues: Object) => {
        const newFilters: Object = {}
        if (popoverValues.status) {
            newFilters.status = [popoverValues.status]
        }
        if (popoverValues.issuer) {
            newFilters.issuer = [popoverValues.issuer]
        }
        if (popoverValues.requestType) {
            newFilters.requestType = [popoverValues.requestType]
        }
        if (typeof popoverValues.amountGreaterThan === "number") {
            newFilters.amountGreaterThan = popoverValues.amountGreaterThan
        }

        if (typeof popoverValues.amountSmallerThan === "number") {
            newFilters.amountSmallerThan = popoverValues.amountSmallerThan
        }

        if (popoverValues.openEndedOnly) {
            newFilters.openEndedOnly = popoverValues.openEndedOnly
        } else {
            if (popoverValues.expiredAfter) {
                newFilters.expiredAfter = popoverValues.expiredAfter
            }

            if (popoverValues.expiredBefore) {
                newFilters.expiredBefore = popoverValues.expiredBefore
            }
        }

        if (popoverValues.issuedAfter) {
            newFilters.issuedAfter = popoverValues.issuedAfter
        }

        if (popoverValues.issuedBefore) {
            newFilters.issuedBefore = popoverValues.issuedBefore
        }

        if (popoverValues.applicant) {
            newFilters.applicant = popoverValues.applicant
        }

        if (popoverValues.beneficiary) {
            newFilters.beneficiary = popoverValues.beneficiary
        }
        if (popoverValues.purpose) {
            newFilters.purpose = popoverValues.purpose
        }
        if (popoverValues.purposeType) {
            newFilters.purposeType = popoverValues.purposeType
        }
        this.props.replaceFilters(newFilters)
    }

    createPopoverInitialValues = filters => {
        const initialValues: Object = {
            status: filters.status ? filters.status[0] : "",
            amountSmallerThan: filters.amountSmallerThan ? +filters.amountSmallerThan : null,
            amountGreaterThan: filters.amountGreaterThan ? +filters.amountGreaterThan : null,
            expiredAfter: filters.expiredAfter || null,
            expiredBefore: filters.expiredBefore || null,
            issuedAfter: filters.issuedAfter || null,
            issuedBefore: filters.issuedBefore || null,
            applicant: filters.applicant || "",
            beneficiary: filters.beneficiary || "",
            issuer: filters.issuer ? filters.issuer[0] : "",
            requestType: filters.requestType ? filters.requestType[0] : "",
            openEndedOnly: filters.openEndedOnly || false,
            purposeType: filters.purposeType || "",
            purpose: filters.purpose || {}
        }
        return initialValues
    }

    render() {
        const { theme, filters, removeFilter, removeFilters, pendingGx, issuers, purposeTemplates } = this.props
        const { anchorEl } = this.state
        const classes = getClasses({ theme })

        return (
            <React.Fragment>
                <Button className={classes.buttonStyle} onClick={this.handleClick}>
                    <Flex>
                        <Tooltip title="Table Filters" disableFocusListener>
                            <Flex className={classes.iconText} alignItems="center">
                                <FilterListIcon className={classes.icon} titleAccess="Open Filter Dialog" />
                                Filters
                            </Flex>
                        </Tooltip>
                    </Flex>
                </Button>
                {renderChips(filters, removeFilter, removeFilters, purposeTemplates)}
                <BGFilterPopover
                    anchorEl={anchorEl}
                    handleClose={this.handleClose}
                    initialValues={this.createPopoverInitialValues(filters)}
                    onChange={this.handlePopoverChanges}
                    pendingGx={pendingGx}
                    issuers={issuers}
                    purposeTemplates={purposeTemplates}
                />
            </React.Fragment>
        )
    }
}

export default withTheme()(BGFilterContainer)
