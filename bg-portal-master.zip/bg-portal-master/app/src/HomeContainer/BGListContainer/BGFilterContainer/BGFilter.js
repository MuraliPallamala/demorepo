// @flow

import React from "react"
import { css } from "emotion"
import FormControl from "@material-ui/core/FormControl"
import InputLabel from "@material-ui/core/InputLabel"
import TextField from "@material-ui/core/TextField"
import Select from "@material-ui/core/Select"
import MenuItem from "@material-ui/core/MenuItem"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import DatePicker from "material-ui-pickers/DatePicker"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import Checkbox from "@material-ui/core/Checkbox"
import KeyboardLeft from "@material-ui/icons/KeyboardArrowLeft"
import KeyboardRight from "@material-ui/icons/KeyboardArrowRight"
import { GX_STATUS, GX_STATUS_DISPLAY_MAP } from "~/util/logic/gx"
import { Flex, Grid, Block, Row, Col, WrappedRow } from "~/shared/layout"
import NumberTextField from "~/shared/NumberTextField"
import ApplicantBeneficiarySearchFieldSet from "~/shared/Fields/ApplicantBeneficiarySearch/ApplicantBeneficiarySearchFieldSet"
import SearchLocationFieldSet from "~/shared/Fields/LocationDetails/SearchLocationFieldSet"

export type PopoverInitialValues = {
    status: string,
    amountGreaterThan?: number,
    amountSmallerThan?: number,
    expiredAfter?: string,
    expiredBefore?: string,
    issuedAfter?: string,
    issuedBefore?: string,
    applicant?: Object,
    beneficiary?: Object,
    issuer?: string,
    requestType?: string,
    openEndedOnly: boolean,
    purpose?: Object,
    purposeType?: string
}

const requestTypes = [
    { value: "Amend", label: "Amend" },
    { value: "Issue", label: "Issue" },
    { value: "Demand", label: "Demand" },
    { value: "Transfer", label: "Transfer" },
    { value: "Cancel", label: "Cancel" }
]
const statuses = [
    {
        value: GX_STATUS.ACTIVE,
        label: GX_STATUS_DISPLAY_MAP[GX_STATUS.ACTIVE]
    },
    {
        value: GX_STATUS.CANCELLED,
        label: GX_STATUS_DISPLAY_MAP[GX_STATUS.CANCELLED]
    },
    {
        value: GX_STATUS.DEMANDED,
        label: GX_STATUS_DISPLAY_MAP[GX_STATUS.DEMANDED]
    },
    {
        value: GX_STATUS.EXPIRED,
        label: GX_STATUS_DISPLAY_MAP[GX_STATUS.EXPIRED]
    },
    {
        value: GX_STATUS.PAYWALKED,
        label: GX_STATUS_DISPLAY_MAP[GX_STATUS.PAYWALKED]
    },
    {
        value: GX_STATUS.TRANSFERRED,
        label: GX_STATUS_DISPLAY_MAP[GX_STATUS.TRANSFERRED]
    }
]

const getClasses = ({ theme }) => {
    const grid = css({
        // gridTemplateRows: "repeat(7, auto)",
        gridColumnGap: "2fr",
        // gridGap: "23un",
        minWidth: "325px",
        // marginTop: "1rem",
        // marginBottom: "1rem",
        flex: "1"
    })
    const gridContent = css(theme.typography.body1, {
        padding: "5px 5px 0px 0px",
        marginRight: "5px"
    })
    const largeLabel = css(theme.typography.body2, {
        fontSize: theme.commonFontSizes.medium,
        alignSelf: "end",
        paddingBottom: "10px"
    })
    const smallLabel = css(theme.typography.body2, {
        alignSelf: "end",
        padding: "5px 5px 0px 0px",
        marginLeft: "0px",
        marginRight: "5px"
    })
    const fullWidthInput = css({
        width: "100%"
    })
    const popOver = css({
        margin: theme.spacing.unit * 2,
        maxWidth: "1200px"
    })
    const datePicker = css()
    const button = css(theme.typography.button)
    return {
        grid,
        gridContent,
        largeLabel,
        smallLabel,
        fullWidthInput,
        popOver,
        datePicker,
        button
    }
}

type CustomSelectProps = {
    id: string,
    label: string,
    value: string,
    data: Array<Object>,
    handleChange: Function
}
const CustomSelect = ({ id, label, value, data, handleChange }: CustomSelectProps) => (
    <Block key={id} paddingBottom="3un">
        <FormControl css={{ width: "100%" }}>
            <InputLabel htmlFor={id}>{label}</InputLabel>
            <Select
                name={id}
                id={id}
                floatingLabelText={`Filter by ${label}`}
                aria-label={`Filter by ${label}`}
                value={value}
                onChange={handleChange}
            >
                {data.map(elem => (
                    <MenuItem value={elem.value} key={elem.value + elem.text}>
                        {elem.text}
                    </MenuItem>
                ))}
            </Select>
        </FormControl>
    </Block>
)

type CustomTextFieldProps = {
    id: string,
    label: string,
    value: any,
    type: ?string, // eslint-disable-line react/require-default-props
    handleChange: Function,
    InputLabelProps?: Object, // eslint-disable-line react/require-default-props
    error: ?string
}
const CustomTextField = ({ id, label, value, type, handleChange, InputLabelProps, error }: CustomTextFieldProps) => (
    <Block key={id} paddingBottom="3un">
        <TextField
            id={id}
            name={id}
            css={{ width: "100%" }}
            label={label}
            floatingLabelText={`Filter by ${label}`}
            // type={type}
            onChange={e => handleChange(id, parseFloat(e.target.value))}
            value={value}
            InputLabelProps={InputLabelProps}
            margin="normal"
            InputProps={{
                inputComponent: NumberTextField
            }}
            error={error ? !!error : false}
            helperText={error && error !== " " ? error : ""}
        />
    </Block>
)

type CustomDatePickerProps = {
    id: string,
    label: string,
    value: any,
    type?: string, // eslint-disable-line react/require-default-props
    handleChange: Function,
    InputLabelProps?: Object, // eslint-disable-line react/require-default-props
    error: ?string,
    disabled?: boolean, // eslint-disable-line react/require-default-props
    helperText?: string // eslint-disable-line react/require-default-props
}
const CustomDatePicker = ({
    id,
    label,
    value,
    type,
    handleChange,
    InputLabelProps,
    error,
    disabled,
    helperText = ""
}: CustomDatePickerProps) => (
    <DatePicker
        animateYearScrolling
        autoOk
        clearable
        showTodayButton
        name={id}
        floatingLabelText={`Filter by ${label}`}
        aria-label={`Filter by ${label}`}
        label={label}
        format="DD/MM/YYYY"
        value={value}
        css={{
            overflow: "visible",
            marginRight: "5px"
        }}
        leftArrowIcon={<KeyboardLeft titleAccess="One month earlier" />}
        rightArrowIcon={<KeyboardRight titleAccess="One month later" />}
        margin="normal"
        error={value ? !!error : false}
        helperText={error && error !== " " ? error : helperText}
        onChange={e => {
            if (e) {
                handleChange(id, e.toISOString())
            } else {
                handleChange(id, e)
            }
        }}
        disabled={disabled}
    />
)

type FormikProps = {
    formikProps: Object
}
const AmountGreaterThan = ({ formikProps }: FormikProps) => (
    <CustomTextField
        id="amountGreaterThan"
        label="Amount Greater Than"
        value={formikProps.values.amountGreaterThan}
        type="number"
        handleChange={formikProps.setFieldValue}
        error={formikProps.errors.amountGreaterThan}
    />
)
const AmountSmallerThan = ({ formikProps }: FormikProps) => (
    <CustomTextField
        id="amountSmallerThan"
        label="Amount Less Than"
        value={formikProps.values.amountSmallerThan}
        type="number"
        handleChange={formikProps.setFieldValue}
        error={formikProps.errors.amountSmallerThan}
    />
)
const ExpiredAfter = ({ formikProps }: FormikProps) => (
    <CustomDatePicker
        id="expiredAfter"
        label="Expires After"
        value={formikProps.values.expiredAfter}
        type="date"
        handleChange={formikProps.setFieldValue}
        InputLabelProps={{ shrink: true }}
        error={formikProps.errors.expiredAfter}
        disabled={formikProps.values.openEndedOnly}
    />
)
const ExpiredBefore = ({ formikProps }: FormikProps) => (
    <CustomDatePicker
        id="expiredBefore"
        label="Expires Before"
        value={formikProps.values.expiredBefore}
        type="date"
        handleChange={formikProps.setFieldValue}
        InputLabelProps={{ shrink: true }}
        error={formikProps.errors.expiredBefore}
        disabled={formikProps.values.openEndedOnly}
    />
)
const IssuedAfter = ({ formikProps }: FormikProps) => (
    <CustomDatePicker
        id="issuedAfter"
        label="Issued After"
        value={formikProps.values.issuedAfter}
        type="date"
        handleChange={formikProps.setFieldValue}
        InputLabelProps={{ shrink: true }}
        error={formikProps.errors.issuedAfter}
    />
)
const IssuedBefore = ({ formikProps }: FormikProps) => (
    <CustomDatePicker
        id="issuedBefore"
        label="Issued Before"
        value={formikProps.values.issuedBefore}
        type="date"
        handleChange={formikProps.setFieldValue}
        InputLabelProps={{ shrink: true }}
        error={formikProps.errors.issuedBefore}
    />
)
const OpenEnded = ({ formikProps }: FormikProps) => (
    <Checkbox
        checked={formikProps.values.openEndedOnly}
        onChange={e => {
            const { checked } = e.target
            formikProps.setFieldValue("openEndedOnly", checked)
        }}
        value="OpenEnded"
        name="openEndedOnly"
    />
)
type LabelProps = {
    theme: Object
}
const LargeLabel = withTheme()(({ theme, ...props }: LabelProps) => {
    const classes = getClasses({ theme })
    // const rowCol = { gridRow: row, gridColumn: col }
    // return <Typography className={classes.largeLabel} css={rowCol} {...props} />
    return <Typography className={classes.largeLabel} {...props} />
})
const SmallLabel = withTheme()(({ theme, ...props }: LabelProps) => {
    const classes = getClasses({ theme })
    // const rowCol = { gridRow: row, gridColumn: col }
    return <Typography className={classes.smallLabel} {...props} />
})
type GridProps = {
    theme: Object,
    row: string,
    col: string
}
const GridLabel = withTheme()(({ theme, row, col, ...props }: GridProps) => {
    const classes = getClasses({ theme })
    const rowCol = { gridRow: row, gridColumn: col }
    return (
        <Flex alignItems="center">
            <Typography className={classes.gridContent} css={rowCol} {...props} />
        </Flex>
    )
})
const GridContent = withTheme()(({ theme, row, col, ...props }: GridProps) => {
    const classes = getClasses({ theme })
    const rowCol = { gridRow: row, gridColumn: col }
    return <Typography className={classes.gridContent} css={rowCol} {...props} />
})

const getData = items => [
    {
        value: "",
        text: ".."
    },
    ...items.map(item => ({
        value: item.value,
        text: item.label
    }))
]

type PartiesInvolvedProps = { theme: Object, formikProps: Object, pendingGx: boolean, issuers: Array<Object> }
const PartiesInvolved = withTheme()(({ theme, formikProps, pendingGx, issuers }: PartiesInvolvedProps) => (
    // const classes = getClasses({ theme })
    <Col flex={1}>
        <Row flex={1}>
            <LargeLabel>Parties Involved</LargeLabel>
        </Row>
        <ApplicantBeneficiarySearchFieldSet formik={formikProps} />
        {pendingGx && (
            <Row flex={1}>
                <CustomSelect
                    id="issuer"
                    label="Issuer"
                    value={formikProps.values.issuer ? formikProps.values.issuer : ""}
                    data={getData(issuers)}
                    handleChange={formikProps.handleChange}
                />
            </Row>
        )}
    </Col>
))

type StatusAndRequestTypeProps = { theme: Object, formikProps: Object, pendingGx: boolean }
const StatusAndRequestType = withTheme()(({ theme, formikProps, pendingGx }: StatusAndRequestTypeProps) => (
    // const classes = getClasses({ theme })
    <Col flex={1}>
        <Row flex={1}>
            <LargeLabel>Status and Request Type</LargeLabel>
        </Row>
        {!pendingGx && (
            <Row flex={1}>
                <SmallLabel>Status</SmallLabel>
                <CustomSelect
                    id="status"
                    label="Status"
                    value={formikProps.values.status}
                    data={getData(statuses)}
                    handleChange={formikProps.handleChange}
                />
            </Row>
        )}
        {pendingGx && (
            <Row flex={1}>
                <CustomSelect
                    id="requestType"
                    label="Request Type"
                    value={formikProps.values.requestType ? formikProps.values.requestType : ""}
                    data={getData(requestTypes)}
                    handleChange={formikProps.handleChange}
                />
            </Row>
        )}
    </Col>
))

type PropertyInvolvedProps = { theme: Object, formikProps: Object }
const PropertyInvolved = withTheme()(({ theme, formikProps }: PropertyInvolvedProps) => {
    const classes = getClasses({ theme })
    return (
        <Col flex={1}>
            <Row>
                <LargeLabel>Property Involved</LargeLabel>
            </Row>
            <Row flex={1}>
                <Grid className={classes.grid} gridTemplateColumns="80px 1fr">
                    <GridLabel row="1" col="1">
                        Location
                    </GridLabel>
                    <GridContent row="1" col="2">
                        <SearchLocationFieldSet formik={formikProps} />
                    </GridContent>
                </Grid>
            </Row>
        </Col>
    )
})

type GuaranteeDetailsProps = { theme: Object, formikProps: Object, pendingGx: boolean }
const GuaranteeDetails = withTheme()(({ theme, formikProps, pendingGx }: GuaranteeDetailsProps) => {
    const classes = getClasses({ theme })
    return (
        <Col flex={1}>
            <Row flex={1}>
                <LargeLabel>Guarantee Details</LargeLabel>
            </Row>
            <Row flex={1}>
                <Grid className={classes.grid} gridTemplateColumns="80px 1fr">
                    <GridLabel row="1" col="1">
                        {pendingGx ? "RequestType" : "Status"}
                    </GridLabel>
                    <GridContent row="1" col="2">
                        {pendingGx && (
                            <CustomSelect
                                id="requestType"
                                label="Request Type"
                                value={formikProps.values.requestType ? formikProps.values.requestType : ""}
                                data={getData(requestTypes)}
                                handleChange={formikProps.handleChange}
                            />
                        )}
                        {!pendingGx && (
                            <CustomSelect
                                id="status"
                                label="Status"
                                value={formikProps.values.status}
                                data={getData(statuses)}
                                handleChange={formikProps.handleChange}
                            />
                        )}
                    </GridContent>
                </Grid>
            </Row>
            <WrappedRow css={{ justifyContent: "space-between" }}>
                <Col flex={1}>
                    <Grid hidden={pendingGx} className={classes.grid} gridTemplateColumns="80px 1fr 1fr">
                        <GridLabel row="1" col="1">
                            Expires
                        </GridLabel>
                        <GridContent row="1" col="2">
                            <ExpiredAfter formikProps={formikProps} />
                        </GridContent>
                        <GridContent row="1" col="3">
                            <ExpiredBefore formikProps={formikProps} />
                        </GridContent>
                        <GridContent row="2" col="2/4">
                            <FormControl>
                                <FormControlLabel
                                    control={<OpenEnded formikProps={formikProps} />}
                                    label="Open Ended Guarantees Only"
                                />
                            </FormControl>
                        </GridContent>
                    </Grid>
                </Col>
                <Col flex={1}>
                    <Grid className={classes.grid} gridTemplateColumns="1fr 1fr 1fr">
                        <GridLabel row="1" col="1">
                            Issued
                        </GridLabel>
                        <GridContent row="1" col="2">
                            <IssuedAfter formikProps={formikProps} />
                        </GridContent>
                        <GridContent row="1" col="3">
                            <IssuedBefore formikProps={formikProps} />
                        </GridContent>
                    </Grid>
                </Col>
                <Col flex={1}>
                    <Grid className={classes.grid} gridTemplateColumns="1fr 1fr 1fr">
                        <GridLabel row="1" col="1">
                            Amount
                        </GridLabel>
                        <GridContent row="1" col="2">
                            <AmountGreaterThan formikProps={formikProps} />
                        </GridContent>
                        <GridContent row="1" col="3">
                            <AmountSmallerThan formikProps={formikProps} />
                        </GridContent>
                    </Grid>
                </Col>
            </WrappedRow>
        </Col>
    )
})

export { PartiesInvolved, StatusAndRequestType, PropertyInvolved, GuaranteeDetails }
