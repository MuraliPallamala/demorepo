// @flow

import React from "react"
import moment from "moment"
import { Formik } from "formik"
import { css } from "emotion"
import FormControl from "@material-ui/core/FormControl"
import InputLabel from "@material-ui/core/InputLabel"
import Button from "@material-ui/core/Button"
import TextField from "@material-ui/core/TextField"
import Select from "@material-ui/core/Select"
import MenuItem from "@material-ui/core/MenuItem"
import Typography from "@material-ui/core/Typography"
import Dialog from "@material-ui/core/Dialog"
import DialogContent from "@material-ui/core/DialogContent"
import { withTheme } from "@material-ui/core/styles"
import DatePicker from "material-ui-pickers/DatePicker"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import Checkbox from "@material-ui/core/Checkbox"
import KeyboardLeft from "@material-ui/icons/KeyboardArrowLeft"
import KeyboardRight from "@material-ui/icons/KeyboardArrowRight"
import CalendarIcon from "@material-ui/icons/Today"
import { GX_STATUS, GX_STATUS_DISPLAY_MAP } from "~/util/logic/gx"
import { Grid, Flex, Block } from "~/shared/layout"
import NumberTextField from "~/shared/NumberTextField"
import ApplicantBeneficiarySearchFieldSet from "~/shared/Fields/ApplicantBeneficiarySearch/ApplicantBeneficiarySearchFieldSet"
import PurposeFieldSet from "~/shared/Fields/PurposeFieldSet/PurposeFieldSet"
import getCurrentTemplate from "~/util/helpers/getCurrentTemplate"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

export type PopoverInitialValues = {
    status: string,
    amountGreaterThan?: number,
    amountSmallerThan?: number,
    expiredAfter?: string,
    expiredBefore?: string,
    issuedAfter?: string,
    issuedBefore?: string,
    applicant?: Object,
    beneficiary?: Object,
    issuer?: string,
    requestType?: string,
    openEndedOnly: boolean,
    purpose?: Object,
    purposeType?: string
}

type Props = {
    theme: Object,
    anchorEl: Object,
    handleClose: Function,
    initialValues: PopoverInitialValues,
    onChange: Function,
    pendingGx: boolean,
    issuers: Array<Object>,
    purposeTemplates: Templates
}

type State = {}

const requestTypes = [
    { value: "Amend", label: "Amend" },
    { value: "Issue", label: "Issue" },
    { value: "Demand", label: "Demand" },
    { value: "Transfer", label: "Transfer" },
    { value: "Cancel", label: "Cancel" }
]

const getClasses = ({ theme }) => {
    const fullWidthInput = css({
        width: "100%"
    })

    const popOver = css({
        margin: theme.spacing.unit * 2,
        maxWidth: "1200px"
    })
    const datePicker = css()
    const button = css(theme.typography.button)
    const label = css({
        fontSize: theme.commonFontSizes.large,
        fontWeight: theme.commonFontWeights.medium
    })
    const body = css({
        marginLeft: 20
    })
    const issuer = css({
        marginTop: "15px"
    })
    const requestType = css({
        marginTop: "15px"
    })
    const status = css({
        marginTop: "15px"
    })
    const subHeading = css({
        fontSize: theme.typography.fontSizeMedium
        // margin: "auto"
    })
    return {
        fullWidthInput,
        popOver,
        datePicker,
        button,
        label,
        body,
        issuer,
        requestType,
        status,
        subHeading
    }
}
// const convertNumber = number => {
//     if (number < 6 && number >= 3) {
//         return 6
//     } else if (number > 6) {
//         return 12
//     }
//     return 4
// }

type CustomSelectProps = {
    id: string,
    label: string,
    value: string,
    data: Array<Object>,
    handleChange: Function
}
const CustomSelect = ({ id, label, value, data, handleChange }: CustomSelectProps) => (
    <Block key={id}>
        <FormControl css={{ width: "100%", marginTop: "15px" }}>
            <InputLabel htmlFor={id}>{label}</InputLabel>
            <Select
                name={id}
                id={id}
                floatingLabelText={`Filter by ${label}`}
                aria-label={`Filter by ${label}`}
                value={value}
                onChange={handleChange}
            >
                {data.map(elem => (
                    <MenuItem value={elem.value} key={elem.value + elem.text}>
                        {elem.text}
                    </MenuItem>
                ))}
            </Select>
        </FormControl>
    </Block>
)

type CustomTextFieldProps = {
    id: string,
    label: string,
    value: any,
    type: ?string, // eslint-disable-line react/require-default-props
    handleChange: Function,
    InputLabelProps?: Object, // eslint-disable-line react/require-default-props
    error: ?string
}
const CustomAmountField = ({ id, label, value, type, handleChange, InputLabelProps, error }: CustomTextFieldProps) => (
    <Block key={id} paddingBottom="3un">
        <TextField
            id={id}
            name={id}
            css={{ width: "100%" }}
            label={label}
            floatingLabelText={`Filter by ${label}`}
            aria-label={`Filter by ${label}`}
            // type={type}
            onChange={e => handleChange(id, parseFloat(e.target.value))}
            value={value}
            InputLabelProps={InputLabelProps}
            margin="normal"
            InputProps={{
                inputComponent: NumberTextField
            }}
            error={error ? !!error : false}
            helperText={error && error !== " " ? error : ""}
        />
    </Block>
)

type CustomDatePickerProps = {
    id: string,
    label: string,
    value: any,
    type?: string, // eslint-disable-line react/require-default-props
    handleChange: Function,
    InputLabelProps?: Object, // eslint-disable-line react/require-default-props
    error: ?string,
    disabled?: boolean, // eslint-disable-line react/require-default-props
    helperText?: string // eslint-disable-line react/require-default-props
}
const CustomDatePicker = ({
    id,
    label,
    value,
    type,
    handleChange,
    InputLabelProps,
    error,
    disabled,
    helperText = ""
}: CustomDatePickerProps) => (
    <DatePicker
        floatingLabelText={`Filter by ${label}`}
        label={label}
        margin="normal"
        error={value ? !!error : false}
        helperText={error && error !== " " ? error : helperText}
        disabled={disabled}
        animateYearScrolling
        autoOk
        keyboard
        clearable
        showTodayButton
        name={id}
        format="DD/MM/YYYY"
        placeholder="DD/MM/YYYY"
        keyboardIcon={<CalendarIcon />}
        mask={v => (v ? [/\d/, /\d/, "/", /\d/, /\d/, "/", /\d/, /\d/, /\d/, /\d/] : [])}
        value={value}
        css={{
            overflow: "visible",
            marginRight: "5px"
        }}
        aria-label={`Filter by ${label}`}
        leftArrowIcon={<KeyboardLeft aria-label="Go to one month earlier" />}
        rightArrowIcon={<KeyboardRight aria-label="Go to one month later" />}
        onChange={e => {
            if (e) {
                handleChange(id, e.toISOString())
            } else {
                handleChange(id, e)
            }
        }}
    />
)

class BGFilterPopover extends React.Component<Props, State> {
    render() {
        const {
            theme,
            anchorEl,
            handleClose,
            initialValues,
            onChange,
            pendingGx,
            issuers,
            purposeTemplates
        } = this.props
        const classes = getClasses({ theme })

        return (
            // $FlowFixMe
            <Dialog open={Boolean(anchorEl)} onClose={handleClose} maxWidth="xl">
                <DialogContent>
                    <Formik
                        initialValues={initialValues}
                        onSubmit={(values, { setSubmitting, setErrors }) => {
                            onChange(values)
                            handleClose()
                        }}
                        validate={values => {
                            const errors = {}
                            if (
                                values.amountGreaterThan != null &&
                                values.amountSmallerThan != null &&
                                values.amountGreaterThan >= values.amountSmallerThan
                            ) {
                                errors.amountGreaterThan = " "
                                errors.amountSmallerThan = "Amount Less Than must be greater than Amount Greater Than"
                            }
                            if (values.expiredAfter && values.expiredBefore) {
                                const expiredAfterMom = moment(values.expiredAfter)
                                const expiredBeforeMom = moment(values.expiredBefore)
                                if (expiredAfterMom.isAfter(expiredBeforeMom)) {
                                    errors.expiredAfter = " "
                                    errors.expiredBefore = "Expires Before cannot be less than Expires After"
                                } else if (expiredAfterMom.isSame(expiredBeforeMom)) {
                                    errors.expiredAfter = " "
                                    errors.expiredBefore = "Expires Before cannot equal Expires After"
                                } else if (expiredBeforeMom.diff(expiredAfterMom, "days") === 1) {
                                    errors.expiredAfter = " "
                                    errors.expiredBefore =
                                        "Expires Before must be at least two days after Expires After"
                                }
                            }
                            if (values.issuedAfter && values.issuedAfter) {
                                const issuedAfterMom = moment(values.issuedAfter)
                                const issuedBeforeMom = moment(values.issuedBefore)
                                if (issuedAfterMom.isAfter(issuedBeforeMom)) {
                                    errors.issuedAfter = " "
                                    errors.issuedBefore = "Issued Before cannot be less than Issued After"
                                } else if (issuedAfterMom.isSame(issuedBeforeMom)) {
                                    errors.issuedAfter = " "
                                    errors.issuedBefore = "Issued Before cannot equal Issued After"
                                } else if (issuedBeforeMom.diff(issuedAfterMom, "days") === 1) {
                                    errors.issuedAfter = " "
                                    errors.issuedBefore = "Issued Before must be at least two days after Issued After"
                                }
                            }
                            return errors
                        }}
                        render={formikProps => (
                            <form onSubmit={formikProps.handleSubmit}>
                                <Flex flexDirection="column" minWidth="1000px" className={classes.popOver}>
                                    <Typography className={classes.label}>Parties Involved</Typography>
                                    <div className={classes.body}>
                                        <ApplicantBeneficiarySearchFieldSet formik={formikProps} />
                                        {pendingGx && (
                                            <Grid gridGap="3un" gridTemplateColumns="1fr 3fr 3fr">
                                                <Flex alignItems="center">
                                                    <Typography className={classes.subHeading}>Issuer</Typography>
                                                </Flex>
                                                <CustomSelect
                                                    id="issuer"
                                                    label="Issuer"
                                                    value={formikProps.values.issuer ? formikProps.values.issuer : ""}
                                                    data={[
                                                        {
                                                            value: "",
                                                            text: ".."
                                                        },
                                                        ...issuers.map(issuer => ({
                                                            value: issuer.value,
                                                            text: issuer.label
                                                        }))
                                                    ]}
                                                    className={classes.issuer}
                                                    handleChange={formikProps.handleChange}
                                                />
                                                <span />
                                            </Grid>
                                        )}
                                    </div>
                                    <Typography className={classes.label}>Guarantee Details</Typography>
                                    <div className={classes.body}>
                                        <Grid gridTemplateColumns="18% 18% 18% 18%" gridColumnGap="16px">
                                            {pendingGx ? (
                                                <CustomSelect
                                                    id="requestType"
                                                    label="Request Type"
                                                    value={
                                                        formikProps.values.requestType
                                                            ? formikProps.values.requestType
                                                            : ""
                                                    }
                                                    data={[
                                                        {
                                                            value: "",
                                                            text: ".."
                                                        },
                                                        ...requestTypes.map(requestType => ({
                                                            value: requestType.value,
                                                            text: requestType.label
                                                        }))
                                                    ]}
                                                    className={classes.requestType}
                                                    handleChange={formikProps.handleChange}
                                                />
                                            ) : (
                                                <CustomSelect
                                                    id="status"
                                                    label="Status"
                                                    value={formikProps.values.status}
                                                    className={classes.status}
                                                    style={{ marginTop: 15 }}
                                                    data={[
                                                        {
                                                            value: "",
                                                            text: ".."
                                                        },
                                                        {
                                                            value: GX_STATUS.ACTIVE,
                                                            text: GX_STATUS_DISPLAY_MAP[GX_STATUS.ACTIVE]
                                                        },
                                                        {
                                                            value: GX_STATUS.CANCELLED,
                                                            text: GX_STATUS_DISPLAY_MAP[GX_STATUS.CANCELLED]
                                                        },
                                                        {
                                                            value: GX_STATUS.DEMANDED,
                                                            text: GX_STATUS_DISPLAY_MAP[GX_STATUS.DEMANDED]
                                                        },
                                                        {
                                                            value: GX_STATUS.EXPIRED,
                                                            text: GX_STATUS_DISPLAY_MAP[GX_STATUS.EXPIRED]
                                                        },
                                                        {
                                                            value: GX_STATUS.PAYWALKED,
                                                            text: GX_STATUS_DISPLAY_MAP[GX_STATUS.PAYWALKED]
                                                        },
                                                        {
                                                            value: GX_STATUS.TRANSFERRED,
                                                            text: GX_STATUS_DISPLAY_MAP[GX_STATUS.TRANSFERRED]
                                                        }
                                                    ]}
                                                    handleChange={formikProps.handleChange}
                                                />
                                            )}
                                            <CustomAmountField
                                                id="amountGreaterThan"
                                                label="Amount Greater Than"
                                                value={formikProps.values.amountGreaterThan}
                                                type="number"
                                                handleChange={formikProps.setFieldValue}
                                                error={formikProps.errors.amountGreaterThan}
                                            />
                                            <CustomAmountField
                                                id="amountSmallerThan"
                                                label="Amount Less Than"
                                                value={formikProps.values.amountSmallerThan}
                                                type="number"
                                                handleChange={formikProps.setFieldValue}
                                                error={formikProps.errors.amountSmallerThan}
                                            />
                                        </Grid>
                                        {!pendingGx ? (
                                            <React.Fragment>
                                                <Grid gridColumnGap="16px" gridTemplateColumns="20% 20% 20% 20%">
                                                    <CustomDatePicker
                                                        id="expiredAfter"
                                                        label="Expires After"
                                                        value={formikProps.values.expiredAfter}
                                                        type="date"
                                                        handleChange={formikProps.setFieldValue}
                                                        InputLabelProps={{ shrink: true }}
                                                        error={formikProps.errors.expiredAfter}
                                                        disabled={formikProps.values.openEndedOnly}
                                                    />
                                                    <CustomDatePicker
                                                        id="expiredBefore"
                                                        label="Expires Before"
                                                        value={formikProps.values.expiredBefore}
                                                        type="date"
                                                        handleChange={formikProps.setFieldValue}
                                                        InputLabelProps={{ shrink: true }}
                                                        error={formikProps.errors.expiredBefore}
                                                        disabled={formikProps.values.openEndedOnly}
                                                    />
                                                    <CustomDatePicker
                                                        id="issuedAfter"
                                                        label="Issued After"
                                                        value={formikProps.values.issuedAfter}
                                                        type="date"
                                                        handleChange={formikProps.setFieldValue}
                                                        InputLabelProps={{ shrink: true }}
                                                        error={formikProps.errors.issuedAfter}
                                                    />
                                                    <CustomDatePicker
                                                        id="issuedBefore"
                                                        label="Issued Before"
                                                        value={formikProps.values.issuedBefore}
                                                        type="date"
                                                        handleChange={formikProps.setFieldValue}
                                                        InputLabelProps={{ shrink: true }}
                                                        error={formikProps.errors.issuedBefore}
                                                    />
                                                </Grid>
                                                <FormControl css="margin-bottom: 10px;">
                                                    <FormControlLabel
                                                        control={
                                                            <Checkbox
                                                                checked={formikProps.values.openEndedOnly}
                                                                onChange={e => {
                                                                    const { checked } = e.target
                                                                    formikProps.setFieldValue("openEndedOnly", checked)
                                                                }}
                                                                value="OpenEnded"
                                                                name="openEndedOnly"
                                                            />
                                                        }
                                                        label="Open Ended Guarantees Only"
                                                    />
                                                </FormControl>
                                            </React.Fragment>
                                        ) : (
                                            <Grid
                                                gridColumnGap="16px"
                                                gridTemplateColumns="20% 20%"
                                                css="margin-bottom: 10px;"
                                            >
                                                <CustomDatePicker
                                                    id="issuedAfter"
                                                    label="Issued After"
                                                    value={formikProps.values.issuedAfter}
                                                    type="date"
                                                    handleChange={formikProps.setFieldValue}
                                                    InputLabelProps={{ shrink: true }}
                                                    error={formikProps.errors.issuedAfter}
                                                />
                                                <CustomDatePicker
                                                    id="issuedBefore"
                                                    label="Issued Before"
                                                    value={formikProps.values.issuedBefore}
                                                    type="date"
                                                    handleChange={formikProps.setFieldValue}
                                                    InputLabelProps={{ shrink: true }}
                                                    error={formikProps.errors.issuedBefore}
                                                />
                                            </Grid>
                                        )}
                                    </div>
                                    <PurposeFieldSet
                                        formik={formikProps}
                                        fields={getCurrentTemplate({
                                            purposeTemplates,
                                            selectedTemplate: formikProps.values.purposeType
                                        })}
                                        purposeTemplates={purposeTemplates}
                                        noRequire
                                        isFilter
                                        hideTemplateTitles={false}
                                        hideTemplateFields={pendingGx}
                                        // gridSizing={field => ({
                                        //     xs: convertNumber(field.appearance.width),
                                        //     sm: convertNumber(field.appearance.width),
                                        //     md: convertNumber(field.appearance.width),
                                        //     lg: convertNumber(field.appearance.width),
                                        //     xl: convertNumber(field.appearance.width)
                                        // })}
                                    />
                                    <Flex justifyContent="flex-end">
                                        <Button className={classes.button} onClick={handleClose} css="margin-right:8px">
                                            CANCEL
                                        </Button>
                                        <Button className={classes.button} type="submit">
                                            SUBMIT
                                        </Button>
                                    </Flex>
                                </Flex>
                            </form>
                        )}
                    />
                </DialogContent>
            </Dialog>
        )
    }
}

export default withTheme()(BGFilterPopover)
