// @flow
// Flow for lazy and suspense for some reason doesn't exist -.-, once fixed un-comment flowfixme
// $FlowFixMe
import React, { Suspense, lazy } from "react"
import { Route, Redirect, Switch } from "react-router-dom"

import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import type { Gx } from "~/util/flow_types"
import { gxParse } from "~/util/logic/gx"
import api from "~/util/api"
import { Block, Flex } from "~/shared/layout"
import SidebarView from "~/shared/Sidebar/SidebarView"
import FilterProviderContainer from "~/shared/Context/Filter/FilterProviderContainer"
import PortalRoute from "~/shared/Router/PortalRoute"
import DataCacheProvider from "~/shared/Context/DataCache/DataCacheProvider"
import DataCacheContext from "~/shared/Context/DataCache/DataCacheContext"
import NotificationSocketClient from "~/util/api/base/notificationClient"
import { authStorage } from "~/util/auth"
import Loading from "~/shared/Loading"
import CardErrorBoundary from "~/shared/CardErrorBoundary"

// for debugging - please leave in uncommented code. using this when lazy loading chucks a fit.
// import BGDetailsContainer from "./BGDetailsContainer/BGDetailsContainer"
// import BGPendingListContainer from "./BGPendingListContainer/BGPendingListContainer"
// import BGListContainer from "./BGListContainer/BGListContainer"
// import BGRequestListContainer from "./BGRequestListContainer/BGRequestListContainer"
// import ApprovalFlowContainer from "./SettingsContainer/ApprovalFlowContainer/ApprovalFlowContainer"
// import SettingsContainer from "./SettingsContainer/SettingsContainer"
// import NotificationContainer from "./NotificationContainer/NotificationContainer"

// import withNotification from "./NotificationPopUps/NotificationPopUps"

const StartReferOnboardingContainer = lazy(() =>
    import("./StartReferOnboardingContainer/StartReferOnboardingContainer")
)
const TermsConditionsContainer = lazy(() => import("./SettingsContainer/TermsConditions/TermsConditionsContainer"))
const BGListContainer = lazy(() => import("./BGListContainer/BGListContainer"))
const OrganizationDetailsContainer = lazy(() => import("./OrganizationDetailsContainer/OrganizationDetailsContainer"))

const BGRequestListContainer = lazy(() => import("./BGRequestListContainer/BGRequestListContainer"))

const BGPendingListContainer = lazy(() => import("./BGPendingListContainer/BGPendingListContainer"))

const HeaderContainer = lazy(() => import("./HeaderContainer/HeaderContainer"))
const NewRequestScreen = lazy(() => import("./NewRequestScreen/NewRequestScreen"))
const OrganizationsListScreenContainer = lazy(() =>
    import("./OrganizationsListScreenContainer/OrganizationsListScreenContainer")
)
const NotificationContainer = lazy(() => import("./NotificationContainer/NotificationContainer"))

const OnboardingListContainer = lazy(() => import("./OnboardingListContainer/OnboardingListContainer"))
const OnboardingReviewContainer = lazy(() => import("./OnboardingReviewContainer/OnboardingReviewContainer"))
const SubmissionContainer = lazy(() => import("./OnboardingReviewContainer/SubmissionContainer"))

const SettingsContainer = lazy(() => import("./SettingsContainer/SettingsContainer"))
const ApiKeyContainer = lazy(() => import("./SettingsContainer/ApiKeyContainer/ApiKeyContainer"))
const UsersContainer = lazy(() => import("./SettingsContainer/UsersContainer/UsersContainer"))

const TwoFactorContainer = lazy(() => import("./SettingsContainer/TwoFactorContainer/TwoFactorContainer"))

const CompanyDetailsContainer = lazy(() =>
    import("./SettingsContainer/CompanyDetailsContainer/CompanyDetailsContainer")
)
const AdministratorDetailsContainer = lazy(() =>
    import("./SettingsContainer/AdministratorDetailsContainer/AdministratorDetailsContainer")
)
const ApprovalFlowContainer = lazy(() => import("./SettingsContainer/ApprovalFlowContainer/ApprovalFlowContainer"))
const CredentialsContainer = lazy(() =>
    import("./SettingsContainer/CredentialsDetailsContainer/CredentialDetailsContainer")
)

const GuaranteeFormContainer = lazy(() => import("./GuaranteeFormContainer/GuaranteeFormContainer"))

const TransferFormContainer = lazy(() => import("./GuaranteeFormContainer/TransferFormContainer"))

const AmendFormContainer = lazy(() => import("./GuaranteeFormContainer/AmendFormContainer"))

const AmendPrefillFormContainer = lazy(() => import("./GuaranteeFormContainer/AmendPrefillFormContainer"))

const TransferPrefillFormContainer = lazy(() => import("./GuaranteeFormContainer/TransferPrefillFormContainer"))
const GuaranteePrefillFormContainer = lazy(() => import("./GuaranteeFormContainer/GuaranteePrefillFormContainer"))

const BGDetailsContainer = lazy(() => import("./BGDetailsContainer/BGDetailsContainer"))

const getClasses = ({ theme }) => {
    const content = css({
        backgroundColor: theme.palette.common.backgroundGrey,
        overflow: "auto"
    })
    const header = css({
        gridArea: "header"
    })
    const main = css({
        gridArea: "main"
    })
    const sidebar = css({
        gridArea: "sidebar"
    })

    const title = css({
        color: theme.palette.common.lightGrey,
        fontSize: "1.5em",
        marginBottom: theme.spacing.unit * 2,
        display: "inline"
    })
    return {
        content,
        header,
        main,
        title,
        sidebar
    }
}

type Props = {
    history: Object,
    match: Object,
    location: Object,
    theme: Object,
    addNotification: Function
}

type State = {
    // lastRemovedNotifications: Array<Notification>,
    user: Object,
    gxList: Array<Gx>,
    loading: boolean,
    notifications: Array<Object>,
    needsAction: Array<Object>,
    needsActionCount: number,
    notificationsCount: number,
    notificationsLoading: boolean
}

class HomeContainer extends React.Component<Props, State> {
    state = {
        // lastRemovedNotifications: [],
        user: {},
        gxList: [],
        loading: false,
        notifications: [],
        needsAction: [],
        needsActionCount: 0,
        notificationsCount: 0,
        notificationsLoading: true
    }

    componentDidMount() {
        if (authStorage.hasTokenSet()) {
            console.log("Found API token, connecting web socket...")
            const notificationClient = new NotificationSocketClient(message => {
                // this.props.addNotification()
                if (message.actionRequired) {
                    this.setState(prevState => ({
                        needsAction: [message, ...prevState.needsAction],
                        needsActionCount: prevState.needsActionCount + 1
                    }))
                } else {
                    this.setState(prevState => ({
                        notifications: [message, ...prevState.notifications],
                        notificationsCount: prevState.notificationsCount + 1
                    }))
                }
            })
            notificationClient.connect()
        }
        this.getNotificationsWithCount()
    }

    onNotifications = (event: Event): void => {
        this.props.history.push("/updates", { notifications: true })
    }
    getNotifications = (queryString: string = "", actioned: boolean = false) => {
        this.setState({ notificationsLoading: true })
        api.notifications
            .getNotifications(queryString)
            .then(({ data }) => {
                const notifications = data.result.filter(item => item.actionRequired === false || !item.actionRequired)

                const needsAction = actioned
                    ? data.result.filter(item => item.actionRequired && item.actionDone)
                    : data.result.filter(item => item.actionRequired && !item.actionDone)
                this.setState({
                    notifications: notifications.reverse(),
                    needsAction: needsAction.reverse(),
                    notificationsLoading: false
                })
            })
            .catch(err => {
                console.log(err)
                this.setState({ notificationsLoading: false })
            })
    }
    getNotificationsWithCount = () => {
        this.setState({ notificationsLoading: true })

        api.notifications
            .getNotifications()
            .then(({ data }) => {
                const notifications = data.result.filter(
                    item => item.status !== "READ" && item.status !== "DISMISSED" && !item.actionRequired
                )
                const needsAction = data.result.filter(item => item.actionRequired && !item.actionDone)

                this.setState({
                    notifications: notifications.reverse(),
                    needsAction: needsAction.reverse(),
                    needsActionCount: needsAction.length,
                    notificationsCount: notifications.length,
                    notificationsLoading: false
                })
            })
            .catch(err => {
                console.log(err)
                this.setState({ notificationsLoading: false })
            })
    }

    getGxList = (): Promise<void> => {
        this.setState({ loading: true })
        return api.gx
            .getGxList({ userId: this.state.user.id })
            .then(json => {
                this.setState({
                    loading: false,
                    gxList: json.map(gx => gxParse(gx))
                })
            })
            .catch(err => this.setState({ loading: false }, console.log(err)))
    }
    updateCount = (needsAction: boolean, count: number) => {
        if (needsAction) {
            if (this.state.needsActionCount !== count) {
                this.setState({ needsActionCount: count })
            }
        } else if (this.state.notificationsCount !== count) {
            this.setState({ notificationsCount: count })
        }
    }
    dismissNotification = (notification: Object, updateSidebar: boolean) => {
        const { notifications } = this.state
        const index = notifications.findIndex(row => row.id === notification.id)
        if (index > -1) {
            notifications.splice(index, 1)
        }
        this.setState(prevState => ({
            notificationsCount: updateSidebar ? prevState.notificationsCount - 1 : prevState.notificationsCount,
            notifications
        }))
    }

    previousScreen = () => {
        if (this.props.history.action === "PUSH") {
            this.props.history.goBack()
        } else {
            this.props.history.push("/")
        }
    }
    render() {
        const { theme } = this.props
        const { notifications, needsAction, needsActionCount, notificationsCount, notificationsLoading } = this.state
        const classes = getClasses({ theme })
        return (
            <React.Fragment>
                <DataCacheProvider>
                    <DataCacheContext.Consumer>
                        {currentUser => (
                            <HeaderContainer
                                className={classes.header}
                                history={this.props.history}
                                match={this.props.match}
                                location={this.props.location}
                                user={currentUser}
                                onNotifications={this.onNotifications}
                                onSearchChange={() => console.log("No search")}
                                onSearchSubmit={(value: string): void => {
                                    this.getGxList()
                                }}
                                entityName={currentUser.entityName}
                                userEmail={currentUser.email}
                                userName={`${currentUser.firstName} ${currentUser.lastName}`}
                            />
                        )}
                    </DataCacheContext.Consumer>
                    <Block className={classes.content}>
                        <FilterProviderContainer>
                            <Switch>
                                <Route
                                    exact
                                    path="/"
                                    render={props => (
                                        <Redirect
                                            to={{
                                                pathname: PORTAL_TYPE === "admin" ? "/organisations" : "/gx",
                                                state: { from: props.location }
                                            }}
                                        />
                                    )}
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/gx"
                                    render={props => (
                                        <DataCacheContext.Consumer>
                                            {userInfo => (
                                                <SidebarView
                                                    notificationsCount={notificationsCount}
                                                    needsActionCount={needsActionCount}
                                                    updateSettings={userInfo.updateSettings}
                                                    {...props}
                                                >
                                                    {waitForChild(
                                                        <CardErrorBoundary message="Error retrieving Guarantees">
                                                            <BGListContainer
                                                                className={classes.main}
                                                                history={this.props.history}
                                                                match={this.props.match}
                                                                location={this.props.location}
                                                                user={userInfo}
                                                            />
                                                        </CardErrorBoundary>
                                                    )}
                                                </SidebarView>
                                            )}
                                        </DataCacheContext.Consumer>
                                    )}
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/guarantee-requests"
                                    render={props => (
                                        <DataCacheContext.Consumer>
                                            {userInfo => (
                                                <SidebarView
                                                    notificationsCount={notificationsCount}
                                                    needsActionCount={needsActionCount}
                                                    updateSettings={userInfo.updateSettings}
                                                    {...props}
                                                >
                                                    {waitForChild(
                                                        <CardErrorBoundary message="Error retrieving guarantee requests">
                                                            <BGRequestListContainer
                                                                className={classes.main}
                                                                history={this.props.history}
                                                                match={this.props.match}
                                                                currentOrgId={userInfo.currentOrgId}
                                                                user={userInfo}
                                                            />
                                                        </CardErrorBoundary>
                                                    )}
                                                </SidebarView>
                                            )}
                                        </DataCacheContext.Consumer>
                                    )}
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/pending-gx"
                                    render={props => (
                                        <DataCacheContext.Consumer>
                                            {userInfo => (
                                                <SidebarView
                                                    notificationsCount={notificationsCount}
                                                    needsActionCount={needsActionCount}
                                                    updateSettings={userInfo.updateSettings}
                                                    {...props}
                                                >
                                                    {waitForChild(
                                                        <CardErrorBoundary message="Error retrieving pending requests">
                                                            <BGPendingListContainer
                                                                className={classes.main}
                                                                history={this.props.history}
                                                                match={this.props.match}
                                                                currentOrgId={userInfo.currentOrgId}
                                                                user={userInfo}
                                                            />
                                                        </CardErrorBoundary>
                                                    )}
                                                </SidebarView>
                                            )}
                                        </DataCacheContext.Consumer>
                                    )}
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/gx/guarantee-requests/:requestID"
                                    render={props =>
                                        waitForChild(
                                            <DataCacheContext.Consumer>
                                                {userContext => (
                                                    <CardErrorBoundary message="Error retrieving guarantee request details">
                                                        <BGDetailsContainer
                                                            {...props}
                                                            className={classes.main}
                                                            userContext={userContext}
                                                            hasGuarantee={false}
                                                            approvalModel={
                                                                userContext.actingOnBehalf
                                                                    ? userContext.actingOnBehalf.approvalModel
                                                                    : userContext.approvalModel
                                                            }
                                                            currentOrgId={
                                                                userContext.actingOnBehalf
                                                                    ? userContext.actingOnBehalf.id
                                                                    : userContext.primaryOrgId
                                                            }
                                                        />
                                                    </CardErrorBoundary>
                                                )}
                                            </DataCacheContext.Consumer>
                                        )
                                    }
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/gx/details/:gxId"
                                    render={props =>
                                        waitForChild(
                                            <DataCacheContext.Consumer>
                                                {userContext => (
                                                    <CardErrorBoundary message="Error retrieving guarantee details">
                                                        <BGDetailsContainer
                                                            {...props}
                                                            user={userContext}
                                                            className={classes.main}
                                                            userContext={userContext}
                                                            hasGuarantee
                                                            approvalModel={
                                                                userContext.actingOnBehalf
                                                                    ? userContext.actingOnBehalf.approvalModel
                                                                    : userContext.approvalModel
                                                            }
                                                            currentOrgId={
                                                                userContext.actingOnBehalf
                                                                    ? userContext.actingOnBehalf.id
                                                                    : userContext.primaryOrgId
                                                            }
                                                        />
                                                    </CardErrorBoundary>
                                                )}
                                            </DataCacheContext.Consumer>
                                        )
                                    }
                                />
                                <Route
                                    exact
                                    path="/organisations"
                                    render={props => (
                                        <SidebarView
                                            notificationsCount={notificationsCount}
                                            needsActionCount={needsActionCount}
                                            {...props}
                                        >
                                            {waitForChild(
                                                <CardErrorBoundary message="Error retrieving organisations">
                                                    <OrganizationsListScreenContainer
                                                        {...props}
                                                        location={this.props.location}
                                                        className={classes.main}
                                                        history={this.props.history}
                                                        match={this.props.match}
                                                        user={this.state.user}
                                                        list={this.state.gxList}
                                                        loading={this.state.loading}
                                                    />
                                                </CardErrorBoundary>
                                            )}
                                        </SidebarView>
                                    )}
                                />
                                <Route
                                    exact
                                    path="/settings"
                                    render={props =>
                                        waitForChild(
                                            <DataCacheContext.Consumer>
                                                {currentUserInformation => (
                                                    <SettingsContainer
                                                        currentUserInformation={currentUserInformation}
                                                        user={this.state.user}
                                                        {...props}
                                                    />
                                                )}
                                            </DataCacheContext.Consumer>
                                        )
                                    }
                                />
                                <Route
                                    exact
                                    path="/settings/usermanagement"
                                    render={props =>
                                        waitForChild(
                                            <DataCacheContext.Consumer>
                                                {currentUserInformation => (
                                                    <UsersContainer
                                                        user={this.state.user}
                                                        currentUserInformation={currentUserInformation}
                                                        {...props}
                                                    />
                                                )}
                                            </DataCacheContext.Consumer>
                                        )
                                    }
                                />

                                <Route
                                    exact
                                    path="/settings/apikey"
                                    render={props => waitForChild(<ApiKeyContainer {...props} />)}
                                />
                                <Route
                                    exact
                                    path="/settings/organisationdetails"
                                    render={props =>
                                        waitForChild(
                                            <DataCacheContext.Consumer>
                                                {currentUserInformation => (
                                                    <CardErrorBoundary message="Error retrieving organisation and primary user information">
                                                        <CompanyDetailsContainer
                                                            user={currentUserInformation}
                                                            {...props}
                                                        />
                                                    </CardErrorBoundary>
                                                )}
                                            </DataCacheContext.Consumer>
                                        )
                                    }
                                />
                                <Route
                                    exact
                                    path="/settings/credentials"
                                    render={props => waitForChild(<CredentialsContainer {...props} />)}
                                />

                                <Route
                                    exact
                                    path="/settings/platformUserTC"
                                    render={props =>
                                        waitForChild(
                                            <TermsConditionsContainer
                                                type="PLATFORM"
                                                title="Platform User Terms"
                                                {...props}
                                            />
                                        )
                                    }
                                />
                                <Route
                                    exact
                                    path="/settings/platformParticipantRules"
                                    render={props =>
                                        waitForChild(
                                            <TermsConditionsContainer
                                                type="PLATFORM"
                                                title="Platform Participant Rules"
                                                {...props}
                                            />
                                        )
                                    }
                                />
                                <Route
                                    exact
                                    path="/settings/bgdeed"
                                    render={props =>
                                        waitForChild(
                                            <TermsConditionsContainer
                                                type="PLATFORM"
                                                title="Form of Bank Guarantee Deed"
                                                {...props}
                                            />
                                        )
                                    }
                                />
                                <Route
                                    exact
                                    path="/settings/administrator"
                                    render={props => waitForChild(<AdministratorDetailsContainer {...props} />)}
                                />
                                <Route
                                    exact
                                    path="/settings/approvalflow"
                                    render={props =>
                                        waitForChild(
                                            <DataCacheContext.Consumer>
                                                {values => (
                                                    <CardErrorBoundary message="Error retrieving approval model">
                                                        <ApprovalFlowContainer
                                                            approvalModel={values.approvalModel}
                                                            {...props}
                                                        />
                                                    </CardErrorBoundary>
                                                )}
                                            </DataCacheContext.Consumer>
                                        )
                                    }
                                />
                                <Route
                                    exact
                                    path="/settings/twofactor"
                                    render={props => waitForChild(<TwoFactorContainer {...props} />)}
                                />
                                <Route
                                    exact
                                    path="/notifications"
                                    render={props => (
                                        <DataCacheContext.Consumer>
                                            {userInfo => (
                                                <SidebarView
                                                    notificationsCount={notificationsCount}
                                                    needsActionCount={needsActionCount}
                                                    updateSettings={userInfo.updateSettings}
                                                    {...props}
                                                >
                                                    {waitForChild(
                                                        <CardErrorBoundary message="Error retrieving notifications">
                                                            <NotificationContainer
                                                                title="Notifications"
                                                                ariaLabel="Notifications Screen"
                                                                getNotificationsWithCount={
                                                                    this.getNotificationsWithCount
                                                                }
                                                                notifications={notifications}
                                                                getNotifications={this.getNotifications}
                                                                dismissNotification={this.dismissNotification}
                                                                notificationsLoading={notificationsLoading}
                                                                currentOrgId={userInfo.primaryOrgId}
                                                                impersonnatingSub={!!userInfo.actingOnBehalf}
                                                                updateCount={this.updateCount}
                                                                user={userInfo}
                                                                {...props}
                                                            />
                                                        </CardErrorBoundary>
                                                    )}
                                                </SidebarView>
                                            )}
                                        </DataCacheContext.Consumer>
                                    )}
                                />
                                <Route
                                    exact
                                    path="/needsaction"
                                    render={props => (
                                        <DataCacheContext.Consumer>
                                            {userInfo => (
                                                <SidebarView
                                                    notificationsCount={notificationsCount}
                                                    needsActionCount={needsActionCount}
                                                    updateSettings={userInfo.updateSettings}
                                                    {...props}
                                                >
                                                    {waitForChild(
                                                        <CardErrorBoundary message="Error retrieving needs action notifications">
                                                            <NotificationContainer
                                                                needsAction
                                                                title="Needs Action"
                                                                getNotificationsWithCount={
                                                                    this.getNotificationsWithCount
                                                                }
                                                                ariaLabel="Needs Action Screen"
                                                                getNotifications={this.getNotifications}
                                                                notifications={needsAction}
                                                                dismissNotification={() => console.log("")}
                                                                notificationsLoading={notificationsLoading}
                                                                impersonnatingSub={!!userInfo.actingOnBehalf}
                                                                currentOrgId={userInfo.primaryOrgId}
                                                                updateCount={this.updateCount}
                                                                user={userInfo}
                                                                {...props}
                                                            />
                                                        </CardErrorBoundary>
                                                    )}
                                                </SidebarView>
                                            )}
                                        </DataCacheContext.Consumer>
                                    )}
                                />
                                <Route
                                    exact
                                    path="/OnboardingList"
                                    render={props => (
                                        <SidebarView
                                            notificationsCount={notificationsCount}
                                            needsActionCount={needsActionCount}
                                            {...props}
                                        >
                                            {waitForChild(
                                                <CardErrorBoundary message="Error retrieving onboarding list">
                                                    <OnboardingListContainer
                                                        {...props}
                                                        location={props.location}
                                                        className={classes.main}
                                                    />
                                                </CardErrorBoundary>
                                            )}
                                        </SidebarView>
                                    )}
                                />
                                <Route
                                    exact
                                    path="/OnboardingList/:requestID"
                                    render={props => waitForChild(<OnboardingReviewContainer {...props} />)}
                                />
                                <Route
                                    exact
                                    path="/OnboardingSubmission/:requestID"
                                    render={props => waitForChild(<SubmissionContainer theme={theme} {...props} />)}
                                />
                                <Route
                                    exact
                                    path="/organisations/:orgID"
                                    render={props =>
                                        waitForChild(<OrganizationDetailsContainer theme={theme} {...props} />)
                                    }
                                />
                                <PortalRoute
                                    exact
                                    path="/new"
                                    portalType={["user", "issuer"]}
                                    portalOrg={["newco"]}
                                    render={props =>
                                        waitForChild(
                                            <DataCacheContext.Consumer>
                                                {values => (
                                                    <NewRequestScreen
                                                        {...props}
                                                        match={this.props.match}
                                                        className={classes.main}
                                                        approvalModel={
                                                            values.actingOnBehalf
                                                                ? values.actingOnBehalf.approvalModel
                                                                : values.approvalModel
                                                        }
                                                        currentOrgId={values.currentOrgId}
                                                        userRoles={values.userRoles}
                                                    />
                                                )}
                                            </DataCacheContext.Consumer>
                                        )
                                    }
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/onboard"
                                    render={props =>
                                        waitForChild(
                                            <StartReferOnboardingContainer
                                                previousPage={() => this.previousScreen()}
                                                // previousPage={() => this.props.history.goback}
                                                {...props}
                                            />
                                        )
                                    }
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/gx/New"
                                    render={props =>
                                        waitForChild(
                                            <DataCacheContext.Consumer>
                                                {currentUser => (
                                                    <CardErrorBoundary message="Error in new guarantee form">
                                                        <GuaranteeFormContainer
                                                            previousPage={() => this.previousScreen()}
                                                            // previousPage={() => this.props.history.goback}
                                                            {...props}
                                                            user={currentUser}
                                                        />
                                                    </CardErrorBoundary>
                                                )}
                                            </DataCacheContext.Consumer>
                                        )
                                    }
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/gx/Transfer/:gxId"
                                    render={props =>
                                        waitForChild(
                                            <CardErrorBoundary message="Error in transfer guarantee form">
                                                <TransferFormContainer
                                                    previousPage={() => this.previousScreen()}
                                                    // previousPage={() => this.props.history.goback}
                                                    {...props}
                                                />
                                            </CardErrorBoundary>
                                        )
                                    }
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/gx/Amend/:gxId"
                                    render={props =>
                                        waitForChild(
                                            <CardErrorBoundary message="Error in amend guarantee form">
                                                <AmendFormContainer
                                                    previousPage={() => this.previousScreen()}
                                                    // previousPage={() => this.props.history.goback}
                                                    {...props}
                                                />
                                            </CardErrorBoundary>
                                        )
                                    }
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/gx/New/:id/prefill"
                                    render={props =>
                                        waitForChild(
                                            <DataCacheContext.Consumer>
                                                {currentUserInformation => (
                                                    <CardErrorBoundary message="Error in new guarantee form">
                                                        <GuaranteePrefillFormContainer
                                                            previousPage={() => this.previousScreen()}
                                                            // previousPage={() => this.props.history.goback}
                                                            currentUserInformation={currentUserInformation}
                                                            {...props}
                                                        />
                                                    </CardErrorBoundary>
                                                )}
                                            </DataCacheContext.Consumer>
                                        )
                                    }
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/gx/Amend/:gxId/prefill"
                                    render={props =>
                                        waitForChild(
                                            <CardErrorBoundary message="Error in amend guarantee form">
                                                <AmendPrefillFormContainer
                                                    previousPage={() => this.previousScreen()}
                                                    // previousPage={() => this.props.history.goback}
                                                    {...props}
                                                />
                                            </CardErrorBoundary>
                                        )
                                    }
                                />
                                <PortalRoute
                                    portalType={["user", "issuer"]}
                                    portalOrg="newco"
                                    exact
                                    path="/gx/Transfer/:gxId/prefill"
                                    render={props =>
                                        waitForChild(
                                            <CardErrorBoundary message="Error in transfer guarantee form">
                                                <TransferPrefillFormContainer
                                                    previousPage={() => this.previousScreen()}
                                                    // previousPage={() => this.props.history.goback}
                                                    {...props}
                                                />
                                            </CardErrorBoundary>
                                        )
                                    }
                                />
                            </Switch>
                        </FilterProviderContainer>
                    </Block>
                </DataCacheProvider>
            </React.Fragment>
        )
    }
}

function waitForChild(children) {
    return (
        <Suspense
            fallback={
                <Flex justifyContent="center" alignItems="center">
                    <Loading show />
                </Flex>
            }
        >
            {children}
        </Suspense>
    )
}

// export default withNotification(withTheme()(HomeContainer))
export default withTheme()(HomeContainer)
