// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Typography from "@material-ui/core/Typography"
import AppBar from "@material-ui/core/AppBar"
import Toolbar from "@material-ui/core/Toolbar"
import Menu from "@material-ui/core/Menu"
import MenuItem from "@material-ui/core/MenuItem"
import Button from "@material-ui/core/Button"
import Tooltip from "@material-ui/core/Tooltip"
import AddIcon from "@material-ui/icons/Add"
import DownIcon from "@material-ui/icons/KeyboardArrowDown"
// import AssignmentIcon from "@material-ui/icons/AssignmentTurnedIn"
import IconButton from "@material-ui/core/IconButton"
import { Link } from "react-router-dom"
import { Block, Flex } from "~/shared/layout"
import importPortalAsset from "~/util/importPortalAsset"
// import NotificationTest from "../NotificationPopUps/NotificationPopUps"

const imgFilePath = importPortalAsset("images/logo.png")

const getClasses = ({ theme }) => {
    const appBar = css({
        background: theme.palette.primary.headerMain,
        borderBottom: "4px solid",
        borderColor: theme.palette.primary.headerBottom
    })
    const title = css(theme.typography.logoSubheading, {
        display: "block",
        textDecoration: "none !important"
    })

    const menu = css({
        boxSizing: "content-box"
    })
    const menuButton = css(menu, {
        margin: `0 ${theme.spacing.unit * 3}px 0 0`,
        textTransform: "none",
        color: theme.palette.primary.contrastText
    })
    const menuNavigation = css(menu, {
        textTransform: "none",
        fontSize: "1em",
        color: theme.palette.common.darkBlue,
        "&:focus": {
            backgroundColor: theme.palette.primary.headerBottom
        }
    })
    const menuItemCursor = css(menu, {
        cursor: "pointer",
        color: theme.palette.common.darkBlue,
        paddingTop: "6px",
        paddingBottom: "6px",
        paddingLeft: "10px",
        "&:hover": {
            backgroundColor: theme.palette.common.buttonHover
        }
    })
    const textColor = css({
        color: theme.palette.primary.contrastText
    })
    const logoContainer = css({
        display: "flex",
        alignItems: "center"
    })
    const logo = css({
        width: theme.overrides.imgWidth,
        marginRight: "12px"
    })
    const logoText = css(textColor, {
        display: "inline-block",
        fontWeight: 500,
        color: theme.palette.primary.contrastText,
        marginLeft: theme.spacing.unit * 1,
        marginTop: theme.spacing.unit * 1,
        fontSize: "22px",
        lineHeight: "1em"
    })
    const skipText = css(textColor, {
        border: "none",
        backgroundColor: "transparent",
        "&:not(:focus):not(:active)": {
            position: "absolute",
            width: "1px",
            height: "1px",
            margin: "-1px",
            border: "0",
            padding: "0",
            whiteSpace: "nowrap",
            clipPath: "inset(100%)",
            clip: "rect(0 0 0 0)",
            overflow: "hidden"
        }
    })

    return {
        appBar,
        title,
        menuButton,
        menuItemCursor,
        textColor,
        menuNavigation,
        logo,
        logoText,
        skipText,
        logoContainer
    }
}

type Props = {
    pathname: string,
    newUrl: Function,
    user: Object,
    openUserMenu: Function,
    menuOpened: boolean,
    anchorEl: any,
    closeUserMenu: Function,
    // onSearchChange: Function,
    // onSearchSubmit: Function,
    onNotifications: Function,
    logout: Function,
    onboard: Function,
    settings: Function,
    // guarantees: Function,
    organisations: Function,
    theme: Object,
    // userEmail: string,
    userName: string,
    onboarding: boolean,
    entityName: string
}

const Header = ({
    newUrl,
    openUserMenu,
    menuOpened,
    anchorEl,
    closeUserMenu,
    onNotifications,
    logout,
    onboard,
    settings,
    organisations,
    theme,
    userName,
    onboarding,
    entityName,
    pathname,
    user
}: Props) => {
    const classes = getClasses({ theme })
    return (
        <AppBar position="static" className={`${classes.appBar}`}>
            <Toolbar>
                <Block flex="1">
                    <Flex>
                        <button
                            onClick={() => {
                                // $FlowFixMe
                                document.getElementById("main-content").focus()
                                // document.getElementById("main-content").scrollIntoView()
                            }}
                            className={classes.skipText}
                        >
                            Skip to main content
                        </button>
                        <Link to="/" style={{ textDecoration: "none" }}>
                            <div className={classes.logoContainer}>
                                <img src={imgFilePath} className={classes.logo} alt={`Main Logo for ${entityName}`} />
                                <Typography className={classes.logoText}>
                                    {onboarding ? "Lygon User Portal" : entityName}
                                </Typography>
                            </div>
                        </Link>
                    </Flex>
                </Block>
                {/* <NotificationTest theme={theme} /> */}

                {!onboarding && (
                    <React.Fragment>
                        {PORTAL_TYPE !== "admin" && (
                            <Tooltip title="New Request" disableFocusListener>
                                <IconButton aria-label="Link to Create a New Request Page" onClick={newUrl}>
                                    <AddIcon className={classes.textColor} />
                                </IconButton>
                            </Tooltip>
                        )}
                        <Tooltip title="User Menu" disableFocusListener>
                            <Button
                                onClick={openUserMenu}
                                className={classes.menuButton}
                                aria-owns={anchorEl ? "user-menu" : undefined}
                                aria-haspopup="true"
                                aria-label={`User Menu for ${userName}. Hit Enter key to open menu. Use up and down arrow keys to navigate. Hit the escape or tab key to exit`}
                            >
                                {userName}
                                <DownIcon />
                            </Button>
                        </Tooltip>
                        <Menu
                            id="user-menu"
                            open={menuOpened}
                            anchorEl={anchorEl}
                            anchorOrigin={{
                                horizontal: "left",
                                vertical: "bottom"
                            }}
                            onClose={closeUserMenu}
                        >
                            <MenuItem
                                className={classes.menuItemCursor}
                                onClick={organisations}
                                aria-label="Link to Organisations Screen"
                            >
                                Organisations
                            </MenuItem>
                            {/* <Divider /> */}
                            {PORTAL_TYPE !== "admin" && (
                                <MenuItem
                                    className={classes.menuItemCursor}
                                    onClick={onboard}
                                    aria-label="Link to Create New Onboarding Screen"
                                >
                                    New Onboarding
                                </MenuItem>
                            )}
                            {/* {PORTAL_TYPE !== "admin" && <Divider />} */}

                            <MenuItem
                                className={classes.menuItemCursor}
                                onClick={settings}
                                aria-label="Link to Settings Screen"
                            >
                                Settings
                            </MenuItem>
                            {/* <Divider /> */}
                            <MenuItem className={classes.menuItemCursor} onClick={logout} aria-label="Log Out">
                                Log out
                            </MenuItem>
                        </Menu>
                    </React.Fragment>
                )}
            </Toolbar>
        </AppBar>
    )
}

Header.defaultProps = {
    entityName: "Lygon User Portal"
}

export default withTheme()(Header)
