// @flow

import React from "react"
import api from "~/util/api"
import type { User } from "~/util/flow_types"
import withError from "~/shared/Context/ErrorDialog/withError"
import { authStorage } from "~/util/auth"

import Header from "./Header"

type Props = {
    location: Object,
    onSearchChange: Function,
    onSearchSubmit: Function,
    onNotifications: Function,
    user: User,
    history: Object,
    className: string,
    // match: Object,
    userEmail: string,
    userName: string,
    handleErrorOpen: Function,
    onboarding: boolean,
    entityName: string
}

type State = { menuOpened: boolean, anchorEl: ?Object }

class HeaderContainer extends React.Component<Props, State> {
    static defaultProps = {
        className: "",
        location: {},
        onSearchChange: () => {},
        onSearchSubmit: () => {},
        onNotifications: () => {},
        history: {},
        match: {},
        onboarding: false,
        entityName: "Loading..."
    }
    constructor(props: Props) {
        super(props)
        this.state = {
            menuOpened: false,
            anchorEl: null
        }
    }

    onboard = () => {
        this.props.history.push("/onboard")
        this.setState({ menuOpened: false })
    }
    settings = () => {
        this.props.history.push("/settings")
        this.setState({ menuOpened: false })
    }

    organisations = () => {
        this.props.history.push("/organisations")
        this.setState({ menuOpened: false })
    }
    newUrl = () => {
        this.props.history.push("/new")
    }

    guarantees = () => {
        this.props.history.push("/gx")
        this.setState({ menuOpened: false })
    }

    closeUserMenu = () => {
        this.setState({ menuOpened: false })
    }

    openUserMenu = (event: SyntheticInputEvent<>) => {
        this.setState({ menuOpened: true, anchorEl: event.currentTarget })
    }

    logout = () => {
        api.general
            .logout(authStorage.getTokenSet().refresh_token)
            .then(resp => {
                authStorage.removeTokenSet()
                authStorage.removeActingOn()
                this.props.history.push(`/logout`)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Logout was Unsuccessful`,
                    title: "Logout Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    render() {
        const {
            user,
            userEmail,
            userName,
            location,
            onSearchChange,
            onSearchSubmit,
            onNotifications,
            className,
            onboarding,
            entityName
        } = this.props
        const { menuOpened, anchorEl } = this.state

        return (
            <React.Fragment>
                <Header
                    className={className}
                    pathname={location.pathname}
                    newUrl={this.newUrl}
                    user={user}
                    userEmail={userEmail}
                    userName={userName}
                    openUserMenu={this.openUserMenu}
                    menuOpened={menuOpened}
                    anchorEl={anchorEl}
                    closeUserMenu={this.closeUserMenu}
                    onSearchChange={onSearchChange}
                    onSearchSubmit={onSearchSubmit}
                    onNotifications={onNotifications}
                    logout={this.logout}
                    onboard={this.onboard}
                    organisations={this.organisations}
                    guarantees={this.guarantees}
                    settings={this.settings}
                    onboarding={onboarding}
                    entityName={entityName}
                />
            </React.Fragment>
        )
    }
}

export default withError(HeaderContainer)
