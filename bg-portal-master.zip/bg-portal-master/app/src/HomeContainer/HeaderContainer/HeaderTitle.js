// @flow

import React from "react"

type Props = {
    pathname: string,
    lastTitle: string
}

const HeaderTitle = ({ pathname, lastTitle }: Props) => {
    if (pathname === "/gx/new") {
        return <span>New Request</span>
    } else if (pathname === "/gx") {
        if (PORTAL_TYPE === "admin") {
            return <span>Organisations</span>
        }
        return <span>All Guarantees</span>
    } else if (pathname === "/onboard") {
        return <span>Onboard New Entity</span>
    } else if (pathname === "/updates") {
        return <span>Updates</span>
    } else if (pathname === "/new") {
        return <span>Onboard New Entity</span>
    } else if (pathname === "/organisations") {
        return <span>Organisations</span>
    } else if (pathname === "/firstlogon") {
        return <span>Welcome Aboard</span>
    } else if (pathname === "/organisations/*") {
        return <span>{"Organisations > Details"}</span>
    }
    // on details page, do breadcrumb
    return (
        <span>
            {/* {pathname} */}
            Guarantees
            <span>{" > Details"}</span>
        </span>
    )
}

export default HeaderTitle
