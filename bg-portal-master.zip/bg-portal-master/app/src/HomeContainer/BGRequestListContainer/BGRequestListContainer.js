// @flow
/* eslint-disable react/sort-comp */

import * as React from "react"
import Card from "@material-ui/core/Card"
import { css } from "emotion"
import debounce from "lodash/debounce"
import { withTheme } from "@material-ui/core/styles"
import { Grid, Block, Flex } from "~/shared/layout"
import withError from "~/shared/Context/ErrorDialog/withError"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import makeCancelable from "~/util/helpers/makeCancelable"
import PageTitle from "~/shared/PageTitle"
import api from "~/util/api"
import { mapGxRequestToTableValues } from "~/util/guarantee"
import ParentSubDropdown from "~/shared/ParentSubDropdown/ParentSubDropdown"

type Props = {
    history: Object,
    className: string,
    handleErrorOpen: Function,
    currentOrgId: string,
    user: Object,
    theme: Object
}

type State = {
    rows: Array<Object>,
    loading: boolean
}

const tableSortDefault = { dataName: "status", order: "asc" }

const columns = [
    { columnHeader: { dataName: "status", displayName: "Status" }, sort: true },
    { columnHeader: { dataName: "requestType", displayName: "Request Type" }, sort: true },
    { columnHeader: { dataName: "createdBy", displayName: "Created By" }, sort: true },
    {
        columnHeader: { dataName: "createdAt", displayName: "Created At" },
        sort: true
    }
]
class BGRequestListContainer extends React.Component<Props, State> {
    cancelablePromise: Object
    cancelableQuery: Object
    constructor(props) {
        super(props)
        this.state = {
            rows: [],
            loading: true
        }
        this.searchQuery = debounce(this.searchQuery, 1000)
        this.cancelablePromise = { cancel: () => console.log("cancel") }
        this.cancelableQuery = { cancel: () => console.log("cancel") }
    }
    componentDidMount() {
        this.cancelablePromise = makeCancelable(this.getGuaranteeRequests())
    }
    componentWillUnmount() {
        this.searchQuery.cancel()
        this.cancelablePromise.cancel()
        this.cancelableQuery.cancel()
    }

    onSearch = searchValue => {
        this.searchQuery(searchValue)
    }
    onRowSelection = row => {
        if (row.requestType !== "Issue" && row.requestType !== "Transfer") {
            this.props.history.push(`/gx/details/${row.guaranteeId}?breadcrumb=guarantee-requests`)
        } else if (row.requestType === "Issue" && row.status === "Approved") {
            this.props.history.push(`/gx/details/${row.guaranteeId}?breadcrumb=guarantee-requests`)
        } else {
            this.props.history.push(`/gx/guarantee-requests/${row.requestId}?breadcrumb=guarantee-requests`)
        }
    }

    getGuaranteeRequests = () =>
        api.guarantee
            .getRequests({ limit: 10000 })
            .then(({ data }) => {
                const filteredRequests = data.result.filter(request => request.type !== "EXPIRE")
                this.setState({
                    rows: mapGxRequestToTableValues(filteredRequests, this.props.currentOrgId),
                    loading: false
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `There was an error getting your guarantee requests`,
                    title: "Guarantee Requests Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })

    getGuarantee = (searchQuery = "") =>
        api.guarantee
            .getGuarantee(searchQuery)
            .then(({ data }) => {
                console.log("Requests", data)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `There was an error getting your search results`,
                    title: "Guarantee Search Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err,
                        Payload: searchQuery
                    }
                })
                throw err
            })
    searchQuery = searchValue => {
        if (searchValue !== "") {
            this.cancelableQuery = makeCancelable(this.getGuarantee(searchValue))
        } else {
            this.cancelableQuery = makeCancelable(this.getGuaranteeRequests())
        }
    }

    render() {
        const { className, user, theme } = this.props
        const { loading, rows } = this.state
        return (
            <Grid gridGap="3un" className={className}>
                <Card>
                    <PageTitle
                        title={
                            // $FlowFixMe
                            <Flex>
                                <Flex flex="1">
                                    <div
                                        // eslint-disable-next-line
                                        tabIndex="0"
                                        id="main-content"
                                    >
                                        {user.actingOnBehalf ? `${user.actingOnBehalf.label} ` : ""}Guarantee Requests
                                    </div>
                                </Flex>

                                <Flex>
                                    <ParentSubDropdown user={user} onChange={() => this.getGuaranteeRequests()} />
                                </Flex>
                            </Flex>
                        }
                    />
                    <Block padding="3un">
                        <FlexAccordionTable
                            onRowSelection={this.onRowSelection}
                            columns={columns}
                            data={rows}
                            loading={loading}
                            defaultSort={tableSortDefault}
                            className={css(theme.typography.tableStyle)}
                        />
                    </Block>
                </Card>
            </Grid>
        )
    }
}

export default withError(withTheme()(BGRequestListContainer))
