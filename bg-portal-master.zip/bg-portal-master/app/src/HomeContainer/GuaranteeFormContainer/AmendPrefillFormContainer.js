// @flow

import * as React from "react"
import api from "~/util/api"
import { withTheme } from "@material-ui/core/styles"
import withError from "~/shared/Context/ErrorDialog/withError"
import { Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import AmendGuaranteeForm from "~/shared/Forms/GuaranteeForm/AmendGuaranteeForm"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import { mapGuaranteeToFormValues, mapAmendFormValuesToRequest } from "~/util/guarantee"
import axios from "axios"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import DataCacheContext from "~/shared/Context/DataCache/DataCacheContext"
import { authStorage } from "~/util/auth"
import _ from "lodash"

type Props = {
    history: Object,
    theme: Object,
    location: Object,
    previousPage: Function,
    match: Object,
    handleErrorOpen: Function
}

type State = {
    initialValues: Object,
    loading: boolean,
    requestId: string,
    issuers: Array<any>,
    prefillRequest: boolean,
    termsAndConditions: Array<Object>,
    requestPayload: Object,
    purposeTemplates: Templates
}

class AmendPrefillFormContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)

        this.state = {
            initialValues: {},
            loading: true,
            requestId: "",
            issuers: [],
            prefillRequest: false,
            termsAndConditions: [],
            requestPayload: {},
            purposeTemplates: []
        }
    }

    componentDidMount() {
        const { gxId } = this.props.match.params
        const qs = this.props.location.search
        const params = new URLSearchParams(qs)
        const requestId = params.get("requestId")
        const prefillRequest = params.get("prefillRequest") === "true"
        this.setState({ requestId, prefillRequest })
        api.general
            .multipleApis([
                api.guarantee.getRequest(requestId),
                api.guarantee.getGuarantee(gxId),
                api.organisations.getOrgsWithQuery("?entityType=ISSUER&status=ACTIVE"),
                api.termsAndConditions.getTCsIdsByType("BANK_GUARANTEE"),
                api.purpose.getAllPurposeTemplates()
            ])
            .then(
                axios.spread((requestDetails, guaranteeDetails, issuers, termsAndConditions, purposeTemplates) => {
                    authStorage.setGuaranteeTCIds(_.keyBy(termsAndConditions.data.result, item => item.id))

                    const { data } = guaranteeDetails

                    const requestPayload = { ...requestDetails.data.payload }
                    if (requestPayload.amount) {
                        requestPayload.amount = {
                            outstanding: requestPayload.amount,
                            currency: data.amount.currency
                        }
                    }
                    // mutate data object to copy over any new (changed) values from the amend request
                    _.merge(data, requestPayload)

                    const guaranteeValues = mapGuaranteeToFormValues(data)

                    // HACK fix later
                    // $FlowFixMe
                    guaranteeValues.issuer = guaranteeValues.issuer.orgId
                    // $FlowFixMe
                    guaranteeValues.applicant = {
                        label: guaranteeValues.applicant.name,
                        value: guaranteeValues.applicant.name,
                        orgId: guaranteeValues.applicant.orgId,
                        abnAcn: guaranteeValues.applicant.businessId
                    }
                    // $FlowFixMe
                    guaranteeValues.beneficiary = {
                        label: guaranteeValues.beneficiary.name,
                        value: guaranteeValues.beneficiary.name,
                        orgId: guaranteeValues.beneficiary.orgId,
                        abnAcn: guaranteeValues.beneficiary.businessId
                    }

                    this.setState({
                        initialValues: guaranteeValues,
                        loading: false,
                        issuers: issuers.data.result,
                        requestPayload: requestDetails.data.payload,
                        termsAndConditions: termsAndConditions.data.result.map(tcItem => ({
                            title: tcItem.title,
                            id: tcItem.id
                        })),
                        purposeTemplates: purposeTemplates.data.result
                    })
                })
            )
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting Guarantee error`,
                    title: "Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: { id: this.props.match.params.gxId },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    submitAmendmentRequest = (values: Object, entityType: string) => {
        const { gxId } = this.props.match.params
        const formValues = mapAmendFormValuesToRequest(values)
        const apiValue = { ...this.state.requestPayload }
        _.merge(apiValue, formValues)
        return api.guarantee
            .submitRequestForGuarantee(gxId, "AMEND", apiValue, this.state.prefillRequest ? this.state.requestId : null)
            .then(({ data }) => {
                this.props.history.push(`/gx/details/${gxId}`)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Amend guarantee request error`,
                    title: "Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: apiValue,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    rejectAmendmentRequest = () => {
        const { requestId } = this.state
        const { gxId } = this.props.match.params
        api.guarantee
            .submitAction({
                requestId,
                type: "REJECT"
            })
            .then(() => this.props.history.push(`/gx/details/${gxId}`))
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Amend guarantee request error`,
                    title: "Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    render() {
        const { theme, previousPage, history } = this.props

        const { initialValues, loading, issuers, prefillRequest, termsAndConditions, purposeTemplates } = this.state
        return (
            <React.Fragment>
                <PageTitle link="/gx" path="Guarantees/" history={history} title="Amend Guarantee" theme={theme} />
                <Block padding="1un 3un 3un 3un">
                    {loading ? (
                        <LoadingCard />
                    ) : (
                        <DataCacheContext.Consumer>
                            {currentUserInformation => (
                                <AmendGuaranteeForm
                                    initialValues={initialValues}
                                    onCancel={() => previousPage()}
                                    onSubmit={this.submitAmendmentRequest}
                                    issuers={issuers}
                                    onReject={this.rejectAmendmentRequest}
                                    prefillRequest={prefillRequest}
                                    fromPrefillContainer
                                    currentUserInformation={currentUserInformation}
                                    termsAndConditions={termsAndConditions}
                                    purposeTemplates={purposeTemplates}
                                />
                            )}
                        </DataCacheContext.Consumer>
                    )}
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(AmendPrefillFormContainer))
