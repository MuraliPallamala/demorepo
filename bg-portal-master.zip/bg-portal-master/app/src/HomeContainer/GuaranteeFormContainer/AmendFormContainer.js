// @flow

import * as React from "react"
import api from "~/util/api"
import { withTheme } from "@material-ui/core/styles"
import withError from "~/shared/Context/ErrorDialog/withError"
import { Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import AmendGuaranteeForm from "~/shared/Forms/GuaranteeForm/AmendGuaranteeForm"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import { mapGuaranteeToFormValues, mapAmendFormValuesToRequest } from "~/util/guarantee"
import axios from "axios"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import DataCacheContext from "~/shared/Context/DataCache/DataCacheContext"
import { authStorage } from "~/util/auth"
import _ from "lodash"

type Props = {
    history: Object,
    theme: Object,
    previousPage: Function,
    match: Object,
    handleErrorOpen: Function
}

type State = {
    initialValues: Object,
    loading: boolean,
    issuers: Array<any>,
    termsAndConditions: Array<Object>,
    purposeTemplates: Templates
}

class AmendFormContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)

        this.state = { initialValues: {}, loading: true, issuers: [], termsAndConditions: [], purposeTemplates: [] }
    }

    componentDidMount() {
        api.general
            .multipleApis([
                api.guarantee.getGuarantee(this.props.match.params.gxId),
                api.organisations.getOrgsWithQuery("?entityType=ISSUER&status=ACTIVE"),
                api.termsAndConditions.getTCsIdsByType("BANK_GUARANTEE"),
                api.purpose.getAllPurposeTemplates()
            ])
            .then(
                axios.spread((guarantee, issuers, termsAndConditions, purposeTemplates) => {
                    authStorage.setGuaranteeTCIds(_.keyBy(termsAndConditions.data.result, item => item.id))
                    const guaranteeValues = mapGuaranteeToFormValues(guarantee.data)
                    // HACK fix later

                    // $FlowFixMe
                    guaranteeValues.issuer = guaranteeValues.issuer.orgId
                    // $FlowFixMe
                    guaranteeValues.applicant = {
                        label: guaranteeValues.applicant.name,
                        value: guaranteeValues.applicant.name,
                        orgId: guaranteeValues.applicant.orgId,
                        abnAcn: guaranteeValues.applicant.businessId
                    }
                    // $FlowFixMe
                    guaranteeValues.beneficiary = {
                        label: guaranteeValues.beneficiary.name,
                        value: guaranteeValues.beneficiary.name,
                        orgId: guaranteeValues.beneficiary.orgId,
                        abnAcn: guaranteeValues.beneficiary.businessId
                    }
                    this.setState({
                        termsAndConditions: termsAndConditions.data.result.map(tcItem => ({
                            title: tcItem.title,
                            id: tcItem.id
                        })),
                        purposeTemplates: purposeTemplates.data.result,
                        issuers: issuers.data.result,
                        initialValues: guaranteeValues,
                        loading: false
                    })
                })
            )

            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting Guarantee error`,
                    title: "Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: { id: this.props.match.params.gxId },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    submitAmendmentRequest = (values: Object, entityType: string) => {
        const apiValue = mapAmendFormValuesToRequest(values)
        return api.guarantee
            .submitRequestForGuarantee(this.props.match.params.gxId, "AMEND", apiValue)
            .then(({ data }) => {
                // need to know on redirect if issuer initiated the amend request
                let qs = ""
                if (entityType === "ISSUER") {
                    qs = "?issuerPrefillRequest=true"
                }
                this.props.history.push(`/gx/details/${this.props.match.params.gxId}${qs}`)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Amend guarantee request error`,
                    title: "Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: apiValue,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    render() {
        const { theme, previousPage, history } = this.props
        const { initialValues, loading, issuers, termsAndConditions, purposeTemplates } = this.state
        return (
            <React.Fragment>
                <PageTitle link="/gx" path="Guarantees/" history={history} title="Amend Guarantee" theme={theme} />
                <Block padding="1un 3un 3un 3un">
                    {loading ? (
                        <LoadingCard />
                    ) : (
                        <DataCacheContext.Consumer>
                            {currentUserInformation => (
                                <AmendGuaranteeForm
                                    initialValues={initialValues}
                                    onCancel={() => previousPage()}
                                    onSubmit={this.submitAmendmentRequest}
                                    issuers={issuers}
                                    fromPrefillContainer={false}
                                    currentUserInformation={currentUserInformation}
                                    termsAndConditions={termsAndConditions}
                                    purposeTemplates={purposeTemplates}
                                />
                            )}
                        </DataCacheContext.Consumer>
                    )}
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(AmendFormContainer))
