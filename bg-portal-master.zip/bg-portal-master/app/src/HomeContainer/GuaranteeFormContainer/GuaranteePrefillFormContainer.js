// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import axios from "axios"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import { Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import FreshGuaranteeForm from "~/shared/Forms/GuaranteeForm/FreshGuaranteeForm"
import { mapGuaranteeToFormValues, mapFormValuesToRequest } from "~/util/guarantee"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import DataCacheContext from "~/shared/Context/DataCache/DataCacheContext"
import { authStorage } from "~/util/auth"
import _ from "lodash"

type Props = {
    history: Object,
    theme: Object,
    previousPage: Function,
    handleErrorOpen: Function,
    match: Object,
    location: Object,
    currentUserInformation: Object
}

type State = {
    initialValues: Object,
    loading: boolean,
    issuers: Array<any>,
    prefillRequest: boolean,
    requestId?: string,
    termsAndConditions: Array<any>,
    purposeTemplates: Templates
}

class GuaranteeFormContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)

        this.state = {
            initialValues: {},
            loading: true,
            issuers: [],
            prefillRequest: false,
            termsAndConditions: [],
            purposeTemplates: []
        }
    }

    componentDidMount() {
        if (this.props.currentUserInformation.isLoaded) {
            this.setFormValues()
        }
    }

    componentDidUpdate(prevProps) {
        if (
            this.props.currentUserInformation.isLoaded &&
            prevProps.currentUserInformation.isLoaded !== this.props.currentUserInformation.isLoaded
        ) {
            this.setFormValues()
        }
    }

    getGuaranteeData = (id, prefillRequest, comesFromRequest) => {
        if (prefillRequest || comesFromRequest) {
            return (
                api.guarantee
                    .getRequest(id)
                    // next line: data.payload.gx only exists if the request is a transfer request. if so, use the contents of that.
                    .then(resp => (resp.data.payload.gx ? resp.data.payload.gx : resp.data.payload))
            )
        }
        return api.guarantee.getGuarantee(id).then(resp => resp.data)
    }
    isApplicantMe = (applicant, orgId) => {
        if (applicant && orgId && applicant.orgId === orgId) {
            return true
        }
        return false
    }
    setFormValues = () => {
        const qs = this.props.location.search
        const params = new URLSearchParams(qs)

        // this prefill request variable gets set when it's an issuer initiated request.
        const prefillRequest = params.get("prefillRequest") === "true"
        // this hasGuarantee variable determines whether this comes from a request or guarantee.
        const comesFromRequest = params.get("isRequest") === "true"

        this.setState({ prefillRequest })
        const { id } = this.props.match.params
        const { currentUserInformation } = this.props
        api.general
            .multipleApis([
                this.getGuaranteeData(id, prefillRequest, comesFromRequest),
                api.organisations.getOrgsWithQuery("?entityType=ISSUER&status=ACTIVE"),
                api.termsAndConditions.getActiveTCsIdsByType("BANK_GUARANTEE"),
                api.purpose.getAllActivePurposeTemplates()
            ])
            .then(
                axios.spread((guaranteeRaw, issuers, termsAndConditions, purposeTemplates) => {
                    authStorage.setGuaranteeTCIds(_.keyBy(termsAndConditions.data.result, item => item.id))

                    const guaranteeValues = mapGuaranteeToFormValues(guaranteeRaw)
                    // HACK fix later
                    // $FlowFixMe
                    guaranteeValues.applicant = {
                        label: guaranteeValues.applicant.name,
                        value: guaranteeValues.applicant.name,
                        orgId: guaranteeValues.applicant.orgId,
                        abnAcn: guaranteeValues.applicant.businessId
                    }
                    // $FlowFixMe
                    guaranteeValues.beneficiary = {
                        label: guaranteeValues.beneficiary.name,
                        value: guaranteeValues.beneficiary.name,
                        orgId: guaranteeValues.beneficiary.orgId,
                        abnAcn: guaranteeValues.beneficiary.businessId
                    }
                    if (
                        (this.isApplicantMe(
                            guaranteeValues.applicant,
                            currentUserInformation.actingOnBehalf
                                ? currentUserInformation.actingOnBehalf.id
                                : currentUserInformation.primaryOrgId
                        ) ||
                            currentUserInformation.entityType === "ISSUER") &&
                        guaranteeValues.issuer &&
                        guaranteeValues.issuer.orgId
                    ) {
                        // $FlowFixMe
                        guaranteeValues.issuer = guaranteeValues.issuer.orgId
                    } else {
                        guaranteeValues.issuer = null
                    }

                    this.setState({
                        initialValues: guaranteeValues,
                        loading: false,
                        issuers: issuers.data.result,
                        termsAndConditions: termsAndConditions.data.result.map(tcItem => ({
                            title: tcItem.title,
                            id: tcItem.id
                        })),
                        purposeTemplates: purposeTemplates.data.result
                    })
                })
            )
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting Request error`,
                    title: "Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: {},
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    submitGuaranteeRequest = (values: Object) => {
        const { id } = this.props.match.params

        return api.guarantee
            .submitRequest("ISSUE", mapFormValuesToRequest(values), this.state.prefillRequest ? id : null)
            .then(({ data }) => {
                this.props.history.push(`/gx/guarantee-requests/${data.id}`)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Submit guarantee request error`,
                    title: "Submit Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: values,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    rejectIssueRequest = () => {
        const { id } = this.props.match.params
        api.guarantee
            .submitAction({
                requestId: id,
                type: "REJECT"
            })
            .then(() => this.props.history.push(`/gx`))
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Issue guarantee request error`,
                    title: "Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    render() {
        const { theme, previousPage } = this.props

        const { initialValues, loading, issuers, prefillRequest, termsAndConditions, purposeTemplates } = this.state
        if (loading) {
            return (
                <React.Fragment>
                    <PageTitle link="/gx" path="Guarantees/" title="New Guarantee" theme={theme} />
                    <Block padding="1un 3un 3un 3un">
                        <LoadingCard />
                    </Block>
                </React.Fragment>
            )
        }
        return (
            <React.Fragment>
                <PageTitle link="/gx" path="Guarantees/" title="New Guarantee" theme={theme} />
                <Block padding="1un 3un 3un 3un">
                    <DataCacheContext.Consumer>
                        {currentUserInformation => (
                            <FreshGuaranteeForm
                                referer
                                onCancel={() => previousPage()}
                                onSubmit={this.submitGuaranteeRequest}
                                initialValues={initialValues}
                                issuers={issuers}
                                onReject={this.rejectIssueRequest}
                                purposeTemplates={purposeTemplates}
                                prefillRequest={prefillRequest}
                                currentUserInformation={currentUserInformation}
                                termsAndConditions={termsAndConditions}
                            />
                        )}
                    </DataCacheContext.Consumer>
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(GuaranteeFormContainer))
