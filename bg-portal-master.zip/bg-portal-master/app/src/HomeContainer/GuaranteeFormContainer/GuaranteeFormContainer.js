// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import axios from "axios"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import { Block } from "~/shared/layout"
import { authStorage } from "~/util/auth"
import _ from "lodash"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

import PageTitle from "~/shared/PageTitle"
import FreshGuaranteeForm from "~/shared/Forms/GuaranteeForm/FreshGuaranteeForm"
import { mapGuaranteeToFormValues, mapFormValuesToRequest } from "~/util/guarantee"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import DataCacheContext from "~/shared/Context/DataCache/DataCacheContext"

type Props = {
    history: Object,
    theme: Object,
    previousPage: Function,
    handleErrorOpen: Function,
    match: Object,
    user: Object
}

type State = {
    initialValues: Object,
    loading: boolean,
    issuers: Array<any>,
    termsAndConditions: Array<Object>,
    purposeTemplates: Templates
}

class GuaranteeFormContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = { initialValues: {}, loading: true, issuers: [], termsAndConditions: [], purposeTemplates: [] }
    }
    componentDidMount() {
        api.general
            .multipleApis([
                api.organisations.getOrgsWithQuery("?entityType=ISSUER&status=ACTIVE"),
                api.termsAndConditions.getActiveTCsIdsByType("BANK_GUARANTEE"),
                api.purpose.getAllActivePurposeTemplates()
            ])
            .then(
                axios.spread((issuers, termsAndConditions, purposeTemplates) => {
                    authStorage.setGuaranteeTCIds(_.keyBy(termsAndConditions.data.result, item => item.id))
                    this.setState({
                        loading: false,
                        issuers: issuers.data.result,
                        termsAndConditions: termsAndConditions.data.result.map(tcItem => ({
                            title: tcItem.title,
                            id: tcItem.id
                        })),
                        purposeTemplates: purposeTemplates.data.result
                    })
                })
            )
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting Issuers or T&Cs error`,
                    title: "Issuer or T&Ts Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: { id: this.props.match.params.gxId },
                        ErrorResponse: err
                    }
                })
                throw err
            })
        if (this.props.user.businessId) {
            this.updateForm()
        }
        window.addEventListener("beforeunload", this.onUnload)
    }
    componentDidUpdate(prevProps) {
        if (prevProps.user && this.props.user && prevProps.user.businessId !== this.props.user.businessId) {
            this.updateForm()
        }
    }
    componentWillUnmount() {
        window.removeEventListener("beforeunload", this.onUnload)
    }
    onUnload = event => {
        // the method that will be used for both add and remove event
        event.returnValue = "Data will be lost if you leave the page, are you sure?"
    }
    updateForm = () => {
        if (this.props.match.params.gxId) {
            this.setState({ loading: true })
            api.guarantee
                .getGuarantee(this.props.match.params.gxId)
                .then(({ data }) => {
                    const guaranteeValues = mapGuaranteeToFormValues(data)
                    const getApplicant = api.organisations.getOrganisations(guaranteeValues.applicant.orgId)
                    const getBeneficiary = api.organisations.getOrganisations(guaranteeValues.beneficiary.orgId)

                    api.general.multipleApis([getApplicant, getBeneficiary]).then(
                        axios.spread((applicant, beneficiary) => {
                            const applicantEntityName = applicant.data.profile.entityName
                            const newApplicant = {
                                label: applicantEntityName,
                                value: applicantEntityName,
                                orgId: guaranteeValues.applicant.orgId,
                                abnAcn: applicant.data.profile.businessId
                            }
                            const beneficiaryEntityName = beneficiary.data.profile.entityName
                            const newBeneficiary = {
                                label: beneficiaryEntityName,
                                value: beneficiaryEntityName,
                                orgId: guaranteeValues.beneficiary.orgId,
                                abnAcn: beneficiary.data.profile.businessId
                            }
                            // $FlowFixMe
                            guaranteeValues.applicant = newApplicant
                            // $FlowFixMe
                            guaranteeValues.beneficiary = newBeneficiary
                            this.setState({ initialValues: guaranteeValues, loading: false })
                        })
                    )
                })
                .catch(err => {
                    this.props.handleErrorOpen({
                        errorMessage: `Getting Guarantee error`,
                        title: "Guarantee Error",
                        error: err,
                        extraDetails: {
                            Info: err.info,
                            CurrentUrl: this.props.history.location.pathname,
                            Payload: { id: this.props.match.params.gxId },
                            ErrorResponse: err
                        }
                    })
                    throw err
                })
        } else {
            // eslint-disable-next-line
            let initialValues={issuer:""}
            if (this.props.user && this.props.user.entityType === "ISSUER") {
                initialValues.issuer = this.props.user.key.toLowerCase() // the key should contain the correct value (issuer id) to send to the api
            }
            this.setState({ initialValues })
        }
    }
    submitGuaranteeRequest = (values: Object, entityType: string, approvalModelName: string) =>
        api.guarantee
            .submitRequest("ISSUE", mapFormValuesToRequest(values))
            .then(({ data }) => {
                // need to know on redirect if issuer initiated the amend request
                if (entityType === "ISSUER" && approvalModelName !== "FOUR_EYE") {
                    this.props.history.push(`/gx?issuerPrefillRequest=true`)
                } else {
                    this.props.history.push(`/gx/guarantee-requests/${data.id}`)
                }
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Submit guarantee request error`,
                    title: "Submit Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: values,
                        ErrorResponse: err
                    }
                })
                throw err
            })

    render() {
        const { theme, previousPage } = this.props
        const { initialValues, loading, issuers, termsAndConditions, purposeTemplates } = this.state
        if (loading) {
            return (
                <React.Fragment>
                    <PageTitle link="/gx" path="Guarantees/" title="New Guarantee" theme={theme} />
                    <Block padding="1un 3un 3un 3un">
                        <LoadingCard />
                    </Block>
                </React.Fragment>
            )
        }
        return (
            <React.Fragment>
                <PageTitle link="/gx" path="Guarantees/" title="New Guarantee" theme={theme} />
                <Block padding="1un 3un 3un 3un">
                    <DataCacheContext.Consumer>
                        {currentUserInformation => (
                            <FreshGuaranteeForm
                                referer
                                onCancel={() => previousPage()}
                                onSubmit={this.submitGuaranteeRequest}
                                initialValues={initialValues}
                                issuers={issuers}
                                termsAndConditions={termsAndConditions}
                                currentUserInformation={currentUserInformation}
                                purposeTemplates={purposeTemplates}
                            />
                        )}
                    </DataCacheContext.Consumer>
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(GuaranteeFormContainer))
