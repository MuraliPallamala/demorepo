// @flow

import * as React from "react"
import axios from "axios"
import api from "~/util/api"
import { withTheme } from "@material-ui/core/styles"
import withError from "~/shared/Context/ErrorDialog/withError"
import { Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import TransferGuaranteeForm from "~/shared/Forms/GuaranteeForm/TransferGuaranteeForm"
import { mapGuaranteeToFormValues } from "~/util/guarantee"
import DataCacheContext from "~/shared/Context/DataCache/DataCacheContext"
import { authStorage } from "~/util/auth"
import _ from "lodash"

type Props = {
    history: Object,
    theme: Object,
    match: Object,
    previousPage: Function,
    handleErrorOpen: Function
}

type State = {
    initialValues: Object,
    loading: boolean,
    issuers: Array<any>,
    termsAndConditions: Array<Object>,
    purposeTemplates: Templates
}

class TransferFormContainer extends React.Component<Props, State> {
    constructor(props) {
        super(props)

        this.state = { initialValues: {}, loading: true, issuers: [], termsAndConditions: [], purposeTemplates: [] }
    }

    componentDidMount() {
        api.general
            .multipleApis([
                api.guarantee.getGuarantee(this.props.match.params.gxId),
                api.organisations.getOrgsWithQuery("?entityType=ISSUER&status=ACTIVE"),
                api.termsAndConditions.getTCsIdsByType("BANK_GUARANTEE"),
                api.purpose.getAllPurposeTemplates()
            ])
            .then(
                axios.spread((guarantee, issuers, termsAndConditions, purposeTemplates) => {
                    authStorage.setGuaranteeTCIds(_.keyBy(termsAndConditions.data.result, item => item.id))

                    const guaranteeValues = mapGuaranteeToFormValues(guarantee.data)

                    // HACK fix later
                    // $FlowFixMe
                    guaranteeValues.issuer = guaranteeValues.issuer.orgId
                    // $FlowFixMe
                    guaranteeValues.applicant = {
                        label: guaranteeValues.applicant.name,
                        value: guaranteeValues.applicant.name,
                        orgId: guaranteeValues.applicant.orgId,
                        abnAcn: guaranteeValues.applicant.businessId
                    }
                    // $FlowFixMe
                    guaranteeValues.beneficiary = {
                        label: guaranteeValues.beneficiary.name,
                        value: guaranteeValues.beneficiary.name,
                        orgId: guaranteeValues.beneficiary.orgId,
                        abnAcn: guaranteeValues.beneficiary.businessId
                    }

                    this.setState({
                        initialValues: guaranteeValues,
                        loading: false,
                        issuers: issuers.data.result,
                        termsAndConditions: termsAndConditions.data.result.map(tcItem => ({
                            title: tcItem.title,
                            id: tcItem.id
                        })),
                        purposeTemplates: purposeTemplates.data.result
                    })
                })
            )
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting Guarantee error`,
                    title: "Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: { id: this.props.match.params.gxId },
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    submitTransferForm = (values: Object) => {
        const request = {
            beneficiaries: [values.beneficiary.orgId],
            reason: values.reason === "Other" ? values.otherReason : values.reason
        }
        return api.guarantee
            .submitRequestForGuarantee(this.props.match.params.gxId, "TRANSFER", request)
            .then(({ data }) => {
                this.props.history.push(`/gx/details/${this.props.match.params.gxId}`)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Transfer guarantee request error`,
                    title: "Guarantee Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: request,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    render() {
        const { theme, previousPage } = this.props
        const { initialValues, loading, issuers, termsAndConditions, purposeTemplates } = this.state
        if (loading) {
            return (
                <React.Fragment>
                    <PageTitle link="/gx" path="Guarantees/" title="Transfer Guarantee" theme={theme} />
                    <Block padding="1un 3un 3un 3un">
                        <LoadingCard />
                    </Block>
                </React.Fragment>
            )
        }
        return (
            <React.Fragment>
                <PageTitle link="/gx" path="Guarantees/" title="Transfer Guarantee" theme={theme} />
                <Block padding="1un 3un 3un 3un">
                    <DataCacheContext.Consumer>
                        {currentUserInformation => (
                            <TransferGuaranteeForm
                                referer
                                issuers={issuers}
                                initialValues={initialValues}
                                onCancel={() => previousPage()}
                                onSubmit={this.submitTransferForm}
                                emailsError={this.props.handleErrorOpen}
                                currentUserInformation={currentUserInformation}
                                termsAndConditions={termsAndConditions}
                                purposeTemplates={purposeTemplates}
                            />
                        )}
                    </DataCacheContext.Consumer>
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(TransferFormContainer))
