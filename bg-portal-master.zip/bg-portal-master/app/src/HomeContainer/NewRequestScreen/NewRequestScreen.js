// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import { withTheme } from "@material-ui/core/styles"
import CardContent from "@material-ui/core/CardContent"
import Button from "@material-ui/core/Button"
import { css } from "emotion"
import { Block } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"

type Props = {
    history: Object,
    className?: string,
    match: Object,
    theme: Object,
    userRoles: Object,
    approvalModel: Object,
    currentOrgId: string
}
const getClasses = ({ theme }) => {
    const buttonColor = css({
        color: theme.typography.button.color
    })
    const buttonStyle = css(buttonColor, {
        border: `solid 1.4px ${theme.typography.button.color}`,
        textTransform: "none",
        marginRight: theme.spacing.unit * 3,
        padding: "19.4px",
        "&:hover": {
            backgroundColor: theme.palette.common.buttonHover
        }
    })
    const buttonStyleDisabled = css(buttonStyle, { border: `solid 1.4px rgba(0, 0, 0, 0.26)` })
    const mainButtonContainer = css({
        marginTop: theme.spacing.unit * 2,
        marginBottom: theme.spacing.unit * 3
    })
    return {
        buttonStyle,
        buttonColor,
        mainButtonContainer,
        buttonStyleDisabled
    }
}
const NewGxScreenContainer = ({ user, theme, history, userRoles, approvalModel, currentOrgId }: Props) => {
    function guarantees() {
        history.push("/gx")
    }
    function onboard() {
        history.push("/onboard")
    }
    function newGuarantee() {
        history.push("/gx/New")
    }
    const classes = getClasses({ theme })
    return (
        <React.Fragment>
            <PageTitle title="New Request" theme={theme} />
            <Block padding="1un 3un 3un 3un">
                <Card>
                    <CardContent>
                        <div className={classes.mainButtonContainer}>
                            <Button
                                onClick={() => newGuarantee()}
                                className={
                                    !approvalModel || !userRoles || !userRoles[currentOrgId]
                                        ? classes.buttonStyleDisabled
                                        : classes.buttonStyle
                                }
                                disabled={
                                    !approvalModel || !userRoles || !userRoles[currentOrgId]
                                    // TODO: this following part is commented out at the moment, because there is no accounting for acting on behalf of another org at the moment. this can be fixed by either adding a dropdown to the top of this page, or a check before submitting the form.
                                    // ||
                                    // (!userRoles[currentOrgId].includes("MANAGER") &&
                                    //     !userRoles[currentOrgId].includes("PROPOSER"))
                                }
                                aria-label="Start a bank guarantee request"
                            >
                                Start a Bank Guarantee Request
                                <br />
                            </Button>
                            <Button
                                onClick={() => onboard()}
                                className={classes.buttonStyle}
                                aria-label="Start Onboarding Process on Behalf of a New Entity"
                            >
                                Start Onboarding on Behalf of a New Entity
                            </Button>
                        </div>
                        <div>
                            <Button
                                onClick={() => guarantees()}
                                className={classes.buttonColor}
                                aria-label="Exit new request page and go back to previous screen"
                            >
                                Exit
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </Block>
        </React.Fragment>
    )
}

NewGxScreenContainer.defaultProps = {
    className: ""
}

export default withTheme()(NewGxScreenContainer)
