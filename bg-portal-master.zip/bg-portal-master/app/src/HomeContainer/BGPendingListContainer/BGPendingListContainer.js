// @flow
/* eslint-disable react/sort-comp */

import * as React from "react"
import Card from "@material-ui/core/Card"
import debounce from "lodash/debounce"
import moment from "moment"
import axios from "axios"
import { css } from "emotion"
import ArrowUp from "@material-ui/icons/KeyboardArrowUp"
import ArrowDown from "@material-ui/icons/KeyboardArrowDown"
import numeral from "numeral"
import { withTheme } from "@material-ui/core/styles"
import Typograpgy from "@material-ui/core/Typography"
import { Grid, Block, Flex } from "~/shared/layout"
import withError from "~/shared/Context/ErrorDialog/withError"
import FlexAccordionTable from "~/shared/FlexAccordionTable"
import makeCancelable from "~/util/helpers/makeCancelable"
import PageTitle from "~/shared/PageTitle"
import api from "~/util/api"
import purposeFormatMapping from "~/util/helpers/purposeFormatMapping"
import type { GxSearchRequest } from "~/util/api/base/guarantee"
import { mapRequestToTableValues } from "~/util/guarantee"
import { withFilter } from "~/shared/Context/Filter/FilterContext"
import ParentSubDropdown from "~/shared/ParentSubDropdown/ParentSubDropdown"
import TimelineItemDetails from "~/shared/TimelineContainer/SharedComponents/TimelineItemDetails"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import BGFilterContainer from "../BGListContainer/BGFilterContainer/BGFilterContainer"

type Props = {
    history: Object,
    className: string,
    handleErrorOpen: Function,
    currentOrgId: string,
    filters: Object,
    replaceFilters: Function,
    addFilter: Function,
    removeFilter: Function,
    removeFilters: Function,
    user: Object,
    theme: Object
}
type State = {
    rows: Array<Object>,
    filteredRows: Array<Object>,
    issuers: Array<Object>,
    loading: boolean,
    purposeTemplates: Templates
}

const getClasses = theme => {
    const detailsTitle = css({
        color: theme.palette.common.defaultRed
    })

    return {
        detailsTitle
    }
}
const tableSortDefault = { dataName: "status", order: "asc" }

const showAccordionToggle = (isOpen, toggleAccordion) =>
    isOpen ? (
        <ArrowUp
            onClick={e => {
                e.stopPropagation()
                toggleAccordion()
            }}
            css={{
                display: "flex",
                justifyContent: "center"
            }}
            titleAccess="Currently displaying extra information. Click again to hide information"
        />
    ) : (
        <ArrowDown
            onClick={e => {
                e.stopPropagation()
                toggleAccordion()
            }}
            css={{
                display: "flex",
                justifyContent: "center"
            }}
            titleAccess="Currently hiding extra information. Click again to display information"
        />
    )

class BGPendingListContainer extends React.Component<Props, State> {
    cancelablePromise: Object
    cancelableQuery: Object
    constructor(props) {
        super(props)
        this.state = {
            rows: [],
            filteredRows: [],
            loading: true,
            issuers: [],
            purposeTemplates: []
        }
        this.searchQuery = debounce(this.searchQuery, 1000)
        this.cancelablePromise = { cancel: () => console.log("cancel") }
        this.cancelableQuery = { cancel: () => console.log("cancel") }
    }
    componentDidMount() {
        this.cancelablePromise = makeCancelable(this.getPendingGuarantees())
        api.general
            .multipleApis([
                api.organisations.getOrgsWithQuery("?entityType=ISSUER"),
                api.purpose.getAllPurposeTemplates()
            ])
            .then(
                axios.spread((issuers, purposeTemplates) => {
                    const mappedIssuers = issuers.data.result.map(issuer => ({
                        label: issuer.entityName,
                        value: issuer.entityName
                    }))
                    this.setState({
                        issuers: mappedIssuers,
                        purposeTemplates: purposeTemplates.data.result
                    })
                })
            )
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting Issuers or Purpose error`,
                    title: "Issuer or Purpose Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }
    componentWillUnmount() {
        this.searchQuery.cancel()
        this.cancelablePromise.cancel()
        this.cancelableQuery.cancel()
    }
    componentDidUpdate(prevProps, prevState) {
        let searchChange = false

        if (this.props.filters !== prevProps.filters) {
            searchChange = true
        }

        if (searchChange) {
            const gxSearchRequest = this.createGxSearchRequest()
            this.searchGuarantees(gxSearchRequest)
        }
    }

    onSearch = searchValue => {
        this.searchQuery(searchValue)
    }
    onRowSelection = row => {
        if (row.requestType !== "Issue" && row.requestType !== "Transfer") {
            this.props.history.push(`/gx/details/${row.guaranteeId}?breadcrumb=pending-gx`)
        } else {
            this.props.history.push(`/gx/guarantee-requests/${row.requestId}?breadcrumb=pending-gx`)
        }
    }
    getColumns = (requestType: Array<string>) => {
        if (requestType && requestType[0] === "Issue") {
            return [
                {
                    columnHeader: { dataName: "", displayName: "" },
                    colWidthProportion: 0.2,
                    cellValue: (row, toggleAccordion, isOpen) => showAccordionToggle(isOpen, toggleAccordion)
                },
                { columnHeader: { dataName: "requestType", displayName: "Active Request" }, sort: true },
                { columnHeader: { dataName: "applicant", displayName: "Applicant" }, sort: true },
                { columnHeader: { dataName: "beneficiary", displayName: "Beneficiary" }, sort: true },
                { columnHeader: { dataName: "issuer", displayName: "Issuer" }, sort: true },
                {
                    columnHeader: { dataName: "amount", displayName: "Amount" },
                    cellValue: row => (row.amount ? `AUD ${numeral(row.amount / 100).format("0,0.00")}` : "N/A"),
                    sort: true
                },
                { columnHeader: { dataName: "createdBy", displayName: "Created By" }, sort: true },
                {
                    columnHeader: { dataName: "createdAt", displayName: "Request Date" },
                    sort: true
                }
            ]
        }
        return [
            {
                columnHeader: { dataName: "", displayName: "" },
                colWidthProportion: 0.2,
                cellValue: (row, toggleAccordion, isOpen) => showAccordionToggle(isOpen, toggleAccordion)
            },
            { columnHeader: { dataName: "requestType", displayName: "Active Request" }, sort: true },
            { columnHeader: { dataName: "status", displayName: "Status" }, sort: true },
            {
                columnHeader: { dataName: "amount", displayName: "Amount" },
                sort: true,
                cellValue: row => (row.amount ? `AUD ${numeral(row.amount / 100).format("0,0.00")}` : "N/A")
            },
            { columnHeader: { dataName: "createdBy", displayName: "Created By" }, sort: true },
            {
                columnHeader: { dataName: "createdAt", displayName: "Request Date" },
                sort: true
            }
        ]
    }
    getPendingGuarantees = () => {
        this.setState({ loading: true })
        return api.guarantee
            .getRequests({ status: "ACTIVE" })
            .then(({ data }) => {
                this.setState({
                    rows: mapRequestToTableValues(data.result, this.props.currentOrgId),
                    filteredRows: mapRequestToTableValues(data.result, this.props.currentOrgId),
                    loading: false
                })
                const gxSearchRequest = this.createGxSearchRequest()
                this.searchGuarantees(gxSearchRequest)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `There was an error getting your guarantee requests`,
                    title: "Guarantee Requests Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    getGuarantee = (searchQuery = "") =>
        api.guarantee
            .getGuarantee(searchQuery)
            .then(({ data }) => {
                console.log("Requests", data)
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `There was an error getting your search results`,
                    title: "Guarantee Search Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err,
                        Payload: searchQuery
                    }
                })
                throw err
            })
    searchQuery = searchValue => {
        if (searchValue !== "") {
            this.cancelableQuery = makeCancelable(this.getGuarantee(searchValue))
        } else {
            this.cancelableQuery = makeCancelable(this.getPendingGuarantees())
        }
    }
    searchGuarantees = (searchRequest?: GxSearchRequest = {}) => {
        this.setState({
            loading: true
        })
        const { rows } = this.state
        const newRows = rows.filter(item => {
            let match = true
            if (searchRequest.amountGreaterThan && item.amount / 100 < searchRequest.amountGreaterThan) {
                match = false
            }
            if (
                searchRequest.issuer &&
                ((item.issuer && item.issuer.toLowerCase() !== searchRequest.issuer) || !item.issuer)
            ) {
                match = false
            }
            if (
                searchRequest.requestType &&
                // $FlowFixMe
                ((item.requestType && item.requestType.toLowerCase() !== searchRequest.requestType.toLowerCase()) ||
                    !item.requestType)
            ) {
                match = false
            }

            if (searchRequest.amountSmallerThan && item.amount / 100 > searchRequest.amountSmallerThan) {
                match = false
            }
            if (searchRequest.issuedAfter && moment(item.orginialCreatedAt).isBefore(searchRequest.issuedAfter)) {
                match = false
            }
            if (searchRequest.issuedBefore && moment(item.orginialCreatedAt).isAfter(searchRequest.issuedBefore)) {
                match = false
            }
            if (searchRequest.applicantId && item.applicantId !== searchRequest.applicantId) {
                match = false
            }
            if (searchRequest.beneficiaryId && item.beneficiaryId !== searchRequest.beneficiaryId) {
                match = false
            }
            if (searchRequest.purposeType && item.purposeType !== searchRequest.purposeType) {
                match = false
            }

            return match
        })

        this.setState({
            loading: false,
            filteredRows: newRows
        })
    }
    createGxSearchRequest() {
        const { props } = this

        const gxSearchRequest: GxSearchRequest = {}
        if (props.filters) {
            if (props.filters.status) {
                // Note api will accept an array of statuses in the future
                gxSearchRequest.status = props.filters.status[0] // eslint-disable-line
            }
            if (props.filters.issuer) {
                // Note api will accept an array of statuses in the future
                gxSearchRequest.issuer = props.filters.issuer[0] // eslint-disable-line
            }
            if (props.filters.requestType) {
                // Note api will accept an array of statuses in the future
                gxSearchRequest.requestType = props.filters.requestType[0] // eslint-disable-line
            }
            gxSearchRequest.amountGreaterThan = props.filters.amountGreaterThan
            gxSearchRequest.amountSmallerThan = props.filters.amountSmallerThan

            if (props.filters.issuedAfter) {
                gxSearchRequest.issuedAfter = moment(props.filters.issuedAfter).toISOString()
            }
            if (props.filters.issuedBefore) {
                gxSearchRequest.issuedBefore = moment(props.filters.issuedBefore).toISOString()
            }
            if (props.filters.applicant) {
                gxSearchRequest.applicantId = props.filters.applicant.orgId
            }
            if (props.filters.beneficiary) {
                gxSearchRequest.beneficiaryId = props.filters.beneficiary.orgId
            }
            if (props.filters.purposeType) {
                gxSearchRequest.purposeType = props.filters.purposeType
            }
        }

        return gxSearchRequest
    }
    detailsRow = (row: Object) => {
        const {
            requestType,
            purpose,
            newBeneficiaries,
            applicant,
            beneficiary,
            amount,
            issuer,
            newExpiresAt,
            reason,
            purposeType
        } = row
        const { purposeTemplates } = this.state
        const classes = getClasses(this.props.theme)

        // bgDetailsDisplay shows the bg value, applicant, bene, new bene and issuer
        const bgDetailsDisplay = []
        if (applicant) {
            bgDetailsDisplay.push({ key: "Applicant", value: applicant })
        }
        if (beneficiary) {
            bgDetailsDisplay.push({
                key: requestType === "Transfer" ? "Current Beneficiary" : "Beneficiary",
                value: beneficiary
            })
        }
        if (requestType === "Transfer") {
            bgDetailsDisplay.push({ key: "New Beneficiary", value: newBeneficiaries[0].entityName })
        }
        if (issuer) {
            bgDetailsDisplay.push({ key: "Issuer", value: issuer })
        }
        if (amount) {
            bgDetailsDisplay.push({
                key: requestType === "Demand" ? "Demand Value" : "Value",
                value: `AUD ${numeral(amount / 100).format("0,0.00")}`
            })
        }
        // purposeDisplay shows the purpose including purposeType
        const purposeDisplay = []
        if (purposeType) {
            const currentTemplate = purposeTemplates.find(template => template.id === purposeType)
            if (currentTemplate) {
                purposeDisplay.push([{ key: "Purpose Type", value: currentTemplate.label }])
            } else {
                purposeDisplay.push([{ key: "Purpose Type", value: purposeType }])
            }
        }
        // Pushes all amend values from purpose with correct labels onto the sameline
        if (purpose) {
            purposeDisplay.push(purposeFormatMapping({ purposeTemplates, purposeType, purpose }))
        }
        const returnReason = () => {
            if (row.requestType === "Cancel" && reason) {
                return reason
            } else if (row.requestType === "Cancel" && !reason) {
                return "No reason given"
            }
            return ""
        }
        // reasonExpiryDisplay shows the expiry date and reason (if applicable)
        let reasonExpiryDisplay = []
        if (newExpiresAt || returnReason()) {
            reasonExpiryDisplay = [
                { key: newExpiresAt ? "Expiry" : null, value: newExpiresAt || null },
                { key: returnReason() ? "Reason" : null, value: returnReason() || null }
            ]
        }
        return (
            <div css={{ backgroundColor: "#fafafa", padding: "4px 24px" }}>
                <Typograpgy className={classes.detailsTitle}>
                    {row.requestType === "Amend" ? "Updated Information:" : null}{" "}
                </Typograpgy>
                <TimelineItemDetails
                    title=""
                    rows={[
                        bgDetailsDisplay,
                        // since purposeDisplay is an array of arrays it is destructured to match prop type. Nested arrays become new lines
                        ...purposeDisplay,
                        reasonExpiryDisplay
                    ]}
                />
            </div>
        )
    }

    render() {
        const { className, filters, replaceFilters, addFilter, removeFilter, removeFilters, user, theme } = this.props
        const { loading, filteredRows, issuers, purposeTemplates } = this.state
        return (
            <Grid gridGap="3un" className={className}>
                <Card>
                    <PageTitle
                        title={
                            // $FlowFixMe
                            <Flex>
                                <Flex flex="1">
                                    <span
                                        // eslint-disable-next-line
                                        tabIndex="0"
                                        id="main-content"
                                    >
                                        {user.actingOnBehalf ? `${user.actingOnBehalf.label} ` : ""}
                                        Pending Requests
                                    </span>
                                    <BGFilterContainer
                                        filters={filters}
                                        replaceFilters={replaceFilters}
                                        addFilter={addFilter}
                                        removeFilter={removeFilter}
                                        removeFilters={removeFilters}
                                        pendingGx
                                        issuers={issuers}
                                        purposeTemplates={purposeTemplates}
                                    />
                                </Flex>
                                <Flex>
                                    <ParentSubDropdown
                                        user={user}
                                        onChange={() => {
                                            const gxSearchRequest = this.createGxSearchRequest()
                                            return this.getPendingGuarantees().then(() => {
                                                this.searchGuarantees(gxSearchRequest)
                                            })
                                        }}
                                    />
                                </Flex>
                            </Flex>
                        }
                    />
                    <Block padding="3un">
                        <FlexAccordionTable
                            onRowSelection={this.onRowSelection}
                            columns={this.getColumns(filters.requestType)}
                            data={filteredRows}
                            loading={loading}
                            // defaultHiddenColumns={[]}
                            defaultSort={tableSortDefault}
                            accordion={this.detailsRow}
                            className={css(theme.typography.tableStyle)}
                        />
                    </Block>
                </Card>
            </Grid>
        )
    }
}

export default withTheme()(withError(withFilter(BGPendingListContainer)))
