let OnboardingReviewContainer // eslint-disable-line import/no-mutable-exports

if (PORTAL_TYPE === "admin") {
    OnboardingReviewContainer = require("./AdminOnboardingReviewContainer").default // eslint-disable-line global-require
} else {
    OnboardingReviewContainer = require("./MemberOnboardingReviewContainer").default // eslint-disable-line global-require
}

export default OnboardingReviewContainer
