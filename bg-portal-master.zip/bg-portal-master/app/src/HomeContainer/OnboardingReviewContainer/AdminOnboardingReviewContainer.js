// @flow

import * as React from "react"
import { Formik } from "formik"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import { Grid, Block } from "~/shared/layout"
import withError from "~/shared/Context/ErrorDialog/withError"
import api from "~/util/api"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import TitleCard from "./Components/TitleCard"
import OrganizationCard from "./Components/OrganizationCard"
import PrimaryContactCard from "./Components/PrimaryContactCard"
import AdminContactCard from "./Components/AdminContactCard"
import SubmitCard from "./Components/SubmitCard"
import VerifyActions from "./Components/VerifyActions"
import RejectDialog from "./Components/RejectDialog"
import AsicCard from "./Components/AsicCard"

type Props = {
    match: Object,
    handleErrorOpen: Function,
    history: Object
}

type State = {
    request?: Object,
    initialValues: {
        CompanyDetails: Object,
        PrimaryContact: Object,
        AdminContact: Object
    },
    rejectOpen: boolean
}

class AdminOnboardingReviewContainer extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        this.state = {
            request: undefined,
            initialValues: {
                CompanyDetails: { checkbox: false, actionId: "" },
                PrimaryContact: { checkbox: false, actionId: "" },
                AdminContact: { checkbox: false, actionId: "" }
            },
            rejectOpen: false
        }
    }

    componentDidMount() {
        this.getOnboardingRequest()
    }

    getOnboardingRequest = () => {
        api.onboarding
            .getOnboardingRequest(this.props.match.params.requestID)
            .then(({ data: request }) => {
                const actionIds = {
                    CompanyDetails: { checkbox: false, actionId: "" },
                    PrimaryContact: { checkbox: false, actionId: "" },
                    AdminContact: { checkbox: false, actionId: "" }
                }
                if (request.actions && request.actions.length >= 1) {
                    request.actions.forEach(item => {
                        if (item.actionType === "VERIFY") {
                            actionIds[item.payload.verifyObject] = { actionId: item.id, checkbox: true }
                        }
                        if (item.actionType === "REVOKE") {
                            actionIds[item.payload.verifyObject] = { actionId: "", checkbox: false }
                        }
                    })
                }

                this.setState({
                    request,
                    initialValues: actionIds
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Get onboarding request error`,
                    title: "Get Onboarding Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: this.props.match.params.requestID,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    inFlightVerifyRequests = {
        organization: null,
        primaryContact: null,
        adminContact: null
    }

    verify = (type: string, actionId: string, updateActionId: Function, setLoading: Function) => (value: boolean) => {
        let verifyRequest
        setLoading(true)
        if (!value) {
            verifyRequest = api.onboarding
                .revokeOnboardingRequest(this.props.match.params.requestID, type, actionId)
                .then(({ data }) => {
                    delete this.inFlightVerifyRequests[type]
                    setLoading(false)
                    return data
                })
                .catch(err => {
                    setLoading(false)
                    delete this.inFlightVerifyRequests[type]
                    this.props.handleErrorOpen({
                        errorMessage: `Revoke Onboarding Request Error`,
                        title: "Revoke Request Error",
                        error: err,
                        extraDetails: {
                            Info: err.info,
                            CurrentUrl: this.props.history.location.pathname,
                            Payload: { id: this.props.match.params.requestID, type, value },
                            ErrorResponse: err
                        }
                    })
                    throw err
                })
        } else {
            verifyRequest = api.onboarding
                .verifyOnboardingRequest(this.props.match.params.requestID, type)
                .then(({ data }) => {
                    delete this.inFlightVerifyRequests[type]
                    updateActionId(type, { actionId: data.id, checkbox: true })
                    setLoading(false)
                    return data
                })
                .catch(err => {
                    setLoading(false)
                    delete this.inFlightVerifyRequests[type]
                    this.props.handleErrorOpen({
                        errorMessage: `Verify Onboarding Request Error`,
                        title: "Verify Request Error",
                        error: err,
                        extraDetails: {
                            Info: err.info,
                            CurrentUrl: this.props.history.location.pathname,
                            Payload: { id: this.props.match.params.requestID, type, value },
                            ErrorResponse: err
                        }
                    })
                    throw err
                })
        }

        this.inFlightVerifyRequests[type] = verifyRequest
        return verifyRequest
    }

    reject = (reason: string) =>
        api.onboarding
            .rejectOnboardingRequest(this.props.match.params.requestID, reason)
            .then(resp => {
                this.handleRejectClose()

                this.getOnboardingRequest()
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Reject Onboarding error`,
                    title: "Reject Onboarding error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: this.props.match.params.requestID,
                        ErrorResponse: err
                    }
                })
                throw err
            })

    approve = async () => {
        try {
            // wait for all pending in flight requests
            await Promise.all(Object.values(this.inFlightVerifyRequests))
        } catch (error) {
            // Errors already handled by updateReviewed
        }
        return api.onboarding
            .approveOnboardingRequest(this.props.match.params.requestID)
            .then(resp => {
                this.getOnboardingRequest()
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Approval error`,
                    title: "Approval error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: this.props.match.params.requestID,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    handleRejectOpen = () => {
        this.setState({ rejectOpen: true })
    }

    handleRejectClose = () => {
        this.setState({ rejectOpen: false })
    }

    statusHide = (status: string) => status === "APPROVED" || status === "REJECTED" || status === "ABANDONED"
    render() {
        const { request, initialValues } = this.state

        if (!request) {
            return (
                <React.Fragment>
                    <Block padding="3un">
                        <LoadingCard />
                    </Block>
                </React.Fragment>
            )
        }
        const { profile } = request
        const primaryContact = profile.contacts.find(contact => contact.roles.includes("PRIMARY"))
        const primaryContactIsAdmin = primaryContact.roles.includes("ADMIN")
        const hasNonPrimaryAdmin = !primaryContactIsAdmin && profile.contacts.length > 1
        const adminContact = profile.contacts.find(contact => contact.roles.includes("ADMIN"))

        return (
            <React.Fragment>
                <TitleCard profile={profile} />
                <Block padding="3un">
                    <Formik
                        initialValues={initialValues}
                        onSubmit={(values, { setSubmitting, setErrors }) => {
                            setSubmitting(true)
                            this.approve()
                                .then(() => {
                                    setSubmitting(false)
                                })
                                .catch(err => {
                                    setSubmitting(false)
                                    this.props.handleErrorOpen({
                                        errorMessage: `Approval error`,
                                        title: "Approval error",
                                        error: err,
                                        extraDetails: {
                                            Info: err.info,
                                            CurrentUrl: this.props.history.location.pathname,
                                            Payload: this.props.match.params.requestID,
                                            ErrorResponse: err
                                        }
                                    })
                                })
                        }}
                        render={formikProps => (
                            <form onSubmit={formikProps.handleSubmit}>
                                <LoadingDialog
                                    open={formikProps.isSubmitting}
                                    loading={formikProps.isSubmitting}
                                    title="Submitting Confirmation request..."
                                />
                                <Grid gridGap="3un">
                                    <OrganizationCard profile={profile}>
                                        <React.Fragment>
                                            <AsicCard profile={profile} />
                                            <div hidden={this.statusHide(request.status)}>
                                                <VerifyActions
                                                    value="CompanyDetails"
                                                    label="I approve the organisation details"
                                                    formik={formikProps}
                                                    onChange={this.verify(
                                                        "CompanyDetails",
                                                        formikProps.values.CompanyDetails.actionId,
                                                        formikProps.setFieldValue,
                                                        formikProps.setSubmitting
                                                    )}
                                                />
                                            </div>
                                        </React.Fragment>
                                    </OrganizationCard>
                                    <PrimaryContactCard
                                        primaryContact={primaryContact}
                                        primaryContactIsAdmin={primaryContactIsAdmin}
                                    >
                                        <div hidden={this.statusHide(request.status)}>
                                            <VerifyActions
                                                value="PrimaryContact"
                                                label={
                                                    !hasNonPrimaryAdmin
                                                        ? "I approve the Primary Contact and Administrator details"
                                                        : "I approve the Primary Contact details"
                                                }
                                                formik={formikProps}
                                                onChange={this.verify(
                                                    "PrimaryContact",
                                                    formikProps.values.PrimaryContact.actionId,
                                                    formikProps.setFieldValue,
                                                    formikProps.setSubmitting
                                                )}
                                            />
                                        </div>
                                    </PrimaryContactCard>
                                    {hasNonPrimaryAdmin ? (
                                        <AdminContactCard adminContact={adminContact}>
                                            <div hidden={this.statusHide(request.status)}>
                                                <VerifyActions
                                                    value="AdminContact"
                                                    label="I approve the Administrator details"
                                                    formik={formikProps}
                                                    onChange={this.verify(
                                                        "AdminContact",
                                                        formikProps.values.AdminContact.actionId,
                                                        formikProps.setFieldValue,
                                                        formikProps.setSubmitting
                                                    )}
                                                />
                                            </div>
                                        </AdminContactCard>
                                    ) : null}
                                    <div hidden={this.statusHide(request.status)}>
                                        <SubmitCard
                                            formik={formikProps}
                                            disabled={
                                                (hasNonPrimaryAdmin && !formikProps.values.AdminContact.checkbox) ||
                                                !formikProps.values.PrimaryContact.checkbox ||
                                                !formikProps.values.CompanyDetails.checkbox
                                            }
                                            reject={this.handleRejectOpen}
                                        />
                                    </div>
                                </Grid>
                            </form>
                        )}
                    />
                    <RejectDialog
                        entityName={profile.entityName}
                        open={this.state.rejectOpen}
                        handleClose={this.handleRejectClose}
                        onSubmit={this.reject}
                    />
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(AdminOnboardingReviewContainer)
