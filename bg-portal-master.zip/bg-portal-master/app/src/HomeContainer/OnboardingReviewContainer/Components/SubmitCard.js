// @flow

import React from "react"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import Button from "@material-ui/core/Button"
import { withTheme } from "@material-ui/core/styles"

const getClasses = ({ theme }) => {
    const buttonContainer = css({
        textAlign: "right",
        marginTop: theme.spacing.unit * 2
    })
    const buttonStyle = css(theme.typography.button, {
        backgroundColor: "#edf2f9",
        margin: theme.spacing.unit * 2
    })

    const submitActionsTitle = css({
        display: "inline"
    })

    return {
        buttonContainer,
        buttonStyle,
        submitActionsTitle
    }
}

type Props = {
    theme: Object,
    reject: Function,
    formik: Object,
    disabled: boolean
}

const SubmitCard = ({ theme, reject, formik, disabled }: Props) => {
    const classes = getClasses({ theme })
    return (
        <Card>
            <CardContent className={classes.buttonContainer}>
                <Typography className={classes.submitActionsTitle}>Approve after reviewing details</Typography>
                <Button disabled={formik.isSubmitting} onClick={reject} className={classes.buttonStyle}>
                    Reject
                </Button>
                <Button disabled={formik.isSubmitting || disabled} type="submit" className={classes.buttonStyle}>
                    Approve
                </Button>
            </CardContent>
        </Card>
    )
}

export default withTheme()(SubmitCard)
