// @flow

import React from "react"
import { withTheme } from "@material-ui/core/styles"
import PageTitle from "~/shared/PageTitle"

type Props = {
    theme: Object,
    profile: Object
}

const TitleCard = ({ theme, profile }: Props) => (
    <PageTitle
        link="/onboardinglist"
        path="Onboarding List/"
        title={`Onboarding Request - '${profile.entityName}'`}
        theme={theme}
    />
)

export default withTheme()(TitleCard)
