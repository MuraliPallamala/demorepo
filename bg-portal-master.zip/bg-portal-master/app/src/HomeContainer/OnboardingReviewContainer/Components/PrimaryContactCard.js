// @flow

import React from "react"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import CardHeader from "@material-ui/core/CardHeader"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import { Grid } from "~/shared/layout"
import PhoneNumberTextMask from "~/shared/PhoneNumberTextMask"

const getClasses = ({ theme }) => {
    const title = css({
        paddingBottom: "0px",
        span: {
            fontSize: "1.2em",
            color: `${theme.palette.common.darkBlue}!important`
        }
    })
    const textContainer = css({
        overflowWrap: "break-word"
    })

    return {
        title,
        textContainer
    }
}

type Props = {
    theme: Object,
    primaryContact: Object,
    primaryContactIsAdmin: boolean,
    children?: Object // eslint-disable-line react/require-default-props
}

const PrimaryContactCard = ({ theme, primaryContact, primaryContactIsAdmin, children }: Props) => {
    const classes = getClasses({ theme })
    return (
        <Card>
            <CardHeader
                title={primaryContactIsAdmin ? "Primary Contact and Administrator" : "Primary Contact"}
                className={classes.title}
            />
            <CardContent>
                <Grid gridGap="3un">
                    {!primaryContactIsAdmin ? (
                        <Typography>
                            The Primary Contact will be the contact person for the account. We will send them a link to
                            their email to join in.
                        </Typography>
                    ) : null}
                    {primaryContactIsAdmin ? (
                        <Typography>
                            The Primary Contact will be the contact person for the account. We will send them a link to
                            their email to join in. As an Administrator, they will also be able to manage users, select
                            approval model, and manage the organisation details.
                        </Typography>
                    ) : null}
                    <Grid
                        gridGap="1un"
                        gridTemplateColumns="repeat(3, minmax(180px, 20%))"
                        className={classes.textContainer}
                    >
                        <Typography>Name</Typography>
                        <Typography>Email</Typography>
                        <Typography>Phone</Typography>
                        <Typography>{`${primaryContact.firstName} ${primaryContact.lastName}`}</Typography>
                        <Typography style={{ overflow: "hidden" }}>{primaryContact.email}</Typography>
                        <Typography>
                            <PhoneNumberTextMask value={primaryContact.phone} />
                        </Typography>
                    </Grid>
                </Grid>
            </CardContent>
            {children}
        </Card>
    )
}

export default withTheme()(PrimaryContactCard)
