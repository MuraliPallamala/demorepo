// @flow

import React from "react"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import CardHeader from "@material-ui/core/CardHeader"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import { Grid } from "~/shared/layout"
import { addressToString } from "~/util/helpers/text"

const getClasses = ({ theme }) => {
    const title = css({
        paddingBottom: "0px",
        span: {
            fontSize: "1.2em",
            color: `${theme.palette.common.darkBlue}!important`
        }
    })
    const textContainer = css({
        overflowWrap: "break-word"
    })

    return {
        title,
        textContainer
    }
}

type Props = {
    theme: Object,
    profile: Object,
    children?: Object // eslint-disable-line react/require-default-props
}

const OrganizationCard = ({ theme, profile, children }: Props) => {
    const classes = getClasses({ theme })
    return (
        <Card>
            <CardHeader title="Organisation Details" className={classes.title} />
            <CardContent>
                <Grid
                    gridGap="1un"
                    gridTemplateColumns="minmax(180px, 20%) minmax(300px, 40%) minmax(180px, 20%)"
                    className={classes.textContainer}
                >
                    <Typography>Legal Entity Name</Typography>
                    <Typography>Registered Address</Typography>
                    <Typography>
                        {profile.businessId.replace(/\s/g, "").length === 9 ? "ACN Number" : "ABN Number"}
                    </Typography>
                    <Typography>{profile.entityName}</Typography>
                    <Typography>{addressToString(profile.entityAddress)} </Typography>
                    <Typography>{profile.businessId}</Typography>
                </Grid>
            </CardContent>
            {children}
        </Card>
    )
}

export default withTheme()(OrganizationCard)
