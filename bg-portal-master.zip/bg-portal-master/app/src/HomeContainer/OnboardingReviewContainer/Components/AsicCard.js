// @flow

import React from "react"
import { css } from "emotion"
import CardHeader from "@material-ui/core/CardHeader"
import Button from "@material-ui/core/Button"
import Loading from "~/shared/Loading"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import { Grid, Flex } from "~/shared/layout"
import { addressToString } from "~/util/helpers/text"
import api from "~/util/api"
import { asicMap } from "~/util/asics"

const getClasses = ({ theme }) => {
    const title = css({
        paddingBottom: "0px",
        span: {
            fontSize: "1.2em",
            color: `${theme.palette.common.darkBlue}!important`
        }
    })
    const textContainer = css({
        overflowWrap: "break-word"
    })
    const button = css(theme.typography.button, { color: theme.palette.common.darkBlue })
    return {
        title,
        textContainer,
        button
    }
}

type Props = {
    theme: Object,
    profile: Object
}

type State = {
    asicInfo: Object,
    loading: boolean
}

class AsicCard extends React.Component<Props, State> {
    constructor(props) {
        super(props)

        this.state = {
            asicInfo: {},
            loading: false
        }
    }
    getAsicInfo = () => {
        const { businessId } = this.props.profile
        this.setState({ loading: true })
        const searchBusinessId = businessId
            .split("_")
            .pop()
            .replace(/\s/g, "")
        if (searchBusinessId.length === 9) {
            return api.asics
                .searchAsicsAcn(searchBusinessId)
                .then(({ data }) => {
                    const orgInfo = data.result.pop()
                    return orgInfo
                })
                .catch(err => {
                    // let form catch error
                    throw err
                })
        }
        return api.asics
            .searchAsicsAbn(businessId.replace(/\s/g, ""))
            .then(({ data }) => {
                const orgInfo = data.result.pop()
                this.setState({ asicInfo: asicMap(orgInfo), loading: false })
            })
            .catch(err => {
                // let form catch error
                throw err
            })
    }

    renderContents = (asicInfo: Object, loading: boolean, classes: Object) => {
        const { profile } = this.props
        const { businessId } = profile
        const searchBusinessId = businessId
            .split("_")
            .pop()
            .replace(/\s/g, "")
        if (loading) {
            return (
                <Flex justifyContent="center">
                    <Loading show size={50} />
                </Flex>
            )
        }
        if (asicInfo.addressCountry && !loading) {
            return (
                <Grid
                    gridGap="1un"
                    gridTemplateColumns="minmax(180px, 20%) minmax(300px, 40%) minmax(180px, 20%)"
                    className={classes.textContainer}
                >
                    <Typography>Legal Entity Name</Typography>
                    <Typography>Registered Address</Typography>
                    <Typography>{searchBusinessId.length === 9 ? "ACN Number" : "ABN Number"}</Typography>
                    <Typography>{asicInfo.entityName}</Typography>
                    <Typography>{addressToString(asicInfo)} </Typography>
                    <Typography>{searchBusinessId}</Typography>
                </Grid>
            )
        }
        return (
            <Button onClick={this.getAsicInfo} className={classes.button}>
                Get Details from ASIC
            </Button>
        )
    }
    render() {
        const { theme } = this.props
        const classes = getClasses({ theme })
        const { asicInfo, loading } = this.state
        return (
            <React.Fragment>
                <CardHeader title="Details from ASIC" className={classes.title} />
                <CardContent>{this.renderContents(asicInfo, loading, classes)}</CardContent>
            </React.Fragment>
        )
    }
}

export default withTheme()(AsicCard)
