// @flow

import React from "react"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import CardHeader from "@material-ui/core/CardHeader"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import { withTheme } from "@material-ui/core/styles"
import ConfirmationCodeButton from "~/shared/ConfirmationCodeButton"
import { Flex } from "~/shared/layout"

const getClasses = ({ theme }) => {
    const title = css({
        paddingBottom: "0px",
        span: {
            fontSize: "1.2em",
            color: `${theme.palette.common.darkBlue}!important`
        }
    })
    const buttonStyle = css(theme.typography.button, {
        backgroundColor: "#edf2f9",
        margin: theme.spacing.unit * 2
    })

    return {
        title,
        buttonStyle
    }
}

type Props = {
    theme: Object,
    confirmationCode: string,
    onRequestCode: Function
}

const PinCard = ({ theme, confirmationCode, onRequestCode }: Props) => {
    const classes = getClasses({ theme })
    return (
        <Card>
            <CardHeader title="Confirmation PIN" className={classes.title} />
            <CardContent>
                <Flex>
                    <Flex flex="1">
                        <Typography>Applicant/Beneficiary Confirmation PIN</Typography>
                    </Flex>
                    <Flex>
                        <ConfirmationCodeButton
                            confirmationCode={confirmationCode}
                            text="Confirmation PIN"
                            onRequestCode={() => onRequestCode()}
                        />
                    </Flex>
                </Flex>
            </CardContent>
        </Card>
    )
}

export default withTheme()(PinCard)
