// @flow

import React from "react"
import DialogContentText from "@material-ui/core/DialogContentText"
import TextField from "@material-ui/core/TextField"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"

type Props = {
    entityName: string,
    onSubmit: Function,
    handleClose: Function,
    open: boolean
}

type State = {
    reason: string
}

class RejectDialog extends React.Component<Props, State> {
    state = {
        reason: ""
    }

    onReasonChange = (e: SyntheticInputEvent<>) => {
        this.setState({
            reason: e.target.value
        })
    }

    render() {
        const { entityName, onSubmit, ...otherProps } = this.props
        return (
            <CustomRequestDialog
                {...otherProps}
                onSubmit={() => onSubmit(this.state.reason)}
                submitText="PROCEED WITH REJECTION"
                renderTitle={() => `Reject '${entityName}' Application`}
                renderContent={() => (
                    <div>
                        <DialogContentText>Please provide a justification for rejection.</DialogContentText>
                        <TextField
                            name="reason"
                            onChange={this.onReasonChange}
                            placeholder="Optional Explanation"
                            label="Optional Explanation"
                        />
                    </div>
                )}
            />
        )
    }
}

export default RejectDialog
