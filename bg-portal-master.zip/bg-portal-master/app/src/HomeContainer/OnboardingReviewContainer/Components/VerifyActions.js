// @flow

import React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import CardActions from "@material-ui/core/CardActions"
import Checkbox from "@material-ui/core/Checkbox"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import Typography from "@material-ui/core/Typography"

const getClasses = ({ theme, checked }) => {
    const verifyCardActions = css({
        backgroundColor: checked ? undefined : "#F0FFFD"
    })
    const textStyle = css({
        color: theme.palette.common.darkBlue
    })

    return {
        verifyCardActions,
        textStyle
    }
}

type Props = {
    theme: Object,
    label: string,
    value: string,
    formik: Object,
    onChange: Function
}

const VerifyActions = ({ theme, label, value, formik, onChange }: Props) => {
    const formikChecked = formik.values[value].checkbox
    const classes = getClasses({ theme, checked: formikChecked })
    return (
        <CardActions className={classes.verifyCardActions}>
            <FormControlLabel
                control={
                    <Checkbox
                        onChange={e => {
                            const { checked } = e.target
                            formik.setFieldValue(value, { checkbox: checked, actionId: formik.values[value].actionId })
                            onChange(checked).catch(error => {
                                // revert update on error
                                // NOTE will probably lead to weird results if user is spamming and server is slow
                                formik.setFieldValue(value, {
                                    chackbox: !checked,
                                    actionId: formik.values[value].actionId
                                })
                            })
                        }}
                        disabled={formik.isSubmitting}
                        value={value}
                        checked={formikChecked}
                    />
                }
                label={<Typography className={classes.textStyle}>{label}</Typography>}
            />
        </CardActions>
    )
}

export default withTheme()(VerifyActions)
