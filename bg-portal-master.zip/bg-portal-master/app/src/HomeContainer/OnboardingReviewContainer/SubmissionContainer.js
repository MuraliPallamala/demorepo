// @flow

import * as React from "react"
import LoadingCard from "~/shared/BasicCards/LoadingCard"

import { Grid, Block } from "~/shared/layout"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"

import PageTitle from "~/shared/PageTitle"
import PinCard from "./Components/PinCard"
import OrganizationCard from "./Components/OrganizationCard"
import PrimaryContactCard from "./Components/PrimaryContactCard"
import AdminContactCard from "./Components/AdminContactCard"

type Props = {
    match: Object,
    theme: Object,
    handleErrorOpen: Function,
    history: Object
}

type State = {
    request?: Object,
    confirmationCode: string
}

class SubmissionContainer extends React.Component<Props, State> {
    state = {
        request: undefined,
        confirmationCode: "****"
    }

    componentDidMount() {
        api.onboarding
            .getOnboardingRequest(this.props.match.params.requestID)
            .then(({ data: request }) => {
                this.setState({
                    request
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Get onboarding request error`,
                    title: "Get Onboarding Request Error",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        CurrentUrl: this.props.history.location.pathname,
                        Payload: this.props.match.params.requestID,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    onRequestCode = () => {
        const { request, confirmationCode } = this.state
        if (!request) {
            throw new Error("Request not loaded yet")
        }
        if (confirmationCode === "****") {
            this.setState({ confirmationCode: request.credentials.token })
        } else this.setState({ confirmationCode: "****" })
    }

    render() {
        const { theme } = this.props
        const { request, confirmationCode } = this.state
        if (!request) {
            return (
                <React.Fragment>
                    <PageTitle link="/onboardinglist" path="Onboarding Requests/" title="New Request" theme={theme} />
                    <Block padding="3un">
                        <Grid gridGap="3un">
                            <LoadingCard />
                        </Grid>
                    </Block>
                </React.Fragment>
            )
        }

        const { profile } = request

        const primaryContact = profile.contacts.find(contact => contact.roles.includes("PRIMARY"))
        const primaryContactIsAdmin = primaryContact.roles.includes("ADMIN")
        const hasNonPrimaryAdmin = !primaryContactIsAdmin && profile.contacts.length > 1
        const adminContact = profile.contacts.find(contact => contact.roles.includes("ADMIN"))

        return (
            <React.Fragment>
                <PageTitle link="/onboardinglist" path="Onboarding Requests/" title="New Request" theme={theme} />
                <Block padding="3un">
                    <Grid gridGap="3un">
                        <PinCard confirmationCode={confirmationCode} onRequestCode={() => this.onRequestCode()} />
                        <OrganizationCard profile={profile} />
                        <PrimaryContactCard
                            primaryContact={primaryContact}
                            primaryContactIsAdmin={primaryContactIsAdmin}
                        />
                        {hasNonPrimaryAdmin ? <AdminContactCard adminContact={adminContact} /> : null}
                    </Grid>
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(SubmissionContainer)
