/* eslint-disable import/prefer-default-export */

import generateTheme from "./theme"

export { generateTheme }
