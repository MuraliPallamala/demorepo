const specificNormalLib = require(`./${PORTAL_TYPE}/${PORTAL_ORG}`) //eslint-disable-line
export default specificNormalLib
