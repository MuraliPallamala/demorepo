// @flow

import blue from "@material-ui/core/colors/blue"
import grey from "@material-ui/core/colors/grey"

import getUserTheme from "~/util/ui/getUserTheme"

function getCustomConfig(pageType?: string) {
    let colors = {
        primary: {
            main: "#000",
            dark: "#000",
            headerBottom: "#f9c623",
            headerMain: "#ffffff",
            contrastText: "#000"
        },
        secondary: blue
    }
    const overrides = { imgWidth: "150px", sideBarHighlight: colors.primary.headerBottom }
    if (pageType === "settings") {
        colors = {
            primary: grey,
            secondary: blue
        }
    }
    return {
        colors,
        overrides
    }
}

export default (pageType?: string) => getUserTheme(getCustomConfig(pageType))
