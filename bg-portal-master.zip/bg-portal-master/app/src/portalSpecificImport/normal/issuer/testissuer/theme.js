// @flow

import blue from "@material-ui/core/colors/blue"
import grey from "@material-ui/core/colors/grey"

import getUserTheme from "~/util/ui/getUserTheme"

function getCustomConfig(pageType?: string) {
    let colors = {
        primary: {
            main: "#711731",
            dark: "#500b20",
            headerMain: "#000",
            headerBottom: "#BE0F00",
            contrastText: "#E1F1FE"
        },
        secondary: blue
    }
    const overrides = { imgWidth: "100px", sideBarHighlight: colors.primary.headerBottom }
    if (pageType === "settings") {
        colors = {
            primary: grey,
            secondary: blue
        }
    }
    return {
        colors,
        overrides
    }
}

export default (pageType?: string) => getUserTheme(getCustomConfig(pageType))
