// @flow

import blue from "@material-ui/core/colors/blue"
import grey from "@material-ui/core/colors/grey"

import getUserTheme from "~/util/ui/getUserTheme"

function getCustomConfig(pageType?: string) {
    let colors = {
        primary: {
            main: "#01456c",
            dark: "#003755",
            contrastText: "#E1F1FE",
            headerBottom: "#0972B5",
            headerMain: "#003755"
        },
        secondary: grey
    }
    const overrides = { imgWidth: "80px" }
    if (pageType === "settings") {
        colors = {
            primary: grey,
            secondary: blue
        }
    }
    return {
        colors,
        overrides
    }
}

export default (pageType?: string) => getUserTheme(getCustomConfig(pageType))
