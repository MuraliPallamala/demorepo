// @flow

import * as React from "react"

import api from "~/util/api"
import { mapFormValuesAndTCsToRequest, onboardingDefaultValues } from "~/util/onboarding"
import OnboardingHeader from "~/HomeContainer/HeaderContainer/HeaderContainer"
import OnboardingFlowStepper from "~/shared/Onboarding/Flow/OnboardingFlowStepper"
import { Block } from "~/shared/layout"
import withError from "~/shared/Context/ErrorDialog/withError"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import UserOnboarding from "./UserOnboarding"

type Props = {
    history: Object,
    initialValues: Object,
    referred: boolean,
    requestKey: string,
    pin: string,
    match: Object,
    handleErrorOpen: Function,
    loading: boolean
}

type State = {
    stage: number,
    values: Object,
    platformTC: ?Object,
    userTC: ?Object,
    submitting: boolean
}

const onboardingFlows = ["Consent Form", "Review Details", "Set Password"]

class UserOnbordingContainer extends React.Component<Props, State> {
    static defaultProps = {
        initialValues: {},
        referred: false
    }

    constructor(props: Props) {
        super(props)
        this.state = {
            stage: 0,
            values: {
                ...onboardingDefaultValues,
                ...props.initialValues
            },
            platformTC: null,
            userTC: null,
            submitting: false
        }
    }

    componentDidMount() {
        Promise.all(
            ["PLATFORM", "USER"].map(tcType =>
                api.termsAndConditions.getTCsByType(tcType).then(data => {
                    console.log("TCs returned by type:")
                    console.log(JSON.stringify(data))
                    const termsAndConditions = data.filter(
                        tc => tc.title.includes("Platform User Terms") || tc.title.includes("Consent Form")
                    )
                    if (termsAndConditions.length > 0) {
                        const tcRecord = termsAndConditions[0]
                        console.log(tcRecord)
                        return api.termsAndConditions.getTCDocumentById(tcRecord.id, tcRecord.title)
                    }
                    throw new Error("Error: Unable to retrieve TC")
                })
            )
        )
            .then(([platformTC, userTC]) => {
                this.setState({
                    platformTC,
                    userTC
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Getting T&C Error`,
                    title: "Getting T&C Error",
                    error: err,
                    extraDetails: {
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
        window.addEventListener("beforeunload", this.onUnload)
    }

    componentWillUnmount() {
        window.removeEventListener("beforeunload", this.onUnload)
    }
    onUnload = event => {
        // the method that will be used for both add and remove event
        event.returnValue = "Data will be lost if you leave the page, are you sure?"
    }

    onPrev = () => {
        this.setState({
            stage: this.state.stage - 1
        })
    }

    onNext = (values?: Object = {}) => {
        this.setState({
            values: {
                ...this.state.values,
                ...values
            },
            stage: this.state.stage + 1
        })
    }

    submitSelfOnboardingRequest = (values: Object) => {
        const { requestKey, pin } = this.props
        const endpoint = this.props.referred
            ? api.onboarding.updateOnboardingRequest // is this the same endpoint?
            : api.onboarding.submitSelfOnboardingRequest // is this the same endpoint?

        const { platformTC, userTC } = this.state

        if (!platformTC || !userTC) {
            throw new Error("Error: Unable to retrieve TC")
        }

        // submitOnboardingRequest (^) will ignore requestKey and pin
        return endpoint(mapFormValuesAndTCsToRequest(values, platformTC.id, userTC.id), requestKey, pin)
            .then(({ data }) => {
                this.setState({
                    stage: this.state.stage + 1
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: this.props.referred
                        ? "Error Updating Onboarding Request"
                        : "Error Submitting Onboarding Request",
                    title: "Getting Onboarding Error",
                    error: err,
                    extraDetails: {
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    rejectTC = () => {
        const { referred, pin } = this.props
        const { requestKey } = this.props.match.params
        this.setState({
            submitting: true
        })
        if (referred) {
            api.onboarding
                .cancelApplication(requestKey, pin)
                .then(resp => this.exitToLogin())
                .catch(err => {
                    console.log("Error", err)
                    this.setState({
                        submitting: false
                    })
                })
        } else {
            this.exitToLogin()
        }
    }

    exitToLogin = () => {
        const { history } = this.props
        history.push("/login")
    }

    render() {
        const { referred, match, history, loading } = this.props
        const { stage, values, platformTC, userTC, submitting } = this.state
        return (
            <React.Fragment>
                <LoadingDialog open={submitting} loading={submitting} title="Abandoning user onboarding..." />
                <OnboardingHeader onboarding />
                <Block padding="3un">
                    <OnboardingFlowStepper labels={onboardingFlows} stage={stage} />
                    <UserOnboarding
                        loading={loading}
                        history={history}
                        match={match}
                        stage={stage}
                        onPrev={this.onPrev}
                        onNext={this.onNext}
                        rejectTC={() => this.rejectTC}
                        referred={referred}
                        exitToLogin={this.exitToLogin}
                        onSubmit={this.submitSelfOnboardingRequest}
                        pin={this.props.pin}
                        values={values}
                        platformTC={platformTC}
                        userTC={userTC}
                        submitting={submitting}
                        emailsError={this.props.handleErrorOpen}
                        initialValues={this.props.initialValues}
                    />
                </Block>
            </React.Fragment>
        )
    }
}

export default withError(UserOnbordingContainer)
