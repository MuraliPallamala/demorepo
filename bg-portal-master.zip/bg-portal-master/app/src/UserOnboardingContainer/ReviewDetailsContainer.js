// @flow

import * as React from "react"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import { withTheme } from "@material-ui/core/styles"
import { Grid, Block } from "~/shared/layout"
import CardActions from "@material-ui/core/CardActions"
import Button from "@material-ui/core/Button"
import ProfileDetailsFormContainer from "~/shared/Forms/ProfileDetailsFormContainer/ProfileDetailsFormContainer"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"

type Props = {
    theme: Object,
    onNext: Function,
    initialValues: Object,
    match: Object,
    pin: string,
    handleErrorOpen: Function,
    loading: boolean,
    history: Object
}

type State = {
    edit: boolean,
    primaryInitialValues: Object
}

const getClasses = theme => {
    const actionsContainer = css({
        justifyContent: "flex-end"
    })
    const buttonStyle = css(theme.typography.button)

    return {
        actionsContainer,
        buttonStyle
    }
}

class ReviewDetailsContainer extends React.Component<Props, State> {
    static defaultProps = {
        initialValues: {}
    }
    constructor(props) {
        super(props)
        this.state = {
            edit: false,
            primaryInitialValues: {
                primaryFirstName: this.props.initialValues.firstName,
                primaryLastName: this.props.initialValues.lastName,
                primaryEmail: this.props.initialValues.userEmail,
                primaryPhone: this.props.initialValues.phone
            }
        }
    }

    submitForm = values => {
        const { requestKey } = this.props.match.params
        const { pin } = this.props
        const request = {
            firstName: values.primaryFirstName,
            lastName: values.primaryLastName,
            phone: `+${values.primaryPhone}`
        }
        return api.onboarding
            .updateOnboardingUserDetails(request, requestKey, pin)
            .then(data => {
                this.setState({
                    primaryInitialValues: data
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: "Error getting user Profile",
                    title: "Error getting user profile",
                    error: err,
                    extraDetails: {
                        Info: err.info,
                        Payload: { request, requestKey, pin },
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    edit = () => {
        this.state.edit ? this.setState({ edit: false }) : this.setState({ edit: true })
    }

    render() {
        const classes = getClasses(this.props.theme)
        const { primaryInitialValues } = this.state
        return (
            <Grid gridGap="3un">
                <Block padding="3un">
                    <Grid gridGap="3un">
                        <ProfileDetailsFormContainer
                            initialValues={primaryInitialValues}
                            onSubmit={this.submitForm}
                            loading={this.props.loading}
                            hideEdit
                            displayUpdateProfile={false}
                        />
                        <Card>
                            <CardActions className={classes.actionsContainer}>
                                <Button
                                    disabled={this.state.edit}
                                    onClick={this.props.onNext}
                                    className={classes.buttonStyle}
                                >
                                    NEXT PASSWORD SETUP
                                </Button>
                            </CardActions>
                        </Card>
                    </Grid>
                </Block>
            </Grid>
        )
    }
}

export default withError(withTheme()(ReviewDetailsContainer))
