// @flow

import React from "react"
import TCStageContainer from "~/shared/Onboarding/Flow/Stages/TCStageContainer"
import ReviewDetailsContainer from "./ReviewDetailsContainer"
import UserSetPasswordContainer from "./UserSetPasswordContainer"

type Props = {
    referred: boolean,
    rejectTC: Function,
    stage: number,
    values: Object,
    onNext: Function,
    onPrev: Function,
    onSubmit: Function,
    exitToLogin: Function,
    pin: string,
    userTC: ?Object,
    emailsError: Function,
    submitting: boolean,
    match: Object,
    initialValues: Object,
    history: Object,
    loading: boolean
}

const UserOnboarding = ({
    referred,
    rejectTC,
    stage,
    values,
    onNext,
    onPrev,
    onSubmit,
    exitToLogin,
    pin,
    userTC,
    emailsError,
    submitting,
    match,
    initialValues,
    history,
    loading
}: Props) =>
    [
        () => (
            <TCStageContainer
                title="Review and Accept Consent Form"
                tc={userTC}
                // TODO Fix with actual type
                type="userTC"
                onExit={rejectTC()}
                onNext={() => onNext()}
                submitting={submitting}
            />
        ),
        () => (
            <ReviewDetailsContainer
                onNext={onNext}
                pin={pin}
                match={match}
                initialValues={initialValues}
                loading={loading}
            />
        ),
        () => <UserSetPasswordContainer history={history} pin={pin} match={match} userEmail={initialValues.userEmail} />
    ][stage]()

export default UserOnboarding
