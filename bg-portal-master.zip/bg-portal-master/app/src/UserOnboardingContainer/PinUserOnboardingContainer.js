// @flow

import React from "react"

import api from "~/util/api"
import EnterPin from "~/EnterPin/EnterPin"
import withError from "~/shared/Context/ErrorDialog/withError"
import CardErrorBoundary from "~/shared/CardErrorBoundary"
import UserOnboardingContainer from "./UserOnboardingContainer"
import SetPasswordContainer from "../SetPasswordContainer/SetPasswordContainer"

type Props = {
    match: Object,
    history: Object,
    handleErrorOpen: Function
}

type State = {
    initialValues: ?Object,
    pin: string,
    userType: string,
    profileUser: ?Object,
    loading: boolean
}

class PinUserOnboardingContainer extends React.Component<Props, State> {
    state = {
        loading: true,
        profileUser: null,
        initialValues: null,
        userType: "",
        pin: "0"
    }

    getProfileAndUser = (pin: string) => {
        const { requestKey } = this.props.match.params
        return api.onboarding
            .getProfileAndUser(requestKey, pin)
            .then(({ data: profileUser }) => {
                const { user } = profileUser
                const key = Object.keys(profileUser.user.userRoles)

                const initialValues = {
                    userEmail: user.email,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    phone: user.phone
                }
                // Key[0] is the first organisation in the users userroles list. It is assumed that there can only be one organisation at this point
                this.setState({
                    pin,
                    userType: profileUser.user.userRoles[key[0]],
                    profileUser,
                    initialValues,
                    loading: false
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Error getting User Profile`,
                    title: `Get User Profile Error`,
                    error: err,
                    extraDetails: {
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                this.setState({
                    loading: false
                })
                throw err
            })
    }

    render() {
        const { userType } = this.state
        let content
        if (userType.includes("ADMIN") || userType.includes("PRIMARY")) {
            content = (
                <SetPasswordContainer
                    history={this.props.history}
                    requestKey={this.props.match.params.requestKey}
                    match={this.props.match}
                    pin={this.state.pin}
                    profileUser={this.state.profileUser}
                />
            )
        } else {
            content = (
                <UserOnboardingContainer
                    referred
                    initialValues={this.state.initialValues}
                    history={this.props.history}
                    requestKey={this.props.match.params.requestKey}
                    userid={this.props.match.params.userid}
                    pin={this.state.pin}
                    match={this.props.match}
                    loading={this.state.loading}
                />
            )
        }

        return (
            <React.Fragment>
                {!userType ? (
                    <EnterPin
                        verify={this.getProfileAndUser}
                        title="Enter your Confirmation PIN"
                        message="You received this PIN during Onboarding Confirmation"
                    />
                ) : (
                    <CardErrorBoundary message="Error: bad payload, profile contact email doesn't match up with user email">
                        <React.Fragment>{content}</React.Fragment>
                    </CardErrorBoundary>
                )}
            </React.Fragment>
        )
    }
}

export default withError(PinUserOnboardingContainer)
