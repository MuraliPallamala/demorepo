// @flow

import * as React from "react"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import { withTheme } from "@material-ui/core/styles"
import { Grid, Block } from "~/shared/layout"
import SetPasswordForm from "~/shared/Forms/SetPasswordForm"
import CardActions from "@material-ui/core/CardActions"
import Button from "@material-ui/core/Button"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import BookmarkDialog from "~/shared/Dialogs/BookmarkDialog/BookmarkDialog"

type Props = {
    theme: Object,
    userEmail: string,
    match: Object,
    pin: string,
    handleErrorOpen: Function,
    history: Object
}

type State = {
    passwordSet: boolean,
    finishDialogOpen: boolean,
    pwUpdated: boolean
}

const getClasses = theme => {
    const actionsContainer = css({
        justifyContent: "flex-end"
    })
    const buttonStyle = css(theme.typography.button)

    const buttonColor = css({
        color: theme.typography.button.color
    })
    const textColor = css({
        color: theme.typography.cardTitle.color
    })

    return {
        actionsContainer,
        buttonStyle,
        buttonColor,
        textColor
    }
}

class UserSetPasswordContainer extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        this.state = {
            passwordSet: false,
            finishDialogOpen: false,
            pwUpdated: false
        }
    }

    submitPassword = ({ password }: Object) => {
        const { requestKey } = this.props.match.params
        const { pin } = this.props

        return api.onboarding
            .setUserPassword(requestKey, pin, password)
            .then(resp => {
                this.setState({
                    passwordSet: true,
                    pwUpdated: true
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Set Password Error`,
                    title: `Set Password Error`,
                    error: err,
                    extraDetails: {
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    openFinishDialog = () => this.setState({ finishDialogOpen: true })

    closeFinishDialog = () => this.setState({ finishDialogOpen: false })

    render() {
        const classes = getClasses(this.props.theme)
        const { history, match } = this.props
        return (
            <React.Fragment>
                <Grid gridGap="3un">
                    <Block padding="3un">
                        <Grid gridGap="3un">
                            <Card>
                                <CardContent>
                                    <SetPasswordForm
                                        headerText="Set password"
                                        onSubmit={this.submitPassword}
                                        userEmail={this.props.userEmail}
                                        setMode
                                        passwordSet={this.state.passwordSet}
                                        pwUpdated={this.state.pwUpdated}
                                        hideEdit
                                    />
                                </CardContent>
                            </Card>
                            <Card>
                                <CardActions className={classes.actionsContainer}>
                                    <Button
                                        disabled={!this.state.passwordSet}
                                        onClick={this.openFinishDialog}
                                        className={classes.buttonStyle}
                                    >
                                        FINISH
                                    </Button>
                                </CardActions>
                            </Card>
                        </Grid>
                    </Block>
                </Grid>
                <BookmarkDialog
                    finishDialogOpen={this.state.finishDialogOpen}
                    closeFinishDialog={this.closeFinishDialog}
                    match={match}
                    history={history}
                />
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(UserSetPasswordContainer))
