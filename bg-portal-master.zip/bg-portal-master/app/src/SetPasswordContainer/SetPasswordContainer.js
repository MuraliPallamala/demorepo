// @flow

import * as React from "react"

import { withTheme } from "@material-ui/core/styles"
import TCStageContainer from "~/shared/Onboarding/Flow/Stages/TCStageContainer"
import OnboardingHeader from "~/HomeContainer/HeaderContainer/HeaderContainer"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"

import api from "~/util/api"
import BookmarkDialog from "~/shared/Dialogs/BookmarkDialog/BookmarkDialog"
import withError from "~/shared/Context/ErrorDialog/withError"
import SetPassword from "./SetPassword"

type Props = {
    history: Object,
    match: Object,
    theme: Object,
    handleErrorOpen: Function,
    profileUser: Object,
    pin: string
}

type State = {
    passwordSet: boolean,
    userTC: ?Object,
    tcSigned: boolean,
    finishDialogOpen: boolean,
    pwUpdated: boolean,
    submitting: boolean
}

class SetPasswordContainer extends React.Component<Props, State> {
    static extractUserContact(profileUser: Object): Object {
        const { profile, user } = profileUser
        const userEmail = user.email.toLowerCase()
        const userContact = profile.contacts.find(contact => contact.email.toLowerCase() === userEmail)

        if (!userContact) {
            throw new Error("Error: bad payload, profile contact email doesn't match up with user email")
        }
        return userContact
    }

    state = {
        passwordSet: false,
        userTC: {},
        tcSigned: this.props.profileUser.user.agreement,
        finishDialogOpen: false,
        pwUpdated: false,
        submitting: false
    }

    componentDidMount() {
        if (!this.props.profileUser.user.agreement) {
            api.termsAndConditions
                .getTCsByType("USER")
                .then(data => {
                    const termsAndConditions = data.filter(tc => tc.title.includes("Consent Form"))
                    if (termsAndConditions.length > 0) {
                        const tcRecord = termsAndConditions[0]
                        return api.termsAndConditions.getTCDocumentById(tcRecord.id, tcRecord.title)
                    }
                    throw new Error("Error: Unable to retrieve TC")
                })
                .then(userTC => {
                    this.setState({
                        userTC
                    })
                })
                .catch(err => {
                    this.props.handleErrorOpen({
                        errorMessage: `Getting T&C Error`,
                        title: "Getting T&C Error",
                        error: err,
                        extraDetails: {
                            CurrentUrl: this.props.history.location.pathname,
                            Payload: "USER",
                            ErrorResponse: err
                        }
                    })
                    throw err
                })
        }
        window.addEventListener("beforeunload", this.onUnload)
    }

    componentWillUnmount() {
        window.removeEventListener("beforeunload", this.onUnload)
    }
    onUnload = event => {
        // the method that will be used for both add and remove event
        event.returnValue = "Data will be lost if you leave the page, are you sure?"
    }

    openFinishDialog = () => this.setState({ finishDialogOpen: true })

    closeFinishDialog = () => this.setState({ finishDialogOpen: false })

    rejectTC = () => {
        api.onboarding
            .cancelApplication(this.props.match.params.requestKey, this.props.pin)
            .then(resp => this.props.history.push("/login"))
            .catch(err => {
                console.log(err)
                this.setState({
                    submitting: false
                })
            })
    }

    acceptTC = () => {
        const { requestKey } = this.props.match.params
        const { pin } = this.props
        const { userTC } = this.state
        if (!userTC) {
            throw new Error("Error userTC not loaded")
        }
        return api.onboarding
            .setUserTC(requestKey, pin, userTC.id)
            .then(() => {
                this.setState({
                    tcSigned: true
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Failed to accept T&C`,
                    title: "Accepting T&C Error",
                    error: err,
                    extraDetails: {
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    submitPassword = ({ password }: Object) => {
        const { requestKey } = this.props.match.params
        const { pin } = this.props

        console.log("requestKey", requestKey, "pin", pin, "password", password)
        return api.onboarding
            .setUserPassword(requestKey, pin, password)
            .then(resp => {
                this.setState({
                    passwordSet: true,
                    pwUpdated: true
                })
            })
            .catch(err => {
                this.props.handleErrorOpen({
                    errorMessage: `Set Password Error`,
                    title: `Set Password Error`,
                    error: err,
                    extraDetails: {
                        CurrentUrl: this.props.history.location.pathname,
                        ErrorResponse: err
                    }
                })
                throw err
            })
    }

    renderStage() {
        const { passwordSet, tcSigned, userTC, pwUpdated } = this.state
        const { profileUser } = this.props

        const { profile, user } = profileUser
        const userContact = SetPasswordContainer.extractUserContact(profileUser)

        if (!userContact) {
            throw new Error("Error bad payload, profile contact email doesn't match up with user email")
        }

        if (!tcSigned) {
            if (!userTC) {
                return (
                    <div>
                        <LoadingCard />
                    </div>
                )
            }
            return (
                <TCStageContainer
                    headerComponent={() => <OnboardingHeader onboarding />}
                    tc={userTC}
                    onExit={this.rejectTC}
                    onNext={this.acceptTC}
                />
            )
        }

        // adminContact is only shown when is different to the user signing up
        let adminContact = profile.contacts.find(contact => contact.roles.length === 1 && contact.roles[0] === "ADMIN")
        if (adminContact && adminContact.email === userContact.email) {
            adminContact = null
        }

        return (
            <SetPassword
                headerText="Set password"
                onSubmitPassword={this.submitPassword}
                onFinish={this.openFinishDialog}
                adminContact={adminContact}
                user={user}
                passwordSet={passwordSet}
                pwUpdated={pwUpdated}
            />
        )
    }

    render() {
        const { match, history } = this.props
        return (
            <React.Fragment>
                {this.renderStage()}
                <LoadingDialog
                    open={this.state.submitting}
                    loading={this.state.submitting}
                    title="Rejecting Terms and Conditions..."
                />
                <BookmarkDialog
                    finishDialogOpen={this.state.finishDialogOpen}
                    closeFinishDialog={this.closeFinishDialog}
                    match={match}
                    history={history}
                />
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(SetPasswordContainer))
