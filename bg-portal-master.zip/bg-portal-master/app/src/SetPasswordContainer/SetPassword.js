// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import CardActions from "@material-ui/core/CardActions"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import CardHeader from "@material-ui/core/CardHeader"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import moment from "moment"
import PhoneNumberTextMask from "~/shared/PhoneNumberTextMask"

import { Grid, Flex } from "~/shared/layout"
// import OnboardingHeader from "~/shared/Onboarding/OnboardingHeader"
import OnboardingHeader from "~/HomeContainer/HeaderContainer/HeaderContainer"

import PinDisplay from "~/shared/Onboarding/Pin/PinDisplay"

import SetPasswordForm from "~/shared/Forms/SetPasswordForm"

const getClasses = ({ theme }) => {
    const finishSetupActions = css({
        flexDirection: "row-reverse"
    })
    const newUserTitle = css({
        fontSize: theme.typography.title.fontSize,
        marginRight: theme.spacing.unit * 3,
        color: theme.palette.common.pageTitle
    })
    const button = css(theme.typography.button)

    return {
        finishSetupActions,
        newUserTitle,
        button
    }
}

type Props = {
    theme: Object,
    onSubmitPassword: Function,
    onFinish: Function,
    user: Object,
    adminContact: ?Object,
    passwordSet: boolean,
    headerText: string,
    pwUpdated: boolean
}

const SetPassword = ({
    theme,
    onSubmitPassword,
    onFinish,
    user,
    adminContact,
    passwordSet,
    headerText,
    pwUpdated
}: Props) => {
    const classes = getClasses({ theme })
    console.log("passwordSet", passwordSet)
    return (
        <React.Fragment>
            {console.log("adminContact", adminContact)}
            <OnboardingHeader onboarding />
            <Grid gridGap="3un" padding="3un">
                <Typography variant="h1" className={classes.newUserTitle}>
                    Welcome Aboard
                </Typography>
                <Card>
                    <CardContent>
                        <SetPasswordForm
                            setMode
                            hideEdit
                            headerText="Set password"
                            onSubmit={onSubmitPassword}
                            userEmail={user.email}
                            passwordSet={passwordSet}
                            pwUpdated={pwUpdated}
                        />
                    </CardContent>
                </Card>
                {adminContact ? (
                    <Card>
                        <CardHeader
                            title={`We have sent an invitation to ${
                                adminContact.firstName
                            }, please pass on this PIN so that the administrator can join the platform.`}
                        />
                        <CardContent>
                            <Typography>
                                The role of the Administrator is to manage users, select approval flow, and manage the
                                organisation details.
                            </Typography>
                            <Flex paddingTop="2un">
                                <Grid gridGap="3un" gridTemplateColumns="repeat(4, minmax(180px, 20%))">
                                    <Typography>Name</Typography>
                                    <Typography>Email</Typography>
                                    <Typography>Phone</Typography>
                                    <Typography>Added On</Typography>
                                    <Typography>{`${adminContact.firstName} ${adminContact.lastName}`}</Typography>
                                    <Typography>{adminContact.email}</Typography>
                                    <Typography>
                                        {" "}
                                        <PhoneNumberTextMask value={adminContact.phone} />
                                    </Typography>
                                    {/* NOTE we are using the primary contact's createdAt as admin's contactAt isn't supplied. Should be the same though */}
                                    <Typography>{moment(user.createdAt).format("L")}</Typography>
                                </Grid>
                                <PinDisplay pin={adminContact.credentials.token} />
                            </Flex>
                        </CardContent>
                    </Card>
                ) : null}
                <Card>
                    <CardActions className={classes.finishSetupActions}>
                        <Button className={classes.button} disabled={!passwordSet} onClick={onFinish}>
                            Finish Setup
                        </Button>
                    </CardActions>
                </Card>
            </Grid>
        </React.Fragment>
    )
}
export default withTheme()(SetPassword)
