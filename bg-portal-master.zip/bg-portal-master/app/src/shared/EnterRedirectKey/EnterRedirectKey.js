// @flow

import * as React from "react"
import { css } from "emotion"
import ReactCodeInput from "react-code-input"
import { withTheme } from "@material-ui/core/styles"
import CircularProgress from "@material-ui/core/CircularProgress"
import Typography from "@material-ui/core/Typography"
import { Flex } from "~/shared/layout"

type Props = {
    theme: Object,
    verify: (pin: string) => Promise<any>,
    title: string
}
type State = {
    isLoading: boolean,
    isValid: boolean,
    value: string
}

const getClasses = ({ theme }) => {
    const textField = css({
        width: 256,
        margin: "10px"
    })
    const progress = css({
        margin: theme.spacing.unit * 2,
        color: theme.palette.common.lightBlue
    })
    const pinTitle = css({
        color: theme.palette.common.darkBlack,
        fontSize: "1em",
        fontWeight: 500,
        margin: theme.spacing.unit * 1,
        display: "inline"
    })
    const verifying = css(pinTitle, {
        fontSize: "18px"
    })
    const pin = css({
        padding: `${theme.spacing.unit * 2}px 0`
    })
    return {
        textField,
        progress,
        pinTitle,
        pin,
        verifying
    }
}

class EnterRedirectKey extends React.Component<Props, State> {
    static defaultProps = {
        title: "Enter your PIN"
    }
    state = {
        isLoading: false,
        isValid: true,
        value: ""
    }

    checkPin = (value: string) => {
        this.setState({
            value,
            isValid: true
        })
        if (value.length === 4) {
            this.setState({ isLoading: true })

            // Assumes redirect on success so no need to set loading to true on success
            this.props.verify(value).catch(error => {
                this.setState({
                    isLoading: false,
                    isValid: false,
                    value: ""
                })
            })
        }
    }

    render() {
        const { theme, title } = this.props
        const { isLoading, isValid, value } = this.state
        const classes = getClasses({ theme })
        const reactCodeInputStyle = {
            fontFamily: "monospace",
            MozAppearance: "textfield",
            border: `1px solid ${theme.palette.common.darkBlue}`,
            boxShadow: "0px 0px 10px 0px rgba(0,0,0,.10)",
            margin: "4px",
            paddingLeft: "10px",
            width: "44px",
            height: "55px",
            fontSize: "40px",
            boxSizing: "border-box"
        }
        const reactCodeInputInvalidStyle = {
            ...reactCodeInputStyle,
            color: "#b94a48",
            backgroundColor: "#f2dede",
            borderColor: "#eed3d7"
        }

        return (
            <Flex justifyContent="center" alignItems="center">
                <div>
                    {isLoading ? (
                        <div>
                            <Typography className={classes.verifying}>Redirecting..</Typography>
                            <CircularProgress variant="indeterminate" className={classes.progress} size={31} />
                        </div>
                    ) : (
                        <Typography className={classes.pinTitle}>{isValid ? title : "Retry"}</Typography>
                    )}
                    <ReactCodeInput
                        className={classes.pin}
                        value={value} // NOTE this is currently not working due to https://github.com/40818419/react-code-input/issues/40
                        onChange={this.checkPin}
                        disabled={isLoading}
                        autoFocus
                        fields={4}
                        isValid={isValid}
                        inputStyle={reactCodeInputStyle}
                        inputStyleInvalid={reactCodeInputInvalidStyle}
                    />
                </div>
            </Flex>
        )
    }
}

export default withTheme()(EnterRedirectKey)
