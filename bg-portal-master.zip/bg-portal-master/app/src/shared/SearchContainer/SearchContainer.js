// @flow
import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import TextField from "@material-ui/core/TextField"
import IconButton from "@material-ui/core/IconButton"
import SearchIcon from "@material-ui/icons/Search"
import InputAdornment from "@material-ui/core/InputAdornment"
import Tooltip from "@material-ui/core/Tooltip"

const getClasses = ({ theme }) => {
    const searchStyle = css({
        display: "inline-block",
        backgroundColor: theme.palette.common.searchBackground,
        paddingLeft: theme.spacing.unit * 1,
        borderRadius: "2px",
        border: `solid 0.5px ${theme.palette.common.defaultGrey}`,
        div: {
            fontSize: theme.commonFontSizes.small
        }
    })
    const detailsSpacing = css({
        marginTop: theme.spacing.unit * 2,
        p: {
            marginBottom: theme.spacing.unit * 2
        }
    })
    const onboardingStyle = css({
        margin: "auto 0 0 0"
    })
    const iconSearch = css({
        color: theme.palette.common.activeStep,
        display: "inline-block"
    })

    return {
        detailsSpacing,
        searchStyle,
        onboardingStyle,
        iconSearch
    }
}

type Props = {
    theme: Object,
    placeholder: string,
    onChange: Function,
    searchValue: string
}

const SearchContainer = ({ theme, placeholder, onChange, searchValue }: Props) => {
    const classes = getClasses({ theme })
    return (
        <Tooltip title={placeholder} disableFocusListener>
            <TextField
                className={classes.searchStyle}
                InputProps={{
                    endAdornment: (
                        <InputAdornment position="end">
                            <IconButton className={classes.iconSearch} tooltip="Search" type="submit">
                                <SearchIcon />
                            </IconButton>
                        </InputAdornment>
                    ),
                    disableUnderline: true
                }}
                onChange={e => onChange(e.target.value)}
                value={searchValue}
                id="searchValue"
                placeholder={placeholder}
            />
        </Tooltip>
    )
}
SearchContainer.defaultProps = {
    onChange: () => console.log(),
    searchValue: ""
}

export default withTheme()(SearchContainer)
