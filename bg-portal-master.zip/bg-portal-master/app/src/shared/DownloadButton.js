// @flow
import Menu from "@material-ui/core/Menu"
import MenuItem from "@material-ui/core/MenuItem"
import IconButton from "@material-ui/core/IconButton"
import Button from "@material-ui/core/Button"
import * as React from "react"
import DownloadIcon from "@material-ui/icons/GetApp"
// import ReactMarkdown from "react-markdown"
import Tooltip from "@material-ui/core/Tooltip"

import saveAs from "file-saver/src/FileSaver"
import { withTheme } from "@material-ui/core/styles"

import { css } from "emotion"

import withError from "~/shared/Context/ErrorDialog/withError"

const getClasses = ({ theme, overrideColor }) => {
    const iconStyle = css({
        color: overrideColor || theme.palette.common.lightBlue
    })
    const buttonStyle = css({
        color: overrideColor || "#fff",
        verticalAlign: "unset"
    })
    return {
        iconStyle,
        buttonStyle
    }
}
type Props = {
    downloadCsv: ?Function,
    downloadPdf: ?Function,
    downloadTCPdf: ?Function,
    disabled: boolean,
    theme: Object,
    handleErrorOpen: Function,
    buttonText: string,
    overrideColor: string
}

type State = {
    anchorEl: any
}
class DownloadButton extends React.Component<Props, State> {
    static defaultProps = {
        downloadCsv: null,
        downloadPdf: null,
        downloadTCPdf: null,
        disabled: false,
        buttonText: "",
        overrideColor: ""
    }
    constructor(props) {
        super(props)
        this.state = {
            anchorEl: null
        }
    }
    handleClick = (event: any, downloadCsv: any, downloadPdf: any, downloadTCPdf: any) => {
        if (downloadCsv && !downloadPdf && !downloadTCPdf) {
            this.handleDownload(downloadCsv, "csv")
        } else if (downloadPdf && !downloadCsv && !downloadTCPdf) {
            this.handleDownload(downloadPdf, "pdf")
        } else if (downloadTCPdf && !downloadCsv && !downloadPdf) {
            this.handleDownload(downloadTCPdf, "TCpdf")
        } else {
            this.setState({ anchorEl: event.currentTarget })
        }
    }
    handleOpen = (event: any) => {
        this.setState({ anchorEl: event.currentTarget })
    }
    handleDownload = (apiCall?: Function, type: string) => {
        if (apiCall) {
            if (type === "csv") {
                apiCall()
                    .then(data => {
                        const header = data.headers["content-disposition"]
                            .split(";")[1]
                            .trim()
                            .split("=")[1]
                        const filename = header.replace(/"/g, "")
                        const file = new Blob([data.data], {
                            type: data.headers["content-type"],
                            responseType: data.headers["content-disposition"]
                        })
                        saveAs(file, filename)
                    })
                    .catch(err => {
                        this.props.handleErrorOpen({
                            errorMessage: `Error downloading CSV`,
                            title: `CSV Download Error`,
                            error: err,
                            extraDetails: {
                                ErrorResponse: err
                            }
                        })
                        throw err
                    })
            }
            if (type === "pdf") {
                apiCall()
                    .then(data => {
                        const file = new Blob([data.data], {
                            type: data.headers["content-type"]
                        })
                        saveAs(file, "Gx-Export.pdf")
                    })
                    .catch(err => {
                        this.props.handleErrorOpen({
                            errorMessage: `Error downloading PDF`,
                            title: `PDF Download Error`,
                            error: err,
                            extraDetails: {
                                ErrorResponse: err
                            }
                        })
                        throw err
                    })
            }
            if (type === "TCpdf") {
                apiCall()
                    .then(data => {
                        if (data.type === "pdf") {
                            saveAs(data.content, "Terms and Conditions.pdf")
                        } else {
                            const blob = new Blob([data.content], { type: "text/plain;charset=utf-8" })
                            saveAs(blob, "Terms and Conditions.md")
                        }
                    })
                    .catch(err => {
                        this.props.handleErrorOpen({
                            errorMessage: `Error downloading PDF`,
                            title: `PDF Download Error`,
                            error: err,
                            extraDetails: {
                                ErrorResponse: err
                            }
                        })
                        throw err
                    })
            }
        }
    }

    handleClose = () => {
        this.setState({ anchorEl: null })
    }
    render() {
        const { anchorEl } = this.state
        const { disabled, theme, downloadCsv, downloadPdf, downloadTCPdf, buttonText, overrideColor } = this.props
        const open = Boolean(anchorEl)
        const classes = getClasses({ theme, overrideColor })

        return (
            <React.Fragment>
                {buttonText ? (
                    <Tooltip
                        title={buttonText === "Download T&Cs" ? "Download Terms and Conditions for this Guarantee" : ""}
                        disableFocusListener
                    >
                        <Button
                            className={classes.buttonStyle}
                            onClick={e => {
                                e.preventDefault()
                                e.stopPropagation()
                                this.handleClick(e, downloadCsv, downloadPdf, downloadTCPdf)
                            }}
                            disabled={disabled}
                        >
                            {buttonText}
                        </Button>
                    </Tooltip>
                ) : (
                    <IconButton
                        className={classes.iconStyle}
                        onClick={e => {
                            e.preventDefault()
                            e.stopPropagation()
                            this.handleClick(e, downloadCsv, downloadPdf, downloadTCPdf)
                        }}
                        disabled={disabled}
                    >
                        <DownloadIcon titleAccess="Download Icon" />
                    </IconButton>
                )}
                <Menu id="long-menu" anchorEl={anchorEl} open={open} onClose={this.handleClose}>
                    {downloadCsv && (
                        <MenuItem
                            key="Download Guarantee Details (CSV)"
                            onClick={() => this.handleDownload(downloadCsv, "csv")}
                        >
                            Download Guarantee Details (CSV)
                        </MenuItem>
                    )}
                    {downloadPdf && (
                        <MenuItem
                            key="Download Guarantee Details (PDF)"
                            onClick={() => this.handleDownload(downloadPdf, "pdf")}
                        >
                            Download Guarantee Details (PDF)
                        </MenuItem>
                    )}
                    {downloadTCPdf && (
                        <MenuItem
                            key="Download Terms and Conditions (PDF)"
                            onClick={() => this.handleDownload(downloadTCPdf, "TCpdf")}
                        >
                            Download Terms and Conditions (PDF)
                        </MenuItem>
                    )}
                </Menu>
            </React.Fragment>
        )
    }
}

export default withError(withTheme()(DownloadButton))
