// @flow

import React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import { Flex } from "~/shared/layout"

type Props = {
    text: string
}

const GenericCard = (props: Props) => (
    <Card css={{ marginBottom: "24px" }}>
        <CardContent>
            <Flex justifyContent="center">
                <Typography>{props.text}</Typography>
            </Flex>
        </CardContent>
    </Card>
)

export default GenericCard
