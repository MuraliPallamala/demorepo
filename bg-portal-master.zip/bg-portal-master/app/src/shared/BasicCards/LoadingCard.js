// @flow

import React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Loading from "~/shared/Loading"
import { Flex } from "~/shared/layout"

const LoadingCard = () => (
    <Card>
        <CardContent>
            <Flex justifyContent="center">
                <Loading show />
            </Flex>
        </CardContent>
    </Card>
)

export default LoadingCard
