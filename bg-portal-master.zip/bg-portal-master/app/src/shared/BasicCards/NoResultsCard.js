// @flow

import React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import { Flex } from "~/shared/layout"

const NoResultsCard = () => (
    <Card>
        <CardContent>
            <Flex justifyContent="center">
                <Typography>No Results</Typography>
            </Flex>
        </CardContent>
    </Card>
)

export default NoResultsCard
