// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import LygonLogo from "~public/admin/newco/assets/images/logo.png"

type Props = {
    theme: Object
}

const getClasses = ({ theme }: Object) => {
    const section = css({
        padding: `${theme.spacing.unit * 14}px 0 ${theme.spacing.unit * 6}px 0`,
        color: theme.palette.primary[50]
    })
    const bold = css({
        fontWeight: theme.typography.fontWeightMedium
    })
    const textStyle = css({
        color: "#FFFFFF"
    })
    const title = css(textStyle, {
        fontSize: 16
    })
    const logo = css({
        maxWidth: 300,
        marginBottom: 40
    })
    return {
        section,
        bold,
        title,
        logo
    }
}

const Title = ({ theme }: Props) => {
    const classes = getClasses({ theme })

    return (
        <div className={classes.section}>
            <img src={LygonLogo} className={classes.logo} alt="Bank DLT Platform Logo" />
            <Typography component="h1" type="display2" className={classes.title} gutterBottom>
                A blockchain-based platform to transform the bank guarantee process
            </Typography>
        </div>
    )
}

export default withTheme()(Title)
