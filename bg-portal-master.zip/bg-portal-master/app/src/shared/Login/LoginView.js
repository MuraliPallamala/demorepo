// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Title from "./Title"

const getClasses = ({ theme }) => {
    const italic = css({
        fontStyle: "italic",
        fontSize: theme.typography.caption.fontSize
    })
    const bg = css({
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
        minHeight: "600px",
        height: "100%",
        backgroundColor: "#00374D !important"
    })
    const section = css({
        textAlign: "center",
        display: "flex",
        flexDirection: "column",
        height: "100%",
        backgroundColor: "#FFFFFF !important"
    })
    const loginCard = css({
        display: "block",
        margin: "auto",
        maxWidth: "350px",
        marginBottom: theme.spacing.unit * 6
    })
    return {
        italic,
        bg,
        section,
        loginCard
    }
}

type Props = {
    theme: Object,
    children: any
}

const Login = ({ theme, children }: Props) => {
    const classes = getClasses({ theme })

    return (
        <div className={classes.section}>
            <div className={classes.bg}>
                <Title />
                <Card className={classes.loginCard}>
                    <CardContent>{children}</CardContent>
                </Card>
            </div>
        </div>
    )
}

export default withTheme()(Login)
