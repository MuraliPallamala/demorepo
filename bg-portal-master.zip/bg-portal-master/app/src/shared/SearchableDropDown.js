// @flow

import React from "react"
import ReactSelect, { components as reactSelectComponents } from "react-select"

import { withStyles } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import TextField from "@material-ui/core/TextField"
import Paper from "@material-ui/core/Paper"
import MenuItem from "@material-ui/core/MenuItem"
import ArrowDropDown from "@material-ui/icons/ArrowDropDown"
import { emphasize } from "@material-ui/core/styles/colorManipulator"

const styles = theme => ({
    root: {
        flexGrow: 1
    },
    input: {
        display: "flex",
        width: "100%",
        flex: 1,
        padding: 0
    },
    valueContainer: {
        display: "flex",
        flex: 1
    },
    chip: {
        margin: `${theme.spacing.unit / 2}px ${theme.spacing.unit / 4}px`
    },
    chipFocused: {
        backgroundColor: emphasize(
            theme.palette.type === "light" ? theme.palette.grey[300] : theme.palette.grey[700],
            0.08
        )
    },
    noOptionsMessage: {
        padding: `${theme.spacing.unit}px ${theme.spacing.unit * 2}px`
    },
    singleValue: {
        // fontSize: 16
    },
    paper: {
        position: "absolute",
        marginTop: theme.spacing.unit,
        zIndex: 100
    },
    placeholder: {
        position: "absolute",
        fontSize: 16
    },
    divider: {
        height: theme.spacing.unit * 2
    },
    boldText: { fontSize: theme.typography.fontSizeSmall, fontWeight: theme.typography.fontWeightMedium },
    textStyle: { fontSize: theme.typography.fontSizeSmall, fontWeight: theme.typography.fontWeightRegular }
})

function NoOptionsMessage(props) {
    return (
        <Typography color="textSecondary" className={props.selectProps.classes.noOptionsMessage} {...props.innerProps}>
            {props.children}
        </Typography>
    )
}

function inputComponent({ inputRef, ...props }) {
    return <div ref={inputRef} data-cy={props["data-cy"]} {...props} />
}

function Option(props) {
    return (
        <MenuItem
            buttonRef={props.innerRef}
            selected={props.isFocused}
            component="div"
            style={{
                fontWeight: props.isSelected ? 500 : 400
            }}
            {...props.innerProps}
        >
            <Typography>{props.children}</Typography>
        </MenuItem>
    )
}

function SingleValue(props) {
    return (
        <div className={props.selectProps.classes.singleValue} {...props.innerProps}>
            {props.children}
        </div>
    )
}

function ValueContainer(props) {
    return <div className={props.selectProps.classes.valueContainer}>{props.children}</div>
}

function Menu(props) {
    return (
        <Paper square className={props.selectProps.classes.paper} {...props.innerProps}>
            {props.children}
        </Paper>
    )
}

type Props = {
    classes: Object,
    theme: Object,
    formik: Object,
    value: Object,
    name: string,
    disabled: boolean,
    currentUserInformation: Object,
    options: Array<Object>,
    placeholder: string,
    dataCy: string,
    fromLocationFieldSet: boolean
}

const SearchableDropDown = (valueProps: Props) => {
    const { classes, theme, formik, value, name, disabled, options, placeholder, fromLocationFieldSet } = valueProps
    const selectStyles = {
        control: base => ({
            ...base,
            borderColor: formik.touched[name] && formik.errors[name] ? "#FF0000" : theme.palette.text.primary
        }),
        input: base => ({
            ...base,
            color: theme.palette.text.primary
        }),
        dropdownIndicator: () => ({
            padding: 0
        }),
        indicatorSeparator: base => ({
            ...base,
            display: "none"
        }),
        placeholder: base => ({
            ...base,
            color: formik.touched[name] && formik.errors[name] ? "#FF0000" : theme.palette.text.primary
        })
    }
    const Control = props => (
        <TextField
            fullWidth
            disabled={props.isDisabled}
            error={!!formik.touched[name] && !!formik.errors[name]}
            InputProps={{
                inputComponent,
                inputProps: {
                    className: props.selectProps.classes.input,
                    inputRef: props.innerRef,
                    children: props.children,
                    "data-cy": valueProps.dataCy,
                    ...props.innerProps
                }
            }}
            {...props.selectProps.textFieldProps}
        />
    )
    const DropdownIndicator = props =>
        reactSelectComponents.DropdownIndicator && (
            <reactSelectComponents.DropdownIndicator {...props}>
                <ArrowDropDown />
            </reactSelectComponents.DropdownIndicator>
        )
    function Placeholder(props) {
        return (
            <Typography
                color={formik.touched[name] && formik.errors[name] ? "error" : "textSecondary"}
                className={props.selectProps.classes.placeholder}
                {...props.innerProps}
            >
                {props.children}
            </Typography>
        )
    }

    const components = {
        Option,
        Control,
        NoOptionsMessage,
        Placeholder,
        SingleValue,
        ValueContainer,
        Menu,
        DropdownIndicator
    }
    return (
        <div className={classes.root}>
            <ReactSelect
                classes={classes}
                value={value}
                onChange={e => {
                    // this is a disgusting hack because the three different spots in the codebase where this component
                    // is used requires a different value to be set
                    if (fromLocationFieldSet) {
                        formik.setFieldValue(name, e)
                    } else {
                        formik.setFieldValue(name, e.value ? e.value : e)
                    }
                }}
                name={name}
                id={name}
                options={options}
                styles={selectStyles}
                components={components}
                isSearchable
                isDisabled={disabled}
                placeholder={placeholder}
                // selectProps={{ "data-cy": "addressRegion" }}
            />
        </div>
    )
}

SearchableDropDown.defaultProps = {
    disabled: false,
    propsOnChange: undefined,
    currentUserInformation: {},
    fromLocationFieldSet: false
}

export default withStyles(styles, { withTheme: true })(SearchableDropDown)
