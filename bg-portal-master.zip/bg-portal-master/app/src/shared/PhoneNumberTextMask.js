// @flow
import React from "react"
import NumberFormat from "react-number-format"

type Props = {
    value: string
}

const PhoneNumberTextMask = ({ value }: Props) => (
    <NumberFormat value={value} displayType="text" defaultValue="" format="(+##) #########" mask=" " />
)

export default PhoneNumberTextMask
