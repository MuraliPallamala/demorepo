// @flow
import * as React from "react"
import DatePicker from "material-ui-pickers/DatePicker"
import KeyboardLeft from "@material-ui/icons/KeyboardArrowLeft"
import KeyboardRight from "@material-ui/icons/KeyboardArrowRight"
import CalendarIcon from "@material-ui/icons/Today"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"

const getClasses = ({ theme, styles }) => {
    const datePicker = css({
        overflow: "visible",
        width: "170px",
        ...styles
    })

    return { datePicker }
}
type Props = {
    theme: Object,
    dateValue: any,
    setDate: Function,
    fieldName: string,
    // My current solution to dynamic styling, accepts a styles object which is then added to the class
    styles: Object
}
const MyDatePicker = ({ theme, dateValue, setDate, fieldName, styles, ...other }: Props) => {
    const classes = getClasses({ theme, styles })
    return (
        <DatePicker
            animateYearScrolling
            autoOk
            keyboard
            clearable
            showTodayButton
            name={fieldName}
            format="DD/MM/YYYY"
            placeholder="DD/MM/YYYY"
            keyboardIcon={<CalendarIcon />}
            mask={value => (value ? [/\d/, /\d/, "/", /\d/, /\d/, "/", /\d/, /\d/, /\d/, /\d/] : [])}
            value={dateValue}
            className={classes.datePicker}
            leftArrowIcon={<KeyboardLeft />}
            rightArrowIcon={<KeyboardRight />}
            onChange={e => {
                // When clearing field the event comes back as null, ISOstring freaks out with null. Thus a null check is necessary
                if (e) {
                    setDate(fieldName, e.toISOString())
                } else {
                    setDate(fieldName, e)
                }
            }}
            // This is to allow for props such as disabled/error or other overrides
            {...other}
        />
    )
}
MyDatePicker.defaultProps = { styles: {} }
export default withTheme()(MyDatePicker)
