import createContactDetailsFieldSet, { createValidate } from "~/factories/forms/createContactDetailsFieldSet"

export const prefix = "primary"
export const validate = createValidate(prefix)
const PrimaryContactDetailsFieldSet = createContactDetailsFieldSet(prefix)

export default PrimaryContactDetailsFieldSet
