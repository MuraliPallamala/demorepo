// @flow

import React from "react"
import Checkbox from "@material-ui/core/Checkbox"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Typography from "@material-ui/core/Typography"

type Props = {
    disabled: boolean,
    formik: Object,
    theme: Object
}

const getClasses = ({ theme }) => {
    const textStyle = css({
        color: `${theme.palette.common.darkBlue}!important`
    })

    return {
        textStyle
    }
}
const AdminSameCheckbox = ({ disabled, formik, theme }: Props) => {
    const classes = getClasses({ theme })
    return (
        <FormControlLabel
            control={
                <Checkbox
                    disabled={disabled}
                    onChange={event => {
                        formik.setFieldValue("adminSameAsPrimaryContact", event.target.checked)
                    }}
                    value="adminSameAsPrimaryContact"
                    checked={formik.values.adminSameAsPrimaryContact}
                    data-cy="adminSameAsPrimaryContact"
                />
            }
            label={<Typography className={classes.textStyle}>Same as Primary Contact</Typography>}
        />
    )
}
AdminSameCheckbox.defaultProps = {
    disabled: false
}

export default withTheme()(AdminSameCheckbox)
