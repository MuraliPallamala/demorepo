import createContactDetailsFieldSet, { createValidate } from "~/factories/forms/createContactDetailsFieldSet"

export const prefix = "admin"
export const validate = createValidate(prefix)
const AdminContactDetailsFieldSet = createContactDetailsFieldSet(prefix)

export default AdminContactDetailsFieldSet
