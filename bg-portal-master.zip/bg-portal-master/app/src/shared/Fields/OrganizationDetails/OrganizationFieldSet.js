// @flow
import React from "react"
import TextField from "@material-ui/core/TextField"
import Button from "@material-ui/core/Button"
import { withTheme } from "@material-ui/core/styles"
import CircularProgress from "@material-ui/core/CircularProgress"
import { css } from "emotion"
import { Formik } from "formik"
import { Col, WrappedRow } from "~/shared/layout"
import businessIDValidation from "~/util/validation/businessIDValidation"
import LocationFieldSet from "~/shared/Fields/LocationDetails/LocationFieldSet"

type validateProps = {
    values: Object,
    referer?: boolean,
    prefilled?: boolean
}

export const validate = ({ values, referer, prefilled }: validateProps) => {
    const errors = {}
    if (!values.businessID && !prefilled) {
        errors.businessID = "Required"
    } else if (!/^(\d *){11}|^(\d *){9}$/i.test(values.businessID) && !prefilled) {
        errors.businessID = "Invalid"
    } else if (!businessIDValidation(values.businessID) && !prefilled) {
        errors.businessID = "Invalid"
    } else if (values.businessID.replace(/\s+/g, "").length > 11 && !prefilled) {
        errors.businessID = "Invalid"
    }
    if (!values.entityName) {
        errors.entityName = "Required"
    } else if (values.entityName.length < 3 || values.entityName.length > 256) {
        errors.entityName = "Invalid"
    } else if (values.entityName.length >= 64) {
        errors.entityName = "Max length: 64"
    }
    if (!values.streetAddress && !referer) {
        errors.streetAddress = "Required"
    } else if (values.streetAddress && values.streetAddress.length < 3) {
        errors.streetAddress = "Invalid"
    }
    if (!values.addressLocality && !referer) {
        errors.addressLocality = "Required"
    } else if (values.addressLocality && values.addressLocality.length < 3) {
        errors.addressLocality = "Invalid"
    }
    if (!values.addressRegion && !referer) {
        errors.addressRegion = "Required"
    } else if (!values.addressRegion.value && !referer) {
        errors.addressRegion = "Invalid"
    }
    if (!values.addressCountry && !referer) {
        errors.addressCountry = "Required"
    } else if (!values.addressCountry.value && !referer) {
        errors.addressCountry = "Invalid"
    }
    if (!values.postalCode && !referer) {
        errors.postalCode = "Required"
    } else if (
        values.postalCode &&
        (values.postalCode.length < 4 || values.postalCode.length > 4 || !/^[0-9]+$/u.test(values.postalCode))
    ) {
        errors.postalCode = "Invalid"
    }

    return errors
}
validate.defaultProps = {
    referer: false,
    prefilled: false
}

const returnError = (regularError, matchError, fieldName) => {
    if (matchError && matchError[fieldName]) {
        return matchError[fieldName]
    }
    return regularError
}

const getClasses = ({ theme }) => {
    const buttonProgress = css({
        color: theme.palette.common.defaultGreen,
        position: "absolute",
        top: "50%",
        left: "50%",
        marginTop: -12,
        marginLeft: -12
    })
    const wrapper = css({
        margin: theme.spacing.unit,
        position: "relative",
        display: "flex",
        alignItems: "center"
    })
    const column = css({
        marginLeft: "16px"
    })
    return {
        buttonProgress,
        wrapper,
        column
    }
}

type FieldSetProps = {
    formik: Object,
    disabled: boolean,
    businessIDCheck: Function,
    referer: boolean,
    prefilled: boolean,
    theme: Object,
    verifyAsic: Function
}

const BusinessIdTextField = ({ formik, businessIDCheck, disabled, prefilled, referer }) => (
    <TextField
        placeholder="ABN/ACN"
        label={`ABN/ACN${!(disabled || prefilled) ? "*" : ""}`}
        disabled={disabled || prefilled}
        name="businessID"
        onChange={e => {
            formik.handleChange(e)
            businessIDCheck(formik, e.target.value, referer)
        }}
        inputProps={{ "data-cy": "businessId" }}
        onBlur={formik.handleBlur}
        value={formik.values.businessID}
        error={
            formik.touched.businessID
                ? !!formik.errors.businessID || (!!formik.status && !!formik.status.businessID)
                : false
        }
        helperText={
            formik.errors.businessID || formik.status
                ? returnError(formik.errors.businessID, formik.status, "businessID")
                : " "
        }
        autoComplete="new-password"
    />
)

const ButtonForm = ({ classes, formik, verifyAsic }) => (
    <Formik
        onSubmit={(values, { setSubmitting, setErrors, setStatus }) => {
            setSubmitting(true)
            setStatus()
            // Assumes that on success component unmounts so no need to call setSubmitting
            verifyAsic(formik.values.businessID.replace(/\s/g, ""), formik)
                .then(orgInfo => {
                    if (orgInfo.length === 0) {
                        setStatus({ button: "No Records found in ASIC" })
                    }
                    setSubmitting(false)
                })
                .catch(() => {
                    setSubmitting(false)
                })
        }}
        render={formikProps => (
            <div className={classes.wrapper}>
                <Button
                    variant="contained"
                    // color="primary"
                    // className={buttonClassname}
                    disabled={
                        !formik.values.businessID ||
                        formikProps.isSubmitting ||
                        !!formik.errors.businessID ||
                        (!!formik.status && !!formik.status.businessID)
                    }
                    onClick={formikProps.handleSubmit}
                >
                    ASIC Lookup
                </Button>
                {formikProps.isSubmitting && <CircularProgress size={24} className={classes.buttonProgress} />}
                {!!formikProps.status && !!formikProps.status.button ? formikProps.status.button : ""}
            </div>
        )}
    />
)

const EntityNameField = ({ disabled, formik }) => (
    <TextField
        disabled={disabled}
        placeholder="Legal Entity Name"
        label={`Legal Entity Name${!disabled ? "*" : ""}`}
        name="entityName"
        multiline
        inputProps={{ id: "entity-name", "data-cy": "entityName" }}
        id="entity-name"
        autoComplete="new-password"
        onChange={e => {
            formik.handleChange(e)
            // entityNameCheck(formik, referer)
        }}
        onBlur={formik.handleBlur}
        value={formik.values.entityName}
        error={formik.touched.entityName ? !!formik.errors.entityName : false}
        helperText={formik.errors.entityName || formik.status ? formik.errors.entityName : " "}
    />
)

const Column = withTheme()(({ theme, ...props }: { theme: Object }) => {
    const classes = getClasses({ theme })
    return <Col className={classes.column} {...props} />
})

const OrganizationFormFieldSet = ({
    formik,
    disabled,
    businessIDCheck,
    referer,
    prefilled,
    verifyAsic,
    theme
}: FieldSetProps) => {
    const classes = getClasses({ theme })
    return (
        <Col flex={1}>
            <WrappedRow flex={1}>
                <Column minWidth="150px" flex={1}>
                    <BusinessIdTextField
                        formik={formik}
                        businessIDCheck={businessIDCheck}
                        disabled={disabled}
                        prefilled={prefilled}
                        referer={referer}
                    />
                </Column>
                <Column hidden={prefilled}>
                    <ButtonForm verifyAsic={verifyAsic} formik={formik} classes={classes} />
                </Column>
                <Column minWidth="150px" flex={1}>
                    <EntityNameField formik={formik} disabled={disabled} />
                </Column>
            </WrappedRow>
            <WrappedRow flex={1}>
                <LocationFieldSet formik={formik} disabled={disabled} referer={referer} prefilled={prefilled} />
            </WrappedRow>
        </Col>
    )
}
OrganizationFormFieldSet.defaultProps = {
    businessIDCheck: () => console.log(),
    disabled: false,
    referer: false,
    prefilled: false,
    verifyAsic: () => console.log()
}
export default withTheme()(OrganizationFormFieldSet)
