// @flow
import React from "react"
import TextField from "@material-ui/core/TextField"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Typography from "@material-ui/core/Typography"
import { Col, WrappedRow } from "~/shared/layout"
import LocationFieldSet from "~/shared/Fields/LocationDetails/LocationFieldSet"

type validateProps = {
    values: Object
}

export const validate = ({ values }: validateProps) => {
    const errors = {}
    if (!values.propertyName) {
        errors.propertyName = "Required"
    }
    return errors
}

const getClasses = ({ theme }) => {
    const subHeading = css({
        fontSize: theme.typography.fontSizeMedium,
        margin: "23px 0px auto 16px"
    })
    const labelColumn = css({
        width: "167px"
    })
    const itemColumn = css({
        marginLeft: "16px"
    })
    return {
        subHeading,
        labelColumn,
        itemColumn
    }
}

type FieldSetProps = {
    formik: Object,
    disabled: boolean,
    transfer: boolean,
    theme: Object
}

const LabelColumn = withTheme()(({ theme, ...props }: { theme: Object }) => {
    const classes = getClasses({ theme })
    return <Col className={classes.labelColumn} {...props} />
})
const ItemColumn = withTheme()(({ theme, ...props }: { theme: Object }) => {
    const classes = getClasses({ theme })
    return <Col className={classes.itemColumn} {...props} />
})
const PropertyInformationFieldSet = ({ formik, disabled, theme, transfer }: FieldSetProps) => {
    const classes = getClasses({ theme })
    return (
        <React.Fragment>
            <WrappedRow>
                <LabelColumn>
                    <Typography className={classes.subHeading}>Property</Typography>
                </LabelColumn>
                <WrappedRow flex={1}>
                    <ItemColumn minWidth="256px" maxWidth="512px" flex={1}>
                        <TextField
                            disabled={disabled || transfer}
                            label="Property Name"
                            name="propertyName"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.propertyName}
                            error={formik.touched.propertyName ? !!formik.errors.propertyName : false}
                            helperText={formik.errors.propertyName ? formik.errors.propertyName : " "}
                        />
                    </ItemColumn>
                    <ItemColumn>
                        <TextField
                            disabled={disabled || transfer}
                            label="Shop No."
                            name="shopNo"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.shopNo}
                            error={formik.touched.shopNo ? !!formik.errors.shopNo : false}
                            helperText={formik.errors.shopNo ? formik.errors.shopNo : " "}
                        />
                    </ItemColumn>
                </WrappedRow>
            </WrappedRow>
            <WrappedRow>
                <LabelColumn>
                    <Typography className={classes.subHeading}>Location</Typography>
                </LabelColumn>
                <LocationFieldSet transfer={transfer} formik={formik} />
            </WrappedRow>
            <WrappedRow>
                <LabelColumn>
                    <Typography className={classes.subHeading}>Purpose</Typography>
                </LabelColumn>
                <ItemColumn minWidth="256px" maxWidth="512px" flex={1}>
                    <TextField
                        disabled={disabled || transfer}
                        label="Optional Comment"
                        name="comments"
                        multiline
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.comments}
                        error={formik.touched.comments ? !!formik.errors.comments : false}
                        helperText={formik.errors.comments ? formik.errors.comments : " "}
                    />
                </ItemColumn>
            </WrappedRow>
        </React.Fragment>
    )
}
PropertyInformationFieldSet.defaultProps = {
    disabled: false,
    transfer: false
}
export default withTheme()(PropertyInformationFieldSet)
