// @flow
import React from "react"
import TextField from "@material-ui/core/TextField"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import FormControl from "@material-ui/core/FormControl"
import FormHelperText from "@material-ui/core/FormHelperText"
import Typography from "@material-ui/core/Typography"
import Select from "@material-ui/core/Select"
import MenuItem from "@material-ui/core/MenuItem"
import InputLabel from "@material-ui/core/InputLabel"
import { Grid, Col, WrappedRow } from "~/shared/layout"
import OrgSearchComponent from "~/shared/OrgSearchComponent/OrgSearchComponent"
// import RemoteSearchComponent from "~/shared/OrgSearchComponent/RemoteSearchComponent"
import NovationFieldSet from "~/shared/Fields/GuaranteeDetails/NovationFieldSet"
import { mapIssuers } from "~/util/issuers"
import ParentSubDropdown from "~/shared/ParentSubDropdown/ParentSubDropdown"

type validateProps = {
    values: Object,
    amend: boolean,
    transfer: boolean,
    currentUserInformation: Object
}

export const validate = ({ values, amend = false, transfer = false, currentUserInformation }: validateProps) => {
    const errors = {}
    if (!values.applicant && !amend && !transfer) {
        errors.applicant = "Required"
    }
    if (!values.applicant || (!values.applicant.abnAcn && !transfer)) {
        errors.applicantBusinessID = "Required"
    }
    if (!values.beneficiary && !amend) {
        errors.beneficiary = "Required"
    }
    if ((!values.beneficiary || !values.beneficiary.abnAcn) && !amend) {
        errors.beneficiaryBusinessID = "Required"
    }
    if (values.beneficiary && values.applicant && values.beneficiary.abnAcn === values.applicant.abnAcn) {
        errors.beneficiary = "Beneficiary can not equal Applicant"
    }

    if (currentUserInformation && currentUserInformation.actingOnBehalf) {
        if (
            !currentUserInformation.userRoles[currentUserInformation.actingOnBehalf.id].includes("MANAGER") &&
            !currentUserInformation.userRoles[currentUserInformation.actingOnBehalf.id].includes("PROPOSER")
        ) {
            errors.actOnBehalf = "You do not have the roles to act on this organisation"
        }
        if (
            transfer &&
            values.beneficiary &&
            values.beneficiary.abnAcn === currentUserInformation.actingOnBehalf.profile.businessId
        ) {
            errors.beneficiary = "New Beneficiary can not equal current Beneficiary"
        }
        if (
            !transfer &&
            values.beneficiary &&
            values.beneficiary.abnAcn !== currentUserInformation.actingOnBehalf.profile.businessId &&
            (values.applicant && values.applicant.abnAcn !== currentUserInformation.actingOnBehalf.profile.businessId)
        ) {
            errors.beneficiary = "Organisation needs to be either Applicant or Beneficiary"
            errors.applicant = "Organisation needs to be either Applicant or Beneficiary"
        }
        if (
            !values.issuer &&
            values.applicant &&
            values.applicant.abnAcn === currentUserInformation.actingOnBehalf.profile.businessId
        ) {
            errors.issuer = "Required"
        }
    } else {
        if (transfer && values.beneficiary && values.beneficiary.abnAcn === currentUserInformation.businessId) {
            errors.beneficiary = "New Beneficiary can not equal current Beneficiary"
        }
        if (!values.issuer && values.applicant && values.applicant.abnAcn === currentUserInformation.businessId) {
            errors.issuer = "Required"
        }
        if (
            !transfer &&
            values.beneficiary &&
            values.beneficiary.abnAcn !== currentUserInformation.businessId &&
            (values.applicant && values.applicant.abnAcn !== currentUserInformation.businessId) &&
            PORTAL_TYPE !== "issuer"
        ) {
            errors.applicant = "Current Organisation needs to be either Applicant or Beneficiary"
            errors.beneficiary = "Current Organisation needs to be either Applicant or Beneficiary"
        }
    }

    return errors
}
validate.defaultProps = {
    amend: false,
    transfer: false,
    currentUserInformation: {}
}

const getClasses = ({ theme }) => {
    const subHeading = css({
        fontSize: theme.typography.fontSizeMedium,
        margin: "23px 0px auto 16px"
    })
    const subHeading2 = css({
        fontSize: theme.typography.fontSizeMedium,
        paddingTop: "10px",
        margin: "0px 0px auto 16px"
    })
    const orgSearch = css({
        marginTop: "21px"
    })
    const labelColumn = css({
        width: "167px"
    })
    const itemColumn = css({
        marginLeft: "16px"
    })
    return {
        subHeading,
        subHeading2,
        orgSearch,
        labelColumn,
        itemColumn
    }
}

type FieldSetProps = {
    formik: Object,
    disabled: boolean,
    amend: boolean,
    transfer: boolean,
    theme: Object,
    currentUserInformation: Object,
    issuers: Array<any>,
    prefillRequest?: boolean
}

const applicantOnChange = (name, e, formik, currentUserInformation, transfer) => {
    let newAorB = {
        orgId: currentUserInformation.primaryOrgId,
        abnAcn: currentUserInformation.businessId,
        value: currentUserInformation.entityName,
        label: currentUserInformation.entityName
    }
    if (PORTAL_TYPE !== "issuer" && !transfer && currentUserInformation.actingOnBehalf) {
        newAorB = {
            orgId: currentUserInformation.actingOnBehalf.id,
            abnAcn: currentUserInformation.actingOnBehalf.profile.businessId,
            value: currentUserInformation.actingOnBehalf.profile.entityName,
            label: currentUserInformation.actingOnBehalf.profile.entityName
        }

        if (e && e.orgId !== currentUserInformation.actingOnBehalf.id) {
            formik.setFieldValue("beneficiary", newAorB)
            formik.setFieldValue("issuer", "")
        }
    } else if (PORTAL_TYPE !== "issuer" && !transfer && e && e.orgId !== currentUserInformation.primaryOrgId) {
        formik.setFieldValue("beneficiary", newAorB)
        formik.setFieldValue("issuer", "")
    }
    if (e && e.orgId) {
        formik.setFieldValue([name], e)
    } else {
        formik.setFieldValue([name], null)
    }
}
const beneficiaryOnChange = (name, e, formik, currentUserInformation, transfer) => {
    let newAorB = {
        orgId: currentUserInformation.primaryOrgId,
        abnAcn: currentUserInformation.businessId,
        value: currentUserInformation.entityName,
        label: currentUserInformation.entityName
    }
    if (PORTAL_TYPE !== "issuer" && !transfer && currentUserInformation.actingOnBehalf) {
        newAorB = {
            orgId: currentUserInformation.actingOnBehalf.id,
            abnAcn: currentUserInformation.actingOnBehalf.profile.businessId,
            value: currentUserInformation.actingOnBehalf.profile.entityName,
            label: currentUserInformation.actingOnBehalf.profile.entityName
        }

        if (e && e.orgId !== currentUserInformation.actingOnBehalf.id) {
            formik.setFieldValue("applicant", newAorB)
        }
    } else if (PORTAL_TYPE !== "issuer" && !transfer && e && e.orgId !== currentUserInformation.primaryOrgId) {
        formik.setFieldValue("applicant", newAorB)
    }
    if (e && e.orgId) {
        formik.setFieldValue([name], e)
    } else {
        formik.setFieldValue([name], null)
    }
}
const isApplicantMe = (applicant, currentUserInformation) => {
    if (
        applicant &&
        currentUserInformation &&
        (applicant.orgId === currentUserInformation.primaryOrgId || applicant.orgId === currentUserInformation.id)
    ) {
        return true
    }
    return false
}

const LabelColumn = withTheme()(({ theme, ...props }: { theme: Object }) => {
    const classes = getClasses({ theme })
    return <Col className={classes.labelColumn} {...props} />
})
const ItemColumn = withTheme()(({ theme, ...props }: { theme: Object }) => {
    const classes = getClasses({ theme })
    return <Col className={classes.itemColumn} {...props} />
})

const PartiesInvolvedFieldSet = ({
    formik,
    disabled,
    theme,
    transfer,
    currentUserInformation,
    issuers,
    prefillRequest,
    amend
}: FieldSetProps) => {
    const classes = getClasses({ theme })
    const issuerList = mapIssuers(issuers)
    return (
        <React.Fragment>
            {!prefillRequest &&
            !transfer &&
            !amend &&
            currentUserInformation &&
            currentUserInformation.relationships.filter(
                item => item.relationship === "PARENT_OF" && item.status === "LINKED"
            ).length >= 1 ? (
                <Grid gridGap="3un" gridTemplateColumns="15% 15% 15%">
                    <Typography className={classes.subHeading}>Act On Behalf</Typography>
                    <ParentSubDropdown
                        user={currentUserInformation}
                        hasError={formik.touched.actOnBehalf && !!formik.errors.actOnBehalf}
                        error={formik.errors.actOnBehalf}
                        onChange={value => formik.setFieldValue("actOnBehalf", value)}
                    />
                </Grid>
            ) : null}
            <WrappedRow>
                <LabelColumn>
                    <Typography className={classes.subHeading}>Applicant</Typography>
                </LabelColumn>
                <WrappedRow flex={1}>
                    <ItemColumn minWidth="256px" maxWidth="512px" flex={1}>
                        <FormControl
                            fullWidth
                            error={formik.touched.applicant ? !!formik.errors.applicant : false}
                            className={classes.orgSearch}
                        >
                            <OrgSearchComponent
                                formik={formik}
                                value={formik.values.applicant}
                                propsOnChange={applicantOnChange}
                                name="applicant"
                                disabled={prefillRequest || transfer || disabled}
                                currentUserInformation={currentUserInformation}
                                transfer={transfer}
                            />
                            <FormHelperText>{formik.errors.applicant ? formik.errors.applicant : " "}</FormHelperText>
                        </FormControl>
                        {/* <FormControl
                            fullWidth
                            error={formik.touched.applicant ? !!formik.errors.applicant : false}
                            className={classes.orgSearch}
                        >
                            <RemoteSearchComponent
                                value={formik.values.applicant}
                                propsOnChange={applicantOnChange}
                                name="applicant"
                                disabled={prefillRequest || transfer || disabled}
                                transfer={transfer}
                                error={formik.touched.applicant ? !!formik.errors.applicant : false}
                                optionsRender={options => {
                                    const abnAcn = options.data.abnAcn.split("_")
                                    return (
                                        <MenuItem
                                            buttonRef={options.innerRef}
                                            selected={options.isFocused}
                                            component="div"
                                            style={{
                                                fontWeight: options.isSelected ? 500 : 400
                                            }}
                                            {...options.innerProps}
                                        >
                                            <Typography>
                                                <span className={options.selectProps.classes.boldText}>Add</span>
                                                <span className={options.selectProps.classes.textStyle}>
                                                    {" "}
                                                    {options.data.entityName}
                                                </span>
                                                {"   "}
                                                <span className={options.selectProps.classes.boldText}>
                                                    {abnAcn[0]}
                                                </span>
                                                <span className={options.selectProps.classes.textStyle}>
                                                    {" "}
                                                    {abnAcn[1]}
                                                </span>
                                            </Typography>
                                        </MenuItem>
                                    )
                                }}
                                remoteFetch={(searchTerm, callback) => {
                                    api.organisations
                                        .getOrganisations(`?entityName=${searchTerm}`)
                                        .then(({ data }) => {
                                            const filteredList = data.result.filter(
                                                item => item.entityType === "APPLICANT_OR_BENEFICIARY"
                                            )

                                            const returnList = filteredList.map(item => ({
                                                label: item.entityName,
                                                value: item.entityName,
                                                abnAcn: item.businessId,
                                                entityName: item.entityName,
                                                orgId: item.id
                                            }))
                                            return returnList
                                        })
                                        .then(list => callback(list))
                                        .catch(error => console.log("Error", error))
                                }}
                            />
                            <FormHelperText>{formik.errors.applicant ? formik.errors.applicant : " "}</FormHelperText>
                        </FormControl> */}
                    </ItemColumn>
                    <ItemColumn>
                        <TextField
                            disabled
                            label="ABN/ACN"
                            name="applicantBusinessID"
                            InputLabelProps={{ shrink: true }}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.applicant ? formik.values.applicant.abnAcn : ""}
                            error={formik.touched.applicant ? !!formik.errors.applicantBusinessID : false}
                            helperText={formik.errors.applicantBusinessID ? formik.errors.applicantBusinessID : " "}
                        />
                    </ItemColumn>
                </WrappedRow>
            </WrappedRow>
            <WrappedRow>
                <LabelColumn>
                    <Typography className={classes.subHeading}>Beneficiary</Typography>
                </LabelColumn>
                <WrappedRow flex={1}>
                    <ItemColumn minWidth="256px" maxWidth="512px" flex={1}>
                        <FormControl
                            fullWidth
                            error={formik.touched.beneficiary ? !!formik.errors.beneficiary : false}
                            className={classes.orgSearch}
                            css={{ minWidth: "256px" }}
                        >
                            <OrgSearchComponent
                                disabled={disabled}
                                formik={formik}
                                value={formik.values.beneficiary}
                                propsOnChange={beneficiaryOnChange}
                                name="beneficiary"
                                transfer={transfer}
                                currentUserInformation={currentUserInformation}
                            />
                            <FormHelperText>
                                {formik.errors.beneficiary ? formik.errors.beneficiary : ""}
                            </FormHelperText>
                        </FormControl>
                    </ItemColumn>
                    <ItemColumn>
                        <TextField
                            disabled
                            label="ABN/ACN"
                            name="beneficiaryBusinessID"
                            InputLabelProps={{ shrink: true }}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.beneficiary ? formik.values.beneficiary.abnAcn : ""}
                            error={formik.touched.beneficiary ? !!formik.errors.beneficiaryBusinessID : false}
                            helperText={formik.errors.beneficiaryBusinessID ? formik.errors.beneficiaryBusinessID : " "}
                        />
                    </ItemColumn>
                </WrappedRow>
            </WrappedRow>
            <WrappedRow>
                <LabelColumn>
                    <Typography className={classes.subHeading}>Issuer</Typography>
                </LabelColumn>
                <ItemColumn minWidth="256px" maxWidth="512px" flex={1}>
                    <FormControl error={formik.touched.issuer ? !!formik.errors.issuer : false}>
                        <InputLabel shrink htmlFor="issuer">
                            Issuer
                            {!(
                                disabled ||
                                prefillRequest ||
                                transfer ||
                                currentUserInformation.entityType === "ISSUER" ||
                                (currentUserInformation && currentUserInformation.actingOnBehalf
                                    ? // isApplicantMe checks to see if the org that is passed in is the applicant or not
                                      !isApplicantMe(formik.values.applicant, currentUserInformation.actingOnBehalf)
                                    : !isApplicantMe(formik.values.applicant, currentUserInformation))
                            )
                                ? "*"
                                : ""}
                        </InputLabel>
                        <Select
                            disabled={
                                disabled ||
                                prefillRequest ||
                                transfer ||
                                currentUserInformation.entityType === "ISSUER" ||
                                (currentUserInformation && currentUserInformation.actingOnBehalf
                                    ? // isApplicantMe checks to see if the org that is passed in is the applicant or not
                                      !isApplicantMe(formik.values.applicant, currentUserInformation.actingOnBehalf)
                                    : !isApplicantMe(formik.values.applicant, currentUserInformation))
                            }
                            value={formik.values.issuer}
                            onChange={formik.handleChange}
                            inputProps={{
                                name: "issuer",
                                id: "issuer"
                            }}
                        >
                            <MenuItem value="">
                                <em>None</em>
                            </MenuItem>
                            {issuerList.map(issuer => (
                                <MenuItem key={issuer.value} value={issuer.value}>
                                    {issuer.label}
                                </MenuItem>
                            ))}
                        </Select>
                        <FormHelperText>{formik.errors.issuer ? formik.errors.issuer : ""}</FormHelperText>
                    </FormControl>
                </ItemColumn>
            </WrappedRow>
            <Grid hidden={!transfer} gridGap="3un" gridTemplateColumns="15% 30%">
                <Typography className={classes.subHeading2}>Novation Reason</Typography>
                <NovationFieldSet formik={formik} />
            </Grid>
        </React.Fragment>
    )
}
PartiesInvolvedFieldSet.defaultProps = {
    disabled: false,
    transfer: false,
    prefillRequest: false,
    amend: false,
    currentUserInformation: {}
}
export default withTheme()(PartiesInvolvedFieldSet)
