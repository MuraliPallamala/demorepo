// @flow

const validate = (values: Object, update: boolean, roleList: Array<any>) => {
    const errors = {}
    if (!values.email && !update) {
        errors.email = "Required"
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
        errors.email = "Invalid"
    }
    if (!values.phone && !update) {
        errors.phone = "Required"
    } else if (values.phone && !/\(?([0-9.+( )-]{8,9})/i.test(values.phone)) {
        errors.phone = "Invalid"
    }
    if (!values.firstName && !update) {
        errors.firstName = "Required"
    } else if (
        !/^[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]+$/u.test(
            values.firstName
        )
    ) {
        errors.firstName = "Invalid"
    }
    if (values.gxLimit && values.gxLimit < 0) {
        errors.gxLimit = "Invalid"
    }
    if (!values.lastName && !update) {
        errors.lastName = "Required"
    } else if (
        !/^[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]+$/u.test(
            values.lastName
        )
    ) {
        errors.lastName = "Invalid"
    }
    if (!values.roles && !update && !(roleList.length <= 1)) {
        errors.roles = "Required"
    } else if (values.roles.length === 0 && !(roleList.length <= 1)) {
        errors.roles = "Required"
    }

    return errors
}

export default validate
