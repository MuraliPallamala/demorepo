// @flow
import React from "react"
import TextField from "@material-ui/core/TextField"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import FormControl from "@material-ui/core/FormControl"
import FormHelperText from "@material-ui/core/FormHelperText"
import Typography from "@material-ui/core/Typography"
import { Grid, Flex } from "~/shared/layout"
import OrgSearchComponent from "~/shared/OrgSearchComponent/OrgSearchComponent"

type validateProps = {
    values: Object
}

export const validate = ({ values }: validateProps) => {
    const errors = {}
    return errors
}

const getClasses = ({ theme }) => {
    const subHeading = css({
        fontSize: theme.typography.fontSizeMedium
        // margin: "auto"
    })
    const orgSearch = css({
        marginTop: "21px"
    })
    return {
        subHeading,
        orgSearch
    }
}

type FieldSetProps = {
    formik: Object,
    disabled: boolean,
    theme: Object
}

const ApplicantBeneficiarySearchFieldSet = ({ formik, disabled, theme }: FieldSetProps) => {
    const classes = getClasses({ theme })

    return (
        <div>
            <Grid gridGap="3un" gridTemplateColumns="1fr 3fr 3fr">
                <Flex alignItems="center">
                    <Typography className={classes.subHeading}>Applicant</Typography>
                </Flex>
                <FormControl
                    error={formik.touched.applicant ? !!formik.errors.applicant : false}
                    className={classes.orgSearch}
                >
                    <OrgSearchComponent
                        formik={formik}
                        value={formik.values.applicant}
                        name="applicant"
                        disabled={disabled}
                        transfer
                    />
                    <FormHelperText>{formik.errors.applicant ? formik.errors.applicant : " "}</FormHelperText>
                </FormControl>
                <TextField
                    disabled
                    label="ABN/ACN"
                    name="applicantBusinessID"
                    InputLabelProps={{ shrink: true }}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.applicant ? formik.values.applicant.abnAcn : ""}
                    error={formik.touched.applicant ? !!formik.errors.applicantBusinessID : false}
                    helperText={formik.errors.applicantBusinessID ? formik.errors.applicantBusinessID : " "}
                />
            </Grid>
            <Grid gridGap="3un" gridTemplateColumns="1fr 3fr 3fr">
                <Flex alignItems="center">
                    <Typography className={classes.subHeading}>Beneficiary</Typography>
                </Flex>
                <FormControl
                    error={formik.touched.beneficiary ? !!formik.errors.beneficiary : false}
                    className={classes.orgSearch}
                >
                    <OrgSearchComponent
                        disabled={disabled}
                        formik={formik}
                        value={formik.values.beneficiary}
                        name="beneficiary"
                        transfer
                    />
                    <FormHelperText>{formik.errors.beneficiary ? formik.errors.beneficiary : ""}</FormHelperText>
                </FormControl>
                <TextField
                    disabled
                    label="ABN/ACN"
                    name="beneficiaryBusinessID"
                    onChange={formik.handleChange}
                    InputLabelProps={{ shrink: true }}
                    onBlur={formik.handleBlur}
                    value={formik.values.beneficiary ? formik.values.beneficiary.abnAcn : ""}
                    error={formik.touched.beneficiary ? !!formik.errors.beneficiaryBusinessID : false}
                    helperText={formik.errors.beneficiaryBusinessID ? formik.errors.beneficiaryBusinessID : " "}
                />
            </Grid>
        </div>
    )
}
ApplicantBeneficiarySearchFieldSet.defaultProps = {
    disabled: false,
    transfer: false,
    currentUserInformation: {}
}
export default withTheme()(ApplicantBeneficiarySearchFieldSet)
