// @flow
/* eslint-disable import/prefer-default-export */

export const validate = (values: Object) => {
    const errors = {}
    if (!values.description) {
        errors.description = "Required"
    } else if (values.description.length < 3) {
        errors.description = "Invalid"
    }

    return errors
}
