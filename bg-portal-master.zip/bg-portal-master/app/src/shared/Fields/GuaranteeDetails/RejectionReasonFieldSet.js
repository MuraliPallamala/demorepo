// @flow
import React from "react"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import FormControl from "@material-ui/core/FormControl"
import TextField from "@material-ui/core/TextField"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import Radio from "@material-ui/core/Radio"
import RadioGroup from "@material-ui/core/RadioGroup"
// TODO refactor validation
// type validateProps = {
//     values: Object
// }
//
// export const validate = ({ values }: validateProps) => {
//     const errors = {}
//     if (!values.otherReason && values.reason === "Other") {
//         errors.otherReason = "Required"
//     }
//     return errors
// }

const getClasses = ({ theme }) => {
    const test = css({
        margin: "auto 0 auto 0",
        overflow: "visible"
    })
    return {
        test
    }
}

type FieldSetProps = {
    formik: Object,
    disabled: boolean,
    // prefilled: boolean,
    theme: Object
}

const RejectionReasonFieldSet = ({ formik, disabled, theme }: FieldSetProps) => {
    const classes = getClasses({ theme })

    return (
        <React.Fragment>
            <FormControl required error={formik.errors.reason} component="fieldset" className={classes.test}>
                <RadioGroup
                    row
                    aria-label="Rejection Reason"
                    name="reason"
                    value={formik.values.reason}
                    onChange={e => formik.setFieldValue("reason", e.target.value)}
                >
                    <FormControlLabel value="KYC" control={<Radio />} label="KYC" />
                    <FormControlLabel value="Credit" control={<Radio />} label="Credit" />
                    <FormControlLabel value="Pricing" control={<Radio />} label="Pricing" />
                    <FormControlLabel value="Other" control={<Radio />} label="Other" />
                </RadioGroup>
                {formik.values.reason === "Other" && (
                    <FormControl error={formik.errors.otherReason} component="fieldset" className={classes.test}>
                        <TextField
                            name="otherReason"
                            placeholder="Reason"
                            label="Reason"
                            error={formik.touched.otherReason ? !!formik.errors.otherReason : false}
                            helperText={formik.errors.otherReason ? formik.errors.otherReason : " "}
                            value={formik.values.otherReason}
                            onChange={formik.handleChange}
                        />
                    </FormControl>
                )}
            </FormControl>
        </React.Fragment>
    )
}
RejectionReasonFieldSet.defaultProps = {
    disabled: false,
    prefilled: false
}
export default withTheme()(RejectionReasonFieldSet)
