// @flow
import React from "react"
import TextField from "@material-ui/core/TextField"
import Select from "@material-ui/core/Select"
import MenuItem from "@material-ui/core/MenuItem"
import FormControl from "@material-ui/core/FormControl"
import FormHelperText from "@material-ui/core/FormHelperText"
import InputLabel from "@material-ui/core/InputLabel"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import Checkbox from "@material-ui/core/Checkbox"
import { BG } from "~/util/CONSTANTS"
import NumberTextField from "~/shared/NumberTextField"
import MyDatePicker from "~/shared/DatePicker/DatePicker"
import { Col, WrappedRow } from "~/shared/layout"

type validateProps = {
    values: Object,
    gxLimit: number
}

export const validate = ({ values, gxLimit }: validateProps) => {
    const errors = {}
    // throw error if the day selected is before tomorrow
    const time = new Date().getTime()
    const date = new Date(time - (time % (24 * 60 * 60 * 1000)))
    const tomorrow = new Date(date.getTime() + 24 * 60 * 60 * 1000)

    if (!values.purposeType) {
        errors.purposeType = "Required"
    }
    if (!values.expiresAt && !values.dateChecked) {
        errors.expiresAt = "Required"
    }
    if (values.expiresAt && new Date(values.expiresAt) < tomorrow) {
        errors.expiresAt = " "
    }
    if (!values.amount) {
        errors.amount = "Required"
    } else if (values.amount === 0 || values.amount < 0) {
        errors.amount = "Invalid"
    }
    // check personal gx limit, but only if it's not a prefill request
    if (gxLimit !== BG.UNLIMITED_GX_LIMIT && values.amount > gxLimit / 100 && PORTAL_TYPE !== "issuer") {
        errors.amount = "Value exceeds Guarantee Limit"
    }
    if (!values.currency) {
        errors.currency = "Required"
    }
    if (!values.termsConditions) {
        errors.termsConditions = "Required"
    }
    return errors
}

const getClasses = ({ theme }) => {
    const datePicker = css({
        overflow: "visible"
    })
    const purpose = css({
        width: "45%"
    })
    const subHeading = css({
        fontSize: theme.typography.fontSizeMedium,
        margin: "23px 0px auto 16px"
    })
    const labelColumn = css({
        width: "167px"
    })
    const itemColumn = css({
        marginLeft: "16px"
    })
    return {
        datePicker,
        purpose,
        subHeading,
        labelColumn,
        itemColumn
    }
}

type FieldSetProps = {
    formik: Object,
    disabled: boolean,
    theme: Object,
    transfer: boolean,
    amend?: boolean,
    termsAndConditions: Array<any>
}

const LabelColumn = withTheme()(({ theme, ...props }: { theme: Object }) => {
    const classes = getClasses({ theme })
    return <Col className={classes.labelColumn} {...props} />
})
const ItemColumn = withTheme()(({ theme, ...props }: { theme: Object }) => {
    const classes = getClasses({ theme })
    return <Col className={classes.itemColumn} {...props} />
})

const GuarnteeFieldSet = ({ formik, disabled, theme, transfer, amend, termsAndConditions }: FieldSetProps) => {
    const today = new Date()
    return (
        <React.Fragment>
            <WrappedRow>
                <LabelColumn />
                <WrappedRow flex={1}>
                    <ItemColumn>
                        <FormControl error={formik.touched.expiresAt ? !!formik.errors.expiresAt : false}>
                            <MyDatePicker
                                fullWidth
                                fieldName="expiresAt"
                                label="Expiry Date*"
                                // disablePast
                                minDate={new Date(today.getTime() + 24 * 60 * 60 * 1000)}
                                minDateMessage="Date must be in the future"
                                error={formik.touched.expiresAt ? !!formik.errors.expiresAt : false}
                                disabled={disabled || formik.values.dateChecked || transfer}
                                setDate={formik.setFieldValue}
                                dateValue={formik.values.expiresAt}
                            />
                            <FormControl error={formik.touched.expiresAt ? !!formik.errors.expiresAt : false}>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            checked={formik.values.dateChecked}
                                            onChange={e => {
                                                const { checked } = e.target
                                                formik.setFieldValue("expiresAt", null)
                                                formik.setFieldValue("dateChecked", checked)
                                            }}
                                            value="OpenEnded"
                                            name="dateChecked"
                                            css={{
                                                color:
                                                    formik.touched.expiresAt && !!formik.errors.expiresAt
                                                        ? "#FF0000"
                                                        : false
                                            }}
                                            disabled={disabled || transfer}
                                        />
                                    }
                                    label="Open Ended"
                                />
                                <FormHelperText>
                                    {formik.errors.expiresAt ? formik.errors.expiresAt : ""}
                                </FormHelperText>
                            </FormControl>
                        </FormControl>
                    </ItemColumn>
                    <WrappedRow>
                        <ItemColumn>
                            <FormControl error={formik.touched.currency ? !!formik.errors.currency : false}>
                                <InputLabel htmlFor="state-simple">Currency*</InputLabel>
                                <Select
                                    disabled
                                    value={formik.values.currency}
                                    onChange={formik.handleChange}
                                    inputProps={{
                                        name: "currency",
                                        id: "state-simple"
                                    }}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value="AUD">AUD</MenuItem>
                                    <MenuItem value="NZD">NZD</MenuItem>
                                </Select>
                                <FormHelperText>{formik.errors.currency ? formik.errors.currency : ""}</FormHelperText>
                            </FormControl>
                        </ItemColumn>
                        <ItemColumn>
                            <TextField
                                label="Maximum Amount*"
                                value={formik.values.amount}
                                name="amount"
                                onChange={e => formik.setFieldValue("amount", e.target.value)}
                                id="amount"
                                disabled={disabled || transfer}
                                error={formik.touched.amount ? !!formik.errors.amount : false}
                                helperText={formik.errors.amount ? formik.errors.amount : " "}
                                InputProps={{
                                    inputComponent: NumberTextField
                                }}
                            />
                        </ItemColumn>
                    </WrappedRow>
                    <ItemColumn minWidth="160px">
                        <FormControl
                            fullWidth
                            error={formik.touched.termsConditions ? !!formik.errors.termsConditions : false}
                        >
                            <InputLabel htmlFor="state-simple">Guarantee Terms*</InputLabel>
                            <Select
                                disabled={disabled || transfer || amend}
                                value={formik.values.termsConditions}
                                onChange={formik.handleChange}
                                inputProps={{
                                    name: "termsConditions",
                                    id: "state-simple"
                                }}
                            >
                                <MenuItem value="">
                                    <em>None</em>
                                </MenuItem>
                                {termsAndConditions.map(tcItem => (
                                    <MenuItem key={tcItem.id} value={tcItem.id}>
                                        {tcItem.title}
                                    </MenuItem>
                                ))}
                            </Select>
                            <FormHelperText>
                                {formik.errors.termsConditions ? formik.errors.termsConditions : ""}
                            </FormHelperText>
                        </FormControl>
                    </ItemColumn>
                </WrappedRow>
            </WrappedRow>
        </React.Fragment>
    )
}
GuarnteeFieldSet.defaultProps = {
    disabled: false,
    transfer: false,
    amend: false
}
export default withTheme()(GuarnteeFieldSet)
