// @flow
import React from "react"
import Button from "@material-ui/core/Button"
import { withTheme } from "@material-ui/core/styles"
import CircularProgress from "@material-ui/core/CircularProgress"
import { css } from "emotion"
import { Formik } from "formik"

const getClasses = ({ theme }) => {
    const buttonProgress = css({
        color: theme.palette.common.defaultGreen,
        position: "absolute",
        top: "50%",
        left: "50%",
        marginTop: -12,
        marginLeft: -12
    })
    const wrapper = css({
        margin: theme.spacing.unit,
        position: "relative",
        display: "flex",
        alignItems: "center"
    })
    const buttonStyle = css(theme.typography.button, {
        boxShadow: "none",
        backgroundColor: "transparent",
        margin: theme.spacing.unit * 2
    })
    return {
        buttonProgress,
        wrapper,
        buttonStyle
    }
}
type Props = {
    theme: Object,
    submitFunction: Function,
    disabled: boolean,
    buttonText: string,
    submitValues: Object
}

const ButtonField = ({ submitFunction, theme, disabled, buttonText, submitValues }: Props) => {
    const classes = getClasses({ theme })
    return (
        <Formik
            onSubmit={(values, { setSubmitting, setErrors, setStatus }) => {
                setSubmitting(true)
                setStatus()
                submitFunction(submitValues)
                    .then(() => {
                        setSubmitting(false)
                    })
                    .catch(() => {
                        setSubmitting(false)
                    })
            }}
            render={formikProps => (
                <div className={classes.wrapper}>
                    <Button
                        variant="contained"
                        disabled={disabled || formikProps.isSubmitting}
                        onClick={e => {
                            e.preventDefault()
                            e.stopPropagation()
                            formikProps.handleSubmit(e)
                        }}
                        className={classes.buttonStyle}
                    >
                        {buttonText}
                    </Button>
                    {formikProps.isSubmitting && <CircularProgress size={24} className={classes.buttonProgress} />}
                    {!!formikProps.status && !!formikProps.status.button ? formikProps.status.button : ""}
                </div>
            )}
        />
    )
}

ButtonField.defaultProps = {
    disabled: false
}

export default withTheme()(ButtonField)
