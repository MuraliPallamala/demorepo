// @flow
import React from "react"
import TextField from "@material-ui/core/TextField"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Slider from "@material-ui/lab/Slider"
import Typography from "@material-ui/core/Typography"
import { Grid } from "~/shared/layout"
import NumberFormat from "react-number-format"

type validateProps = {
    values: Object,
    maxValue: number,
    minValue: number
}

export const validate = ({ maxValue, minValue, values }: validateProps) => {
    const errors = {}
    if (values.sliderValue > maxValue) {
        errors.sliderValue = "The demand value exceeds the value of the Bank Guarantee."
    }
    if (values.sliderValue < minValue) {
        errors.sliderValue = "The demand amount must be greater than zero."
    }
    return errors
}

const getClasses = ({ theme }) => {
    const root = css({})
    const number = css({
        textAlign: "center",
        fontSize: "29px",
        fontWeight: theme.typography.fontWeightMedium
    })
    const sliderLabel = css({
        textAlign: "center",
        fontSize: "18px",
        fontWeight: theme.typography.fontWeightRegular
    })
    const sliderFooter = css({
        fontSize: theme.typography.fontSizeSmall,
        textAlign: "center"
    })
    const sliderRoot = css({
        width: "75% !important",
        margin: "10px auto 20px auto"
    })
    const sliderTrack = css({
        height: "4px"
    })
    const optionalComments = css({
        marginTop: "auto"
    })
    const textStyle = css({
        fontWeight: theme.typography.fontWeightMedium
    })
    // const textfieldStyle = css({})
    const linkStyle = css({
        textDecoration: "none",
        color: `${theme.palette.common.lightBlue}!important`
    })
    return {
        root,
        number,
        sliderLabel,
        sliderFooter,
        sliderRoot,
        sliderTrack,
        optionalComments,
        textStyle,
        linkStyle
    }
}

const NumberFormatCustom = withTheme()(props => {
    const { inputRef, onChange, theme, ...other } = props
    return (
        <NumberFormat
            {...other}
            getInputRef={inputRef}
            onValueChange={values => {
                onChange({
                    target: {
                        value: values.value
                    }
                })
            }}
            thousandSeparator
            isAllowed={values => values.value <= 999999999.99}
            decimalScale={2}
            isNumericString={false}
            prefix="$"
            style={{
                textAlign: "center",
                fontSize: "29px",
                fontWeight: theme.typography.fontWeightMedium
            }}
        />
    )
})

type FieldSetProps = {
    formik: Object,
    disabled: boolean,
    // prefilled: boolean,
    theme: Object,
    maxValue: number,
    minValue: number
}

const GuarnteeFieldSet = ({ formik, disabled, theme, maxValue, minValue }: FieldSetProps) => {
    const classes = getClasses({ theme })

    return (
        <Grid gridGap="2un" className={classes.root}>
            <Typography id="label" className={classes.textStyle}>
                Select the entire or partial amount to demand:
            </Typography>
            <div style={{ textAlign: "center" }}>
                <Typography className={classes.textStyle}>To Demand AUD$</Typography>
                <TextField
                    // className={classes.formControl}
                    placeholder="To Demand AUD$"
                    value={formik.values.sliderValue}
                    name="sliderValue"
                    onChange={e => formik.setFieldValue("sliderValue", parseFloat(e.target.value))}
                    id="sliderValue"
                    error={formik.touched.sliderValue ? !!formik.errors.sliderValue : false}
                    helperText={formik.errors.sliderValue ? formik.errors.sliderValue : " "}
                    InputProps={{ inputComponent: NumberFormatCustom }}
                    style={{ minWidth: "50%", textAlign: "center" }}
                />
                <Grid gridGap="3un" gridTemplateColumns="14% auto 17%">
                    <Typography className={classes.sliderLabel} style={{ textAlign: "right" }}>
                        $0
                    </Typography>
                    <div />
                    <Typography className={classes.sliderLabel} style={{ textAlign: "left" }}>
                        ${maxValue}
                    </Typography>
                </Grid>
                <Slider
                    name="sliderValue"
                    id="sliderValue"
                    value={formik.values.sliderValue}
                    aria-labelledby="label"
                    max={maxValue}
                    step={0.01}
                    min={0}
                    classes={{
                        root: classes.sliderRoot,
                        track: classes.sliderTrack
                    }}
                    onChange={(event, value) => {
                        // there seems to be a bug with material-ui slider where sometimes the value emitted
                        // does not respect the `step` prop. Using toFixed() to get around this bug
                        formik.setFieldValue("sliderValue", value.toFixed(2))
                    }}
                />
            </div>

            <Typography className={classes.textStyle}>
                Optional comments, which will be visible to the issuer and applicant if approved:
            </Typography>
            <TextField
                label="Optional Comments"
                name="optionalComments"
                value={formik.values.optionalComments}
                onChange={formik.handleChange}
                className={classes.optionalComments}
            />
        </Grid>
    )
}
GuarnteeFieldSet.defaultProps = {
    disabled: false,
    prefilled: false
}
export default withTheme()(GuarnteeFieldSet)
