// @flow
import React from "react"
import TextField from "@material-ui/core/TextField"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import FormControl from "@material-ui/core/FormControl"
import FormHelperText from "@material-ui/core/FormHelperText"
import { Col, WrappedRow } from "~/shared/layout"
import SearchableDropDown from "~/shared/SearchableDropDown"

const getClasses = ({ theme }) => {
    const searchDropDown = css({
        display: "flex",
        flexDirection: "column",
        justifyContent: "flex-end",
        marginLeft: "16px"
    })
    const itemColumn = css({
        marginLeft: "16px"
    })
    return {
        searchDropDown,
        itemColumn
    }
}

type validateProps = {
    values: Object,
    prefilled?: boolean
}

export const validate = ({ values, prefilled }: validateProps) => {
    const errors = {}
    if (!values.streetAddress) {
        errors.streetAddress = "Required"
    } else if (values.streetAddress && values.streetAddress.length < 3) {
        errors.streetAddress = "Invalid"
    }
    if (!values.addressLocality) {
        errors.addressLocality = "Required"
    } else if (values.addressLocality && values.addressLocality.length < 3) {
        errors.addressLocality = "Invalid"
    }
    if (!values.addressRegion) {
        errors.addressRegion = "Required"
    } else if (values.addressRegion && values.addressRegion.length < 2) {
        errors.addressRegion = "Invalid"
    }
    if (!values.addressCountry) {
        errors.addressCountry = "Required"
    } else if (!values.addressCountry.value) {
        errors.addressCountry = "Invalid"
    }
    if (!values.postalCode) {
        errors.postalCode = "Required"
    } else if (
        values.postalCode &&
        (values.postalCode.length < 4 || values.postalCode.length > 4 || !/^[0-9]+$/u.test(values.postalCode))
    ) {
        errors.postalCode = "Invalid"
    }

    return errors
}
validate.defaultProps = {
    prefilled: false
}

type FieldSetProps = {
    formik: Object,
    disabled: boolean,
    referer: boolean,
    prefilled: boolean,
    theme: Object,
    transfer: boolean
}

const countries = [{ value: "Australia", label: "Australia" }]

const states = [
    { value: "Australian Capital Territory", label: "Australian Capital Territory" },
    { value: "New South Wales", label: "New South Wales" },
    { value: "Northern Territory", label: "Northern Territory" },
    { value: "Queensland", label: "Queensland" },
    { value: "South Australia", label: "South Australia" },
    { value: "Tasmania", label: "Tasmania" },
    { value: "Victoria", label: "Victoria" },
    { value: "Western Australia", label: "Western Australia" }
]

const ItemColumn = withTheme()(({ theme, ...props }: { theme: Object }) => {
    const classes = getClasses({ theme })
    return <Col className={classes.itemColumn} {...props} />
})

const LocationFieldSet = ({ formik, disabled, referer, prefilled, transfer, theme }: FieldSetProps) => {
    const classes = getClasses({ theme })
    return (
        <WrappedRow flex={1}>
            <ItemColumn minWidth="256px" maxWidth="512px" flex={1}>
                <TextField
                    fullWidth
                    disabled={disabled || transfer}
                    placeholder="Street Address"
                    label="Street Address*"
                    name="streetAddress"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.streetAddress}
                    error={formik.touched.streetAddress ? !!formik.errors.streetAddress : false}
                    inputProps={{ "data-cy": "streetAddress" }}
                    helperText={formik.errors.streetAddress ? formik.errors.streetAddress : " "}
                    autoComplete="new-password"
                />
            </ItemColumn>
            <ItemColumn>
                <TextField
                    disabled={disabled || transfer}
                    placeholder="Suburb/City"
                    label="Suburb/City*"
                    name="addressLocality"
                    onChange={formik.handleChange}
                    inputProps={{ "data-cy": "addressLocality" }}
                    onBlur={formik.handleBlur}
                    value={formik.values.addressLocality}
                    error={formik.touched.addressLocality ? !!formik.errors.addressLocality : false}
                    helperText={formik.errors.addressLocality ? formik.errors.addressLocality : " "}
                    autoComplete="new-password"
                />
            </ItemColumn>
            <ItemColumn>
                <TextField
                    disabled={disabled || transfer}
                    placeholder="Postal Code"
                    label="Postal Code*"
                    name="postalCode"
                    inputProps={{ "data-cy": "postalCode" }}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.postalCode}
                    error={formik.touched.postalCode ? !!formik.errors.postalCode : false}
                    helperText={formik.errors.postalCode ? formik.errors.postalCode : " "}
                    autoComplete="new-password"
                />
            </ItemColumn>
            <ItemColumn className={classes.searchDropDown}>
                <FormControl fullWidth error={formik.touched.addressCountry ? !!formik.errors.addressCountry : false}>
                    <SearchableDropDown
                        name="addressCountry"
                        value={formik.values.addressCountry}
                        // disabled={disabled || transfer}
                        disabled
                        formik={formik}
                        placeholder="Country*"
                        options={countries}
                        autoComplete="new-password"
                    />
                    <FormHelperText>{formik.errors.addressCountry ? formik.errors.addressCountry : ""}</FormHelperText>
                </FormControl>
            </ItemColumn>
            <ItemColumn className={classes.searchDropDown} minWidth="140px">
                <FormControl fullWidth error={formik.touched.addressRegion ? !!formik.errors.addressRegion : false}>
                    <SearchableDropDown
                        name="addressRegion"
                        value={formik.values.addressRegion}
                        disabled={disabled || transfer}
                        formik={formik}
                        fromLocationFieldSet
                        placeholder="State/Region*"
                        options={states}
                        autoComplete="new-password"
                    />
                    <FormHelperText>{formik.errors.addressRegion ? formik.errors.addressRegion : ""}</FormHelperText>
                </FormControl>
            </ItemColumn>
        </WrappedRow>
    )
}
LocationFieldSet.defaultProps = {
    disabled: false,
    referer: false,
    prefilled: false,
    transfer: false
}
export default withTheme()(LocationFieldSet)
