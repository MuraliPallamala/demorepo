// @flow
import React from "react"
import TextField from "@material-ui/core/TextField"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import FormControl from "@material-ui/core/FormControl"
import FormHelperText from "@material-ui/core/FormHelperText"
import { Grid } from "~/shared/layout"
import SearchableDropDown from "~/shared/SearchableDropDown"

const getClasses = ({ theme }) => {
    const searchDropDown = css({
        marginTop: "21px"
    })
    return {
        searchDropDown
    }
}

type validateProps = {
    values: Object,
    prefilled?: boolean
}

export const validate = ({ values, prefilled }: validateProps) => {
    const errors = {}

    return errors
}
validate.defaultProps = {
    prefilled: false
}

type FieldSetProps = {
    formik: Object,
    disabled: boolean,
    referer: boolean,
    prefilled: boolean,
    theme: Object
}

const countries = [{ value: "Australia", label: "Australia" }]

const states = [
    { value: "Australian Capital Territory", label: "Australian Capital Territory" },
    { value: "New South Wales", label: "New South Wales" },
    { value: "Northern Territory", label: "Northern Territory" },
    { value: "Queensland", label: "Queensland" },
    { value: "South Australia", label: "South Australia" },
    { value: "Tasmania", label: "Tasmania" },
    { value: "Victoria", label: "Victoria" },
    { value: "Western Australia", label: "Western Australia" }
]

const SearchLocationFieldSet = ({ formik, disabled, referer, prefilled, theme }: FieldSetProps) => {
    const classes = getClasses({ theme })
    return (
        <Grid gridGap="1un">
            <TextField
                disabled={disabled}
                placeholder="Street Address"
                label="Street Address"
                name="streetAddress"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.streetAddress}
                error={formik.touched.streetAddress ? !!formik.errors.streetAddress : false}
                inputProps={{ "data-cy": "streetAddress" }}
                helperText={formik.errors.streetAddress ? formik.errors.streetAddress : " "}
                autoComplete="new-password"
            />
            <TextField
                disabled={disabled}
                placeholder="Suburb/City"
                label="Suburb/City"
                name="addressLocality"
                onChange={formik.handleChange}
                inputProps={{ "data-cy": "addressLocality" }}
                onBlur={formik.handleBlur}
                value={formik.values.addressLocality}
                error={formik.touched.addressLocality ? !!formik.errors.addressLocality : false}
                helperText={formik.errors.addressLocality ? formik.errors.addressLocality : " "}
                autoComplete="new-password"
            />
            <TextField
                disabled={disabled}
                placeholder="Postal Code"
                label="Postal Code"
                name="postalCode"
                inputProps={{ "data-cy": "postalCode" }}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.postalCode}
                error={formik.touched.postalCode ? !!formik.errors.postalCode : false}
                helperText={formik.errors.postalCode ? formik.errors.postalCode : " "}
                autoComplete="new-password"
            />

            <FormControl
                error={formik.touched.addressCountry ? !!formik.errors.addressCountry : false}
                className={classes.searchDropDown}
            >
                <SearchableDropDown
                    name="addressCountry"
                    value={formik.values.addressCountry}
                    disabled
                    formik={formik}
                    placeholder="Country"
                    options={countries}
                    autoComplete="new-password"
                />
                <FormHelperText>{formik.errors.addressCountry ? formik.errors.addressCountry : ""}</FormHelperText>
            </FormControl>
            <FormControl
                error={formik.touched.addressRegion ? !!formik.errors.addressRegion : false}
                className={classes.searchDropDown}
            >
                <SearchableDropDown
                    name="addressRegion"
                    value={formik.values.addressRegion}
                    disabled={disabled}
                    formik={formik}
                    placeholder="State/Region"
                    options={states}
                    autoComplete="new-password"
                />
                <FormHelperText>{formik.errors.addressRegion ? formik.errors.addressRegion : ""}</FormHelperText>
            </FormControl>
        </Grid>
    )
}
SearchLocationFieldSet.defaultProps = {
    disabled: false,
    referer: false,
    prefilled: false
}
export default withTheme()(SearchLocationFieldSet)
