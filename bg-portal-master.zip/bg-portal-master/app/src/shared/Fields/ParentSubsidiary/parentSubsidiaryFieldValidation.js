// @flow

const validate = (values: Object) => {
    const errors = {}
    if (!values.relationship) {
        errors.relationship = "Required"
    }
    if (!values.permission) {
        errors.permission = "Required"
    }
    if (!values.organisation) {
        errors.organisation = "Required"
    }
    return errors
}

export default validate
