import React from "react"
import PhoneNumberMask from "~/shared/PhoneNumberMask"
import _ from "lodash"
import NumberTextField from "~/shared/NumberTextField"
import MyDatePicker from "~/shared/DatePicker/DatePicker"
import FreeFormTextField from "@material-ui/core/TextField"
import FormControl from "@material-ui/core/FormControl"
import FormHelperText from "@material-ui/core/FormHelperText"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import Typography from "@material-ui/core/Typography"
import Checkbox from "@material-ui/core/Checkbox"
// import BasicSelect from "./BasicSelect"
import SearchableDropDown from "~/shared/SearchableDropDown"

// All CustomInputs are wrapped by the Formik Fields in the purposeFieldset
// Formik fields supply various props to handle the state and validation
// Lodash is used to handle dot chaining. This is due to the PurposeField set using nestedObjects.
// Field names used are dotchained in a string

const CustomInputComponent = ({
    disabled,
    formField,
    field, // { name, value, onChange, onBlur }
    form: { touched, errors, handleChange, handleBlur, submitCount }, // also values, setXXXX, handleXXXX, dirty, isValid, status, etc.
    ...props
}) => (
    <FreeFormTextField
        fullWidth
        placeholder={formField.appearance.label}
        label={`${formField.appearance.label}${!formField.optional ? "*" : ""}`}
        value={field.value || ""}
        onChange={handleChange}
        onBlur={handleBlur}
        disabled={disabled}
        name={field.name}
        error={
            // NOTE submitCount is used to make sure the error colour will work. This is due to formik only recently deciding it should allow fields to construct initial values bottom up rather than declaring inital values at the start. Hopefully will be resolved in future updates
            (_.has(touched, field.name) || submitCount >= 1) && _.has(errors, field.name)
                ? !!_.get(errors, field.name)
                : false
        }
        helperText={_.has(errors, field.name) ? _.get(errors, field.name) : " "}
        {...props}
    />
)

const CustomCheckBoxComponent = ({
    disabled,
    formField,
    field, // { name, value, onChange, onBlur }
    form: { touched, errors, handleChange, handleBlur, submitCount, setFieldValue }, // also values, setXXXX, handleXXXX, dirty, isValid, status, etc.
    ...props
}) => {
    // if value is not a boolean the default value must be made false
    if (typeof field.value !== "boolean") {
        setFieldValue(field.name, false)
    }
    return (
        <FormControl
            fullWidth
            error={
                (_.has(touched, field.name) || submitCount >= 1) && _.has(errors, field.name)
                    ? !!_.get(errors, field.name)
                    : false
            }
            disabled={disabled}
            // required={!formField.optional}
        >
            <FormControlLabel
                control={
                    <Checkbox name={field.name} onChange={handleChange} value={field.name} checked={field.value} />
                }
                label={<Typography>{`${formField.appearance.label}${!formField.optional ? "*" : ""}`}</Typography>}
                disabled={disabled}
                name={field.name}
                helperText={_.has(errors, field.name) ? _.get(errors, field.name) : " "}
                {...props}
            />
            <FormHelperText
                error={
                    (_.has(touched, field.name) || submitCount >= 1) && _.has(errors, field.name)
                        ? !!_.get(errors, field.name)
                        : false
                }
            >
                {_.has(errors, field.name) ? _.get(errors, field.name) : " "}
            </FormHelperText>
        </FormControl>
    )
}

const CustomSelectComponent = ({
    disabled,
    formField,
    field, // { name, value, onChange, onBlur }
    form, // the formik bag
    ...props
}) => {
    const tmp = formField.constraints.find(constraint => constraint.constraintType === "ONE_OF")
    // if it has constraintType "ONE_OF", then the field has an array of values we can use to render in the dropdown.
    // if not, we assume its because we want to render a boolean dropdown
    const options = tmp
        ? tmp.availableValues.map(v => ({ value: v, label: v }))
        : [{ value: true, label: "Yes" }, { value: false, label: "No" }]
    const required = !formField.optional
    const oneOption = options && options.length === 1
    // In the case that the field is required and only has one availableValue the field should be set to that value and made disabled
    // The check for field.value is to make it so it wont go into an endless loop of setting the fieldValue
    if (required && oneOption && options && !field.value) {
        form.setFieldValue(field.name, options[0].value)
    }
    return (
        <FormControl
            error={
                (_.has(form.touched, field.name) || form.submitCount >= 1) && _.has(form.errors, field.name)
                    ? !!_.get(form.errors, field.name)
                    : false
            }
            fullWidth
            // required={required}
        >
            <SearchableDropDown
                value={field.value ? { value: field.value, label: field.value } : field.value}
                placeholder={`${formField.appearance.label}${!formField.optional ? "*" : ""}`}
                onChange={form.handleChange}
                name={field.name}
                // In the case that the field is required and only has one availableValue the field should be set to that value and made disabled
                disabled={disabled || (required && oneOption && options)}
                formik={form}
                id={field.name}
                isSearchable
                options={options || []}
            />
            <FormHelperText>{_.has(form.errors, field.name) ? _.get(form.errors, field.name) : ""}</FormHelperText>
        </FormControl>
    )
}

const CustomDateComponent = ({
    disabled,
    formField,
    field, // { name, value, onChange, onBlur }
    form: { touched, errors, handleChange, handleBlur, setFieldValue, submitCount }, // also values, setXXXX, handleXXXX, dirty, isValid, status, etc.
    ...props
}) => (
    <FormControl
        error={_.has(touched, field.name) && _.has(errors, field.name) ? !!_.get(errors, field.name) : false}
        fullWidth
        disabled={disabled}
        // required={!formField.optional}
    >
        <MyDatePicker
            setDate={setFieldValue}
            onBlur={handleBlur}
            label={formField.appearance.label}
            dateValue={field.value || null}
            disabled={disabled}
            fieldName={field.name}
            error={
                (_.has(touched, field.name) || submitCount >= 1) && _.has(errors, field.name)
                    ? !!_.get(errors, field.name)
                    : false
            }
            styles={{ width: "100%" }}
            {...props}
        />
        <FormHelperText
            error={
                (_.has(touched, field.name) || submitCount >= 1) && _.has(errors, field.name)
                    ? !!_.get(errors, field.name)
                    : false
            }
        >
            {_.has(errors, field.name) ? _.get(errors, field.name) : " "}
        </FormHelperText>
    </FormControl>
)
const CustomNumberFormatComponent = ({
    disabled,
    formField,
    field, // { name, value, onChange, onBlur }
    form: { touched, errors, handleChange, handleBlur, submitCount }, // also values, setXXXX, handleXXXX, dirty, isValid, status, etc.
    ...props
}) => (
    <FreeFormTextField
        // required={!formField.optional}
        label={formField.appearance.label}
        value={field.value}
        name={field.name}
        onChange={handleChange}
        disabled={disabled}
        error={
            (_.has(touched, field.name) || submitCount >= 1) && _.has(errors, field.name)
                ? !!_.get(errors, field.name)
                : false
        }
        helperText={_.has(errors, field.name) ? _.get(errors, field.name) : " "}
        {...props}
        InputProps={{
            inputComponent: NumberTextField
        }}
    />
)
const CustomPhoneNumberComponent = ({
    disabled,
    formField,
    field, // { name, value, onChange, onBlur }
    form: { touched, errors, handleChange, handleBlur, submitCount }, // also values, setXXXX, handleXXXX, dirty, isValid, status, etc.
    ...props
}) => (
    <FreeFormTextField
        // required={!formField.optional}
        label={formField.appearance.label}
        value={field.value}
        name={field.name}
        onChange={handleChange}
        disabled={disabled}
        error={
            (_.has(touched, field.name) || submitCount >= 1) && _.has(errors, field.name)
                ? !!_.get(errors, field.name)
                : false
        }
        helperText={_.has(errors, field.name) ? _.get(errors, field.name) : " "}
        {...props}
        InputProps={{
            inputComponent: PhoneNumberMask
        }}
    />
)

export {
    CustomInputComponent,
    CustomSelectComponent,
    CustomDateComponent,
    CustomNumberFormatComponent,
    CustomPhoneNumberComponent,
    CustomCheckBoxComponent
}
