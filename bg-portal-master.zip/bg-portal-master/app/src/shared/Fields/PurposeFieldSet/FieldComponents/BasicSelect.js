// @flow
import React from "react"
import Select from "@material-ui/core/Select"
import FormControl from "@material-ui/core/FormControl"
import MenuItem from "@material-ui/core/MenuItem"
import InputLabel from "@material-ui/core/InputLabel"

import FormHelperText from "@material-ui/core/FormHelperText"

type BasicSelectType = {
    onChange: Function,
    onBlur: Function,
    label: string,
    value: any,
    options: Array<Object>,
    name: string,
    error: boolean,
    helperText: string
}

const BasicSelect = ({
    onChange,
    onBlur,
    label,
    value,
    options,
    name,
    error,
    helperText,
    ...props
}: BasicSelectType) => (
    <FormControl error={error} fullWidth>
        <InputLabel htmlFor={name} shrink={value !== null && value !== undefined && value !== ""}>
            {label}
        </InputLabel>
        <Select
            value={value}
            onChange={onChange}
            onBlur={onBlur}
            inputProps={{
                name,
                id: name,
                fullWidth: true
            }}
            {...props}
        >
            <MenuItem value="">
                <em>None</em>
            </MenuItem>
            {options && options.map(option => <MenuItem value={option.value}>{option.displayValue}</MenuItem>)}
        </Select>
        <FormHelperText>{helperText || ""}</FormHelperText>
    </FormControl>
)

export default BasicSelect
