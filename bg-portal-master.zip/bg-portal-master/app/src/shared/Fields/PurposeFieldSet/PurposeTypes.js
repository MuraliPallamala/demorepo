// @flow

type Fields = Array<Field>

export type Field = {
    name: string,
    constraints: Array<Constraints>,
    optional?: boolean,
    type: FieldType,
    appearance: Appearance,
    subFields: Fields
}

type FieldType = "STRING" | "NUMBER" | "CHARACTER" | "BOOLEAN" | "TEXT" | "DATE" | "OBJECT" | "LIST"

type Constraints = {
    appliesTo: AppliesTo,
    constraintType: string,
    pattern?: string,
    maxValue?: number,
    minValue?: number,
    includeMax?: boolean,
    includeMin?: boolean
}

type AppliesTo = {
    type: Array<string>
}
type Appearance = {
    width?: number,
    label: string,
    tooltip?: string,
    renderAs?: string
}
export type Templates = Array<Template>
export type Template = {
    name: string,
    fields: Fields,
    active: boolean,
    id: string,
    label: string
}

export type validateTypes = {
    value: any,
    field: Field,
    noRequire: boolean
}
export type renderFieldType = {
    formik: Object,
    field: Object,
    disabled: boolean,
    noRequire: boolean,
    isFilter: boolean,
    parentFieldName: string,
    gridSizing: Function
}

export type renderPurposeProps = {
    theme: Object,
    formik: Object,
    fields: Fields,
    disabled?: boolean,
    noRequire: boolean,
    isFilter: boolean,
    hideTemplateTitles: boolean,
    gridSizing: Function
}

export type PurposeFieldSetProps = {
    fields: Fields,
    disabled?: boolean,
    formik: Object,
    purposeTemplates: Templates,
    theme: Object,
    noRequire: boolean,
    isFilter: boolean,
    hideTemplateTitles: boolean,
    amend: boolean,
    gridSizing: Function,
    hideTemplateFields: boolean
}
