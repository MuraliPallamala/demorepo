// @flow

import React from "react"
import MaterialGrid from "@material-ui/core/Grid"
import { css } from "emotion"
import { Col, WrappedRow } from "~/shared/layout"
import { withTheme } from "@material-ui/core/styles"
import Select from "@material-ui/core/Select"
import FormControl from "@material-ui/core/FormControl"
import MenuItem from "@material-ui/core/MenuItem"
import FormHelperText from "@material-ui/core/FormHelperText"
import Typography from "@material-ui/core/Typography"
import { Field as FormikField } from "formik"
import InputLabel from "@material-ui/core/InputLabel"
import type { PurposeFieldSetProps, validateTypes, renderFieldType, renderPurposeProps, Field } from "./PurposeTypes"
import {
    CustomInputComponent,
    CustomSelectComponent,
    CustomDateComponent,
    CustomCheckBoxComponent
    // ,
    // CustomNumberFormatComponent,
    // CustomPhoneNumberComponent
} from "./FieldComponents"

const getClasses = ({ theme }) => {
    const datePicker = css({
        overflow: "visible"
    })
    const purpose = css({
        width: "45%"
    })
    const subHeading = css({
        fontSize: theme.typography.fontSizeMedium,
        margin: "23px 0px auto 20px"
    })
    const labelColumn = css({
        width: "167px",
        marginRight: "16px"
    })
    const noDataText = css({
        fontSize: theme.typography.fontSizeMedium
    })

    return {
        datePicker,
        purpose,
        subHeading,
        labelColumn,
        noDataText
    }
}

// Handles all the validation, isTouched, etc of the PurposeFields, no default values required
const PurposeFieldSet = ({
    formik,
    theme,
    fields,
    // Intent for 'disabled' prop is to disable all fields and purposeType. Its currently used for Transfer form
    disabled,
    purposeTemplates,
    // 'noRequire''s intent is to make all fields optional. Currently used in the filterPopover
    noRequire,
    // 'amend' Could probably be renamed to disablePurposeType. As all it does is disable the purposeType. Could be used for other things down the track
    amend,
    // isFilter is used to display booleans as dropdowns when it is being rendered in the filter popover
    isFilter,
    hideTemplateTitles,
    hideTemplateFields,
    // Creates grid sizing for Material grid. Should return Object with values, xs, s, md, lg, xl
    gridSizing
}: PurposeFieldSetProps): any => {
    const classes = getClasses({ theme })

    return (
        <React.Fragment>
            <WrappedRow>
                <Col className={classes.labelColumn}>
                    <Typography className={classes.subHeading}>Type</Typography>
                </Col>
                <Col minWidth="150px">
                    <FormControl error={formik.touched.purposeType ? !!formik.errors.purposeType : false}>
                        <InputLabel htmlFor="purposeType">Purpose Type</InputLabel>
                        <Select
                            disabled={disabled || amend}
                            value={formik.values.purposeType}
                            onChange={e => {
                                if (formik.values.purposeType !== e.target.value) {
                                    // Resets purpose to empty object so no leftover values remain after swapping purposeType
                                    formik.setFieldValue("purpose", {})
                                    formik.setFieldValue("purposeType", e.target.value)
                                }
                            }}
                            inputProps={{
                                name: "purposeType",
                                id: "purposeType"
                            }}
                        >
                            <MenuItem value="">
                                <em>None</em>
                            </MenuItem>
                            {purposeTemplates.map(template => (
                                <MenuItem value={template.id}>{template.label}</MenuItem>
                            ))}
                        </Select>
                        <FormHelperText>{formik.errors.purposeType ? formik.errors.purposeType : ""}</FormHelperText>
                    </FormControl>
                </Col>
            </WrappedRow>
            {formik.values.purposeType && !hideTemplateFields
                ? renderPurpose({
                      theme,
                      formik,
                      fields,
                      disabled,
                      noRequire,
                      isFilter,
                      hideTemplateTitles,
                      gridSizing
                  })
                : null}
        </React.Fragment>
    )
}

const renderPurpose = ({
    theme,
    formik,
    fields,
    disabled,
    noRequire,
    isFilter,
    hideTemplateTitles,
    gridSizing
}: renderPurposeProps) => {
    const classes = getClasses({ theme })
    // The aim of the folliwng loop is to create an array of objects. Each object will have a set of fields which will create a wrapped row. A type, and in the case the type is subfields will have a displayGroupName. The purpose of this is to be able to group subfields by a title and render it on the left of the row. The regular field type will just have spacing on the left to make them all inline
    // Subfields are recognised by the type 'subfields'
    const fieldRenderArray = []
    // This array will build up the fieldRow. (I.e fields that are not grouped in a subField)
    // Will be added to the fieldRenderArray and then reset when the next field item has subfields or if it is in the final loop of the fields
    let fieldRowArray = []
    fields.forEach((field, i) => {
        if (field.subFields && field.subFields.length >= 1) {
            if (fieldRowArray.length >= 1) {
                fieldRenderArray.push({ type: "fields", fields: fieldRowArray })
                fieldRowArray = []
            }
            // The subFieldRenderArray is generated if there are any subFields and will create its own row. Thus is in the scope of the field
            const subFieldRenderArray = []
            field.subFields.forEach(subField => {
                // Takes on the object that will be passed directly to renderField
                subFieldRenderArray.push({
                    formik,
                    field: subField,
                    disabled: disabled || false,
                    noRequire,
                    isFilter,
                    parentFieldName: field.name,
                    gridSizing
                })
            })
            // Once all subFields have been added to the subFieldRenderArray the entire array is added to the object to be added to fieldRenderArray.
            fieldRenderArray.push({
                type: "subfields",
                // Used to render the title on the left side of the row
                displayGroupName: field.appearance.label,
                fields: subFieldRenderArray
            })
        } else {
            fieldRowArray.push({
                formik,
                field,
                disabled: disabled || false,
                noRequire,
                parentFieldName: "",
                gridSizing,
                isFilter
            })
        }
        // If this is the final loop push fieldRowArray as there are no more fields to be added
        if (fields.length - 1 === i) {
            fieldRenderArray.push({ type: "fields", fields: fieldRowArray })
            fieldRowArray = []
        }
    })
    return (
        <MaterialGrid>
            {/* Aim is to map through each field, if is type subfield render displayGroupName on the left if not just empty space. It will put each fieldRow on the same line, else on a new line. */}
            {fieldRenderArray.map(fieldRow => (
                <WrappedRow>
                    {hideTemplateTitles ? null : (
                        <Col className={classes.labelColumn}>
                            {fieldRow.type === "subfields" && fieldRow.displayGroupName ? (
                                <Typography className={classes.subHeading}>{fieldRow.displayGroupName}</Typography>
                            ) : null}
                        </Col>
                    )}
                    <WrappedRow flex={1}>
                        <MaterialGrid container spacing={16} alignItems="flex-end">
                            {fieldRow.fields.map(field => renderField(field))}
                        </MaterialGrid>
                    </WrappedRow>
                </WrappedRow>
            ))}
        </MaterialGrid>
    )
}

const createSmallGridSize = (size: ?number) => {
    if (size && size * 2 >= 12) {
        return 12
    } else if (size) {
        return size * 2
    }
    return size
}

PurposeFieldSet.defaultProps = {
    disabled: false,
    noRequire: false,
    amend: false,
    isFilter: false,
    hideTemplateTitles: false,
    hideTemplateFields: false,
    gridSizing: (field: Field) => ({
        // $FlowFixMe
        xs: field.appearance.width * 4 >= 12 ? 12 : field.appearance.width * 4,
        sm: createSmallGridSize(field.appearance.width),
        md: field.appearance.width,
        lg: field.appearance.width,
        // $FlowFixMe
        xl: field.appearance.width
    })
}
// Validate that is run on every field
const validate = ({ value, field, noRequire }: validateTypes) => {
    let errorMessage = ""
    if (!field.optional && value == null && !noRequire) {
        errorMessage = "Required"
    } else if (value && field.constraints && field.constraints.length >= 1) {
        // Goes through each constraint and validates against the value
        field.constraints.forEach(constraint => {
            if (constraint.constraintType === "PATTERN" && constraint.pattern) {
                const pattern = new RegExp(constraint.pattern)
                if (!pattern.test(value)) {
                    errorMessage = "Invalid"
                }
            } else if (
                constraint.constraintType === "MAX_VALUE" &&
                (constraint.maxValue !== null && constraint.maxValue !== undefined)
            ) {
                if ((value >= constraint.maxValue && constraint.includeMax) || value > constraint.maxValue) {
                    errorMessage = "Invalid"
                }
            } else if (
                constraint.constraintType === "MIN_VALUE" &&
                (constraint.minValue !== undefined && constraint.minValue !== null)
            ) {
                if ((constraint.includeMin && value <= constraint.minValue) || value < constraint.minValue) {
                    errorMessage = "Invalid"
                }
            }
        })
    }
    return errorMessage
}

// rendersField, aim is to go through each field and return a FormikField that uses a custom component
const renderField = ({
    formik,
    field,
    disabled,
    noRequire,
    parentFieldName,
    gridSizing,
    isFilter
}: renderFieldType) => {
    if (field.type === "STRING" && !field.constraints.find(constraint => constraint.constraintType === "ONE_OF")) {
        return (
            <MaterialGrid
                item
                // Creates grid sizing for Material grid
                {...gridSizing(field)}
            >
                {/* FormikField is Formiks Field component. Used to manage state/validation/etc of purposefields */}
                <FormikField
                    name={`purpose.${parentFieldName ? `${parentFieldName}.` : ""}${field.name}`}
                    component={CustomInputComponent}
                    formField={field}
                    validate={value => validate({ value, field, noRequire })}
                    disabled={disabled}
                />
            </MaterialGrid>
        )
    }
    if (
        field.type === "BOOLEAN" &&
        // boolean has its to be rendered in the filter popover
        isFilter &&
        !field.constraints.find(constraint => constraint.constraintType === "ONE_OF")
    ) {
        return (
            <MaterialGrid item {...gridSizing(field)}>
                <FormikField
                    name={`purpose.${parentFieldName ? `${parentFieldName}.` : ""}${field.name}`}
                    component={CustomSelectComponent}
                    formField={field}
                    validate={value => validate({ value, field, noRequire })}
                    disabled={disabled}
                />
            </MaterialGrid>
        )
    }
    if (
        field.type === "BOOLEAN" &&
        !isFilter &&
        !field.constraints.find(constraint => constraint.constraintType === "ONE_OF")
    ) {
        return (
            <MaterialGrid
                item
                // Creates grid sizing for Material grid
                {...gridSizing(field)}
            >
                {/* FormikField is Formiks Field component. Used to manage state/validation/etc of purposefields */}
                <FormikField
                    name={`purpose.${parentFieldName ? `${parentFieldName}.` : ""}${field.name}`}
                    component={CustomCheckBoxComponent}
                    formField={field}
                    validate={value => validate({ value, field, noRequire })}
                    disabled={disabled}
                />
            </MaterialGrid>
        )
    }
    if (field.type === "NUMBER" && !field.constraints.find(constraint => constraint.constraintType === "ONE_OF")) {
        return (
            <MaterialGrid
                item
                // Creates grid sizing for Material grid
                {...gridSizing(field)}
            >
                {/* FormikField is Formiks Field component. Used to manage state/validation/etc of purposefields */}
                <FormikField
                    name={`purpose.${parentFieldName ? `${parentFieldName}.` : ""}${field.name}`}
                    component={CustomInputComponent}
                    formField={field}
                    validate={value => validate({ value, field, noRequire })}
                    disabled={disabled}
                    type="number"
                />
            </MaterialGrid>
        )
    }
    if (field.type === "TEXT" && !field.constraints.find(constraint => constraint.constraintType === "ONE_OF")) {
        return (
            <MaterialGrid item {...gridSizing(field)}>
                <FormikField
                    name={`purpose.${parentFieldName ? `${parentFieldName}.` : ""}${field.name}`}
                    component={CustomInputComponent}
                    formField={field}
                    validate={value => validate({ value, field, noRequire })}
                    multiline
                    disabled={disabled}
                />
            </MaterialGrid>
        )
    }
    // Only returns select if the constraint 'ONE_OF' is present. A semi odd way of signifying a Select is required. Works nonetheless.
    // The type can be anything theoretically
    if (field.constraints.find(constraint => constraint.constraintType === "ONE_OF")) {
        return (
            <MaterialGrid item {...gridSizing(field)}>
                <FormikField
                    name={`purpose.${parentFieldName ? `${parentFieldName}.` : ""}${field.name}`}
                    component={CustomSelectComponent}
                    formField={field}
                    validate={value => validate({ value, field, noRequire })}
                    disabled={disabled}
                />
            </MaterialGrid>
        )
    }
    if (field.type === "DATE") {
        return (
            <MaterialGrid item {...gridSizing(field)}>
                <FormikField
                    name={`purpose.${parentFieldName ? `${parentFieldName}.` : ""}${field.name}`}
                    component={CustomDateComponent}
                    formField={field}
                    validate={value => validate({ value, field, noRequire })}
                    disabled={disabled}
                />
            </MaterialGrid>
        )
    }
    return <div>Something went wrong</div>
}

export default withTheme()(PurposeFieldSet)
