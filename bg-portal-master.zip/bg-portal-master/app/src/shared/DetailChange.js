// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import type { GxDetails } from "~/util/flow_types"
import * as gx from "~/util/logic/gx"
import { split } from "~/util/helpers/text"
import { Grid } from "~/shared/layout"

type Props = {
    before: GxDetails,
    after: GxDetails,
    theme: Object
}

const getClasses = ({ theme }) => {
    const bold = css({ fontWeight: theme.typography.fontWeightMedium })
    return {
        bold
    }
}

const DetailChange = ({ before, after, theme }: Props) => {
    const changes = gx.findChanges(before, after)
    const classes = getClasses({ theme })
    const gridDivs = changes.reduce((acc, { key, bv, av }, i) => {
        let beforeString
        let afterString

        if (key === "expiryDate") {
            beforeString = bv ? new Date(bv).toLocaleDateString() : "Open Ended"
            afterString = av ? new Date(av).toLocaleDateString() : "Open Ended"
        } else {
            beforeString = bv || "(empty)"
            afterString = av || "(empty)"
        }

        return acc.concat([
            <div className={classes.bold} key={`${key}-1`}>
                {split(key)}
            </div>,
            <div key={`${key}-2`}>{beforeString}</div>,
            <div key={`${key}-3`}>{afterString}</div>
        ])
    }, [])
    return (
        <Grid gridTemplateColumns="repeat(3, minmax(180px, 20%))" gridGap="1un">
            <div className={classes.bold}>Field</div>
            <div className={classes.bold}>Before</div>
            <div className={classes.bold}>After</div>
            {gridDivs}
        </Grid>
    )
}

export default withTheme()(DetailChange)
