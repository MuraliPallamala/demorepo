import React from "react"
import ErrorDialogContext from "./ErrorDialogContext"

export default function withError(Component) {
    return function ErrorDialogComponent(props) {
        return (
            <ErrorDialogContext.Consumer>
                {({ handleErrorOpen }) => <Component {...props} handleErrorOpen={handleErrorOpen} />}
            </ErrorDialogContext.Consumer>
        )
    }
}
