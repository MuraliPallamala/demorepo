// @flow
import React from "react"
import { withRouter } from "react-router-dom"

import Dialog from "@material-ui/core/Dialog"

import ErrorDetails from "./Components/ErrorDetails"
import ErrorDialogContext from "./ErrorDialogContext"

type State = {
    errorOpen: boolean,
    errorMessage: string,
    extraDetails: string,
    title: string,
    error: Object
}
type Props = {
    children: any,
    history: Object
}

class ErrorDialogProviderContainer extends React.Component<Props, State> {
    state = {
        errorOpen: false,
        errorMessage: "Error getting your token",
        extraDetails: "",
        title: "Server Error",
        error: {}
    }
    setDetails = ({ errorMessage, title, extraDetails, error, errorDetails }) => {
        if (errorMessage !== "" && title && extraDetails) {
            this.setState({
                errorMessage: `${errorMessage}: ${errorDetails}`,
                title,
                extraDetails: JSON.stringify(extraDetails),
                errorOpen: true,
                error
            })
        } else if (errorMessage !== "" && title) {
            this.setState({
                errorMessage: `${errorMessage}: ${errorDetails}`,
                title,
                errorOpen: true,
                error
            })
        } else {
            this.setState({
                errorMessage: `${errorMessage}: ${errorDetails}`,
                errorOpen: true,
                error
            })
        }
    }
    handleErrorOpen = ({ errorMessage, title, extraDetails, error, alternateDetails }) => {
        if (error) {
            if (error.response) {
                const errorDetails = error.response.data.message
                this.setDetails({ errorMessage, errorDetails, title, extraDetails, error })
            } else if (error.request) {
                const errorDetails = " Server Request Failed "
                this.setDetails({ errorMessage, errorDetails, title, extraDetails, error })
            } else if (error.message) {
                const errorDetails = error.message
                this.setDetails({ errorMessage, errorDetails, title, extraDetails, error })
            } else {
                this.setDetails({ errorMessage, errorDetails: "Unknown Error", title, extraDetails, error })
            }
        } else if (alternateDetails) {
            this.setDetails({ errorMessage, errorDetails: alternateDetails, title, extraDetails, error })
        } else {
            this.setDetails({ errorMessage, errorDetails: "Unknown Error", title, extraDetails, error })
        }
    }

    handleErrorClose = () => {
        this.setState({
            errorOpen: false,
            title: "Server Error"
        })
        if (this.state.error.code === 1402) {
            this.props.history.push("/logout")
        }
        if (
            // if a requst is no longer active, we want to refresh the page to prevent the user to click the same button again.
            // TODO: if reloading doesn't work, this is why - might have to check if the error code is exposed in this way.
            this.state.error.response.data.code % 10000 === 3000 || // approved
            this.state.error.response.data.code % 10000 === 3001 || // cancelled
            this.state.error.response.data.code % 10000 === 3002 || // rejected
            this.state.error.response.data.code % 10000 === 3003 || // withdrawn
            this.state.error.response.data.code % 10000 === 3004 // expired (currently not in use)
        ) {
            window.location.reload()
        }
    }

    render() {
        const { children } = this.props
        const { title, errorMessage, errorOpen, extraDetails } = this.state
        return (
            <ErrorDialogContext.Provider
                value={{
                    handleErrorOpen: this.handleErrorOpen,
                    handleErrorClose: this.handleErrorClose
                }}
            >
                <Dialog open={errorOpen} maxWidth="md" onClose={this.handleErrorClose}>
                    <ErrorDetails
                        handleClose={this.handleErrorClose}
                        title={title}
                        errorMessage={errorMessage}
                        extraDetails={extraDetails}
                    />
                </Dialog>
                {children}
            </ErrorDialogContext.Provider>
        )
    }
}

export default withRouter(ErrorDialogProviderContainer)
