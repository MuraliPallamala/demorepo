import React from "react"

const ErrorDialogContext = React.createContext({
    handleErrorOpen: () => {},
    handleErrorClose: () => {}
})

export default ErrorDialogContext
