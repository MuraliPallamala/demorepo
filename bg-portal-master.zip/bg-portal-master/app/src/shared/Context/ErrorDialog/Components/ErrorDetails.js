// @flow
import React from "react"
import { withRouter } from "react-router-dom"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import DownArrow from "@material-ui/icons/KeyboardArrowDown"
import UpArrow from "@material-ui/icons/KeyboardArrowUp"
import DialogContent from "@material-ui/core/DialogContent"
import DialogContentText from "@material-ui/core/DialogContentText"
import DialogTitle from "@material-ui/core/DialogTitle"
import DialogActions from "@material-ui/core/DialogActions"
import WarningIcon from "@material-ui/icons/Warning"
import { CopyToClipboard } from "react-copy-to-clipboard"
import ReactJson from "react-json-view"
import { Flex } from "~/shared/layout"

type State = {
    detailsOpen: boolean,
    copied: boolean
}
type Props = {
    handleClose: Function,
    errorMessage: string,
    extraDetails: string,
    title: string,
    theme: Object
}
const getClasses = theme => {
    const icon = css({
        verticalAlign: "middle",
        marginRight: theme.spacing.unit,
        fill: theme.palette.common.defaultRed
    })
    const button = css(theme.typography.button)
    const titleStyle = css({ h2: { color: `${theme.palette.common.darkBlue}!important` } })

    return {
        icon,
        button,
        titleStyle
    }
}
class ErrorDetails extends React.Component<Props, State> {
    state = {
        detailsOpen: true,
        copied: false
    }
    toggleDetails = () => {
        if (this.state.detailsOpen) {
            this.setState({ detailsOpen: false })
        } else {
            this.setState({ detailsOpen: true })
        }
    }

    render() {
        const { handleClose, extraDetails, title, theme, errorMessage } = this.props
        const { detailsOpen, copied } = this.state
        const classes = getClasses(theme)

        return (
            <React.Fragment>
                <DialogTitle classes={{ root: classes.titleStyle }}>
                    <WarningIcon className={classes.icon} titleAccess="Error Icon" />
                    {title}
                </DialogTitle>
                <DialogContent>
                    <React.Fragment>
                        <DialogContentText>{errorMessage}</DialogContentText>
                        {extraDetails && extraDetails !== "" && extraDetails !== '""' && (
                            <React.Fragment>
                                <Flex>
                                    <Flex flex="1">
                                        <Button onClick={() => this.toggleDetails()}>
                                            Error Logs
                                            <DownArrow hidden={!detailsOpen} />
                                            <UpArrow hidden={detailsOpen} />
                                        </Button>
                                    </Flex>
                                    <Flex>
                                        {copied ? (
                                            <span>
                                                <Typography>Copied</Typography>
                                            </span>
                                        ) : (
                                            ""
                                        )}
                                        <CopyToClipboard
                                            text={extraDetails}
                                            onCopy={() => this.setState({ copied: true })}
                                        >
                                            <Button>Copy logs to clipboard</Button>
                                        </CopyToClipboard>{" "}
                                    </Flex>
                                </Flex>
                                <div hidden={detailsOpen} style={{ overflowWrap: "break-word" }}>
                                    <ReactJson enableClipboard={false} src={JSON.parse(extraDetails)} />
                                </div>
                            </React.Fragment>
                        )}
                    </React.Fragment>
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={handleClose}
                        // className={classes.button}
                        autoFocus
                    >
                        Ok
                    </Button>
                </DialogActions>
            </React.Fragment>
        )
    }
}

export default withRouter(withTheme()(ErrorDetails))
