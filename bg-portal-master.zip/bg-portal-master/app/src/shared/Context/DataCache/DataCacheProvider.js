// @flow

import React, { Component } from "react"
import { withRouter } from "react-router-dom"
import axios from "axios"
import api from "~/util/api"
import withError from "~/shared/Context/ErrorDialog/withError"
import { authStorage } from "~/util/auth"
import DataCacheContext from "./DataCacheContext"

type Props = {
    // handleErrorOpen: Function,
    children: any
}

type Context = {
    apiAuth: Object,
    apiKeys: Object,
    approvalModel: Object,
    attachments: Array<any>,
    bankAccounts: Array<Object>,
    businessId: string,
    contacts: Array<Object>,
    createdAt: string,
    credentials: Object,
    email: string,
    entityAddress: Object,
    entityName: string,
    entityType: string,
    firstName: string,
    gxLimit: number,
    id: string,
    key: string,
    lastName: string,
    phone: string,
    primaryOrgId: string,
    relationships: Array<any>,
    roles: Array<Object>,
    status: string,
    updatedAt: string,
    userAuth: Object,
    userRoles: Object
}
type State = {
    context: Context,
    actingOnBehalf: ?Object,
    isLoaded: boolean
}

class DataCacheProvider extends Component<Props, State> {
    constructor() {
        super()
        this.state = {
            context: {
                apiAuth: {},
                apiKeys: {},
                approvalModel: {},
                attachments: [],
                bankAccounts: [],
                businessId: "",
                contacts: [],
                createdAt: "",
                credentials: {},
                email: "",
                entityAddress: {},
                entityName: "",
                entityType: "",
                firstName: "",
                gxLimit: -1,
                id: "",
                key: "",
                lastName: "",
                phone: "",
                primaryOrgId: "",
                relationships: [],
                roles: [],
                status: "",
                updatedAt: "",
                userAuth: {},
                userRoles: {}
            },
            actingOnBehalf: null,
            isLoaded: false
        }
    }

    componentDidMount() {
        this.getDataFromAPI()
    }

    getDataFromAPI = () => {
        api.general
            .multipleApis([api.settings.getOrgSettings(), api.user.getUser(), api.settings.getCurrentOrg()])
            .then(
                axios.spread((orgSettings, UserInformation, CurrentOrg) => {
                    delete CurrentOrg.data.id
                    const returnData = { ...orgSettings.data, ...UserInformation.data, ...CurrentOrg.data }
                    const actingOn = authStorage.getActingOn()
                    if (actingOn) {
                        this.updateActingOrg({ value: actingOn, id: actingOn })
                    }
                    this.setState({ context: returnData, isLoaded: true })
                })
            )
            .catch(err => {
                console.log("Context Error", err)
            })
    }

    updateSettings = () =>
        api.settings
            .getOrgSettings()
            .then(({ data }) => this.setState(prevState => ({ context: { ...prevState.context, ...data } })))

    isAdmin = currentUser => {
        if (currentUser.userRoles && currentUser.userRoles[currentUser.primaryOrgId]) {
            return currentUser.userRoles[currentUser.primaryOrgId].includes("ADMIN")
        }
        return false
    }
    isPrimary = currentUser => {
        if (currentUser.userRoles && currentUser.userRoles[currentUser.primaryOrgId]) {
            return currentUser.userRoles[currentUser.primaryOrgId].includes("PRIMARY")
        }
        return false
    }

    updateActingOrg = async (org: Object, onChange?: Function) => {
        if (org.value) {
            let res
            try {
                res = await Promise.all([
                    api.organisations.getOrganisations(org.value),
                    api.manageOrgSettings.retrieveAprovalModel(org.value)
                ])
            } catch (err) {
                console.log("Context Error", err)
                throw new Error(`Context Error ${err.Error()}`)
            }
            // $FlowFixMe
            const [orgDetails, orgSettings] = res
            this.setState({
                actingOnBehalf: {
                    ...org,
                    ...orgDetails.data,
                    label: orgDetails.data.profile.entityName,
                    approvalModel: orgSettings.data
                }
            })
            authStorage.setActingOn(org.value)
            if (onChange) {
                onChange()
            }
        } else {
            this.setState({ actingOnBehalf: null })
            authStorage.removeActingOn()
            if (onChange) {
                onChange()
            }
        }
    }

    render() {
        const { context, isLoaded, actingOnBehalf } = this.state
        return (
            <DataCacheContext.Provider
                value={{
                    ...context,
                    isAdmin: this.isAdmin(context),
                    isPrimary: this.isPrimary(context),
                    update: this.getDataFromAPI,
                    updateSettings: this.updateSettings,
                    actingOnBehalf,
                    updateActingOrg: this.updateActingOrg,
                    isLoaded,
                    currentOrgId: actingOnBehalf ? actingOnBehalf.id : context.primaryOrgId
                }}
            >
                {this.props.children}
            </DataCacheContext.Provider>
        )
    }
}

export default withRouter(withError(DataCacheProvider))
