// @flow

import React from "react"

export type Filters = {
    status?: Array<string>,
    issuedAfter?: Object,
    issuedBefore?: Object,
    expiredAfter?: Object,
    expiredBefore?: Object,
    amountSmallerThan?: number,
    amountGreaterThan?: number,
    applicantId?: string,
    beneficiaryId?: string,
    purpose?: Object,
    purposeType?: string
}

type FilterContextInput = {
    filters: Filters,
    replaceFilters: Function,
    addFilter: Function,
    removeFilter: Function
}

const FilterContext = React.createContext(
    ({
        filters: {},
        replaceFilters: filters => {},
        addFilter: (key, value) => {},
        removeFilter: key => {}
    }: FilterContextInput)
)

export function withFilter(Component: any) {
    return (props: any) => (
        <FilterContext.Consumer>{filterProps => <Component {...props} {...filterProps} />}</FilterContext.Consumer>
    )
}

export default FilterContext
