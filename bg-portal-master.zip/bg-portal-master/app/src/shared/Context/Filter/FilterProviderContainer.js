import React from "react"
import { withRouter } from "react-router-dom"
import queryString from "query-string"
import _ from "lodash/fp"
import regLodash from "lodash"
import FilterContext from "./FilterContext"

const qsOptions = { arrayFormat: "bracket" }

const stringify = filters => {
    const filtersCopy = { ...filters }
    Object.entries(filtersCopy).forEach(([key, value]) => {
        if (_.isObject(value) && !Array.isArray(value)) {
            filtersCopy[key] = JSON.stringify(value)
        }
    })
    return queryString.stringify(filtersCopy, qsOptions)
}

const parse = search => {
    const filters = queryString.parse(search, qsOptions)
    Object.entries(filters).forEach(([key, value]) => {
        if (value.length > 1 && value[0] === "{" && value[value.length - 1] === "}") {
            filters[key] = JSON.parse(value)
        }
    })
    // NOTE: Temp hack job, remove issuerPrefillRequest from filters obj if it exists
    // because it is not a filter but a query param used for something else
    delete filters.issuerPrefillRequest
    return filters
}

class FilterProviderContainer extends React.Component {
    replaceFilters = filters => {
        const { history, location } = this.props
        const newSearch = `?${stringify(filters)}`
        if (location.search !== newSearch) {
            history.replace(`${location.pathname}${newSearch}`)
        }
    }

    addFilter = (key, value) => {
        const { location, history } = this.props
        const filters = parse(location.search)
        if (!_.isEqual(filters[key])(value)) {
            filters[key] = value
            const newSearch = `?${stringify(filters)}`
            history.replace(`${location.pathname}${newSearch}`)
        }
    }
    // Remove a list of keys from the filters
    removeFilters = keys => {
        const { location, history } = this.props
        const filters = parse(location.search)
        // Lodah is used to delete the values as in the case the key is from a chip nested in the purpose the key is a dotchained string
        keys.forEach(key => {
            if (regLodash.has(filters, key)) {
                regLodash.unset(filters, key)
            }
        })
        const newSearch = `?${stringify(filters)}`
        history.replace(`${location.pathname}${newSearch}`)
    }

    removeFilter = key => {
        const { location, history } = this.props
        const filters = parse(location.search)
        // Lodah is used to delete the values as in the case the key is from a chip nested in the purpose the key is a dotchained string
        if (regLodash.has(filters, key)) {
            regLodash.unset(filters, key)
            const newSearch = `?${stringify(filters)}`
            history.replace(`${location.pathname}${newSearch}`)
        }
    }

    render() {
        const { children, location } = this.props
        const filters = parse(location.search)
        return (
            <FilterContext.Provider
                value={{
                    filters,
                    replaceFilters: this.replaceFilters,
                    addFilter: this.addFilter,
                    removeFilter: this.removeFilter,
                    removeFilters: this.removeFilters
                }}
            >
                {children}
            </FilterContext.Provider>
        )
    }
}

export default withRouter(FilterProviderContainer)
