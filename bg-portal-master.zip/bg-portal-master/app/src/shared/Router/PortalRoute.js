// @flow

import React from "react"
import { Route, Redirect } from "react-router-dom"

type Props = {
    render: Function,
    portalOrg: string | Array<string>,
    portalType: string | Array<string>
}

const portalTypeCheck = portalType =>
    !portalType || (typeof portalType === "string" && portalType === PORTAL_TYPE) || portalType.includes(PORTAL_TYPE)

const portalOrgCheck = portalOrg => true
// !portalOrg || (typeof portalOrg === "string" && portalOrg === PORTAL_ORG) || portalOrg.includes(PORTAL_ORG)

const PortalRoute = ({ render, portalType, portalOrg, ...rest }: Props) => (
    <Route
        {...rest}
        render={props => {
            if (portalTypeCheck(portalType) && portalOrgCheck(portalOrg)) {
                return render(props)
            }

            // if ((!portalTypes || portalTypes === PORTAL_TYPE) && (!portalOrg || portalOrg === PORTAL_ORG)) {
            //     return render(props)
            // }
            return (
                <Redirect
                    to={{
                        pathname: "/",
                        state: { from: props.location }
                    }}
                />
            )
        }}
    />
)

export default PortalRoute
