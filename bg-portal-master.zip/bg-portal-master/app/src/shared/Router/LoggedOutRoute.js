import React from "react"
import { Redirect } from "react-router-dom"
import { authStorage } from "~/util/auth"
import PortalRoute from "./PortalRoute"

const LoggedOutRoute = ({ render, ...rest }) => (
    <PortalRoute
        {...rest}
        render={props => {
            const hasUser = authStorage.hasTokenSet()
            if (!hasUser) {
                return render(props)
            }
            return (
                <Redirect
                    to={{
                        pathname: "/",
                        state: { from: props.location }
                    }}
                />
            )
        }}
    />
)

export default LoggedOutRoute
