// @flow

import React from "react"
import CircularProgress from "@material-ui/core/CircularProgress"

type Props = { show: boolean, size: number }

const Loading = ({ show, size }: Props) => (
    <CircularProgress
        size={size}
        left={0}
        top={0}
        // loadingColor="#FF9800"
        status={show ? "loading" : "hide"}
        style={{
            display: "inline-block",
            position: "relative"
        }}
    />
)

Loading.defaultProps = {
    size: 100
}

export default Loading
