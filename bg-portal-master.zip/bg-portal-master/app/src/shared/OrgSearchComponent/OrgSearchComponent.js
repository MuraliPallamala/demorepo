// @flow

import React from "react"
import AsyncSelect from "react-select/lib/Async"
import debounce from "lodash/debounce"
import { withStyles } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"
import TextField from "@material-ui/core/TextField"
import Paper from "@material-ui/core/Paper"
import MenuItem from "@material-ui/core/MenuItem"
import { emphasize } from "@material-ui/core/styles/colorManipulator"
import api from "~/util/api"
import { components as reactSelectComponents } from "react-select"
import ArrowDropDown from "@material-ui/icons/ArrowDropDown"
import elasticlunr from "elasticlunr"

const styles = theme => ({
    root: {
        flexGrow: 1
    },
    input: {
        display: "flex",
        width: "100%",
        flex: 1,
        padding: 0
    },
    valueContainer: {
        display: "flex",
        flex: 1
    },
    chip: {
        margin: `${theme.spacing.unit / 2}px ${theme.spacing.unit / 4}px`
    },
    chipFocused: {
        backgroundColor: emphasize(
            theme.palette.type === "light" ? theme.palette.grey[300] : theme.palette.grey[700],
            0.08
        )
    },
    noOptionsMessage: {
        padding: `${theme.spacing.unit}px ${theme.spacing.unit * 2}px`
    },
    singleValue: {
        fontSize: 16
    },
    paper: {
        position: "absolute",
        marginTop: theme.spacing.unit,
        zIndex: 100
    },
    placeholder: {
        position: "absolute",
        fontSize: 16
    },
    divider: {
        height: theme.spacing.unit * 2
    },
    boldText: { fontSize: theme.typography.fontSizeSmall, fontWeight: theme.typography.fontWeightMedium },
    textStyle: { fontSize: theme.typography.fontSizeSmall, fontWeight: theme.typography.fontWeightRegular }
})

const index = elasticlunr(function() {
    this.addField("entityName")
})

function NoOptionsMessage(props) {
    return (
        <Typography color="textSecondary" className={props.selectProps.classes.noOptionsMessage} {...props.innerProps}>
            {props.selectProps.inputValue && props.selectProps.inputValue !== "" ? props.children : "Start Typing..."}
        </Typography>
    )
}

function inputComponent({ inputRef, ...props }) {
    return <div ref={inputRef} {...props} />
}

function Option(props) {
    const abnAcn = props.data.abnAcn.split("_")
    return (
        <MenuItem
            buttonRef={props.innerRef}
            selected={props.isFocused}
            component="div"
            style={{
                fontWeight: props.isSelected ? 500 : 400
            }}
            {...props.innerProps}
        >
            <Typography>
                <span className={props.selectProps.classes.boldText}>Add</span>
                <span className={props.selectProps.classes.textStyle}> {props.data.entityName}</span>
                {"   "}
                <span className={props.selectProps.classes.boldText}>{abnAcn[0]}</span>
                <span className={props.selectProps.classes.textStyle}> {abnAcn[1]}</span>
            </Typography>
        </MenuItem>
    )
}

function ValueContainer(props) {
    return <div className={props.selectProps.classes.valueContainer}>{props.children}</div>
}

function Menu(props) {
    return (
        <Paper square className={props.selectProps.classes.paper} {...props.innerProps}>
            {props.children}
        </Paper>
    )
}

type Props = {
    classes: Object,
    theme: Object,
    formik: Object,
    value: Object,
    name: string,
    disabled: boolean,
    propsOnChange: ?Function,
    currentUserInformation: Object,
    transfer: boolean,
    placeholder: string,
    clearable: boolean
}
type State = {}
class OrgSearchComponent extends React.Component<Props, State> {
    static defaultProps = {
        disabled: false,
        propsOnChange: null,
        currentUserInformation: {},
        transfer: false,
        placeholder: "",
        clearable: true
    }

    componentDidMount() {
        this.populateIndex()
    }

    populateIndex = async () => {
        const indexedItems = await api.organisations.getOrganisations("").then(({ data }) => data.result)
        indexedItems.forEach(item => index.addDoc(item))
    }

    getApi = async inputValue => {
        if (inputValue.match(/^\d/) && inputValue.length >= 3) {
            return api.organisations.getOrganisations(`?businessId=${inputValue}`)
        }
        const indexResult = index.search(inputValue, { expand: true })

        return {
            data: {
                result: await Promise.all(
                    indexResult.map(result =>
                        api.organisations.getOrganisations(result.ref).then(entity => entity.data.profile)
                    )
                )
            }
        }
    }

    debouncedFetch = debounce((searchTerm, callback) => {
        this.getApi(searchTerm)
            .then(({ data }) => {
                const filteredList = data.result.filter(
                    item => item.entityType === "APPLICANT_OR_BENEFICIARY" && item.status === "ACTIVE"
                )

                const returnList = filteredList.map(item => ({
                    label: item.entityName,
                    value: item.entityName,
                    abnAcn: item.businessId,
                    entityName: item.entityName,
                    orgId: item.id
                }))
                return returnList
            })
            .then(list => callback(list))
            .catch(error => console.log("Error", error))
    }, 500)
    render() {
        const {
            classes,
            theme,
            formik,
            value,
            name,
            disabled,
            propsOnChange,
            currentUserInformation,
            transfer,
            placeholder,
            clearable
        } = this.props
        const getColor = (formikProp: Object, isDisabled: boolean, fieldName: string) => {
            if (isDisabled) {
                return theme.palette.common.defaultGrey
            }
            if (formikProp.touched[fieldName] && formikProp.errors[fieldName]) {
                return "#FF0000"
            }
            return null
        }

        const SingleValue = props => (
            <div
                style={{
                    color: getColor(formik, disabled, name),
                    position: "absolute",
                    marginLeft: "2px",
                    alignSelf: "center"
                }}
                {...props.innerProps}
            >
                {props.children}
            </div>
        )
        const selectStyles = {
            control: base => ({
                ...base,
                borderColor: getColor(formik, disabled, name)
            }),
            input: base => ({
                ...base,
                color: getColor(formik, disabled, name)
            }),
            dropdownIndicator: () => ({
                padding: 0
            }),
            indicatorSeparator: base => ({
                ...base,
                display: "none"
            }),
            placeholder: base => ({
                ...base,
                color: getColor(formik, disabled, name)
            })
        }
        const Control = props => (
            <TextField
                fullWidth
                placeholder="Search"
                disabled={disabled}
                error={!!formik.touched[name] && !!formik.errors[name]}
                InputProps={{
                    inputComponent,
                    inputProps: {
                        className: props.selectProps.classes.input,
                        inputRef: props.innerRef,
                        children: props.children,
                        ...props.innerProps
                    }
                }}
                {...props.selectProps.textFieldProps}
            />
        )
        const DropdownIndicator = props =>
            reactSelectComponents.DropdownIndicator && (
                <reactSelectComponents.DropdownIndicator {...props}>
                    <ArrowDropDown />
                </reactSelectComponents.DropdownIndicator>
            )
        const ClearIndicator = null
        function Placeholder(props) {
            return (
                <Typography
                    color={formik.touched[name] && formik.errors[name] ? "error" : "textSecondary"}
                    className={props.selectProps.classes.placeholder}
                    {...props.innerProps}
                >
                    {props.children}
                </Typography>
            )
        }
        const onChange = (fieldName, e) => {
            if (propsOnChange) {
                propsOnChange(fieldName, e, formik, currentUserInformation, transfer)
            } else {
                formik.setFieldValue(fieldName, e)
            }
        }
        const components = {
            Option,
            Control,
            NoOptionsMessage,
            Placeholder,
            SingleValue,
            ValueContainer,
            Menu,
            DropdownIndicator,
            ClearIndicator
        }
        return (
            <div className={classes.root}>
                <AsyncSelect
                    classes={classes}
                    value={value}
                    onChange={e => {
                        onChange(name, e)
                    }}
                    textFieldProps={{
                        label: placeholder || "",
                        InputLabelProps: {
                            shrink: true
                        }
                    }}
                    name={name}
                    id={name}
                    loadOptions={this.debouncedFetch}
                    styles={selectStyles}
                    components={components}
                    isDisabled={disabled}
                    loadingMessage={() => <Typography>Loading...</Typography>}
                    placeholder={placeholder || "Start Typing..."}
                    backspaceRemovesValue
                    isClearable={clearable}
                />
            </div>
        )
    }
}

export default withStyles(styles, { withTheme: true })(OrgSearchComponent)
