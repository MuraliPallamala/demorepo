// @flow

import React from "react"
import DialogContentText from "@material-ui/core/DialogContentText"
import CustomRequestDialog from "./CustomRequestDialog"

type Props = {
    title: string,
    message: string,
    submitText?: string, // eslint-disable-line react/require-default-props
    cancelText?: string, // eslint-disable-line react/require-default-props
    onSubmit: Function,
    handleClose: Function,
    open: boolean,
    submitting: boolean,
    hasCancelButton: boolean
}

const RequestDialog = ({ message, title, submitting, hasCancelButton, ...other }: Props) => (
    <CustomRequestDialog
        {...other}
        submitting={submitting}
        renderTitle={() => title}
        hasCancelButton={hasCancelButton}
        renderContent={() => <DialogContentText>{message}</DialogContentText>}
    />
)

RequestDialog.defaultProps = {
    submitting: false,
    hasCancelButton: true
}
export default RequestDialog
