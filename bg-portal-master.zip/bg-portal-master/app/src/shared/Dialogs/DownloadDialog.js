// @flow

import React from "react"
import MyDatePicker from "~/shared/DatePicker/DatePicker"
import { Formik } from "formik"
import saveAs from "file-saver/src/FileSaver"
import CustomRequestDialog from "./CustomRequestDialog"

type Props = {
    onSubmit: Function,
    handleClose: Function,
    open: boolean,
    submitting: boolean,
    hasCancelButton: boolean,
    parentOrgId: string
}

const DownloadDialog = ({ submitting, onSubmit, hasCancelButton, parentOrgId, ...other }: Props) => (
    <Formik
        onSubmit={(values, { setSubmitting, setErrors, setStatus }) => {
            setSubmitting(true)
            setStatus()
            const createQueryString = () => {
                const mappedValues = { parentOrgId, date: values.dateAt }
                let queryString = Object.keys(mappedValues)
                    .filter(key => mappedValues[key])
                    .map(key => `${key}=${mappedValues[key]}`)
                    .join("&")
                queryString = `?${queryString}`
                return queryString
            }
            onSubmit(createQueryString())
                .then(data => {
                    const header = data.headers["content-disposition"]
                        .split(";")[1]
                        .trim()
                        .split("=")[1]
                    const filename = header.replace(/"/g, "")
                    const file = new Blob([data.data], {
                        type: data.headers["content-type"],
                        responseType: data.headers["content-disposition"]
                    })
                    saveAs(file, filename)

                    setSubmitting(false)
                })
                .catch(err => {
                    console.log("Error", err)

                    setSubmitting(false)
                })
        }}
        render={formikProps => (
            <CustomRequestDialog
                {...other}
                submitting={submitting}
                onSubmit={() => formikProps.handleSubmit()}
                renderTitle={() => "Download User Permissions"}
                hasCancelButton={hasCancelButton}
                renderContent={() => (
                    <React.Fragment>
                        <MyDatePicker
                            fieldName="dateAt"
                            label="Select Date"
                            dateValue={formikProps.values.dateAt}
                            setDate={formikProps.setFieldValue}
                            clearable={false}
                            disableFuture
                        />
                    </React.Fragment>
                )}
                submitText="Download"
                cancelText="Exit"
            />
        )}
    />
)

DownloadDialog.defaultProps = {
    submitting: false,
    hasCancelButton: true
}
export default DownloadDialog
