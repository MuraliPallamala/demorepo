// @flow

import * as React from "react"
import Typography from "@material-ui/core/Typography"
import Divider from "@material-ui/core/Divider"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Button from "@material-ui/core/Button"
import Dialog from "@material-ui/core/Dialog"
import DialogActions from "@material-ui/core/DialogActions"
import DialogContent from "@material-ui/core/DialogContent"
import { Link } from "react-router-dom"

type Props = {
    history: Object,
    match: Object,
    theme: Object,
    finishDialogOpen: boolean,
    closeFinishDialog: Function
}

const getClasses = ({ theme }) => {
    const buttonColor = css({
        color: theme.typography.button.color
    })
    const textColor = css({
        color: theme.typography.cardTitle.color
    })

    return {
        textColor,
        buttonColor
    }
}

const BookmarkDialog = ({ history, match, theme, finishDialogOpen, closeFinishDialog }: Props) => {
    const getLoginUrl = () => {
        const { requestKey } = match.params
        return `${window.location.origin}/login/${requestKey.substr(0, 4)}`
    }

    const redirectToLogin = () => {
        const { requestKey } = match.params
        history.push(`/login/${requestKey.substr(0, 4)}`)
    }
    const classes = getClasses({ theme })
    const { requestKey } = match.params
    return (
        <React.Fragment>
            <Dialog open={finishDialogOpen} onClose={closeFinishDialog} maxWidth="md">
                <DialogContent>
                    <div>
                        <Typography className={classes.textColor}>
                            Great, here is the link you will need to log in into the platform next time. <br />
                            Please bookmark this link - this link can be found under <br /> settings {`>`} organisation
                            details.
                            <br />
                            {PORTAL_TYPE === "user" && (
                                <span>
                                    **IMPORTANT** Please save this code as it is your organisations unique identifier
                                    <br />
                                    <b>{requestKey.substr(0, 4)}</b>{" "}
                                </span>
                            )}
                        </Typography>
                        <br />
                        <Divider />
                        <br />
                        {PORTAL_TYPE === "user" ? (
                            <Link to={`/login/${requestKey.substr(0, 4)}`}>
                                <Typography>{getLoginUrl()}</Typography>
                            </Link>
                        ) : (
                            <Link to="/login">
                                <Typography>{window.location.origin}/login</Typography>
                            </Link>
                        )}
                    </div>
                </DialogContent>
                <DialogActions>
                    <React.Fragment>
                        <Button onClick={redirectToLogin} className={classes.buttonColor} autoFocus>
                            Redirect to Log in
                        </Button>
                    </React.Fragment>
                </DialogActions>
            </Dialog>
        </React.Fragment>
    )
}

export default withTheme()(BookmarkDialog)
