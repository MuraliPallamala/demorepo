// @flow
import React from "react"
import { withTheme } from "@material-ui/core/styles"
import Dialog from "@material-ui/core/Dialog"
import DialogActions from "@material-ui/core/DialogActions"
import DialogContent from "@material-ui/core/DialogContent"
import DialogTitle from "@material-ui/core/DialogTitle"
import Button from "@material-ui/core/Button"
// import Typography from "@material-ui/core/Typography"
import { Formik } from "formik"
// import Divider from "@material-ui/core/Divider"
import { css } from "emotion"
import { Flex } from "~/shared/layout"
import DemandFieldSet, {
    validate as demandDetailsFieldSetValidate
} from "~/shared/Fields/DemandFieldSet/DemandFieldSet"
import { demandDefaultValues } from "~/util/guarantee"
import withError from "~/shared/Context/ErrorDialog/withError"

type State = {}
type Props = {
    theme: Object,
    open: boolean,
    initialValues: Object,
    // handleErrorOpen: Function,
    onSubmit: Function,
    closeDialog: Function,
    maxValue: number,
    minValue: number
}

const getClasses = ({ theme }) => {
    const button = css(theme.typography.button)
    const titleStyle = css({ h2: { color: `${theme.palette.common.darkBlue}!important` } })
    const dialog = css({ height: "548px", maxWidth: "850px" })
    const dialogActions = css({
        //  justifyContent: "flex-start"
    })
    const dialogContent = css({
        overflow: "hidden"
    })
    return {
        button,
        titleStyle,
        dialog,
        dialogActions,
        dialogContent
    }
}

class DemandDialog extends React.Component<Props, State> {
    static defaultProps = {
        initialValues: {},
        onSubmit: values => console.log("values", values)
    }

    onSubmit = (values: Object) => {
        this.props.onSubmit(values)
    }

    render() {
        const { initialValues, theme, maxValue, minValue } = this.props
        const classes = getClasses({ theme })

        return (
            <Formik
                initialValues={{
                    ...demandDefaultValues,
                    ...initialValues
                }}
                validate={values => ({
                    ...demandDetailsFieldSetValidate({ values, maxValue, minValue })
                })}
                enableReinitialize
                onSubmit={(values, { setSubmitting, setErrors }) => {
                    setSubmitting(true)
                    // Assumes that on success component unmounts so no need to call setSubmitting
                    this.onSubmit(values)
                    // .catch(() => {
                    //     setSubmitting(false)
                    // })
                }}
                render={formikProps => (
                    <form onSubmit={formikProps.handleSubmit}>
                        <Dialog
                            classes={{ paper: classes.dialog }}
                            open={this.props.open}
                            onClose={this.props.closeDialog}
                            scroll="body"
                        >
                            <DialogTitle className={classes.titleStyle} variant="h2">
                                You are about to demand this Bank Guarantee.
                            </DialogTitle>
                            <DialogContent className={classes.dialogContent}>
                                <DemandFieldSet maxValue={maxValue} minValue={minValue} formik={formikProps} />
                            </DialogContent>
                            <DialogActions disableActionSpacing className={classes.dialogActions}>
                                <Flex>
                                    <Flex flex="1">
                                        <Button className={classes.button} onClick={this.props.closeDialog}>
                                            {"EXIT"}
                                        </Button>
                                    </Flex>
                                    <Flex>
                                        <Button
                                            onClick={formikProps.handleSubmit}
                                            type="submit"
                                            className={classes.button}
                                            autoFocus
                                        >
                                            {"Proceed with demand"}
                                        </Button>
                                    </Flex>
                                </Flex>
                            </DialogActions>
                        </Dialog>
                    </form>
                )}
            />
        )
    }
}

export default withError(withTheme()(DemandDialog))
