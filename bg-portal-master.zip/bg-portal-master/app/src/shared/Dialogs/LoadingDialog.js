// @flow
import React from "react"
import Dialog from "@material-ui/core/Dialog"
import DialogContent from "@material-ui/core/DialogContent"
import Typography from "@material-ui/core/Typography"
import { css } from "emotion"
import debounce from "lodash/debounce"
import { withTheme } from "@material-ui/core/styles"
import Loading from "~/shared/Loading"

type Props = {
    theme: Object,
    open: boolean
}
type State = {
    open: boolean
}

const getClasses = ({ theme }) => {
    const doneIcon = css({ color: theme.palette.common.defaultGreen })
    const titleStyle = css({ h2: { color: `${theme.palette.common.darkBlue}!important` } })
    const dialogStyle = css({ width: "550px", height: "147px" })
    return {
        doneIcon,
        titleStyle,
        dialogStyle
    }
}
class LoadingDialog extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            open: false
        }
        this.delayedClose = debounce(this.delayedClose, 250)
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.open === false && nextProps.open !== this.props.open) {
            this.delayedClose()
        }
        if (nextProps.open === true && nextProps.open !== this.props.open) {
            this.delayedClose.cancel()
            this.setState({ open: true })
        }
    }
    delayedClose = () => {
        this.setState({
            open: false
        })
    }

    render() {
        const { theme } = this.props
        const { open } = this.state
        const classes = getClasses({ theme })
        return (
            <Dialog open={open} maxWidth="md" classes={{ paper: classes.dialogStyle }}>
                <DialogContent style={{ textAlign: "center" }}>
                    <Loading show size={70} /> <Typography> Loading...</Typography>
                </DialogContent>
            </Dialog>
        )
    }
}
export default withTheme()(LoadingDialog)
