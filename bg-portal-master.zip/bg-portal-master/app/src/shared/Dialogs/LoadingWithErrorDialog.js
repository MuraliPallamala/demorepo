// @flow
import React from "react"
import Dialog from "@material-ui/core/Dialog"
import DialogContent from "@material-ui/core/DialogContent"
import DoneIcon from "@material-ui/icons/Done"
import ErrorIcon from "@material-ui/icons/ErrorOutline"
import Typography from "@material-ui/core/Typography"
import { css } from "emotion"
import debounce from "lodash/debounce"
import { withTheme } from "@material-ui/core/styles"
import Loading from "~/shared/Loading"
import ErrorDetails from "~/shared/Context/ErrorDialog/Components/ErrorDetails"

type Props = {
    theme: Object,
    title: string,
    loading: boolean,
    open: boolean,
    errorMessage: string,
    extraDetails: Object,
    errorTitle: string,
    isError: boolean,
    error: Object
}
type State = {
    open: boolean
}

const getClasses = ({ theme, isError }) => {
    const doneIcon = css({ color: theme.palette.common.defaultGreen })
    const titleStyle = css({ h2: { color: `${theme.palette.common.darkBlue}!important` } })
    let dialogStyle = css({ width: "550px", height: "147px" })

    if (isError) {
        dialogStyle = css({})
    }

    const errorIcon = css({ color: theme.palette.common.defaultYellow })
    return {
        doneIcon,
        titleStyle,
        dialogStyle,
        errorIcon
    }
}
class LoadingDialog extends React.Component<Props, State> {
    constructor(props) {
        super(props)
        this.state = {
            open: false
        }
        this.delayedClose = debounce(this.delayedClose, 3000)
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.open === false && nextProps.open !== this.props.open) {
            this.delayedClose()
        }
        if (nextProps.isError && nextProps.isError !== this.props.isError) {
            this.delayedClose.cancel()
        }
        if (nextProps.open === true && nextProps.open !== this.props.open) {
            this.delayedClose.cancel()
            this.setState({ open: true })
        }
    }
    delayedClose = () => {
        this.setState({
            open: false
        })
    }
    isLoading = () => {
        const { loading, isError, theme } = this.props
        const classes = getClasses({ theme, isError })
        if (loading) {
            return (
                <React.Fragment>
                    <Loading show size={70} /> <Typography> Loading...</Typography>
                </React.Fragment>
            )
        }
        if (!loading && !isError) {
            return (
                <React.Fragment>
                    <DoneIcon style={{ fontSize: "70px" }} className={classes.doneIcon} />{" "}
                    <Typography> Completed</Typography>
                </React.Fragment>
            )
        }
        return (
            <React.Fragment>
                <Loading show size={70} /> <Typography> Loading...</Typography>
            </React.Fragment>
        )
    }
    handleClose = () => {
        this.setState({ open: false })
    }
    isError = (isError: boolean) => {
        const { errorTitle, errorMessage, extraDetails, error, theme } = this.props
        const classes = getClasses({ theme, isError })
        let errorDisplayMessage = errorMessage
        if (isError && this.props.extraDetails) {
            if (error) {
                if (error.response) {
                    errorDisplayMessage = `${errorMessage}: ${error.response.data.message}`
                } else if (error.request) {
                    errorDisplayMessage = `${errorMessage}: Server Request Failed`
                } else if (error.message) {
                    errorDisplayMessage = `${errorMessage}: ${error.message}`
                }
            }
            return (
                <ErrorDetails
                    handleClose={this.handleClose}
                    title={errorTitle}
                    errorMessage={errorDisplayMessage}
                    extraDetails={JSON.stringify(extraDetails)}
                />
            )
        }
        if (isError) {
            return (
                <React.Fragment>
                    <ErrorIcon style={{ fontSize: "70px" }} className={classes.errorIcon} />{" "}
                    <Typography> {errorMessage}</Typography>
                </React.Fragment>
            )
        }
        return <DialogContent style={{ textAlign: "center" }}>{this.isLoading()}</DialogContent>
    }
    render() {
        const { theme, isError } = this.props
        const { open } = this.state
        const classes = getClasses({ theme, isError })
        return (
            <Dialog open={open} maxWidth="md" classes={{ paper: classes.dialogStyle }}>
                {this.isError(isError)}
            </Dialog>
        )
    }
}
export default withTheme()(LoadingDialog)
