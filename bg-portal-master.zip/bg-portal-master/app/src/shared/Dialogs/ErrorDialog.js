// @flow

import * as React from "react"
import { css } from "emotion"
import Button from "@material-ui/core/Button"
import Dialog from "@material-ui/core/Dialog"
import DialogActions from "@material-ui/core/DialogActions"
import DialogContent from "@material-ui/core/DialogContent"
import DialogContentText from "@material-ui/core/DialogContentText"
import DialogTitle from "@material-ui/core/DialogTitle"
import WarningIcon from "@material-ui/icons/Warning"
import { withTheme } from "@material-ui/core/styles"

type Props = {
    open: boolean,
    handleClose: Function,
    title: string,
    message: string,
    theme: Object
}

const getClasses = theme => {
    const icon = css({
        verticalAlign: "middle",
        marginRight: theme.spacing.unit,
        fill: theme.palette.common.darkBlue
    })
    const button = css(theme.typography.button)
    const titleStyle = css({ h2: { color: `${theme.palette.common.darkBlue}!important` } })

    return {
        icon,
        button,
        titleStyle
    }
}

const ErrorDialog = ({ theme, open, handleClose, title, message }: Props) => {
    const classes = getClasses(theme)
    return (
        <Dialog open={open} maxWidth="md" onClose={handleClose}>
            <DialogTitle classes={{ root: classes.titleStyle }}>
                <WarningIcon className={classes.icon} titleAccess="Error Icon" />
                {title}
            </DialogTitle>
            <DialogContent>
                <DialogContentText>{message}</DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button onClick={handleClose} className={classes.button} autoFocus>
                    Ok
                </Button>
            </DialogActions>
        </Dialog>
    )
}

ErrorDialog.defaultProps = {
    title: "Server Error",
    message: "Unknown server error, please try again later."
}

export default withTheme()(ErrorDialog)
