// @flow

import * as React from "react"
import { css } from "emotion"
import Dialog from "@material-ui/core/Dialog"
import DialogActions from "@material-ui/core/DialogActions"
import DialogContent from "@material-ui/core/DialogContent"
import DialogTitle from "@material-ui/core/DialogTitle"
import Button from "@material-ui/core/Button"
import { withTheme } from "@material-ui/core/styles"

type Props = {
    renderTitle: Function,
    renderContent: Function,
    submitText: string,
    cancelText: string,
    onSubmit: Function,
    handleClose: Function,
    open: boolean,
    submitting: boolean,
    theme: Object,
    buttonType: string,
    hasCancelButton?: boolean
}

const getClasses = theme => {
    const button = css(theme.typography.button)
    const body1 = css(theme.typography.body1)
    const titleStyle = css({ h2: { color: `${theme.palette.common.darkBlue}!important` } })
    const redButton = css(button, {
        color: theme.palette.common.defaultRed
    })
    return {
        button,
        titleStyle,
        redButton,
        body1
    }
}

const CustomRequestDialog = ({
    renderTitle,
    renderContent,
    submitText,
    onSubmit,
    handleClose,
    open,
    cancelText,
    submitting,
    theme,
    buttonType,
    hasCancelButton
}: Props) => {
    const classes = getClasses(theme)
    return (
        <Dialog open={open} maxWidth="md" onClose={handleClose}>
            <DialogTitle className={classes.titleStyle} variant="h2">
                {renderTitle()}
            </DialogTitle>
            <DialogContent classes={{ root: classes.body1 }}>
                {renderContent({
                    handleClose
                })}
            </DialogContent>
            <DialogActions>
                <React.Fragment>
                    {hasCancelButton ? (
                        <Button onClick={handleClose} className={classes.button} disabled={submitting}>
                            {cancelText}
                        </Button>
                    ) : null}
                    <Button
                        onClick={onSubmit}
                        className={buttonType === "red" ? classes.redButton : classes.button}
                        autoFocus
                        disabled={submitting}
                    >
                        {submitText}
                    </Button>
                </React.Fragment>
            </DialogActions>
        </Dialog>
    )
}

CustomRequestDialog.defaultProps = {
    submitText: "Submit",
    cancelText: "Cancel",
    submitting: false,
    buttonType: "",
    hasCancelButton: true
}

export default withTheme()(CustomRequestDialog)
