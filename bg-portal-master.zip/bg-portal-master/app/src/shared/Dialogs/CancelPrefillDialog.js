// @flow
import React from "react"
import { withTheme } from "@material-ui/core/styles"
import Dialog from "@material-ui/core/Dialog"
import DialogActions from "@material-ui/core/DialogActions"
import DialogContent from "@material-ui/core/DialogContent"
import DialogTitle from "@material-ui/core/DialogTitle"
import TextField from "@material-ui/core/TextField"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import { Formik } from "formik"
import Divider from "@material-ui/core/Divider"
import { css } from "emotion"
import { Flex } from "~/shared/layout"
import { cancelDefaultValues } from "~/util/guarantee"
import withError from "~/shared/Context/ErrorDialog/withError"

type Props = {
    theme: Object,
    open: boolean,
    onSubmit: Function,
    closeDialog: Function,
    text: "",
    submitButtonText: "",
    initialValues: Object
}

const getClasses = ({ theme }) => {
    const button = css(theme.typography.button)
    const titleStyle = css({ h2: { color: `${theme.palette.common.darkBlue}!important` } })
    // const dialog = css({ height: "300px" })
    const optionalComments = css({
        width: "50%",
        marginTop: "auto"
    })
    const dialogActions = css({
        //  justifyContent: "flex-start"
    })
    return {
        button,
        titleStyle,
        // dialog,
        optionalComments,
        dialogActions
    }
}

class CancelPrefillDialog extends React.Component<Props> {
    static defaultProps = {
        onSubmit: values => console.log("values", values)
    }

    onSubmit = (values: Object) => {
        this.props.onSubmit(values)
    }

    render() {
        const { theme, initialValues } = this.props
        const classes = getClasses({ theme })
        return (
            <Formik
                enableReinitialize
                initialValues={{
                    ...cancelDefaultValues,
                    ...initialValues
                }}
                onSubmit={(values, { setSubmitting, setErrors }) => {
                    setSubmitting(true)
                    this.onSubmit(values)
                }}
                render={formikProps => (
                    <form onSubmit={formikProps.handleSubmit}>
                        <Dialog
                            // classes={{ paper: classes.dialog }}
                            open={this.props.open}
                            maxWidth="md"
                            onClose={this.props.closeDialog}
                            scroll="body"
                        >
                            <DialogTitle classes={{ root: classes.titleStyle }}>
                                <React.Fragment>
                                    <Typography>{this.props.text}</Typography>
                                    <Divider />
                                </React.Fragment>
                            </DialogTitle>

                            <DialogContent style={{ display: "flex" }}>
                                <TextField
                                    label="Cancelling Reason"
                                    name="reason"
                                    value={formikProps.values.reason}
                                    onChange={formikProps.handleChange}
                                    className={classes.optionalComments}
                                />
                            </DialogContent>

                            <DialogActions disableActionSpacing className={classes.dialogActions}>
                                <Flex>
                                    <Flex flex="1">
                                        <Button className={classes.button} onClick={this.props.closeDialog}>
                                            {"Exit"}
                                        </Button>
                                    </Flex>
                                    <Flex>
                                        <Button
                                            onClick={formikProps.handleSubmit}
                                            type="submit"
                                            className={classes.button}
                                            autoFocus
                                        >
                                            {this.props.submitButtonText}
                                        </Button>
                                    </Flex>
                                </Flex>
                            </DialogActions>
                        </Dialog>
                    </form>
                )}
            />
        )
    }
}

export default withError(withTheme()(CancelPrefillDialog))
