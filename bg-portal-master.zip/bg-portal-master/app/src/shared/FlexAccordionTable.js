// @flow

import * as React from "react"

import styled from "react-emotion"

import Menu from "@material-ui/core/Menu"
import MenuItem from "@material-ui/core/MenuItem"
import Checkbox from "@material-ui/core/Checkbox"
import Tooltip from "@material-ui/core/Tooltip"
import IconButton from "@material-ui/core/IconButton"
import ListItemText from "@material-ui/core/ListItemText"
import DownArrow from "@material-ui/icons/ArrowDownward"
import UpArrow from "@material-ui/icons/ArrowUpward"
import ColIcon from "@material-ui/icons/FilterList"
import Loading from "~/shared/Loading"
import { Flex } from "~/shared/layout"

type Sort = {
    order?: string,
    dataName: string
}
type ColumnHeader = {
    displayName: string,
    dataName: string
    // ,
    // cellValue?: () => string | React$Element<any>
}

type Props = {
    // array of homogeneous data to be populated in the table
    data: Array<Object>,
    // Specify the details of each column of the table, including how to render each cell
    columns: Array<Column>,
    // accordion return the react component to be rendered for a row
    accordion?: (rowData: Object) => React$Element<any>,
    // what should happen when a row is clicked
    onRowSelection?: (rowData: Object, toggleAccordion: Function) => any,
    className?: string,
    header?: string,
    // shows a loading spinner when true
    loading?: boolean,
    // callback for remote sorting
    onSortingChange?: (sort: Sort) => any,
    defaultSort?: Sort,
    defaultHiddenColumns?: Array<string>,
    headerCustomContent?: React$Element<any>,
    defaultMinWidth?: number
}

type Column = {
    // columnHeader is the title of the column
    columnHeader: ColumnHeader,
    // cellValue is a function that is used to render the data for the specified column,
    // the function is passed the row data, a function to call to toggle the accordion and
    // a boolean telling you whether the accordion for this row is currently open or not
    cellValue?: (rowData: Object, toggleAccordion: Function, isOpen: boolean) => string | React$Element<any>,
    // sizing the columns of the table is done with colWidthProportion proportion, under the hood it just applies
    // the flex property with the specified value, if not supplied the default is 1
    colWidthProportion?: number,
    minWidth?: number,
    // sort specifies whether the column is sortable or not. If a boolean is supplied then basic alphanumeric sorting
    // is done on the column, alternatively a sort function can be supplied
    sort?: boolean | ((a: Object, b: Object) => number),
    hideTooltip?: boolean
}

type State = {
    // openIndexes keeps track of which row accordions are open and closed
    openIndexes: Array<boolean>,
    sortedColumn: ?Sort,
    visibleColumns: Array<Column>,
    columnFilterEl: any
}

class FlexTable extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        // initialise array with all false values because
        // no items are open initially
        const bools = this.props.data.reduce(sum => [...sum, false], [])
        this.state = {
            openIndexes: bools,
            sortedColumn: props.defaultSort,
            visibleColumns: getInitialVisibleColumns(props.defaultHiddenColumns, props.columns),
            columnFilterEl: null
        }
    }

    toggleAccordion = (index: number) => {
        const self = this
        return () => {
            // update the openIndexes bools
            const bools = [...this.state.openIndexes]
            bools[index] = !bools[index]
            self.setState({
                openIndexes: bools
            })
        }
    }

    sortData = (data: Array<Object>, columns: Array<Column>, sortedColumn: ?Object) => {
        let sortedData = [...data]
        if (sortedColumn) {
            // To find the currently selected column the columns list needs to be searched through
            const column = columns.find(
                element => sortedColumn && element.columnHeader.dataName === sortedColumn.dataName
            )
            // If/else chain is used to call the correct sort funciton
            if (column && column.sort) {
                if (typeof column.sort === "boolean") {
                    // Relies on the users sort function to sort the correct way by providing the sortedColumn order
                    sortedData = data.sort(compareValues(column.columnHeader.dataName, sortedColumn.order))
                } else if (sortedColumn.sortOrder === "asc") {
                    sortedData = data.sort(column.sort)
                } else if (sortedColumn.sortOrder === "desc") {
                    sortedData = data.sort(column.sort).reverse()
                }
            }
        }

        return sortedData
    }

    renderRow = (columns: Array<Column>) => {
        const { onRowSelection, accordion } = this.props
        return (rowItem: Object, index: number) => (
            <div key={index}>
                <TableRowDiv
                    className="table-row"
                    // only add tabindex if user has supplied a function
                    tabIndex={onRowSelection ? "0" : null}
                    // only add onClick listener if user has supplied a function
                    onClick={onRowSelection ? () => onRowSelection(rowItem, this.toggleAccordion(index)) : null}
                >
                    {columns.map(this.renderRowColumn(rowItem, calcTotalProportions(columns), index))}
                </TableRowDiv>
                {this.state.openIndexes[index] && accordion ? accordion(rowItem) : null}
            </div>
        )
    }

    renderRowColumn = (rowItem: Object, totalWidthProportions: number, index: number) => (
        columnItem: Column,
        columnIndex: number
    ) => {
        let tmp
        const { cellValue } = columnItem
        if (cellValue) {
            tmp = cellValue(rowItem, this.toggleAccordion(index), this.state.openIndexes[index])
        } else {
            const cellData = rowItem[columnItem.columnHeader.dataName]
            if (cellData === undefined) {
                console.warn(
                    `dataName "${
                        columnItem.columnHeader.dataName
                    }" does not match any of the data fields. Make sure the key/value pair matches the dataname`
                )
            }
            tmp = cellData
        }
        return columnItem.hideTooltip ? (
            <TableRowItemDiv
                key={columnIndex}
                className="table-row-item"
                totalWidthProportions={totalWidthProportions}
                colWidthProportion={columnItem.colWidthProportion}
                minWidth={columnItem.minWidth || this.props.defaultMinWidth || null}
            >
                {tmp}
            </TableRowItemDiv>
        ) : (
            <Tooltip title={tmp}>
                <TableRowItemDiv
                    key={columnIndex}
                    className="table-row-item"
                    totalWidthProportions={totalWidthProportions}
                    colWidthProportion={columnItem.colWidthProportion}
                    minWidth={columnItem.minWidth || this.props.defaultMinWidth || null}
                >
                    {tmp}
                </TableRowItemDiv>
            </Tooltip>
        )
    }

    // click listener for header cells with the column is sortable
    onHeaderCellClick = (dataName: string) => () => {
        // if the currently sorted column is the column that was clicked, reverse the sort order
        const { sortedColumn } = this.state
        let sortObj
        if (sortedColumn && sortedColumn.dataName === dataName) {
            sortObj = {
                dataName,
                order: this.state.sortedColumn && this.state.sortedColumn.order === "asc" ? "desc" : "asc"
            }
        } else {
            sortObj = { dataName, order: "asc" }
        }

        this.setState({ sortedColumn: sortObj })
        // if onSortingChange, call it to delegate sorting to the parent
        if (this.props.onSortingChange) {
            this.props.onSortingChange(sortObj)
        }
    }
    renderHeaderColumn = (totalWidthProportions: number) => (columnItem: Object, index: number) => (
        <TableHeaderItemDiv
            key={index}
            totalWidthProportions={totalWidthProportions}
            colWidthProportion={columnItem.colWidthProportion}
            className="table-header-column"
            aria-label={this.createColumnHeaderLabel(columnItem)}
            // only add tabindex if user has supplied a sort function
            tabIndex={columnItem.sort ? "0" : null}
            // only add onClick listener if user has supplied a sort function
            onClick={columnItem.sort ? this.onHeaderCellClick(columnItem.columnHeader.dataName) : null}
            minWidth={columnItem.minWidth || this.props.defaultMinWidth || null}
        >
            {columnItem.columnHeader.displayName}
            {this.displaySortArrow(columnItem)}
        </TableHeaderItemDiv>
    )

    createColumnHeaderLabel = (columnItem: Object) => {
        if (this.state.sortedColumn && this.state.sortedColumn.dataName === columnItem.columnHeader.dataName) {
            if (this.state.sortedColumn.order === "asc") {
                return "Column sorted ascending"
            }
            return "Column sorted descending"
        }
        return null
    }

    displaySortArrow = (columnItem: Object) => {
        if (this.state.sortedColumn && this.state.sortedColumn.dataName === columnItem.columnHeader.dataName) {
            if (this.state.sortedColumn.order === "asc") {
                return <UpArrow fontSize="inherit" />
            }
            return <DownArrow fontSize="inherit" />
        } else if (columnItem.sort) {
            return <HiddenArrow id="hiddenArrow" fontSize="inherit" />
        }

        return null
    }

    buildHeaderRow = (
        header?: string,
        visibleColumns: Array<Column>,
        columns: Array<Column>,
        columnFilterEl: any,
        hiddenColumns?: Array<string>,
        headerCustomContent?: React$Element<any>
    ) => (
        <Flex alignItems="center">
            {header ? <TableTitleDiv>{header}</TableTitleDiv> : null}
            <Flex flex="1" />
            {headerCustomContent}
            {hiddenColumns ? (
                <React.Fragment>
                    <IconButton css={{ color: "#006CC5" }} onClick={this.handleColumnFilterClick}>
                        <ColIcon />
                    </IconButton>
                    <Menu
                        anchorEl={columnFilterEl}
                        open={Boolean(columnFilterEl)}
                        onClose={this.handleColumnFilterClose}
                    >
                        {columns.map(column => {
                            const isVisible = !!isColumnVisible(visibleColumns, column)
                            return (
                                <MenuItem
                                    onClick={this.onColumnFilterItemClick(
                                        column.columnHeader.dataName,
                                        this.state.visibleColumns,
                                        isVisible
                                    )}
                                    key={column.columnHeader.dataName}
                                    value={column.columnHeader.dataName}
                                >
                                    {/* $FlowFixMe */}
                                    <Checkbox checked={isVisible} />
                                    <ListItemText primary={column.columnHeader.displayName} />
                                </MenuItem>
                            )
                        })}
                    </Menu>
                </React.Fragment>
            ) : null}
        </Flex>
    )
    columnLookup = (columnName: string) => {
        const { columns } = this.props
        return columns.findIndex(column => column.columnHeader.dataName === columnName)
    }

    // will update the visibleColumns when a column is checked/unchecked
    onColumnFilterItemClick = (dataName: string, visibleColumns: Array<Column>, isVisible: boolean) => () => {
        let newVisibleColumns = [...visibleColumns]
        if (isVisible) {
            newVisibleColumns = newVisibleColumns.filter(column => column.columnHeader.dataName !== dataName)
        } else {
            const { columns } = this.props
            const columnToAdd = columns.find(column => column.columnHeader.dataName === dataName)
            if (columnToAdd) {
                newVisibleColumns.push(columnToAdd)
            }
            // Sorts visibleColumns to match order of this.props.columns. Uses columnLookup to return index of original position
            newVisibleColumns = newVisibleColumns.sort(
                (a: Column, b: Column) =>
                    this.columnLookup(a.columnHeader.dataName) - this.columnLookup(b.columnHeader.dataName)
            )
        }

        this.setState({ visibleColumns: newVisibleColumns })
    }
    handleColumnFilterClick = (e: SyntheticEvent<>) => {
        this.setState({ columnFilterEl: e.currentTarget })
    }
    handleColumnFilterClose = () => {
        this.setState({ columnFilterEl: null })
    }

    render() {
        const {
            header,
            className,
            data,
            columns,
            loading,
            onSortingChange,
            defaultHiddenColumns,
            headerCustomContent
        } = this.props
        const { sortedColumn, visibleColumns, columnFilterEl } = this.state

        const display = () => {
            if (loading) {
                return (
                    <LoadingContainer>
                        <Loading show />
                    </LoadingContainer>
                )
            } else if (data.length === 0) {
                return <NoDataContainer>No Data</NoDataContainer>
            }
            // only call sortData if onSortingChange is not present, if its present
            // sorting is handled by the parent
            if (onSortingChange) {
                return data.map(this.renderRow(visibleColumns))
            }
            return this.sortData(data, columns, sortedColumn).map(this.renderRow(visibleColumns))
        }
        return (
            <div className={className}>
                {this.buildHeaderRow(
                    header,
                    visibleColumns,
                    columns,
                    columnFilterEl,
                    defaultHiddenColumns,
                    headerCustomContent
                )}
                <TableDiv className="table-div">
                    <TableHeaderRowDiv className="table-header-row">
                        {visibleColumns.map(this.renderHeaderColumn(calcTotalProportions(visibleColumns)))}
                    </TableHeaderRowDiv>
                    {display()}
                </TableDiv>
            </div>
        )
    }
}

const isColumnVisible = (visibleColumns, column) =>
    visibleColumns.find(col => col.columnHeader.dataName === column.columnHeader.dataName)

const getInitialVisibleColumns = (defaultHiddenColumns, columns) => {
    // if defaultHiddenColumns is supplied, then hide them from column list, otherwise return all columns
    if (defaultHiddenColumns) {
        const visibleColumns = []
        columns.forEach(column => {
            if (!defaultHiddenColumns.find(colName => colName === column.columnHeader.dataName)) {
                visibleColumns.push(column)
            }
        })
        return visibleColumns
    }

    return columns
}

const createDateObj = (item: any) => {
    if (item.constructor === Date) {
        return new Date(item)
    }
    // TODO FIX SKETCHY CODE
    if (item.constructor === String) {
        const tmp = item.split("/")
        if (tmp.length > 1) {
            return new Date(tmp[2], tmp[1] - 1, tmp[0])
        }
    }
    return null
}

const compareValues = (dataName, order) => (a, b) => {
    let check = 0

    // Checks if only one of the key has a value, if so no need to compare.
    if (!a[dataName] && b[dataName]) {
        return order === "desc" ? 1 : -1
    } else if (a[dataName] && !b[dataName]) {
        return order === "desc" ? -1 : 1
    } else if (!a[dataName] && !b[dataName]) {
        return 0
    }
    // Checks if both a and b are date objects. compares date objects only if is true
    const dateA = createDateObj(a[dataName])
    const dateB = createDateObj(b[dataName])
    const bothDateObject = dateA !== null && dateB !== null
    const dataA = bothDateObject ? dateA : a[dataName]
    const dataB = bothDateObject ? dateB : b[dataName]
    // $FlowFixMe
    if (dataA > dataB) {
        check = 1
        // $FlowFixMe
    } else if (dataA < dataB) {
        check = -1
    }
    return order === "desc" ? check * -1 : check
}

// sum up all the supplied proportions or default to 1
const calcTotalProportions = (columns: Array<Column>): number =>
    columns.reduce((acc, val) => acc + (val.colWidthProportion ? val.colWidthProportion : 1), 0)

const LoadingContainer = styled.div`
    display: flex;
    justify-content: center;
    padding: 12px;
    overflow: hidden;
`
const NoDataContainer = styled.div`
    display: flex;
    justify-content: center;
    padding: 40px;
    border-bottom: 1px solid #e0e0e0;
`
const HiddenArrow = styled(UpArrow)`
    display: none;
`
const TableDiv = styled.div`
    display: flex;
    flex-flow: column nowrap;
    overflow-x: auto;
`
const TableTitleDiv = styled.div`
    display: flex;
    height: 64px;
    align-items: center;
    font-size: 24px;
`
const TableHeaderRowDiv = styled.div`
    display: flex;
    flex-flow: row nowrap;
    align-items: center;
    font-weight: bold;
    border-bottom: 1px solid #e0e0e0;
    height: 48px;
`
const TableHeaderItemDiv = styled.div`
    width: ${props => `${((props.colWidthProportion || 1) / props.totalWidthProportions) * 100}%`};
    min-width: ${props => (props.minWidth ? `${props.minWidth}px` : null)};
    cursor: ${props => (props.onClick ? "pointer" : "default")};
    padding: 0px 10px;
    display: flex;
    align-items: center;
    &:hover > #hiddenArrow {
        display: inline;
    }
    /* https://davidwalsh.name/css-ellipsis */
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
`
const TableRowDiv = styled.div`
    display: flex;
    flex-flow: row nowrap;
    cursor: ${props => (props.onClick ? "pointer" : "default")};
    height: 48px;
    border-bottom: 1px solid #e0e0e0;
    align-items: center;
    &:hover {
        background-color: ${props => (props.onClick ? "#F4FEFD" : "none")};
    }
`
const TableRowItemDiv = styled.div`
    width: ${props => `${((props.colWidthProportion || 1) / props.totalWidthProportions) * 100}%`};
    min-width: ${props => (props.minWidth ? `${props.minWidth}px` : null)};
    padding: 0px 10px;
    /* https://davidwalsh.name/css-ellipsis */
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
`

export default FlexTable
