// @flow
import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Select from "@material-ui/core/Select"
import FormControl from "@material-ui/core/FormControl"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"
import FormHelperText from "@material-ui/core/FormHelperText"

const relationships = (list: Array<any>) => {
    const subsidiaries = list.filter(
        item => item.relationship === "PARENT_OF" && (item.status === "LINKED" || item.status === "UNLINK_PENDING")
    )
    const returnList = [
        { label: "My Organisation", value: "" },
        ...subsidiaries.map(item => {
            item.label = item.relatedEntityName
            item.value = item.id
            return item
        })
    ]
    return returnList
}

const getClasses = ({ theme }) => {
    const actingOnBehalf = css({
        minWidth: "200px"
    })

    return {
        actingOnBehalf
    }
}
type Props = {
    user: Object,
    theme: Object,
    hasError: boolean,
    error: string,
    formik: Object,
    formik: Object,
    onChange: Function
}

const ParentSubDropdown = ({ user, theme, error, hasError, formik, onChange }: Props) => {
    const classes = getClasses({ theme })
    const returnValue = () => {
        if (formik.values) {
            return formik.values.actOnBehalf
        }
        if (user.actingOnBehalf && user.actingOnBehalf.value) {
            return user.actingOnBehalf.value
        }
        if (user.actingOnBehalf) {
            return user.actingOnBehalf
        }
        return ""
    }

    if (
        PORTAL_TYPE !== "admin" &&
        PORTAL_TYPE !== "issuer" &&
        user.relationships &&
        relationships(user.relationships).length >= 2
    ) {
        return (
            <div>
                {/* <Typography className={classes.textColor}>Act on Behalf of</Typography> */}
                <FormControl error={hasError}>
                    <InputLabel shrink htmlFor="actOnBehalf">
                        Act on Behalf
                    </InputLabel>
                    <Select
                        displayEmpty
                        value={returnValue()}
                        name="actOnBehalf"
                        id="actOnBehalf"
                        onChange={event => {
                            if (formik.values) {
                                formik.setFieldValue("actOnBehalf", event.target)
                            }
                            user.updateActingOrg(event.target, onChange)
                        }}
                        inputProps={{
                            name: "actOnBehalf",
                            id: "actOnBehalf"
                        }}
                        className={classes.actingOnBehalf}
                    >
                        {(user.relationships ? relationships(user.relationships) : []).map(relationship => (
                            <MenuItem key={relationship.value} value={relationship.value}>
                                {relationship.label}
                            </MenuItem>
                        ))}
                    </Select>
                    <FormHelperText>{error || ""}</FormHelperText>
                </FormControl>
            </div>
        )
    }
    return <div />
}

ParentSubDropdown.defaultProps = {
    hasError: false,
    error: "",
    formik: {},
    onChange: () => null
}

export default withTheme()(ParentSubDropdown)
