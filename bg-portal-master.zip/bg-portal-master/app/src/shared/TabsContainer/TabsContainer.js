// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import Tabs from "@material-ui/core/Tabs"
import Tab from "@material-ui/core/Tab"
import Typography from "@material-ui/core/Typography"
import { css } from "emotion"
import { Block, Flex } from "~/shared/layout"
import PageTitle from "~/shared/PageTitle"
import generateKey from "~/util/helpers/generateKey"

type Props = {
    theme: Object,
    children: any,
    labels: Array<string>,
    selectedTab: number,
    handleChange: Function,
    // handleChangeIndex: Function,
    pageTitle: string
}

const getClasses = theme => {
    const tabsIndicator = css({
        backgroundColor: "#0972B5"
    })
    const tabSelected = css({
        color: "#0972B5"
    })
    const tabRoot = css({
        opacity: "1",
        paddingTop: "16px",
        span: {
            color: "#0972B5 !important",
            fontWeight: `${theme.typography.fontWeightMedium}!important`,
            fontSize: "18px"
        },
        "&$tabSelected": {
            color: "#0972B5",
            fontWeight: theme.typography.fontWeightMedium
        },
        "&:focus": {
            color: "#0972B5"
        }
    })
    return {
        tabsIndicator,
        tabRoot,
        tabSelected
    }
}

function TabContainer({ children, dir }) {
    return (
        <Typography component="div" dir={dir} style={{ padding: 8 * 3 }}>
            {children}
        </Typography>
    )
}

const TabsContainer = (props: Props) => {
    const { theme, children, labels, pageTitle, selectedTab } = props
    const classes = getClasses(theme)
    return (
        <React.Fragment>
            <Flex>
                <Flex flex="0.5">
                    <PageTitle
                        path="Settings/" // TODO use match.path
                        theme={theme}
                        title={pageTitle}
                    />
                </Flex>
                <Flex>
                    <Tabs
                        classes={{ root: classes.tabRoot, indicator: classes.tabsIndicator }}
                        value={selectedTab}
                        centered
                        onChange={props.handleChange}
                        style={{ display: "inline-block" }}
                    >
                        {labels.map((label, index) => (
                            <Tab
                                label={label}
                                value={index}
                                key={label}
                                classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
                            />
                        ))}
                    </Tabs>
                </Flex>
            </Flex>
            <Block padding="3un">
                {React.Children.toArray(children).map(
                    (child, i) =>
                        selectedTab === i && (
                            <TabContainer dir={theme.direction} key={generateKey(i)}>
                                {/* $FlowFixMe */}
                                {child}
                            </TabContainer>
                        )
                )}
            </Block>
        </React.Fragment>
    )
}

export default withTheme()(TabsContainer)
