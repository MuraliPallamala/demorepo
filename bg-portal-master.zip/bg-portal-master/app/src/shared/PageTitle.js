// @flow

import * as React from "react"
import { Link } from "react-router-dom"
import CardHeader from "@material-ui/core/CardHeader"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"

const getClasses = ({ theme }) => {
    const title = css({
        color: `${theme.palette.common.pageTitle}`,
        fontWeight: theme.typography.fontWeightLight,
        fontSize: theme.commonFontSizes.large,
        display: "inline"
    })
    const margin = css({ marginTop: "8px" })
    const breadCrumbs = css({
        color: theme.typography.cardTitle.color
    })
    const linkStyle = css({
        textDecoration: "none"
    })
    const linkButtonStyle = css(linkStyle, breadCrumbs, {
        background: "none",
        border: "none",
        fontSize: theme.commonFontSizes.large,
        padding: "0"
    })
    return {
        title,
        breadCrumbs,
        linkStyle,
        margin,
        linkButtonStyle
    }
}

type Props = {
    theme: Object,
    title: string,
    path?: string,
    link: string,
    history: Object
}

const PageTitle = ({ theme, title, path, link, history }: Props) => {
    const classes = getClasses({ theme })
    const displayPath = () => {
        if (history && history.length && history.length > 0 && path) {
            return (
                <button onClick={history.goBack} className={classes.linkButtonStyle}>
                    {path}
                </button>
            )
        }
        if (path) {
            return (
                <Link to={link} className={classes.linkStyle}>
                    <span className={classes.breadCrumbs}>{path}</span>
                </Link>
            )
        }
        return null
    }
    return (
        <CardHeader
            title={
                <React.Fragment>
                    <div className={classes.margin}>
                        {displayPath()} <h1 className={classes.title}>{title}</h1>
                    </div>
                </React.Fragment>
            }
        />
    )
}
PageTitle.defaultProps = {
    path: "",
    link: "/settings",
    history: {}
}

export default withTheme()(PageTitle)
