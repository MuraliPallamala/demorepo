import React from "react"
import NumberFormat from "react-number-format"

function NumberFormatCustom(props) {
    const { inputRef, onChange, ...other } = props
    return (
        <NumberFormat
            getInputRef={inputRef}
            onValueChange={values => {
                onChange({
                    target: {
                        value: values.value
                    }
                })
            }}
            thousandSeparator
            decimalScale={2}
            isAllowed={values => values.value <= 999999999.99}
            isNumericString={false}
            prefix="$"
            {...other}
        />
    )
}

export default NumberFormatCustom
