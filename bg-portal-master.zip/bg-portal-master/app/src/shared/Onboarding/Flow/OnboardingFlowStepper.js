// @flow

import * as React from "react"
import { css } from "emotion"
import Stepper from "@material-ui/core/Stepper"
import Step from "@material-ui/core/Step"
import StepLabel from "@material-ui/core/StepLabel"
import Typography from "@material-ui/core/Typography"
import { Flex } from "~/shared/layout"

import { withTheme } from "@material-ui/core/styles"

const getClasses = ({ theme }) => {
    const newUserTitle = css({
        fontSize: theme.typography.title.fontSize,
        marginRight: theme.spacing.unit * 3,
        color: theme.palette.common.pageTitle
    })
    const stepper = css(theme.stepper)

    return {
        newUserTitle,
        stepper
    }
}

type Props = { labels: Array<string>, stage: number, theme: Object }

const OnboardingFlowStepper = ({ labels, stage, theme }: Props) => {
    const classes = getClasses({ theme })
    return (
        <Flex alignItems="center">
            <Typography className={classes.newUserTitle}>Before you start</Typography>
            <Stepper activeStep={stage} className={classes.stepper}>
                {labels.map((label, i) => (
                    <Step key={label}>
                        <StepLabel completed={stage > i}>{label}</StepLabel>
                    </Step>
                ))}
            </Stepper>
        </Flex>
    )
}

export default withTheme()(OnboardingFlowStepper)
