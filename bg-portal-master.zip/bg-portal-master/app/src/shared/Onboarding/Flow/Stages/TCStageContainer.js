// @flow

import React from "react"
import CircularProgress from "@material-ui/core/CircularProgress"
import RequestDialog from "~/shared/Dialogs/RequestDialog"
import TCStage from "~/shared/Onboarding/Flow/Stages/TCStage"

type Props = {
    onNext: Function,
    onExit: Function,
    tc: ?Object,
    headerComponent: ?Function,
    title: string,
    message: string
}

const TCStageContainer = ({ onExit, tc, title, message, headerComponent, ...otherProps }: Props) => {
    if (!tc) {
        return (
            <div>
                <CircularProgress variant="indeterminate" />
            </div>
        )
    }
    let tcMessage = ""
    if (tc && tc.title) {
        tcMessage = `Are you sure you want to reject the ${tc.title}?`
    }
    return (
        <React.Fragment>
            {headerComponent ? headerComponent() : null}
            <TCStage
                tcElem={tc}
                title={`Review and Accept ${tc.title}`}
                {...otherProps}
                exitDialogRender={(tcProps: any) => (
                    <RequestDialog
                        open={tcProps.open}
                        handleClose={tcProps.handleClose}
                        title={title}
                        message={tcMessage || message}
                        submitText="Confirm"
                        onSubmit={onExit}
                    />
                )}
            />
        </React.Fragment>
    )
}

TCStageContainer.defaultProps = {
    title: "Confirm Rejection",
    headerComponent: null,
    message: "Are you sure you want to reject?"
}

export default TCStageContainer
