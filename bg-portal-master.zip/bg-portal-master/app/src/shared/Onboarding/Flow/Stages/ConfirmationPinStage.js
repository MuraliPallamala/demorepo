// @flow

import React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Typography from "@material-ui/core/Typography"
import { Flex, Block } from "~/shared/layout"
import PinDisplay from "~/shared/Onboarding/Pin/PinDisplay"

function getClasses(theme) {
    const title = css({
        fontSize: "1em", // TODO remove hard coding
        color: theme.palette.common.darkBlue,
        paddingBottom: 2 * theme.spacing.unit
    })

    const message = css({
        fontSize: "0.8em"
    })

    return {
        title,
        message
    }
}

type Props = {
    theme: Object,
    pin: string
}

const ConfirmationPinStage = ({ pin, theme }: Props) => {
    const classes = getClasses(theme)
    return (
        <Card>
            <CardContent>
                <Flex paddingTop="2un">
                    <Block flex={1} paddingRight="4un">
                        <Typography variant="h6" className={classes.title}>
                            New Confirmation PIN
                        </Typography>
                        <Typography color="error" className={classes.message}>
                            It is important to remember this PIN as you will need it to log in to the DLT Platform once
                            your company is onboarded.
                        </Typography>
                        <Typography color="error" className={classes.message}>
                            Please await email confirmation.
                        </Typography>
                    </Block>
                    <Block paddingRight="5un">
                        <PinDisplay pin={pin} />
                    </Block>
                </Flex>
            </CardContent>
        </Card>
    )
}
export default withTheme()(ConfirmationPinStage)
