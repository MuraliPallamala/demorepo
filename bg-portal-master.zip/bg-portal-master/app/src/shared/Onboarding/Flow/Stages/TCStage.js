// @flow

import * as React from "react"
import { css } from "emotion"
import Card from "@material-ui/core/Card"
import CardHeader from "@material-ui/core/CardHeader"
import CardContent from "@material-ui/core/CardContent"
import CardActions from "@material-ui/core/CardActions"
import ReactMarkdown from "react-markdown"
import Button from "@material-ui/core/Button"
import Paper from "@material-ui/core/Paper"
import { Flex } from "~/shared/layout"
import { withTheme } from "@material-ui/core/styles"
import Divider from "@material-ui/core/Divider"
import print from "print-js"
import IconButton from "@material-ui/core/IconButton"
import DownloadIcon from "@material-ui/icons/GetApp"
import marked from "marked"
import TermsConditionsPDF from "../../../../HomeContainer/SettingsContainer/TermsConditions/TermsConditionsPDF"

const getClasses = theme => {
    const loadingContainer = css({
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "inherit"
    })

    const dividerStyle = css({
        width: "80%"
    })
    const title = css({
        borderBottom: "solid 1px"
    })
    const actionsContainer = css({
        justifyContent: "flex-end"
    })
    const buttonStyle = css(theme.typography.button)
    const linkStyle = css({
        textDecoration: "none"
    })
    const paperStyle = css({
        maxHeight: window.innerHeight * 0.6,
        overflow: "auto",
        boxShadow: "none"
    })
    const paperStylePDF = css({
        overflow: "auto",
        boxShadow: "none"
    })
    const iconStyle = css({
        color: theme.palette.common.lightBlue
    })

    return {
        loadingContainer,
        dividerStyle,
        title,
        paperStyle,
        actionsContainer,
        buttonStyle,
        linkStyle,
        iconStyle,
        paperStylePDF
    }
}
type Props = {
    theme: Object,
    title?: string,
    onNext: Function,
    exitDialogRender: any,
    // tcTextElem: React.Node,
    tcElem: Object,
    submitting?: boolean
}
type State = {
    exitOpen: boolean,
    termsAndConditions: Object,
    dataType: string,
    isTermsConditionsRead: boolean
}

class TCStage extends React.Component<Props, State> {
    static defaultProps = {
        title: "Review and Accept Terms and Conditions",
        tcElem: {}
    }

    state = {
        exitOpen: false,
        termsAndConditions: {},
        dataType: "",
        isTermsConditionsRead: false
    }

    componentDidMount() {
        this.getTCtype(this.props.tcElem)
    }

    componentDidUpdate(prevProps) {
        if (prevProps.tcElem !== this.props.tcElem) {
            this.getTCtype(this.props.tcElem)
        }
    }

    getTCtype = (tcElem: Object) => {
        if (tcElem.type === "pdf") {
            this.setState({
                termsAndConditions: tcElem,
                dataType: "pdf"
            })
        } else if (tcElem.type === "markdown") {
            this.setState({
                termsAndConditions: marked(tcElem.content),
                dataType: "markdown"
            })
        }
    }

    termsConditionsRead = (tcRead: boolean) => {
        this.setState({ isTermsConditionsRead: tcRead })
    }

    ScrollTop = (dataType: string) => {
        window.scrollTo(0, 0)
    }
    handleExitOpen = () => this.setState({ exitOpen: true })
    handleExitClose = () => this.setState({ exitOpen: false })

    render() {
        const { theme, title, onNext, exitDialogRender: ExitDialog, submitting } = this.props
        const { termsAndConditions, dataType, isTermsConditionsRead } = this.state
        const classes = getClasses(theme)

        return (
            <React.Fragment>
                <Card>
                    <CardHeader
                        title={
                            <Flex>
                                <Flex flex={1} className={classes.title}>
                                    {title}
                                </Flex>
                                {dataType === "markdown" && (
                                    <IconButton
                                        className={classes.iconStyle}
                                        onClick={e => {
                                            e.preventDefault()
                                            e.stopPropagation()
                                            print({
                                                printable: "mdDiv",
                                                type: "html"
                                            })
                                        }}
                                    >
                                        <DownloadIcon />
                                    </IconButton>
                                )}
                            </Flex>
                        }
                    />
                    <CardContent>
                        {dataType === "markdown" && <Divider />}

                        <Paper
                            id={dataType === "pdf" ? "pdfDiv" : "mdDiv"}
                            className={dataType === "markdown" ? classes.paperStyle : classes.paperStylePDF}
                        >
                            {dataType === "markdown" && (
                                <ReactMarkdown escapeHtml={false}>{termsAndConditions}</ReactMarkdown>
                            )}
                            {dataType === "pdf" && (
                                <TermsConditionsPDF
                                    onboarding
                                    loading={false}
                                    data={termsAndConditions}
                                    isTcRead={this.termsConditionsRead}
                                />
                            )}
                        </Paper>
                        {dataType === "markdown" && <Divider />}
                    </CardContent>
                    <CardActions className={classes.actionsContainer}>
                        <Button onClick={this.handleExitOpen} className={classes.buttonStyle}>
                            Reject & EXIT
                        </Button>
                        <Button
                            data-cy="acceptNext"
                            onClick={() => {
                                onNext()
                                this.ScrollTop(dataType)
                                this.setState({ isTermsConditionsRead: false })
                            }}
                            className={classes.buttonStyle}
                            disabled={!isTermsConditionsRead}
                        >
                            Accept & Next
                        </Button>
                    </CardActions>
                </Card>
                <ExitDialog open={this.state.exitOpen && !submitting} handleClose={this.handleExitClose} />
            </React.Fragment>
        )
    }
}

export default withTheme()(TCStage)
