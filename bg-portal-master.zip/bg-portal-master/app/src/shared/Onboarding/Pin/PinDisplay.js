import React from "react"
import { css } from "emotion"
import Typography from "@material-ui/core/Typography"
import { Block } from "~/shared/layout"

function getClasses() {
    const pin = css({
        backgroundColor: "#edf2f9",
        borderRadius: 4,
        minWidth: 130
    })

    // TODO refactor fontSizes into theme
    const pinCaption = css({
        fontSize: "0.7em"
    })

    const pinNumber = css({
        fontSize: "1.7em"
    })

    return {
        pin,
        pinCaption,
        pinNumber
    }
}

const PinDisplay = ({ pin }) => {
    const classes = getClasses()
    return (
        <Block padding="1un 1un 0" className={classes.pin}>
            <Typography className={classes.pinCaption}>Onboarding PIN</Typography>
            <Typography className={classes.pinNumber}>{pin}</Typography>
        </Block>
    )
}
export default PinDisplay
