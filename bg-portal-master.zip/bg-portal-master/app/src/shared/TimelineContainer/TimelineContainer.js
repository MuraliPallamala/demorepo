// @flow

import * as React from "react"
import VisibilitySensor from "react-visibility-sensor"
import styled from "react-emotion"
import Typography from "@material-ui/core/Typography"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import { Flex } from "~/shared/layout"
import HistoryItems from "./Converters/HistoryItems"
import GuaranteeItems from "./Converters/GuaranteeItems"

type HistoryItem = {
    key: string,
    icon: string,
    title: string, // what
    subtitle: string, // who
    date: string,
    meta: ?Object,
    id: string,
    status: string,
    requestType: string,
    createdAt: string,
    payload: Object
}

type Props = {
    data: Array<Object>,
    hideActions: boolean,
    actionFunction: Function,
    guarantee: boolean,
    whoAmI: string,
    currentGxId: string,
    purposeTemplates: Templates,
    purposeType: string
}

type State = {}

type ItemTypeProps = {
    historyItem: Object,
    odd: number,
    actionFunction: Function,
    hideActions: boolean,
    guarantee: boolean
}

class HistoryComponent extends React.Component<Props, State> {
    static defaultProps = {
        data: [],
        hideActions: false,
        actionFunction: (item: Object) => console.log("NoActionFunction", item),
        guarantee: false,
        currentGxId: "",
        whoAmI: "",
        purposeType: "",
        purposeTemplates: []
    }

    getItemsType = ({ historyItem, hideActions, actionFunction, odd, guarantee }: ItemTypeProps) => {
        if (guarantee) {
            return (
                <GuaranteeItems
                    odd={odd}
                    historyItem={historyItem}
                    hideActions={hideActions}
                    actionFunction={actionFunction}
                    whoAmI={this.props.whoAmI}
                    currentGxId={this.props.currentGxId}
                    purposeTemplates={this.props.purposeTemplates}
                    purposeType={this.props.purposeType}
                />
            )
        }
        return (
            <HistoryItems
                odd={odd}
                historyItem={historyItem}
                hideActions={hideActions}
                actionFunction={actionFunction}
            />
        )
    }

    render() {
        const { hideActions, actionFunction, guarantee } = this.props
        return (
            <HistoryContainer>
                {this.props.data.length !== 0 ? (
                    this.props.data.map((historyItem: HistoryItem, index: number) => {
                        const odd = index % 2
                        return (
                            <VisibilitySensor key={historyItem.id} partialVisibility="bottom" offset={{ bottom: -100 }}>
                                {this.getItemsType({ historyItem, hideActions, actionFunction, odd, guarantee })}
                            </VisibilitySensor>
                        )
                    })
                ) : (
                    <Flex justifyContent="center">
                        <Typography>No Data</Typography>
                    </Flex>
                )}
            </HistoryContainer>
        )
    }
}

const HistoryContainer = styled("div")`
    padding: 0;
`

export default HistoryComponent
