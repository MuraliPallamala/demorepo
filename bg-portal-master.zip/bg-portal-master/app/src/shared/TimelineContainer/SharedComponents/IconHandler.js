// @flow
import React from "react"
import TimeIcon from "@material-ui/icons/AccessTime"
import SettingsIcon from "@material-ui/icons/Settings"
import RemoveIcon from "@material-ui/icons/Clear"
import CancelledIcon from "@material-ui/icons/Block"
import ErrorIcon from "@material-ui/icons/ErrorOutline"
import UpdateIcon from "@material-ui/icons/Update"
import CompletedIcon from "@material-ui/icons/Done"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"

const TimeType = "TIME"
const SettingsType = "SETTINGS"
const RemoveType = "REMOVE"
const CancelledType = "CANCELLED"
const ErrorType = "ERROR"
const UpdateType = "UPDATE"
const CompleteType = "COMPLETED"
type Props = {
    theme: Object,
    iconType: string
}
const getClasses = ({ theme }) => {
    const icon = css({
        color: theme.typography.timelineIcon.color,
        marginTop: "8px",
        height: "26px",
        width: "26px"
    })
    return { icon }
}

const IconHandler = ({ iconType, theme }: Props) => {
    const classes = getClasses({ theme })
    if (TimeType === iconType) {
        return <TimeIcon className={classes.icon} />
    }
    if (SettingsType === iconType) {
        return <SettingsIcon className={classes.icon} />
    }
    if (RemoveType === iconType) {
        return <RemoveIcon className={classes.icon} />
    }
    if (ErrorType === iconType) {
        return <ErrorIcon className={classes.icon} />
    }
    if (UpdateType === iconType) {
        return <UpdateIcon className={classes.icon} />
    }
    if (CancelledType === iconType) {
        return <CancelledIcon className={classes.icon} />
    }
    if (CompleteType === iconType) {
        return <CompletedIcon className={classes.icon} />
    }
    return <ErrorIcon className={classes.icon} />
}

export default withTheme()(IconHandler)
