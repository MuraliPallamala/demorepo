// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import DownArrow from "@material-ui/icons/KeyboardArrowDown"
import UpArrow from "@material-ui/icons/KeyboardArrowUp"
import Button from "@material-ui/core/Button"
import TimelineItemDetails from "./TimelineItemDetails"

type Props = {
    title: string,
    rows: Array<Array<Object>>,
    theme: Object
    // detailsTitle: string
}
type State = {
    open: boolean
}

const getClasses = ({ theme }) => {
    const icon = css({
        marginTop: "8px",
        height: "26px",
        width: "26px"
    })
    const button = css({
        color: theme.typography.button.color
    })

    return { icon, button }
}

class TimelineDetailsAuto extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        this.state = {
            open: true
        }
    }
    toggleDetails = () => {
        if (this.state.open) {
            this.setState({ open: false })
        } else {
            this.setState({ open: true })
        }
    }
    render() {
        const { open } = this.state
        const { theme, title, rows } = this.props
        const classes = getClasses({ theme })
        const filteredRows = rows.filter(item => {
            const checkItems = item.filter(each => each.value !== undefined)
            if (checkItems.length >= 1) {
                return true
            }
            return false
        })
        return (
            <React.Fragment>
                <TimelineItemDetails title={title} rows={filteredRows.slice(0, 3)} />
                {filteredRows.length >= 4 && (
                    <React.Fragment>
                        <div hidden={open}>
                            <TimelineItemDetails title="" rows={filteredRows.slice(3)} />
                        </div>
                        <Button onClick={() => this.toggleDetails()} className={classes.button}>
                            Details
                            <DownArrow hidden={!open} />
                            <UpArrow hidden={open} />
                        </Button>
                    </React.Fragment>
                )}
            </React.Fragment>
        )
    }
}

export default withTheme()(TimelineDetailsAuto)
