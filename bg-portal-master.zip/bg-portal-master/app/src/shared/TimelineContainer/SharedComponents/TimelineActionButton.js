// @flow

import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import { css } from "emotion"

type Props = {
    buttonText: string,
    theme: Object,
    action: Function,
    colour: string
}

const getClasses = ({ theme, colour }) => {
    const cancelButton = css(theme.typography.button, {
        color: colour === "red" ? theme.palette.common.defaultRed : theme.palette.common.defaultBlue
    })

    return { cancelButton }
}

const TimelineActionButton = ({ buttonText, theme, action, colour }: Props) => {
    const classes = getClasses({ theme, colour })
    if (buttonText) {
        return (
            <React.Fragment>
                <Button className={classes.cancelButton} onClick={action}>
                    {buttonText}
                </Button>
            </React.Fragment>
        )
    }
    return <div />
}

TimelineActionButton.defaultProps = {
    colour: "#FF0000"
}

export default withTheme()(TimelineActionButton)
