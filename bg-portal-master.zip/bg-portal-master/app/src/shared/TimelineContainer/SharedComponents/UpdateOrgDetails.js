// @flow

import * as React from "react"
import styled from "react-emotion"
import { withTheme } from "@material-ui/core/styles"

import Typography from "@material-ui/core/Typography"

type Props = {
    historyItem: Object,
    theme: Object
}

const UpdateOrgDetails = ({ theme, historyItem }: Props) => {
    const { orgName, hide } = historyItem
    if (hide) {
        return <div />
    }
    return (
        <React.Fragment>
            <div>
                <BoldText>
                    Organisation <LightText>{orgName}</LightText>
                </BoldText>
            </div>
        </React.Fragment>
    )
}

const BoldText = styled(Typography)`
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
    display: inline-block;
`
const LightText = styled("span")`
    font-weight: 300;
    font-size: 13px;
    letter-spacing: 0.24px;
`
/* border-bottom: ${props =>
    `1px solid ${props.theme.detailPage.history.subTitle}`}; */

export default withTheme()(UpdateOrgDetails)
