// @flow

import * as React from "react"
import styled from "react-emotion"
import { withTheme } from "@material-ui/core/styles"

import Typography from "@material-ui/core/Typography"

type Props = {
    historyItem: Object,
    theme: Object
}

const UpdateStatusDetails = ({ theme, historyItem }: Props) => {
    const { status, hide } = historyItem
    const { firstName, lastName, role } = historyItem.payload
    if (hide) {
        return <div />
    }
    return (
        <React.Fragment>
            <div>
                {firstName && lastName && (
                    <BoldText>
                        User{" "}
                        <LightText>
                            {firstName} {lastName}
                        </LightText>
                    </BoldText>
                )}
                {status && status === "DELETED" && (
                    <React.Fragment>
                        <Space />
                        <BoldText>
                            Status <LightText>USER REJECTED</LightText>
                        </BoldText>
                    </React.Fragment>
                )}
                {role && (
                    <React.Fragment>
                        <Space />
                        <BoldText>
                            Roles Added <LightText>{role.length === 1 ? role[0] : `${role[0]}, ${role[1]}`}</LightText>
                        </BoldText>
                    </React.Fragment>
                )}
            </div>
        </React.Fragment>
    )
}

const Space = styled("span")`
    padding: 5px;
`
const BoldText = styled(Typography)`
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
    display: inline-block;
`
const LightText = styled("span")`
    font-weight: 300;
    font-size: 13px;
    letter-spacing: 0.24px;
`
/* border-bottom: ${props =>
    `1px solid ${props.theme.detailPage.history.subTitle}`}; */

export default withTheme()(UpdateStatusDetails)
