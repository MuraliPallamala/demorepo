// @flow

import * as React from "react"
import styled from "react-emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import DownArrow from "@material-ui/icons/KeyboardArrowDown"
import UpArrow from "@material-ui/icons/KeyboardArrowUp"

import { css } from "emotion"
import Typography from "@material-ui/core/Typography"

const getClasses = ({ theme }) => {
    const icon = css({
        marginTop: "8px",
        height: "26px",
        width: "26px"
    })
    const button = css({
        color: theme.typography.button.color
    })

    return { icon, button }
}

type Props = {
    theme: Object,
    orgDetails: Object
}

type State = {
    open: boolean
}

class AddressDetails extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props)
        this.state = {
            open: true
        }
    }
    toggleDetails = () => {
        if (this.state.open) {
            this.setState({ open: false })
        } else {
            this.setState({ open: true })
        }
    }
    render() {
        const { theme, orgDetails } = this.props
        const { open } = this.state
        const classes = getClasses({ theme })
        const {
            payload: { address, entityAddress, entityName, originalProfile }
        } = orgDetails
        // If the payload comes from an onboarding request instead of an org change request the structure is differnt. orgOnboarding has entityAddress, orgChange is address
        const getAddressObject = entityAddress || address
        const { streetAddress, addressLocality, postalCode, addressRegion, addressCountry } = getAddressObject

        let originalAddressObject = {}
        if (originalProfile) {
            originalAddressObject = originalProfile.entityAddress || originalProfile.address
        }

        return (
            <React.Fragment>
                <div hidden={open}>
                    <BoldText>
                        {originalProfile && (
                            <div>
                                {/* If it comes from an org onboarding request(from entityAddress) it is not an update */}
                                <RedText> Original </RedText>Organisation Details:
                                <br />
                                <BoldSpanText>
                                    Entity Name: <LightText>{originalProfile.entityName} </LightText>
                                </BoldSpanText>
                                <br />
                                <BoldSpanText>
                                    Address Details:
                                    <LightText>
                                        {originalAddressObject.streetAddress}, {originalAddressObject.addressLocality},{" "}
                                        {originalAddressObject.postalCode}, {originalAddressObject.addressRegion},{" "}
                                        {originalAddressObject.addressCountry}
                                    </LightText>
                                </BoldSpanText>
                            </div>
                        )}
                        {!entityAddress && <RedText> Updated </RedText>} Organisation Details:
                        <br />
                        <BoldSpanText>
                            Entity Name: <LightText>{entityName} </LightText>
                        </BoldSpanText>
                        <br />
                        <BoldSpanText>
                            Address Details:
                            <LightText>
                                {streetAddress}, {addressLocality}, {postalCode}, {addressRegion}, {addressCountry}
                            </LightText>
                        </BoldSpanText>
                    </BoldText>
                </div>
                <Button onClick={() => this.toggleDetails()} className={classes.button}>
                    Details
                    <DownArrow hidden={!open} />
                    <UpArrow hidden={open} />
                </Button>
            </React.Fragment>
        )
    }
}
const BoldText = styled(Typography)`
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
    display: inline-block;
`
const BoldSpanText = styled("span")`
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
    display: inline-block;
`
const LightText = styled("span")`
    font-weight: 300;
    font-size: 13px;
    letter-spacing: 0.24px;
`
const RedText = styled("span")`
    color: #fa2970;
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
`

/* border-bottom: ${props =>
    `1px solid ${props.theme.detailPage.history.subTitle}`}; */

export default withTheme()(AddressDetails)
