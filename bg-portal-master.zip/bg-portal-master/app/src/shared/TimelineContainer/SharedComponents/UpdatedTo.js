// @flow

import * as React from "react"
import styled from "react-emotion"
import { withTheme } from "@material-ui/core/styles"

import Typography from "@material-ui/core/Typography"

type Props = {
    updatedTo: string,
    theme: Object
}

const UpdateStatusDetails = ({ theme, updatedTo }: Props) => (
    <React.Fragment>
        <div>
            <React.Fragment>
                <BoldText>
                    Updated to <LightText>{updatedTo}</LightText>
                </BoldText>
            </React.Fragment>
        </div>
    </React.Fragment>
)

const BoldText = styled(Typography)`
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
    display: inline-block;
`
const LightText = styled("span")`
    font-weight: 300;
    font-size: 13px;
    letter-spacing: 0.24px;
`
/* border-bottom: ${props =>
    `1px solid ${props.theme.detailPage.history.subTitle}`}; */

export default withTheme()(UpdateStatusDetails)
