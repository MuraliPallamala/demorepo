// @flow

import * as React from "react"
import styled from "react-emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import DownArrow from "@material-ui/icons/KeyboardArrowDown"
import UpArrow from "@material-ui/icons/KeyboardArrowUp"

import { css } from "emotion"
import Typography from "@material-ui/core/Typography"

const getClasses = ({ theme }) => {
    const icon = css({
        marginTop: "8px",
        height: "26px",
        width: "26px"
    })
    const button = css({
        color: theme.typography.button.color
    })

    return { icon, button }
}

type Props = {
    historyItem: Object,
    theme: Object,
    relationshipDetails: Object,
    open: boolean,
    toggleDetails: Function
}

const LinkRequestDetails = ({ theme, historyItem, open, relationshipDetails, toggleDetails }: Props) => {
    const classes = getClasses({ theme })
    const {
        orgId,
        payload: { permission, relationship }
    } = relationshipDetails
    return (
        <React.Fragment>
            <div hidden={open}>
                <BoldText>
                    Registered Relationship as:
                    <br />
                    <LightText>
                        {relationship} of {orgId} with{" "}
                        {permission.includes("WRITE") ? "View and Action Permissions" : "Read only Permission"}
                    </LightText>
                </BoldText>
            </div>
            <Button onClick={() => toggleDetails()} className={classes.button}>
                Details
                <DownArrow hidden={!open} />
                <UpArrow hidden={open} />
            </Button>
        </React.Fragment>
    )
}

const BoldText = styled(Typography)`
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
    display: inline-block;
`
const LightText = styled("span")`
    font-weight: 300;
    font-size: 13px;
    letter-spacing: 0.24px;
`

/* border-bottom: ${props =>
    `1px solid ${props.theme.detailPage.history.subTitle}`}; */

export default withTheme()(LinkRequestDetails)
