// @flow

import * as React from "react"
import styled from "react-emotion"
import { withTheme } from "@material-ui/core/styles"
import { dateToString } from "~/util/helpers/text"

import Typography from "@material-ui/core/Typography"

type Props = {
    title: string,
    historyItem: Object,
    theme: Object
}

const DetailsHeader = ({ theme, title, historyItem }: Props) => {
    const { name, createdAt, initiatedBy } = historyItem
    return (
        <React.Fragment>
            <H2 theme={theme}>{title}</H2>
            <div>
                <BoldText>
                    Date <LightText>{dateToString(createdAt)}</LightText>
                </BoldText>
                {name && (
                    <React.Fragment>
                        <Space />
                        <BoldText>
                            By <LightText>{name}</LightText>
                        </BoldText>
                    </React.Fragment>
                )}
                {initiatedBy && !name && (
                    <React.Fragment>
                        <Space />
                        <BoldText>
                            Initiated By <LightText>{initiatedBy}</LightText>
                        </BoldText>
                    </React.Fragment>
                )}
            </div>
        </React.Fragment>
    )
}
const Space = styled("span")`
    padding: 5px;
`

const BoldText = styled(Typography)`
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
    display: inline-block;
`
const LightText = styled("span")`
    font-weight: 300;
    font-size: 13px;
    letter-spacing: 0.24px;
`
/* border-bottom: ${props =>
    `1px solid ${props.theme.detailPage.history.subTitle}`}; */

const H2 = styled(Typography)`
    color: ${props => props.theme.typography.cardTitle.color};
    font-size: 20px;
    font-weight: 500;
`

export default withTheme()(DetailsHeader)
