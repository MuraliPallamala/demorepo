// @flow

import * as React from "react"
import styled from "react-emotion"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import { Link } from "react-router-dom"

import Typography from "@material-ui/core/Typography"
import generateKey from "~/util/helpers/generateKey"

type Props = {
    title: string,
    rows: Array<Array<Object>>,
    theme: Object
}

const getClasses = ({ theme }) => {
    const link = css(theme.typography.link, {
        p: {
            fontSize: theme.commonFontSizes.small
        }
    })
    return {
        link
    }
}

const TimelineItemDetails = ({ theme, title, rows }: Props) => (
    <React.Fragment>
        <H2 theme={theme}>{title}</H2>
        {rows.map(mapRow)}
    </React.Fragment>
)

type StyledLinkProps = {
    theme: Object,
    keyValuePair: Object
}
const StyledLink = withTheme()(({ theme, keyValuePair }: StyledLinkProps) => {
    const classes = getClasses({ theme })
    return (
        <Link className={classes.link} to={keyValuePair.value}>
            <Typography>{keyValuePair.key}.</Typography>
        </Link>
    )
})

const mapRow = (row, index) => {
    const filteredRow = row.filter(keyValuePair => keyValuePair.value !== undefined)
    return (
        <div key={generateKey(index)}>
            {filteredRow.map((keyValuePair, i) => {
                // The subheading Key gets rendered differently
                if (keyValuePair.key === "SUBHEADING") {
                    return (
                        <BoldText key={generateKey(keyValuePair.value)} addSpace={i < filteredRow.length - 1}>
                            <RedText> Update: </RedText> {`${keyValuePair.value}`}
                        </BoldText>
                    )
                }
                if (keyValuePair.link) {
                    return (
                        <BoldText key={generateKey(keyValuePair.value)} addSpace={i < filteredRow.length - 1}>
                            <StyledLink keyValuePair={keyValuePair} />
                        </BoldText>
                    )
                }
                return (
                    <BoldText key={generateKey(keyValuePair.value)} addSpace={i < filteredRow.length - 1}>
                        {keyValuePair.key} <LightText>{`${keyValuePair.value}`}</LightText>
                    </BoldText>
                )
            })}
        </div>
    )
}

const BoldText = styled(Typography)`
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
    display: inline-block;
    padding-right: ${props => (props.addSpace ? "5px" : "0px")};
`
const LightText = styled("span")`
    font-weight: 400;
    font-size: 13px;
    letter-spacing: 0.24px;
`
const RedText = styled("span")`
    color: #c90e2f;
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 0.24px;
`

/* border-bottom: ${props =>
    `1px solid ${props.theme.detailPage.history.subTitle}`}; */

const H2 = styled(Typography)`
    color: ${props => props.theme.typography.cardTitle.color};
    font-size: 20px;
    font-weight: 500;
`

export default withTheme()(TimelineItemDetails)
