// @flow
import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import numeral from "numeral"
import { dateToString } from "~/util/helpers/text"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"
import purposeFormatMapping from "~/util/helpers/purposeFormatMapping"
import TimelineActionButton from "../SharedComponents/TimelineActionButton"
import TimelineDetailsAuto from "../SharedComponents/TimelineDetailsAuto"

import HistoryItemHandler from "../HistoryItemHandler"
import IconHandler from "../SharedComponents/IconHandler"

import * as GuaranteeItemCheck from "./GuaranteeMapping"

type Props = {
    historyItem: Object,
    theme: Object,
    odd: number,
    actionFunction: Function,
    hideActions: boolean,
    whoAmI: string,
    currentGxId: string,
    purposeTemplates: Templates,
    purposeType: string
}

const getReasonText = guaranteeItemType => {
    if (guaranteeItemType === "TRANSFER") {
        return "Reason for Transferral"
    } else if (guaranteeItemType === "CANCEL") {
        return "Reason for Cancellation"
    }
    return "Reason"
}

const mapAmendItemToDisplayRows = (guaranteeItem, whoAmI, currentGxId, purposeTemplates, purposeType) => {
    const { payload } = guaranteeItem
    let purposeDisplay = []
    const extraDisplay = []
    let subHeading = []
    let amountValue = null
    if (payload && payload.amount) {
        if (payload.amount.outstanding) {
            amountValue = payload.amount.outstanding
        } else {
            amountValue = payload.amount
        }
    }
    if (GuaranteeItemCheck.isAmend(guaranteeItem.type) && payload) {
        const { purpose, expiresAt, expiresAtOpenEnded } = payload
        // The subheading Key gets rendered differently in the TimelineItemDetails
        subHeading = [{ key: "SUBHEADING", value: "Amend Details" }]

        purposeDisplay = []
        if (expiresAt || expiresAtOpenEnded) {
            purposeDisplay.push([
                {
                    key: "Expiry",
                    value: expiresAt && !expiresAtOpenEnded ? dateToString(expiresAt) : "Open Ended"
                }
            ])
        }

        purposeFormatMapping({ purposeTemplates, purposeType, purpose }).forEach(item => {
            purposeDisplay.push([item])
        })
    }
    if (
        GuaranteeItemCheck.isTransfer(guaranteeItem.type) &&
        payload &&
        payload.gx &&
        payload.gx.id &&
        payload.gx.id !== currentGxId &&
        (whoAmI === "issuer" || whoAmI === "applicant")
    ) {
        subHeading = [{ key: "SUBHEADING", value: "Guarantee Transferred" }]
        purposeDisplay = [
            [
                {
                    key: "View original Bank Guarantee",
                    value: payload.gx.id,
                    link: true
                }
            ]
        ]
    }
    return [
        [
            { key: "Date", value: dateToString(guaranteeItem.createdAt) },
            {
                key: guaranteeItem.name ? "By" : "Initiated By",
                value: guaranteeItem.name ? guaranteeItem.name : guaranteeItem.initiatedBy
            }
        ],
        subHeading,
        [
            {
                key: "Created By User",
                value: guaranteeItem.authoredBy
                    ? `${guaranteeItem.authoredBy.firstName} ${guaranteeItem.authoredBy.lastName}`
                    : undefined
            }
        ],
        [{ key: getReasonText(guaranteeItem.type), value: guaranteeItem.reason }],
        extraDisplay,
        [
            {
                key: "Value",
                value: amountValue ? `AUD $${numeral(amountValue / 100).format("0,0.00")}` : undefined
            }
        ],
        ...purposeDisplay
    ]
}

const GuaranteeItems = ({
    historyItem,
    theme,
    odd,
    actionFunction,
    hideActions,
    whoAmI,
    currentGxId,
    purposeTemplates,
    purposeType
}: Props) => {
    const GuaranteeItem = GuaranteeItemCheck.AuditToDisplayData({ historyItem })
    const { iconType, title, buttonText, type } = GuaranteeItem
    if (
        GuaranteeItemCheck.isIssue(type) ||
        GuaranteeItemCheck.isAmend(type) ||
        GuaranteeItemCheck.isDemand(type) ||
        GuaranteeItemCheck.isTransfer(type) ||
        GuaranteeItemCheck.isPaywalk(type) ||
        GuaranteeItemCheck.isStartTransferGuarantee(type) ||
        GuaranteeItemCheck.isCancel(type) ||
        GuaranteeItemCheck.isReject(type) ||
        GuaranteeItemCheck.isRejected(type) ||
        GuaranteeItemCheck.isApprovalFlowCancel(type) ||
        GuaranteeItemCheck.isStartAmendGuarantee(type) ||
        GuaranteeItemCheck.isRejectAmendGuarantee(type)
    ) {
        return (
            <HistoryItemHandler
                odd={odd}
                hideActions={hideActions}
                detailsRender={() => (
                    <React.Fragment>
                        <TimelineDetailsAuto
                            detailsTitle=""
                            title={title}
                            rows={mapAmendItemToDisplayRows(
                                GuaranteeItem,
                                whoAmI,
                                currentGxId,
                                purposeTemplates,
                                purposeType
                            )}
                        />
                    </React.Fragment>
                )}
                iconsRender={() => <IconHandler iconType={iconType} />}
                actionsRender={() => (
                    <TimelineActionButton
                        buttonText={buttonText}
                        colour="NotRed"
                        action={() => actionFunction(GuaranteeItem)}
                    />
                )}
            />
        )
    }
    return (
        <HistoryItemHandler
            odd={odd}
            hideActions={hideActions}
            detailsRender={() => (
                <React.Fragment>
                    <TimelineDetailsAuto
                        detailsTitle=""
                        title={title}
                        rows={mapAmendItemToDisplayRows(
                            GuaranteeItem,
                            whoAmI,
                            currentGxId,
                            purposeTemplates,
                            purposeType
                        )}
                    />
                </React.Fragment>
            )}
            iconsRender={() => <IconHandler iconType={iconType} />}
            actionsRender={() => <div />}
        />
    )
}

export default withTheme()(GuaranteeItems)
