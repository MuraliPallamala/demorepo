// @flow
export const Issue = "ISSUE"
const StartIssueGuarantee = "START_ISSUE_GUARANTEE"
const StartAmendGuarantee = "START_AMEND_GUARANTEE"
const StartDemandGuarantee = "START_DEMAND_GUARANTEE"
const StartPaywalkGuarantee = "START_PAYWALK_GUARANTEE"
const StartCancelGuarantee = "START_CANCEL_GUARANTEE"
const StartTransferGuarantee = "START_TRANSFER_GUARANTEE"
const ApproveIssueGuarantee = "APPROVE_ISSUE_GUARANTEE"
const ApproveAmendGuarantee = "APPROVE_AMEND_GUARANTEE"
const ApprovePaywalkGuarantee = "APPROVE_PAYWALK_GUARANTEE"
const ApproveDemandGuarantee = "APPROVE_DEMAND_GUARANTEE"
const ApproveCancelGuarantee = "APPROVE_CANCEL_GUARANTEE"
const ApproveTransferGuarantee = "APPROVE_TRANSFER_GUARANTEE"
const RevokeApproveIssue = "REVOKE_APPROVE_ISSUE"
const RevokeApproveAmend = "REVOKE_APPROVE_AMEND"
const RevokeApproveCancel = "REVOKE_APPROVE_CANCEL"
const RevokeApproveTransfer = "REVOKE_APPROVE_TRANSFER"
const CancelIssueGuarantee = "CANCEL_ISSUE_GUARANTEE"
const CancelAmendGuarantee = "CANCEL_AMEND_GUARANTEE"
const CancelPaywalkGuarantee = "CANCEL_PALWALK_GUARANTEE"
const CancelDemandGuarantee = "CANCEL_DEMAND_GUARANTEE"
const CancelCancelGuarantee = "CANCEL_CANCEL_GUARANTEE"
const CancelTransferGuarantee = "CANCEL_TRANSFER_GUARANTEE"
const RejectIssueGuarantee = "REJECT_ISSUE_GUARANTEE"
const RejectAmendGuarantee = "REJECT_AMEND_GUARANTEE"
const RejectPaywalkGuarantee = "REJECT_PAYWALK_GUARANTEE"
const RejectDemandGuarantee = "REJECT_DEMAND_GUARANTEE"
const RejectCancelGuarantee = "REJECT_CANCEL_GUARANTEE"
const RejectTransferGuarantee = "REJECT_TRANSFER_GUARANTEE"
const DeferDemandGuarantee = "DEFER_DEMAND_GUARANTEE"
const RecallIssueGuarantee = "RECALL_ISSUE_GUARANTEE"
const RecallAmendGuarantee = "RECALL_AMEND_GUARANTEE"
const RecallDemandGuarantee = "RECALL_DEMAND_GUARANTEE"
const RecallCancelGuarantee = "RECALL_CANCEL_GUARANTEE"
const RecallTransferGuarantee = "RECALL_TRANSFER_GUARANTEE"
const ApprovalFlowCancel = "APPROVAL_FLOW_CANCEL"
const ApprovalFlowReject = "APPROVAL_FLOW_REJECT"
const ApprovalFlowApprove = "APPROVAL_FLOW_APPROVE"
const ApprovalFlowRecall = "APPROVAL_FLOW_RECALL"
const Amend = "AMEND"
const Transfer = "TRANSFER"
const Demand = "DEMAND"
const Revoke = "REVOKE"
const Reject = "REJECT"
const Cancel = "CANCEL"
const Expire = "EXPIRE"
const Withdrawn = "WITHDRAWN"
const Withdraw = "WITHDRAW"
const Active = "ACTIVE"
const Successful = "SUCCESSFUL"
const Approved = "APPROVED"
const Cancelled = "CANCELLED"
const Rejected = "REJECTED"
const Approve = "APPROVE"
const Defer = "DEFER"
const Paywalk = "PAYWALK"
const Initiated = "INITIATED"
// Client side created type
const RejectDefer = "REJECT_DEFER"
const ApproveDefer = "APPROVE_DEFER"
export const isStartIssueGuarantee = (type: String) => type === StartIssueGuarantee
export const isStartPaywalkGuarantee = (type: String) => type === StartPaywalkGuarantee
export const isStartCancelGuarantee = (type: String) => type === StartCancelGuarantee
export const isApproveIssueGuarantee = (type: String) => type === ApproveIssueGuarantee
export const isApproveAmendGuarantee = (type: String) => type === ApproveAmendGuarantee
export const isApprovePaywalkGuarantee = (type: String) => type === ApprovePaywalkGuarantee

export const isApproveDemandGuarantee = (type: String) => type === ApproveDemandGuarantee
export const isApproveCancelGuarantee = (type: String) => type === ApproveCancelGuarantee
export const isApproveTransferGuarantee = (type: String) => type === ApproveTransferGuarantee
export const isRevokeApproveIssue = (type: String) => type === RevokeApproveIssue
export const isRevokeApproveAmend = (type: String) => type === RevokeApproveAmend
export const isRevokeApproveCancel = (type: String) => type === RevokeApproveCancel
export const isRevokeApproveTransfer = (type: String) => type === RevokeApproveTransfer
export const isCancelIssueGuarantee = (type: String) => type === CancelIssueGuarantee

export const isCancelAmendGuarantee = (type: String) => type === CancelAmendGuarantee
export const isCancelPaywalkGuarantee = (type: String) => type === CancelPaywalkGuarantee
export const isCancelDemandGuarantee = (type: String) => type === CancelDemandGuarantee
export const isCancelCancelGuarantee = (type: String) => type === CancelCancelGuarantee
export const isCancelTransferGuarantee = (type: String) => type === CancelTransferGuarantee
export const isRejectIssueGuarantee = (type: String) => type === RejectIssueGuarantee

export const isRejectDemandGuarantee = (type: String) => type === RejectDemandGuarantee
export const isRejectCancelGuarantee = (type: String) => type === RejectCancelGuarantee
export const isRejectTransferGuarantee = (type: String) => type === RejectTransferGuarantee

export const isDeferDemandGuarantee = (type: String) => type === DeferDemandGuarantee
export const isRecallIssueGuarantee = (type: String) => type === RecallIssueGuarantee
export const isRecallAmendGuarantee = (type: String) => type === RecallAmendGuarantee
export const isRecallDemandGuarantee = (type: String) => type === RecallDemandGuarantee
export const isRecallCancelGuarantee = (type: String) => type === RecallCancelGuarantee
export const isRecallTransferGuarantee = (type: String) => type === RecallTransferGuarantee
export const isApprovalFlowReject = (type: String) => type === ApprovalFlowReject
export const isApprovalFlowApprove = (type: String) => type === ApprovalFlowApprove
export const isApprovalFlowRecall = (type: String) => type === ApprovalFlowRecall

export const isSubmit = (type: String) => type === "SUBMIT"
export const isDefer = (type: String) => type === Defer
export const isPaywalk = (type: String) => type === Paywalk
export const isIssue = (type: String) => type === Issue
export const isTransfer = (type: String) => type === Transfer
export const isAmend = (type: String) => type === Amend
export const isStartAmendGuarantee = (type: String) => type === StartAmendGuarantee
export const isActive = (type: String) => type === Active
export const isCancelled = (type: String) => type === Cancelled
export const isWithdrawn = (type: String) => type === Withdrawn || type === Withdraw
export const isSuccessful = (status: String) => status === Successful
export const isRejected = (type: String) => type === Rejected
export const isDemand = (type: String) => type === Demand
export const isCancel = (type: String) => type === Cancel
export const isInitiated = (type: String) => type === Initiated
export const isReject = (type: String) => type === Reject
export const isExpire = (type: String) => type === Expire
export const isApprove = (type: String) => type === Approve
export const isApproved = (type: String) => type === Approved
export const isRevoke = (type: string) => type === Revoke
export const isStartTransferGuarantee = (type: String) => type === StartTransferGuarantee
export const isRejectAmendGuarantee = (type: String) => type === RejectAmendGuarantee
export const isRejectPaywalkGuarantee = (type: String) => type === RejectPaywalkGuarantee
export const isApprovalFlowCancel = (type: String) => type === ApprovalFlowCancel
export const isStartDemandGuarantee = (type: String) => type === StartDemandGuarantee
const isRejectDefer = (type: String) => type === RejectDefer
const isApproveDefer = (type: String) => type === ApproveDefer
type Props = {
    historyItem: Object
}

export const mapActions = (action: Object) => {
    const { actionType, createdBy, createdAt } = action

    return { type: actionType, createdAt, createdBy, ...action }
}

export const AuditToDisplayData = ({ historyItem }: Props) => {
    const {
        type,
        status,
        createdAt,
        // masterFlowId,
        createdBy,
        payload
    } = historyItem
    let { title, iconType, name, orgName } = {
        title: undefined,
        iconType: undefined,
        orgName: undefined,
        name: undefined
    }
    const initiatedBy = createdBy && createdBy.entityName ? createdBy.entityName : undefined
    const buttonText = "View"

    if (isStartIssueGuarantee(type)) {
        title = "Guarantee Issuance Initiated"
        iconType = "TIME"
        name = undefined
        orgName = undefined
    } else if (isStartPaywalkGuarantee(type)) {
        title = "Guarantee Pay and Walk Initiated"
        iconType = "COMPLETED"
    } else if (isStartCancelGuarantee(type)) {
        title = "Guarantee Cancellation Initiated"
        iconType = "COMPLETED"
    } else if (isApproveIssueGuarantee(type)) {
        title = "Guarantee Approval of Issuance"
        iconType = "COMPLETED"
    } else if (isApproveAmendGuarantee(type)) {
        title = "Guarantee Amendment Approved"
        iconType = "COMPLETED"
    } else if (isApprovePaywalkGuarantee(type)) {
        title = "Guarantee Pay and Walk Approved"
        iconType = "COMPLETED"
    } else if (isApproveDemandGuarantee(type)) {
        title = "Guarantee Demand Approved"
        iconType = "COMPLETED"
    } else if (isApproveCancelGuarantee(type)) {
        title = "Guarantee Cancellation Approved"
        iconType = "COMPLETED"
    } else if (isApproveTransferGuarantee(type)) {
        title = "Guarantee Transfer Approved"
        iconType = "COMPLETED"
    } else if (isRevokeApproveIssue(type)) {
        title = "Guarantee Issuance Rovocation Approved"
        iconType = "COMPLETED"
    } else if (isRevokeApproveAmend(type)) {
        title = "Guarantee Amend Revocation Approved"
        iconType = "COMPLETED"
    } else if (isRevokeApproveCancel(type)) {
        title = "Guarantee Cancellation Revocation Approved"
        iconType = "COMPLETED"
    } else if (isRevokeApproveTransfer(type)) {
        title = "Guarantee Transfer Revocation Approved"
        iconType = "COMPLETED"
    } else if (isCancelIssueGuarantee(type)) {
        title = "Guarantee Issuance Cancelled"
        iconType = "CANCELLED"
    } else if (isCancelAmendGuarantee(type)) {
        title = "Guarantee Amendment Cancelled"
        iconType = "CANCELLED"
    } else if (isCancelPaywalkGuarantee(type)) {
        title = "Guarantee Pay and Walk Cancelled"
        iconType = "CANCELLED"
    } else if (isCancelDemandGuarantee(type)) {
        title = "Guarantee Demand Cancelled"
        iconType = "CANCELLED"
    } else if (isCancelCancelGuarantee(type)) {
        title = "Guarantee Cancellation Cancelled"
        iconType = "CANCELLED"
    } else if (isCancelTransferGuarantee(type)) {
        title = "Guarantee Transfer Cancelled"
        iconType = "CANCELLED"
    } else if (isRejectIssueGuarantee(type)) {
        title = "Guarantee Issuance Rejected"
        iconType = "CANCELLED"
    } else if (isDeferDemandGuarantee(type)) {
        title = "Guarantee Demand Deferred"
        iconType = "CANCELLED"
    } else if (isRejectCancelGuarantee(type)) {
        title = "Guarantee Cancellation Rejected"
        iconType = "CANCELLED"
    } else if (isRejectDemandGuarantee(type)) {
        title = "Guarantee Demand Withdrawn"
        iconType = "CANCELLED"
    } else if (isRecallIssueGuarantee(type)) {
        title = "Guarantee Issuance Recalled"
        iconType = "TIME"
    } else if (isRecallAmendGuarantee(type)) {
        title = "Guarantee Amend Recalled"
        iconType = "TIME"
    } else if (isRecallDemandGuarantee(type)) {
        title = "Guarantee Demand Recalled"
        iconType = "TIME"
    } else if (isRecallCancelGuarantee(type)) {
        title = "Guarantee Cancellation Recalled"
        iconType = "TIME"
    } else if (isRecallTransferGuarantee(type)) {
        title = "Guarantee Transfer Recalled"
        iconType = "TIME"
    } else if (isApprovalFlowReject(type)) {
        title = "Guarantee Internal Rejection"
        iconType = "CANCELLED"
    } else if (isApprovalFlowApprove(type)) {
        title = "Guarantee Internal Approval"
        iconType = "COMPLETED"
    } else if (isApprovalFlowRecall(type)) {
        title = "Guarantee Internal Recall"
        iconType = "TIME"
    } else if (isRejectTransferGuarantee(type)) {
        title = "Guarantee Transfer Withdrawn"
        iconType = "CANCELLED"
    } else if (isDefer(type)) {
        title = "Guarantee Demand Request Deferred"
        iconType = "CANCELLED"
    } else if (isApprove(type)) {
        title = "Guarantee Request Approved"
        iconType = "COMPLETED"
    } else if (isExpire(type)) {
        title = "Guarantee Expired"
        iconType = "CANCELLED"
    } else if (isRejected(type) || isReject(type)) {
        title = "Guarantee Request Rejected"
        iconType = "CANCELLED"
    } else if (isRejectDefer(type)) {
        title = "Guarantee Demand Deferral Rejected"
        iconType = "CANCELLED"
    } else if (isApproveDefer(type)) {
        title = "Guarantee Demand Deferral Approved"
        iconType = "COMPLETED"
    } else if (isApprovalFlowCancel(type)) {
        title = "Guarantee Request Cancelled Internally"
        iconType = "CANCELLED"
    } else if (isStartAmendGuarantee(type)) {
        title = "Guarantee Amend Request Initiated"
        iconType = "COMPLETED"
    } else if (isStartTransferGuarantee(type)) {
        iconType = "COMPLETED"
        title = "Guarantee Transfer Initiated"
    } else if (isRejectAmendGuarantee(type)) {
        iconType = "COMPLETED"
        title = "Guarantee Amend Rejection Initiated"
    } else if (isRejectPaywalkGuarantee(type)) {
        iconType = "COMPLETED"
        title = "Guarantee Paywalk Rejection Initiated"
    } else if (isWithdrawn(type) && !status) {
        iconType = "CANCELLED"
        title = "Guarantee Request Withdrawn"
    } else if (isCancel(type) && !status) {
        iconType = "CANCELLED"
        title = "Guarantee Request Cancelled"
    } else if (isCancel(type) && isRejected(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Cancellation Request Rejected"
    } else if (isCancel(type) && isActive(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Cancellation In Progress"
    } else if (isCancel(type) && (isSuccessful(status) || isApproved(status))) {
        iconType = "COMPLETED"
        title = "Guarantee Cancellation Completed"
    } else if (isCancel(type) && isCancelled(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Cancellation Cancelled"
    } else if (isCancel(type) && isWithdrawn(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Cancellation Withdrawn"
    } else if (isIssue(type) && (isSuccessful(status) || isApproved(status))) {
        iconType = "COMPLETED"
        title = "Guarantee Created"
    } else if (isInitiated(status)) {
        iconType = "TIME"
        title = "Guarantee Request Initiated"
    } else if (isIssue(type) && isActive(status)) {
        iconType = "TIME"
        title = "Guarantee Request In Progress"
    } else if (isIssue(type) && isWithdrawn(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Issuance Withdrawn"
    } else if (isIssue(type) && isCancelled(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Issuance Cancelled"
    } else if (isIssue(type) && isRejected(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Issuance Rejected"
    } else if (isAmend(type) && isActive(status)) {
        iconType = "TIME"
        title = "Guarantee Amend In Progress"
    } else if (isAmend(type) && (isSuccessful(status) || isApproved(status))) {
        iconType = "COMPLETED"
        title = "Guarantee Amend Completed"
    } else if (isAmend(type) && isCancelled(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Amend Cancelled"
    } else if (isAmend(type) && isRejected(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Amend Rejected"
    } else if (isAmend(type) && isWithdrawn(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Amend Withdrawn"
    } else if (isSubmit(type)) {
        iconType = "TIME"
        title = "Guarantee Submit In Progress"
    } else if (isPaywalk(type) && isActive(status)) {
        iconType = "TIME"
        title = "Guarantee Pay and Walk In Progress"
    } else if (isPaywalk(type) && (isSuccessful(status) || isApproved(status))) {
        iconType = "COMPLETED"
        title = "Guarantee Pay and Walk Completed"
    } else if (isPaywalk(type) && isCancelled(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Pay and Walk Cancelled"
    } else if (isPaywalk(type) && isRejected(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Pay and Walk Withdrawn"
    } else if (isPaywalk(type)) {
        title = "Guarantee Pay and Walk"
        iconType = "COMPLETED"
    } else if (isTransfer(type) && isActive(status)) {
        iconType = "TIME"
        title = "Guarantee Transfer In Progress"
    } else if (isTransfer(type) && (isSuccessful(status) || isApproved(status))) {
        iconType = "COMPLETED"
        title = "Guarantee Transfer Completed"
    } else if (isTransfer(type) && isCancelled(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Transfer Cancelled"
    } else if (isTransfer(type) && isRejected(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Transfer Withdrawn"
    } else if (isStartDemandGuarantee(type)) {
        iconType = "TIME"
        title = "Guarantee Demand Initiated"
    } else if (isDemand(type) && isActive(status)) {
        iconType = "TIME"
        title = "Guarantee Demand In Progress"
    } else if (isDemand(type) && (isSuccessful(status) || isApproved(status))) {
        iconType = "COMPLETED"
        title = "Guarantee Demand Completed"
    } else if (isDemand(type) && isCancelled(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Demand Cancelled"
    } else if (isDemand(type) && isRejected(status)) {
        iconType = "CANCELLED"
        title = "Guarantee Demand Withdrawn"
    } else if (isRevoke(type)) {
        iconType = "CANCELLED"
        title = "Guarantee Request Revoked"
    }

    return {
        ...historyItem,
        status,
        type,
        createdAt,
        title,
        iconType,
        buttonText,
        // masterFlowId,
        name,
        orgName,
        initiatedBy,
        reason: payload && (payload.reason || payload.message) ? payload.reason || payload.message : undefined
    }
}
