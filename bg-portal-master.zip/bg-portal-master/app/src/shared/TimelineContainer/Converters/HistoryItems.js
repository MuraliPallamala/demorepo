// @flow
import * as React from "react"
import { withTheme } from "@material-ui/core/styles"
import DetailsHeader from "../SharedComponents/DetailsHeader"
import AddressDetails from "../SharedComponents/AddressDetails"
import TimelineActionButton from "../SharedComponents/TimelineActionButton"
import UpdateStatusDetails from "../SharedComponents/UpdateStatusDetails"
import UpdateOrgDetails from "../SharedComponents/UpdateOrgDetails"
import UpdatedTo from "../SharedComponents/UpdatedTo"
import HistoryItemHandler from "../HistoryItemHandler"
import IconHandler from "../SharedComponents/IconHandler"

import { displayTypes, AuditToDisplayData } from "./AuditMapping"

type Props = {
    historyItem: Object,
    theme: Object,
    odd: number,
    actionFunction: Function,
    hideActions: boolean
}

const HistoryItems = ({ historyItem, theme, odd, actionFunction, hideActions }: Props) => {
    const HistoryItem = AuditToDisplayData({ historyItem })
    const { iconType, title, buttonText, colour } = HistoryItem

    if (HistoryItem.displayType === displayTypes.AddressDetails) {
        return (
            <HistoryItemHandler
                odd={odd}
                hideActions={hideActions}
                detailsRender={() => (
                    <React.Fragment>
                        <DetailsHeader title={title} historyItem={HistoryItem} />
                        <AddressDetails orgDetails={HistoryItem} />
                    </React.Fragment>
                )}
                iconsRender={() => <IconHandler iconType={iconType} />}
                actionsRender={() => (
                    <TimelineActionButton
                        buttonText={buttonText}
                        colour={colour}
                        action={() => actionFunction(HistoryItem)}
                    />
                )}
            />
        )
    }
    if (HistoryItem.displayType === displayTypes.AddressDetails) {
        return (
            <HistoryItemHandler
                odd={odd}
                hideActions={hideActions}
                detailsRender={() => (
                    <React.Fragment>
                        <DetailsHeader title={title} historyItem={HistoryItem} />
                    </React.Fragment>
                )}
                iconsRender={() => <IconHandler iconType={iconType} />}
                actionsRender={() => (
                    <TimelineActionButton
                        buttonText={buttonText}
                        colour={colour}
                        action={() => actionFunction(HistoryItem)}
                    />
                )}
            />
        )
    }

    if (HistoryItem.displayType === displayTypes.UserStatusDetails) {
        return (
            <HistoryItemHandler
                odd={odd}
                hideActions={hideActions}
                detailsRender={() => (
                    <React.Fragment>
                        <DetailsHeader title={title} historyItem={HistoryItem} />
                        <UpdateStatusDetails historyItem={HistoryItem} />
                    </React.Fragment>
                )}
                iconsRender={() => <IconHandler iconType={iconType} />}
                actionsRender={() => (
                    <TimelineActionButton
                        buttonText={buttonText}
                        colour={colour}
                        action={() => actionFunction(HistoryItem)}
                    />
                )}
            />
        )
    }
    if (HistoryItem.displayType === displayTypes.UpdatedTo) {
        return (
            <HistoryItemHandler
                odd={odd}
                hideActions={hideActions}
                detailsRender={() => (
                    <React.Fragment>
                        <DetailsHeader title={title} historyItem={HistoryItem} />
                        {
                            // eslint-disable-next-line
                        <UpdatedTo updatedTo={HistoryItem.extraText} />
                        }
                    </React.Fragment>
                )}
                iconsRender={() => <IconHandler iconType={iconType} />}
                actionsRender={() => (
                    <TimelineActionButton
                        buttonText={buttonText}
                        colour={colour}
                        action={() => actionFunction(HistoryItem)}
                    />
                )}
            />
        )
    }
    if (HistoryItem.displayType === displayTypes.UpdatedOrgDetails) {
        return (
            <HistoryItemHandler
                odd={odd}
                hideActions={hideActions}
                detailsRender={() => (
                    <React.Fragment>
                        <DetailsHeader title={title} historyItem={HistoryItem} />
                        <UpdateOrgDetails historyItem={HistoryItem} />
                    </React.Fragment>
                )}
                iconsRender={() => <IconHandler iconType={iconType} />}
                actionsRender={() => (
                    <TimelineActionButton
                        buttonText={buttonText}
                        colour={colour}
                        action={() => actionFunction(HistoryItem)}
                    />
                )}
            />
        )
    }
    if (HistoryItem.displayType === displayTypes.Default) {
        return (
            <HistoryItemHandler
                odd={odd}
                hideActions={hideActions}
                detailsRender={() => (
                    <React.Fragment>
                        <DetailsHeader title={title} historyItem={HistoryItem} />
                    </React.Fragment>
                )}
                iconsRender={() => <IconHandler iconType={iconType} />}
                actionsRender={() => (
                    <TimelineActionButton
                        buttonText={buttonText}
                        colour={colour}
                        action={() => actionFunction(HistoryItem)}
                    />
                )}
            />
        )
    }
    return (
        <HistoryItemHandler
            odd={odd}
            hideActions={hideActions}
            detailsRender={() => (
                <React.Fragment>
                    <DetailsHeader title="Unkown HistoryItem" historyItem={HistoryItem} />
                </React.Fragment>
            )}
            iconsRender={() => <IconHandler iconType="ERROR" />}
            actionsRender={() => <div />}
        />
    )
}

export default withTheme()(HistoryItems)
