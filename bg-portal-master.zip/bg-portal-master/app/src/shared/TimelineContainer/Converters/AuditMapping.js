// @flow
/* eslint-disable import/prefer-default-export */
const SubmitOrgChange = "SUBMIT_ORG_CHANGE_REQUEST"
const SubmitOrgLink = "SUBMIT_ORG_LINK_REQUEST"
const RecallOrgChange = "RECALL_ORG_CHANGE_REQUEST"
const CancelOrgLinkRequest = "CANCEL_ORG_LINK_REQUEST"
const UpdateUserStatus = "UPDATE_USER_STATUS"
const UpdateApprovalModel = "UPDATE_APPROVAL_MODEL"
const AddUserRole = "ADD_USER_ROLE"
const SubmitOrgOnboarding = "SUBMIT_ORG_ONBOARDING"
const UpdateOrgOnboarding = "UPDATE_ORG_ONBOARDING"
const RejectOrgOnboaridng = "REJECT_ORG_ONBOARDING"
const CancelOrgOnboarding = "CANCEL_ORG_ONBOARDING"
const RecallOrgOnboarding = "RECALL_ORG_ONBOARDING"
const VerifyOrg = "VERIFY_ORG"
const VerifyPrimary = "VERIFY_PRIMARY"
const VerifyAdmin = "VERIFY_ADMIN"
const RevokeVerifyOrg = "REVOKE_VERIFY_ORG"
const RevokeVerifyPrimary = "REVOKE_VERIFY_PRIMARY"
const RevokeVerifyAdmin = "REVOKE_VERIFY_ADMIN"
const ApproveOrgOnboarding = "APPROVE_ORG_ONBOARDING"
const RejectOrgOnboarding = "REJECT_ORG_ONBOARDING"
const AddBusinessAccount = "ADD_BUSINESS_ACCOUNT"
const UpdateBusinessAccount = "UPDATE_BUSINESS_ACCOUNT"
const DeleteBusinessAccount = "DELETE_BUSINESS_ACCOUNT"
const CancelOrgChangeRequest = "CANCEL_ORG_CHANGE_REQUEST"
const RecallOrgChangeRequest = "RECALL_ORG_CHANGE_REQUEST"
const VerifyOrgChannge = "VERIFY_ORG_CHANGE"
const RevokeVerifyOrgChange = "REVOKE_VERIFY_ORG_CHANGE"
const ApproveOrgChange = "APPROVE_ORG_CHANGE"
const RejectOrgChange = "REJECT_ORG_CHANGE"
const ApproveOrgLinkRequest = "APPROVE_ORG_LINK_REQUEST"
const RejectOrgLinkRequest = "REJECT_ORG_LINK_REQUEST"
const RecallOrgLinkRequest = "RECALL_ORG_LINK_REQUEST"
const SubmitUserOnboarding = "SUBMIT_USER_ONBOARDING"
const UpdateUserOnboarding = "UPDATE_USER_ONBOARDING"
const ApproveUserOnboarding = "APPROVE_USER_ONBOARDING"
const RejectUserOnboarding = "REJECT_USER_ONBOARDING"
const CancelUserOnboarding = "CANCEL_USER_ONBOARDING"
const RecallUserOnboarding = "RECALL_USER_ONBOARDING"
const UpdateUserPassword = "UPDATE_USER_PASSWORD"
const UpdateUserDetails = "UPDATE_USER_DETAILS"
const DeleteUserRole = "DELETE_USER_ROLE"
const DeleteUser = "DELETE_USER"
const SetUserAuthCode = "SET_USER_AUTH_CODE"
const StartIssueGuarantee = "START_ISSUE_GUARANTEE"
const StartAmendGuarantee = "START_AMEND_GUARANTEE"
const StartDemandGuarantee = "START_DEMAND_GUARANTEE"
const StartPaywalkGuarantee = "START_PAYWALK_GUARANTEE"
const StartCancelGuarantee = "START_CANCEL_GUARANTEE"
const StartTransferGuarantee = "START_TRANSFER_GUARANTEE"
const ApproveIssueGuarantee = "APPROVE_ISSUE_GUARANTEE"
const ApproveAmendGuarantee = "APPROVE_AMEND_GUARANTEE"
const ApproveDemandGuarantee = "APPROVE_DEMAND_GUARANTEE"
const ApproveCancelGuarantee = "APPROVE_CANCEL_GUARANTEE"
const ApproveTransferGuarantee = "APPROVE_TRANSFER_GUARANTEE"
const RevokeApproveIssue = "REVOKE_APPROVE_ISSUE"
const RevokeApproveAmend = "REVOKE_APPROVE_AMEND"
const RevokeApproveCancel = "REVOKE_APPROVE_CANCEL"
const RevokeApproveTransfer = "REVOKE_APPROVE_TRANSFER"
const CancelIssueGuarantee = "CANCEL_ISSUE_GUARANTEE"
const CancelAmendGuarantee = "CANCEL_AMEND_GUARANTEE"
const CancelDemandGuarantee = "CANCEL_DEMAND_GUARANTEE"
const CancelCancelGuarantee = "CANCEL_CANCEL_GUARANTEE"
const CancelTransferGuarantee = "CANCEL_TRANSFER_GUARANTEE"
const RejectIssueGuarantee = "REJECT_ISSUE_GUARANTEE"
const RejectAmendGuarantee = "REJECT_AMEND_GUARANTEE"
const RejectDemandGuarantee = "REJECT_DEMAND_GUARANTEE"
const RejectCancelGuarantee = "REJECT_CANCEL_GUARANTEE"
const RejectTransferGuarantee = "REJECT_TRANSFER_GUARANTEE"
const DeferDemandGuarantee = "DEFER_DEMAND_GUARANTEE"
const RecallIssueGuarantee = "RECALL_ISSUE_GUARANTEE"
const RecallAmendGuarantee = "RECALL_AMEND_GUARANTEE"
const RecallDemandGuarantee = "RECALL_DEMAND_GUARANTEE"
const RecallCancelGuarantee = "RECALL_CANCEL_GUARANTEE"
const RecallTransferGuarantee = "RECALL_TRANSFER_GUARANTEE"
const PrefillIssueGuarantee = "PREFILL_ISSUE_GUARANTEE"
const PrefillAmendGuarantee = "PREFILL_AMEND_GUARANTEE"
const PrefillCancelGuarantee = "PREFILL_CANCEL_GUARANTEE"
const Onboarding = "ON_BOARDING"
const ChangeDetails = "CHANGE_DETAILS"
// const ChangeStatus = "CHANGE_STATUS"
// const RemoveAdministrator = "REMOVE_ADMINISTRATOR"
// const UpdateAdministrator = "UPDATE_ADMINISTRATOR"
// const AddAdministrator = "ADD_ADMINISTRATOR"
const LinkOrganisation = "LINK_ORGANIZATION"
// const UnlinkOrganisation = "UNLINK_ORGANIZATION"

// const Active = "ACTIVE"

const Approved = "APPROVED"
const Drafted = "DRAFTED"
const Rejected = "REJECTED"
// const Abandoned = "ABANDONED"

const Confirmed = "CONFIRMED"

const isOnboarding = (item: Object) => item.requestType === Onboarding
// const isRemoveAdministrator = (item: Object) => item.requestType === RemoveAdministrator
const isChangeDetails = (item: Object) => item.requestType === ChangeDetails
// const isChangeStatus = (item: Object) => item.requestType === ChangeStatus
// const isUnlinkOrganisation = (item: Object) => item.requestType === UnlinkOrganisation
// const isUpdateAdministrator = (item: Object) => item.requestType === UpdateAdministrator
// const isAddAdministrator = (item: Object) => item.requestType === AddAdministrator
const isLinkOrganisation = (item: Object) => item.requestType === LinkOrganisation
const isPrefillIssueGuarantee = (item: Object) => item.type === PrefillIssueGuarantee
const isPrefillAmendGuarantee = (item: Object) => item.type === PrefillAmendGuarantee
const isPrefillCancelGuarantee = (item: Object) => item.type === PrefillCancelGuarantee
const isUpdateOrgOnboarding = (item: Object) => item.type === UpdateOrgOnboarding
const isRejectOrgOnboaridng = (item: Object) => item.type === RejectOrgOnboaridng
const isCancelOrgOnboarding = (item: Object) => item.type === CancelOrgOnboarding
const isRecallOrgOnboarding = (item: Object) => item.type === RecallOrgOnboarding
const isVerifyAdmin = (item: Object) => item.type === VerifyAdmin
const isRevokeVerifyOrg = (item: Object) => item.type === RevokeVerifyOrg
const isRevokeVerifyPrimary = (item: Object) => item.type === RevokeVerifyPrimary
const isRevokeVerifyAdmin = (item: Object) => item.type === RevokeVerifyAdmin
const isAddBusinessAccount = (item: Object) => item.type === AddBusinessAccount
const isUpdateBusinessAccount = (item: Object) => item.type === UpdateBusinessAccount
const isDeleteBusinessAccount = (item: Object) => item.type === DeleteBusinessAccount
const isRecallOrgChangeRequest = (item: Object) => item.type === RecallOrgChangeRequest
const isVerifyOrgChannge = (item: Object) => item.type === VerifyOrgChannge
const isRevokeVerifyOrgChange = (item: Object) => item.type === RevokeVerifyOrgChange
const isApproveOrgChange = (item: Object) => item.type === ApproveOrgChange
const isRejectOrgChange = (item: Object) => item.type === RejectOrgChange
const isRejectOrgLinkRequest = (item: Object) => item.type === RejectOrgLinkRequest
const isRevokeApproveTransfer = (item: Object) => item.type === RevokeApproveTransfer
const isRecallOrgLinkRequest = (item: Object) => item.type === RecallOrgLinkRequest
const isUpdateUserOnboarding = (item: Object) => item.type === UpdateUserOnboarding
const isApproveUserOnboarding = (item: Object) => item.type === ApproveUserOnboarding

const isRejectUserOnboarding = (item: Object) => item.type === RejectUserOnboarding
const isRecallUserOnboarding = (item: Object) => item.type === RecallUserOnboarding
const isUpdateUserDetails = (item: Object) => item.type === UpdateUserDetails
const isCancelIssueGuarantee = (item: Object) => item.type === CancelIssueGuarantee
const isCancelAmendGuarantee = (item: Object) => item.type === CancelAmendGuarantee
const isCancelDemandGuarantee = (item: Object) => item.type === CancelDemandGuarantee
const isCancelCancelGuarantee = (item: Object) => item.type === CancelCancelGuarantee
const isCancelTransferGuarantee = (item: Object) => item.type === CancelTransferGuarantee
const isRejectIssueGuarantee = (item: Object) => item.type === RejectIssueGuarantee
const isDeleteUserRole = (item: Object) => item.type === DeleteUserRole
const isDeleteUser = (item: Object) => item.type === DeleteUser

const isSetUserAuthCode = (item: Object) => item.type === SetUserAuthCode
const isRejectDemandGuarantee = (item: Object) => item.type === RejectDemandGuarantee
const isRejectCancelGuarantee = (item: Object) => item.type === RejectCancelGuarantee
const isRejectTransferGuarantee = (item: Object) => item.type === RejectTransferGuarantee
const isDeferDemandGuarantee = (item: Object) => item.type === DeferDemandGuarantee
const isRecallIssueGuarantee = (item: Object) => item.type === RecallIssueGuarantee
const isRecallAmendGuarantee = (item: Object) => item.type === RecallAmendGuarantee
const isRecallDemandGuarantee = (item: Object) => item.type === RecallDemandGuarantee
const isRecallCancelGuarantee = (item: Object) => item.type === RecallCancelGuarantee
const isRecallTransferGuarantee = (item: Object) => item.type === RecallTransferGuarantee

const isRejectAmendGuarantee = (item: Object) => item.type === RejectAmendGuarantee

const isStartDemandGuarantee = (item: Object) => item.type === StartDemandGuarantee
const isStartAmendGuarantee = (item: Object) => item.type === StartAmendGuarantee

const isStartPaywalkGuarantee = (item: Object) => item.type === StartPaywalkGuarantee

const isStartCancelGuarantee = (item: Object) => item.type === StartCancelGuarantee

const isStartIssueGuarantee = (item: Object) => item.type === StartIssueGuarantee

const isApproveIssueGuarantee = (item: Object) => item.type === ApproveIssueGuarantee

const isCancelUserOnboarding = (item: Object) => item.type === CancelUserOnboarding
const isSubmitOrgOnboarding = (item: Object) => item.type === SubmitOrgOnboarding

const isSubmitOrgChangeRequest = (item: Object) => item.type === SubmitOrgChange

const isSubmitLinkRequest = (item: Object) => item.type === SubmitOrgLink

const isAddUserRole = (item: Object) => item.type === AddUserRole

const isRecallOrgChange = (item: Object) => item.type === RecallOrgChange

const isOrgChangeCancellation = (item: Object) => item.type === CancelOrgChangeRequest

const isUpdateUserStatus = (item: Object) => item.type === UpdateUserStatus

const isUpdateApprovalModel = (item: Object) => item.type === UpdateApprovalModel
const isApproveOrgLinkRequest = (item: Object) => item.type === ApproveOrgLinkRequest

const isCancelOrgLinkRequest = (item: Object) => item.type === CancelOrgLinkRequest

const isSubmitUserOnboarding = (item: Object) => item.type === SubmitUserOnboarding

const isUpdateUserPassword = (item: Object) => item.type === UpdateUserPassword

const isVerifyOrg = (item: Object) => item.type === VerifyOrg

const isVerifyPrimary = (item: Object) => item.type === VerifyPrimary

const isApproveOrgOnboarding = (item: Object) => item.type === ApproveOrgOnboarding
const isRejectOrgOnboarding = (item: Object) => item.type === RejectOrgOnboarding

const isStartTransferGuarantee = (item: Object) => item.type === StartTransferGuarantee

const isApproveAmendGuarantee = (item: Object) => item.type === ApproveAmendGuarantee

const isApproveDemandGuarantee = (item: Object) => item.type === ApproveDemandGuarantee

const isApproveCancelGuarantee = (item: Object) => item.type === ApproveCancelGuarantee

const isApproveTransferGuarantee = (item: Object) => item.type === ApproveTransferGuarantee

const isRevokeApproveIssue = (item: Object) => item.type === RevokeApproveIssue

const isRevokeApproveAmend = (item: Object) => item.type === RevokeApproveAmend

const isRevokeApproveCancel = (item: Object) => item.type === RevokeApproveCancel

const isUnlinkOrganisation = (type: string) => type === "UNLINK_ORGANIZATION"

// had to create a seperate function for recall since it needs to be handled quite differently
// as discussed here https://github.ibm.com/bank-guarantees/bg-issues/issues/448
const getOrgChangeRecallPayload = (item: Object) => {
    let payload
    let count = 0
    let lastRecallAction = {}
    const actions = item.data.orgChangeRequest.actions
    // find out how many recall actions there are
    actions.forEach(action => {
        if (action.actionType === "RECALL") {
            count += 1
            lastRecallAction = action.payload
        }
    })
    // if there is more than one recall action, the original payload will be a previous action
    if (count > 1) {
        payload = lastRecallAction
        // get the second last recall action
        let foundLastRecall = false
        for (let i = actions.length - 1; i >= 0; --i) {
            if (actions[i].actionType === "RECALL") {
                // if this is the last one, set bool to true, otherwise set payload and break
                if (foundLastRecall === false) {
                    foundLastRecall = true
                } else {
                    payload.originalProfile = actions[i].payload
                    break
                }
            }
        }
    }
    // there is only one recall action
    else if (count === 1) {
        payload = lastRecallAction
        payload.originalProfile = item.data.orgChangeRequest.payload
    }
    return payload
}

const getOrgChangePayload = (item: Object) => {
    const payload = item.data.orgChangeRequest.payload
    // commented this out since its handled in getOrgChangeRecallPayload now
    // if (item.data.orgChangeRequest.actions != null) {
    //     item.data.orgChangeRequest.actions.forEach(action => {
    //         if (action.actionType === "RECALL") {
    //             payload = action.payload
    //             ;({ payload } = action)
    //         }
    //     })
    // }
    if (item.data.orgChangeRequest.originalProfile) {
        payload.originalProfile = item.data.orgChangeRequest.originalProfile
    }
    return payload
}

type Props = {
    historyItem: Object
}

export const displayTypes = {
    UserStatusDetails: "USER_STATUS_DETAILS",
    UpdatedTo: "UPDATED_TO",
    UpdatedOrgDetails: "UPDATED_ORG_DETAILS",
    AddressDetails: "ADDRESS_DETAILS",
    Default: "DEFAULT"
}

export const AuditToDisplayData = ({ historyItem }: Props) => {
    const { type, userName } = historyItem
    let { createdAt } = historyItem
    let { displayType, status, id, payload, name, title, iconType, buttonText, orgName, action, extraText, colour } = {
        status: "",
        id: "",
        payload: {},
        name: userName,
        title: "",
        iconType: "",
        buttonText: "",
        orgName: "",
        action: "",
        extraText: "",
        colour: "",
        displayType: displayTypes.Default
    }
    const theRequestType = historyItem.requestType ? historyItem.requestType : ""
    if (isUpdateUserStatus(historyItem)) {
        ;({ status } = historyItem.data)
        ;({ id } = historyItem)
        payload = historyItem.data.user
        iconType = "COMPLETED"
        title = `Updated a Users Status`
        if (historyItem.userName === `${payload.firstName} ${payload.lastName}`) {
            title = `User ${historyItem.userName} Created`
            iconType = "SETTINGS"
        }
        displayType = displayTypes.UserStatusDetails
    } else if (isUnlinkOrganisation(theRequestType)) {
        ;({ status } = historyItem)
        if (status === Approved) {
            title = "Parent & Subsidiary Unlink Request Approved"
        } else if (status === Confirmed) {
            title = "Parent & Subsidiary Unlink Request Initiated"
        } else {
            title = "Parent & Subsidiary Unlink Request Rejected"
        }
        ;({ id } = historyItem)
        name = historyItem.userName
        iconType = "CANCELLED"
    } else if (isAddBusinessAccount(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Business Account Created"
        iconType = "COMPLETED"
    } else if (isUpdateBusinessAccount(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Business Account Updated"
        iconType = "COMPLETED"
    } else if (isDeleteBusinessAccount(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Business Account Deleted"
        iconType = "CANCELLED"
    } else if (isRecallOrgChangeRequest(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.orgChangeRequest)
        payload = getOrgChangeRecallPayload(historyItem)
        displayType = displayTypes.AddressDetails
        if (status === Confirmed) {
            action = "CANCEL_REQUEST"
            colour = "red"

            buttonText = "Cancel Request"
        }
        name = historyItem.userName
        title = "Organisation Change Request Updated"
        iconType = "TIME"
    } else if (isVerifyOrgChannge(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.orgChangeRequest)
        payload = getOrgChangePayload(historyItem)
        name = historyItem.userName
        displayType = displayTypes.AddressDetails
        title = "Organisation Change Verified"
        iconType = "COMPLETED"
    } else if (isRevokeVerifyOrgChange(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.orgChangeRequest)
        payload = getOrgChangePayload(historyItem)
        name = historyItem.userName
        title = "Organisation Change Verification Revoked"
        iconType = "CANCELLED"
    } else if (isApproveOrgChange(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.orgChangeRequest)
        payload = getOrgChangePayload(historyItem)
        name = historyItem.userName
        displayType = displayTypes.AddressDetails
        title = "Organisation Change Approved"
        iconType = "COMPLETED"
    } else if (isRejectOrgChange(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.orgChangeRequest)
        payload = getOrgChangePayload(historyItem)
        name = historyItem.userName
        displayType = displayTypes.AddressDetails
        title = "Organisation Change Rejected"
        iconType = "CANCELLED"
    } else if (isRejectOrgLinkRequest(historyItem)) {
        if (historyItem.data.orgChangeRequest.requestType === "UNLINK_ORGANIZATION") {
            title = "Parent & Subsidiary Unlink Request Rejected"
        } else {
            title = "Parent & Subsidiary Link Request Rejected"
        }
        ;({ id } = historyItem)
        name = historyItem.userName
        iconType = "CANCELLED"
    } else if (isRevokeApproveTransfer(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Transfer Approval Revoked"
        iconType = "CANCELLED"
    } else if (isRecallOrgLinkRequest(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Parent & Subsidiary Link Recalled"
        iconType = "TIME"
    } else if (isUpdateUserPassword(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "User Updated Password"
        iconType = "COMPLETED"
    } else if (isRejectUserOnboarding(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "User Onboarding Rejected"
        iconType = "CANCELLED"
    } else if (isRecallUserOnboarding(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "User Onboarding Recalled"
        iconType = "TIME"
    } else if (isUpdateUserDetails(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        payload = historyItem.data.user
        title = "User Details Updated"
        iconType = "COMPLETED"
        displayType = displayTypes.UserStatusDetails
    } else if (isCancelIssueGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Issuance Cancelled"
        iconType = "CANCELLED"
    } else if (isCancelAmendGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Amendment Cancelled"
        iconType = "CANCELLED"
    } else if (isCancelDemandGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Demand Cancelled"
        iconType = "CANCELLED"
    } else if (isCancelCancelGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Cancellation Cancelled"
        iconType = "CANCELLED"
    } else if (isCancelTransferGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Transfer Cancelled"
        iconType = "CANCELLED"
    } else if (isRecallDemandGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Demand Recalled"
        iconType = "TIME"
    } else if (isRejectIssueGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Issuance Rejected"
        iconType = "CANCELLED"
    } else if (isDeleteUserRole(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "User Role Deleted"
        iconType = "CANCELLED"
    } else if (isDeleteUser(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        payload = historyItem.data.user
        title = "User Deleted"
        iconType = "CANCELLED"
        displayType = displayTypes.UserStatusDetails
    } else if (isUpdateUserOnboarding(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "User Onboarding Updated"
        iconType = "COMPLETED"
    } else if (isApproveUserOnboarding(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "User Onboarding Approved"
        iconType = "COMPLETED"
    } else if (isSetUserAuthCode(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "User Authentication Code Set"
        iconType = "COMPLETED"
    } else if (isRejectDemandGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Demand Rejected"
        iconType = "CANCELLED"
    } else if (isRejectCancelGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Rejected Guarantee Cancellation"
        iconType = "CANCELLED"
    } else if (isRejectTransferGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Transfer Withdrawn"
        iconType = "CANCELLED"
    } else if (isDeferDemandGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Demand Deferred"
        iconType = "TIME"
    } else if (isRecallIssueGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Issuance Recalled"
        iconType = "TIME"
    } else if (isRecallAmendGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Amend Recalled"
        iconType = "TIME"
    } else if (isRecallCancelGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarntee Cancellation Recalled"
        iconType = "TIME"
    } else if (isRecallTransferGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Guarantee Transfer Recalled"
        iconType = "TIME"
    } else if (isCancelUserOnboarding(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        payload = historyItem.data.user
        title = "User Onboarding Cancelled"
        iconType = "CANCELLED"
        displayType = displayTypes.UserStatusDetails
    } else if (isRecallOrgChange(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Organisation Change Recalled"
        iconType = "TIME"
    } else if (isApproveOrgLinkRequest(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        const { requestType } = historyItem.data.orgChangeRequest
        title = "Parent & Subsidiary Link Approved"
        iconType = "COMPLETED"
        if (requestType === "UNLINK_ORGANIZATION") {
            title = "Parent & Subsidiary Unlink Approved"
            iconType = "COMPLETED"
        }
    } else if (isCancelOrgLinkRequest(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        const { requestType } = historyItem.data.orgChangeRequest
        title = "Parent & Subsidiary Link Cancelled"
        iconType = "COMPLETED"
        if (requestType === "UNLINK_ORGANIZATION") {
            title = "Parent & Subsidiary Unlink Cancelled"
            iconType = "COMPLETED"
        }
    } else if (isSubmitUserOnboarding(historyItem)) {
        ;({ status } = historyItem.data.user)
        ;({ id } = historyItem)
        payload = historyItem.data.user
        name = historyItem.userName
        title = "User Onboarding Initiated"
        iconType = "TIME"
        displayType = displayTypes.UserStatusDetails
    } else if (isSubmitLinkRequest(historyItem)) {
        ;({ id, status, payload, createdAt } = historyItem.data.orgChangeRequest)
        const { requestType } = historyItem.data.orgChangeRequest
        if (status === Confirmed) {
            action = "CANCEL_REQUEST"
            colour = "red"

            buttonText = "Cancel Request"
        }
        orgName = historyItem.data.organization.profile.entityName
        displayType = displayTypes.UpdatedOrgDetails
        if (requestType === "UNLINK_ORGANIZATION") {
            title = "Parent & Subsidiary Relationship Unlink Initiated"
            iconType = "TIME"
        } else {
            title = "Parent & Subsidiary Relationship Initiated"
            iconType = "TIME"
        }
    } else if (isUpdateApprovalModel(historyItem)) {
        title = "Approval Model Updated"
        ;({ status } = historyItem.data)
        ;({ id } = historyItem)
        iconType = "COMPLETED"
        displayType = displayTypes.UpdatedTo
        if (historyItem.data.approvalModel === "FOUR_EYE") {
            extraText = "Four Eye"
        } else if (historyItem.data.approvalModel === "SOLE_APPROVER") {
            extraText = "Sole Approver"
        }
    } else if (isAddUserRole(historyItem)) {
        title = "Updated User Role"
        payload = {
            firstName: historyItem.data.user.firstName,
            lastName: historyItem.data.user.lastName,
            role: historyItem.data.role
        }
        iconType = "COMPLETED"
        ;({ id } = historyItem)
        displayType = displayTypes.UserStatusDetails
    } else if (isSubmitOrgChangeRequest(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.orgChangeRequest)
        title = "Organisation Change Request Initiated"
        payload = getOrgChangePayload(historyItem)
        iconType = "TIME"
        displayType = displayTypes.AddressDetails
        if (status === Confirmed) {
            action = "CANCEL_REQUEST"
            colour = "red"
            buttonText = "Cancel Request"
        }
    } else if (isOrgChangeCancellation(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.orgChangeRequest)
        payload = getOrgChangePayload(historyItem)
        title = "Organisation Change Request Cancelled"
        iconType = "CANCELLED"
        action = "RESUBMIT_REQUEST"
        buttonText = "Resubmit Request"
        displayType = displayTypes.AddressDetails
        // buttonText = "Resubmit Request"
    } else if (isSubmitOrgOnboarding(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.onboardingRequest)
        payload = { referer: historyItem.data.onboardingRequest, profile: historyItem.data.onboardingRequest }
        name = historyItem.userName
        if (status === Confirmed || status === Drafted) {
            title = "Organisation Onboarding Initiated"
            iconType = "TIME"
        }
        if (status === Approved) {
            title = "Organisation Onboarding Completed"
            iconType = "COMPLETED"
        } else {
            title = "Organisation Onboarding Initiated"
            iconType = "TIME"
        }
    } else if (isUpdateOrgOnboarding(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.onboardingRequest)
        payload = { referer: historyItem.data.onboardingRequest, profile: historyItem.data.onboardingRequest }
        name = historyItem.userName
        title = "Organisation Onboarding Updated"
        iconType = "COMPLETE"
    } else if (isRejectOrgOnboaridng(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.onboardingRequest)
        payload = { referer: historyItem.data.onboardingRequest, profile: historyItem.data.onboardingRequest }
        name = historyItem.userName
        title = "Organisation Onboarding Rejected"
        iconType = "CANCELLED"
    } else if (isCancelOrgOnboarding(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.onboardingRequest)
        payload = { referer: historyItem.data.onboardingRequest, profile: historyItem.data.onboardingRequest }
        name = historyItem.userName
        title = "Organisation Onboarding Cancelled"
        iconType = "CANCELLED"
    } else if (isRecallOrgOnboarding(historyItem)) {
        ;({ id, status, createdAt } = historyItem.data.onboardingRequest)
        payload = { referer: historyItem.data.onboardingRequest, profile: historyItem.data.onboardingRequest }
        name = historyItem.userName
        title = "Organisation Onboarding Recalled"
        iconType = "TIME"
    } else if (isVerifyOrg(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Verified Organisation"
        iconType = "COMPLETED"
        displayType = displayTypes.UpdatedOrgDetails
        orgName = historyItem.data.onboardingRequest.profile.entityName
    } else if (isRevokeVerifyOrg(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Revoked Verification of Organisation"
        iconType = "CANCELLED"
        displayType = displayTypes.UpdatedOrgDetails
        orgName = historyItem.data.onboardingRequest.profile.entityName
    } else if (isRevokeVerifyPrimary(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Revoked Verification of Organisation Primary Contact"
        iconType = "CANCELLED"
        displayType = displayTypes.UpdatedOrgDetails
        orgName = historyItem.data.onboardingRequest.profile.entityName
    } else if (isRevokeVerifyAdmin(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Revoked Verification of Organisation Admin Contact"
        iconType = "CANCELLED"
        displayType = displayTypes.UpdatedOrgDetails
        orgName = historyItem.data.onboardingRequest.profile.entityName
    } else if (isVerifyAdmin(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Verified Organisation Admin Contact"
        iconType = "COMPLETED"
        displayType = displayTypes.UpdatedOrgDetails
        orgName = historyItem.data.onboardingRequest.profile.entityName
    } else if (isVerifyPrimary(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Verified Organisation Primary Contact"
        iconType = "COMPLETED"
        displayType = displayTypes.UpdatedOrgDetails

        orgName = historyItem.data.onboardingRequest.profile.entityName
    } else if (isApproveOrgOnboarding(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Organisation Onboarding Approved"
        displayType = displayTypes.AddressDetails
        payload = historyItem.data.onboardingRequest.profile
        iconType = "COMPLETED"
        orgName = historyItem.data.onboardingRequest.profile.entityName
    } else if (isRejectOrgOnboarding(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Organisation Onboarding Rejected"
        displayType = displayTypes.UpdatedOrgDetails

        iconType = "CANCELLED"
        orgName = historyItem.data.onboardingRequest.profile.entityName
    } else if (isApproveIssueGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Approved Guarantee Issuance"
        iconType = "COMPLETED"
    } else if (isStartIssueGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Initiated a Guarantee"
        iconType = "COMPLETED"
    } else if (isStartCancelGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Initiated Cancel of Guarantee"
        iconType = "TIME"
    } else if (isStartPaywalkGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Initiated Pay and Walk of Guarantee"
        iconType = "TIME"
    } else if (isStartAmendGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Initiated Amendment of a Guarantee"
        iconType = "TIME"
    } else if (isStartDemandGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Initiated Demand of a Guarantee"
        iconType = "TIME"
    } else if (isRejectAmendGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Rejected Amend of Guarantee"
        iconType = "CANCELLED"
    } else if (isStartTransferGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Initiated Transfer of Guarantee"
        iconType = "TIME"
    } else if (isApproveAmendGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Approved Amendment of a Guarantee"
        iconType = "COMPLETED"
    } else if (isApproveDemandGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Approved Demand of a Guarantee"
        iconType = "COMPLETED"
    } else if (isApproveCancelGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Approved Cancellation of a Guarantee"
        iconType = "COMPLETED"
    } else if (isApproveTransferGuarantee(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Approved Transfer of a Guarantee"
        iconType = "COMPLETED"
    } else if (isRevokeApproveIssue(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Revoked Approval of a Guarantee"
        iconType = "CANCELLED"
    } else if (isRevokeApproveAmend(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Revoked Approval of a Amendment"
        iconType = "CANCELLED"
    } else if (isRevokeApproveCancel(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Revoked Approval of a Cancellation"
        iconType = "CANCELLED"
    } else if (isOnboarding(historyItem)) {
        ;({ id } = historyItem)
        name = historyItem.userName
        title = "Onboarding Initiated"
        iconType = "TIME"
        if (status === Approved) {
            title = "Onboarding Initiated"
            iconType = "TIME"
        }
        if (status === Rejected) {
            title = "Onboarding Rejected"
            iconType = "CANCELLED"
        }

        // isOnboarding
        // isRemoveAdministrator
        // isChangeDetails
        // isChangeStatus
        // isUnlinkOrganisation
        // isUpdateAdministrator
        // isAddAdministrator
        // isLinkOrganisation
    } else if (isPrefillIssueGuarantee(historyItem)) {
        title = "Prefill Guarantee Issuance Initiated"
        iconType = "TIME"
    } else if (isPrefillAmendGuarantee(historyItem)) {
        title = "Prefill Guarantee Amend Initiated"
        iconType = "TIME"
    } else if (isPrefillCancelGuarantee(historyItem)) {
        iconType = "CANCELLED"
        title = "Prefill Guarantee Cancellation Initiated"
    } else if (isChangeDetails(historyItem)) {
        ;({ id, status } = historyItem)
        const { updatedAt } = historyItem
        payload = getOrgChangePayload({
            data: {
                orgChangeRequest: historyItem
            }
        })
        if (updatedAt) {
            createdAt = updatedAt
        }
        name = "Lygon Admin"
        title = "Organisation Change Request Initiated"
        iconType = "TIME"
        displayType = displayTypes.AddressDetails

        if (status === Approved) {
            title = "Organisation Change Request Approved"
            iconType = "TIME"
        } else if (status === Rejected) {
            title = "Organisation Change Request Rejected"
            iconType = "CANCELLED"
            action = "RESUBMIT_REQUEST"
            buttonText = "Resubmit Request"
        }
    } else if (isLinkOrganisation(historyItem)) {
        ;({ id, payload, status } = historyItem)
        const { updatedAt } = historyItem

        if (updatedAt) {
            createdAt = updatedAt
        }
        name = historyItem.userName
        title = "Parent & Subsidiary Relationship Initiated"
        iconType = "TIME"
        if (status === Approved) {
            title = "Parent & Subsidiary Relationship Completed"
            iconType = "COMPLETED"
        } else if (status === Rejected) {
            title = "Parent & Subsidiary Relationship Rejected"
            iconType = "CANCELLED"
        }
    }

    return {
        status,
        id,
        payload,
        createdAt,
        type,
        name,
        title,
        iconType,
        buttonText,
        orgName,
        action,
        extraText,
        displayType,
        colour
    }
}
