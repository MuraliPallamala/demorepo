// @flow

import * as React from "react"
import styled from "react-emotion"
import { withTheme } from "@material-ui/core/styles"

type Props = {
    theme: Object,
    detailsRender: Function,
    actionsRender: Function,
    iconsRender: Function,
    odd: number,
    hideActions: boolean
}

const HistoyItemHandler = ({ theme, detailsRender, actionsRender, iconsRender, odd, hideActions }: Props) => (
    <HistoryItemDiv>
        <MainContent theme={theme} odd={odd}>
            {detailsRender()}
        </MainContent>

        <ViewContainer>
            <HistoryLine theme={theme} />
            <Circle theme={theme} diameter={40} borderRadius={5}>
                {iconsRender()}
            </Circle>
        </ViewContainer>
        <ActionDiv theme={theme} odd={odd}>
            {!hideActions && actionsRender()}
        </ActionDiv>
    </HistoryItemDiv>
)

const MainContent = styled("div")`
    order: ${props => (props.odd ? 2 : 0)};
    flex: 0 0 auto;
    width: 42%;
    /* right align item content text when it is to the left of the timeline */
    display: flex;
    flex-direction: column;
    align-items: ${props => (props.odd ? "flex-start" : "flex-end")};
    text-align: ${props => (props.odd ? "left" : "right")};
`
const ActionDiv = styled("div")`
    order: ${props => (props.odd ? 0 : 2)};
    flex: 0 0 auto;
    width: 42%;
    color: ${props => props.theme.typography.timelineIcon.color}!important;
    line-height: ${props => `${props.diameter + 2 * props.borderRadius}px`};
    /* right align date text when it is to the left of the timeline */
    display: flex;
    justify-content: ${props => (props.odd ? "flex-end" : "flex-start")};
`

const HistoryItemDiv = styled("div")`
    position: relative;
    display: flex;
    align-items: center;
    padding-top: 20px;
    padding-bottom: 20px;
`

/* border-bottom: ${props =>
    `1px solid ${props.theme.detailPage.history.subTitle}`}; */

const ViewContainer = styled("div")`
    order: 1;
    flex: 0 0 auto;
    width: 16%;
`

const Circle = styled("div")`
    position: relative;
    left: 50%;
    transform: translateX(-50%);
    background-color: #fff;
    width: 46px;
    height: 46px;
    border: 2px solid #c5cdda;
    border-radius: 50%;
    text-align: center;
    vertical-align: middle;
    line-height: 2px;
`

const HistoryLine = styled("div")`
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    width: 3px;
    top: 0;
    bottom: 0;
    background: #c5cdda;
`

export default withTheme()(HistoyItemHandler)
