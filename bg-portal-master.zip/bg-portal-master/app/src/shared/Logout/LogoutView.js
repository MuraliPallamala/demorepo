// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import LockIcon from "@material-ui/icons/Lock"
import LoginView from "~/shared/Login/LoginView"
import { authStorage } from "~/util/auth"

type Props = {
    theme: Object,
    children: Object,
    history: Object,
    match: Object,
    redirectKey: string
}
const getClasses = ({ theme }) => {
    const buttonStyle = css({
        color: theme.typography.button.color,
        fontSize: "20px",
        fontWeight: 400
    })
    const lockStyle = css(buttonStyle, {
        fontSize: "60px"
    })
    const textStyle = css({ color: theme.typography.cardTitle.color })
    const containerStlye = css({ marginTop: "24px", marginBottom: "24px" })

    return {
        buttonStyle,
        lockStyle,
        textStyle,
        containerStlye
    }
}
const redirectLogin = history => {
    const requestKey = authStorage.getRequestKey()
    if (requestKey && requestKey !== " ") {
        history.push(`/login/${requestKey}`)
    } else {
        history.push(`/login?nokey`)
    }
}

const Logout = ({ theme, children, history, match }: Props) => {
    const classes = getClasses({ theme })
    return (
        <LoginView>
            <div className={classes.containerStlye}>
                <LockIcon className={classes.lockStyle} />
                <Typography className={classes.textStyle}> You have been logged out.</Typography>
                <Button className={classes.buttonStyle} onClick={() => redirectLogin(history)} data-cy="loginbutton">
                    Log in again
                </Button>
            </div>
        </LoginView>
    )
}

Logout.defaultProps = {
    redirectKey: " "
}

export default withTheme()(Logout)
