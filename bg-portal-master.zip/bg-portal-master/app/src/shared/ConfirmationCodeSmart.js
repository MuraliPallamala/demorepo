// @flow

import * as React from "react"
import Button from "@material-ui/core/Button"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import { Grid } from "~/shared/layout"
import Typography from "@material-ui/core/Typography"
import Tooltip from "@material-ui/core/Tooltip"

const getClasses = ({ theme }) => {
    const buttonStyle = css({
        backgroundColor: theme.palette.common.confirmationButtonBackground,
        padding: "7px 7px 0px 7px",
        borderRadius: "5px"
    })
    const textContainer = css({
        textAlign: "left"
    })
    const confirmationButtonText = css({
        color: theme.palette.common.confirmationButtonText,
        display: "block",
        fontWeight: theme.typography.fontWeightMedium,
        textTransform: "none"
    })
    const confirmationText = css(confirmationButtonText, {
        fontSize: "10px"
    })
    const pinStyle = css(confirmationButtonText, {
        fontSize: "2em",
        lineHeight: "28px"
    })

    return {
        buttonStyle,
        textContainer,
        confirmationText,
        pinStyle
    }
}

type Props = {
    theme: Object,
    text: string,
    onRequestCode: Function,
    id: string
}

type State = {
    confirmationCode: string
}

class SmartPinButton extends React.Component<Props, State> {
    static defaultProps = {
        id: "hi"
    }
    constructor(props) {
        super(props)

        this.state = {
            confirmationCode: "****"
        }
    }
    changeCode = () => {
        if (this.state.confirmationCode === "****") {
            this.props
                .onRequestCode(this.props.id)
                .then(({ data }) => this.setState({ confirmationCode: data.token }))
                .catch(err => console.log(err))
        } else {
            this.setState({ confirmationCode: "****" })
        }
    }
    render() {
        const { text, theme } = this.props
        const { confirmationCode } = this.state
        const classes = getClasses({ theme })
        return (
            <Tooltip title={text} disableFocusListener>
                <Button
                    className={classes.buttonStyle}
                    onClick={e => {
                        e.preventDefault()
                        e.stopPropagation()
                        this.changeCode()
                    }}
                >
                    <Grid className={classes.textContainer}>
                        <Typography className={classes.confirmationText}>{text}</Typography>
                        <Typography className={classes.pinStyle}>{confirmationCode}</Typography>
                    </Grid>
                </Button>
            </Tooltip>
        )
    }
}

export default withTheme()(SmartPinButton)
