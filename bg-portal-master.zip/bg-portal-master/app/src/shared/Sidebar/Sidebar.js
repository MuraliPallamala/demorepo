// @flow

import * as React from "react"
import { css } from "emotion"
import _ from "lodash/fp"
import { withTheme } from "@material-ui/core/styles"
import MenuList from "@material-ui/core/MenuList"
import { GX_STATUS, getGxStatusDisplay } from "~/util/logic/gx"
import FilterContext from "~/shared/Context/Filter/FilterContext"
import generateKey from "~/util/helpers/generateKey"
import SidebarMenuItem from "./SidebarMenuItem"

const getClasses = ({ theme }) => {
    const main = css({
        minHeight: "100vh",
        backgroundColor: theme.palette.common.backgroundGrey,
        fontFamily: theme.fontFamily,
        display: "flex",
        flexDirection: "column",
        marginRight: "5px"
    })
    const flexFullBorderBox = css({
        flex: 1,
        boxSizing: "border-box",
        padding: "8px"
    })
    const titleLink = css({
        display: "block",
        textDecoration: "none",
        color: theme.palette.common.sidebarText,
        paddingLeft: theme.spacing.unit * 2,
        fontSize: "25px",
        fontWeight: theme.typography.fontWeightMedium
    })
    const titleFooter = css({
        display: "block",
        textDecoration: "none",
        color: theme.palette.common.sidebarText,
        paddingLeft: theme.spacing.unit * 2
    })
    const footerContainer = css({
        backgroundColor: theme.palette.common.white,
        padding: `${theme.spacing.unit * 2}px`,
        color: theme.palette.textColor
    })
    const logoContainer = css({
        marginBottom: theme.spacing.unit,
        display: "flex",
        justifyContent: "space-between"
    })
    const ibmLogo = css({
        paddingTop: 9,
        height: 36
    })
    const anzLogo = css({ height: "35px" })
    const logo = css({
        padding: theme.spacing.unit * 2,
        maxWidth: "100%",
        paddingTop: theme.spacing.unit * 10
    })
    const footerLink = css({
        color: theme.palette.common.sidebarText,
        textdecoration: "none",
        "&:hover": {
            textdecoration: "underline"
        }
    })
    const poweredByText = css({
        fontStyle: "italic",
        fontSize: theme.typography.caption.fontSize
    })
    const ibmText = css({
        fontWeight: theme.typography.fontWeightMedium
    })
    const sidebarList = css({
        // marginTop: theme.spacing.unit * 4,
        backgroundColor: theme.palette.common.backgroundGrey
    })
    const menuList = css({
        padding: "0px"
    })
    const outerDivFirstItem = css({
        marginTop: theme.spacing.unit * 2
    })
    const outerDivSecondItem = css({
        marginBottom: theme.spacing.unit
    })
    const outerDivRemainingItems = css({
        marginTop: theme.spacing.unit * 2
    })

    return {
        main,
        flexFullBorderBox,
        titleLink,
        titleFooter,
        footerContainer,
        logoContainer,
        ibmLogo,
        anzLogo,
        footerLink,
        poweredByText,
        ibmText,
        sidebarList,
        logo,
        menuList,
        outerDivFirstItem,
        outerDivSecondItem,
        outerDivRemainingItems
    }
}

type Props = {
    theme: Object,
    location: Object,
    className?: string,
    needsActionCount: number,
    notificationsCount: number,
    updateSettings?: Function
}

type State = {
    // settingsList: Array<Object>,
    notifications: Object,
    needsAction: Object,
    mainList: Array<Object>,
    adminList: Array<Object>
}

class Sidebar extends React.Component<Props, State> {
    static countFilters = filters => {
        let count = 0
        Object.values(filters).forEach(value => {
            if (Array.isArray(value)) {
                count += value.length
            } else {
                count += 1
            }
        })

        return count
    }
    state = {
        notifications: {
            label: "Notifications",
            indent: false,
            route: "notifications",
            filters: {},
            count: 0
        },
        needsAction: {
            label: "Needs Action",
            indent: false,
            route: "needsaction",
            filters: {},
            count: 0
        },

        adminList: [
            {
                label: "Organisations",
                indent: false,
                route: "organisations",
                filters: {},
                count: 0
            },
            {
                label: "Active",
                indent: true,
                route: "organisations",
                filters: {
                    status: "ACTIVE"
                },
                count: 0
            },
            {
                label: "Inactive",
                indent: true,
                route: "organisations",
                filters: {
                    status: "INACTIVE"
                },
                count: 0
            },
            {
                label: "Onboarding",
                indent: false,
                route: "onboardinglist",
                filters: {},
                count: 0
            },
            {
                label: "In Progress",
                indent: true,
                route: "onboardinglist",
                filters: {
                    status: "CONFIRMED"
                },
                count: 0
            },
            {
                label: "Completed",
                indent: true,
                route: "onboardinglist",
                filters: {
                    status: "APPROVED"
                },
                count: 0
            },
            {
                label: "Rejected",
                indent: true,
                route: "onboardinglist",
                filters: {
                    status: "REJECTED"
                },
                count: 0
            }
        ],
        mainList: [
            {
                label: "Pending Requests",
                indent: false,
                route: "pending-gx",
                filters: {},
                count: 0
            },
            // {
            //     label: "Pending",
            //     indent: true,
            //     route: "guarantee-requests",
            //     filters: {
            //         status: "PENDING"
            //     },
            //     count: 0
            // },
            // {
            //     label: "Withdrawn",
            //     indent: true,
            //     route: "guarantee-requests",
            //     filters: {
            //         status: "WITHDRAWN"
            //     },
            //     count: 0
            // },
            // {
            //     label: "Completed",
            //     indent: true,
            //     route: "guarantee-requests",
            //     filters: {
            //         status: "COMPLETED"
            //     },
            //     count: 0
            // },
            {
                label: "All Guarantees",
                indent: false,
                route: "gx",
                filters: {},
                count: 0
            },
            // {
            //     label: "Valid",
            //     indent: false,
            //     route: "gx",
            //     filters: {
            //         status: ["valid"]
            //     },
            //     count: 0
            // },
            {
                label: getGxStatusDisplay(GX_STATUS.ACTIVE),
                indent: false,
                route: "gx",
                filters: {
                    status: [GX_STATUS.ACTIVE]
                },
                count: 0
            },
            {
                label: "Expires in 3 Months",
                indent: true,
                route: "gx",
                filters: {
                    expiryMonths: "3"
                },
                count: 0
            },
            {
                label: "Expires in 2 Months",
                indent: true,
                route: "gx",
                filters: {
                    expiryMonths: "2"
                },
                count: 0
            },

            {
                label: "Expires in 1 Month",
                indent: true,
                route: "gx",
                filters: {
                    expiryMonths: "1"
                },
                count: 0
            },
            // {
            //     label: "Not Yet Issued",
            //     indent: true,
            //     route: "gx",
            //     filters: {
            //         status: [GX_STATUS.notIssued]
            //     },
            //     count: 0
            // },

            {
                label: "Inactive",
                indent: false,
                route: "gx",
                filters: {
                    status: "void"
                },
                disabled: true,
                count: 0
            },

            {
                label: getGxStatusDisplay(GX_STATUS.EXPIRED),
                indent: true,
                route: "gx",
                filters: {
                    status: [GX_STATUS.EXPIRED]
                },
                count: 0
            },
            {
                label: getGxStatusDisplay(GX_STATUS.CANCELLED),
                indent: true,
                route: "gx",
                filters: {
                    status: [GX_STATUS.CANCELLED]
                },
                count: 0
            },
            {
                label: getGxStatusDisplay(GX_STATUS.TRANSFERRED),
                indent: true,
                route: "gx",
                filters: {
                    status: [GX_STATUS.TRANSFERRED]
                },
                count: 0
            },
            // {
            //     label: "Rejected",
            //     indent: true,
            //     route: "gx",
            //     filters: {
            //         status: [GX_STATUS.denied]
            //     },
            //     count: 0
            // },
            {
                label: "Satisfied",
                indent: false,
                route: "gx",
                filters: {
                    status: [GX_STATUS.DEMANDED, GX_STATUS.PAYWALKED]
                },
                disabled: true,
                count: 0
            },
            {
                label: getGxStatusDisplay(GX_STATUS.DEMANDED),
                indent: true,
                route: "gx",
                filters: {
                    status: [GX_STATUS.DEMANDED]
                },
                count: 0
            },
            {
                label: getGxStatusDisplay(GX_STATUS.PAYWALKED),
                indent: true,
                route: "gx",
                filters: {
                    status: [GX_STATUS.PAYWALKED]
                },
                count: 0
            },
            {
                label: "Guarantee Requests",
                indent: false,
                route: "guarantee-requests",
                filters: {},
                count: 0
            },

            {
                label: "Organisations",
                indent: false,
                route: "organisations",
                filters: {},
                count: 0
            },
            {
                label: "Active",
                indent: true,
                route: "organisations",
                filters: {
                    status: "ACTIVE"
                },
                count: 0
            },
            {
                label: "Inactive",
                indent: true,
                route: "organisations",
                filters: {
                    status: "INACTIVE"
                },
                count: 0
            },
            {
                label: "Onboarding",
                indent: false,
                route: "onboardinglist",
                filters: {},
                count: 0
            },
            {
                label: "In Progress",
                indent: true,
                route: "onboardinglist",
                filters: {
                    status: "CONFIRMED"
                },
                count: 0
            },
            {
                label: "Completed",
                indent: true,
                route: "onboardinglist",
                filters: {
                    status: "APPROVED"
                },
                count: 0
            },
            {
                label: "Rejected",
                indent: true,
                route: "onboardinglist",
                filters: {
                    status: "REJECTED"
                },
                count: 0
            }
        ]
    }

    isSelected = (filters, sidebarItem) => {
        const { location } = this.props

        // make sure pending-gx is still selected when on pending-gx route and filters are applied
        if (
            location.pathname.substring(1) === "pending-gx" &&
            sidebarItem.route === location.pathname.substring(1, sidebarItem.route.length + 1) &&
            Sidebar.countFilters(filters) > 0
        ) {
            return true
        }
        // don't highlight sidebar item if there is more than 1 filters applied or if the current route doesn't
        // match the sidebar route
        if (
            Sidebar.countFilters(filters) > 1 ||
            sidebarItem.route !== location.pathname.substring(1, sidebarItem.route.length + 1)
        ) {
            return false
        }
        // If the path matches (from getting past if statement above), return true if both filters are empty
        if (Object.keys(sidebarItem.filters).length === 0) {
            return Object.keys(filters).length === 0
        }

        // checks whether filter matches for gx filters
        return !Object.entries(sidebarItem.filters).some(([key, value]) => !_.isEqual(filters[key])(value))
    }

    listType = () => {
        if (PORTAL_TYPE === "admin") {
            return this.state.adminList
        }
        return this.state.mainList
    }
    render() {
        const { theme, className = "", needsActionCount, notificationsCount, updateSettings } = this.props
        const notifications = {
            ...this.state.notifications,
            count: notificationsCount
        }
        const needsAction = {
            ...this.state.needsAction,
            count: needsActionCount
        }
        const classes = getClasses({ theme })
        return (
            <FilterContext.Consumer>
                {({ filters, replaceFilters, addFilter, removeFilter }) => (
                    <div className={`${classes.main} ${className}`}>
                        <div className={classes.flexFullBorderBox}>
                            <div role="group" className={classes.sidebarList}>
                                <MenuList className={classes.menuList}>
                                    <SidebarMenuItem
                                        className={classes.outerDivFirstItem}
                                        item={notifications}
                                        selected={this.isSelected(filters, notifications)}
                                        type="notification"
                                        updateSettings={updateSettings}
                                    />
                                </MenuList>
                                <MenuList className={classes.menuList}>
                                    <SidebarMenuItem
                                        className={classes.outerDivSecondItem}
                                        item={needsAction}
                                        selected={this.isSelected(filters, needsAction)}
                                        type="notification"
                                        updateSettings={updateSettings}
                                    />
                                </MenuList>
                            </div>
                            <MenuList className={classes.menuList}>
                                {this.listType().map((item, index) => (
                                    <SidebarMenuItem
                                        className={classes.outerDivRemainingItems}
                                        key={generateKey(index)} // eslint-disable-line react/no-array-index-key
                                        item={item}
                                        selected={this.isSelected(filters, item)}
                                        updateSettings={updateSettings}
                                    />
                                ))}
                            </MenuList>
                        </div>
                    </div>
                )}
            </FilterContext.Consumer>
        )
    }
}

export default withTheme()(Sidebar)
