// @flow

import * as React from "react"
import { css } from "emotion"
import { Link } from "react-router-dom"
import MenuItem from "@material-ui/core/MenuItem"
import queryString from "query-string"
import { withTheme } from "@material-ui/core/styles"

const getClasses = ({ theme, selected, item }) => {
    const selectedSidebarColor = theme.palette.primary.selectedSidebar || theme.palette.primary.contrastText
    // gets the length of the notification count in order to set circle width approrpiately
    const width = item.count.toString().length > 1 ? item.count.toString().length * 17 : 27
    const menuItem = css({
        // color: selected ? theme.palette.primary[50] : theme.palette.primary[50],
        color: selected ? selectedSidebarColor : theme.palette.common.sidebarText,
        backgroundColor: selected ? theme.overrides.sideBarHighlight : null,
        "&:hover": {
            backgroundColor: selected ? theme.overrides.sideBarHighlight : "rgba(0, 0, 0, 0.08)"
        },
        // paddingLeft: report.indent ? 7 * theme.spacing.unit : 4 * theme.spacing.unit,
        fontWeight: item.indent ? theme.typography.fontWeightLight : theme.typography.fontWeightRegular,
        justifyContent: "space-between",
        // paddingRight: 4 * theme.spacing.unit,
        borderRadius: "20px",
        height: "10px",
        margin: " auto",
        width: "200px",
        lineHeight: "1.5em"
    })
    const circle = css({
        backgroundColor: item.count > 0 && theme.palette.common.notificationBlue,
        color: item.count > 0 && theme.palette.common.white,
        borderRadius: "100px",
        height: "27px",
        width: `${width}px`,
        textAlign: "center"
    })
    const indent = css({
        paddingLeft: item.indent ? theme.spacing.unit * 4 : "0px",
        lineHeight: "24px"
    })
    const outerDiv = css({
        marginBottom: "0px",
        marginTop: "0px"
    })
    return {
        menuItem,
        circle,
        indent,
        outerDiv
    }
}

type Props = {
    item: Object,
    theme: Object,
    selected: boolean,
    className: string,
    type: string,
    updateSettings?: Function
}
type State = {}

// Note Required to be a class component as MenuList uses ref under the hood
// eslint-disable-next-line react/prefer-stateless-function
class SidebarMenuItem extends React.Component<Props, State> {
    static defaultProps = {
        type: ""
    }
    getLink = () => {
        const { item } = this.props
        const search = queryString.stringify(item.filters, { arrayFormat: "bracket" })
        return `/${item.route}?${search}`
    }

    render() {
        const { item, theme, selected, type, updateSettings } = this.props
        const classes = getClasses({ theme, selected, item })

        const cName = this.props.item.indent ? classes.outerDiv : this.props.className

        const menuItemElem = (
            <MenuItem disabled={item.disabled} className={classes.menuItem}>
                <div className={classes.indent}>{item.label}</div>
                {type === "notification" && <div className={classes.circle}>{item.count}</div>}
            </MenuItem>
        )

        return (
            <div className={cName}>
                {!item.disabled ? (
                    <Link to={this.getLink()} onClick={updateSettings || (() => null)} css="text-decoration:none">
                        {menuItemElem}
                    </Link>
                ) : (
                    menuItemElem
                )}
            </div>
        )
    }
}

export default withTheme()(SidebarMenuItem)
