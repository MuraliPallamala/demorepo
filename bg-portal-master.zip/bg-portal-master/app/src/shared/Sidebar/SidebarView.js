// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import { Grid, Block } from "~/shared/layout"
import Sidebar from "./Sidebar"

const getClasses = ({ theme }) => {
    const sidebar = css({
        gridArea: "sidebar"
    })
    const main = css({
        gridArea: "main"
    })
    return {
        sidebar,
        main
    }
}

type Props = {
    theme: Object,
    location: Object,
    children: Object,
    needsActionCount: number,
    notificationsCount: number,
    updateSettings: Function
}

const SidebarView = ({ theme, location, children, needsActionCount, notificationsCount, updateSettings }: Props) => {
    const classes = getClasses({ theme })
    return (
        <Grid
            grid={` "sidebar header"
        "sidebar main" 1fr /
        256px 1fr`}
        >
            <Sidebar
                className={classes.sidebar}
                notificationsCount={notificationsCount}
                needsActionCount={needsActionCount}
                location={location}
                updateSettings={updateSettings}
            />
            <Block className={classes.main}>{children}</Block>
        </Grid>
    )
}

export default withTheme()(SidebarView)
