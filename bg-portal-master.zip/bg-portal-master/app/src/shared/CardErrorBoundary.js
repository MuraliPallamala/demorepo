// @flow

import * as React from "react"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import WarningIcon from "@material-ui/icons/Warning"
import { CopyToClipboard } from "react-copy-to-clipboard"
import { css } from "emotion"
import { authStorage } from "~/util/auth"
import { withTheme } from "@material-ui/core/styles"

import { Flex } from "~/shared/layout"

type Props = {
    children: React.Node,
    customStyle?: Object,
    message: string,
    theme: Object
}

type State = {
    hasError: boolean,
    error: ?Error,
    info: ?Object
}

class CardErrorBoundary extends React.Component<Props, State> {
    state = { hasError: false, error: null, info: null }

    static getDerivedStateFromError(error: Error) {
        return { hasError: true }
    }
    componentDidCatch(error, info) {
        // Example "componentStack":
        //   in ComponentThatThrows (created by App)
        //   in ErrorBoundary (created by App)
        //   in div (created by App)
        //   in App
        this.setState({ error, info })
    }
    render() {
        if (this.state.hasError) {
            // You can render any custom fallback UI
            return (
                <Card className={css(this.props.customStyle)}>
                    <CardContent>
                        <Flex>
                            <WarningIcon
                                css={{
                                    fill: this.props.theme.palette.common.defaultRed,
                                    marginRight: this.props.theme.spacing.unit
                                }}
                                titleAccess="Error Icon"
                            />
                            <Typography
                                className={css(this.props.theme.typography.cardTitle, {
                                    color: this.props.theme.palette.common.defaultRed
                                })}
                            >
                                {this.props.message}
                            </Typography>
                        </Flex>
                        <Flex alignItems="center">
                            <CopyToClipboard
                                text={`${this.state.error ? `Error Message: ${this.state.error.message}` : ""}\n${
                                    this.state.info ? `Component Stack: ${this.state.info.componentStack}` : ""
                                } \n ${authStorage.getFormattedErrorQueueLogs()}`}
                            >
                                <Button className={css(this.props.theme.typography.button)}>
                                    Copy Error to clipboard
                                </Button>
                            </CopyToClipboard>
                        </Flex>
                    </CardContent>
                </Card>
            )
        }
        return this.props.children
    }
}

export default withTheme()(CardErrorBoundary)
