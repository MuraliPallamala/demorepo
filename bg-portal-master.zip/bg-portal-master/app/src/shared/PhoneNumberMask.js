import React from "react"
import NumberFormat from "react-number-format"

function PhoneNumberMask(props) {
    const { inputRef, onChange, ...other } = props
    return (
        <NumberFormat
            {...other}
            getInputRef={inputRef}
            onValueChange={values => {
                onChange({
                    target: {
                        value: values.value
                    }
                })
            }}
            defaultValue=""
            format="(+##) #########"
            mask=" "
        />
    )
}

export default PhoneNumberMask
