// @flow

import * as React from "react"
import TextField from "@material-ui/core/TextField"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import { Flex, Grid, Block } from "~/shared/layout"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import { Formik } from "formik"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"

const getClasses = ({ theme }) => {
    const cardTitle = css(theme.typography.formTitle)
    const confirmMessage = css(theme.typography.confirmMessage)
    const emailStyle = css({
        ...theme.typography.formTitle,
        fontWeight: 300,
        marginLeft: ".4em"
    })
    const detailsSpacing = css({
        p: {
            marginBottom: theme.spacing.unit * 2
        }
    })
    const inviteButton = css({
        color: theme.palette.common.lightBlue
    })
    const textStyling = css({
        maxWidth: "80%",
        color: theme.palette.grey,
        paddingBottom: theme.spacing.unit * 2
    })
    const contentWrapper = css({
        position: "relative"
    })
    const validSection = css({
        color: "green"
    })
    const invalidSection = css({
        color: theme.palette.common.defaultRed
    })
    return {
        cardTitle,
        emailStyle,
        detailsSpacing,
        inviteButton,
        textStyling,
        contentWrapper,
        validSection,
        invalidSection,
        confirmMessage
    }
}

type Props = {
    theme: Object,
    onSubmit: Function,
    userEmail: string,
    passwordSet: boolean,
    headerText: string,
    edit: Function,
    setMode: boolean,
    pwUpdated: boolean,
    hideEdit: boolean
}

const validate = values => {
    const errors = {}
    if (!values.password) {
        errors.password = "Required"
    } else if (
        !/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]).{8,}$/i.test(values.password)
    ) {
        errors.password = "Invalid"
    }
    if (!/(?=.*?[a-z])/.test(values.password)) {
        errors.oneLowerLetter = "No Lower letter"
    }
    if (!/^(?=.*?[A-Z])/.test(values.password)) {
        errors.oneUpperLetter = "No upper letter"
    }
    if (!/^(?=.*?[0-9])/.test(values.password)) {
        errors.oneNumber = "No Number"
    }
    if (!/^(?=.*?[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~])/.test(values.password)) {
        errors.oneSpecialCharacter = "No Special Character"
    }
    if (values.password.length < 8) {
        errors.minCharacters = "Min 8 Characters"
    }
    if (!values.confirmPassword) {
        errors.confirmPassword = "Required"
    } else if (values.confirmPassword !== values.password) {
        errors.confirmPassword = "Passwords are not the same"
    }
    if (Object.keys(errors).length === 0) {
        return {}
    }
    return errors
}

const SetPasswordForm = ({
    theme,
    onSubmit,
    profile,
    userEmail,
    passwordSet,
    headerText,
    edit,
    setMode,
    pwUpdated,
    hideEdit
}: Props) => {
    function isPasswordValid(hasBeenTouched, isvalid) {
        if (isvalid && hasBeenTouched) {
            return classes.invalidSection
        } else if (hasBeenTouched) {
            return classes.validSection
        }
        return classes.textStyling
    }

    const classes = getClasses({ theme })
    return (
        <Formik
            initialValues={{
                password: "",
                confirmPassword: "",
                // NOTE these are for validation errors
                oneLowerLetter: "",
                oneUpperLetter: "",
                oneNumber: "",
                oneSpecialCharacter: "",
                minCharacters: ""
            }}
            validate={validate}
            onSubmit={(values, { setSubmitting, setErrors }) => {
                setSubmitting(true)
                onSubmit(values)
                    .then(() => {
                        setSubmitting(false)
                        edit()
                    })
                    .catch(() => {
                        setSubmitting(false)
                    })
            }}
            render={formikProps => (
                <form onSubmit={formikProps.handleSubmit}>
                    <div>
                        <Flex>
                            <span>
                                <Typography className={classes.cardTitle}>{headerText}</Typography>
                            </span>
                            <span>
                                <Typography className={classes.emailStyle}> for {userEmail}</Typography>
                            </span>
                            <span hidden={!pwUpdated} className={classes.confirmMessage}>
                                Your password has been updated.
                            </span>
                            <Flex flex="1" />
                            <LoadingDialog
                                open={formikProps.isSubmitting}
                                loading={formikProps.isSubmitting}
                                title="Submitting onboarding request..."
                            />
                            <Button
                                type="submit"
                                hidden={passwordSet}
                                disabled={
                                    formikProps.isSubmitting ||
                                    (formikProps.touched.password
                                        ? !!formikProps.errors.confirmPassword || !!formikProps.errors.password
                                        : true)
                                }
                                className={classes.inviteButton}
                            >
                                Save
                            </Button>
                            <Button
                                onClick={() => edit()}
                                hidden={passwordSet || setMode}
                                className={classes.inviteButton}
                            >
                                Cancel
                            </Button>
                            <Button
                                onClick={() => edit()}
                                hidden={!passwordSet || hideEdit}
                                className={classes.inviteButton}
                            >
                                Edit
                            </Button>
                        </Flex>
                    </div>
                    <Flex maxWidth="800px" justifyContent="space-between">
                        <Block>
                            <Typography>
                                <span hidden={passwordSet}>
                                    <span>Password must contain: </span>
                                    <span
                                        className={isPasswordValid(
                                            formikProps.values.password.length > 0,
                                            formikProps.errors.minCharacters
                                        )}
                                    >
                                        Min 8 characters
                                    </span>
                                    <span>,&nbsp;</span>
                                    <span>at least</span>
                                    <span>&nbsp;</span>
                                    <span
                                        className={isPasswordValid(
                                            formikProps.values.password.length > 0,
                                            formikProps.errors.oneUpperLetter
                                        )}
                                    >
                                        one upper case letter
                                    </span>
                                    <span>,&nbsp;</span>
                                    <span
                                        className={isPasswordValid(
                                            formikProps.values.password.length > 0,
                                            formikProps.errors.oneLowerLetter
                                        )}
                                    >
                                        one lower case letter
                                    </span>
                                    <span>,&nbsp;</span>
                                    <span
                                        className={isPasswordValid(
                                            formikProps.values.password.length > 0,
                                            formikProps.errors.oneNumber
                                        )}
                                    >
                                        one digit
                                    </span>
                                    <span>,&nbsp;</span>
                                    <span
                                        className={isPasswordValid(
                                            formikProps.values.password.length > 0,
                                            formikProps.errors.oneSpecialCharacter
                                        )}
                                    >
                                        one special character
                                    </span>
                                </span>
                            </Typography>

                            <Grid gridGap="3un" paddingTop="4un" gridTemplateColumns="repeat(2, auto)">
                                <TextField
                                    placeholder="Password"
                                    label="Password"
                                    type="password"
                                    name="password"
                                    disabled={passwordSet}
                                    onChange={formikProps.handleChange}
                                    onBlur={formikProps.handleBlur}
                                    value={formikProps.values.password}
                                    error={
                                        formikProps.touched.password && !passwordSet
                                            ? !!formikProps.errors.password
                                            : false
                                    }
                                    helperText={formikProps.errors.password}
                                />
                                <TextField
                                    placeholder="Confirm Password"
                                    label="Confirm Password"
                                    type="password"
                                    name="confirmPassword"
                                    disabled={passwordSet}
                                    onChange={formikProps.handleChange}
                                    onBlur={formikProps.handleBlur}
                                    value={formikProps.values.confirmPassword}
                                    error={
                                        formikProps.touched.password && !passwordSet
                                            ? !!formikProps.errors.confirmPassword
                                            : false
                                    }
                                    helperText={formikProps.errors.confirmPassword}
                                />
                            </Grid>
                        </Block>
                    </Flex>
                </form>
            )}
        />
    )
}

SetPasswordForm.defaultProps = {
    edit: () => console.log(),
    hideEdit: false
}

export default withTheme()(SetPasswordForm)
