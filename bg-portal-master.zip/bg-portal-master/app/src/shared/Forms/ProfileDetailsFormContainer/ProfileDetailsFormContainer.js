// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import Button from "@material-ui/core/Button"
import Typography from "@material-ui/core/Typography"
import { Formik } from "formik"
import { Flex } from "~/shared/layout"
import { primaryContactDefaultValues } from "~/util/onboarding"
import LoadingCard from "~/shared/BasicCards/LoadingCard"
import PrimaryContactDetailsFieldSet, {
    validate as primaryContactDetailsFieldSetValidate
} from "~/shared/Fields/ContactDetails/PrimaryContactDetailsFieldSet"

const getClasses = ({ theme }) => {
    const cardTitle = css(theme.typography.cardTitle)
    const formTitle = css(theme.typography.formTitle)
    const footerText = css(theme.typography.footerText)
    const button = css(theme.typography.button)
    const buttonContainer = css({
        marginTop: theme.spacing.unit,
        marginBottom: theme.spacing.unit
    })
    const body1 = css(theme.typography.body1)
    return {
        formTitle,
        cardTitle,
        button,
        footerText,
        buttonContainer,
        body1
    }
}

type Props = {
    initialValues: Object,
    onSubmit: Function,
    theme: Object,
    hideEdit?: boolean,
    loading: boolean,
    displayUpdateProfile: boolean,
    isAdmin: boolean,
    isPrimary: boolean
}

type State = {
    values: Object,
    edit: boolean
}

class ProfileDetailsFormContainer extends React.Component<Props, State> {
    static defaultProps = {
        displayUpdateProfile: true,
        isAdmin: false,
        isPrimary: false
    }
    constructor(props) {
        super(props)
        this.state = {
            values: {
                ...primaryContactDefaultValues,
                ...props.initialValues
            },
            edit: false
        }
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.initialValues.primaryEmail !== this.props.initialValues.primaryEmail) {
            this.setState({
                values: {
                    primaryFirstName: nextProps.initialValues.primaryFirstName,
                    primaryLastName: nextProps.initialValues.primaryLastName,
                    primaryEmail: nextProps.initialValues.primaryEmail,
                    primaryPhone: nextProps.initialValues.primaryPhone
                }
            })
        }
    }
    setEdit = () => {
        if (this.state.edit === false) {
            this.setState({
                edit: true
            })
        } else {
            this.setState({
                edit: false
            })
        }
    }

    setResetFields = (setFieldValue, fields) => {
        fields.forEach(field => {
            setFieldValue(field, this.state.values[field], false)
        })
    }

    setResetPrimary = setFieldValue => {
        this.setResetFields(setFieldValue, [
            "primaryFirstName",
            "primaryLastName",
            "primaryEmail",
            "primaryPhone",
            "primaryVerify"
        ])
    }

    updateValues = values => {
        this.setState({
            values: {
                ...this.state.values,
                ...values
            }
        })
    }
    formReset = func => {
        func()
        this.setState({
            edit: false
        })
    }

    render() {
        const { hideEdit, onSubmit, theme, loading, displayUpdateProfile, isAdmin, isPrimary } = this.props
        const { edit } = this.state
        const classes = getClasses({ theme })
        if (loading) {
            return <LoadingCard />
        }
        return (
            <Formik
                initialValues={this.state.values}
                validate={values => ({
                    ...primaryContactDetailsFieldSetValidate(values)
                })}
                onSubmit={(values, { setSubmitting, setErrors }) => {
                    setSubmitting(true)
                    // Assumes that on success component unmounts so no need to call setSubmitting
                    onSubmit(values)
                        .then(this.setState({ edit: false }))
                        .catch(() => {
                            setSubmitting(false)
                        })
                }}
                render={formikProps => (
                    <form onSubmit={formikProps.handleSubmit}>
                        <Card>
                            <CardContent>
                                <Flex>
                                    <Flex flex="1">
                                        <Typography
                                            hidden={!edit || !displayUpdateProfile}
                                            className={classes.formTitle}
                                        >
                                            Update Your Profile
                                        </Typography>
                                        <Typography
                                            hidden={edit || !displayUpdateProfile}
                                            className={classes.cardTitle}
                                        >
                                            Update Your Profile
                                        </Typography>
                                        <Typography hidden={displayUpdateProfile} className={classes.cardTitle}>
                                            View Your Profile
                                        </Typography>
                                    </Flex>
                                    <Flex className={classes.buttonContainer}>
                                        <Button
                                            className={classes.button}
                                            hidden={edit || hideEdit}
                                            onClick={() => this.setEdit()}
                                        >
                                            Edit
                                        </Button>
                                        <Button className={classes.button} type="submit" hidden={!edit}>
                                            Save
                                        </Button>
                                        <Button
                                            className={classes.button}
                                            onClick={() => this.formReset(formikProps.handleReset)}
                                            hidden={!edit}
                                        >
                                            Cancel
                                        </Button>
                                    </Flex>
                                </Flex>
                                <div>
                                    <Typography
                                        className={classes.body1}
                                        hidden={!displayUpdateProfile || (isAdmin || isPrimary)}
                                    >
                                        You can only change your <b>name</b> and <b>phone</b> details, but not your
                                        email.
                                    </Typography>
                                    <Typography
                                        className={classes.body1}
                                        hidden={!displayUpdateProfile || (!isAdmin && !isPrimary)}
                                    >
                                        As an Administrator or Primary Contact you can not update these details.
                                    </Typography>
                                    <Typography className={classes.body1} hidden={displayUpdateProfile}>
                                        You can change these details after logging in to the platform.
                                    </Typography>
                                </div>
                                <div>
                                    <PrimaryContactDetailsFieldSet prefilled disabled={!edit} formik={formikProps} />
                                </div>
                            </CardContent>
                        </Card>
                    </form>
                )}
            />
        )
    }
}

export default withTheme()(ProfileDetailsFormContainer)
