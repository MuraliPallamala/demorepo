// @flow

import React from "react"
import Button from "@material-ui/core/Button"

type Props = {
    formik: Object,
    edit: boolean,
    setEdit: Function,
    setSave: Function,
    setReset: Function
}

const SaveEditActions = ({ formik, edit, setEdit, setSave, setReset }: Props) => (
    <div>
        <div hidden={!edit}>
            <Button
                onClick={() => {
                    setSave(formik.values)
                    setEdit(false)
                }}
            >
                Done
            </Button>
            <Button
                onClick={() => {
                    setReset(formik.setFieldValue)
                    setEdit(false)
                }}
            >
                Cancel
            </Button>
        </div>
        <div hidden={edit}>
            <Button onClick={() => setEdit(true)}>Edit</Button>
        </div>
    </div>
)

export default SaveEditActions
