// @flow

import React from "react"
import Checkbox from "@material-ui/core/Checkbox"
import FormControlLabel from "@material-ui/core/FormControlLabel"
import CardActions from "@material-ui/core/CardActions"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Typography from "@material-ui/core/Typography"

const getClasses = ({ theme, checked, error }) => {
    let verifyCardActions = css({
        backgroundColor: checked ? undefined : "#F0FFFD"
    })
    if (error) {
        verifyCardActions = css({
            backgroundColor: "#ff8a80"
        })
    }

    const textStyle = css({ color: theme.palette.common.darkBlue })

    return {
        verifyCardActions,
        textStyle
    }
}

export const validate = (values: Object) => {
    const errors = {}
    if (!values.orgVerify) {
        errors.orgVerify = "I have verified these details (required)"
    }
    if (!values.adminVerify) {
        errors.adminVerify = "I have verified these details (required)"
    }
    if (!values.primaryVerify) {
        errors.primaryVerify = "I have verified these details (required)"
    }
    return errors
}

type Props = {
    theme: Object,
    field: string,
    formik: Object,
    disabled: boolean
}

const VerifyDetailsCheckBox = ({ disabled, formik, field, theme }: Props) => {
    const classes = getClasses({
        theme,
        checked: formik.values[field],
        error: formik.touched[field] && formik.errors[field]
    })
    const formikChecked = formik.values[field]
    return (
        <CardActions className={classes.verifyCardActions}>
            <FormControlLabel
                disabled={disabled || formik.isSubmitting}
                control={
                    <Checkbox
                        onChange={event => {
                            const { checked } = event.target
                            formik.setFieldValue(field, checked)
                        }}
                        value={field}
                        checked={!!formikChecked}
                    />
                }
                label={
                    formik.errors[field] ? (
                        formik.errors[field]
                    ) : (
                        <Typography className={classes.textStyle}>I have verified these details</Typography>
                    )
                }
            />
        </CardActions>
    )
}
VerifyDetailsCheckBox.defaultProps = {
    disabled: false
}

export default withTheme()(VerifyDetailsCheckBox)
