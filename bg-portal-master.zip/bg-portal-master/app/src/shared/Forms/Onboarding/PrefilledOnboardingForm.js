// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import CardActions from "@material-ui/core/CardActions"
import Typography from "@material-ui/core/Typography"
import { Formik } from "formik"

import { Block, Flex } from "~/shared/layout"
import OrganizationFieldSet, {
    validate as organizationFieldSetValidate
} from "~/shared/Fields/OrganizationDetails/OrganizationFieldSet"
import PrimaryContactDetailsFieldSet, {
    validate as primaryContactDetailsFieldSetValidate
} from "~/shared/Fields/ContactDetails/PrimaryContactDetailsFieldSet"
import AdminContactDetailsFieldSet, {
    validate as adminContactDetailsFieldSetValidate
} from "~/shared/Fields/ContactDetails/AdminContactDetailsFieldSet"
import AdminSameCheckbox from "~/shared/Fields/ContactDetails/AdminSameCheckbox"
import { onboardingDefaultValues } from "~/util/onboarding"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import withError from "~/shared/Context/ErrorDialog/withError"

import SaveEditActions from "./Components/SaveEditActions"
import VerifyDetailsCheckBox, { validate as verifyDetailsFieldSetValidate } from "./Components/VerifyDetailsCheckBox"

const getClasses = ({ theme }) => {
    const notFirstCard = css({
        marginTop: `${theme.spacing.unit * 2}px`
    })
    const title = css({
        fontSize: "20px", // TODO remove hard coding
        color: theme.palette.common.darkBlue
    })

    const adminTitle = css(title, {
        marginRight: theme.spacing.unit * 3
    })

    const button = css({
        color: theme.palette.common.darkBlue
    })
    const buttonContainer = css({
        marginTop: theme.spacing.unit,
        marginBottom: theme.spacing.unit
    })

    return {
        notFirstCard,
        title,
        adminTitle,
        button,
        buttonContainer
    }
}

const optionalAdminContactDetailsFieldSetValidate = values =>
    values.adminSameAsPrimaryContact ? {} : adminContactDetailsFieldSetValidate(values)

const adminPrimaryEmailFielSetValidate = (values, handleErrorOpen) => {
    const errors = {}
    if (
        values.adminEmail !== "" &&
        values.primaryEmail !== "" &&
        values.adminEmail.toLowerCase() === values.primaryEmail.toLowerCase() &&
        !values.adminSameAsPrimaryContact
    ) {
        errors.emailMatch = "Email of Primary Contact and Administrator are the same. Use the tick box instead"
        handleErrorOpen({
            errorMessage: "Email of Primary Contact and Administrator are the same. Use the tick box instead",
            title: "Administrator and Primary Contact emails match"
        })
    }
    return errors
}

type Props = {
    initialValues: Object,
    onCancel: Function,
    onSubmit: Function,
    theme: Object,
    handleErrorOpen: Function
}

type State = {
    values: Object,
    edit: Object
}
class PrefilledOnboardingForm extends React.Component<Props, State> {
    static defaultProps = {
        initialValues: {}
    }

    constructor(props) {
        super(props)
        this.state = {
            values: {
                ...onboardingDefaultValues,
                ...props.initialValues,
                primaryPhone: props.initialValues.primaryPhone.replace(/\+/g, ""),
                adminPhone: props.initialValues.adminPhone.replace(/\+/g, "")
            },
            edit: {
                org: false,
                primary: false,
                admin: false
            }
        }
    }

    setEdit = (type, formik) => edit => {
        this.setState({
            edit: {
                ...this.state.edit,
                [type]: edit
            }
        })
        formik.setFieldValue(`${type}Verify`, false)
    }

    setResetFields = (setFieldValue, fields) => {
        fields.forEach(field => {
            setFieldValue(field, this.state.values[field], false)
        })
    }

    setResetOrg = setFieldValue => {
        this.setResetFields(setFieldValue, [
            "entityName",
            "streetAddress",
            "addressLocality",
            "addressRegion",
            "addressCountry",
            "postalCode",
            "postOfficeBoxNumber",
            "businessID",
            "orgVerify"
        ])
    }

    setResetPrimary = setFieldValue => {
        this.setResetFields(setFieldValue, [
            "primaryFirstName",
            "primaryLastName",
            "primaryEmail",
            "primaryTelephone",
            "primaryMobile",
            "primaryVerify"
        ])
    }

    setResetAdmin = setFieldValue => {
        this.setResetFields(setFieldValue, [
            "adminSameAsPrimaryContact",
            "adminFirstName",
            "adminLastName",
            "adminEmail",
            "adminTelephone",
            "adminMobile",
            "adminVerify"
        ])
    }

    updateValues = values => {
        this.setState({
            values: {
                ...this.state.values,
                ...values
            }
        })
    }

    render() {
        const { onCancel, onSubmit, handleErrorOpen } = this.props
        const { edit } = this.state
        const classes = getClasses(this.props)

        return (
            <Formik
                initialValues={this.state.values}
                validate={values => ({
                    ...organizationFieldSetValidate({ values }),
                    ...primaryContactDetailsFieldSetValidate(values),
                    ...optionalAdminContactDetailsFieldSetValidate(values),
                    ...verifyDetailsFieldSetValidate(values),
                    ...adminPrimaryEmailFielSetValidate(values, handleErrorOpen)
                })}
                onSubmit={(values, { setSubmitting, setErrors }) => {
                    setSubmitting(true)
                    // Assumes that on success component unmounts so no need to call setSubmitting
                    onSubmit(values).catch(() => {
                        setSubmitting(false)
                    })
                }}
                render={formikProps => (
                    <form onSubmit={formikProps.handleSubmit}>
                        <LoadingDialog
                            open={formikProps.isSubmitting}
                            loading={formikProps.isSubmitting}
                            title="Submitting onboarding request..."
                        />
                        <Card style={{ overflow: "visible" }}>
                            <CardContent>
                                <Typography className={classes.title}>Company Details</Typography>
                                <Flex>
                                    <Flex flex="1" />
                                    <SaveEditActions
                                        formik={formikProps}
                                        edit={edit.org}
                                        setEdit={this.setEdit("org", formikProps)}
                                        setSave={this.updateValues}
                                        setReset={this.setResetOrg}
                                    />
                                </Flex>
                                <OrganizationFieldSet disabled={!edit.org} formik={formikProps} prefilled />
                                <VerifyDetailsCheckBox disabled={edit.org} field="orgVerify" formik={formikProps} />
                            </CardContent>
                        </Card>
                        <Card className={classes.notFirstCard}>
                            <CardContent>
                                <Typography className={classes.title}>Primary Contact</Typography>
                                <Flex>
                                    <Flex flex="1" />
                                    <SaveEditActions
                                        formik={formikProps}
                                        edit={edit.primary}
                                        setEdit={this.setEdit("primary", formikProps)}
                                        setSave={this.updateValues}
                                        setReset={this.setResetPrimary}
                                    />
                                </Flex>
                                <PrimaryContactDetailsFieldSet
                                    prefilled
                                    disabled={!edit.primary}
                                    formik={formikProps}
                                />
                                <VerifyDetailsCheckBox
                                    disabled={edit.primary}
                                    field="primaryVerify"
                                    formik={formikProps}
                                />
                            </CardContent>
                        </Card>
                        <Card className={classes.notFirstCard}>
                            <CardContent>
                                <Typography className={classes.title}>Administrator</Typography>
                                <Flex>
                                    <Flex flex="1" />
                                    <SaveEditActions
                                        formik={formikProps}
                                        edit={edit.admin}
                                        setEdit={this.setEdit("admin", formikProps)}
                                        setSave={this.updateValues}
                                        setReset={this.setResetAdmin}
                                    />
                                </Flex>
                                <AdminSameCheckbox disabled={!edit.admin} formik={formikProps} />
                                <AdminContactDetailsFieldSet
                                    disabled={!edit.admin}
                                    hidden={formikProps.values.adminSameAsPrimaryContact}
                                    formik={formikProps}
                                />
                                <div>
                                    <VerifyDetailsCheckBox
                                        disabled={edit.admin}
                                        field="adminVerify"
                                        formik={formikProps}
                                    />
                                </div>
                            </CardContent>
                        </Card>
                        <Card className={classes.notFirstCard}>
                            <CardActions className={classes.buttonContainer}>
                                <Button className={classes.button} onClick={() => onCancel()}>
                                    Cancel Onboarding
                                </Button>
                                <Block flex="1" />
                                <Typography className={classes.title}>
                                    Proceed to submit once the details are reviewed
                                </Typography>
                                <Button
                                    className={classes.button}
                                    disabled={
                                        formikProps.isSubmitting ||
                                        this.state.edit.org ||
                                        this.state.edit.admin ||
                                        this.state.edit.primary
                                    }
                                    type="submit"
                                >
                                    Submit Details
                                </Button>
                            </CardActions>
                        </Card>
                    </form>
                )}
            />
        )
    }
}
export default withError(withTheme()(PrefilledOnboardingForm))
