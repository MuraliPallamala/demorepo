// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import CardActions from "@material-ui/core/CardActions"
import Typography from "@material-ui/core/Typography"
import { Formik } from "formik"
import api from "~/util/api"

import { Flex, Block } from "~/shared/layout"
import OrganizationFieldSet, {
    validate as organizationFieldSetValidate
} from "~/shared/Fields/OrganizationDetails/OrganizationFieldSet"
import PrimaryContactDetailsFieldSet, {
    validate as primaryContactDetailsFieldSetValidate
} from "~/shared/Fields/ContactDetails/PrimaryContactDetailsFieldSet"
import AdminContactDetailsFieldSet, {
    validate as adminContactDetailsFieldSetValidate
} from "~/shared/Fields/ContactDetails/AdminContactDetailsFieldSet"
import AdminSameCheckbox from "~/shared/Fields/ContactDetails/AdminSameCheckbox"
import { onboardingDefaultValues } from "~/util/onboarding"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import withError from "~/shared/Context/ErrorDialog/withError"
import { asicAutoFillMap } from "~/util/asics"

const getClasses = ({ theme }) => {
    const notFirstCard = css({
        marginTop: `${theme.spacing.unit * 2}px`
    })

    const title = css(theme.typography.formTitle)

    const adminTitle = css(title, {
        marginRight: theme.spacing.unit * 3
    })
    const footerText = css(theme.typography.footerText)
    const body1 = css(theme.typography.body1)

    const button = css(theme.typography.button)
    const buttonContainer = css({
        marginTop: theme.spacing.unit,
        marginBottom: theme.spacing.unit
    })

    return {
        notFirstCard,
        title,
        adminTitle,
        button,
        footerText,
        buttonContainer,
        body1
    }
}

const setFromAsics = (orgInfo: Object, formik: Object) => {
    const asicInfo = asicAutoFillMap(orgInfo)
    formik.setFieldValue("addressRegion", asicInfo.addressRegion)
    formik.setFieldValue("postalCode", asicInfo.postalCode)
    formik.setFieldValue("entityName", asicInfo.entityName)
    formik.setFieldValue("addressCountry", { value: "Australia", label: "Australia" })
    formik.setStatus()
}

const getFromAsics = (businessId: string, formik: Object) => {
    if (businessId.replace(/\s/g, "").length === 9) {
        return api.asics
            .searchAsicsAcn(businessId.replace(/\s/g, ""))
            .then(({ data }) => {
                const orgInfo = data.result.pop()
                if (data.result.length === 0) {
                    formik.setStatus({ businessID: "This ACN does not exist within ASIC" })
                }
                setFromAsics(orgInfo, formik)
                return orgInfo
            })
            .catch(err => {
                // let form catch error
                throw err
            })
    }
    return api.asics
        .searchAsicsAbn(businessId.replace(/\s/g, ""))
        .then(({ data }) => {
            if (data.result.length === 0) {
                formik.setStatus({ businessID: "This ABN does not exist within ASIC" })
            }
            const orgInfo = data.result.pop()
            setFromAsics(orgInfo, formik)
            return orgInfo
        })
        .catch(err => {
            // let form catch error
            throw err
        })
}

const businessIDCheck = (formik, businessID, runApi) => {
    const values = { businessID }
    const query = `?businessId=${businessID.replace(/\s/g, "")}`
    const errors = {}
    formik.setStatus()
    if (runApi) {
        if (!organizationFieldSetValidate({ values }).businessID) {
            api.organisations
                .getOrganisations(query)
                .then(({ data }) => {
                    if (data.result.length >= 1) {
                        errors.businessIdMatch = "Error"
                        formik.setStatus({ businessID: "This ABN/ACN has already been added to the system" })
                    }
                })
                .catch(error => console.error("/api/organisations error", error))
        }
    }
}

const optionalAdminContactDetailsFieldSetValidate = values =>
    values.adminSameAsPrimaryContact ? {} : adminContactDetailsFieldSetValidate(values)

const adminPrimaryEmailFielSetValidate = (values, handleErrorOpen) => {
    const errors = {}
    if (
        values.adminEmail !== "" &&
        values.primaryEmail !== "" &&
        values.adminEmail.toLowerCase() === values.primaryEmail.toLowerCase() &&
        !values.adminSameAsPrimaryContact
    ) {
        errors.emailMatch = "Email of Primary Contact and Administrator are the same. Use the tick box instead"
        handleErrorOpen({
            errorMessage: "Email of Primary Contact and Administrator are the same. Use the tick box instead",
            title: "Administrator and Primary Contact emails match"
        })
    }
    return errors
}

type Props = {
    initialValues: Object,
    onCancel: Function,
    onSubmit: Function,
    referer: boolean,
    handleErrorOpen: Function,
    // eslint-disable-next-line
    theme: Object
}

const FreshOnboardingForm = ({ initialValues, onCancel, onSubmit, referer, handleErrorOpen, ...otherProps }: Props) => {
    const classes = getClasses(otherProps)
    return (
        <Formik
            initialValues={{
                ...onboardingDefaultValues,
                ...initialValues
            }}
            validate={values => ({
                ...organizationFieldSetValidate({ values, referer }),
                ...primaryContactDetailsFieldSetValidate(values, referer),
                ...optionalAdminContactDetailsFieldSetValidate(values),
                ...adminPrimaryEmailFielSetValidate(values, handleErrorOpen)
            })}
            onSubmit={(values, { setSubmitting, setErrors }) => {
                setSubmitting(true)
                // Assumes that on success component unmounts so no need to call setSubmitting
                onSubmit(values).catch(() => {
                    setSubmitting(false)
                })
            }}
            render={formikProps => (
                <form onSubmit={formikProps.handleSubmit}>
                    <LoadingDialog
                        open={formikProps.isSubmitting}
                        loading={formikProps.isSubmitting}
                        title="Submitting"
                    />
                    <Card style={{ overflow: "visible" }}>
                        <CardContent>
                            <Typography className={classes.title}>Organisation Details</Typography>
                            <Typography className={classes.body1}>Please complete the following details.</Typography>
                            <Typography className={classes.body1}>
                                Upon typing in your ABN/ACN and clicking the verify button, this form will auto-complete
                                fields matched within ASIC.
                            </Typography>
                            <OrganizationFieldSet
                                formik={formikProps}
                                businessIDCheck={businessIDCheck}
                                referer={referer}
                                verifyAsic={getFromAsics}
                            />
                        </CardContent>
                    </Card>
                    <Card className={classes.notFirstCard}>
                        <CardContent>
                            <Typography className={classes.title}>Primary Contact Details</Typography>
                            <Typography className={classes.body1}>
                                The Primary Contact will be the contact person for the account. We will send them a link
                                to their email to join in.
                            </Typography>
                            <PrimaryContactDetailsFieldSet primary formik={formikProps} />
                        </CardContent>
                    </Card>
                    <Card className={classes.notFirstCard}>
                        <CardContent>
                            <Flex alignItems="center">
                                <Typography className={classes.adminTitle}>
                                    Administrator Details {referer && "(Optional)"}
                                </Typography>
                                <AdminSameCheckbox formik={formikProps} />
                            </Flex>
                            <Typography className={classes.body1}>
                                The role of the Administrator is to manage users, select approval flow, and manage the
                                organisation details.
                            </Typography>
                            <AdminContactDetailsFieldSet
                                hidden={formikProps.values.adminSameAsPrimaryContact}
                                formik={formikProps}
                            />
                        </CardContent>
                    </Card>
                    <Card className={classes.notFirstCard}>
                        <CardActions className={classes.buttonContainer}>
                            <Button className={classes.button} onClick={onCancel}>
                                Cancel Onboarding
                            </Button>
                            <Block flex="1" />
                            <Typography className={classes.footerText}>
                                {referer
                                    ? "This onboarding request will be sent to the new entity for approval."
                                    : "This onboarding request will be sent to Lygon for approval."}
                            </Typography>
                            <Button
                                className={classes.button}
                                disabled={formikProps.isSubmitting}
                                data-cy="submit"
                                type="submit"
                            >
                                Submit Details
                            </Button>
                        </CardActions>
                    </Card>
                </form>
            )}
        />
    )
}
FreshOnboardingForm.defaultProps = {
    referer: false,
    initialValues: {}
}

export default withError(withTheme()(FreshOnboardingForm))
