// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import CardActions from "@material-ui/core/CardActions"
import Typography from "@material-ui/core/Typography"
import { Formik } from "formik"
import Divider from "@material-ui/core/Divider"
import MaterialGrid from "@material-ui/core/Grid"

import { Block } from "~/shared/layout"
import GuaranteeFieldSet, {
    validate as guaranteeDetailsFieldSetValidate
} from "~/shared/Fields/GuaranteeDetails/GuaranteeFieldSet"
import PartiesInvolvedFieldSet, {
    validate as partiesInvolvedFieldSetValidate
} from "~/shared/Fields/PartiesInvolved/PartiesInvolvedFieldSet"
import PurposeFieldSet from "~/shared/Fields/PurposeFieldSet/PurposeFieldSet"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

import { guaranteeDefaultValues, partiesInvolvedDefaultValues } from "~/util/guarantee"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import getCurrentTemplate from "~/util/helpers/getCurrentTemplate"

const getClasses = ({ theme }) => {
    const notFirstCard = css({
        marginTop: `${theme.spacing.unit * 2}px`
    })

    const title = css({ fontSize: theme.typography.fontSizeLarge })

    const adminTitle = css(title, {
        marginRight: theme.spacing.unit * 3
    })
    const footerText = css(theme.typography.footerText)
    const body1 = css(theme.typography.body1)

    const button = css(theme.typography.button)
    const buttonContainer = css({
        marginTop: theme.spacing.unit,
        marginBottom: theme.spacing.unit
    })
    const header = css({
        fontSize: theme.typography.fontSizeMedium
    })
    const containerCard = css({
        overflow: "visible"
    })

    return {
        notFirstCard,
        title,
        adminTitle,
        button,
        footerText,
        buttonContainer,
        body1,
        header,
        containerCard
    }
}

type Props = {
    initialValues: Object,
    onCancel: Function,
    onSubmit: Function,
    onReject?: Function,
    referer: boolean,
    // eslint-disable-next-line
    theme: Object,
    issuers: Array<any>,
    currentUserInformation: Object,
    prefillRequest: boolean,
    termsAndConditions: Array<any>,
    purposeTemplates: Templates
}

const FreshGuaranteeForm = ({
    initialValues,
    issuers,
    termsAndConditions,
    onCancel,
    onSubmit,
    referer,
    currentUserInformation,
    onReject,
    prefillRequest,
    purposeTemplates,
    ...otherProps
}: Props) => {
    const classes = getClasses(otherProps)
    return (
        <Formik
            // Doesnt require purposeFieldSet initial values as Formik Fields handles the initial values
            initialValues={{
                ...guaranteeDefaultValues,
                ...partiesInvolvedDefaultValues,
                ...initialValues
            }}
            validate={values => ({
                ...guaranteeDetailsFieldSetValidate({
                    values,
                    gxLimit: currentUserInformation.gxLimit[currentUserInformation.currentOrgId]
                }),
                ...partiesInvolvedFieldSetValidate({
                    values,
                    amend: false,
                    transfer: false,
                    currentUserInformation
                })
            })}
            enableReinitialize
            isInitialValid
            onSubmit={(values, { setSubmitting, setErrors, setTouched }) => {
                setSubmitting(true)
                // Assumes that on success component unmounts so no need to call setSubmitting

                // This section removes empty values and objects that just have empty fields
                const keyValues = Object.keys(values.purpose)
                keyValues.forEach(key => {
                    const keys = Object.keys(values.purpose[key])
                    const count = keys.length
                    let currCount = 0
                    keys.forEach(secondKey => {
                        if (values.purpose[key][secondKey] === "") {
                            currCount += 1
                            delete values.purpose[key][secondKey]
                        }
                    })
                    if (count === currCount) {
                        delete values.purpose[key]
                    }
                })
                onSubmit(values, currentUserInformation.entityType, currentUserInformation.approvalModel.name)
                    .then(() => setSubmitting(false))
                    .catch(() => {
                        setSubmitting(false)
                    })
            }}
            render={formikProps => {
                let buttonText = "Create Bank Guarantee"
                if (prefillRequest) {
                    buttonText = "Accept Issue Request"
                } else if (currentUserInformation.entityType === "ISSUER") {
                    buttonText = "Create Bank Guarantee Request"
                }
                const currentTemplateFields = getCurrentTemplate({
                    purposeTemplates,
                    selectedTemplate: formikProps.values.purposeType
                })
                return (
                    <form onSubmit={formikProps.handleSubmit}>
                        <LoadingDialog
                            open={formikProps.isSubmitting && !formikProps.isValidating && formikProps.isValid}
                            loading={formikProps.isSubmitting}
                            title="Submitting Bank Guarantee request..."
                        />
                        <Card className={classes.containerCard}>
                            <React.Fragment>
                                <CardContent>
                                    {currentUserInformation.actingOnBehalf &&
                                    currentUserInformation.actingOnBehalf.label ? (
                                        <Typography className={classes.header}>
                                            Acting on behalf of {currentUserInformation.actingOnBehalf.label}. Creating
                                            a Bank Guarantee
                                        </Typography>
                                    ) : (
                                        <Typography className={classes.header}>
                                            {currentUserInformation.entityName} is creating a Bank Guarantee
                                        </Typography>
                                    )}
                                    <Divider />
                                </CardContent>
                                <CardContent>
                                    <Typography className={classes.title}>Parties Involved</Typography>
                                    <PartiesInvolvedFieldSet
                                        formik={formikProps}
                                        currentUserInformation={currentUserInformation}
                                        issuers={issuers}
                                        prefillRequest={prefillRequest}
                                    />
                                </CardContent>
                            </React.Fragment>
                            <CardContent>
                                <MaterialGrid xl={9} lg={9}>
                                    <Typography className={classes.title}>Guarantee Purpose</Typography>
                                    <PurposeFieldSet
                                        fields={currentTemplateFields}
                                        purposeTemplates={purposeTemplates}
                                        formik={formikProps}
                                    />
                                </MaterialGrid>
                            </CardContent>
                            <CardContent>
                                <Typography className={classes.title}>Guarantee Details</Typography>
                                <GuaranteeFieldSet formik={formikProps} termsAndConditions={termsAndConditions} />
                            </CardContent>
                            <CardActions className={classes.buttonContainer}>
                                <Button className={classes.button} onClick={onCancel}>
                                    Exit
                                </Button>
                                <Block flex="1" />
                                {prefillRequest ? (
                                    <Button className={classes.button} onClick={onReject}>
                                        Reject Issue Request
                                    </Button>
                                ) : null}
                                <Button className={classes.button} disabled={formikProps.isSubmitting} type="submit">
                                    {buttonText}
                                </Button>
                            </CardActions>
                        </Card>
                    </form>
                )
            }}
        />
    )
}
FreshGuaranteeForm.defaultProps = {
    referer: false,
    initialValues: {},
    onReject: () => console.log(),
    prefillRequest: false
}

export default withTheme()(FreshGuaranteeForm)
