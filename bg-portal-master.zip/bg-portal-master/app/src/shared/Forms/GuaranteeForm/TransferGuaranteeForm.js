// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import CardActions from "@material-ui/core/CardActions"
import Typography from "@material-ui/core/Typography"
import MaterialGrid from "@material-ui/core/Grid"
import { Formik } from "formik"
import Divider from "@material-ui/core/Divider"
import { Block } from "~/shared/layout"
import GuaranteeFieldSet from "~/shared/Fields/GuaranteeDetails/GuaranteeFieldSet"
import PartiesInvolvedFieldSet, {
    validate as partiesInvolvedFieldSetValidate
} from "~/shared/Fields/PartiesInvolved/PartiesInvolvedFieldSet"
import { guaranteeDefaultValues, partiesInvolvedDefaultValues, novationDefaultValues } from "~/util/guarantee"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import { validate as novationFieldSetValidate } from "~/shared/Fields/GuaranteeDetails/NovationFieldSet"
import PurposeFieldSet from "~/shared/Fields/PurposeFieldSet/PurposeFieldSet"
import getCurrentTemplate from "~/util/helpers/getCurrentTemplate"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

const getClasses = ({ theme }) => {
    const notFirstCard = css({
        marginTop: `${theme.spacing.unit * 2}px`
    })

    const title = css({ fontSize: theme.typography.fontSizeLarge })

    const adminTitle = css(title, {
        marginRight: theme.spacing.unit * 3
    })
    const footerText = css(theme.typography.footerText)
    const body1 = css(theme.typography.body1)

    const button = css(theme.typography.button)
    const buttonContainer = css({
        marginTop: theme.spacing.unit,
        marginBottom: theme.spacing.unit
    })
    const header = css({
        fontSize: theme.typography.fontSizeMedium
    })
    const containerCard = css({
        overflow: "visible"
    })

    return {
        notFirstCard,
        title,
        adminTitle,
        button,
        footerText,
        buttonContainer,
        body1,
        header,
        containerCard
    }
}

type Props = {
    initialValues: Object,
    onCancel: Function,
    onSubmit: Function,
    theme: Object,
    currentUserInformation: Object,
    issuers: Array<any>,
    termsAndConditions: Array<any>,
    purposeTemplates: Templates
}
type State = {
    stateValues: Object
}

class TransferGuaranteeForm extends React.Component<Props, State> {
    static defaultProps = {
        initialValues: {}
    }
    constructor(props) {
        super(props)
        this.state = {
            stateValues: {
                ...guaranteeDefaultValues,
                ...partiesInvolvedDefaultValues,
                ...novationDefaultValues,
                ...props.initialValues
            }
        }
    }

    render() {
        const {
            onCancel,
            onSubmit,
            theme,
            currentUserInformation,
            issuers,
            termsAndConditions,
            purposeTemplates
        } = this.props
        const { stateValues } = this.state
        const classes = getClasses({ theme })
        return (
            <Formik
                initialValues={{
                    ...stateValues
                }}
                validate={values => ({
                    ...partiesInvolvedFieldSetValidate({
                        values,
                        amend: false,
                        transfer: true,
                        currentUserInformation
                    }),
                    ...novationFieldSetValidate({ values })
                })}
                onSubmit={(values, { setSubmitting, setErrors }) => {
                    setSubmitting(true)
                    // Assumes that on success component unmounts so no need to call setSubmitting
                    onSubmit(values)
                        .then(() => setSubmitting(false))
                        .catch(() => {
                            setSubmitting(false)
                        })
                }}
                render={formikProps => (
                    <form onSubmit={formikProps.handleSubmit}>
                        <LoadingDialog
                            open={formikProps.isSubmitting && !formikProps.isValidating && formikProps.isValid}
                            loading={formikProps.isSubmitting}
                            title="Submitting Bank Guarantee request..."
                        />
                        <Card className={classes.containerCard}>
                            <CardContent>
                                {currentUserInformation.actingOnBehalf &&
                                currentUserInformation.actingOnBehalf.relatedEntityName ? (
                                    <Typography className={classes.header}>
                                        Acting on behalf of {currentUserInformation.actingOnBehalf.relatedEntityName}.
                                        Transferring a Bank Guarantee
                                    </Typography>
                                ) : (
                                    <Typography className={classes.header}>
                                        {currentUserInformation.entityName} is Transferring a Bank Guarantee
                                    </Typography>
                                )}

                                <Divider />
                            </CardContent>

                            <CardContent>
                                <Typography className={classes.title}>Parties Involved</Typography>
                                <PartiesInvolvedFieldSet
                                    transfer
                                    formik={formikProps}
                                    issuers={issuers}
                                    currentUserInformation={currentUserInformation}
                                />
                            </CardContent>
                            <CardContent>
                                <MaterialGrid xl={9} lg={9}>
                                    <Typography className={classes.title}>Guarantee Purpose</Typography>
                                    <PurposeFieldSet
                                        fields={getCurrentTemplate({
                                            purposeTemplates,
                                            selectedTemplate: formikProps.values.purposeType
                                        })}
                                        purposeTemplates={purposeTemplates}
                                        formik={formikProps}
                                        disabled
                                    />
                                </MaterialGrid>
                            </CardContent>

                            <CardContent>
                                <Typography className={classes.title}>Guarantee Details</Typography>

                                <GuaranteeFieldSet
                                    transfer
                                    formik={formikProps}
                                    termsAndConditions={termsAndConditions}
                                />
                            </CardContent>
                            <CardActions className={classes.buttonContainer}>
                                <Button className={classes.button} onClick={onCancel}>
                                    Exit
                                </Button>
                                <Block flex="1" />
                                <Button className={classes.button} disabled={formikProps.isSubmitting} type="submit">
                                    Transfer Bank Guarantee
                                </Button>
                            </CardActions>
                        </Card>
                    </form>
                )}
            />
        )
    }
}

export default withTheme()(TransferGuaranteeForm)
