// @flow

import * as React from "react"
import { css } from "emotion"
import { withTheme } from "@material-ui/core/styles"
import Button from "@material-ui/core/Button"
import Card from "@material-ui/core/Card"
import CardContent from "@material-ui/core/CardContent"
import CardActions from "@material-ui/core/CardActions"
import Typography from "@material-ui/core/Typography"
import MaterialGrid from "@material-ui/core/Grid"
import { Formik } from "formik"
import Divider from "@material-ui/core/Divider"
import _ from "lodash"

import { Block, Flex } from "~/shared/layout"
import GuaranteeFieldSet, {
    validate as guaranteeDetailsFieldSetValidate
} from "~/shared/Fields/GuaranteeDetails/GuaranteeFieldSet"
import PartiesInvolvedFieldSet from "~/shared/Fields/PartiesInvolved/PartiesInvolvedFieldSet"
import PurposeFieldSet from "~/shared/Fields/PurposeFieldSet/PurposeFieldSet"
import type { Templates } from "~/shared/Fields/PurposeFieldSet/PurposeTypes"

import { guaranteeDefaultValues, partiesInvolvedDefaultValues } from "~/util/guarantee"
import LoadingDialog from "~/shared/Dialogs/LoadingDialog"
import difference from "~/util/helpers/difference"
import getCurrentTemplate from "~/util/helpers/getCurrentTemplate"

const getClasses = ({ theme }) => {
    const notFirstCard = css({
        marginTop: `${theme.spacing.unit * 2}px`
    })

    const title = css({ fontSize: theme.typography.fontSizeLarge })

    const error = css({
        color: "#FF0000",
        paddingLeft: `${theme.spacing.unit * 2}px`,
        fontSize: theme.commonFontSizes.medium
    })

    const adminTitle = css(title, {
        marginRight: theme.spacing.unit * 3
    })
    const footerText = css(theme.typography.footerText)
    const body1 = css(theme.typography.body1)

    const button = css(theme.typography.button)
    const buttonContainer = css({
        marginTop: theme.spacing.unit,
        marginBottom: theme.spacing.unit
    })
    const header = css({
        fontSize: theme.typography.fontSizeMedium
    })
    const containerCard = css({
        overflow: "visible"
    })

    return {
        notFirstCard,
        title,
        adminTitle,
        button,
        error,
        footerText,
        buttonContainer,
        body1,
        header,
        containerCard
    }
}

type Props = {
    initialValues: Object,
    onCancel: Function,
    onSubmit: Function,
    theme: Object,
    issuers: Array<any>,
    currentUserInformation: Object,
    onReject: Function,
    prefillRequest: boolean,
    termsAndConditions: Array<any>,
    purposeTemplates: Templates,
    fromPrefillContainer: boolean
}

const validateWholeFormForChanges = (values, initialValues, prefillRequest, fromPrefillContainer) => {
    // remove purpose and termsConditions from values because they are not
    // present in initialValues
    delete initialValues.termsConditions
    const valuesCopy = _.cloneDeep(values)
    delete valuesCopy.termsConditions
    delete valuesCopy.actOnBehalf

    const errors = {}
    // if not a prefill request, error if nothing has changed
    if (_.isEqual(valuesCopy, initialValues) && !prefillRequest && !fromPrefillContainer) {
        errors.unchangedForm = "No values changed"
    }
    return errors
}

const AmendGuaranteeForm = (props: Props) => {
    const {
        onCancel,
        onSubmit,
        initialValues,
        theme,
        onReject,
        prefillRequest,
        currentUserInformation,
        issuers,
        termsAndConditions,
        fromPrefillContainer,
        purposeTemplates
    } = props
    const classes = getClasses({ theme })
    return (
        <Formik
            initialValues={{
                ...guaranteeDefaultValues,
                ...partiesInvolvedDefaultValues,
                ...initialValues
            }}
            validate={values => ({
                ...guaranteeDetailsFieldSetValidate({
                    values,
                    gxLimit: currentUserInformation.gxLimit[currentUserInformation.currentOrgId]
                }),
                ...validateWholeFormForChanges(values, initialValues, prefillRequest, fromPrefillContainer)
            })}
            onSubmit={(values, { setSubmitting, setErrors }) => {
                setSubmitting(true)
                // Assumes that on success component unmounts so no need to call setSubmitting
                const originalValues = {
                    ...partiesInvolvedDefaultValues,
                    ...initialValues
                }
                const valuesDiff = difference(values, originalValues)
                onSubmit(valuesDiff, currentUserInformation.entityType)
                    .then(() => setSubmitting(false))
                    .catch(() => {
                        setSubmitting(false)
                    })
            }}
            render={formikProps => (
                <form onSubmit={formikProps.handleSubmit}>
                    <LoadingDialog
                        open={formikProps.isSubmitting && !formikProps.isValidating && formikProps.isValid}
                        loading={formikProps.isSubmitting}
                        title="Submitting Bank Guarantee request..."
                    />
                    <Card className={classes.containerCard}>
                        <CardContent>
                            {currentUserInformation.actingOnBehalf &&
                            currentUserInformation.actingOnBehalf.relatedEntityName ? (
                                <Typography className={classes.header}>
                                    Acting on behalf of {currentUserInformation.actingOnBehalf.relatedEntityName}.
                                    Amending a Bank Guarantee
                                </Typography>
                            ) : (
                                <Typography className={classes.header}>
                                    {currentUserInformation.entityName} is amending a Bank Guarantee
                                </Typography>
                            )}

                            <Divider />
                        </CardContent>
                        <CardContent>
                            <Typography className={classes.title}>Parties Involved</Typography>
                            <PartiesInvolvedFieldSet
                                disabled
                                amend
                                formik={formikProps}
                                issuers={issuers}
                                currentUserInformation={currentUserInformation}
                            />
                        </CardContent>
                        <CardContent>
                            <MaterialGrid xl={9} lg={9}>
                                <Typography className={classes.title}>Guarantee Purpose</Typography>
                                <PurposeFieldSet
                                    fields={getCurrentTemplate({
                                        purposeTemplates,
                                        selectedTemplate: formikProps.values.purposeType
                                    })}
                                    purposeTemplates={purposeTemplates}
                                    formik={formikProps}
                                    amend
                                />
                            </MaterialGrid>
                        </CardContent>
                        <CardContent>
                            <Typography className={classes.title}>Guarantee Details</Typography>
                            <GuaranteeFieldSet formik={formikProps} termsAndConditions={termsAndConditions} />
                        </CardContent>
                        <CardActions className={classes.buttonContainer}>
                            <Button className={classes.button} onClick={onCancel}>
                                Exit
                            </Button>
                            <Block flex="1" />
                            {prefillRequest ? (
                                <Button className={classes.button} onClick={onReject}>
                                    Reject amend request
                                </Button>
                            ) : null}
                            <Flex flexDirection="column">
                                <Button className={classes.button} disabled={formikProps.isSubmitting} type="submit">
                                    Amend Bank Guarantee
                                </Button>
                                {formikProps.errors.unchangedForm ? (
                                    <Typography className={classes.error}>
                                        {formikProps.errors.unchangedForm}
                                    </Typography>
                                ) : null}
                            </Flex>
                        </CardActions>
                    </Card>
                </form>
            )}
        />
    )
}

AmendGuaranteeForm.defaultProps = {
    initialValues: {},
    onReject: () => console.log("default value"),
    prefillRequest: false
}

export default withTheme()(AmendGuaranteeForm)
