export default function firstLetter(s) {
    return s.toLowerCase().replace(/^.{1}/g, s[0].toUpperCase())
}
