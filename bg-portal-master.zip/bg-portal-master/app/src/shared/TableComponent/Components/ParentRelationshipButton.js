// @flow
import * as React from "react"
import Tooltip from "@material-ui/core/Tooltip"
import Button from "@material-ui/core/Button"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import Typography from "@material-ui/core/Typography"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"

const getClasses = ({ theme }) => {
    const buttonStyle = css(theme.typography.button)
    const rejectButton = css(buttonStyle, { color: theme.palette.common.defaultRed })
    const approveButton = css(buttonStyle)

    return {
        buttonStyle,
        approveButton,
        rejectButton
    }
}

type Props = {
    rowId: number,
    approve: Function,
    reject: Function,
    theme: Object,
    disabled: boolean,
    row: Object
}
type State = {
    dialogOpen: boolean,
    dialogTitle: string,
    dialogMessage: string,
    action: Function
}

class ApproveRejectButton extends React.Component<Props, State> {
    static defaultProps = {
        disabled: false
    }
    constructor(props: Props) {
        super(props)
        this.state = {
            dialogOpen: false,
            dialogTitle: "Reject Link",
            dialogMessage: "Are you sure you want to Reject the link to this organisation?",
            action: () => console.log()
        }
    }
    closeDialog = () => {
        this.setState({ dialogOpen: false })
    }
    openDialog = (rowId: number, dialogTitle: string, dialogMessage: string, action: Function) =>
        this.setState({ dialogOpen: true, dialogTitle, dialogMessage, action })

    linkTypeText = (type: string) => (type === "LINK_PENDING" ? "Link Request " : "Unlink Request")
    render() {
        const { rowId, theme, disabled, reject, approve, row } = this.props
        const { dialogOpen, dialogTitle, dialogMessage, action } = this.state
        const classes = getClasses({ theme })
        return (
            <React.Fragment>
                <CustomRequestDialog
                    renderTitle={() => dialogTitle}
                    renderContent={() => <Typography>{dialogMessage}</Typography>}
                    onSubmit={e => {
                        e.preventDefault()
                        e.stopPropagation()
                        action(row)
                    }}
                    handleClose={e => {
                        e.preventDefault()
                        e.stopPropagation()
                        this.closeDialog()
                    }}
                    open={dialogOpen}
                    submitText="Yes"
                    cancelText="No"
                />
                <Tooltip title="Reject Relationship" disableFocusListener>
                    <Button
                        className={classes.rejectButton}
                        onClick={e => {
                            e.preventDefault()
                            e.stopPropagation()
                            this.openDialog(
                                rowId,
                                `Reject ${this.linkTypeText(row.status)}`,
                                `Are you sure you want to Reject the ${this.linkTypeText(
                                    row.status
                                )} to this organisation?`,
                                reject
                            )
                        }}
                        disabled={disabled}
                    >
                        Reject
                    </Button>
                </Tooltip>
                <Tooltip title="Approve Relationship" disableFocusListener>
                    <Button
                        className={classes.approveButton}
                        onClick={e => {
                            e.preventDefault()
                            e.stopPropagation()
                            this.openDialog(
                                rowId,
                                `Approve ${this.linkTypeText(row.status)}`,
                                `Are you sure you want to Approve the ${this.linkTypeText(
                                    row.status
                                )} to this organisation?`,
                                approve
                            )
                        }}
                        disabled={disabled}
                    >
                        Approve
                    </Button>
                </Tooltip>
            </React.Fragment>
        )
    }
}

export default withTheme()(ApproveRejectButton)
