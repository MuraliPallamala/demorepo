// @flow
import * as React from "react"
import Tooltip from "@material-ui/core/Tooltip"
import IconButton from "@material-ui/core/IconButton"
import Button from "@material-ui/core/Button"
import EditIcon from "@material-ui/icons/Edit"
import BlockIcon from "@material-ui/icons/Block"
import DeleteIcon from "@material-ui/icons/Delete"
import Typography from "@material-ui/core/Typography"
import UnblockIcon from "@material-ui/icons/LockOpen"
import { withTheme } from "@material-ui/core/styles"
import { css } from "emotion"
import CustomRequestDialog from "~/shared/Dialogs/CustomRequestDialog"
import generateKey from "~/util/helpers/generateKey"

const getClasses = ({ theme }) => {
    const tableRow = css({
        cursor: "pointer",
        textTransform: "capitalize",
        "&:hover": {
            backgroundColor: theme.palette.common.buttonHover
        }
    })
    const buttonStyle = css(theme.typography.button)

    const table = css({
        boxShadow: "none"
    })

    const deleteIcons = css({
        color: theme.palette.common.defaultRed
    })
    const editIcon = css({
        color: theme.palette.common.lightBlue
    })
    const revokeButton = css(theme.typography.button, { color: theme.palette.common.defaultRed })

    return {
        tableRow,
        table,
        buttonStyle,
        deleteIcons,
        editIcon,
        revokeButton
    }
}

type Props = {
    rowId: number,
    changeEditingRowIds: Function,
    theme: Object,
    otherAction: Function,
    disabled?: boolean,
    openDialog: Function,
    actionButtons: Array<string>,
    editTooltip: string,
    deleteTooltip: string,
    blockTooltip: string
}

type State = {
    dialogOpen: boolean,
    dialogTitle: string,
    dialogMessage: string
}

class ActionButtons extends React.Component<Props, State> {
    static defaultProps = {
        editTooltip: "Edit a user",
        deleteTooltip: "Remove a user",
        blockTooltip: "Block a user",
        disabled: false,
        otherAction: () => null,
        openDialog: () => null,
        changeEditingRowIds: () => null,

        rowId: 0
    }
    constructor(props: Props) {
        super(props)
        this.state = {
            dialogOpen: false,
            dialogTitle: "Block User",
            dialogMessage: "Are you sure you want to block this user?"
        }
    }
    onSubmit = e => {
        e.preventDefault()
        e.stopPropagation()
        this.props.otherAction(this.props.rowId).then(() => this.closeDialog())
    }
    closeDialog = () => {
        this.setState({ dialogOpen: false })
    }
    dialogOpen = (rowId: number, dialogTitle: string, dialogMessage: string) =>
        this.setState({ dialogOpen: true, dialogTitle, dialogMessage })

    render() {
        const {
            rowId,
            changeEditingRowIds,
            theme,
            disabled,
            openDialog,
            actionButtons,
            editTooltip,
            blockTooltip,
            deleteTooltip
        } = this.props
        const { dialogOpen } = this.state
        const classes = getClasses({ theme })
        return (
            <React.Fragment>
                {actionButtons.map(item => (
                    <React.Fragment key={generateKey(item)}>
                        {item === "edit" && (
                            <Tooltip title={editTooltip} enterDelay={300} leaveDelay={200} disableFocusListener>
                                <IconButton
                                    className={classes.editIcon}
                                    onClick={e => {
                                        e.preventDefault()
                                        e.stopPropagation()
                                        changeEditingRowIds([rowId])
                                    }}
                                    disabled={disabled}
                                >
                                    <EditIcon />
                                </IconButton>
                            </Tooltip>
                        )}
                        {item === "block" && (
                            <Tooltip title={blockTooltip} enterDelay={300} leaveDelay={200} disableFocusListener>
                                <IconButton
                                    className={classes.deleteIcons}
                                    onClick={e => {
                                        e.preventDefault()
                                        e.stopPropagation()
                                        this.dialogOpen(
                                            rowId,
                                            "Block User",
                                            "Are you sure you want to block this user?"
                                        )
                                    }}
                                    disabled={disabled}
                                >
                                    <BlockIcon />
                                </IconButton>
                            </Tooltip>
                        )}
                        {item === "delete" && (
                            <Tooltip title={deleteTooltip} enterDelay={300} leaveDelay={200} disableFocusListener>
                                <IconButton
                                    className={classes.deleteIcons}
                                    onClick={e => {
                                        e.preventDefault()
                                        e.stopPropagation()
                                        openDialog(rowId)
                                    }}
                                    disabled={disabled}
                                >
                                    <DeleteIcon />
                                </IconButton>
                            </Tooltip>
                        )}
                        {item === "unblock" && (
                            <Tooltip title="Unblock a user" enterDelay={300} leaveDelay={200} disableFocusListener>
                                <IconButton
                                    className={classes.deleteIcons}
                                    onClick={e => {
                                        e.preventDefault()
                                        e.stopPropagation()
                                        this.dialogOpen(
                                            rowId,
                                            "Unblock User",
                                            "Are you sure you want to unblock this user?"
                                        )
                                    }}
                                    disabled={disabled}
                                >
                                    <UnblockIcon />
                                </IconButton>
                            </Tooltip>
                        )}
                        {item === "revoke" && (
                            <Tooltip
                                title="Remove a relationship"
                                enterDelay={300}
                                leaveDelay={200}
                                disableFocusListener
                            >
                                <Button
                                    onClick={e => {
                                        e.preventDefault()
                                        e.stopPropagation()
                                        this.dialogOpen(
                                            rowId,
                                            "Revoke Relationship",
                                            "Are you sure you want to Revoke this relationship?"
                                        )
                                    }}
                                    disabled={disabled}
                                    className={classes.revokeButton}
                                >
                                    Revoke
                                </Button>
                            </Tooltip>
                        )}
                    </React.Fragment>
                ))}
                <CustomRequestDialog
                    renderTitle={() => this.state.dialogTitle}
                    renderContent={() => <Typography>{this.state.dialogMessage}</Typography>}
                    onSubmit={this.onSubmit}
                    handleClose={this.closeDialog}
                    open={dialogOpen}
                    submitText="Yes"
                    cancelText="No"
                />
            </React.Fragment>
        )
    }
}

export default withTheme()(ActionButtons)
