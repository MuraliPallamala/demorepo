// @flow
import * as React from "react"
import Block from "./Block"
import Flex from "./Flex"
import Grid from "./Grid"

const Row = (props: {}) => <Flex flexDirection="row" {...props} />
const Col = (props: {}) => <Flex flexDirection="column" {...props} />
const ReversedRow = (props: {}) => <Flex flexDirection="row-reverse" {...props} />
const ReversedCol = (props: {}) => <Flex flexDirection="column-reverse" {...props} />
const CenteredRow = (props: {}) => <Row alignItems="center" justifyContent="center" {...props} />
const CenteredCol = (props: {}) => <Col alignItems="center" {...props} />
const WrappedRow = (props: {}) => <Row flexWrap="wrap" {...props} />
const WrappedCol = (props: {}) => <Col flexWrap="wrap" {...props} />

export { Block, Flex, Grid, Row, Col, ReversedRow, ReversedCol, CenteredRow, CenteredCol, WrappedRow, WrappedCol }
