// @flow
import styled from "react-emotion"
import { createReplaceUn } from "~/util/ui/unit"

type Props = {
    theme: Object,
    inline?: string,
    gridArea?: string,
    flex?: string | number,
    flexDirection?: string,
    flexFlow?: string,
    flexWrap?: string,
    justifyContent?: string,
    alignItems?: string,
    padding?: string | number,
    paddingTop?: string | number,
    paddingRight?: string | number,
    paddingBottom?: string | number,
    paddingLeft?: string | number,
    margin?: string | number,
    marginTop?: string | number,
    marginRight?: string | number,
    marginBottom?: string | number,
    marginLeft?: string | number,
    height?: string | number,
    maxHeight?: string | number,
    minHeight?: string | number,
    width?: string | number,
    maxWidth?: string | number,
    minWidth?: string | number
}

const Flex = styled("div")(
    ({
        theme,
        inline,
        gridArea,
        flex,
        flexDirection,
        flexFlow,
        flexWrap,
        alignItems,
        justifyContent,
        padding,
        paddingTop,
        paddingRight,
        paddingBottom,
        paddingLeft,
        margin,
        marginTop,
        marginRight,
        marginBottom,
        marginLeft,
        height,
        maxHeight,
        minHeight,
        width,
        maxWidth,
        minWidth
    }: Props) => {
        const replaceUn = createReplaceUn(theme.spacing.unit)

        return {
            display: inline ? "inline-flex" : "flex",
            gridArea: replaceUn(gridArea),
            flex: replaceUn(flex),
            flexDirection,
            flexFlow,
            flexWrap,
            justifyContent,
            alignItems,
            padding: replaceUn(padding),
            paddingTop: replaceUn(paddingTop),
            paddingRight: replaceUn(paddingRight),
            paddingBottom: replaceUn(paddingBottom),
            paddingLeft: replaceUn(paddingLeft),
            margin: replaceUn(margin),
            marginTop: replaceUn(marginTop),
            marginRight: replaceUn(marginRight),
            marginBottom: replaceUn(marginBottom),
            marginLeft: replaceUn(marginLeft),
            height: replaceUn(height),
            maxHeight: replaceUn(maxHeight),
            minHeight: replaceUn(minHeight),
            width: replaceUn(width),
            maxWidth: replaceUn(maxWidth),
            minWidth: replaceUn(minWidth)
        }
    }
)

export default Flex
