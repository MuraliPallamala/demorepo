package com.ibm.au.bgx.export.pdf;

import com.ibm.au.bgx.export.pdf.exception.PDFExportException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.gx.Gx;

import org.apache.commons.io.FileUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import static com.ibm.au.bgx.export.pdf.Utils.getFile;
import static com.ibm.au.bgx.export.pdf.Utils.readJson;

public class SampleGxExportCreator {
    private static final String GX_PDF_FORM_FIXTURE = "fixtures/templates/gx_electronic_template.pdf";
    private static final String GX_JSON_FIXTURE = "fixtures/json/gx.json",
            BENEFICIARY_JSON_FIXTURE = "fixtures/json/beneficiary.json",
            ISSUER_JSON_FIXTURE = "fixtures/json/issuer.json",
            APPLICANT_JSON_FIXTURE = "fixtures/json/applicant.json";

    public static void main(String... args) throws IOException, PDFExportException {
        if (args.length != 1) {
            throw new IllegalArgumentException("Usage: SampleGxExportCreator <sample output file path>");
        }
        Gx gx = readJson(getFile(GX_JSON_FIXTURE), Gx.class);
        OrgProfile issuer = readJson(getFile(ISSUER_JSON_FIXTURE), OrgProfile.class);
        OrgProfile beneficiary = readJson(getFile(BENEFICIARY_JSON_FIXTURE), OrgProfile.class);
        OrgProfile applicant = readJson(getFile(APPLICANT_JSON_FIXTURE), OrgProfile.class);

        GxPDFExporter gxPDFExporter = new GxPDFExporter();
        // TODO: to run this, the GxPDFExporter will require a purpose format manager wired to the component as it resolves the pdf template file

        try (ByteArrayOutputStream byteArrayPDF = new ByteArrayOutputStream()) {
            gxPDFExporter.export(gx, issuer, beneficiary, applicant, byteArrayPDF);
            FileUtils.writeByteArrayToFile(new File(args[0]), byteArrayPDF.toByteArray());
            System.out.printf("Sample PDF Output to: %s", args[0]);
        }
    }
}
