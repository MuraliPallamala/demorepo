package com.ibm.au.bgx.export.pdf;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Utils {
  public static File getFile(String fileName) {
    return new File(Utils.class.getClassLoader().getResource(fileName).getFile());
  }

  public static Map<String, String> readPDFForm(File testPDF) throws IOException {
    PDDocument doc = PDDocument.load(testPDF);
    PDAcroForm form = doc.getDocumentCatalog().getAcroForm();
    Map<String, String> formValues = new HashMap<>();
    for (PDField field : form.getFields()) {
      formValues.put(field.getFullyQualifiedName(), field.getValueAsString());
    }
    doc.close();
    return formValues;
  }

  public static <T> T readJson(File jsonFile, Class<T> cls) throws IOException {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    return mapper.readValue(jsonFile, cls);
  }
}
