package com.ibm.au.bgx.export.pdf;

import com.ibm.au.bgx.export.pdf.exception.InvalidPDFFormatException;
import com.ibm.au.bgx.export.pdf.exception.PDFExportException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.ibm.au.bgx.export.pdf.Utils.getFile;
import static com.ibm.au.bgx.export.pdf.Utils.readPDFForm;
import static org.junit.Assert.assertEquals;

public class PDFExporterTest {
  private static final String BASIC_PDF_FORM_FIXTURE = "fixtures/templates/basic_pdf_form.pdf";
  private static final String PDF_WITHOUT_FORM_FIXTURE = "fixtures/templates/pdf_without_form.pdf";
  @Rule public TemporaryFolder tempFolder = new TemporaryFolder();
  private File pdfTemplate;
  private PDFExporter exporter;

  @Before
  public void setupFixtures() {
    pdfTemplate = getFile(BASIC_PDF_FORM_FIXTURE);
    exporter = new PDFExporter();
  }

  @Test
  public void testFormValuesAreCorrectlySet() throws IOException, PDFExportException {
    File tempPDF = tempFolder.newFile();
    try (FileOutputStream fileStream = new FileOutputStream(tempPDF)) {
      Map<String, String> expectedValues = new HashMap<>();
      expectedValues.put("field1", "some_value1");
      expectedValues.put("field2", "some_value2");

      exporter.export(pdfTemplate, expectedValues, fileStream);

      Map<String, String> persistedValues = readPDFForm(tempPDF);
      assertEquals(expectedValues, persistedValues);
    }
  }

  @Test
  public void testPreservationOfDefaultFormValues() throws IOException, PDFExportException {
    PDFExporter exporter = new PDFExporter();
    File tempPDF = tempFolder.newFile();
    try (FileOutputStream fileStream = new FileOutputStream(tempPDF)) {
      Map<String, String> expectedValues = new HashMap<>();
      String expectedDefaultValue = "Some Default Value";
      exporter.export(pdfTemplate, expectedValues, fileStream);

      Map<String, String> persistedValues = readPDFForm(tempPDF);
      assertEquals(expectedDefaultValue, persistedValues.get("field2"));
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFailsOnNullFormValueMapArg() throws PDFExportException, IOException {
    PDFExporter exporter = new PDFExporter();
    exporter.export(pdfTemplate, null, null);
  }

  @Test(expected = InvalidPDFFormatException.class)
  public void testFailsForPDFWithNoForm() throws PDFExportException, IOException {
    PDFExporter exporter = new PDFExporter();
    try (FileOutputStream fileStream = new FileOutputStream(tempFolder.newFile())) {
      exporter.export(getFile(PDF_WITHOUT_FORM_FIXTURE), new HashMap<>(), fileStream);
    }
  }

  @Test(expected = FileNotFoundException.class)
  public void testFailsIfPDFTemplateDoesNotExist() throws IOException, PDFExportException {
    PDFExporter exporter = new PDFExporter();
    try (FileOutputStream fileStream = new FileOutputStream(tempFolder.newFile())) {
      exporter.export(getFile(""), new HashMap<>(), fileStream);
    }
  }
}
