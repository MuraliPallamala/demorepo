package com.ibm.au.bgx.export.pdf;

import com.ibm.au.bgx.export.pdf.exception.PDFExportException;
import com.ibm.au.bgx.model.api.exceptions.ApiException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.purpose.NewPurposeFormat;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;
import com.ibm.au.bgx.model.purpose.PurposeFormatManager;
import com.ibm.au.bgx.purpose.PurposeFormatManagerMock;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

import static com.ibm.au.bgx.export.pdf.Utils.getFile;
import static com.ibm.au.bgx.export.pdf.Utils.readJson;
import static com.ibm.au.bgx.export.pdf.Utils.readPDFForm;
import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
        PurposeFormatManagerMock.class,
})
public class GxPDFExporterTest {

    private static final String GX_PDF_FORM_FIXTURE = "fixtures/templates/gx_electronic_template.pdf";
    private static final String GX_JSON_FIXTURE = "fixtures/json/gx.json",
            GX_OPEN_JSON_FIXTURE = "fixtures/json/gx_open_ended.json",
            BENEFICIARY_JSON_FIXTURE = "fixtures/json/beneficiary.json",
            ISSUER_JSON_FIXTURE = "fixtures/json/issuer.json",
            APPLICANT_JSON_FIXTURE = "fixtures/json/applicant.json",
            PURPOSE_FORMAT_JSON_FIXTURE = "fixtures/json/pdftest-purposeformat.json";
    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();
    @Autowired
    PurposeFormatManager purposeFormatManager;
    private Gx guarantee, openGuarantee;
    private OrgProfile issuer, beneficiary, applicant;
    private GxPDFExporter exporter;
    private File pdfTemplate;
    private PurposeFormat purposeFormat;

    @Before
    public void setupFixtures() throws IOException {
        this.guarantee = readJson(getFile(GX_JSON_FIXTURE), Gx.class);
        this.openGuarantee = readJson(getFile(GX_OPEN_JSON_FIXTURE), Gx.class);
        this.issuer = readJson(getFile(ISSUER_JSON_FIXTURE), OrgProfile.class);
        this.beneficiary = readJson(getFile(BENEFICIARY_JSON_FIXTURE), OrgProfile.class);
        this.applicant = readJson(getFile(APPLICANT_JSON_FIXTURE), OrgProfile.class);
        try {
            this.purposeFormat = purposeFormatManager.create(readJson(getFile(PURPOSE_FORMAT_JSON_FIXTURE), NewPurposeFormat.class));
        } catch (ApiException apiEx) {
            Assert.assertFalse(true);
        }
        this.guarantee.setPurposeType(this.purposeFormat.getId());
        this.openGuarantee.setPurposeType(this.purposeFormat.getId());

        pdfTemplate = getFile(GX_PDF_FORM_FIXTURE);
        // TODO: this is a hack, should be autowired, but T&C manager mock is missing
        exporter = new GxPDFExporter();
        exporter.purposeFormatManager = this.purposeFormatManager;
    }

    @Test
    public void testExportOfAllGxDetails() throws IOException, PDFExportException {
        exportAndAssert(guarantee);
    }

    @Test
    public void testExportOfOpenEndedGxDetails() throws IOException, PDFExportException {
        exportAndAssert(openGuarantee);
    }

    private void exportAndAssert(Gx gx) throws IOException, PDFExportException {
        Map<String, String> expectedValues =
                exporter.extractFieldsForForm(gx, issuer, beneficiary, applicant);
        // status field uses current time so would not be deterministic between calls to
        // extractFieldsForForm and export
        expectedValues.remove(GxPDFExporter.FormField.GX_STATUS);
        File tempPDF = tempFolder.newFile();
        try (FileOutputStream exportedPDFStream = new FileOutputStream(tempPDF)) {
            exporter.export(pdfTemplate, exporter.extractFieldsForForm(gx, issuer, beneficiary, applicant), exportedPDFStream);
            assertPDFFormValues(tempPDF, expectedValues);
        }
    }

    private void assertPDFFormValues(File gxPDF, Map<String, String> expectedValues)
            throws IOException {
        Map<String, String> persistedValues = readPDFForm(gxPDF);
        for (Map.Entry<String, String> expected : expectedValues.entrySet()) {
            assertEquals(expected.getKey(), persistedValues.get(expected.getKey()), expected.getValue());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFailIfOrgParamsDontMatchGxOrgs() throws IOException, PDFExportException {
        beneficiary.setId("some-other-id");
        try (FileOutputStream fileStream = new FileOutputStream(tempFolder.newFile())) {
            exporter.export(pdfTemplate, exporter.extractFieldsForForm(guarantee, issuer, beneficiary, applicant), fileStream);
        }
    }
}
