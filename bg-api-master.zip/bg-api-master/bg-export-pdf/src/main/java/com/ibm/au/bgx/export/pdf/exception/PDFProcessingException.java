package com.ibm.au.bgx.export.pdf.exception;

public class PDFProcessingException extends PDFExportException {
  public PDFProcessingException(String s) {
    super(s);
  }
}
