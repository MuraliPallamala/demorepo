package com.ibm.au.bgx.export.pdf.exception;

import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;

public class InvalidPDFCredentialsException extends PDFExportException {
  public InvalidPDFCredentialsException(InvalidPasswordException e) {
    super(e);
  }
}
