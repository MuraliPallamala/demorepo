package com.ibm.au.bgx.export.pdf;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.util.TimeZoneUtil;
import com.ibm.au.bgx.export.pdf.exception.PDFExportException;
import com.ibm.au.bgx.model.api.NewCoTermsAndCondClient;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.PostalAddress;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAmount;
import com.ibm.au.bgx.model.pojo.gx.GxStatusType;
import com.ibm.au.bgx.model.pojo.purpose.PurposeField;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;
import com.ibm.au.bgx.model.pojo.tc.TcExternalContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCondContent.Type;
import com.ibm.au.bgx.model.purpose.PurposeFormatManager;
import com.ibm.au.bgx.model.util.JacksonUtil;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.xerces.impl.dv.util.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.text.MaskFormatter;

/**
 * Exports the details of a Bank Guarantee to a PDF using a specified PDF template.
 *
 * <p>The class extracts key details of a Bank Guarantee for export into a PDF, based on a provided
 * PDF template. The class first extracts the key attributes of a guarantee to a {@code Map<String,
 * String} {@link #extractFieldsForForm(Gx, OrgProfile, OrgProfile, OrgProfile)} wherein keys of the
 * map represent the specific gx field and are defined in the constants in {@link FormField}. These
 * key names need to correspond to the form field names in the provided PDF template, as explained
 * in {@link PDFExporter}
 *
 * @see PDFExporter
 */
@Component
public class GxPDFExporter extends PDFExporter {

    /**
     * Specifies the timezone to use when reporting date attributes of a Bank Guarantee (i.e. {@link
     * Gx#getExpiresAt()}. The default is currently Australia/Sydney.
     */
    private static final String ABN_MASK = "### ### ###";
    private static final String ACN_MASK = "## ### ### ###";
    private static final int ABN_ID_SIZE = 9;
    private static final String OPEN_GX_VALUE = "Open Guarantee";
    private static final Logger LOGGER = LoggerFactory.getLogger(GxPDFExporter.class);
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    private static final String PURPOSE_PDF_TEMPLATE_KEY_PREFIX = "purpose_";

    @Autowired
    protected TermsAndCondManager termsAndCondManager;

    @Autowired
    protected PurposeFormatManager purposeFormatManager;

    @Autowired
    private NewCoTermsAndCondClient newCoTermsAndCondClient;

    @Value("${gx.template.pdf:../static/guarantees}")
    private String pdfTemplateFolder;


    /**
     * Extracts key attributes of a Bank Guarantee (see list in {@link FormField}) as a Map<String,
     * String>, which is to be used when exporting {@link #export(Gx, OrgProfile, OrgProfile,
     * OrgProfile, OutputStream)} a {@link Gx}
     *
     * @param gx          Bank Guarantee to extract details of
     * @param issuer      Organisation details of the issuer of the Gx
     * @param beneficiary Organisation details of the beneficiary of the Gx
     * @param applicant   Organisation details of the application of a {@code Gx}
     * @return A map containing the key attributes of a Gx (see list in {@link FormField}). Where
     * keys represent the name of the field as defined in {@link FormField}, and the corresponding
     * value are extracted from the provided {@code gx}, {@code issuer}, {@code beneficiary} and
     * {@code applicant}.
     * @throws IllegalArgumentException if the ids of the issuer {@link Gx#getIssuer()}, beneficiary
     *                                  {@link Gx#getBeneficiaries()} or applicant {@link
     *                                  Gx#getApplicants()} specified in the Gx does not match the
     *                                  {@code issuer}, {@code beneficiary} or {@code applicant}
     *                                  specified as argument
     * @see FormField lists the specific field names for Gx attribtues which correspond to keys in
     * the Map<String, String> of fields returned
     */
    protected Map<String, String> extractFieldsForForm(
            Gx gx, OrgProfile issuer, OrgProfile beneficiary, OrgProfile applicant) {

        checkOrgDetailsMatch(gx, issuer, beneficiary, applicant);
        Map<String, String> fields = new HashMap<>();

        populateGxDetails(fields, gx);
        populateBeneficiaryDetails(fields, beneficiary);
        populateIssuerDetails(fields, issuer);
        populateApplicantDetails(fields, applicant);

        return fields;
    }

    private void populateGxDetails(Map<String, String> formFields, Gx gx) {

        PurposeFormat purposeFormat = purposeFormatManager.get(gx.getPurposeType());

        formFields.put(FormField.GX_ID, gx.getId());
        formFields.put(FormField.GX_TYPE, purposeFormat.getLabel());
        formFields.put(FormField.GX_AMOUNT, formatAmount(gx.getAmount()));
        formFields.put(FormField.GX_STATUS, formatStatus(gx.getStatus()));
        formFields.put(FormField.GX_ISSUE_DATE, TimeZoneUtil.formatDateTimeDefault(gx.getIssuedAt()));
        formFields.put(FormField.GX_BANK_REF_NUMBER, gx.getBankReference());
        String expiry = hasExpiryDate(gx) ? TimeZoneUtil.formatDateTimeDefault(gx.getExpiresAt()) : OPEN_GX_VALUE;
        formFields.put(FormField.GX_EXPIRY_DATE, expiry);

        this.populateGxPurpose(formFields, gx.getPurpose(), PURPOSE_PDF_TEMPLATE_KEY_PREFIX, purposeFormat.getFields());
    }

    private void populateGxPurpose(Map<String, String> formFields, Map<String, Object> purpose, String keyPrefix, List<PurposeField> fields) {
        // fall back to empty map
        if (purpose == null) {
            purpose = new HashMap<>();
        }
        for (PurposeField field : fields) {
            String value = "";
            String key = keyPrefix + field.getName();
            if (field.getType().equals(PurposeField.Type.OBJECT)) {
                this.populateGxPurpose(formFields, (Map<String, Object>) purpose.get(field.getName()), key + "_", field.getSubFields());
                continue;
            } else if (purpose.containsKey(field.getName())) {
                if (field.getType().equals(PurposeField.Type.STRING) || field.getType().equals(PurposeField.Type.TEXT)) {
                    // stored as string
                    value = (String) purpose.get(field.getName());
                } else if (field.getType().equals(PurposeField.Type.NUMBER)) {
                    // differentiate between double / int
                    if (purpose.get(field.getName()) instanceof Double) {
                        value = Double.toString((Double) purpose.get(field.getName()));
                    } else if (purpose.get(field.getName()) instanceof Integer) {
                        value = Integer.toString((Integer) purpose.get(field.getName()));
                    }
                } else if (field.getType().equals(PurposeField.Type.BOOLEAN)) {
                    if ((Boolean) purpose.get(field.getName())) {
                        value = "Yes";
                    } else {
                        value = "No";
                    }
                } else if (field.getType().equals(PurposeField.Type.DATE)) {
                    // internally handled as String
                    value = (String) purpose.get(field.getName());
                }
            }

            formFields.put(key, value);
        }
    }

    private boolean hasExpiryDate(Gx b) {
        return b.getExpiresAt() != null;
    }

    private String formatStatus(GxStatusType status) {
        return String.format("%s as at %s", status.value(), TimeZoneUtil.formatDateTimeDefault(Instant.now()));
    }

    private String formatAmount(GxAmount amount) {
        return String.format(
                "%s %,.2f", amount.getCurrency().value(), amount.getOutstanding().longValue() / 100.0);
    }

    private void populateApplicantDetails(Map<String, String> formFields, OrgProfile applicant) {
        formFields.put(FormField.APPLICANT_NAME, applicant.getEntityName());
        formFields.put(FormField.APPLICANT_BID, formatBusinessId(applicant.getBusinessId()));
        formFields.put(FormField.APPLICANT_ADDRESS, formatAddress(applicant.getEntityAddress()));
    }

    private void populateIssuerDetails(Map<String, String> formFields, OrgProfile issuer) {
        formFields.put(FormField.ISSUER_NAME, issuer.getEntityName());
        formFields.put(FormField.ISSUER_BID, formatBusinessId(issuer.getBusinessId()));
        formFields.put(FormField.ISSUER_ADDRESS, formatAddress(issuer.getEntityAddress()));
    }

    private void populateBeneficiaryDetails(Map<String, String> formFields, OrgProfile beneficiary) {
        formFields.put(FormField.BENEFICIARY_NAME, beneficiary.getEntityName());
        formFields.put(FormField.BENEFICIARY_BID, formatBusinessId(beneficiary.getBusinessId()));
        formFields.put(FormField.BENEFICIARY_ADDRESS, formatAddress(beneficiary.getEntityAddress()));
    }

    private String formatBusinessId(String bId) {
        // TODO: optimise the use of this MaskFormatter without compromising thread safety
        MaskFormatter bIDFormatter = new MaskFormatter();
        bIDFormatter.setValueContainsLiteralCharacters(false);
        try {
            String mask = isABN(bId) ? ABN_MASK : ACN_MASK;
            bIDFormatter.setMask(mask);
            return bIDFormatter.valueToString(bId);
        } catch (ParseException e) {
            LOGGER.error(
                    "Error formatting business ID '{}', defaulting to displaying unformatted ID", bId, e);
        }
        return bId;
    }

    private boolean isABN(String bId) {
        return bId.length() == ABN_ID_SIZE;
    }

    private String formatAddress(PostalAddress address) {
        return String.format(
                "%s%n%s %s, %s %s",
                address.getStreetAddress(),
                address.getAddressLocality(),
                address.getPostalCode(),
                address.getAddressRegion(),
                address.getAddressCountry());
    }

    private void checkOrgDetailsMatch(
            Gx gx, OrgProfile issuer, OrgProfile beneficiary, OrgProfile applicant) {
        final String msg = "Provided %s ID '%s', does not match ID in Bank Guarantee '%s'";
        String gxApplicant = gx.getApplicants().get(0);
        String gxBeneficiary = gx.getBeneficiaries().get(0);

        if (!gx.getIssuer().equals(issuer.getId()))
            throw new IllegalArgumentException(
                    String.format(msg, "issuer", issuer.getId(), gx.getIssuer()));
        if (!gxApplicant.equals(applicant.getId()))
            throw new IllegalArgumentException(
                    String.format(msg, "applicant", applicant.getId(), gxApplicant));
        if (!gxBeneficiary.equals(beneficiary.getId()))
            throw new IllegalArgumentException(
                    String.format(msg, "beneficiary", beneficiary.getId(), gxBeneficiary));
    }

    private File getPdfTemplate(Gx gx) throws IOException {
        PurposeFormat format = purposeFormatManager.get(gx.getPurposeType());
        if (format == null || format.getPdfTemplateId() == null) {
            throw new IOException(String.format("Could not retrieve purpose format %s for Gx %s", gx.getPurposeType(), gx.getId()));
        }

        File pdfTemplate = new File(pdfTemplateFolder, format.getPdfTemplateId());
        if (!pdfTemplate.isFile()) {
            LOGGER.error("Could not find PDF template {} in folder {}", format.getPdfTemplateId(), pdfTemplateFolder);
            throw new IOException("Could not find PDF template to export guarantee.");
        }
        return pdfTemplate;
    }

    /**
     * Extracts key attributes of a Bank Guarantee and exports it to a PDF based on a provided PDF
     * template.
     *
     * @param gx           Bank Guarantee to export
     * @param issuer       Organisation details of the issuer of the Gx
     * @param beneficiary  Organisation details of the beneficiary of the Gx
     * @param applicant    Organisation details of the application of a {@code Gx}
     * @param outputStream The output stream to write the exported PDF to
     * @throws PDFExportException If errors occur processing the provided template, or creating an
     *                            exported PDF.
     * @throws IOException        If IO errors occur reading the specified provided template file or
     *                            creating the exported PDF stream.
     * @see PDFExporter#export(File, Map, OutputStream)
     */
    public void export(
            Gx gx,
            OrgProfile issuer,
            OrgProfile beneficiary,
            OrgProfile applicant,
            OutputStream outputStream)
            throws PDFExportException, IOException {
        export(this.getPdfTemplate(gx), extractFieldsForForm(gx, issuer, beneficiary, applicant), outputStream);
    }


    /**
     * Extracts key attributes of a Bank Guarantee and exports it to a PDF based on a provided PDF
     * template. It appends the Terms and Conditions of the Bank Guarantees to the PDF
     *
     * @param gx           Bank Guarantee to export
     * @param issuer       Organisation details of the issuer of the Gx
     * @param beneficiary  Organisation details of the beneficiary of the Gx
     * @param applicant    Organisation details of the application of a {@code Gx}
     * @param outputStream The output stream to write the exported PDF to
     * @throws PDFExportException If errors occur processing the provided template, or creating an
     *                            exported PDF.
     * @throws IOException        If IO errors occur reading the specified provided template file or
     *                            creating the exported PDF stream.
     * @see PDFExporter#export(File, Map, OutputStream)
     */
    public void exportWithTC(
            Gx gx,
            OrgProfile issuer,
            OrgProfile beneficiary,
            OrgProfile applicant,
            OutputStream outputStream)
            throws PDFExportException, IOException {

        // create merger utility
        PDFMergerUtility mergerUtility = new PDFMergerUtility();

        // Add GX Pdf
        ByteArrayOutputStream gxStream = new ByteArrayOutputStream();
        export(this.getPdfTemplate(gx), extractFieldsForForm(gx, issuer, beneficiary, applicant), gxStream);
        mergerUtility.addSource(new ByteArrayInputStream(gxStream.toByteArray()));

        // Retrieve TC
        TermsAndCond tc;

        try {
            tc = termsAndCondManager.getById(gx.getTcId());
        } catch (ProfileChainException e) {
            throw new IOException(String.format("Could not retrieve TC %s", gx.getTcId()), e);
        }

        // Only support EXTERNAL terms and conditions
        if (!Type.EXTERNAL.equals(tc.getContent().getType())) {
            throw new IllegalArgumentException("Cannot export guarantee with non-external Terms and Conditions");
        }

        TcExternalContent tec = MAPPER.convertValue(tc.getContent().getData(), TcExternalContent.class);
        if (tec.getPayload() == null) {
            // If we are here, then we need to fetch from newco-admin
            try {
                tec = newCoTermsAndCondClient.getDocumentPayload(gx.getTcId());
                if (tec == null) {
                    throw new Exception("Retrieved null from newco-admin");
                }
            } catch (Exception e) {
                throw new IOException("Unable to retrieve TC from newco admin", e);
            }
        }

        // Add TC PDF
        byte[] tcPdf = Base64.decode(tec.getPayload());
        mergerUtility.addSource(new ByteArrayInputStream(tcPdf));
        mergerUtility.setDestinationStream(outputStream);

        // Merge
        mergerUtility.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());
    }

    /**
     * Declares a list of key attributes of a Gx, which will be exported to a PDF. The specific
     * values of the constants define the key of the map used in {@link #extractFieldsForForm(Gx,
     * OrgProfile, OrgProfile, OrgProfile)}, and need to be defined as field names in the PDF
     * template's form.
     */
    static final class FormField {
        static final String GX_ID = "gx_id",
                GX_ISSUE_DATE = "gx_issue_date",
                GX_EXPIRY_DATE = "gx_expiry_date",
                GX_TYPE = "gx_type",
                GX_AMOUNT = "gx_amount",
                GX_STATUS = "gx_status",
                GX_BANK_REF_NUMBER = "gx_bank_reference_number",
                BENEFICIARY_NAME = "beneficiary_name",
                BENEFICIARY_BID = "beneficiary_bid",
                BENEFICIARY_ADDRESS = "beneficiary_address",
                ISSUER_NAME = "issuer_name",
                ISSUER_BID = "issuer_bid",
                ISSUER_ADDRESS = "issuer_address",
                APPLICANT_NAME = "applicant_name",
                APPLICANT_BID = "applicant_bid",
                APPLICANT_ADDRESS = "applicant_address";
    }
}
