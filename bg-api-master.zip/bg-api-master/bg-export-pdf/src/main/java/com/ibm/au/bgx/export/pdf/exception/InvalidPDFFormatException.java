package com.ibm.au.bgx.export.pdf.exception;

public class InvalidPDFFormatException extends PDFExportException {
  public InvalidPDFFormatException(String s) {
    super(s);
  }
}
