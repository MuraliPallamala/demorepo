package com.ibm.au.bgx.export.pdf.exception;

public class PDFExportException extends Exception {
  public PDFExportException(String s) {
    super(s);
  }

  public PDFExportException(Throwable e) {
    super(e);
  }
}
