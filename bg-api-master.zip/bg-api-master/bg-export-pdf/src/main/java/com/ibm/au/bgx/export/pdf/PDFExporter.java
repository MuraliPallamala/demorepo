package com.ibm.au.bgx.export.pdf;

import com.ibm.au.bgx.export.pdf.exception.InvalidPDFCredentialsException;
import com.ibm.au.bgx.export.pdf.exception.InvalidPDFFormatException;
import com.ibm.au.bgx.export.pdf.exception.PDFExportException;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Exports a map of fields into a PDF form.
 *
 * <p>The class writes out a given set of fields onto a PDF file based on a provided PDF template.
 * The provided template should contain a PDF form, which will contain the fields being exported.
 * The values should be a a {@code Map<String, String>} where the keys of the map are PDF form field
 * names. If fields are specified in the export map, which do not exist in the PDF form, they are
 * ignored. If a field exists in the PDF form for which value is not specified in the map, the field
 * is not updated and hence the default value specified in the template remains in effect.
 *
 * @author ermyasabebe
 */
public class PDFExporter {
    private static final Logger LOGGER = LoggerFactory.getLogger(PDFExporter.class);

    /**
     * @param pdfTemplate The PDF template to use in creating the exported PDF. The template should
     *                    contain a form with field names corresponding to the keys of the {@code
     *                    formValues} map specified
     * @param formValues  A map of field names and values. The keys of the map should correspond to
     *                    the field names in the PDF template ({@code pdfTemplate}) form specified.
     * @param output      An output stream of the exported PDF
     * @throws PDFExportException       If errors occur processing the provided template, or
     *                                  creating an exported PDF.
     * @throws IOException              If IO errors occur reading the specified provided template
     *                                  file or creating the exported PDF stream.
     * @throws IllegalArgumentException if a null is provided for {@code formValues}
     */
    public void export(File pdfTemplate, Map<String, String> formValues, OutputStream output)
            throws PDFExportException, IOException {
        if (formValues == null)
            throw new IllegalArgumentException(
                    "The form values to use in populating a PDF cannot be null");

        LOGGER.debug("Exporting PDF with file {} and content: {}", pdfTemplate.getAbsolutePath(), formValues);

        try (PDDocument doc = PDDocument.load(pdfTemplate)) {
            populateFormField(pdfTemplate, formValues, doc);
            doc.save(output);
        } catch (InvalidPasswordException e) {
            LOGGER.error("Invalid credentials specified for template PDF", e);
            throw new InvalidPDFCredentialsException(e);
        }
    }

    private void populateFormField(File pdfTemplate, Map<String, String> formValues, PDDocument doc)
            throws IOException, InvalidPDFFormatException {
        PDAcroForm form = doc.getDocumentCatalog().getAcroForm();

        if (form == null)
            throw new InvalidPDFFormatException(
                    String.format(
                            "The provided PDF template does not contain a valid form: '%s'",
                            pdfTemplate.getName()));

        for (PDField field : form.getFields()) {
            String fieldName = field.getFullyQualifiedName();
            if (formValues.containsKey(fieldName)) field.setValue(formValues.get(fieldName));
        }
    }
}
