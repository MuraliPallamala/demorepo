package com.ibm.au.bgx.admin;

import com.ibm.au.bgx.core.OrganizationManagerImpl;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.chain.profile.AdminOrganizationManager;
import com.ibm.au.bgx.model.exception.IdentityProviderException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.identityprovider.ManagedIdentityProviderClient;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.BaseRequest;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.Organization;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Class <b>AdminOrganizationManagerImpl</b>. This is the default implementation of the {@link AdminOrganizationManager}
 * interface, used by the administrative vertical to support additional organisation management functions such as bootstrapping
 * organisations, and configuring their identity provider for allowing users to operate within the platform as part of their
 * organisation.
 * </p>
 * <p>
 * This class extends the {@link OrganizationManagerImpl} class to implement the additional capabilities required by the
 * {@link AdminOrganizationManager} interface, thus reusing most of the logic of the default implementation of the organisation
 * manager.
 * </p> 
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class AdminOrganizationManagerImpl extends OrganizationManagerImpl implements AdminOrganizationManager {

	/**
	 * A {@link Logger} implementation that is used to collect the log messages that have been created
	 * by the instances of this class.
	 */
    private static final Logger LOGGER = LoggerFactory.getLogger(AdminOrganizationManagerImpl.class);
	
    /**
     * A {@link String} constant representing the template used to generated the unique identifiers of the
     * OpenID clients used to perform the authentication of the end-users via a browser authentication session.
     * This is the common authentication user scenario.
     */
	public static final String PORTAL_CLIENT_TEMPLATE 	= 	"%s-portal";

    /**
     * A {@link String} constant representing the template used to generated the unique identifiers of the
     * OpenID clients used to perform the API authentication for an organisation. This is the scenario where
     * the API of two distinct verticals need to talk to each other for exchanging information.
     */
	public static final String API_CLIENT_TEMPLATE		=	"%s-api";


    /**
     * A {@link ManagedIdentityProviderClient} implementation that is used to create and manage the security
     * realm associated to the organisations that are onboarded in the platform.
     */
    @Autowired
    private ManagedIdentityProviderClient identityProvider;
    
    
    /**
     * This method creates an organisation into the platform. The logic implemented in this method is very
     * similar to {@link AdminOrganizationManagerImpl#create(OrgProfileRequest, String, boolean)} with the
     * exception of a more relaxed validation of the organization profile.
     * 
     * @param profileRequest	a {@link OrgProfileRequest} instance that contains information about the 
     * 							organization to bootstrap. It cannot be {@literal null}.
     * @param adminCert			a {@link String} containing the certificate of the administrator that is
     * 							used to create the organization profile in the ledger. It is expected to
     * 							not to be {@literal null} or an empty string.
     * @param forceReconnect	a {@literal boolean} indicating whether the method should reconnect in case
     * 							of network disconnection.
     * 
     * @return an {@link Organization} instance that represents the organization that has been bootstrapped.
     * 
     * 
     * @throws IllegalArgumentException	if one of the following conditions occur:
     * 									<ul>
     * 									<li><i>profileRequest</i> is {@literal null}</li>
     * 									<li><i>profileRequest</i> has a {@literal null} profile</li>
     * 									<li>there already exist an organization profile with the same identifier 
     * 									or the same business identifier</li>
     * 									</ul>
     * @throws DataValidationException	if <i>profileRequest</i> contains an invalid profile (see {@link 
     * 									BgxDataValidator#validateProfile(OrgProfile,Status)}).
     * 
     * @throws ProfileChainException	if there is any error with the interaction with the ledger to lookup 
     * 									profiles
     * 							
     * @throws ProfileCreateException	if there is any error during the creation of organisation profile in 
     * 									the ledger. 
     */
    public Organization bootstrap(OrgProfileRequest profileRequest, String adminCert, boolean forceReconnect) throws ProfileCreateException, ProfileChainException {


    	if (profileRequest == null) {
    		throw new IllegalArgumentException("Parameter 'profileRequest' cannot be null.");
    	}
    	
    	OrgProfile profile = profileRequest.getProfile();
    	if (profile == null) {
    		
    		throw new IllegalArgumentException("Parameter 'profileRequest' must have a non-null organization profile.");
    	}
    	
    	BaseRequest.Status status = profile.getAgreement() == null ? Status.DRAFTED : Status.APPROVED; 
    	
        this.validateProfileRequest(profileRequest, status);
        
        
        profile = this.initProfile(profileRequest, adminCert, forceReconnect);

        return this.createOrUpdateCacheRecord(profile);
    }
    

    /**
     * This method configures the organisation with the default identity provider. As part of the organisation creation process in the
     * platform a security realm needs to be configured in order for the organisation users to be able to authenticate and login within
     * the platform and operates as recognised users of a specific organisation. This method sets up such security realm.
     * 
     * @param organization				an {@link Organization} instance that needs to be configured with the identity provider. It cannot
     * 									be {@literal null}.
     * 
     * @param config					a {@link Map} implementation that contains the configuration settings for the identity provider.
     * 									While the set of keys in this map may depend on the specific implementation of the identity provider
     * 									being used, this map should at least contain {@link BgxConstants#BOOTSTRAP_USER_REDIRECT_URI_LIST}
     * 									which needs to be set to the redirect url that needs to be contacted once authentication of a user
     * 									for this specific organisation is completed. It cannot be {@literal null}.
     * 
     * @param bootstrapPortalClient		a {@literal boolean} value indicating whether the initialisation process also needs to configure
     * 									an OpenID client for the portal (i.e. {@literal true}) or not (i.e. {@literal false}).
     * 
     * @param bootstrapApiClient		a {@literal boolean} value indicating whether the initialisation process also needs to configure the
     * 									OpenID client for API-to-API communication (i.e. {@literal true}) or not (i.e. {@literal false}).
     * 
     * @param bootstrapUsers			a {@literal boolean} value indicating whether the initialisation process also needs to initialise
     * 									the users that are defined in the contact list of the organisation profile associated to the 
     * 									organization.
     * 
     * @return	an {@link Organization} instance that is updated with the identity provider configuration as specified by the method arguments. 
     * 			It is guaranteed to not to be {@literal null}.	
     * 
     * @throws IdentityProviderException	if there is any error occurring while interacting the default identity provider, while creating
     * 										the security realm, configuring the client, or creating the users.
     * 
     * @throws IllegalArgumentException		if one of the following occurs:
     * 										<ul>
     * 										<li><i>organization</i> is {@literal null}</li>
     * 										<li><i>config</i> is {@literal null}</li>
     * 										</ul>
     */
    @Override
    public synchronized Organization prepareIdentityProvider(Organization organization, 
    														 Map<String, Object> config, 
    														 boolean bootstrapPortalClient, 
    														 boolean bootstrapApiClient,
    														 boolean bootstrapUsers) throws IdentityProviderException {

    	if (organization == null) {
    		throw new IllegalArgumentException("Organization cannot be null.");
    	}
    	
        // verify config
        this.verifyConfig(config);

        // create realm
        String realmName = this.prepareRealmName(organization);

        // check if it exists already or not
        this.checkRealmCreate(realmName, organization);

        // fetch user auth client info
        if (bootstrapPortalClient) {
            organization = this.bootstrapPortalClient(organization, realmName, config);
        }

        // create api auth client
        if (bootstrapApiClient) {
            organization = this.bootstrapApiClient(organization, realmName);
        }

        // bootstrap users
        if (bootstrapUsers) {
            this.bootstrapUsers(organization, realmName, config);
        }

        return this.updateCache(organization);
    }
    
    /**
     * Utility method to verify that the configuration settings used to initialise the identity provider for a given organisation contains 
     * the minimum set of required parameters for its setup. 
     * 
     * @param config					a {@link Map} implementation that contains the configuration settings for the identity provider.
     * 									While the set of keys in this map may depend on the specific implementation of the identity provider
     * 									being used, this map should at least contain {@link BgxConstants#BOOTSTRAP_USER_REDIRECT_URI_LIST}
     * 									which needs to be set to the redirect url that needs to be contacted once authentication of a user
     * 									for this specific organisation is completed. It cannot be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>config</i> is {@literal null} or does not contain {@link BgxConstants#BOOTSTRAP_USER_REDIRECT_URI_LIST}
     * 									as one of the keys in the map.
     */
    protected void verifyConfig(Map<String, Object> config)  {
    	
    	if (config == null) {
    		
    		throw new IllegalArgumentException("Identity provider configuration cannot be null.");
    	}
    	
        List<String> configProperties = Arrays.asList( BgxConstants.BOOTSTRAP_USER_REDIRECT_URI_LIST );

        for (String key : configProperties) {
            if (!config.containsKey(key)) {
                throw new IllegalArgumentException(String.format("Config '%s' is required for Identity provider configuration", key));
            }
        }
    }

    /**
     * Creates the security realm for the given <i>organization</i> and sets its name to <i>realmName</i>. The method first checks
     * that there isn't a realm named <i>realmNme</i> already configured with the identity provider, and if this is not existing
     * it creates one.
     * 
     * @param realmName			a {@link String} representing the name of the security realm to assign to <i>organization</i>. 
     * 							It cannot be {@literal null} or an empty string.
     * 
     * @param organization		a {@link Organization} instance that represents the organisation to create the security realm
     * 							for. It is expected to be not {@literal null}.
     * 
     * @throws IdentityProviderException	if there is an error while interacting with the identity provider to create or
     * 										lookup the realm <i>realmNme</i>.
     * 
     * @throws IllegalArgumentException		if <i>realmName</i> is {@literal null} or an empty string.
     */
    protected void checkRealmCreate(String realmName, Organization organization)  throws IdentityProviderException {
    	
        if (this.identityProvider.getRealm(realmName) == null) {
            LOGGER.debug(BgxLogMarkers.DEV, "Creating realm '{}' for {} {}", realmName, organization.getId(), organization.getProfile().getEntityName());

            this.identityProvider.createRealm(realmName, organization.getProfile().getEntityName());

            LOGGER.debug(BgxLogMarkers.DEV, "Created new realm '{}' for '{}'", realmName, organization.getProfile().getEntityName());
        } else {
            LOGGER.debug(BgxLogMarkers.DEV, "Found realm '{}'", realmName);
        }
    }

    /**
     * This method creates the OpenID client that is used for the authentication of the organisation users against the security realm created for the
     * organisation. This is the client that is used when user log in into the platform via the application portals.
     * 
     * @param organization	a {@link Organization} instance representing the organisation for which the portal client is being configured. It is expected
     * 						to not to be {@literal null} and be a validly initialised organisation instance.
     * @param realmName		a {@link String} representing the name of the security realm associated to <i>organization</i>. This is the security realm
     * 						that will be associated to the OpenID client being created. It cannot be {@literal null} or an empty string.
     * @param config		a {@link Map} implementation that is used to configure an initialise the OpenID client. It is expected to not to be {@literal 
     * 						null}.
     * 	
     * @return	an {@link Organization} instance configured with the newly created OpenID client to support user authentication. If the operation is 
     * 			successful, this reference is guaranteed to not to be {@literal null} and the value of {@link OrgSettings#getUserAuth()} returs the
     * 			configuration of the OpenID client created.
     * 
     * @throws IdentityProviderException	if there is any error in interacting with the identity provider while creating the client.
     * 
     * @throws IllegalArgumentException		if <i>realmName</i> is {@literal null} or an empty string.
     */
    @SuppressWarnings("unchecked")
	protected Organization bootstrapPortalClient(Organization organization, String realmName, Map<String, Object> config) throws IdentityProviderException {
    	
    	if (realmName == null || realmName.isEmpty()) {
    		throw new IllegalArgumentException("Realm name cannot be null.");
    	}
    	
        String userAuthClientId = this.prepareUserAuthClientId(realmName);
        OpenIdConfig userAuth = this.identityProvider.getClient(realmName, userAuthClientId);
        if (userAuth == null) {
        	
            LOGGER.debug(BgxLogMarkers.DEV, "Creating auth client '{}'", userAuthClientId);

            userAuth = this.identityProvider.createUserClient(realmName, userAuthClientId, (List<String>) config.get(BgxConstants.BOOTSTRAP_USER_REDIRECT_URI_LIST));
        } else {
        	
            LOGGER.debug(BgxLogMarkers.DEV, "Found auth client '{}'", userAuthClientId);
        }

        // set the configuration
        organization.getSettings().setUserAuth(userAuth);
        return organization;
    }


    /**
     * This method creates the OpenID client that is used for the authentication of the organisation among API verticals. API-to-API communication
     * utilises a different OpenID client that is not designed to be used within the context of a browser flow, where a user has to enter the security
     * credentials for authetication.
     * 
     * @param organization	a {@link Organization} instance representing the organisation for which the API client is being configured. It is expected
     * 						to not to be {@literal null} and be a validly initialised organisation instance.
     * @param realmName		a {@link String} representing the name of the security realm associated to <i>organization</i>. This is the security realm
     * 						that will be associated to the OpenID client being created. It cannot be {@literal null} or an empty string.
     * @param config		a {@link Map} implementation that is used to configure an initialise the OpenID client. It is expected to not to be {@literal 
     * 						null}.
     * 	
     * @return	an {@link Organization} instance configured with the newly created OpenID client to support API-to-API authentication. If the operation is 
     * 			successful, this reference is guaranteed to not to be {@literal null} and the value of {@link OrgSettings#getApiAuth()} returns the
     * 			configuration of the OpenID client created.
     * 
     * @throws IdentityProviderException	if there is any error in interacting with the identity provider while creating the client.
     * 
     * @throws IllegalArgumentException		if <i>realmName</i> is {@literal null} or an empty string.
     */
    protected Organization bootstrapApiClient(Organization organization, String realmName) throws IdentityProviderException {
    	

    	if (realmName == null || realmName.isEmpty()) {
    		throw new IllegalArgumentException("Realm name cannot be null.");
    	}
        
    	String apiAuthClientId = this.prepareApiAuthClientId(realmName);
        OpenIdConfig apiAuth = identityProvider.getClient(realmName, apiAuthClientId);
        if (apiAuth == null) {
        	
            LOGGER.debug(BgxLogMarkers.DEV, "Creating auth client '{}'", apiAuthClientId);
            apiAuth = this.identityProvider.createApiClient(realmName, apiAuthClientId);
        
        } else {
            LOGGER.debug(BgxLogMarkers.DEV, "Found auth client '{}'", apiAuthClientId);
        }

        organization.getSettings().setApiAuth(apiAuth);
        return organization;
    }

    /**
     * Initialises all the contacts in the organisation profile with corresponding users in the security realm associated to the organisation and sets
     * for them a default password if provided. For all the contacts defined in {@link OrgProfile#getContacts()} the method checks whether a user with
     * the same email exists within the security realm <i>realmName</i>. If not found it creates a user for such contact and sets its default password.
     * 
     * @param organization	an instance of {@link Organization} whose contacts are being initialised as users in the security realm <i>realmName</i>.
     * 						It is expected to not to be {@literal null} and have a valid profile.
     * @param realmName		a {@link String} representing the security realm that has been associated in the identity provider to <i>organization</i>,
     * 						which is also the realm where the users will be created. It cannot be {@literal null} or an empty string.
     * @param config		a {@link Map} implementation that contains the additional attributes required to setup the contacts. In particular this
     * 						map may contain the key {@link BgxConstants#BOOTSTRAP_USER_TEMP_SECRET}, which represents the initial password that is
     * 						assigned to all the users that are created for the organisation, if present. This argument is expected to not to be {@literal 
     * 						null}.
     * 
     * @throws IdentityProviderException	if any error occurs while interacting with the identity provider during the process of initialising
     * 										the organisation contacts.
     * 
     * @throws IllegalArgumentException		if <i>realmName</i> is {@literal null} or an empty string.
     */
    protected void bootstrapUsers(Organization organization, String realmName, Map<String, Object> config) throws IdentityProviderException {
    	
        LOGGER.debug(BgxLogMarkers.DEV, "Bootstrapping users - see debug.log for details.");
        for (ContactInfo contact : organization.getProfile().getContacts()) {

            if (!this.identityProvider.userExists(realmName, contact.getEmail())) {

                LOGGER.debug(BgxLogMarkers.DEV, "Creating user '{}'", contact.getEmail());

                this.identityProvider.createUser(realmName, contact.getEmail(), contact.getFirstName(), contact.getLastName());

                if (config.containsKey(BgxConstants.BOOTSTRAP_USER_TEMP_SECRET)) {
                	
                	this.identityProvider.setPassword(realmName, contact.getEmail(), (String) config.get(BgxConstants.BOOTSTRAP_USER_TEMP_SECRET));
                    LOGGER.debug(BgxLogMarkers.DEV, "Created user '{}' with temp password '{}'", contact.getEmail(), config.get(BgxConstants.BOOTSTRAP_USER_TEMP_SECRET));
                }

            } else {
                LOGGER.debug("Found user '{}'", contact.getEmail());
            }
        }
    }

    /**
     * Utility method to create the unique identifier of the OpenID client used to authenticate the end users via
     * a browser authentication flow for the specified realm. This client is the common client used to authenticate
     * organisation users via the application portals.
     * 
     * @param realm		a {@link String} representing the name of the realm for which the portal OpenID client is
     * 					being created. This argument is expected to not to be {@literal null} or an empty string.
     * 
     * @return 	a {@link String} representing the unique identifier of the portal client for realm. It is guaranteed
     * 			to not to be {@literal null} and it is generated by using the {@link #PORTAL_CLIENT_TEMPLATE} as a
     * 			base which is then specialised with the name of the realm.
     */
    private String prepareUserAuthClientId(String realm) {
    	
        return String.format(AdminOrganizationManagerImpl.PORTAL_CLIENT_TEMPLATE, realm);
    }

    /**
     * Utility method to create the unique identifier of the OpenID client used to authenticate the API-to-API
     * communication for the specified realm. This client is primarily used when one vertical needs to talk to
     * another vertical to exchange some information. In this scenario there is no browser authentication flow
     * but a different client is utilised.
     * 
     * @param realm		a {@link String} representing the name of the realm for which the API OpenID client is
     * 					being created. This argument is expected to not to be {@literal null} or an empty string.
     * 
     * @return 	a {@link String} representing the unique identifier of the API client for realm. It is guaranteed
     * 			to not to be {@literal null} and it is generated by using the {@link #API_CLIENT_TEMPLATE} as a
     * 			base which is then specialised with the name of the realm.
     */
    private String prepareApiAuthClientId(String realm) {
    	
        return String.format(AdminOrganizationManagerImpl.API_CLIENT_TEMPLATE, realm);
    }


}
