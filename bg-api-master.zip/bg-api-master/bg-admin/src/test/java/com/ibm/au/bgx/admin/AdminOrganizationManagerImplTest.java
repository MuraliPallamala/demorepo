package com.ibm.au.bgx.admin;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.ManagedIdentityProviderClientMock;
import com.ibm.au.bgx.chain.ProfileChainMock;
import com.ibm.au.bgx.chain.TermsAndCondChainMock;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.common.KeyGeneratorImpl;
import com.ibm.au.bgx.core.ApprovalModelCatalogImpl;
import com.ibm.au.bgx.core.validation.BgxDataValidatorImpl;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.chain.profile.AdminOrganizationManager;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.identityprovider.ManagedIdentityProviderClient;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.OrgSettings;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.repository.TermsAndCondRepository;
import com.ibm.au.bgx.model.validation.FileWhiteListManager;
import com.ibm.au.bgx.queue.TransientQueueClient;
import com.ibm.au.bgx.repository.OrgProfileRepositoryMock;
import com.ibm.au.bgx.repository.OrganizationRepositoryMock;
import com.ibm.au.bgx.repository.TermsAndCondRepositoryMock;
import com.ibm.au.bgx.repository.UserProfileRepositoryMock;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    AdminOrganizationManagerImpl.class,
    OrganizationRepositoryMock.class,
    OrgProfileRepositoryMock.class,
    ProfileChainMock.class,
    ManagedIdentityProviderClientMock.class,
    KeyGeneratorImpl.class,
    DefaultTestHelper.class,
    ApprovalModelCatalogImpl.class,
    UserProfileRepositoryMock.class,
    TransientQueueClient.class,
    BgxDataValidatorImpl.class,
    TermsAndCondManagerMock.class,
    FileWhiteListManager.class

})
@TestPropertySource(locations = "classpath:application-test.properties")
public class AdminOrganizationManagerImplTest {

    @Autowired
    protected AdminOrganizationManager manager;

    @Autowired
    KeyGenerator generator;

    @Autowired
    ManagedIdentityProviderClient identityProviderClient;

    @Autowired
    protected DefaultTestHelper testHelper;
    
    @Autowired
    protected TermsAndCondManager termsAndCondManager;

    protected List<String> sampleAdminCerts;

    @Before
    public void setUp() throws Exception {

        this.sampleAdminCerts = testHelper.getAdminCerts();
        this.testHelper.setupTermsAndConds(this.termsAndCondManager);
       

        // we need to check that one organization has already been bootstrapped without adminCert input
        // This is required for local java-integration-test where chaincode throws error if the admin org hasn't been bootstrapped
        List<Organization> orgs = manager.getAll();
        if (orgs.size() == 0) {
            this.initailizeOrganization(null, null); // create the first org that does not require cert
        }
    }

    @Test
    public void prepareIdentityProvider() throws Exception {

        List<Organization> mocks = this.createMocks(1);
        Organization org = mocks.get(0);

        org.getSettings().setKey("TEST-" + generator.newKey(BgxConstants.ORG_KEY_LEN));
        org = manager.updateCache(org);

        List<String> redirectUriList = Arrays
            .asList(new String[]{"http://localhost/redirect/cb/" + UUID.randomUUID().toString()});
        Map<String, Object> config = new HashMap<>();
        config.put(BgxConstants.BOOTSTRAP_USER_REDIRECT_URI_LIST, redirectUriList);
        Organization saved = manager.prepareIdentityProvider(org, config, true, true, true);

        // delete the realm
        identityProviderClient.removeRealm(saved.getSettings().getKey());
    }


    protected Organization initailizeOrganization(OrgProfileRequest profileRequest,
        String adminCert)
        throws ProfileCreateException, ProfileChainException {

        if (profileRequest == null) {
            profileRequest = testHelper.createOrgProfileRequestMock();
        }

        profileRequest.getProfile().setId(profileRequest.getId());

        Organization expected = new Organization();
        expected.setProfile(profileRequest.getProfile());
        OrgSettings settings = new OrgSettings();
        expected.setSettings(settings);

        Organization actual = manager.create(profileRequest, adminCert);

        assertNotNull(actual);
        assertNotNull(actual.getId());
        assertNotNull(actual.getProfile());
        assertNotNull(actual.getSettings());
        assertEquals(expected.getProfile().getId(), actual.getProfile().getId());
        assertEquals(expected.getProfile().getEntityName(), actual.getProfile().getEntityName());
        assertEquals(expected.getProfile().getEntityType(), actual.getProfile().getEntityType());
        assertEquals(expected.getProfile().getBusinessId(), actual.getProfile().getBusinessId());
        assertEquals(expected.getProfile().getEntityAddress(),
            actual.getProfile().getEntityAddress());

        return actual;
    }

    protected List<Organization> createMocks(int count)
        throws Exception {
        List<Organization> mocks = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            Organization org = this
                .initailizeOrganization(null, sampleAdminCerts.get(i % sampleAdminCerts.size()));
            mocks.add(org);
        }

        return mocks;
    }

}