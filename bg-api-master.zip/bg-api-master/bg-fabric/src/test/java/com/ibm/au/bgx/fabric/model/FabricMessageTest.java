package com.ibm.au.bgx.fabric.model;

import java.text.ParseException;

import org.junit.Assert;
import org.junit.Test;


/**
 * Class <b>FabricMessageTest</b>. This class tests the implemented behaviour
 * of the {@link FabricMessage} class. The primary purpose of this class is
 * to provide a more accessible structure to the information that is embedded
 * in a response from the fabric.
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class FabricMessageTest {

    /**
     * <p>
     * This method tests the implemented behaviour of {@link FabricMessage#parse(String)}
     * that is expected to construct an instance of {@link FabricMessage} from the given
     * string. The method tries to identify the code section that stores the pair of attributes
     * of interest for the creation of the {@link FabricMessage} instance and parses the
     * corresponding text and extracts the value of the status code and the status message.
     * </p>
     * <p>
     * If the parsing is successful and the string is compliant with the expected format
     * then a {@link FabricMessage} will be returned. Otherwise the following exception
     * will be thrown:
     * <ul>
     * <li>{@link IllegalArgumentException} if the given argument is {@literal null} or an
     * empty string</li>
     * <li>{@link ParseException} in all the other cases</li>
     * </ul>
     * The test method investigates several configurations of the string to cover all the
     * branches of the implementation logic.
     * </p>
     *
     * @throws ParseException	declared but not expected to be thrown.
     */
    @Test
    public void testParse() throws ParseException {


        // Test 1 - An empty string, this should throw IllegalArgumentException
        //
        try {

            FabricMessage.parse("");
            Assert.fail("FabricMessage.parse(String) should throw IllegalArgumentException if invoked with an empty string.");

        } catch(IllegalArgumentException ilex) {

            // good to go.
        }

        // Test 2 - A null string, this should throw IllegalArgumentException
        //
        try {

            FabricMessage.parse(null);
            Assert.fail("FabricMessage.parse(String) should throw IllegalArgumentException if invoked with a null string.");

        } catch(IllegalArgumentException ilex) {

            // good to go...
        }
        
        
        // These are a bunch a string formats that can be used to easily compose raw messages to be parsed, where we can inject the values that
        // we expect to parse and have exposed in FabricMessage instance.
        //
        String descriptionFormatWithChaincodeError = "chaincode error (status: %1$d, message: %2$s)";
        String descriptionFormatWithoutChaincodeError = "error executing chaincode: error chaincode is already launching: contract-v108:20190423_1500";
        String messageFormat = "Sending proposal to peer.org.example.com failed because of; gRPC failure=Status{code=%1$s, description=%2$s, cause=%3$s}";
        

        int expectedCode 		= 	404;
        String expectedMessage 	= 	"\"This is not JSON.\"";
        String expectedStatus	=	"UNKNOWN";
        String expectedCause	=	"null";
        

        // Test 3 - A compliant string. We need to obtain a non-null instance of FabricMessage.
        //
        
        // Test 3.1 - A compliant string without information about the chaincode error.
        //
        String expectedDescription = descriptionFormatWithoutChaincodeError;
        String expectedRawMessage = String.format(messageFormat, expectedStatus, expectedDescription, expectedCause);

        FabricMessage message = FabricMessage.parse(expectedRawMessage);
        
        Assert.assertNotNull("FabricMessage.parse(String) should return a non-null instance, when invoked with a valid raw messag (without chaincode error status).", message);

        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getRawMessage() matches the argument being parsed (without chaincode error status).", expectedRawMessage, message.getRawMessage());
        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getStatus() matches the value parsed (without chaincode error status).", expectedStatus, message.getStatus());
        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getDescription() matches the value parsed (without chaincode error status).", expectedDescription, message.getDescription());
        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getCause() matches the value parsed (without chaincode error status).", expectedCause, message.getCause());
        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getChaincodeStatus() is set to the default FabricMessage.CHAINCODE_STATUS_NOT_SET (without chaincode error status).", FabricMessage.CHAINCODE_STATUS_NOT_SET, message.getChaincodeStatusCode());
        Assert.assertNull("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getChaincodeMessage() is set to null (without chaincode error status).", message.getChaincodeMessage());

        
         
        // Test 3.2 - A compliant string with information about the chaincode error.
        //
        expectedDescription = String.format(descriptionFormatWithChaincodeError, expectedCode, expectedMessage);
        expectedRawMessage = String.format(messageFormat, expectedStatus, expectedDescription, expectedCause);

        message = FabricMessage.parse(expectedRawMessage);
        
        Assert.assertNotNull("FabricMessage.parse(String) should return a non-null instance, when invoked with a valid raw messag (with chaincode error status).", message);

        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getRawMessage() matches the argument being parsed (with chaincode error status).", expectedRawMessage, message.getRawMessage());
        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getStatus() matches the value parsed (with chaincode error status).", expectedStatus, message.getStatus());
        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getDescription() matches the value parsed (with chaincode error status).", expectedDescription, message.getDescription());
        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getCause() matches the value parsed (with chaincode error status).", expectedCause, message.getCause());
        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getChaincodeStatus() matches the value parsed (with chaincode error status).", expectedCode, message.getChaincodeStatusCode());
        Assert.assertEquals("FabricMessage.parse(String) should create an FabricMessage instance whose property FabricMessage.getChaincodeMessage() matches the value parsed (with chaincode error status).", expectedMessage, message.getChaincodeMessage());
        

        
        // Test 4 - Invalid Structure of the Status Fragment.
        //
        
        // Test 4.1 - Missing status header.
        //
        
        String invalidRawMessage = expectedRawMessage.replace(FabricMessage.STATUS_HEADER, "");
        
        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the given message is missing the status header ('%1$s').", FabricMessage.STATUS_HEADER));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        // Test 4.2 - Missing status footer.
        //
        invalidRawMessage = expectedRawMessage.replace(FabricMessage.STATUS_FOOTER, "");

        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the given message is missing the status footer ('%1$s').", FabricMessage.STATUS_FOOTER));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        // Test 4.3 - Misplaced delimiters for status fragment.
        //
        invalidRawMessage = expectedRawMessage.replace(FabricMessage.STATUS_HEADER, "#");
        invalidRawMessage = invalidRawMessage.replace(FabricMessage.STATUS_FOOTER, FabricMessage.STATUS_HEADER);
        invalidRawMessage = invalidRawMessage.replace("#", FabricMessage.STATUS_FOOTER);
        
        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the positions of the status delimiters are inverted in the message ('%1$s' after '%2$s').", FabricMessage.STATUS_HEADER, FabricMessage.STATUS_FOOTER));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        
        // Test 4.4 - Commas.
        
        // Test 4.4.a - Status fragment with no commas at all.
        //
        invalidRawMessage = expectedRawMessage.replace("" + FabricMessage.COMMA, "");

        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the status fragment does not have delimiters ('%1$s').", FabricMessage.COMMA));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        // Test 4.4.b - Status fragment with not comma after the status premable.
        //
        invalidRawMessage = expectedRawMessage.replace(FabricMessage.COMMA + " " + FabricMessage.DESCRIPTION_PREAMBLE, " " + FabricMessage.DESCRIPTION_PREAMBLE);

        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the status fragment does not have a delimiter after the status ('%1$s').", FabricMessage.COMMA));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        // Test 4.4.c - Status fragment with not comma after the description preamble.
        //
        invalidRawMessage = expectedRawMessage.replace(FabricMessage.COMMA + " " + FabricMessage.CAUSE_PREAMBLE, " " + FabricMessage.CAUSE_PREAMBLE);

        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the status fragment does not have a delimiter after the description ('%1$s').", FabricMessage.COMMA));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        // Test 4.5 - No code preamble.
        //
        
        invalidRawMessage = expectedRawMessage.replace(FabricMessage.CODE_PREAMBLE, "bingo=");
        
        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the status fragment does not have a code attribute (preamble: '%1$s').", FabricMessage.CODE_PREAMBLE));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        // Test 4.6 - No cause preamble.
        //

        invalidRawMessage = expectedRawMessage.replace(FabricMessage.CAUSE_PREAMBLE, "bingo=");
        
        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the status fragment does not have a cause attribute (preamble: '%1$s').", FabricMessage.CAUSE_PREAMBLE));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        // Test 4.7 - No description preamble.
        //

        invalidRawMessage = expectedRawMessage.replace(FabricMessage.DESCRIPTION_PREAMBLE, "bingo=");
        
        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the status fragment does not have a description attribute (preamble: '%1$s').", FabricMessage.DESCRIPTION_PREAMBLE));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        // Test 5 - Invalid Structure of the Description/Chaincode Fragment.
        //
        //
        
        expectedDescription = String.format(descriptionFormatWithChaincodeError, expectedCode, expectedMessage);
        expectedRawMessage = String.format(messageFormat, expectedStatus, expectedDescription, expectedCause);
        
        // Test 5.1 - Missing Chaincode Status error delimiter.
        //
        invalidRawMessage = expectedRawMessage.replace(FabricMessage.ERROR_CODE_FOOTER, "");
        
        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the chaincode status fragment has a preamble but not the delimiter (preamble: '%2$s', delimiter: '%1$s').", 
        							  FabricMessage.ERROR_CODE_HEADER, FabricMessage.ERROR_CODE_FOOTER));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }

        // Test 5.2 - Comma after the message header.
        //
        
        invalidRawMessage = expectedRawMessage.replace(FabricMessage.COMMA + " " + FabricMessage.MESSAGE_HEADER, " " + FabricMessage.MESSAGE_HEADER + "text" + FabricMessage.COMMA);

        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail(String.format("FabricMessage.parse(String) should throw ParseException when the chaincode status fragment has a comma after the message header (expected '%1$s'<...>'%2$s' '%3$s'<...>'%4$s').", 
        							  FabricMessage.ERROR_CODE_HEADER, FabricMessage.COMMA, FabricMessage.MESSAGE_HEADER, FabricMessage.ERROR_CODE_FOOTER));
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
        
        // Test 5.3 - Status code is not an integer.
        //
        invalidRawMessage = expectedRawMessage.replace("" + expectedCode, "mozumbo");

        try {
        	
        	FabricMessage.parse(invalidRawMessage);
        	Assert.fail("FabricMessage.parse(String) should throw ParseException when the chaincode status fragment has a code that is not an integer.");
        	
        } catch(ParseException pex) {
        	
        	// good to go.
        	//
        	
        }
    }


    
    /**
     * This method tests the implemented behaviour of {@link FabricMessage#FabricMessage(String, String, String, String)}
     * and validates whether the constructor raises the desired {@link IllegalArgumentException} errors in case of invalid parameter, 
     * or whether the parameters passed to the constructor are properly returned by the corresponding getters.
     */
    @Test
    public void testConstructorWithFourParameters() {


    	// Test 1. Sunny, day we pass all arguments with valid values, 
    	//		   and we retrieve them from the corresponding getters. 
    	//         We also expect that the default values are set.
    	//
    	String expectedRawMessage 	= 	"This is not a real message, but it works for the test.";
    	String expectedStatus     	=  	"UNKNOWN";
    	String expectedDescription 	=	"The description should be found in the message after description=";
    	String expectedCause		=	"The cause shoudl be found in the message after cause=";
    	
    	FabricMessage message = new FabricMessage(expectedRawMessage, expectedStatus, expectedDescription, expectedCause);
    	Assert.assertEquals("FabricMessage(String,String,String,String) should set the first argumnt as the value returned by FabricMessage.getRawMessage().", expectedRawMessage, message.getRawMessage());
    	Assert.assertEquals("FabricMessage(String,String,String,String) should set the second argumnt as the value returned by FabricMessage.getStatus().", expectedStatus, message.getStatus());
    	Assert.assertEquals("FabricMessage(String,String,String,String) should set the third argumnt as the value returned by FabricMessage.getDescription().", expectedDescription, message.getDescription());
    	Assert.assertEquals("FabricMessage(String,String,String,String) should set the fourth argumnt as the value returned by FabricMessage.getCause().", expectedCause, message.getCause());
    	Assert.assertEquals("FabricMessage(String,String,String,String) should set the value returned by FabricMessage.getChaincodeStatusCode() to FabricMessage.CHAINCODE_STATUS_NOT_SET.", FabricMessage.CHAINCODE_STATUS_NOT_SET, message.getChaincodeStatusCode());
    	Assert.assertNull("FabricMessage(String,String,String,String) should set the value returned by FabricMessage.getChaincodeMessage() to null.", message.getChaincodeMessage());

    	
    	// Test 2. Setting expectedRawMessage to null, it should throw
    	//         IllegalArgumentException.
    	
    	try {
    		
    		new FabricMessage(null, expectedStatus, expectedDescription, expectedCause);
    		Assert.fail("FabricMessage(null,String,String,String) should throw IllegalArgumentException.");
    		
    	} catch(IllegalArgumentException ilex) {
    		
    		// good to go.
    	}
    	
    	// Test 3. Setting expectedStatus to null, it should throw
    	//         IllegalArgumentException.
    	
    	try {
    		
    		new FabricMessage(expectedRawMessage, null, expectedDescription, expectedCause);
    		Assert.fail("FabricMessage(null,String,String,String) should throw IllegalArgumentException.");
    		
    	} catch(IllegalArgumentException ilex) {
    		
    		// good to go.
    	}
    	
    	// Test 4. Setting expectedRawMessage to null, it should throw
    	//         IllegalArgumentException.
    	
    	try {
    		
    		new FabricMessage(expectedRawMessage, expectedStatus, null, expectedCause);
    		Assert.fail("FabricMessage(String,String,null,String) should throw IllegalArgumentException.");
    		
    	} catch(IllegalArgumentException ilex) {
    		
    		// good to go.
    	}
    	
    	// Test 5. Setting expectedStatus to null, it should throw
    	//         IllegalArgumentException.
    	
    	try {
    		
    		new FabricMessage(expectedRawMessage, expectedStatus, expectedDescription, null);
    		Assert.fail("FabricMessage(String,String,String,null) should throw IllegalArgumentException.");
    		
    	} catch(IllegalArgumentException ilex) {
    		
    		// good to go.
    	}
    	
    }
    
    /**
     * This method tests the implemented behaviour of {@link FabricMessage#FabricMessage(String, String, String, String, int, String)}
     * and validates whether the constructor raises the desired {@link IllegalArgumentException} errors in case of invalid parameter, 
     * or whether the parameters passed to the constructor are properly returned by the corresponding getters.
     */
    @Test
    public void testConstructorWithSixParameters() {
    

    	// Test 1. Sunny, day we pass all arguments with valid values, 
    	//		   and we retrieve them from the corresponding getters. 
    	//         We also expect that the default values are set.
    	//
    	String expectedRawMessage 	= 	"This is not a real message, but it works for the test.";
    	String expectedStatus     	=  	"UNKNOWN";
    	String expectedDescription 	=	"The description should be found in the message after description=";
    	String expectedCause		=	"The cause shoudl be found in the message after cause=";
    	String expectedMessage		=	"This is the chaincode status message.";
    	int expectedCode			=	404;
    	
    	FabricMessage message = new FabricMessage(expectedRawMessage, expectedStatus, expectedDescription, expectedCause, expectedCode, expectedMessage);
    	Assert.assertEquals("FabricMessage(String,String,String,String,int,String) should set the first argumnt as the value returned by FabricMessage.getRawMessage().", expectedRawMessage, message.getRawMessage());
    	Assert.assertEquals("FabricMessage(String,String,String,String,int,String) should set the second argumnt as the value returned by FabricMessage.getStatus().", expectedStatus, message.getStatus());
    	Assert.assertEquals("FabricMessage(String,String,String,String,int,String) should set the third argumnt as the value returned by FabricMessage.getDescription().", expectedDescription, message.getDescription());
    	Assert.assertEquals("FabricMessage(String,String,String,String,int,String) should set the fourth argumnt as the value returned by FabricMessage.getCause().", expectedCause, message.getCause());
    	Assert.assertEquals("FabricMessage(String,String,String,String,int,String) should set the fifth argument as the value returned by FabricMessage.getChaincodeStatusCode().", expectedCode, message.getChaincodeStatusCode());
    	Assert.assertEquals("FabricMessage(String,String,String,String,int,String) should set the sixth argument as the value returned by FabricMessage.getChaincodeMessage().", expectedMessage, message.getChaincodeMessage());

    	
    	// Test 2. Setting expectedRawMessage to null, it should throw
    	//         IllegalArgumentException.
    	
    	try {
    		
    		new FabricMessage(null, expectedStatus, expectedDescription, expectedCause, expectedCode, expectedMessage);
    		Assert.fail("FabricMessage(null,String,String,String,int,String) should throw IllegalArgumentException.");
    		
    	} catch(IllegalArgumentException ilex) {
    		
    		// good to go.
    	}
    	
    	// Test 3. Setting expectedStatus to null, it should throw
    	//         IllegalArgumentException.
    	
    	try {
    		
    		new FabricMessage(expectedRawMessage, null, expectedDescription, expectedCause, expectedCode, expectedMessage);
    		Assert.fail("FabricMessage(null,String,String,String,int,String) should throw IllegalArgumentException.");
    		
    	} catch(IllegalArgumentException ilex) {
    		
    		// good to go.
    	}
    	
    	// Test 4. Setting expectedRawMessage to null, it should throw
    	//         IllegalArgumentException.
    	
    	try {
    		
    		new FabricMessage(expectedRawMessage, expectedStatus, null, expectedCause, expectedCode, expectedMessage);
    		Assert.fail("FabricMessage(String,String,null,String,int,String) should throw IllegalArgumentException.");
    		
    	} catch(IllegalArgumentException ilex) {
    		
    		// good to go.
    	}
    	
    	// Test 5. Setting expectedStatus to null, it should throw
    	//         IllegalArgumentException.
    	
    	try {
    		
    		new FabricMessage(expectedRawMessage, expectedStatus, expectedDescription, null, expectedCode, expectedMessage);
    		Assert.fail("FabricMessage(String,String,String,null,int,String) should throw IllegalArgumentException.");
    		
    	} catch(IllegalArgumentException ilex) {
    		
    		// good to go.
    	}
    	
    	// Test 6. Setting message to null should not cause any throuble.
    	//
    	
    	message = new FabricMessage(expectedRawMessage, expectedStatus, expectedDescription, expectedCause, 410, null);
    	Assert.assertNull("FabricMessage(String,String,String,String,int,null) should set to null the value returned by FabricMessage.getChaincodeMessage().", message.getChaincodeMessage());
    	
    }



}
