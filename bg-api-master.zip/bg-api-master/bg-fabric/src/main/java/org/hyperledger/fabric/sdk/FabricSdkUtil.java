package org.hyperledger.fabric.sdk;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


/**
 * Utility functions
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com> 
 */

public class FabricSdkUtil {

    /**
     * Helper method to remove channel from HFClient
     * @param client
     * @param channel
     */
    public static void removeChannel(HFClient client, Channel channel) {
        client.removeChannel(channel);
    }
}
