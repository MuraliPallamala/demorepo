package com.ibm.au.bgx.fabric.model;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.fabric.util.IbpUtil;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;
import org.hyperledger.fabric.sdk.helper.Utils;

/**
 * @todo Add description
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com> 
 */

public class IbpConfiguration extends DefaultConfiguration {


  /**
   * A {@link IbpConfig} containing the IBP configuration
   */
  private IbpConfig ibpConfig;

  /**
   * Initializes an instance of {@link DefaultConfiguration} with the given set of properties.
   * The constructor loops through the set of key-value pairs defined in <i>properties</i> and copies
   * all those properties whose name starts with {@link DefaultConfiguration#FABRIC_SDK_PREFIX}.
   *
   * It expects a property be set with key FABRIC_SDK_PREFIX + PROP_IBP_CONFIG specifying the IBP configuration JSON
   *
   * @param properties a {@link Properties} instance that contains the properties for the
   * configuration of the fabric network. It cannot be {@literal null} or an empty collection.
   * @throws IllegalArgumentException if <i>properties</i> is {@literal null} or an empty collection.
   */
  public IbpConfiguration(Properties properties) {
    String propKey = DefaultConfiguration.FABRIC_SDK_PREFIX + PROP_IBP_CONFIG;
    if (!properties.containsKey(propKey)) {
      throw new IllegalArgumentException(
          String.format("'%s' config property cannot be empty", propKey));
    }
    String ibpConfigFile = properties.getProperty(propKey);

    FileInputStream inputStream;
    try {
      inputStream = new FileInputStream(ibpConfigFile);
    } catch (FileNotFoundException e) {
      throw new IllegalArgumentException(
          String.format("Could not load IBP json config file: %s", e.getMessage()), e);
    }

    this.ibpConfig = IbpUtil.loadIbpConfig(inputStream);

    // FIXME for now we initialize DefaultConfiguration
    // Ideally we need to implement the Configuration interface and return properties based on IbpConfig
    IbpUtil.parseConfig(this.ibpConfig, properties);

    this.init(properties);
  }

  public IbpConfiguration(IbpConfig config) {
    this.ibpConfig = config;
    Properties props = new Properties();
    IbpUtil.parseConfig(config, props);
    this.init(props); // TODO: init sdk properties?
  }

  @Override
  protected Properties getEndpointProperties(String endpointType, String hostName) {

    if (endpointType == null) {

      throw new IllegalArgumentException("Parameter endPointType cannot be null.");
    }

    if (hostName == null) {

      throw new IllegalArgumentException("Parameter hostName cannot be null.");
    }

    String certPem;
    String url;
    if (endpointType.equals(ENDPOINT_PEER) || endpointType.equals(ENDPOINT_EVENT_HUB)) {

      if (!this.ibpConfig.getPeers().containsKey(hostName)) {
        throw new IllegalArgumentException(
            String.format("Could not find peer config for '%s'", hostName));
      }

      PeerConfig peerConfig = this.ibpConfig.getPeers().get(hostName);
      certPem = peerConfig.getTlsCACerts().getPem();
      url = peerConfig.getUrl();

    } else if (endpointType.equals(ENDPOINT_ORDERER)) {

      if (!this.ibpConfig.getOrderers().containsKey(hostName)) {
        throw new IllegalArgumentException(
            String.format("Could not find orderer config for '%s'", hostName));
      }

      OrdererConfig ordererConfig = this.ibpConfig.getOrderers().get(hostName);
      certPem = ordererConfig.getTlsCACerts().getPem();
      url = ordererConfig.getUrl();
    } else {
      throw new IllegalArgumentException(
          String.format("Parameter endpointType (value: %s) is not recognised.", endpointType));
    }

    byte[] pemBytes = certPem.getBytes(); // IMPORTANT! no need to do Base64.decode

    Properties props = new Properties();

    props.put(DefaultConfiguration.PROPERTY_ENDPOINT_PEM_BYTES, pemBytes);
    props.put(DefaultConfiguration.PROPERTY_ENDPOINT_SSL_PROVIDER,
        DefaultConfiguration.ENDPOINT_SSL_PROVIDER_DEFAULT);
    props.put(DefaultConfiguration.PROPERTY_ENDPOINT_NEGOTIATION_TYPE,
        DefaultConfiguration.ENDPOINT_NEGOTIATION_TYPE_DEFAULT);
    props.put(DefaultConfiguration.PROPERTY_ENDPOINT_TRUST_SERVER_CERTIFICATE,
        DefaultConfiguration.ENDPOINT_TRUST_SERVER_CERTIFICATE_DEFAULT);

    Properties urlProp = Utils.parseGrpcUrl(url);
    props
        .put(DefaultConfiguration.PROPERTY_ENDPOINT_HOSTNAME_OVERRIDE, urlProp.getProperty("host"));

    return props;
  }
}
