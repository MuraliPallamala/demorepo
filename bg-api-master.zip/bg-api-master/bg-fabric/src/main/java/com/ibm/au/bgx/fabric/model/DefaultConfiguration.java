package com.ibm.au.bgx.fabric.model;

import org.hyperledger.fabric.sdk.helper.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

/**
 * Class <i>DefaultConfiguration</i>. This class is the default implementation of the {@link Configuration}
 * interface. It provides a default behaviour to store the configuration parameters of a fabric network.
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public class DefaultConfiguration implements Configuration {

    /**
     * A {@link String} representing the prefix used to identify the subset of the properties that
     * relate to the fabric network configuration. All the properties that begin with this specific
     * prefix are fabric properties.
     */
    public static final String FABRIC_SDK_PREFIX = "fabric.sdk.";
    /**
     * A {@link String} representing the IBP config file location
     */
    public static final String PROP_IBP_CONFIG = "ibp.config";
    /**
     * A {@link String} that contains the prefix used to identify the properties that are of
     * interest for defining organizations.
     */
    public static final String PROPERTY_ORG_PREFIX = "org.";

    // ORGANIZATION PARAMETERS
    //
    //
    // Example:
    //
    // fabric.sdk.org.MyOrg.mspid 				= 	MyOrgMSPID
    // fabric.sdk.org.MyOrg.domainName			=	myorg.example.com
    // fabric.sdk.org.MyOrg.ca.location			=	http://localhost:7050
    // fabric.sdk.org.MyOrg.peer.locations		=	[peer0.myorg.example.com@grpc://localhost:7051, peer1.myorg.example.com@grpc://localhost:7052]
    // fabric.sfk.org.MyOrg.eventHub.locations	=	[peer0.myorg.example.com@grpc://localhost:7053, peer1.myorg.example.com@grpc://localhost:7054]
    // fabric.sdk.org.MyOrg.orderer.locations   =	[orderer0.myorg.example.com@grpc://localhost:7055]
    /**
     * A {@link String} that contains the name of the property suffix used to store the information
     * about the unique identifier of the membership services provider within an organization. The
     * format of the property would be the following:
     *
     * {@link #FABRIC_SDK_PREFIX}{@link #PROPERTY_ORG_PREFIX}<i>orgName</i>{@link #PROPERTY_ORG_MSP_ID}
     */
    public static final String PROPERTY_ORG_MSP_ID = "mspid";
    /**
     * A {@link String} that contains the CA name
     */
    public static final String PROPERTY_ORG_CA_NAME = "ca.name";
    /**
     * A {@link String} that contains the CA cert PEM bytes
     */
    public static final String PROPERTY_ORG_CA_CERT = "ca.cert";
    /**
     * A {@link String} that contains the SIGNED cert PEM bytes for peerAdmin
     */
    public static final String PROPERTY_ORG_SIGNED_CERT = "signedCert";
    /**
     * A {@link String} that contains the name of the property suffix used to store the information
     * about the domain name for an organization. The format of the property would be the following:
     *
     * {@link #FABRIC_SDK_PREFIX}{@link #PROPERTY_ORG_PREFIX}<i>orgName</i>{@link #PROPERTY_ORG_DOMAIN_NAME}
     */
    public static final String PROPERTY_ORG_DOMAIN_NAME = "domainName";
    /**
     * A {@link String} that contains the name of the property suffix used to store the information
     * about the location of the CA for an organization. The format of the property would be the following:
     *
     * {@link #FABRIC_SDK_PREFIX}{@link #PROPERTY_ORG_PREFIX}<i>orgName</i>{@link #PROPERTY_ORG_CA_LOCATION}
     */
    public static final String PROPERTY_ORG_CA_LOCATION = "ca.location";
    /**
     * A {@link String} that contains the name of the property suffix used to store the information
     * about the location of the peers within the organization. The format of the property would be the following:
     *
     * {@link #FABRIC_SDK_PREFIX}{@link #PROPERTY_ORG_PREFIX}<i>orgName</i>{@link #PROPERTY_ORG_PEER_LOCATIONS}
     *
     * The format of the property value is as follows:
     *
     * [ <i>peer1hostName</i>@<i>peer1endpoint</i>,  <i>peer1hostName</i>@<i>peer1endpoint</i>, ... ]
     *
     * where:
     *
     * <i>peer1hostName</i> maps the logical hostname used for the peer in the organization
     * <i>peer1endpoint</i> maps the real url used to talk to the peer, including port and protocol
     */
    public static final String PROPERTY_ORG_PEER_LOCATIONS = "peer.locations";
    /**
     * A {@link String} that contains the name of the property suffix used to store the information
     * about the location of the orderers within the organization. The format of the property would be the following:
     *
     * {@link #FABRIC_SDK_PREFIX}{@link #PROPERTY_ORG_PREFIX}<i>orgName</i>{@link #PROPERTY_ORG_ORDERER_LOCATIONS}
     *
     * The format of the property value is as follows:
     *
     * [ <i>orderer1hostName</i>@<i>orderer1endpoint</i>,  <i>orderer1hostName</i>@<i>orderer1endpoint</i>, ... ]
     *
     * where:
     *
     * <i>orderer1hostName</i> maps the logical hostname used for the orderer in the organization
     * <i>orderer1endpoint</i> maps the real url used to talk to the orderer, including port and protocol
     */
    public static final String PROPERTY_ORG_ORDERER_LOCATIONS = "orderer.locations";
    /**
     * A {@link String} that contains the name of the property suffix used to store the information
     * about the location of the event hubs within the organization. The format of the property would be the following:
     *
     * {@link #FABRIC_SDK_PREFIX}{@link #PROPERTY_ORG_PREFIX}<i>orgName</i>{@link #PROPERTY_ORG_EVENT_HUB_LOCATIONS}
     *
     * The format of the property value is as follows:
     *
     * [ <i>eventHub1hostName</i>@<i>eventHub1endpoint</i>,  <i>eventHub1hostName</i>@<i>eventHub1endpoint</i>, ... ]
     *
     * where:
     *
     * <i>eventHub1hostName</i> maps the logical hostname used for the event hub in the organization
     * <i>eventHub1endpoint</i> maps the real url used to talk to the event hub, including port and protocol
     */
    public static final String PROPERTY_ORG_EVENT_HUB_LOCATIONS = "eventHub.locations";
    /**
     * A {@link String} containing the name of the property that defines the security behaviour of the
     * configuration. If set to {@literal true} all the urls of the organizations, will be converted to
     * their secured versions (otherwise) they will be left to their original values. The default is
     * {@literal false}.
     */
    public static final String PROPERTY_GLOBAL_TLS = "tls";


    // GLOBAL PARAMETERS
    /**
     * A {@link String} constant that is used to identify the regular expression used to capture the
     * protocol component of a url that matches a non-TLS version of GRPC.
     */
    public static final String PROTOCOL_GRPC_REGEX = "^grpc://";
    /**
     * A {@link String} constant that is used to identify the regular expression used to capture the
     * protocol component of a url that matches a non-TLS version of HTTP.
     */
    public static final String PROTOCOL_HTTP_REGEX = "^http://";
    /**
     * A {@link String} constant that is used to store the value of the GRPCS protocol including the
     * separator.
     */
    public static final String PROTOCOL_GRPCS = "grpcs://";
    /**
     * A {@link String} constant that is used to store the value of the HTTPS protocol including the
     * separator.
     */
    public static final String PROTOCOL_HTTPS = "https://";
    /**
     * A {@link String} representing the name of the property that points to the wait time for the gossip
     * protocol, specified in the configuration.
     */
    public static final String PROPERTY_GLOBAL_GOSSIP_WAIT_TIME = "gossipWaitTime";
    /**
     * A {@link String} representing the name of the property that points to the invoke time that is
     * specified in the configuration.
     */
    public static final String PROPERTY_GLOBAL_INVOKE_WAIT_TIME = "invokeWaitTime";
    /**
     * A {@link String} representing the name of the property that points to the deploy time that is
     * specified in the configuration. The deploy time controls the delay that the client should expect
     * when deploying the chaincode.
     */
    public static final String PROPERTY_GLOBAL_DEPLOY_WAIT_TIME = "deployWaitTime";
    /**
     * A {@link String} containing the name of the peer endpoint.
     *
     * @see DefaultConfiguration#getPeerSettings(String).
     */
    public static final String ENDPOINT_PEER = "peer";

    // ENDPOINT SPECIFIC PARAMETERS...
    /**
     * A {@link String} containing the name of the users endpoint.
     *
     * @see DefaultConfiguration#getUserCryptoSettings(String, String) .
     */
    public static final String ENDPOINT_USER = "user";
    /**
     * A {@link String} containing the name of the orderer endpoint.
     *
     * @see DefaultConfiguration#getOrdererSettings(String).
     */
    public static final String ENDPOINT_ORDERER = "orderer";
    /**
     * A {@link String} contianing the name of the event hub endpoint. In this
     * implementation the value is set to {@link DefaultConfiguration#ENDPOINT_PEER}.
     *
     * @see DefaultConfiguration#getEventHubSettings(String).
     */
    public static final String ENDPOINT_EVENT_HUB = ENDPOINT_PEER;
    /**
     * A {@link String} containing the name of the default value for the {@link DefaultConfiguration#PROPERTY_ENDPOINT_TRUST_SERVER_CERTIFICATE}
     * property, which controls whether the client should trust the server certificate or not.
     * The default value is set to <i>true</i>.
     */
    public static final String ENDPOINT_TRUST_SERVER_CERTIFICATE_DEFAULT = "true";
    /**
     * A {@link String} containing the name of the default value for the {@link DefaultConfiguration#PROPERTY_ENDPOINT_NEGOTIATION_TYPE}
     */
    public static final String ENDPOINT_NEGOTIATION_TYPE_DEFAULT = "TLS";
    /**
     * A {@link String} containing the name of the default value for the {@link DefaultConfiguration#PROPERTY_ENDPOINT_SSL_PROVIDER}
     */
    public static final String ENDPOINT_SSL_PROVIDER_DEFAULT = "openSSL";
    /**
     * A {@link String} representing the template that is used to retrieve the certificate of the endpoint in the file
     * system that is used to identify and verify a given endpoint (peer, orderer, eventhub). The template assumes the
     * following structure:
     *
     * <i>channel.path</i>/crypto-config/<i>endpointType</i>Organizations/<i>domainName</i>/<i>endpointType</i>s
     * /<endpointType</i>.<i></i>domainName</i>/tls/server.crt
     *
     * This information is fetched from the configuration.
     */
    public static final String ENDPOINT_TLS_PATH_TEMPLATE = "%s/crypto-config/%sOrganizations/%s/%ss/%s/tls/server.crt";
    /**
     * A {@link String} representing the template that is used to retrieve the certificate of the certificate authority
     * for the given organization. The template assumes the following structure:
     *
     * <i>channel.path</i>/crypto-config/<i>peerOrganizations/<i>domainName<i>/ca/ca.<i>domainName</i>-cert.pem
     *
     * The information about the channel.path and the domainName is fetched from the configuration of the organization.
     */
    public static final String ENDPOINT_CA_TLS_PATH_TEMPLATE = "%s/crypto-config/peerOrganizations/%s/ca/ca.%s-cert.pem";
    /**
     * A {@link String} representing the name of the configuration setting that controls the host names for the
     * certificate authority.
     */
    public static final String PROPERTY_ENDPOINT_CA_ALLOW_HOSTNAMES = "allowAllHostNames";
    /**
     * A {@link String} representing the default value for the {@link #PROPERTY_ENDPOINT_CA_ALLOW_HOSTNAMES} property.
     */
    public static final String ENDPOINT_CA_ALLOW_HOSTNAMES_DEFAULT = "true";
    /**
     * A {@link String} representing the template that is used to retrieve the certificate of a peerAdmin user in the file
     * system that is used to identify and verify a given endpoint (peer, orderer, eventhub). The template assumes the
     * following structure:
     *
     * <i>channel.path</i>/crypto-config/<i>endpointType</i>Organizations/<i>domainName</i>/<i>endpointType</i>s/<userNameWithDomain>/msp/signcerts/<userNameWithDomain>-cert.pem
     *
     * This information is fetched from the configuration.
     */

    public static final String USER_CERT_PATH_TEMPLATE = "%s/crypto-config/%sOrganizations/%s/%ss/%s/msp/signcerts/%s-cert.pem";


    /**
     * User cryto config related properties
     */
    /**
     * A {@link String} representing the template that is used to retrieve the keystore directory of a peerAdmin user
     *
     * The template assumes the following structure:
     *
     * <i>channel.path</i>/crypto-config/<i>endpointType</i>Organizations/<i>domainName</i>/<i>endpointType</i>s/<userNameWithDomain>/msp/signcerts/<userNameWithDomain>-cert.pem
     *
     * This information is fetched from the configuration.
     */

    public static final String USER_KEYSTORE_PATH_TEMPLATE = "%s/crypto-config/%sOrganizations/%s/%ss/%s/msp/keystore";
    /**
     * A {@link String} containing the name of the property that points to the keystore file
     * for a user.
     */
    public static final String PROPERTY_USER_KEYSTORE = "keystore";
    /**
     * A {@link String} containing the name of the property that points to the certificate file
     * for a user.
     */
    public static final String PROPERTY_USER_CERTIFICATE = "certificate";
    /**
     * A {@link String} containing the name of the property that points to the PEM file
     * that contains the certificate for the given endpoint.
     */
    public static final String PROPERTY_ENDPOINT_PEM_FILE = "pemFile";


    /**
     * Endpoint related properties. These properties are used to compose the set of
     * properties that are associated to a specific endpoint and primarily cover the
     * SSL configuration of such endpoint.
     */
    /**
     * A {@link String} containing the name of the property that points to the PEM file
     * that contains the certificate for the given endpoint.
     */
    public static final String PROPERTY_ENDPOINT_PEM_BYTES = "pemBytes";
    /**
     * A {@link String} containing the name og the property that points to the property
     * that determines whether the client should trust the server certificate or not. By
     * default this property is set to {@link DefaultConfiguration#ENDPOINT_TRUST_SERVER_CERTIFICATE_DEFAULT}.
     */
    public static final String PROPERTY_ENDPOINT_TRUST_SERVER_CERTIFICATE = "trustServerCertificate";
    /**
     * A {@link String} containing the name of the property that points to the hostname
     * override for the certificate. This property will contain the new hostname to use
     * in the properties that are retrieved for a given endpoint (peer, orderer, event hub).
     *
     * @see DefaultConfiguration#getPeerSettings(String)
     * @see DefaultConfiguration#getOrdererSettings(String)
     * @see DefaultConfiguration#getEventHubSettings(String)
     */
    public static final String PROPERTY_ENDPOINT_HOSTNAME_OVERRIDE = "hostnameOverride";
    /**
     * A {@link String} containing the name of the property that points to the specific SSL
     * provider used to communicate with the selected endpoint.
     */
    public static final String PROPERTY_ENDPOINT_SSL_PROVIDER = "sslProvider";
    /**
     * A {@link String} containing the name of the property that points to the specific type
     * of negotiation protocol used to communicate with the endpoint.
     */
    public static final String PROPERTY_ENDPOINT_NEGOTIATION_TYPE = "negotiationType";
    /**
     * A {@link String} containing the name of the property that points to the channel to use.
     */
    public static final String PROPERTY_CHANNEL_NAME = "channel.name";
    /**
     * A {@link String} containing the name of the property that points to the channel file that
     * describes the configuration of the channel.
     */
    public static final String PROPERTY_CHANNEL_FILE = "channel.file";
    /**
     * A {@link String} containing the name of the property that points to the absolute path of
     * the directory that contains the channel configuration.
     */
    public static final String PROPERTY_CHANNEL_PATH = "channel.path";
    /**
     * A {@link String} containing the name of the property that points to the name of the
     * chaincode module in the configuration.
     */
    public static final String PROPERTY_CHAINCODE_NAME = "chaincode.name";
    /**
     * A {@link String} containing the name of the property that points to the version of the
     * chaincode directory specified in the configuration.
     */
    public static final String PROPERTY_CHAINCODE_VERSION = "chaincode.version";
    /**
     * A {@link String} containing the name of the property that points to the root of the chaincode
     * directory specified in the configuration. It is similar to $GOPATH such that the chaincode resides
     * in a directory <i>chaincode.root/chaincode.path</i>
     */
    public static final String PROPERTY_CHAINCODE_ROOT = "chaincode.root";
    /**
     * A {@link String} containing the name of the property that points to the path of the chaincode
     * directory specified in the configuration.
     *
     * This needs to be a directoy path relative to $GOPATH/src. e.g. github.ibm.com/example/example.cc
     */
    public static final String PROPERTY_CHAINCODE_PATH = "chaincode.path";
    /**
     * A {@link String} containing the name of the property that points to the path of the chaincode
     * policy file specified in the configuration.
     */
    public static final String PROPERTY_CHAINCODE_POLICY_PATH = "chaincode.policy";
    /**
     * A {@link String} representing the separator used between name and URL for peer, orderer etc.
     */
    public static final String NAME_LOCATION_SEPARATOR = "@";
    /**
     * A {@link Logger} instance that collects all the logging messages generated by instances
     * of this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultConfiguration.class);
    /**
     * A {@link Properties} instance that is used to store all the properties that are
     * of interest for the configuration of the fabric network.
     */
    protected final Properties sdkProperties = new Properties();

    /**
     * A {@link Map} implementation that is used to store the organizations that are defined
     * in the configuration properties. The map uses the organization name (unique) as a key
     * and the corresponding {@link Organization} implementation as a value.
     */
    protected final Map<String, Organization> organizations = new HashMap<>();

    /**
     * A {@literal boolean} value indicating whether the configuration is using TLS or not. If the
     * configuration is using TLS all the URLs will be automatically converted to the corresponding
     * secure versions, before being added to the configuration of the corresponding organizations
     * (Certificate Authority, Peers, Orderers, Event Hub).
     */
    protected boolean hasTLS = false;

    /**
     * Protected constructor for subclasses
     */
    protected DefaultConfiguration() {

    }

    /**
     * Initializes an instance of {@link DefaultConfiguration} with the given set of properties.
     * The constructor loops through the set of key-value pairs defined in <i>properties</i> and copies
     * all those properties whose name starts with {@link DefaultConfiguration#FABRIC_SDK_PREFIX}.
     *
     * @param properties a {@link Properties} instance that contains the properties for the configuration
     *                   of the fabric network. It cannot be {@literal null} or an empty collection.
     * @throws IllegalArgumentException if <i>properties</i> is {@literal null} or an empty collection.
     */
    public DefaultConfiguration(Properties properties) {

        if (properties == null) {

            throw new IllegalArgumentException("Parameter 'properties' cannot be null.");
        }

        if (properties.size() <= 0) {

            throw new IllegalArgumentException("Parameter 'properties' cannot be empty.");
        }

        this.init(properties);
    }

    /**
     * 
     * @param properties
     */
    protected void init(Properties properties) {
        Properties orgProps = new Properties();

        String orgPrefix = DefaultConfiguration.FABRIC_SDK_PREFIX + DefaultConfiguration.PROPERTY_ORG_PREFIX;
        int orgPrefixPivot = orgPrefix.length();

        for (Entry<?, ?> entry : properties.entrySet()) {

            String key = (String) entry.getKey();
            String value = (String) entry.getValue();

            if (key.startsWith(orgPrefix)) {

                // we strip the prefix because it is not useful anymore.
                //
                String orgKey = key.substring(orgPrefixPivot);
                orgProps.put(orgKey, value);

            } else if (key.startsWith(DefaultConfiguration.FABRIC_SDK_PREFIX)) {

                this.sdkProperties.put(key, value);
            }
        }


        String propTLS = this.getProperty(DefaultConfiguration.PROPERTY_GLOBAL_TLS);
        if (propTLS != null) {

            propTLS = propTLS.trim();

            if (propTLS.equals(Boolean.TRUE.toString()) || propTLS.equals(Boolean.FALSE.toString())) {

                this.hasTLS = propTLS.equals(Boolean.TRUE.toString());

            } else {

                LOGGER.warn("Property {}{} has unknown value: {}.", DefaultConfiguration.FABRIC_SDK_PREFIX, DefaultConfiguration.PROPERTY_GLOBAL_TLS, propTLS);
            }
        }

        if (orgProps.size() > 0) {

            // we now need to extract the information about the organizations
            // if any.

            this.setupOrganizations(orgProps);

        }

    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Collection<Organization> getOrganizations() {

        return Collections.unmodifiableCollection(this.organizations.values());
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Organization getOrganization(String orgName) {

        return this.organizations.get(orgName);
    }



    /**
     * {@inheritDoc}
     */
    @Override
    public Properties getChaincodeSettings() {

        Properties props = new Properties();

        props.setProperty(DefaultConfiguration.PROPERTY_CHAINCODE_NAME, this.getProperty(DefaultConfiguration.PROPERTY_CHAINCODE_NAME));
        props.setProperty(DefaultConfiguration.PROPERTY_CHAINCODE_VERSION, this.getProperty(DefaultConfiguration.PROPERTY_CHAINCODE_VERSION));
        props.setProperty(DefaultConfiguration.PROPERTY_CHAINCODE_PATH, this.getProperty(DefaultConfiguration.PROPERTY_CHAINCODE_PATH));
        props.setProperty(DefaultConfiguration.PROPERTY_CHAINCODE_ROOT, this.getProperty(DefaultConfiguration.PROPERTY_CHAINCODE_ROOT));
        props.setProperty(DefaultConfiguration.PROPERTY_CHAINCODE_POLICY_PATH, this.getProperty(DefaultConfiguration
                .PROPERTY_CHAINCODE_POLICY_PATH));

        return props;
    }

    /**
     * Determines whether the current configuration contains settings for
     * configuring the connection and entities to an IBM Blockchain Platform
     * deployment of Hyperledger Fabric.
     * 
     * @return	{@literal true} if the current configuration settings contains
     * 			the property {@link DefaultConfiguration#PROP_IBP_CONFIG} or
     * 			{@literal false} otherwise.
     */
    public boolean hasIbpConfig() {
        return this.getProperty(PROP_IBP_CONFIG) != null;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Properties getChannelSettings() {

        Properties props = new Properties();

        props.setProperty(DefaultConfiguration.PROPERTY_CHANNEL_NAME, this.getProperty(DefaultConfiguration.PROPERTY_CHANNEL_NAME));
        props.setProperty(DefaultConfiguration.PROPERTY_CHANNEL_FILE, this.getProperty(DefaultConfiguration.PROPERTY_CHANNEL_FILE));

        return props;

    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Properties getEventHubSettings(String hostName) {

        return this.getEndpointProperties(DefaultConfiguration.ENDPOINT_EVENT_HUB, hostName);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Properties getPeerSettings(String hostName) {

        return this.getEndpointProperties(DefaultConfiguration.ENDPOINT_PEER, hostName);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Properties getOrdererSettings(String hostName) {

        return this.getEndpointProperties(DefaultConfiguration.ENDPOINT_ORDERER, hostName);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public int getTransactionWaitTime() {

        return Integer.parseInt(this.getProperty(DefaultConfiguration.PROPERTY_GLOBAL_INVOKE_WAIT_TIME));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getDeployWaitTime() {

        return Integer.parseInt(this.getProperty(DefaultConfiguration.PROPERTY_GLOBAL_DEPLOY_WAIT_TIME));

    }


    /**
     * {@inheritDoc}
     */
    @Override
    public int getGossipWaitTime() {

        return Integer.parseInt(this.getProperty(DefaultConfiguration.PROPERTY_GLOBAL_GOSSIP_WAIT_TIME));
    }

    /**
     * Gets the value of a property whose name is <i>name</i>. The method
     * implicitly adds the prefix to the property as specified by the value
     * of {@link DefaultConfiguration#FABRIC_SDK_PREFIX}.
     *
     * @param propertyName a {@link String} representing the name of the property to
     *                     retrieve. It cannot be {@literal null} or an empty string..
     * @return the corresponding value mapped to <i>propertyName</i>.
     * @throws IllegalArgumentException if <i>propertyName</i> is {@literal null}.
     */
    @Override
    public String getProperty(String propertyName) {

        if ((propertyName == null) || (propertyName.trim().isEmpty() == true)) {

            throw new IllegalArgumentException("Parameter 'propertyName' cannot be null or an empty string a property must have a name.");
        }

        String fullPropertyName = DefaultConfiguration.FABRIC_SDK_PREFIX + propertyName.trim();

        return this.sdkProperties.getProperty(fullPropertyName);
    }

    /**
     * This method returns the set of properties that are associated to the specific
     * endpoint selected. The
     *
     * @param endpointType a {@link String} representing the type of the endpoint this can be
     *                     one of {@link DefaultConfiguration#ENDPOINT_PEER} or {@link
     *                     DefaultConfiguration#ENDPOINT_ORDERER}.
     * @param hostName     a {@link String} representing the hostname for the specific endpoint.
     * @throws IllegalArgumentException if <i>endpointType</i> or <i>hostName</i> is {@literal null}
     *                                  or <i>endpointType</i> is not one of the following:
     *                                  <ul>
     *                                  <li>{@link DefaultConfiguration#ENDPOINT_PEER}</li>
     *                                  <li>{@link DefaultConfiguration#ENDPOINT_ORDERER}</li>
     *                                  <li>{@link DefaultConfiguration#ENDPOINT_EVENT_HUB}</li>
     *                                  </ul>
     * @return a {@link Properties} instance that is used to store the information about the
     * certificate and the SSL configuration settings associated to the endpoint.
     */
    protected Properties getEndpointProperties(String endpointType, String hostName) {

        if (endpointType == null) {

            throw new IllegalArgumentException("Parameter endPointType cannot be null.");
        }

        if (hostName == null) {

            throw new IllegalArgumentException("Parameter hostName cannot be null.");
        }

        if (endpointType.equals(ENDPOINT_PEER) || endpointType.equals(ENDPOINT_ORDERER) || endpointType.equals(ENDPOINT_EVENT_HUB)) {


            String absoluteCertPath = String.format(DefaultConfiguration.ENDPOINT_TLS_PATH_TEMPLATE,
                    this.getProperty(DefaultConfiguration.PROPERTY_CHANNEL_PATH),
                    endpointType,
                    this.getDomainName(hostName),
                    endpointType,
                    hostName);

            return this.getSSLDefaultProperties(absoluteCertPath, hostName);

        } else {

            throw new IllegalArgumentException(String.format("Parameter endpointType (value: %s) is not recognised.", endpointType));
        }
    }

    /**
     * This method returns the set of properties that are associated to the specific
     * user selected. Particularly it returns the absolute path of keystore and certificate file of the user
     *
     * @param userName   a {@link String} representing the userName for the specific user
     * @param domainName a {@link String} representing the domainName for the specific endpoint.
     * @throws IllegalArgumentException if <i>userName</i> or <i>hostName</i> is {@literal null}
     * @return a {@link Properties} instance that is used to store the information about the
     * certificate and the keystore settings associated to the user.
     */
    public Properties getUserCryptoSettings(String userName, String domainName) {

        if (domainName == null) {

            throw new IllegalArgumentException("Parameter hostName cannot be null.");
        }

        if (userName == null) {

            throw new IllegalArgumentException("Parameter userName cannot be null.");
        }


        String userId = String.format("%s@%s", userName, domainName);
        String absoluteKeystorePath = String.format(DefaultConfiguration.USER_KEYSTORE_PATH_TEMPLATE,
                this.getProperty(DefaultConfiguration.PROPERTY_CHANNEL_PATH),
                ENDPOINT_PEER,
                domainName,
                ENDPOINT_USER,
                userId);

        String absoluteCertPath = String.format(DefaultConfiguration.USER_CERT_PATH_TEMPLATE,
                this.getProperty(DefaultConfiguration.PROPERTY_CHANNEL_PATH),
                ENDPOINT_PEER,
                domainName,
                ENDPOINT_USER,
                userId,
                userId);

        Properties props = new Properties();
        props.setProperty(PROPERTY_USER_KEYSTORE, absoluteKeystorePath);
        props.setProperty(PROPERTY_USER_CERTIFICATE, absoluteCertPath);

        return props;
    }

    /**
     * Generates the default SSL properties for the endpoint that is represented by the given
     * <i>hostName</i> and identified with the given certficate file.
     *
     * @param absoluteCertPath a {@link String} representing the absolute path to the certificate file. It cannot be {@literal null}.
     * @param hostName         a {@link String} representing the host name of the endpoint. It cannot be {@literal null}.
     * @throws IllegalArgumentException if <i>absoluteCertPath</i> or <i>hostName</i> is {@literal null}
     * @return a {@link Properties} instance configured with the default properties.
     */
    protected Properties getSSLDefaultProperties(String absoluteCertPath, String hostName) {

        if (absoluteCertPath == null) {

            throw new IllegalArgumentException("Parameter 'absoluteCertPath' cannot be null.");
        }

        if (hostName == null) {

            throw new IllegalArgumentException("Parameter 'hostName' cannot be null.");
        }


        Properties props = new Properties();

        props.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_PEM_FILE, absoluteCertPath);
        props.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_SSL_PROVIDER, DefaultConfiguration.ENDPOINT_SSL_PROVIDER_DEFAULT);
        props.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_NEGOTIATION_TYPE, DefaultConfiguration.ENDPOINT_NEGOTIATION_TYPE_DEFAULT);
        props.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_TRUST_SERVER_CERTIFICATE, DefaultConfiguration.ENDPOINT_TRUST_SERVER_CERTIFICATE_DEFAULT);
        props.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_HOSTNAME_OVERRIDE, hostName);

        return props;
    }

    /**
     * This is a simple utility function that extracts (if any) the domain name from
     * the given host name. If the host name is not present, the method will return
     * {@literal null}.
     *
     * @param hostName a {@link String} containing the host name. It cannot be {@literal null}.
     * @return a {@link String} containing the domain name part of the given <i>hostName</i> if
     * any, otherwise <i></i>
     * @throws IllegalArgumentException if <i>hostName</i> is {@literal null}.
     */
    protected String getDomainName(String hostName) {

        if (hostName == null) {

            throw new IllegalArgumentException("Parameter 'hostName' cannot be null.");
        }

        int dot = hostName.indexOf(".");
        if (-1 == dot) {
            return null;
        } else {
            return hostName.substring(dot + 1);
        }

    }

    /**
     * This method extracts and partitions the information about the organizations configured with
     * the fabric network from the given collection of properties. The method first separates the
     * different organizations properties and then generates the corresponding {@link Organization}
     * instances.
     *
     * @param orgProps a {@link Properties} instance that stores all the configuration parameters
     *                 for all the organizations. It cannot be {@literal null}.
     * @throws IllegalArgumentException if <i>orgProps</i> is {@literal null}.
     */
    protected void setupOrganizations(Properties orgProps) {

        if (orgProps == null) {

            throw new IllegalArgumentException("Parameter 'orgProps' cannot be null.");
        }

        // The structure of the organization properties is as follows:
        //
        // orgName1.mspid = ....
        // orgName1.domainName = ....
        // orgName1.peer.locations = ....
        // ...
        // ...
        // orgName2.mspid = .....
        // orgName2.domainName = ....
        // ...
        // ...
        // orgNameI.mspid = ....
        // ...
        //
        // The information that we need to setup an organization is at least
        // composed by two elements: name and mspid. This information is contained
        // in one key.

        for (Entry<?, ?> pair : orgProps.entrySet()) {

            String key = (String) pair.getKey();
            if (key.endsWith(DefaultConfiguration.PROPERTY_ORG_MSP_ID)) {
                // ok we found the pivot.

                String orgName = key.substring(0, key.indexOf('.'));
                Organization org = new DefaultOrganization(orgName, (String) pair.getValue());

                this.organizations.put(orgName, org);
            }
        }

        // we now iterate over all the other properties and pull out all the
        // other optional properties that we use to setup the content of the
        // DefaultFabricOrg instance.

        for (Entry<String, Organization> pair : this.organizations.entrySet()) {

            // for each organization, we need to collect the following information
            //
            // domainName
            // ca.location
            // peer.locations
            // orderer.locations
            // eventHub.locations

            DefaultOrganization org = (DefaultOrganization) this.organizations.get(pair.getKey());
            String orgName = pair.getKey();

            // Signed cert
            String signedCert = this.getOrgProperty(orgProps, orgName, DefaultConfiguration.PROPERTY_ORG_SIGNED_CERT);
            if (signedCert != null) {
                org.setSignedCert(signedCert);
            }

            // Domain Name
            //
            String domainName = this.getOrgProperty(orgProps, orgName, DefaultConfiguration.PROPERTY_ORG_DOMAIN_NAME);
            if (domainName != null) {

                org.setDomainName(domainName);
            }

            // CA Location
            //
            String value = this.getOrgProperty(orgProps, orgName, DefaultConfiguration.PROPERTY_ORG_CA_LOCATION);
            if (value != null) {

                if (this.hasTLS == true) {

                    Properties caProperties = new Properties();

                    String caCert = this.getOrgProperty(orgProps, orgName, DefaultConfiguration.PROPERTY_ORG_CA_CERT);
                    if (caCert != null) {
                        caProperties.put(DefaultConfiguration.PROPERTY_ENDPOINT_PEM_BYTES, certToBytes(caCert));
                    } else {
                        // if it is TLS we need to secure the endpoint and then we need to add additional
                        // properties that are required by the certificate authority.
                        //
                        value = value.replaceAll(DefaultConfiguration.PROTOCOL_HTTP_REGEX,
                                DefaultConfiguration.PROTOCOL_HTTPS);

                        // information about the CA certificate location and othe details.
                        //
                        String absoluteCertPath = String
                                .format(DefaultConfiguration.ENDPOINT_CA_TLS_PATH_TEMPLATE,
                                        this.getProperty(DefaultConfiguration.PROPERTY_CHANNEL_PATH),
                                        domainName,
                                        domainName);

                        caProperties.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_PEM_FILE,
                                absoluteCertPath);
                    }
                    caProperties.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_CA_ALLOW_HOSTNAMES, DefaultConfiguration.ENDPOINT_CA_ALLOW_HOSTNAMES_DEFAULT);
                    org.setCAProperties(caProperties);
                }

                org.setCALocation(value);
            }


            // Peer Locations
            //
            Map<String, String> locations = new HashMap<String, String>();
            value = this.getOrgProperty(orgProps, orgName, DefaultConfiguration.PROPERTY_ORG_PEER_LOCATIONS);
            try {
                this.parseLocations(value, locations);
                for (Entry<String, String> location : locations.entrySet()) {

                    String url = this.checkGrpcUrl(location.getValue());
                    org.addPeerLocation(location.getKey(), url);
                }
            } catch (ParseException pex) {

                LOGGER.warn(String.format("Could not parse parameter %s for organization %s: %s.", DefaultConfiguration.PROPERTY_ORG_PEER_LOCATIONS, orgName, pex.getMessage()), pex);
            }
            locations.clear();

            // Orderer Locations
            //
            value = this.getOrgProperty(orgProps, orgName, DefaultConfiguration.PROPERTY_ORG_ORDERER_LOCATIONS);
            try {
                this.parseLocations(value, locations);
                for (Entry<String, String> location : locations.entrySet()) {

                    String url = this.checkGrpcUrl(location.getValue());
                    org.addOrdererLocation(location.getKey(), url);
                }
            } catch (ParseException pex) {
                LOGGER.warn(String.format("Could not parse parameter %s for organization %s: %s.", DefaultConfiguration.PROPERTY_ORG_ORDERER_LOCATIONS, orgName, pex.getMessage()), pex);
            }
            locations.clear();

            // EventHub Locations
            //
            value = this.getOrgProperty(orgProps, orgName, DefaultConfiguration.PROPERTY_ORG_EVENT_HUB_LOCATIONS);
            try {
                this.parseLocations(value, locations);
                for (Entry<String, String> location : locations.entrySet()) {

                    String url = this.checkGrpcUrl(location.getValue());
                    org.addEventHubLocation(location.getKey(), url);
                }
            } catch (ParseException pex) {
                LOGGER.warn(String.format("Could not parse parameter %s for organization %s.", DefaultConfiguration.PROPERTY_ORG_EVENT_HUB_LOCATIONS, orgName), pex);
            }
            locations.clear();

        }


    }

    // [CV] NOTE: this would be a better implementation of the three sections of code repeated above if we had function pointers.
    //			  It would reduce to the following lines:
    //
    //            this.setupEndpoint(orgProps, org, DefaultFabricNetworkSettings.PROPERTY_ORG_PEER_LOCATIONS, (String name, String location) -> { org.addPeerLocation(name, location); });
    //            this.setupEndpoint(orgProps, org, DefaultFabricNetworkSettings.PROPERTY_ORG_ORDERER_LOCATIONS, (String name, String location) -> { org.addOrdererLocation(name, location); });
    //			  this.setupEndpoint(orgProps, org, DefaultFabricNetworkSettings.PROPERTY_ORG_EVENT_HUB_LOCATIONS, (String name, String location) -> { org.addEventHubLocation(name, location); });
    //
    // protected void setupEndpoint(Properties orgProps, DefaultFabricOrg org, String endpointType, pointer: (string, string)) {
    //
    //	Map<String,String> locations = new HashMap<String,String>();
    //	String value = this.getOrgProperty(orgProps, org.getName(), endpointType);
    //	try {
    //		this.parseLocations(value, locations);
    //		for(Entry<String,String> location : locations.entrySet()) {
    //
    //			String url = this.checkGrpcUrl(location.getValue());
    //
    //			pointer(location.getKey(), location.getValue());
    //		}
    //	} catch(ParseException pex) {
    //		LOGGER.warn(String.format("Could not parse parameter %s for organization %s.", endpointType, orgName), pex);
    //	}
    //
    // }


    /**
     * This method extract the value of the property that is composed by combining the
     * name of the organization with the specific organization property from the given
     * container of properties.
     *
     * @param props        a {@link Properties} instance containing the properties to
     *                     lookup for. It cannot be {@literal null}.
     * @param orgName      a {@link String} instance  containing the name of the organization
     *                     whose properties are of interest for the search. It cannot be {@literal
     *                     null}.
     * @param propertyName a {@link String} instance containing the name of the organization
     *                     property that is of interest. It cannot be {@literal null}.
     * @throws IllegalArgumentException if <i>props</i>, <i>orgName</i>, or <i>propertyName</i>
     *                                  is {@literal null}.
     * @return a {@link String} containing the value of the property if found.
     */
    protected String getOrgProperty(Properties props, String orgName, String propertyName) {

        if (props == null) {
            throw new IllegalArgumentException("Parameter 'props' cannot be null.");
        }
        if (orgName == null) {
            throw new IllegalArgumentException("Parameter 'orgName' cannot be null.");
        }
        if (propertyName == null) {
            throw new IllegalArgumentException("Parameter 'propertyName' cannot be null.");
        }

        return props.getProperty(orgName + '.' + propertyName);
    }

    /**
     * This method parses the given <i>input</i> and stores the pair (<i>name</i>,<i>location</i>) into the
     * given map <i>container</i>. The method parses the input string according to the following format:
     *
     * <code>
     * input ::=  OPEN_SQUARE_BRACKET [ pair { COMMA pair } ] CLOSE_SQUARE_BRACKET
     * pair  ::=  url AT url
     *
     *
     * OPEN_SQUARE_BRACKET  ::= '['
     * CLOSE_SQUARE_BRACKET ::= ']'
     * COMMA                ::= ','
     * AT                   ::= '@'
     * </code>
     *
     * @param input     a {@link String} instance representing the input to parse. It cannot be {@literal null}.
     * @param container a {@link Map} implementation that will store the pairs (name,location) parsed from the
     *                  given <i>input</i>.  It cannot be {@literal null}.
     * @throws IllegalArgumentException if <i>input</i> or <i>container</i> is {@literal null}.
     * @throws ParseException           if <i>input</i> does not conform to the expected structure.
     */
    protected void parseLocations(String input, Map<String, String> container) throws ParseException {


        // [CV] NOTE: we could write a parser according to the grammar above but
        //            I think it is an overkill. Hence, we do a simple parsing
        //            that is a bit inefficient, but is less logic to write.

        if (input == null) {

            throw new IllegalArgumentException("Parameter 'input' cannot be null.");
        }

        if (container == null) {

            throw new IllegalArgumentException("Parameter 'container' cannot be null.");
        }

        // we clean the input from some spurious spaces
        // at the beginning and at the end of the string.
        //
        input = input.trim();

        if (input.isEmpty()) {

            throw new ParseException("Parameter 'input' is an empty string.", 0);
        }

        if (input.startsWith("[") && input.endsWith("]")) {

            // do we have something within the brackets?
            //
            if (input.length() > 2) {


                // yes, we do..

                input = input.substring(1, input.length() - 1);
                input = input.trim();

                String[] pairs = null;

                // do we have one or more entries in the
                // array?
                //
                if (input.indexOf(',') > -1) {

                    pairs = input.split(",");

                } else {

                    pairs = new String[]{input};
                }

                for (int i = 0; i < pairs.length; i++) {

                    String pair = pairs[i].trim();
                    if (pair.indexOf(NAME_LOCATION_SEPARATOR) > -1) {

                        String[] nameLocation = pair.split(NAME_LOCATION_SEPARATOR);
                        if (nameLocation.length != 2 || nameLocation[0].trim().isEmpty() || nameLocation[1].trim().isEmpty()) {

                            throw new ParseException(String.format("Parameter 'input' has invalid pair structure (expected: name@location, found: %s)", pair), -1);
                        }

                        container.put(nameLocation[0].trim(), nameLocation[1].trim());
                    }
                }
            }

        } else
            throw new ParseException("Parameter 'input' is not of the expected structure, (expected: [ ... ]).", -1);

    }

    /**
     * Checks whether the given url is a valid GRPC url and updates it according to the value of
     * the TLS flag that is configured with the current configuration instance.
     *
     * @param url a {@link String} containing the url to verify.
     * @throws ParseException if there is any error while checking the url.
     * @return a {@link String} that matches the given <i>url</i>, whose protocol has been updated
     * to the corresponding secure version if the TLS flag is set to {@literal true}.
     */
    protected String checkGrpcUrl(String url) throws ParseException {

        Exception ex = Utils.checkGrpcUrl(url);
        if (ex != null) {

            throw new ParseException("Invalid GRPC url: " + url, 0);
        }
        if (this.hasTLS == true) {

            url = url.replaceAll(DefaultConfiguration.PROTOCOL_GRPC_REGEX, DefaultConfiguration.PROTOCOL_GRPCS);
        }

        return url;
    }

    /**
     * This is a utility method that is used to convert the string representation of a PEM certificate into
     * its corresponding bytes.
     * 
     * @param cert	a {@link String} representing the base64 encoding of the PEM certificate. It is expected
     * 				to not to be {@literal null}.
     * 
     * @return 	the array of bytes representing the PEM certificate, stripped of the header and footer and all
     * 			the new lines characters. It is guaranteed to not to be {@literal null}.
     * 
     * @throws IllegalArgumentException	if there is any error while parsing the certificate.
     */
    public static byte[] certToBytes(String cert) {

        byte[] pemBytes;
        try {
            pemBytes = Base64.getDecoder().decode(cert.replaceAll("-----(BEGIN|END) CERTIFICATE-----", "")
                            						  .replaceAll("(\n|\r\n)", "")
                            						  .getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException(String.format("Could not parse certificate: %s", e.getMessage()), e);
        }

        return pemBytes;
    }
}
