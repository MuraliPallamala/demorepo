package com.ibm.au.bgx.fabric.model;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 * Class <b>DefaultEnrollmentSerializer</b>. This class serialize an instance of
 * {@link DefaultEnrollment}
 *
 * This PrivateKey field cannot be automatically serialized, we are using custom
 * serializer and deserializer This serializer converts the whole object to byte
 * array for storage.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * @todo Add description
 */

public class DefaultEnrollmentSerializer extends StdSerializer<DefaultEnrollment> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3933388885582096710L;

	public DefaultEnrollmentSerializer() {
		this(null);
	}

	public DefaultEnrollmentSerializer(Class<DefaultEnrollment> t) {
		super(t);
	}

	@Override
	public void serialize(DefaultEnrollment defaultEnrollment, JsonGenerator jsonGenerator,
			SerializerProvider serializerProvider) throws IOException {

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			ObjectOutputStream oos = new ObjectOutputStream(bos);
			oos.writeObject(defaultEnrollment);
			oos.flush();
			jsonGenerator.writeBinary(bos.toByteArray());
			bos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
