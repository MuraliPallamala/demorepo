package com.ibm.au.bgx.fabric.model;

import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.User;
import org.hyperledger.fabric_ca.sdk.HFCAClient;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;


/**
 * Class <b>DefaultOrganization</b>. This class provides a default implementation of the {@link Organization}
 * interface. This class also provides convenient setters for the corresponding properties instances that
 * implement {@link Organization} can be easily configured and set up.
 *
 * @author Christian Vecchiola
 */
public class DefaultOrganization implements Organization {

    /**
     * A {@link String} that contains the name of the organization.
     */
    protected final String name;
    /**
     * A {@link String} that contains the unique identifier of the
     * membership services provider.
     */
    protected final String mspid;

    /**
     * A {@link String} that contains the name of the domain that
     * is mapped to the organization.
     */
    protected String domainName;

    /**
     * A {@link User} that represent the administrator of the
     * organization.
     */
    protected User admin;

    /**
     * A {@link Map} that acts as local cache for the users that
     * are registered with the organization.
     */
    protected Map<String, User> userMap = new HashMap<String, User>();

    /**
     * A {@link HFCAClient} instance that is used to talk to the
     * certificate authority configured with the organization.
     */
    protected HFCAClient caClient;
    /**
     * A {@link String} containing the location (url including port and protocol)
     * that is used to interact with the certificate authority registered with the
     * organization.
     */
    protected String caLocation;
    /**
     * A {@link Properties} instance that holds the configuration settings/attributes
     * of the certificate authority configured with the organization.
     */
    protected Properties caProperties = null;

    /**
     * A {@link Set} containing the list of {@link Peer} instances representing
     * peers in the organization.
     */
    protected Set<Peer> peers = new HashSet<Peer>();

    /**
     * A {@link User} implementation that contains information about the administrator
     * of the organization.
     */
    protected User peerAdmin;
    /**
     * A {@link Map} that correlates the name of the peers in the organization to the
     * corresponding URLs that are used to communicate with them.
     */
    protected Map<String, String> peerLocations = new HashMap<String, String>();
    /**
     * A {@link Map} that correlates the name of the orderers in the organization to the
     * corresponding URLs that are used to communicate with them.
     */
    protected Map<String, String> ordererLocations = new HashMap<String, String>();
    /**
     * A {@link Map} that correlates the name of the event hubs in the organization to the
     * corresponding URLs that are used to communicate with them.
     */
    protected Map<String, String> eventHubLocations = new HashMap<String, String>();

    /**
     * A {@link String} containing signed certificate for org admin
     */
    protected String signedCert;

    /**
     * Initialise an instance of {@link DefaultOrganization} with the given <i>name</i>
     * and membership services provider identifier.
     *
     * @param name  a {@link String} containing the name of the organization. It cannot
     *              be {@literal null}.
     * @param mspid a {@link String} containing the name of the unique identifier of the
     *              membership services provider. It cannot be {@literal null}.
     * @throws IllegalArgumentException if <i>name>/i> or <i>mspid</i> is {@literal null}.
     */
    public DefaultOrganization(String name, String mspid) {

        if (name == null) {

            throw new IllegalArgumentException("Parameter 'name' cannot be null.");
        }
        this.name = name;

        if (mspid == null) {

            throw new IllegalArgumentException("Parameter 'mspid' cannot be null.");
        }
        this.mspid = mspid;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getMSPID() {
        return mspid;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getDomainName() {
        return domainName;
    }

    /**
     * Sets the domain name for the organization.
     *
     * @param domainName a {@link String} representing the domain name
     *                   of the organization.
     */
    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public User getAdmin() {
        return admin;
    }

    /**
     * Sets the administrator for the organization.
     *
     * @param admin a {@link User} implementation that represents the
     *              administrator for the organization.
     */
    public void setAdmin(User admin) {
        this.admin = admin;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public User getUser(String name) {
        return userMap.get(name);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public HFCAClient getCAClient() {

        return caClient;
    }

    /**
     * Sets the client used to communicate with the certificate authority configured
     * with the organization.
     *
     * @param caClient a {@link HFCAClient} instance.
     */
    public void setCAClient(HFCAClient caClient) {

        this.caClient = caClient;
    }



    /**
     * {@inheritDoc}
     */
    @Override
    public String getCALocation() {
        return this.caLocation;
    }

    /**
     * Sets the url (including protocol and port) of the certificate authority.
     *
     * @param caLocation a {@link String} representing the url (including protocol
     *                   and port) of the certificate authority.
     */
    public void setCALocation(String caLocation) {
        this.caLocation = caLocation;
    }



    /**
     * {@inheritDoc}
     */
    @Override
    public Properties getCAProperties() {
        return caProperties;
    }

    /**
     * Sets the properties/attributes of the certificate authority configured with
     * this organization.
     *
     * @param CAProperties a {@link Properties} instance holding the attributes of
     *                     the certificate authority configured with the organization.
     */
    public void setCAProperties(Properties CAProperties) {
        this.caProperties = CAProperties;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public User getPeerAdmin() {
        return peerAdmin;
    }

    /**
     * Sets the administrator for the peer.
     *
     * @param peerAdmin a {@link User} representing the administrator of the peer.
     */
    public void setPeerAdmin(User peerAdmin) {
        this.peerAdmin = peerAdmin;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<String> getPeerNames() {

        return Collections.unmodifiableSet(peerLocations.keySet());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Collection<String> getPeerLocations() {
        return Collections.unmodifiableCollection(peerLocations.values());
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public String getPeerLocation(String name) {
        return peerLocations.get(name);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<String> getOrdererNames() {

        return Collections.unmodifiableSet(ordererLocations.keySet());
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Collection<String> getOrdererLocations() {
        return Collections.unmodifiableCollection(ordererLocations.values());
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public String getOrdererLocation(String name) {
        return ordererLocations.get(name);

    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Set<String> getEventHubNames() {

        return Collections.unmodifiableSet(eventHubLocations.keySet());
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Collection<String> getEventHubLocations() {
        return Collections.unmodifiableCollection(eventHubLocations.values());
    }

    /**
     * Gets the signed cert for the org admin
     *
     * @return a {@link String} containing signed PEM file contents
     */
    @Override
    public String getSignedCert() {
        return signedCert;
    }

    /**
     * Sets the signed cert for the org admin
     *
     * @param signedCert a {@link String} containing signed PEM file contents
     */
    public void setSignedCert(String signedCert) {
        this.signedCert = signedCert;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public String getEventHubLocation(String name) {
        return eventHubLocations.get(name);

    }

    /**
     * Adds a user to the organization.
     *
     * @param user a {@link User} implementation that represents a
     *             user in the organization.
     */
    public void addUser(User user) {
        userMap.put(user.getName(), user);
    }

    /**
     * Adds a {@link Peer} to the list of peers that are configured with the
     * organization.
     *
     * @param peer a {@link Peer} instance representing a peer. It cannot be {@literal null}.
     */
    public void addPeer(Peer peer) {

        if (peer == null) {

            throw new IllegalArgumentException("Parameter 'peer' cannot be null.");
        }
        peers.add(peer);

        // [CV] NOTE: we need to add the peer also to the peer location otherwise
        //			  the two collections go out of sync.
        //
        if (!peerLocations.containsKey(peer.getName())) {
            peerLocations.put(peer.getName(), peer.getUrl());
        }
    }

    /**
     * Adds a mapping (peer name, peer url) to the organization.
     *
     * @param name     a {@link String} representing the name of the peer.
     * @param location a {@link String} representing the url of the peer.
     */
    public void addPeerLocation(String name, String location) {

        peerLocations.put(name, location);

        // [CV] NOTE: how to keep in sync with the peers set?
    }

    /**
     * Adds a mapping (orderer name, orderer url) to the organization.
     *
     * @param name     a {@link String} representing the name of the orderer.
     * @param location a {@link String} representing the url of the orderer.
     */
    public void addOrdererLocation(String name, String location) {

        ordererLocations.put(name, location);
    }

    /**
     * Adds a mapping (event hub name, event hub url) to the organization.
     *
     * @param name     a {@link String} representing the name of the event hub.
     * @param location a {@link String} representing the utl of the event hub.
     */
    public void addEventHubLocation(String name, String location) {

        eventHubLocations.put(name, location);
    }

}
