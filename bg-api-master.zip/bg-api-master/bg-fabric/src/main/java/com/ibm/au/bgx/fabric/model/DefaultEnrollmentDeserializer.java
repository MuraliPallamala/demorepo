package com.ibm.au.bgx.fabric.model;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 * Class <b>DefaultEnrollmentDeserializer</b>. This class deserialize an
 * instance of {@link DefaultEnrollment}
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * @todo Add description
 */

public class DefaultEnrollmentDeserializer extends StdDeserializer<DefaultEnrollment> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2695150275658777598L;

	public DefaultEnrollmentDeserializer() {
		this(null);
	}

	public DefaultEnrollmentDeserializer(Class<DefaultEnrollment> t) {
		super(t);
	}

	@Override
	public DefaultEnrollment deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
			throws IOException, JsonProcessingException {

		DefaultEnrollment enrollment;
		ByteArrayInputStream bis = new ByteArrayInputStream(jsonParser.getBinaryValue());
		try {
			ObjectInputStream ois = new ObjectInputStream(bis);
			enrollment = (DefaultEnrollment) ois.readObject();
		} catch (ClassNotFoundException e) {
			throw new IOException(String.format("Could not deserialize default enrollment: %s", e.getMessage()), e);
		}

		return enrollment;
	}

}
