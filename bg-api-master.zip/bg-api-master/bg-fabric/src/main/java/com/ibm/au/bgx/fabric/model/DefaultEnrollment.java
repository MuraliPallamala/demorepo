package com.ibm.au.bgx.fabric.model;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


/**
 * Class <i>DefaultEnrollment</i>. This class is the default implementation of the {@link org.hyperledger.fabric.sdk.Enrollment}
 * interface. It provides a default behaviour to store the user enrollment certificate.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com> 
 */

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import org.hyperledger.fabric.sdk.Enrollment;

import java.io.Serializable;
import java.security.PrivateKey;

@JsonSerialize(using = DefaultEnrollmentSerializer.class )
@JsonDeserialize(using = DefaultEnrollmentDeserializer.class )
public class DefaultEnrollment implements Enrollment, Serializable {
  private static final long serialVersionUID = 870416591376968096L;
  protected final PrivateKey key;
  protected final String cert;

  public DefaultEnrollment(PrivateKey privateKey, String signedPem) {
    this.key = privateKey;
    this.cert = signedPem;
  }

  public DefaultEnrollment(Enrollment enrollment) {
    this.key = enrollment.getKey();
    this.cert = enrollment.getCert();
  }

  public PrivateKey getKey() {
    return this.key;
  }

  public String getCert() {
    return this.cert;
  }
}
