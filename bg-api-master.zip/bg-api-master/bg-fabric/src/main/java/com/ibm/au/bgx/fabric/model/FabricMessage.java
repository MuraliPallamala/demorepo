package com.ibm.au.bgx.fabric.model;


import java.text.ParseException;
import java.util.Map;


/**
 * Class <b>FabricMessage</b>. This class wraps the information that represents a
 * response to a proposal request, or transaction invocation. The instance stores
 * information about the status code and a text message, which can be eventually
 * parsed into a {@link Map} implementation, being assumed as a JSON structure.
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class FabricMessage {
	
	/**
	 * A {@link String} constant that is used to identify the beginning of the
	 * text fragment that contains information about the message status.
	 */
	public static final String STATUS_HEADER = "Status{";
	/**
	 * A {@link String} constant that is used to identify the end of the text fragment
	 * that contains information about the message status.
	 */
	public static final String STATUS_FOOTER = "}";
	/**
	 * A {@link String} constant that is used to locate in the status fragment the
	 * information that is associated to the status of the message. This value is
	 * assigned to an attribute that is named <i>code</i>.
	 */
	public static final String CODE_PREAMBLE = "code=";
	/**
	 * A {@link String} constant that is used to locate in the status fragment the
	 * information that is associated to the description of the message. This value 
	 * is assigned to an attribute that is named <i>description</i>.
	 */
	public static final String DESCRIPTION_PREAMBLE = "description=";
	/**
	 * A {@link String} constant that is used to locate in the status fragment the
	 * information that is associated to the original cause of the message. This value 
	 * is assigned to an attribute that is named <i>cause</i>.
	 */
	public static final String CAUSE_PREAMBLE = "cause=";

	/**
	 * A {@literal int} constant that represents a chaincode error status that has
	 * been not set. This is the value returned by {@link FabricMessage#getChaincodeStatusCode()}
	 * when the instance of {@link FabricMessage} has no information about the error
	 * status code.
	 */
	public static final int CHAINCODE_STATUS_NOT_SET = -1;
	
    /**
     * A {@link String} representing the header of the status code in the response
     * message. This string is utilized by {@link FabricMessage#parse(String)} to
     * identify the portion of the string that contains information about the status
     * code of the response.
     */
    public static final String ERROR_CODE_HEADER = "(status:";
    /**
     * A {@link String} representing the header of the message part in the response
     * message. This string is utilized by {@link FabricMessage#parse(String)} to
     * identify the portion of the string that contains information about the text
     * message that can be eventually interpreted as a JSON structure.
     */
    public static final String MESSAGE_HEADER = "message:";
    /**
     * A {@link String} that represents the end character (interpreted as the last
     * occurring one) for the section in the message that contains the status details.
     * This character is utilized by {@link FabricMessage#parse(String)} to cut out
     * the section of the message that identifies the status message.
     */
    public static final String ERROR_CODE_FOOTER = ")";
    /**
     * A {@literal char} that represents the separator beetween the status code and
     * the status message in the portion that identifies the status details in the
     * response. Within that fragment the character is interpreted as first occurring.
     * This character is utilized by {@link FabricMessage#parse(String)} to separate
     * the status code section from the status message section.
     */
    public static final char COMMA = ',';


    /**
     * A {@literal int} representing the status code of the chaincode invocation that
     * has generated this message. This value may or may not be set according to whether
     * the error is associated to a chaincode invocation.
     */
    protected int chaincodeStatus;
    /**
     * A {@link String} representing the content of the message attribute that has been 
     * returned by the chaincode that originated this message.
     */
    protected String chaincodeMessage;
    /**
     * A {@link String} representing the status message of the response.
     */
    protected String rawMessage;
    
    /**
     * A {@link String} representing the status information that is stored in the current
     * instance of {@link FabricMessage}, this is the value assigned to the attribute
     * {@link FabricMessage#CODE_PREAMBLE}.
     */
    protected String code;
    /**
     * A {@link String} representing the original cause that triggered the error associated 
     * to the current instance of {@link FabricMessage}. This is the value that is assigned
     * to the attribute {@link FabricMessage#CAUSE_PREAMBLE}.
     */
    protected String cause;
    /**
     * A {@link String} representing the description of the error that triggered the current
     * instance of {@link FabricMessage}. This is the value that is assigned to the attribute
     * {@link FabricMessage#DESCRIPTION_PREAMBLE} and the one that may contain the details
     * about the chaincode error if any.
     */
    protected String description;
    
    

    /**
     * Initializes an instance of {@link FabricMessage} with the given attributes. This constructor
     * can be used to create instances of {@link FabricMessage} that originate from non-chaincode
     * errors (e.g. chaincode starting and other types of errors). This constructor then invokes
     * {@link FabricMessage#FabricMessage(String, String, String, String, int, String)} by setting
     * the last two parameters to {@link FabricMessage#CHAINCODE_STATUS_NOT_SET} and {@literal null}.
     * 
     * @param rawMessage		a {@link String} representing the original message that has been
     * 							returned by the Hyperledger Fabric client. It cannot be {@literal null}.
     * 
     * @param code				a {@literal String} representing the status value associated to the
     * 							message <i>rawMessage</i>. This parameter is set to the value that
     * 							is associated to {@link FabricMessage#CAUSE_PREAMBLE} in <i>rawMessage</i>.
     * 							It cannot be {@literal null}.
     * 
     * @param description		a {@literal String} representing the description of the error represented
     * 							by <i>rawMessage</i>. This parameter is set to the value that is associated 
     * 							to {@link FabricMessage#DESCRIPTION_PREAMBLE} in <i>rawMessage</i>.
     * 							It cannot be {@literal null}.
     * 
     * @param cause				a {@link String} representing the original error cause associated to the
     * 							error message <i>rawMessage</i>. This parameter is set to the value that 
     * 							is associated to {@link FabricMessage#CAUSE_PREAMBLE} in <i>rawMessage</i>.
     * 							It cannot be {@literal null}.
     * 
     * @throws IllegalArgumentException if any of the arguments that have been passed is {@literal null}.
     */
    public FabricMessage(String rawMessage, String code, String description, String cause) {
    	this(rawMessage, code, description, cause, FabricMessage.CHAINCODE_STATUS_NOT_SET, null);
    }
    
    /**
     * Initializes an instance of {@link FabricMessage} with the given attributes. 
     * 
     * @param rawMessage		a {@link String} representing the original message that has been returned 
     * 							by the Hyperledger Fabric client. It cannot be {@literal null}.
     * 
     * @param code				a {@literal String} representing the status value associated to the
     * 							message <i>rawMessage</i>. This parameter is set to the value that
     * 							is associated to {@link FabricMessage#CAUSE_PREAMBLE} in <i>rawMessage</i>.
     * 							It cannot be {@literal null}.
     * 
     * @param description		a {@literal String} representing the description of the error represented
     * 							by <i>rawMessage</i>. This parameter is set to the value that is associated 
     * 							to {@link FabricMessage#DESCRIPTION_PREAMBLE} in <i>rawMessage</i>.
     * 							It cannot be {@literal null}.
     * 
     * @param cause				a {@link String} representing the original error cause associated to the
     * 							error message <i>rawMessage</i>. This parameter is set to the value that 
     * 							is associated to {@link FabricMessage#CAUSE_PREAMBLE} in <i>rawMessage</i>.
     * 							It cannot be {@literal null}.
     * 
     * @param chaincodeStatus	a {@literal int} representing the chaincode error status. This is a
     * 							parameter set when <i>rawMessage</i> contains {@link FabricMessage#ERROR_CODE_FOOTER}
     * 							and represents error messages that originate from chaincode invocations, rather
     * 							than other types of errors. When the created instance of {@link FabricMessage}
     * 							does not represent a chaincode invocation error, this value should be set to
     * 							{@link FabricMessage#CHAINCODE_STATUS_NOT_SET}.
     * 
     * @param chaincodeMessage	a {@link String} containing the error message returned by the chaincode as
     * 							additional context associated to the error. This value is not {@literal null}
     * 							when the <i>rawMessage</i> contains a fully formed fragment indicating the
     * 							chaincode error details (i.e. a text fragment delimited by {@link FabricMessage#ERROR_CODE_FOOTER}
     * 							and {@link FabricMessage#ERROR_CODE_HEADER}.
     * 
     * @throws IllegalArgumentException if any of <i>rawMessage</i>, <i>code</i>, <i>description</i> or <i>cause</i> is {@literal null}.
     */
    public FabricMessage(String rawMessage, String code, String description, String cause, int chaincodeStatus, String chaincodeMessage) {

    	if (rawMessage == null) {
    		throw new IllegalArgumentException("Parameter 'rawMessage' cannot be null.");
    	}
    	if (code == null) {
    		throw new IllegalArgumentException("Parameter 'code' cannot be null.");
    	}
    	if (description == null) {
    		throw new IllegalArgumentException("Parameter 'description' cannot be null.");
    	}
    	if (cause == null) {
    		throw new IllegalArgumentException("Parameter 'cause' cannot be null.");
    	}
    	
        this.rawMessage = rawMessage;
    	this.code = code;
        this.description = description;
        this.cause = cause;
        this.chaincodeStatus = chaincodeStatus;
        this.chaincodeMessage = chaincodeMessage;
    }
    /**
     * Gets the value of the status code for the response that has been returned
     * by the chaincode invocation that generated this instance of {@link FabricMessage}.
     *
     * @return	a {@literal int} representing the value of the error code generated
     * 			by the chaincode invocation, or {@link FabricMessage#CHAINCODE_STATUS_NOT_SET}
     * 			if this instance originates from a non-chaincode error.
     */
    public int getChaincodeStatusCode() {

        return this.chaincodeStatus;
    }
    /**
     * Gets the error message (if any) that has been returned by the
     * chaincode invocation that has generated the current instance of
     * {@link FabricMessage}.
     * 
     * @return	a {@link String} containing the chaincode error message or 
     * 			{@literal null} if this instance of {@link FabricMessage}
     * 			has been originated by non-chaincode errors.
     */
    public String getChaincodeMessage() {
    	
    	return this.chaincodeMessage;
    }
    
    /**
     * Gets the status of the error message associated to this instance
     * of {@link FabricMessage}.
     * 
     * @return  a {@link String} containing the status code. Usually set 
     * 			to UNKNOWN.
     */
    public String getStatus() {
    	
    	return this.code;
    }
    
    /**
     * Gets the description that has been parsed from the raw message
     * text, associated to this instance of {@link FabricMessage}.
     * 
     * @return a {@link String} containing the parsed description.
     */
    public String getDescription() {
    	
    	return this.description;
    }
    
    /**
     * Gets the original cause of the error message associated to this 
     * instance of {@link FabricMessage}.
     * 
     * @return a {@link String} containing information about the cause,
     * 		   usually set to 'null'.
     */
    public String getCause() {
    	
    	return this.cause;
    }
    
    /**
     * Gets the value of the status message.
     *
     * @return	a {@link String} representing the original
     * 			status message.
     */
    public String getRawMessage() {

        return this.rawMessage;
    }


    /**
     * <p>
     * This method parses the response string that has been returned by the fabric and creates an instance of {@link FabricMessage} if the parsing is successful.
     * </p>
     * <p>
     * This method does not implement a fully formed grammar to parse <i>rawMessage</i>, but works under the following assumptions, which are based on the instances
     * of <i>rawMessage</i> that have been observed so far:
     * <ul>
     * <li><i>rawMessage</i> contains a fragment delimited by {@link FabricMessage#STATUS_HEADER} and {@link FabricMessage#STATUS_FOOTER};</li>
     * <li>the value next to {@link FabricMessage#STATUS_HEADER} is set to the status of the message, returned by {@link FabricMessage#getStatus()};</li>
     * <li>the next pair (value=key) is identified by {@link FabricMessage#DESCRIPTION_PREAMBLE} and the value next to it represents the textual description of the error,
     * which is returned by {@link FabricMessage#getDescription()};</li>
     * <li>the next pair (value=key) is identified by {@link FabricMessage#CAUSE_PREAMBLE} and the value next to it represents the original cause of the error if any,
     * which is returned by {@link FabricMessage#getCause()};</li>
     * <li>the parsed description may contain a portion delimited by {@link FabricMessage#ERROR_CODE_HEADER} and {@link FabricMessage#ERROR_CODE_FOOTER}, and in this
     * case, the value next to {@link FabricMessage#ERROR_CODE_HEADER} is interpreted as an integer indicating the chaincode error status code associated to the message
     * and returned by {@link FabricMessage#getChaincodeStatusCode()};</li>
     * <li>if a fully formed fragment indicating a chaincode error is parsed, the next pair (value: key) is identified by {@link FabricMessage#MESSAGE_HEADER} and the
     * value next to it is associated to additional textual information passed by the chaincode together with the error status code. This value is returned by the
     * method {@link FabricMessage#getChaincodeMessage()};</li>
     * <li>all the parts are separated by {@link FabricMessage#COMMA}</li>
     * </ul>
     * Below is an example of a correct <i>rawMessage</i>:
     * </p>
     * <p>
     * <code>
     * Failed responses or inconsistent proposal set. Sending proposal to fabric-peer-org1-xxxx failed because of: gRPC failure=Status{code=UNKNOWN, 
     * description=error executing chaincode: error chaincode is already launching:  chaincode-v108:20190423_1500, cause=null}
     * </code>
     * </p>
     * <p>
     * This is an example of an error that does not contain information about the chaincode status error. An example that contains the chaincode status error is the
     * following:
     * </p>
     * <p>
     * <code>
     * Sending proposal to peer0.org1.example.com failed because of: gRPC failure=Status{code=UNKNOWN, description=chaincode error (status: 404, 
     * message: {\"id\" : \"003030302011101\", \"code\": 34 }), cause=null}
     * </code>
     * </p>
     * <p>
     * In the first example the created instance of {@link FabricMessage} will have the values of {@link FabricMessage#getChaincodeStatusCode()} and {@link 
     * FabricMessage#getChaincodeMessage()} set to {@link FabricMessage#CHAINCODE_STATUS_NOT_SET} and {@literal null} respectively. In the second case, these values
     * will be set to <code>404</code> and <code>{\"id\" : \"ICA20171202\", \"code\": 34 }</code>.
     * </p>
     *
     * @param response 	a {@link String} representing the response message raw text. It cannot be {@literal null} or an empty string.
     *
     * @return 	a {@link FabricMessage} instance with the content parsed from <i>rawMessage</i> exposed as properties.
     *
     * @throws ParseException				if there is any error in parsing <i>response</i>.
     * @throws IllegalArgumentException		if <i>response</i> is {@literal null} or
     * 										an empty string.
     *
     */
    public static FabricMessage parse(String response) throws ParseException {

        if (response == null || response.isEmpty()) {

            throw new IllegalArgumentException("Parameter 'response' cannot be null or an empty string.");
        }

        int pivot = response.indexOf(FabricMessage.STATUS_HEADER);
        if (pivot < 0) {
        	throw new ParseException(String.format("Could not find beginning of error code section '%1$s' in message: '%2$s'", FabricMessage.STATUS_HEADER, response), 0);
        }
        
        int mark = response.lastIndexOf(FabricMessage.STATUS_FOOTER);
        if (mark < 0) {
        	throw new ParseException(String.format("Incomplete status fragment, could not fund closing '%1$s' for block beginning with %2$s in message: '%3$s'", FabricMessage.STATUS_FOOTER, FabricMessage.STATUS_HEADER, response), pivot);
        }
        
        if (mark < pivot) {
        	
        	throw new ParseException(String.format("Inconsistent fragment, closing '%1$s' found before '%2$s' in message %3$s.",  FabricMessage.STATUS_FOOTER, FabricMessage.STATUS_HEADER, response), mark);
        }

        // [CV] NOTE: ok, now that we have identified the status fragment
        //            we dig into it and extract all the other pieces. We
        //            now have a structure that is composed as follows:
        //
        //            key=value, key=value, ...
        //
        //            we cannot use string.split(,) because the values can
        //            also include these separators, but we need to ensure
        //            that we read the content pair by pair and at every
        //            step do the appropriate analysis.
        //
        int pointer = pivot + FabricMessage.STATUS_HEADER.length();
        String statusFragment = response.substring(pointer, mark);
        
        
        // [CV] NOTE: first we parse code='.....',
        //
        int boundary = statusFragment.indexOf(FabricMessage.COMMA);
        if (boundary < 0) {
        	throw new ParseException(String.format("Invalid status fragment, could not find separator '%1$s' within fragment content, in message '%2$s'.", FabricMessage.COMMA, response), pointer);
        }
        
        String pair = statusFragment.substring(0, boundary);
        if (!pair.startsWith(FabricMessage.CODE_PREAMBLE)) {
        	throw new ParseException(String.format("Invalid status fragment, expected '%1$s<...>%2$s' in message: '%3$s'.", FabricMessage.CODE_PREAMBLE, FabricMessage.COMMA, response), pointer);
        }
        
        String code = pair.substring(FabricMessage.CODE_PREAMBLE.length());
        
        pointer = pointer + pair.length();
        
        // [CV] NOTE: we then need to find description='....', but
        //            in this case the boundary cannot simply be
        //            the comma, but we actually need to find the
        //            beginning of the next pair.
        //
        boundary = statusFragment.indexOf(FabricMessage.CAUSE_PREAMBLE);
        if (boundary < 0) {
        	throw new ParseException(String.format("Invalid status fragment, expected '%1$s<...>%2$s' in message: '%3$s'.", FabricMessage.CAUSE_PREAMBLE, FabricMessage.COMMA, response), pointer);
        }
        
        // [CV] NOTE: we have now found the pair that contains the pair
        //            that contains the description.
        //
        pair = statusFragment.substring(pair.length() + 1, boundary - 1)
        		             .trim();
        
        if (!pair.startsWith(FabricMessage.DESCRIPTION_PREAMBLE)) {
        	
        	throw new ParseException(String.format("Invalid status fragment, expected '%1$s<...>%2$s' in message: '%3$s'", FabricMessage.DESCRIPTION_PREAMBLE, FabricMessage.COMMA, response), pointer);
        }
        if (!pair.endsWith("" + FabricMessage.COMMA)) {
        	
        	throw new ParseException(String.format("Invalid status fragment, expeected delimter '%1$s' for description pair in message: '%2$s'.", FabricMessage.COMMA, response), pointer + pair.length());
        
        } 

        String description = pair.substring(FabricMessage.DESCRIPTION_PREAMBLE.length(), pair.length()-1);
        
        
         // [CV] NOTE: we are deferring parsing the content of the description
        //            to look for chaincode errors, and we move to parse the
        //            last pair, that should be the cause. Because we have found
        //            boundary by using the preamble text, we do not need to check
        //            again whether the pair starts with it.
        //
        pair = statusFragment.substring(boundary);
        String cause = pair.substring(FabricMessage.CAUSE_PREAMBLE.length());
        
        
        int chaincodeStatusCode = FabricMessage.CHAINCODE_STATUS_NOT_SET;
        String chaincodeMessage = null;
        
        
        mark = description.indexOf(FabricMessage.ERROR_CODE_HEADER);
        if (mark >= 0) {
        	
        	pointer = pointer + FabricMessage.DESCRIPTION_PREAMBLE.length();
            
        	// [CV] NOTE: ok we have a chaincode error, in this case and we need to
        	//            parse the rest.
        	//
        	String chaincodeFragment = description.substring(mark + FabricMessage.ERROR_CODE_HEADER.length());
        	
        	
        	pointer = pointer + FabricMessage.ERROR_CODE_HEADER.length();
        	
        	// [CV] NOTE: the next piece of code should be status code returned by the
        	//            chaincode, but first we want to parse the end of the chaincode
        	//			  fragment.
        	//
        	mark = chaincodeFragment.lastIndexOf(FabricMessage.ERROR_CODE_FOOTER);
        	if (mark < FabricMessage.ERROR_CODE_HEADER.length() + 1) {
        		
        		throw new ParseException(String.format("Invalid chaincode error fragment, expected delimiter '%1$s' in message: '%2$s'.", FabricMessage.ERROR_CODE_FOOTER, response), 
        								 pointer + chaincodeFragment.length());
        	}
        	
        	chaincodeFragment = chaincodeFragment.substring(0, mark)
        			                             .trim();
        	
        	
        	// [CV] NOTE: we are now in the following case:
        	//
        	//            <int>, message: .....
        	//
        	//            that is what is left to parse. We look
        	//            for the comma first and the we deal with
        	//            the message component.
        	//
        	
        	mark = chaincodeFragment.indexOf("" + FabricMessage.COMMA);
        	int markTwo = chaincodeFragment.indexOf(FabricMessage.MESSAGE_HEADER);
        	if (mark >= markTwo) {
        		
        		throw new ParseException(String.format("Invalid chaincode status, could not isolate error code in message: '%1$s'.", response), pointer + markTwo);
        	}
        	
        	// ok we get the delimiter for the number.
        	// let's see whether we can parse it into an integer.
        	//
        	String value = chaincodeFragment.substring(0,mark).trim();
        	try {
        		
        		chaincodeStatusCode = Integer.parseInt(value);
        		
        	} catch (NumberFormatException nfex) {

                throw new ParseException(String.format("Invalid chaincode status code, could not parse integer value from '%1$s' in mssage: '%2$s'.", value, response), pointer + mark);
                    
            }
        	
        	// ok, we now can move to the message part. We do not have
        	// to check for the message preamble because we have already
        	// found it and this is the result of having markTwo.
        	//
        	chaincodeMessage = chaincodeFragment.substring(markTwo + FabricMessage.MESSAGE_HEADER.length()).trim();
        	
        }
        
        return new FabricMessage(response, code, description, cause, chaincodeStatusCode, chaincodeMessage);
       
    }

}

