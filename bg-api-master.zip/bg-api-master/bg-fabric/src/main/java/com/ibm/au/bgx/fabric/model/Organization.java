package com.ibm.au.bgx.fabric.model;

import org.hyperledger.fabric.sdk.User;
import org.hyperledger.fabric_ca.sdk.HFCAClient;

import java.util.Collection;
import java.util.Properties;
import java.util.Set;

/**
 * <p>
 * Interface <b>FabricOrg</b>. This interface represents an organization in the fabric network.
 * A fabric organization contains information about the peers, orderers, and event-hub nodes 
 * as well as their locations (in terms of urls).
 * </p>
 * <p>
 * More specifically, this interface provides access to:
 * <ul>
 * <li>general information about the organization (name, domain name, administrator)</li>
 * <li>details about the membership services provider</li>
 * <li>details about the certificate authority (location, properties, and client to it)</li>
 * <li>details about the peers (list of peers, names, and their locations)</li>
 * <li>details about the orderers (orderers names, and their locations)</li>
 * <li>details about the event hubs (event hubs names, and their locations)</li>
 * </ul>
 * </p>
 * 
 *
 */
public interface Organization {

	// BASIC PROPERTIES
	
	/**
	 * Gets the name of the organization.
	 * 
	 * @return	a {@link String} containing the name of the organization.
	 * 			It cannot be {@literal null}.
	 */
    public String getName();

    /**
     * Gets the unique identifier of the membership services provider 
     * configured for the organization.
     * 
     * @return	a {@link String} containing the unique identifier of the
     * 			the MSP. It cannot be {@literal null}.
     */
    public String getMSPID();

    /**
     * Gets the domain name associated to the organization.
     * 
     * @return	a {@link String} containing the domain name of the 
     * 			organization.
     */
    public String getDomainName();
    
    /**
     * Gets information about the administrator for the organization. 
     * This user can register and enroll or register other users with
     * the membership services provider configured for the organization.
     * 
     * @return	a {@link User} implementation that contains the
     * 			detail of the organization administrator.
     */
    public User getAdmin();

    /**
     * Gets the user details for the user that matches the given name
     * in the organization.
     * 
     * @param name	a {@link String} containing the name of the user.
     * 				It cannot be {@literal null}.
     * 				
     * @return	a {@link User} implementation that contains the detail
     * 			for the user mapped by <i>name</i>,or {@literal null}
     * 			if there is no user mapped by <i>name</i>.
     * 
     * @throws IllegalArgumentException if <i>name</i> is {@literal null}.
     */
    public User getUser(String name);
    
    
    // CERTIFICATE AUTHORITY
    /**
     * Gets the location (url) of the certificate authority for the 
     * organization.
     * 
     * @return	a {@link String} containing the url to the certificate
     * 			authority set up for the organization.
     */
    public String getCALocation();
    
    /**
     * Gets a client that can be used to communicate with the certificate
     * authority that is configured with the organization.
     * 
     * @return	a {@link HFCAClient} instance.
     */
    public HFCAClient getCAClient();

    /**
     * Gets the configuration of the Certificate Authority for the 
     * organization.
     * 
     * @return	a {@link Properties} class containing the settings related 	
     *			to the certificate authority.
     */
    public Properties getCAProperties();
    

    // PEERS DETAILS

    /**
     * Gets the peer administrator. This can join and create channel and
     * deploy the chaincode within those channels.
     * 
     * @return	a {@link User} implementation providing information about
     * 			the chaincode administrator.
     */
    public User getPeerAdmin();
    
    /**
     * Gets the list of names of the peers in the organization.
     * 
     * @return	a {@link Set} implementation that contains the names of the
     * 			peers configured with the organization.
     */
    public Set<String> getPeerNames();

    /**
     * Gets the list of locations of the peers in the organization. A location
     * is represented by a URL (including protocol and port) that can be used
     * to communicate with the peer.
     * 
     * @return 	a {@link Set} implementation that contains the locations of the
     * 			peers configured with the organization.
     */
    public Collection<String> getPeerLocations();
    
    /**
     * Gets the location for the given peer.
     * 	
     * @param name	a {@link String} representing the name of the peer. It 
     * 				cannot be {@literal null}.
     * 
     * @return	a {@link String} representing the url to communicate with the
     * 			peer for the given <i>name</i>.
     * 
     * @throws IllegalArgumentException if <i>name</i> is {@literal null}.
     */
    public String getPeerLocation(String name);


    // ORDERERS DETAILS

    /**
     * Gets the list of names of the orderers in the organization.
     * 
     * @return	a {@link Set} implementation that contains the names of the
     * 			orderers configured with the organization.
     */
    public Set<String> getOrdererNames();
    
    /**
     * Gets the location for the given orderer.
     * 	
     * @param name	a {@link String} representing the name of the orderer. It 
     * 				cannot be {@literal null}.
     * 
     * @return	a {@link String} representing the url to communicate with the
     * 			orderer for the given <i>name</i>.
     * 
     * @throws IllegalArgumentException if <i>name</i> is {@literal null}.
     */
    public String getOrdererLocation(String name);
    
    /**
     * Gets the list of locations of the orderers in the organization. A location
     * is represented by a URL (including protocol and port) that can be used
     * to communicate with the orderer.
     * 
     * @return 	a {@link Set} implementation that contains the locations of the
     * 			peers configured with the organization.
     */
    public Collection<String> getOrdererLocations();
    
    // EVENT HUBS DETAILS

    /**
     * Gets the list of names of the event hubs in the organization.
     * 
     * @return	a {@link Set} implementation that contains the names of the
     * 			event hubs configured with the organization.
     */
    public Set<String> getEventHubNames();
    
    /**
     * Gets the location for the given event hub.
     * 	
     * @param name	a {@link String} representing the name of the event hub. It 
     * 				cannot be {@literal null}.
     * 
     * @return	a {@link String} representing the url to communicate with the
     * 			event hub for the given <i>name</i>.
     * 
     * @throws IllegalArgumentException if <i>name</i> is {@literal null}.
     */
    public String getEventHubLocation(String name);
    
    /**
     * Gets the list of locations of the event hubs in the organization. A location
     * is represented by a URL (including protocol and port) that can be used
     * to communicate with the event hub.
     * 
     * @return 	a {@link Set} implementation that contains the locations of the
     * 			event hubs configured with the organization.
     */
    public Collection<String> getEventHubLocations();


    /**
     * Gets the signed cert for the org admin
     * @return a {@link String} containing signed PEM file contents
     */
    public String getSignedCert();
}
