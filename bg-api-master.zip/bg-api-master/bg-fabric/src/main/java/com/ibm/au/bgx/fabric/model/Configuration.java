package com.ibm.au.bgx.fabric.model;

import java.util.Collection;
import java.util.Properties;
import java.util.Set;

/**
 * Interface <b>Configuration</b>. This interface provides information
 * about the configuration of the fabric network. The interface is meant to be
 * <i>read-only</i>: this means that the configuration settings that are accessed
 * through this interface cannot be modified. 
 *  
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 * @author Yuan Yuan <idayuan@sg.ibm.com>
 *
 */
public interface Configuration {
	

	
	/**
	 * Gets the configuration settings that are associated to the chaincode.
	 * 
	 * @return	a {@link Properties} object that contains the configuration
	 * 			settings for the chaincode. This instance is meant to be 
	 * 			treated as a <i>read-only</i> object, which means that any
	 * 			change made to this instance will not affect the fabric
	 * 			configuration.
	 */
	public Properties getChaincodeSettings();
	
	/**
	 * Gets the configuration settings that are associated to the channel.
	 * 
	 * @return	a {@link Properties} object that contains the configuration
	 * 			settings for the channel. This instance is meant to be 
	 * 			treated as a <i>read-only</i> object, which means that any
	 * 			change made to this instance will not affect the fabric
	 * 			configuration.
	 */
	public Properties getChannelSettings();
	
	/**
	 * Gets the configuration settings that are associated to the event hub.
	 * 
	 * @param hostName	a {@link String} representing the name of the host
	 * 					for the given event hub.
	 * 
	 * @return	a {@link Properties} object that contains the configuration
	 * 			settings for the event hub. This instance is meant to be 
	 * 			treated as a <i>read-only</i> object, which means that any
	 * 			change made to this instance will not affect the fabric
	 * 			configuration.
	 */
	public Properties getEventHubSettings(String hostName);
	
	/**
	 * Gets the configuration settings that are associated to the orderer.
	 * 
	 * @param hostName	a {@link String} representing the name of the host
	 * 					for the given orderer.
	 * 
	 * @return	a {@link Properties} object that contains the configuration
	 * 			settings for the orderer. This instance is meant to be 
	 * 			treated as a <i>read-only</i> object, which means that any
	 * 			change made to this instance will not affect the fabric
	 * 			configuration.
	 */
	public Properties getOrdererSettings(String hostName);
	
	/**
	 * Gets the configuration settings that are associated to the peer.
	 * 
	 * @param hostName	a {@link String} representing the name of the host
	 * 					for the given peer.
	 * 
	 * @return	a {@link Properties} object that contains the configuration
	 * 			settings for the peer. This instance is meant to be treated
	 * 		    as a <i>read-only</i> object, which means that any change
	 * 			made to this instance will not affect the fabric configuration.
	 */
	public Properties getPeerSettings(String hostName);

	/**
	 * Gets the crypto configuration settings that are associated to the user.
	 *
	 * @param hostName	a {@link String} representing the name of the host
	 * 					for the given peer.
	 * @param userName	a {@link String} representing the name of the user including hostname
	 *          in the format <name>@<hostName>
	 *
	 * @return	a {@link Properties} object that contains the configuration
	 * 			settings for the user. This instance is meant to be treated
	 * 		    as a <i>read-only</i> object, which means that any change
	 * 			made to this instance will not affect the fabric configuration.
	 */
	public Properties getUserCryptoSettings(String hostName, String userName);

	/**
	 * Gets the list of organizations that are stored configured in the 
	 * fabric network. If there are no organizations setup the set is
	 * empty.
	 * 
	 * @return	a {@link Set} of {@link Organization} instances.
	 */
	public Collection<Organization> getOrganizations();
	
	/**
	 * Gets the organization that maps the given name.
	 * 	
	 * @param orgName	a {@link String} representing the name of the 
	 * 					organization. It cannot be {@literal null}.
	 * 
	 * @returna a {@link Organization} implementation if there is an organization
	 * 			mapped to <i>orgName</i>, {@literal null} otherwise.
	 */
	public Organization getOrganization(String orgName);
	
	/**
	 * Gets the time in milliseconds to wait for a transaction to be completed.
	 * 
	 * @return	an {@literal int} value representing the number of milliseconds
	 * 			to wait for a transaction.
	 */
	public int getTransactionWaitTime();
	
	/**
	 * Gets the time in milliseconds to wait for a deployment to be completed.
	 * 
	 * @return	an {@literal int} value representing the number of milliseconds
	 * 			to wait for a deployment to be completed.
	 */
	public int getDeployWaitTime();
	
	/**
	 * Gossip Time.
	 * 
	 * @return	an {@literal int} value representing the gossip time in milliseconds.
	 */
	public int getGossipWaitTime();
	
	/**
	 * Retrieves a generic property from the configuration. This method is provided
	 * for extension purpose. Should the configuration implementation be used to
	 * carry additional configuration settings.
	 * 
	 * @param propertyName	a {@link String} containing the name of the property to
	 * 						look for. It cannot be {@literal null}.
	 * 
	 * @return	a {@link String} containing the value for the property, if found
	 * 			otherwise {@literal null}.
	 * 
	 * @throws IllegalArgumentException	if <i>propertyName</i> is {@literal null} or
	 * 									an empty string.
	 */
	public String getProperty(String propertyName);
	
}
