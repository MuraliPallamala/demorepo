package com.ibm.au.bgx.keycloak;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;

/**
 * Class <b>AbstractClient</b>. This class contains the basic capabilities that are used by the
 * concrete KeyCloak client implementations to perform all the management tasks that are required
 * for the management of organizations and users. These capabilities primarily relate to handling
 * the public and private URLs to the Keycloak installation to be used:
 * <ul>
 * <li>A public URL is meant to be used by the end users and the browsers to allow the user to
 * perform authentication.</li>
 * <li>A private URL is meant to be used by the APIs to perform all te required management
 * tasks.</li>
 * </ul>
 * The client does not necessarily requires the existence of both URLs, but it does require the
 * public URL to be set. In the absence of a private URL the public URL will be used for the
 * management functions.
 * 
 * @author brunomar
 *
 */
public class AbstractClient {

    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractClient.class);

    /**
     * A {@link String} representing the base URL of the Keycloak installation that will be used to
     * manage identities. This URL represents the public facing endpoint of keycloak that is meant
     * to be used by browsers to allow users to perform manual authentication.
     */
    @Value("${keycloak.url:https://bg-keycloak.sl.cloud9.ibm.com:8443}")
    private String basePublicUrl;

    /**
     * A {@link String} representing the has URL of the Keycloak installation that will b used to
     * manage identities. The URL represents the private facing endpoint of Keycloak that is used by
     * the APIs internally to perform all the required management tasks without any necessity of
     * involving the user in the process.
     */
    @Value("${keycloak.privateUrl:}")
    private String basePrivateUrl;


    /**
     * A {@link String} representing the password of the keystore that will contain the client
     * certificate used to talk to the services portal.
     */
    @Value("${keycloak.ssl.keystorePassword:}")
    private String keystorePassword;

    /**
     * 
     */
    @Value("${keycloak.ssl.clientCertificatePassword:}")
    private String clientCertificatePassword;

    /**
     * 
     */
    @Value("${keycloak.ssl.keystorePath:}")
    private String keystorePath;
    
    /**
     * 
     */
    @Value("${keycloack.logging.requests:true}")
    private boolean logRequests;
    
    @Autowired
    protected SSLUtils sslUtils;
    
    private ClientHttpRequestFactory requestFactory;

    /**
     * This method initializes the {@link AbstractClient} and sets inherited values if these are not
     * set in the Spring configuration. In particular, this method set the value returned by
     * {@link AbstractClient#getBasePrivateUrl()} it the corresponding field has not been set to the
     * corresponding value of the defined public url for Keycloak.
     */
    @PostConstruct
    public void initialize() {

        if (this.basePrivateUrl == null || this.basePrivateUrl.trim().isEmpty()) {

            this.basePrivateUrl = this.basePublicUrl;
        }
        
        try {
        
            URI uri = new URI(this.basePublicUrl);
            
            if (uri.getScheme().equals("https")) {
                
                SSLConnectionSocketFactory factory = this.sslUtils.getSSLConnectionSocketFactory();
                
                HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(factory).build();
                this.requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
            
            } else {
                
                this.requestFactory = new SimpleClientHttpRequestFactory();
            }
        
        } catch(IOException | URISyntaxException ioex) {
            
            LOGGER.error(BgxLogMarkers.DEV, "Could not initialize SSL Client Request Factory, defaulting to SimpleHttpClientFactory.", ioex);
            
            this.requestFactory = new SimpleClientHttpRequestFactory();
        }
    }
    
    /**
     * This method creates a default {@link RestTemplate} that is used to connect to the selected
     * Keycloak installation.
     * 
     * @return	a {@link RestTemplate} instance that is used to make requests to the federated 
     * 			identity provider and that is configured according to the selected logging behaviour.
     */
    protected RestTemplate getRestTemplate() {
    	
        return this.getRestTemplate(this.logRequests);
    }
    

    /**
     * This method creates a default {@link RestTemplate} that is used to connect to the selected
     * Keycloak installation.
     * 
     * @return a {@link RestTemplate} instance containing a {@link LoggingRequestInterceptor} used
     *         to log each request made to the Keycloak instance.
     */
    protected RestTemplate getRestTemplate(boolean logRequest) {

        RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(this.requestFactory));
        if (logRequest) {
        
            List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
            interceptors.add(new LoggingRequestInterceptor());
            restTemplate.setInterceptors(interceptors);
        }
        return restTemplate;
    }

    /**
     * This method returns the public facing URL of the Keycloak instance that is meant to be used
     * by the end user to perform authentication.
     * 
     * @return a {@link String} containing the configured public URL.
     */
    protected String getBasePublicUrl() {
        return this.basePublicUrl;
    }

    /**
     * This method returns the private facing URL of the Keycloak instance that is meant to be used
     * by application clients to perform authentication without the intervention of the user. When
     * this attribute is not set by default it is set to the public facing URL.
     * 
     * @return a {@link String} containing the configured private URL.
     */
    protected String getBasePrivateUrl() {
        return this.basePrivateUrl;
    }

    /**
     * This method sets the public facing URL of the Keycloak instance that is meant to be used for
     * authentication purposes by the end user.
     * 
     * @param basePublicUrl a {@link String} representing the public facing URL of the Keycloak
     *        instance.
     */
    protected void setBasePublicUrl(String basePublicUrl) {
        this.basePublicUrl = basePublicUrl;
    }

    /**
     * This method sets the private facing URL of the Keycloak instance that is meant to be usd for
     * authentication without the intervention of the end user.
     * 
     * @param basePrivateUrl a {@link String} representing the private facing URL of the Keycloak
     *        instance.
     */
    protected void setBasePrivateUrl(String basePrivateUrl) {
        this.basePrivateUrl = basePrivateUrl;
    }

    /**
     * This method sets the private facing URL of the Keycloak instance that is meant to be usd for
     * authentication without the intervention of the end user.
     * 
     * @param basePrivateUrl a {@link String} representing the private facing URL of the Keycloak
     *        instance.
     */
    protected String getKeystorePassword() {
        return this.keystorePassword;
    }

    /**
     * This method sets the private facing URL of the Keycloak instance that is meant to be usd for
     * authentication without the intervention of the end user.
     * 
     * @param basePrivateUrl a {@link String} representing the private facing URL of the Keycloak
     *        instance.
     */
    protected void setKeystorePassword(String keystorePassword) {
        this.keystorePassword = keystorePassword;
    }

    /**
     * This method sets the private facing URL of the Keycloak instance that is meant to be usd for
     * authentication without the intervention of the end user.
     * 
     * @param basePrivateUrl a {@link String} representing the private facing URL of the Keycloak
     *        instance.
     */
    protected String getClientCertificatePassword() {
        return clientCertificatePassword;
    }

    /**
     * This method sets the private facing URL of the Keycloak instance that is meant to be usd for
     * authentication without the intervention of the end user.
     * 
     * @param basePrivateUrl a {@link String} representing the private facing URL of the Keycloak
     *        instance.
     */
    protected void setClientCertificatePassword(String clientCertificatePassword) {
        this.clientCertificatePassword = clientCertificatePassword;
    }

    /**
     * This method sets the private facing URL of the Keycloak instance that is meant to be usd for
     * authentication without the intervention of the end user.
     * 
     * @param basePrivateUrl a {@link String} representing the private facing URL of the Keycloak
     *        instance.
     */
    protected String getKeystorePath() {
        return keystorePath;
    }

    /**
     * This method sets the private facing URL of the Keycloak instance that is meant to be usd for
     * authentication without the intervention of the end user.
     * 
     * @param basePrivateUrl a {@link String} representing the private facing URL of the Keycloak
     *        instance.
     */
    protected void setKeystorePath(String keystorePath) {
        this.keystorePath = keystorePath;
    }
    
    /**
     * Returns the configured behaviour for loggin HTTP requests to the federated identity
     * provide.
     * 
     * @return	{@true} if logging the requests, {@literal false} otherwise.
     */
    protected boolean getLogRequests() {
    	
    	return this.logRequests;
    }
    
    /**
     * Sets the configured behaviour for logging HTTP requests to the federated identity
     * provider.
     * 
     * @param logRequests {@true} for logging the requests, {@literal false} otherwise.
     */
    protected void setLogRequests(boolean logRequests) {
    	
    	this.logRequests = logRequests;
    }
    
    /**
     * This a utility method that is used to process {@link Exceptions} that may be generated
     * by the use of {@link KeycloakTokenSession} as a {@link Closeable} in <i>try-with-resource</i>
     * blocks.
     * 
     * @param error	a {@link Exception} providing information about the error occurred while closing
     * 				the session.
     */
    protected void logLogoutError(Exception error) {
    	
    	  LOGGER.warn(BgxLogMarkers.DEV, "Could not logout from the Keycloack session.", error);
    }
}
