package com.ibm.au.bgx.keycloak;

import com.ibm.au.bgx.model.pojo.keycloak.KeycloakAuthExecutionInfo;
import com.ibm.au.bgx.model.pojo.keycloak.KeycloakAuthExecutionInfo.Requirement;
import java.io.IOException;
import java.math.BigInteger;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.exception.IdentityProviderException;
import com.ibm.au.bgx.model.identityprovider.LogoutClient;
import com.ibm.au.bgx.model.identityprovider.ManagedIdentityProviderClient;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;
import com.ibm.au.bgx.model.pojo.OpenIdConfig.Provider;
import com.ibm.au.bgx.model.pojo.keycloak.KeycloakClientRepresentationRequest;
import com.ibm.au.bgx.model.pojo.keycloak.KeycloakRealmRepresentationRequest;
import com.ibm.au.bgx.model.pojo.keycloak.KeycloakUserCredentialRepresentationRequest;
import com.ibm.au.bgx.model.pojo.keycloak.KeycloakUserRepresentationRequest;
import com.nimbusds.oauth2.sdk.AuthorizationGrant;
import com.nimbusds.oauth2.sdk.ParseException;
import com.nimbusds.oauth2.sdk.ResourceOwnerPasswordCredentialsGrant;
import com.nimbusds.oauth2.sdk.Scope;
import com.nimbusds.oauth2.sdk.TokenErrorResponse;
import com.nimbusds.oauth2.sdk.TokenRequest;
import com.nimbusds.oauth2.sdk.TokenResponse;
import com.nimbusds.oauth2.sdk.auth.Secret;
import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import com.nimbusds.oauth2.sdk.http.HTTPResponse;
import com.nimbusds.oauth2.sdk.id.ClientID;
import com.nimbusds.openid.connect.sdk.OIDCTokenResponse;
import com.nimbusds.openid.connect.sdk.OIDCTokenResponseParser;
import com.nimbusds.openid.connect.sdk.token.OIDCTokens;

/**
 * Class <b>ManagedIdentityProviderClientImpl</b>. This class implements the
 * {@link ManagedIdentityProviderClient} interface and provides the bindings for using Keycloak as
 * federated identity provider and manage through that users and realms.
 *
 * @author Bruno Marques <brunomar@au1.ibm.com>
 */
@Component
public class ManagedIdentityProviderClientImpl extends AbstractClient
                							   implements ManagedIdentityProviderClient {


    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ManagedIdentityProviderClientImpl.class);

    /**
     * A {@link String} containing the name of the attribute holding the default client account
     * identifier.
     */
    public static final String DEFAULT_ACCOUNT_CLIENT_ID = "account";

    /**
     * A {@link String} containing the name of the attribute holding the default security admin
     * console client identifier.
     */
    public static final String DEFAULT_SECURITY_ADMIN_CONSOLE_CLIENT_ID = "security-admin-console";

    /**
     * A {@link String} containing the name of the attribute holding the default client identifier.
     */
    public static final String UNIQUE_CLIENT_ID_ATTRIBUTE = "id";

    /**
     * A {@link String} containing the name of the master realm.
     */
    public static final String REALM_MASTER = "master";
    
    /**
     * A {@link String} containing the name that shows up in the title of the html page.
     */
    public static final String DEFAULT_DISPLAY_NAME = "Bank Guarantees DLT Platform";

    /**
     * A {@link String} containing the name of the attribute holding the information about the keys.
     */
    public static final String REALM_KEYS_ATTRIBUTE = "keys";

    /**
     * A {@link String} containing the name of the attribute holding the value about the realm. This
     * is used for either querying Keycloak or creating a new realm.
     */
    public static final String REALM_NAME_ATTRIBUTE = "realmName";
    /**
     * A {@link String} containing the name of the attribute holding the information about the
     * public key.
     */
    public static final String REALM_PUBLIC_KEY_ATTRIBUTE = "publicKey";
    /**
     * A {@link String} containing the name of the attribute containing the host name of the mail
     * server that will be used by the Kycloak instance to send emails to users of a given realm.
     */
    public static final String REALM_MAIL_SERVER_HOST = "host";
    /**
     * A {@link String} containing the name of the attribute containing the value of the port that
     * is used to communicate with the configured mail server by Keycloak to send emails.
     */
    public static final String REALM_MAIL_SERVER_PORT = "port";
    /**
     * A {@link String} containing the name of the attribute that is used to configure the SSL
     * settings for Keycloak when communicating with a mail server.
     */
    public static final String REALM_MAIL_SERVER_SSL = "ssl";
    /**
     * A {@link String} containing the name of the attribute that is used to configure the
     * authentication settings for Keycloak to communicate with the configured mail server.
     */
    public static final String REALM_MAIL_SERVER_AUTH = "auth";
    /**
     * A {@link String} containing the name of the attribute that is used to store the name of the
     * identity used to authenticate with the mail server.
     */
    public static final String REALM_MAIL_SERVER_USERNAME = "user";
    /**
     * A {@link String} containing the name of the attribute that is used to store the password
     * credentials of the identity used to authenticate with the mail server.
     */
    public static final String REALM_MAIL_SERVER_PASSWORD = "password";
    /**
     * A {@link String} containing the name of the attribute that is used to store the mail address
     * of the identity that is used to send emails to through Keycloak.
     */
    public static final String REALM_MAIL_FROM = "from";
    /**
     * A {@link String} containing the name of the attribute that is usd to store the email address
     * that should be used to reply to when Keycloak sends emails.
     */
    public static final String REALM_MAIL_REPLY_TO = "replyTo";
    /**
     * A {@link String} containing the configured password policy for the users that are created
     * within a given realm.
     */
    public static final String REALM_PASSWORD_POLICY = "passwordHistory(3) and specialChars(1) and upperCase(1) and lowerCase(1) and digits(1) and length(8) and notUsername(1)";
    /**
     * A {@link String} containing the name of the attribute that stores the unique identifier of
     * the client used to issue the request to Keycloak.
     */
    public static final String CLIENT_CLIENTID_ATTRIBUTE = "clientId";

    /**
     * A {@link String} containing the name of the attribute that stores the unique identifier of
     * ???
     */
    public static final String CLIENT_CLIENTID_ID_ATTRIBUTE = "id";
    /**
     * A {@link String} containing the name of the attribute that stores the name of the secret used
     * by the client to authenticate against Keycloak.
     */
    public static final String CLIENT_SECRET_ATTRIBUTE = "value";
    /**
     * A {@link String} containing the name of the attribute that provides information to Keycloak
     * about the status of the service accounts. When the service account is enabled, users can
     * login into the Keycloak portal and operate on their own user details.
     */
    public static final String CLIENT_SERVICE_ACCOUNTS_ENABLED = "serviceAccountsEnabled";
    /**
     * A {@link String} containing the name of the attributes that provides information about the
     * unique user identifier associated to the request made to Keycloak.
     */
    public static final String USER_USERID_ATTRIBUTE = "id";
    /**
     * A {@link String} containing the name of the attribute that stores the user password.
     */
    public static final String USER_PASSWORD_ATTRIBUTE = "password";

    /**
     * A {@link String} containing the default OTP policy type we use for realm
     */
    @Value("${keycloak.realm.otp.type:totp}")
    private String otpType;

    /**
     * A {@link String} containing the default OTP policy algorithm we use for realm
     */
    @Value("${keycloak.realm.otp.algo:HmacSHA1}")
    private String otpAlgo;

    /**
     * A {@link String} containing the default OTP policy digits
     */
    @Value("${keycloak.realm.otp.digits:6}")
    private long otpDigits;

    /**
     * A {@link String} containing the default OTP policy look ahead window
     */
    @Value("${keycloak.realm.otp.window:1}")
    private long otpLookAheadWindow;

    /**
     * A {@link String} containing the default OTP policy counter
     */
    @Value("${keycloak.realm.otp.counter:0}")
    private long otpCounter;

    /**
     * A {@link String} containing the default OTP policy period
     */
    @Value("${keycloak.realm.otp.period:30}")
    private long otpPeriod;

    /**
     * A {@link LogoutClient} instance that is used to logout the client when interacting with the
     * Keycloak instance.
     */
    @Autowired
    private LogoutClient logoutClient;

    /**
     * A {@link String} containing the relative path to the Keycloak base URL used to retrieve the
     * OpenID Connect token.
     */
    @Value("${keycloak.openidConnectToken.path:auth/realms/master/protocol/openid-connect/token}")
    private String tokenPath;

    /**
     * A {@link String} containing the name of the administrative client. This is used to perform
     * administrative and management operations on a realm and on the keycloak installation.
     */
    @Value("${keycloak.admin.clientId:admin-cli}")
    private String clientId;

    /**
     * A {@link String} containing the type of authentication method used for the administrator.
     */
    @Value("${keycloak.admin.grantType:password}")
    private String grantType;

    /**
     * A {@link String} containing the username for the administrative credentials.
     */
    @Value("${keycloak.admin.username:admin}")
    private String adminUsername;

    /**
     * A {@link String} containing the password for the administrative credentials.
     */
    @Value("${keycloak.admin.password:secret}")
    private String adminPassword;

    /**
     * A {@link String} containing the relative path to the authentication endpoint for an
     * administrator.
     */
    @Value("${keycloak.admin.path:auth/admin}")
    private String adminPath;

    /**
     * A {@link String} containing the name of the default theme to setup when creating a new realm.
     */
    @Value("${keycloak.realm.theme:dlt}")
    private String realmTheme;

    /**
     * A {@literal boolean} value containing the flag controlling the reset password behaviour. If
     * set to {@literal true} the users within a realm will be able to reset their password.
     */
    @Value("${keycloak.realm.resetPasswordAllowed:true}")
    private boolean resetPasswordAllowed;

    /**
     * A {@link String} containing the name of mail server host that will be used by Keycloak to
     * send email to the users.
     */
    @Value("${keycloak.mail.server.host:ris-pup-01-wdc01.sl.cloud9.ibm.com}")
    private String smtpServerHost;

    /**
     * A {@link String} containing the port number used to communicate with the mail server host.
     * The default value that is injected is "25".
     */
    @Value("${keycloak.mail.server.port:25}")
    private String smtpServerPort;

    /**
     * A {@link String} containing the flag that controls whether the communication with the mail
     * server should be executed through SSL or not. If set to {@literal 
     * true} the communication will go over SSL. The default value that is injcted is "false".
     */
    @Value("${keycloak.mail.server.ssl:false}")
    private String smtpServerSsl;

    /**
     * A {@link String} containing the flag the controls whether the mail client needs to
     * authenticate ({@literal true}) or not. The default value that is injected is "false".
     */
    @Value("${keycloak.mail.server.auth:false}")
    private String smtpServerAuth;

    /**
     * A {@link String} containing the email address that will act as sender when the Keycloak
     * instance will send emails on behalf of the platform.
     */
    @Value("${keycloak.mail.from:}")
    private String smtpServerFrom;

    /**
     * A {@link String} containing the email address that will act as replyTo email when the
     * Keycloak instance will send emails on behalf of the platform.
     */
    @Value("${keycloak.mail.replyTo:noreply@dlt.res.ibm.com}")
    private String smtpServerReplyTo;

    /**
     * A {@link String} containing the username credentials that will be used by the Keycloak
     * instance when authenticating with the mail server.
     */
    @Value("${keycloak.mail.server.username:}")
    private String smtpServerUsername;

    /**
     * A {@link String} containing the password credentials that will be used by the Keycloak
     * instance when authenticating with the mail server.
     */
    @Value("${keycloak.mail.server.password:}")
    private String smtpServerPassword;

    /**
     * This method creates a new realm in Keycloak. A realm is used to store the information about a
     * sigle organisation that operates in the platform.
     * 
     * @param realmName a {@link String} containing the name of the realm that will be used in
     *        			Keycloak.
     * @param displayNameHtml a {@link String} containing the display name associated to the realm.
     * 
     * @return a {@link Map} implementation containing a collection of attributes that are to be
     *         store the entity that has invoked the method to operate on the realm later on with
     *         this client.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public Map<String, Object> createRealm(String realmName, String displayNameHtml) throws IdentityProviderException {

        Map<String, Object> result = new LinkedHashMap<>();


        try (KeycloakTokenSession session = this.initKeycloakTokenSession()) {


            // Calls Keycloak api to create realm.
            this.createKeycloakRealm(session, realmName, displayNameHtml);

            // We add the information about the realmName to the result to be
            // returned to the caller.
            //
            result.put(ManagedIdentityProviderClientImpl.REALM_NAME_ATTRIBUTE, realmName);


            // Calls Keycloak api to get information about realm that has just been created.
            Map<String, Object> info = this.getRealmPublicKeyInformation(session, realmName);

            // We extract the information associated to the public key and we add ito the
            // result returned to the caller.By default we assume that there will only be
            // a single public key at this point.
            //
            String publicKey = this.extractPublicKey(info, 0);
            result.put(ManagedIdentityProviderClientImpl.REALM_PUBLIC_KEY_ATTRIBUTE, publicKey);



            // Deactivates Keycloak default client for user management (account and
            // security-admin-console clients).

            // Note: We do not deactivate the ACCOUNT client so that users may use
            // 'Forgot password' functionality of Keycloak to reset password
            // 
            // Deactivate security-admin-console clients
            // FIXME we should enable it with role `manage-users` so that realm admin
            // can manage the realm users

            info = this.getClientInformation(session, realmName, ManagedIdentityProviderClientImpl.DEFAULT_SECURITY_ADMIN_CONSOLE_CLIENT_ID);
            if (info == null) {
            	
            	throw new IdentityProviderException(String.format("Could not retrieve OpenID Connect client information (realm: %s).", realmName));
            }
            
            String securityAdminConsoleClientUniqueId = (String) info.get(ManagedIdentityProviderClientImpl.UNIQUE_CLIENT_ID_ATTRIBUTE);

            // We finally disable the client for the realm.
            //
            this.disableClient(session, realmName,
                            ManagedIdentityProviderClientImpl.DEFAULT_SECURITY_ADMIN_CONSOLE_CLIENT_ID,
                            securityAdminConsoleClientUniqueId);


        } catch (IdentityProviderException e) {
        	
            throw e;
            
        } catch (Exception e) {
        	
          this.logLogoutError(e);
        }

        return result;
    }

    /**
     * Retrieves the information associated to the given <i>realmName</i>.
     * 
     * @param realmName a {@link String} containing the name of the realm to retrieve information
     *        about. It is expected to not to be {@literal null} or an empty string.
     * 
     * @returns a {@link Map} implementation that contains information about the realm specified by
     *          <i>realmName</i>. The map will contain two attributes:
     *          <ul>
     *          <li>{@link ManagedIdentityProviderClientImpl#REALM_NAME_ATTRIBUTE} mapping the name
     *          of the requested realm</li>
     *          <li>{@link ManagedIdentityProviderClientImpl#REALM_PUBLIC_KEY_ATTRIBUTE} mapping the
     *          value of the public key associated to the realm.</li>
     *          </ul>
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     * 
     */
    @Override
    public Map<String, Object> getRealm(String realmName) throws IdentityProviderException {
    	
    	
    	if (realmName == null || realmName.isEmpty()) {
    		
    		throw new IllegalArgumentException("Parameter 'realmName' cannot be null.");
    	}
    	
        Map<String, Object> result = null;

        try (KeycloakTokenSession session = this.initKeycloakTokenSession()) {

            // Calls Keycloak api to get information about realm that has just been created.
            Map<String, Object> keyInfo = null;

            keyInfo = this.getRealmPublicKeyInformation(session, realmName);

            String publicKey = this.extractPublicKey(keyInfo, 0);

            // Populates Map to be returned
            result = new LinkedHashMap<>();
            result.put(ManagedIdentityProviderClientImpl.REALM_NAME_ATTRIBUTE, realmName);
            result.put(ManagedIdentityProviderClientImpl.REALM_PUBLIC_KEY_ATTRIBUTE, publicKey);



        } catch (IdentityProviderException e) {

            Throwable cause = e.getCause();

            // to detect whether the realm does not exist, we should check whether
            // we have received an HttpClientErrorException and check whether the
            // status code is 404.
            //
            if (cause instanceof HttpClientErrorException) {

                HttpClientErrorException error = (HttpClientErrorException) cause;
                if (HttpStatus.NOT_FOUND.equals(error.getStatusCode())) {

                    if (LOGGER.isDebugEnabled()) {
                        LOGGER.debug(BgxLogMarkers.DEV, String.format(
                                        "Realm %s is not found (status code: %d).", realmName,
                                        error.getRawStatusCode()));
                    }

                    return null;
                }   
            }

            // if it is not a 404 error, it is something that needs to be bubbled up.
            throw e;
            
        } catch (Exception e) {

        	this.logLogoutError(e);
        }
        
        return result;
    }

    /**
     * This method creates a client based on the OpenID Connect protocol for the Federated Identity
     * Provider. This method internally calls
     * {@link ManagedIdentityProviderClientImpl#createClient(KeycloakTokenSession, String, String, List, String)} and sets
     * the value of the grant type to {@link BgxConstants#OAUTH_PASSWORD_GRANT_TYPE}.
     * 
     * @param realmName a {@link String} containing the name of the realm. It is expected to not to
     *        be {@literal 
     * 						null} or an empty string.
     * @param clientId a {@link String} containing the unique identifier of the client to be
     *        created. It is expected to not to be {@literal null} or an empty string.
     * @param redirectUrls a {@link List} of strings that contains the redirect URLs that are
     *        allowed for this clien when performing an authentication request.
     * 
     * @return an instance of {@link OpenIdConfig} that contains all the required details for the
     *         client to connect to the provider.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Identity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public OpenIdConfig createUserClient(String realmName, String clientId, List<String> redirectUrls) throws IdentityProviderException {

        OpenIdConfig client = null;

        try (KeycloakTokenSession session = this.initKeycloakTokenSession()) {

            client = this.createClient(session, realmName, clientId, redirectUrls, BgxConstants.OAUTH_PASSWORD_GRANT_TYPE);

        } catch (IdentityProviderException e) {
        	
            throw e;
            
        } catch (Exception e) {
        	
        	this.logLogoutError(e);
        }

        return client;
    }

    /**
     * This method creates a client for the APIs based on the OpenID Connect protocol to the
     * Federated Identity Provider. This method internally calls
     * {@link ManagedIdentityProviderClientImpl#createClient(KeycloakTokenSession, String, String, List, String)} and sets
     * the grant type to {@link BgxConstants#OAUTH_CLIENT_CREDENTIALS_GRANT_TYPE}.
     * 
     * @param realmName a {@link String} containing the name of the realm. It is expected to not to
     *        be {@literal 
     * 						null} or an empty string.
     * @param clientId a {@link String} containing the unique identifier of the client to be
     *        created. It is expected to not to be {@literal null} or an empty string.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Identity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public OpenIdConfig createApiClient(String realmName, String clientId) throws IdentityProviderException {

        OpenIdConfig client = null;

        try (KeycloakTokenSession session = this.initKeycloakTokenSession()) {

            client = this.createClient(session, realmName, clientId, null, BgxConstants.OAUTH_CLIENT_CREDENTIALS_GRANT_TYPE);

        } catch (IdentityProviderException e) {
        	
            throw e;
        
        } catch (Exception e) {
        	
        	this.logLogoutError(e);
        }
        return client;
    }

    /**
     * This method retrieves the details of the configuration for the specified <i>clientId</i> and
     * <i>realmName</i>.
     * 
     * @param realmName a {@link String} containing th name of the realm from which to retrieve the
     *        			client for. It is expected to not to be {@literal null} or an empty string.
     *
     * @param clientId 	a {@link String} containing the unique identifier of the client to retrieve
     *        			the configuration of the client of interest. It is expected to not be {@literal 
     *        			null} or an empty string.
     * 
     * @returns an instance of {@link OpenIdConfig} containing the details of the configuration for
     *          the requested client.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Identity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public OpenIdConfig getClient(String realmName, String clientId) throws IdentityProviderException {

        OpenIdConfig realm = null;

        try (KeycloakTokenSession session = initKeycloakTokenSession()) {
            
        	realm = this.getKeycloakClient(session, realmName, clientId);

        } catch (IdentityProviderException e) {
            
        	throw e;
            
        } catch (Exception e) {
        	
        	this.logLogoutError(e);
        }
        return realm;
    }

    /**
     * This method removes a realm from the Federated identity provider. The removal of the realm
     * also causes the removal of all the users associated to that realm.
     * 
     * @param realmName a {@link String} containing th name of the realm from which to retrieve the
     *        			client for. It is expected to not to be {@literal null} or an empty string.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public void removeRealm(String realmName) throws IdentityProviderException {

        String url = String.format("%s/%s/realms/%s", this.getBasePrivateUrl(), this.getAdminPath(), realmName);

        try (KeycloakTokenSession session = initKeycloakTokenSession()) {
        	
            HttpHeaders headers = generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(headers);

            this.getRestTemplate().exchange(url, HttpMethod.DELETE, request, Map.class);

        } catch (RestClientException e) {

            throw new IdentityProviderException(String.format("Could not remove realm %s.", realmName), e);

        } catch (Exception e) {
        	
        	this.logLogoutError(e);
        }
    }

    /**
     * This method removes a client associated to the given realm, that matches the given
     * identifier.
     * 
     * @param realmName a {@link String} containing th name of the realm from which to retrieve the
     *        client for. It is expected to not to be {@literal null} or an empty string.
     *
     * @param clientId a {@link String} containing the unique identifier of the client to remove. It
     *        is expected to not be {@literal null} or an empty string.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public void removeClient(String realmName, String clientId) throws IdentityProviderException {


        try (KeycloakTokenSession session = initKeycloakTokenSession()) {
        	
            Map<String, Object> clientInfo = this.getClientInformation(session, realmName, clientId);
            if (clientInfo == null) {
            	
            	throw new IdentityProviderException(String.format("Could not retrieve OpenID Connect client information (realm: %s, clientId: %s).", realmName, clientId));
            }

            String id = (String) clientInfo.get(ManagedIdentityProviderClientImpl.CLIENT_CLIENTID_ID_ATTRIBUTE);

            String url = String.format("%s/%s/realms/%s/clients/%s", this.getBasePrivateUrl(), this.getAdminPath(), realmName, id);

            HttpHeaders headers = generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(headers);

            this.getRestTemplate().exchange(url, HttpMethod.DELETE, request, Map.class);

        } catch (RestClientException e) {

            throw new IdentityProviderException(String.format("Could not remove client (realmName: %s, clientId: %s).", realmName, clientId), e);
            
        } catch (Exception e) {
        	
        	this.logLogoutError(e);
        }
    }

    /**
     * This method creates a user in the realm identified by <i>realmName</i>.
     * 
     * @param realmName a {@link String} containing the name of the realm where to create the user
     *        in. It is expected to not to be {@literal null} or an empty string.
     * 
     * @param email a {@link String} containing the email of the user to crate. It is expected to
     *        not to be {@literal null} or empty.
     * @param firstName a {@link String} containing the first name of the user.
     * @param lastName a {@link String} containing the last name of the user.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     * 
     */
    @Override
    public Map<String, Object> createUser(String realmName, String email, String firstName, String lastName) throws IdentityProviderException {

        Map<String, Object> result = null;

        try (KeycloakTokenSession session = initKeycloakTokenSession()) {
        	
            this.createKeycloakUser(session, email, firstName, lastName, realmName);

            Map<String, Object> userInfo = this.getUserInformation(session, realmName, email);
            String userId = this.validateUserInfo(userInfo, realmName, email);

            result = new LinkedHashMap<>();
            result.put(ManagedIdentityProviderClientImpl.USER_USERID_ATTRIBUTE, userId);

        } catch (IdentityProviderException e) {
        	
            throw e;
        
        } catch (Exception e) {
        	
        	this.logLogoutError(e);
        }

        return result;
    }

    /**
     * Checks whether a given user exists in <i>realmName</i>.
     * 
     * @param realmName a {@link String} containing the name of the realm where to lookup the user.
     *        It is expected to not to be {@literal null} or an empty string.
     * 
     * @param username a {@link String} containing the username (email) of the user. It is expected
     *        to not to be {@literal null} or an empty string.
     * 
     * @returns {@literal true} if the user exists in the given realm, or {@literal false}
     *          otherwise.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     * 
     */
    @Override
    public boolean userExists(String realmName, String username) throws IdentityProviderException {

        boolean userExists = false;

        try (KeycloakTokenSession session = initKeycloakTokenSession()) {
        	
            userExists = (this.getUserInformation(session, realmName, username) != null);

        } catch (IdentityProviderException e) {
        	
            throw e;
        
        } catch (Exception e) {
        	
        	this.logLogoutError(e);
        }

        return userExists;
    }

    /**
     * This method allows for updating the details of a given user within the realm.
     * 
     * @param realmName a {@link String} containing the name of the realm where to create the user
     *        			in. It is expected to not to be {@literal null} or an empty string.
     * 
     * @param email a {@link String} containing the email of the user to crate. It is expected to
     *        		not to be {@literal null} or empty.
     * @param firstName a {@link String} containing the first name of the user.
     * @param lastName a {@link String} containing the last name of the user.
     * 
     * @return a {@link Map} implementation that contains the unique identifier of the user that has
     *         been updated. The unique identifier is mapped by
     *         {@link ManagedIdentityProviderClientImpl#USER_USERID_ATTRIBUTE}.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     * 
     */
    @Override
    public Map<String, Object> updateUser(String realmName, String email, String firstName, String lastName) throws IdentityProviderException {

        Map<String, Object> userInfo = null;

        try (KeycloakTokenSession session = initKeycloakTokenSession()) {

            // get user info so that we can get the id
            userInfo = this.getUserInformation(session, realmName, email); 
            String userId = this.validateUserInfo(userInfo, realmName, email);
            String url = String.format("%s/%s/realms/%s/users/%s", this.getBasePrivateUrl(), this.getAdminPath(), realmName, userId);


            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);

            KeycloakUserRepresentationRequest keycloakUserRepresentationRequest = new KeycloakUserRepresentationRequest();
            keycloakUserRepresentationRequest.setUsername(email);
            keycloakUserRepresentationRequest.setEmail(email);
            keycloakUserRepresentationRequest.setEnabled(true);
            keycloakUserRepresentationRequest.setFirstName(firstName);
            keycloakUserRepresentationRequest.setLastName(lastName);

            HttpEntity<KeycloakUserRepresentationRequest> request = new HttpEntity<>(keycloakUserRepresentationRequest, headers);

            this.getRestTemplate().exchange(url, HttpMethod.PUT, request, Map.class);

            // fetch user details
            userInfo = this.getUserInformation(session, realmName, email);
            userId = this.validateUserInfo(userInfo, realmName, email);
            
            Map<String, Object> result = new LinkedHashMap<>();
            result.put(ManagedIdentityProviderClientImpl.USER_USERID_ATTRIBUTE, userId);

        } catch (IdentityProviderException e) {
           
        	throw e;
        
        } catch (Exception e) {
        	
        	this.logLogoutError(e);
        }
        return userInfo;
    }

    /**
     * This method allows to set the user's password.
     * 
     * @param realmName a {@link String} containing the name of the realm where the user is defined.
     *        			It is expected to not to be {@literal null} or an empty string.
     *        
     * @param username 	a {@link String} containing the username (email) of the user. It is expected
     *        			to not to be {@literal null} or an empty string.
     *        
     * @param password 	a {@link String} containing the new password to set up.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public void setPassword(String realmName, String username, String password) throws IdentityProviderException {

        try (KeycloakTokenSession session = this.initKeycloakTokenSession()) {
        	
            Map<String, Object> userInfo = this.getUserInformation(session, realmName, username);
            String userId = this.validateUserInfo(userInfo, realmName, username);
            String url = String.format("%s/%s/realms/%s/users/%s/reset-password", this.getBasePrivateUrl(), this.getAdminPath(), realmName, userId);

            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
            KeycloakUserCredentialRepresentationRequest keycloakUserCredentialRepresentationRequest = new KeycloakUserCredentialRepresentationRequest();
            keycloakUserCredentialRepresentationRequest.setType(USER_PASSWORD_ATTRIBUTE);
            keycloakUserCredentialRepresentationRequest.setTemporary(false);
            keycloakUserCredentialRepresentationRequest.setValue(password);

            HttpEntity<KeycloakUserCredentialRepresentationRequest> request = new HttpEntity<>(keycloakUserCredentialRepresentationRequest, headers);

            this.getRestTemplate().exchange(url, HttpMethod.PUT, request, Map.class);

        } catch (HttpClientErrorException | HttpServerErrorException e) {

            throw new IdentityProviderException("Please make sure that the specified password adheres to the configured policy.", e);
            
        } catch (IdentityProviderException e) {
            
         	throw e;

        } catch (Exception e) {
         	
         	this.logLogoutError(e);
        }
    }

    /**
     * This method removes the user from a given realm.
     * 
     * @param realmName a {@link String} containing the name of the realm where the user is defined.
     *        			It is expected to not to be {@literal null} or an empty string.
     *        
     * @param username 	a {@link String} containing the username (email) of the user. It is expected
     *        			to not to be {@literal null} or an empty string.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public void removeUser(String realmName, String username) throws IdentityProviderException {


        try (KeycloakTokenSession session = initKeycloakTokenSession()) {
        	
            Map<String, Object> userInfo = this.getUserInformation(session, realmName, username);

            if (userInfo != null) {

	            String userId = (String) userInfo.get(ManagedIdentityProviderClientImpl.USER_USERID_ATTRIBUTE);
	
	            String url = String.format("%s/%s/realms/%s/users/%s", this.getBasePrivateUrl(), this.getAdminPath(), realmName, userId);
	
	            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
	            HttpEntity<?> request = new HttpEntity<>(headers);
	
	            this.getRestTemplate().exchange(url, HttpMethod.DELETE, request, Map.class);            
            
            } else {
            	
            	LOGGER.warn(BgxLogMarkers.DEV, "User NOT FOUND (realm: {}, name: {}).", realmName, username);
            }

        } catch (IdentityProviderException e) {
            
         	throw e;
         
        } catch (Exception e) {
         	
         	this.logLogoutError(e);
        }
    }
    
    /**
     * Retrieves a configuration for the One Time Password (OTP) setup. The method interact with 
     * the managed extension of the federated identity provider and pulls the OTP setup information
     * for the given user in the specified realm. 
     * 	
     * @param realmName		a {@link String} representing the name of the realm the user belongs to.
     * 						It is expected to not to be {@literal null} or an empty string.
     * 
     * @param email			a {@link String} containign the username (email) of the user. It is 
     * 						expected to not to be {@literal null} or an empty string.
     * 
     * @return	a {@link Map} containing the attributes required by a user to configure clients that
     * 			are used to generate codes during a 2-Factor Authentication process (i.e. Google Authenticator
     * 			or FreeOTP).
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @SuppressWarnings("unchecked")
	@Override
    public Map<String, Object> generateOtpSetup(String realmName, String email) throws IdentityProviderException {

    	Map<String, Object> otpInfo  = null;
    	
    	try (KeycloakTokenSession session = this.initKeycloakTokenSession()) {
    	
	        // get user info so that we can get the id
	        Map<String, Object> userInfo = this.getUserInformation(session, realmName, email);
	        
	        String userId = this.validateUserInfo(userInfo, realmName, email);
	
	        String url = this.getOtpUrl(realmName, userId) + "/setup";
	
            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(headers);

            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = this.getRestTemplate().exchange(url, HttpMethod.GET, request, Map.class);

            otpInfo = response.getBody();

            // unset unsupported values
            otpInfo.remove("qrUrl");
            otpInfo.remove("manualUrl");
	
	
    	} catch (RestClientException e) {
	        	
    		throw new IdentityProviderException(String.format("Could not generate OTP for user (realm: %s, username: %s).", realmName, email), e);
	    
    	} catch(Exception e) {
    		
    		this.logLogoutError(e);
    	} 
    	

        return otpInfo;

    }

    /**
     * Sets up the One Time Password configuration for the given user.
     * 
     * 	
     * @param realmName		a {@link String} representing the name of the realm the user belongs to.
     * 						It is expected to not to be {@literal null} or an empty string.
     * 
     * @param email			a {@link String} containign the username (email) of the user. It is 
     * 						expected to not to be {@literal null} or an empty string.
     * 
     * @param encodedSecret a {@link String} containing the base32 encoded secret. It is 
     * 						expected to not to be {@literal null} or an empty string.
     * 		
     * @param token			a {@link String} representing the initial PIN that has been provided
     * 						by the authentication device (i.e. Google Authenticator, Free OTP) to
     * 						setup the secret. It is expected to not to be {@literal null} or an empty 
     * 						string.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public void setOtp(String realmName, String email, String encodedSecret, String token) throws IdentityProviderException {
    	
    	try (KeycloakTokenSession session = this.initKeycloakTokenSession()) {

	        // get user info so that we can get the id
	        Map<String, Object> userInfo = this.getUserInformation(session, realmName, email);
	        String userId = this.validateUserInfo(userInfo, realmName, email);
	
	        String url = this.getOtpUrl(realmName, userId);

            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);

            Map<String, String> payload = new HashMap<>();
            payload.put(BgxConstants.OTP_ENCODED_SECRET, encodedSecret);
            payload.put(BgxConstants.OTP_TOKEN, token);

            HttpEntity<?> request = new HttpEntity<>(payload, headers);

            this.getRestTemplate().exchange(url, HttpMethod.PUT, request, Map.class);
            
        } catch(RestClientException e) {
        	
            throw new IdentityProviderException(String.format("Could not set OTP for user %s.", email), e);
        
        } catch(Exception e) {
        	
        	this.logLogoutError(e);
        }

    }

    /**
     * Removes the One Time Password (OTP) configuration for the selected user.
     * 
     * 	
     * @param realmName		a {@link String} representing the name of the realm the user belongs to.
     * 						It is expected to not to be {@literal null} or an empty string.
     * 
     * @param email			a {@link String} containign the username (email) of the user. It is 
     * 						expected to not to be {@literal null} or an empty string.
     * 
     * @throws IdentityProviderException 	in case there is any error in interacting with the
     *         								Federated Idenity Provider. The inner exception will 
     *         								further detail the nature of the error.
     */
    @Override
    public void deleteOtp(String realmName, String email) throws IdentityProviderException {
    	
    	try (KeycloakTokenSession session = this.initKeycloakTokenSession()) {

	        // get user info so that we can get the id
	        Map<String, Object> userInfo = this.getUserInformation(session, realmName, email);
	        if (userInfo != null) {
	        
		        String userId = this.validateUserInfo(userInfo, realmName, email);
		        String url = this.getOtpUrl(realmName, userId);
		
		        HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
		        HttpEntity<?> request = new HttpEntity<>(headers);
		
		        this.getRestTemplate().exchange(url, HttpMethod.DELETE, request, Map.class);
	        
	        } else {
	        	
	        	LOGGER.warn(BgxLogMarkers.DEV, "User NOT FOUND while trying to remove OTP (realm: {}, username: {})", realmName, email);
	        }
	
	    } catch (RestClientException e) {
	    
	    	throw new IdentityProviderException(String.format("Could not delete user OTP setup (realm: %s, username: %s)", realmName, email), e);
	    
	    } catch(Exception e) {
    		
    		this.logLogoutError(e);
    	}

    }

    /**
     * Gets the name of the default theme being setup when a new realm is created for an
     * organization.
     * 
     * @returns a {@link String} containing the name of the default theme.
     */
    public String getRealmTheme() {
        return this.realmTheme;
    }

    /**
     * Sets the name of the default theme being setup a new realm is created for an organization.
     * 
     * @param realmTheme a {@link String} containing the name of the default theme to set.
     */
    public void setRealmTheme(String realmTheme) {
        this.realmTheme = realmTheme;
    }

    /**
     * Gets the value of the flag that controls whether the user is allowed to reset the password
     * associated to his/her credentials.
     * 
     * @return {@literal true} if the user is allowed to change his her password, {@literal false}
     *         otherwise.
     */
    public boolean isResetPasswordAllowed() {
        return this.resetPasswordAllowed;
    }

    /**
     * Sets the value of the flag that controls whether the user is allowed to reset the password
     * associated to his/her credentials.
     * 
     * @param resetPasswordAllowed {@literal true} if the user is allowed to change his/her
     *        password, {@literal 
     * 								false} otherwise.
     */
    public void setResetPasswordAllowed(boolean resetPasswordAllowed) {
        this.resetPasswordAllowed = resetPasswordAllowed;
    }

    /**
     * Gets the name of mail server host that will be used by Keycloak to send email to the users.
     * 
     * @returns a {@link String} containing the mail server host.
     */
    public String getSmtpServerHost() {
        return this.smtpServerHost;
    }

    /**
     * sets the name of mail server host that will be used by Keycloak to send email to the users.
     * 
     * @param smtpServerHost a {@link String} containing the mail server host.
     */
    public void setSmtpServerHost(String smtpServerHost) {
        this.smtpServerHost = smtpServerHost;
    }

    /**
     * Gets the email address that will act as sender when the Keycloak instance will send emails on
     * behalf of the platform.
     * 
     * @return a {@link String} containing the configured email.
     */
    public String getSmtpServerFrom() {
        return this.smtpServerFrom;
    }


    /**
     * Sets the email address that will act as sender when the Keycloak instance will send emails on
     * behalf of the platform.
     * 
     * @param smtpServerFrom a {@link String} containing the email to configure.
     */
    public void setSmtpServerFrom(String smtpServerFrom) {
        this.smtpServerFrom = smtpServerFrom;
    }

    /**
     * Gets the the port number used to communicate with the mail server host. The default value
     * that is injected is "25".
     * 
     * @return a {@link String} containing the server port.
     */
    public String getSmtpServerPort() {
        return this.smtpServerPort;
    }

    /**
     * Sets the the port number used to communicate with the mail server host. The default value
     * that is injected is "25".
     * 
     * @param smtpServerPort a {@link String} containing the server port.
     */
    public void setSmtpServerPort(String smtpServerPort) {
        this.smtpServerPort = smtpServerPort;
    }


    /**
     * Gets the flag that controls whether the communication with the mail server should be xecuted
     * through SSL or not.
     * 
     * @return a {@link String} containing the value {@literal true} if SSL is enabled, or a
     *         {@link String} containing {@literal false} if not.
     */
    public String getSmtpServerSsl() {
        return this.smtpServerSsl;
    }

    /**
     * Sets the flag that controls whether the communication with the mail server should be xecuted
     * through SSL or not.
     * 
     * @param smtpServerSsl a {@link String} containing the value {@literal true} to enable SSL, or
     *        a {@link String} containing {@literal 
     * 							false} to disable it.
     */
    public void setSmtpServerSsl(String smtpServerSsl) {
        this.smtpServerSsl = smtpServerSsl;
    }

    /**
     * Gets the email address that will act as replyTo email when the Keycloak instance will send
     * emails on behalf of the platform.
     * 
     * @return a {@link String} containing the reply to email.
     */
    public String getSmtpServerReplyTo() {
        return this.smtpServerReplyTo;
    }

    /**
     * Sets the email address that will act as replyTo email when the Keycloak instance will send
     * emails on behalf of the platform.
     * 
     * @param smtpServerReplyTo a {@link String} containing the reply to email.
     */
    public void setSmtpServerReplyTo(String smtpServerReplyTo) {
        this.smtpServerReplyTo = smtpServerReplyTo;
    }

    /**
     * Gets the username credentials that will be used by the Keycloak instance when authenticating
     * with the mail server.
     * 
     * @return a {@link String} containing the username credential.
     */
    public String getSmtpServerUsername() {
        return this.smtpServerUsername;
    }

    /**
     * Sets the username credentials that will be used by the Keycloak instance when authenticating
     * with the mail server.
     * 
     * @param smtpServerUsername a {@link String} containing the username credential.
     */
    public void setSmtpServerUsername(String smtpServerUsername) {
        this.smtpServerUsername = smtpServerUsername;
    }

    /**
     * Gets the password credentials that will be used by the Keycloak instance when authenticating
     * with the mail server.
     * 
     * @return a {@link String} containing the password credential.
     */
    public String getSmtpServerPassword() {
        return this.smtpServerPassword;
    }

    /**
     * Sets the password credentials that will be used by the Keycloak instance when authenticating
     * with the mail server.
     * 
     * @param smtpServerPassword a {@link String} containing the username credential.
     */
    public void setSmtpServerPassword(String smtpServerPassword) {
        this.smtpServerPassword = smtpServerPassword;
    }


    /**
     * Gets the flag the controls whether the mail client needs to authenticate or not against the
     * SMTP server.
     * 
     * @return a {@link String} containing the value "{@literal true}" if the client has been
     *         configured to instruct Keycloak to authenticate, a {@link String} containing the
     *         value "{@literal false}" otherwise.
     */
    public String getSmtpServerAuth() {
        return this.smtpServerAuth;
    }

    /**
     * Gets the flag the controls whether the mail client needs to authenticate or not against the
     * SMTP server.
     * 
     * @return a {@link String} containing the value "{@literal true}" if the client has been
     *         configured to instruct Keycloak to authenticate, a {@link String} containing the
     *         value "{@literal false}" otherwise.
     */
    public void setSmtpServerAuth(String smtpServerAuth) {
        this.smtpServerAuth = smtpServerAuth;
    }

    /**
     * Gets the URI used to retrieve the authentication token. This method uses the configured
     * public URL of the keycloak instance and appends to it the relative path associated to the
     * token retrieval.
     * 
     * @return a {@link String} containing the unique resource identifier of the end point used to
     *         retrieve the authentication token.
     */
    public String getTokenUri() {
        return String.format("%s/%s", this.getBasePublicUrl(), this.getTokenPath());
    }

    /**
     * Gets a {@link String} containing the token URI based on the private URI of the configured
     * Keycloak installation.
     * 
     * @return a {@link String} containing the unique resource identifier of the end point used to
     *         retrieve the authentication token.
     */
    protected String getPrivateTokenUri() {
        return String.format("%s/%s", this.getBasePrivateUrl(), this.getTokenPath());
    }


    /**
     * Gets the username of the administrative credentials that have been configured with this
     * client.
     * 
     * @return a {@link String} containing the usernam of the administrator.
     */
    public String getAdminUsername() {
        return this.adminUsername;
    }

    /**
     * Sets the username of the administrative credentials for this client to use.
     * 
     * @param adminUsername a {@link String} containing the usernam of the administrator.
     */
    public void setAdminUsername(String adminUsername) {
        this.adminUsername = adminUsername;
    }

    /**
     * Gets the password of the administrative credentials that have been configured with this
     * client.
     * 
     * @return a {@link String} containing the password of the administrator.
     */
    protected String getAdminPassword() {
        return this.adminPassword;
    }

    /**
     * Sets the password of the administrative credentials for this client to use.
     * 
     * @param adminPassword {@link String} containing the password of the administrator.
     */
    protected void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }

    /**
     * Gets the relative path with respect to the base URL of the configured Keycloak installation
     * from where to retrieve the authentication token.
     * 
     * @return a {@link String} containing the authentication path.
     */
    protected String getTokenPath() {

        return this.tokenPath;
    }

    /**
     * Sets the relative path with respect to the base URL of the configured Keycloak installation
     * from where to retrieve the authentication token.
     * 
     * @param tokenPath a {@link String} containing the authentication path.
     */
    protected void setTokenPath(String tokenPath) {
        this.tokenPath = tokenPath;
    }

    /**
     * Gets the unique identifier of the client to use to interact with the configured Keycloak
     * installation.
     * 
     * @return a {@link String} containing the unique identifier of the client.
     */
    protected String getClientId() {
        return this.clientId;
    }

    /**
     * Sets the unique identifier of the client to use to interact with the configured Keycloak
     * installation.
     * 
     * @return a {@link String} containing the unique identifier of the client.
     */
    protected void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Gets the configured grant type.
     * 
     * @return a {@link String} containing the grant type.
     */
    protected String getGrantType() {

        return this.grantType;
    }

    /**
     * Sets the configured grant type.
     * 
     * @param grantType a {@link String} containing the grant type.
     */
    protected void setGrantType(String grantType) {

        this.grantType = grantType;
    }

    /**
     * Gets the relative path to the URL of the configured Keycloak installation that identifies the
     * endpoint for the administrative functions exposed by Keycloak.
     * 
     * @return a {@link String} containing the path to the administrative functions.
     */
    protected String getAdminPath() {

        return this.adminPath;
    }

    /**
     * Sets the relative path to the URL of the configured Keycloak installation that identifies the
     * endpoint for the administrative functions exposed by Keycloak.
     * 
     * @param adminPath a {@link String} containing the path to the administrative functions.
     */
    protected void setAdminPath(String adminPath) {

        this.adminPath = adminPath;
    }

    /**
     * This method creates an OpenID Connect client.
     *
     * @param session	a {@link KeycloakTokenSession} instance that is used to isolate the operation
     * 					of a specific client. This instance contains the collection of OpenID Connect
     * 					tokens that are specific to a given user interaction. It cannot be {@literal 
     * 					null}.
     *
     * @param realmName a {@link String} containing the name of the realm. It is expected to not to
     *        			be {@literal null} or an empty string.
     *        
     * @param clientId 	a {@link String} representing the unique identifier of the client to be
     *        			created. It is expected to not to be {@literal null} or an empty string.
     * 
     * @param redirectUrls 	a {@link List} implementation containing the list of accepted URLs that
     *        				an application client will be redirectd to when authenticating by using 
     *        				this client.
     * 
     * @return an {@link OpenIdConfig} instance containing th details of the client identified by
     *         <i>clientId</i>.
     * 
     * @throws IdentityProviderException if there is any error being thrown during the creation of
     *         the realm, it is wrapped into an exception of this type and re-thrown.
     */
    private OpenIdConfig createClient(KeycloakTokenSession session, String realmName,
                    String clientId, List<String> redirectUrls, String grantType)
                    throws IdentityProviderException {

        this.createKeycloakClient(session, realmName, clientId, redirectUrls, grantType);

        return this.getKeycloakClient(session, realmName, clientId);
    }

    /**
     * This method makes a call to the Keycloak APIs to retrieve the details of a specified OpenID
     * Connect client.
     *
     * @param session	a {@link KeycloakTokenSession} instance that is used to isolate the operation
     * 					of a specific client. This instance contains the collection of OpenID Connect
     * 					tokens that are specific to a given user interaction. It cannot be {@literal 
     * 					null}.
     *
     * @param realmName a {@link String} containing the name of the realm. It is expected to not to
     *        			be {@literal null} or an empty string.
     *        
     * @param clientId 	a {@link String} representing the unique identifier of the client to be
     *        			created. It is expected to not to be {@literal null} or an empty string.
     * 
     * @throws IdentityProviderException 	if there is any error being thrown during the creation of
     *         								the realm, it is wrapped into an exception of this type and 
     *         								re-thrown.
     */
    private OpenIdConfig getKeycloakClient(KeycloakTokenSession session, String realmName, String clientId) throws IdentityProviderException {

        Map<String, Object> keyInfo = this.getRealmPublicKeyInformation(session, realmName);
        String publicKey = this.extractPublicKey(keyInfo, 0);

        Map<String, Object> clientInfo = this.getClientInformation(session, realmName, clientId);
        if (clientInfo == null) {
            return null;
        }

        Map<String, Object> clientSecretInfo =  this.getClientSecretInformation(session, 
        																		realmName, 
        																		(String) clientInfo.get(ManagedIdentityProviderClientImpl.CLIENT_CLIENTID_ID_ATTRIBUTE));


        String realmUri = String.format("%s/auth/realms/%s", this.getBasePublicUrl(), realmName);
        String issuer = realmUri;
        String authorizationUri = String.format("%s/protocol/openid-connect/auth", realmUri);
        String accessTokenUri = String.format("%s/protocol/openid-connect/token", realmUri);

        OpenIdConfig openIdConfig = new OpenIdConfig();

        openIdConfig.setClientId(clientInfo.get(ManagedIdentityProviderClientImpl.CLIENT_CLIENTID_ATTRIBUTE) .toString());
        openIdConfig.setClientSecret(clientSecretInfo.get(ManagedIdentityProviderClientImpl.CLIENT_SECRET_ATTRIBUTE).toString());
        openIdConfig.setGrantType((boolean) clientInfo.get(ManagedIdentityProviderClientImpl.CLIENT_SERVICE_ACCOUNTS_ENABLED)
                                        ? BgxConstants.OAUTH_CLIENT_CREDENTIALS_GRANT_TYPE
                                        : BgxConstants.OAUTH_PASSWORD_GRANT_TYPE);

        openIdConfig.setAccessTokenUri(accessTokenUri);
        openIdConfig.setUserAuthorizationUri(authorizationUri);
        openIdConfig.setIssuer(issuer);
        openIdConfig.setIssuerPublicKey(publicKey);
        openIdConfig.setProvider(Provider.KEYCLOAK);
        openIdConfig.setScopes(Arrays.asList(BgxConstants.OPENID_SCOPE));

        return openIdConfig;
    }

    /**
     * This class uses the Keycloak Admin api to retrieve the public key associated with the realm.
     *
     * @param session	a {@link KeycloakTokenSession} instance that is used to isolate the operation
     * 					of a specific client. This instance contains the collection of OpenID Connect
     * 					tokens that are specific to a given user interaction. It cannot be {@literal 
     * 					null}.
     *
     * @param realmName name of the realm for which the public key information is retrieved. It is
     *        			expected to not to be {@literal null} or an empty string.
     * 
     * @return a {@link Map} implementation that contains the list of public keys associated to the
     *         specified realm. The public keys array is mapped to the attribute
     *         {@link ManagedIdentityProviderClientImpl#REALM_KEYS_ATTRIBUTE}.
     * 
     * @throws IdentityProviderException if there is any error being thrown during the creation of
     *         the realm, it is wrapped into an exception of this type and re-thrown.
     */
    @SuppressWarnings("unchecked")
	private Map<String, Object> getRealmPublicKeyInformation(KeycloakTokenSession session, String realmName) throws IdentityProviderException {

        String url = String.format("%s/%s/realms/%s/keys", this.getBasePrivateUrl(), this.getAdminPath(), realmName);


        try {
            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(headers);

            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = this.getRestTemplate().exchange(url, HttpMethod.GET, request, Map.class);

            return response.getBody();

        } catch (Exception e) {

            throw new IdentityProviderException("Could not retrieve information about public key of the realm.", e);

        }
    }

    /**
     * Retrieve full realm details
     *
     * @param session
     * @param realmName
     * @return
     * @throws IdentityProviderException
     */
    private Map<String, Object> getRealmInformation(KeycloakTokenSession session, String realmName) throws IdentityProviderException {

        String url = String.format("%s/%s/realms/%s", this.getBasePrivateUrl(), this.getAdminPath(), realmName);


        try {
            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(headers);

            @SuppressWarnings("rawtypes")
            ResponseEntity<Map> response = this.getRestTemplate().exchange(url, HttpMethod.GET, request, Map.class);

            return response.getBody();

        } catch (Exception e) {

            throw new IdentityProviderException("Could not retrieve information about public key of the realm.", e);

        }
    }

    /**
     * Get realm auth execution flow details
     * @param session
     * @param realmName
     * @return
     * @throws IdentityProviderException
     */
    private List<KeycloakAuthExecutionInfo> getRealmAuthFlowExecutions(KeycloakTokenSession session, String realmName, String authFlowName) throws IdentityProviderException {

        try {
            String url = String.format("%s/%s/realms/%s/authentication/flows/%s/executions", this.getBasePrivateUrl(), this.getAdminPath(), realmName, authFlowName);

            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(headers);

            ResponseEntity<List<KeycloakAuthExecutionInfo>> response = this.getRestTemplate().exchange(
                url, HttpMethod.GET, request,
                new ParameterizedTypeReference<List<KeycloakAuthExecutionInfo>>() {});

            return response.getBody();

        } catch (Exception e) {

            throw new IdentityProviderException("Could not retrieve information about public key of the realm.", e);

        }
    }

    /**
     * Disable browser authentication cookie
     *
     * This is to avoid letting user to be logged in automatically by Keycloak based on browser cookies
     *
     * @param session
     * @param realmName
     * @throws IdentityProviderException
     */
    private void disableBrowserAuthCookie(KeycloakTokenSession session, String realmName) throws IdentityProviderException {

        try {
            String authFlowName = "browser";
            List<KeycloakAuthExecutionInfo> executionInfos = this.getRealmAuthFlowExecutions(session, realmName, authFlowName);

            KeycloakAuthExecutionInfo browserExec = null;
            for(KeycloakAuthExecutionInfo executionInfo : executionInfos) {
                if (executionInfo.getProviderId().equals("auth-cookie")) {
                    browserExec = executionInfo;
                    break;
                }
            }

            if (browserExec == null) {
                throw new IllegalArgumentException(
                    String.format("Could not find '%s' authentication execution information for realm '%s'", authFlowName, realmName));
            }

            // disable
            browserExec.setRequirement(Requirement.DISABLED);

            String url = String.format("%s/%s/realms/%s/authentication/flows/%s/executions", this.getBasePrivateUrl(), this.getAdminPath(), realmName, authFlowName);
            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(browserExec, headers);

            this.getRestTemplate().exchange(url, HttpMethod.PUT, request, Map.class);

        } catch (Exception e) {

            throw new IdentityProviderException("Could not retrieve information about public key of the realm.", e);

        }
    }

    /**
     * This method makes a call to the Keycloak API to retrieve the information associated the
     * specified OpenID Connect client.
     *
     * @param session	a {@link KeycloakTokenSession} instance that is used to isolate the operation
     * 					of a specific client. This instance contains the collection of OpenID Connect
     * 					tokens that are specific to a given user interaction. It cannot be {@literal 
     * 					null}.
     *
     * @param realmName name of the realm. It is expected to not to be {@literal null} or an empty
     *        			string.
     * 
     * @param clientId 	a {@link String} containing the unique identifier of the client for which the
     *        			information is being retrieved. It is expected to not to be {@literal null} or 
     *        			an empty string.
     * 
     * @return a {@link Map} implementation containing the details and configuration attributes of
     *         the specified client.
     * 
     * @throws IdentityProviderException if there is any error being thrown during the creation of
     *         the realm, it is wrapped into an exception of this type and re-thrown.
     */
    @SuppressWarnings("unchecked")
	private Map<String, Object> getClientInformation(KeycloakTokenSession session, String realmName, String clientId) throws IdentityProviderException {

        Map<String, Object> clientInfo = null;
        String url = String.format("%s/%s/realms/%s/clients?clientId={clientId}", this.getBasePrivateUrl(), this.getAdminPath(), realmName);


        try {
            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(headers);
            @SuppressWarnings("rawtypes")
			ResponseEntity<List> response = this.getRestTemplate().exchange(url, HttpMethod.GET, request, List.class, clientId);

            @SuppressWarnings({ "rawtypes"})
			List<Map> clients = response.getBody();

            for (@SuppressWarnings("rawtypes") Map client : clients) {

                if (client.get(ManagedIdentityProviderClientImpl.CLIENT_CLIENTID_ATTRIBUTE).equals(clientId)) {
                    clientInfo = client;
                    break;
                }
            }

            return clientInfo;

        }  catch (Exception e) { 
         
        	throw new IdentityProviderException(String.format("Could not retrieve information about the client of the realm (realm: %s, clientId: %s).", realmName, clientId), e);

        }
    }

    /**
     * This class uses the Keycloak admin API to retrieve the information about the client secret.
     *
     * @param session	a {@link KeycloakTokenSession} instance that is used to isolate the operation
     * 					of a specific client. This instance contains the collection of OpenID Connect
     * 					tokens that are specific to a given user interaction. It cannot be {@literal 
     * 					null}.
     *
     * @param realmName name of the realm. It is expected to not to be {@literal null} or an empty
     *        			string.
     *        
     * @param id 		the unique identifier of the client for which to retrieve the secret. It is
     *        			expected to not to be {@literal null} or an empty string.
     * 
     * @return a {@link Map} implementation containing information related to the Bank Guarantee api
     *         client secret.
     * 
     * 
     * @throws IdentityProviderException if there is any error being thrown during the creation of
     *         the realm, it is wrapped into an exception of this type and re-thrown.
     */
    @SuppressWarnings("unchecked")
	private Map<String, Object> getClientSecretInformation(KeycloakTokenSession session, String realmName, String id) throws IdentityProviderException {

        String url = String.format("%s/%s/realms/%s/clients/%s/client-secret", this.getBasePrivateUrl(), this.getAdminPath(), realmName, id);

        try {
            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(headers);
            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = this.getRestTemplate().exchange(url, HttpMethod.GET, request, Map.class);

            return response.getBody();

        } catch (Exception e) {

            throw new IdentityProviderException(String.format("Could not retrieve client secret information (realm: %s, clientId: %s).", realmName, id), e);
        }
    }

    /**
     * This method invokes the Keycloak API to disable the client identified by <i>id</i>.
     *
     * @param session	a {@link KeycloakTokenSession} instance that is used to isolate the operation
     * 					of a specific client. This instance contains the collection of OpenID Connect
     * 					tokens that are specific to a given user interaction. It cannot be {@literal 
     * 					null}.
     *
     * @param realmName a {@link String} containing the name of the realm for which the client is
     *        			defined. It is expected to not to be {@literal null} or an empty string.
     *        
     * @param clientId 	a {@link String} containing the unique identifier of the OpenID Connect client
     *        			through which execute the request to the APIs. It is expected to not to be
     *        			{@literal null} or an empty string.
     *        
     * @param id 		a {@link String} representing the unique identifier of the client to disable. 
     * 					It is expected to not to be {@literal null} or an empty string.
     * 
     * @throws IdentityProviderException 	if there is any error being thrown during the interaction
     * 										with the provider. The original exception is wrapped into 
     * 										an exception of this type and re-thrown.
     */
    private void disableClient(KeycloakTokenSession session, String realmName, String clientId, String id) throws IdentityProviderException {

        String url = String.format("%s/%s/realms/%s/clients/%s", this.getBasePrivateUrl(), this.getAdminPath(), realmName, id);

        try {
            HttpHeaders headers = generateBearerAuthorizationHeader(session);

            KeycloakClientRepresentationRequest body = new KeycloakClientRepresentationRequest();
            body.setClientId(clientId);
            body.setEnabled(false);

            HttpEntity<?> request = new HttpEntity<>(body, headers);
            this.getRestTemplate().exchange(url, HttpMethod.PUT, request, KeycloakClientRepresentationRequest.class);
            
        } catch (Exception e) {

            throw new IdentityProviderException(String.format("Could not disable the client (realm: %s, clientId: %s, id: %s).", realmName, clientId, id), e);
        }
    }

    /**
     * Makes a call to the Keycloak API in order to create the realm. Upon creation, the realm will
     * not be ready to be used as it still requires the creation of a client associated to the realm
     * through which authentication requests will be made.
     *
     * @param session	a {@link KeycloakTokenSession} instance that is used to isolate the operation
     * 					of a specific client. This instance contains the collection of OpenID Connect
     * 					tokens that are specific to a given user interaction. It cannot be {@literal 
     * 					null}.
     *
     * @param realmName name of the realm. It is expected to not to be {@literal null} or an empty
     *        			string.
     *        
     * @param displayNameHtml name in HTML format that will be displayed in the login page.
     * 
     * @throws IdentityProviderException 	if there is any error being thrown during the creation of
     *         							  	the realm. The original error (if any) is wrapped into an 
     *         								exception of this type and re-thrown.
     */
    private void createKeycloakRealm(KeycloakTokenSession session, String realmName, String displayNameHtml) throws IdentityProviderException {

        try {

            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);

            KeycloakRealmRepresentationRequest keycloakRealmRepresentationRequest = new KeycloakRealmRepresentationRequest();

            keycloakRealmRepresentationRequest.setId(realmName);
            keycloakRealmRepresentationRequest.setRealm(realmName);
            keycloakRealmRepresentationRequest.setDisplayName(DEFAULT_DISPLAY_NAME);
            keycloakRealmRepresentationRequest.setDisplayNameHtml(displayNameHtml);
            keycloakRealmRepresentationRequest.setEnabled(true);
            keycloakRealmRepresentationRequest.setLoginWithEmailAllowed(true);
            keycloakRealmRepresentationRequest.setLoginTheme(this.realmTheme);
            keycloakRealmRepresentationRequest.setAccountTheme(this.realmTheme);
            keycloakRealmRepresentationRequest.setEmailTheme(this.realmTheme);
            keycloakRealmRepresentationRequest.setAdminTheme(this.realmTheme);

            // Security settings for the realm: password policy, password reset, brute force
            // protection, failure factor, ....
            //
            // TODO: Make failureFactor which is the same as maxLoginFailures customizable
            //
            keycloakRealmRepresentationRequest.setResetPasswordAllowed(this.resetPasswordAllowed);
            keycloakRealmRepresentationRequest.setPasswordPolicy(ManagedIdentityProviderClientImpl.REALM_PASSWORD_POLICY);
            keycloakRealmRepresentationRequest.setBruteForceProtected(true);
            keycloakRealmRepresentationRequest.setPermanentLockout(false);
            keycloakRealmRepresentationRequest.setFailureFactor(BigInteger.valueOf(5));
            keycloakRealmRepresentationRequest.setWaitIncrementSeconds(BigInteger.valueOf(1800));

            // Set OTP policy
            keycloakRealmRepresentationRequest.setOtpPolicyType(otpType);
            keycloakRealmRepresentationRequest.setOtpPolicyAlgorithm(otpAlgo);
            keycloakRealmRepresentationRequest.setOtpPolicyDigits(BigInteger.valueOf(otpDigits));
            keycloakRealmRepresentationRequest.setOtpPolicyInitialCounter(BigInteger.valueOf(otpCounter));
            keycloakRealmRepresentationRequest.setOtpPolicyLookAheadWindow(BigInteger.valueOf(otpLookAheadWindow));
            keycloakRealmRepresentationRequest.setOtpPolicyPeriod(BigInteger.valueOf(otpPeriod));

            // Setting the SMTP Server Details for th Realm that is being created.
            //
            Map<String, String> smtpServer = new HashMap<>();
            smtpServer.put(ManagedIdentityProviderClientImpl.REALM_MAIL_SERVER_HOST, smtpServerHost);
            smtpServer.put(ManagedIdentityProviderClientImpl.REALM_MAIL_FROM, smtpServerFrom);
            smtpServer.put(ManagedIdentityProviderClientImpl.REALM_MAIL_REPLY_TO, smtpServerReplyTo);
            smtpServer.put(ManagedIdentityProviderClientImpl.REALM_MAIL_SERVER_PORT, smtpServerPort);
            smtpServer.put(ManagedIdentityProviderClientImpl.REALM_MAIL_SERVER_SSL, smtpServerSsl);
            smtpServer.put(ManagedIdentityProviderClientImpl.REALM_MAIL_SERVER_AUTH, smtpServerAuth);
            
            if (smtpServerAuth != null && smtpServerAuth.trim().equalsIgnoreCase("true")) {
                smtpServer.put(ManagedIdentityProviderClientImpl.REALM_MAIL_SERVER_USERNAME, smtpServerUsername);
                smtpServer.put(ManagedIdentityProviderClientImpl.REALM_MAIL_SERVER_PASSWORD, smtpServerPassword);
            }
            keycloakRealmRepresentationRequest.setSmtpServer(smtpServer);

            HttpEntity<KeycloakRealmRepresentationRequest> request =  new HttpEntity<>(keycloakRealmRepresentationRequest, headers);

            // URL to be used, we can use the internal URL here because we are performing the realm
            // creation and no information is sent back to the client in terms of URL details.
            //
            String url = String.format("%s/%s/realms", this.getBasePrivateUrl(), this.getAdminPath());


            this.getRestTemplate().exchange(url, HttpMethod.POST, request, Map.class);

            // Disable auth-cookie
            this.disableBrowserAuthCookie(session, realmName);

        } catch (Exception e) {
        	
        	throw new IdentityProviderException(String.format("Could not create realm (name: %s).", realmName), e);
        }

    }


    /**
     * This method invokes the Keycloak API to create an OpenID Connect client.
     *
     * @param session	a {@link KeycloakTokenSession} instance that is used to isolate the operation
     * 					of a specific client. This instance contains the collection of OpenID Connect
     * 					tokens that are specific to a given user interaction. It cannot be {@literal 
     * 					null}.
     *
     * @param realmName name of the realm.It is expected to not to be {@literal null} or an empty
     *        			string.
     *        
     * @param clientId 	a {@link String} containing the unique identifier of the client being
     *        			created. It is expected to not to be {@literal null} or an empty string.
     * 
     * @param redirectUrl list of urls that will be accepted for redirecting the user after login.
     * 
     * @param grantType a {@link String} containing the type of grant associated to the client. This
     *        			parameter can be one of the two values: {@link BgxConstants#OAUTH_PASSWORD_GRANT_TYPE}
     *        			or {@link BgxConstants#OAUTH_CLIENT_CREDENTIALS_GRANT_TYPE}.
     * 
     * @throws IdentityProviderException 	if there is any error being thrown during the creation of
     *         							  	the client. The original error (if any) is wrapped into an 
     *         								exception of this type and re-thrown.
     */
    private void createKeycloakClient(KeycloakTokenSession session, String realmName,
                    String clientId, List<String> redirectUrl, String grantType)
                    throws IdentityProviderException {

        String url = String.format("%s/%s/realms/%s/clients", this.getBasePrivateUrl(), this.getAdminPath(), realmName);


        try {
            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);

            KeycloakClientRepresentationRequest keycloakClientRepresentationRequest = new KeycloakClientRepresentationRequest();

            keycloakClientRepresentationRequest.setClientId(clientId);

            switch (grantType) {
                case BgxConstants.OAUTH_PASSWORD_GRANT_TYPE:
                    keycloakClientRepresentationRequest.setRedirectUris(redirectUrl);
                    keycloakClientRepresentationRequest.setImplicitFlowEnabled(false);
                    keycloakClientRepresentationRequest.setStandardFlowEnabled(true);
                    keycloakClientRepresentationRequest.setServiceAccountsEnabled(false);
                    keycloakClientRepresentationRequest.setDirectAccessGrantsEnabled(true);
                    break;
                case BgxConstants.OAUTH_CLIENT_CREDENTIALS_GRANT_TYPE:
                    keycloakClientRepresentationRequest.setImplicitFlowEnabled(false);
                    keycloakClientRepresentationRequest.setStandardFlowEnabled(false);
                    keycloakClientRepresentationRequest.setServiceAccountsEnabled(true);
                    keycloakClientRepresentationRequest.setDirectAccessGrantsEnabled(false);
                    break;
                default:
                    break;
            }

            HttpEntity<KeycloakClientRepresentationRequest> request = new HttpEntity<>(keycloakClientRepresentationRequest, headers);

           this.getRestTemplate().exchange(url, HttpMethod.POST, request, Map.class);

        } catch (RestClientException e) {

            throw new IdentityProviderException(String.format("Could not create client in realm (name: %s, clientId: %s).", realmName, clientId), e);
        }
    }


    /**
     * This method invokes the Keycloak APIs to retrieve the information about the specified user.
     *
     * @param session	a {@link KeycloakTokenSession} instance that is used to isolate the operation
     * 					of a specific client. This instance contains the collection of OpenID Connect
     * 					tokens that are specific to a given user interaction. It cannot be {@literal 
     * 					null}.
     * 
     * @param realmName name of the realm wher the user has been created. It is expected to not to
     *        			be {@literal null} or an empty string.
     *        
     * @param username name of the user for which the information will be retrieved. It is expected
     *        			to not to be {@literal null} or an empty string.
     * 
     * @return a {@link Map} implementation containing the information about the user.
     * 
     * @throws IdentityProviderException 	if there is any error being thrown during the retrieval of
     * 										user information. The original error (if any) is wrapped into 
     * 										an exception of this type and re-thrown.
     */
    private Map<String, Object> getUserInformation(KeycloakTokenSession session, String realmName, String username) throws IdentityProviderException {

        String url = String.format("%s/%s/realms/%s/users?username={username}", this.getBasePrivateUrl(), this.getAdminPath(), realmName);

        Map<String, Object> userInfo = null;

        try {
            HttpHeaders headers = generateBearerAuthorizationHeader(session);
            HttpEntity<?> request = new HttpEntity<>(headers);


            @SuppressWarnings("rawtypes")
			ResponseEntity<List> response = this.getRestTemplate().exchange(url, HttpMethod.GET, request, List.class, username);
            @SuppressWarnings("unchecked")
			List<Map<String, Object>> users = response.getBody();

            int size = users.size();

            if (size > 0) {

                if (size > 1) {

                    throw new IdentityProviderException(String.format("There is more than one user with the same username (realm: %s, name: %s, occurrences: %d).", realmName, username, users.size()));
                }

                userInfo = users.get(0);
            }
            
            return userInfo;

            
        } catch (IdentityProviderException e) {
        	
        	throw e;
        
        } catch (Exception e) {
        	
            throw new IdentityProviderException(String.format("Could not retrieve user information (realm: %s, name: %s).", realmName, username), e);
        }
    }

    /**
     * This method invokes the Keycloak API to create a user within the specified realm.
     * 
     * @param session		a {@link KeycloakTokenSession} instance that is used to perform the creation
     * 						of the user. It is expected to not to be {@literal null}.
     * @param realmName		name of the realm where the user will be created. It is expected to not to be
     *        				{@literal null} or an empty string.
     * @param username 		name of the user for which the information will be retrieved. It is expected
     *        				to not to be {@literal null} or an empty string.
     * @param lastName 		a {@link String} containing the first name of the user.
     * @param firstName 	a {@link String} containing the last name of the user.
     * 
     * @throws IdentityProviderException 	if there is any error being thrown during the creation of the
     * 										user. The original error (if any) is wrapped into an exception 
     * 										of this type and re-thrown.
     */
    private void createKeycloakUser(KeycloakTokenSession session, String username, String firstName, String lastName, String realmName) throws IdentityProviderException {

        String url = String.format("%s/%s/realms/%s/users", this.getBasePrivateUrl(), this.getAdminPath(), realmName);


        try {
            HttpHeaders headers = this.generateBearerAuthorizationHeader(session);

            KeycloakUserRepresentationRequest keycloakUserRepresentationRequest =  new KeycloakUserRepresentationRequest();

            keycloakUserRepresentationRequest.setUsername(username);
            keycloakUserRepresentationRequest.setEmail(username);
            keycloakUserRepresentationRequest.setFirstName(firstName);
            keycloakUserRepresentationRequest.setLastName(lastName);
            keycloakUserRepresentationRequest.setEnabled(true);

            HttpEntity<KeycloakUserRepresentationRequest> request = new HttpEntity<>(keycloakUserRepresentationRequest, headers);

            this.getRestTemplate().exchange(url, HttpMethod.POST, request, Map.class);
            
        } catch (Exception e) {

            throw new IdentityProviderException(String.format("Could not create user (realm: %s, username: %s).", realmName, username), e);
        }
    }


    /**
     * Generates a header to be used for calling admin functions exposed by the Keycloak APIs.
     *
     * @return an instance of {@lik HttpHeaders} containing one header specifying the content type
     *         (JSON) and the authentication token required to make admin calls.
     * 
     * @throws IdentityProviderException 	if there is any error being thrown during the retrieval of the
     * 										tokens. The original error (if any) is wrapped into an exception 
     * 										of this type and re-thrown.
     */
    private HttpHeaders generateBearerAuthorizationHeader(KeycloakTokenSession tokenSession) {
    	
        if (tokenSession == null || tokenSession.getOIDCTokens() == null) {
        	
            throw new IllegalArgumentException("Keycloak token session is null or OIDC tokens are null.");
        }
        OIDCTokens tokens = tokenSession.getOIDCTokens();


        HttpHeaders bearerAuthorizationHeader = new HttpHeaders();
        bearerAuthorizationHeader.setContentType(MediaType.APPLICATION_JSON);
        bearerAuthorizationHeader.add(BgxConstants.AUTHORIZATION_HEADER, BgxConstants.BEARER_PREFIX + tokens.getAccessToken().getValue());


        return bearerAuthorizationHeader;
    }

    /**
     * This method initialises a token session. This is used to isolate the interaction with the federated
     * identity provide per user and avoid inconsistent behaviour in a multi-tenant environment where
     * this instance is invoked as a result of multiple user requests.
     *
     * @return	a {@link KeycloakTokenSession} instance that contains the collection of OpenID Connect tokens
     * 			for a given user.
     * 
     * @throws 	IdentityProviderException	thrown if the client encounters error while retrieving the OpenID
     * 										Connect tokens to initialise the session. 
     */
    private KeycloakTokenSession initKeycloakTokenSession() throws IdentityProviderException {
    	
        OIDCTokens tokens = this.getValidOIDCTokens(null, this.getAdminUsername(), this.getAdminPassword(), this.getClientId(), this.getPrivateTokenUri());

        Map<String, String> sessionConfig = new HashMap<>();
        sessionConfig.put(KeycloakTokenSession.CLIENT_ID, this.getClientId());
        sessionConfig.put(KeycloakTokenSession.REALM, ManagedIdentityProviderClientImpl.REALM_MASTER);

        LOGGER.debug(BgxLogMarkers.DEV,
        			 "Creating Keycloak Token Session for (realm: {}, clientId: {})", 
        			 ManagedIdentityProviderClientImpl.REALM_MASTER, 
        			 this.getClientId());

        KeycloakTokenSession session = new KeycloakTokenSession(logoutClient, tokens, sessionConfig);

        return session;
    }


    /**
     * <p>
     * Gets the collection of OpenID Connect tokens required to authenticate against Keycloak. The
     * method uses the grant type set to {@link BgxConstants#OAUTH_PASSWORD_GRANT_TYPE} and
     * therefore requires username/password credentials for the retrieval of the tokens.
     * </p>
     * <p>
     * The method checks the current expiration time of the existing tokens, and if these have less
     * than five second left, they are refreshed and the method retrieves new tokens.
     * </p>
     *
     * @param username a {@link String} containing the username to retrieve the tokens for. It is
     *        expected to not to be {@literal null} or an empty string.
     * @param password a {@link String} containing the password credentials requird to validate
     *        <i>username</i>.
     * @param clientId a {@link String} containing the unique identifier of the client through which
     *        the request is made to the APIS. It is expected to not to be {@literal null} or an
     *        empty string.
     * @param tokenUri a {@link String} containing the relative path to the base URL of the
     *        configured Keycloak instance that provides the capabilities to retrieve the
     *        authentication tokens.
     * 
     * @return a {@link OIDCTokens} object that contains th information about the tokens.
     * 
     * @throws IdentityProviderException if there is any error being thrown during the creation of
     *         the realm, it is wrapped into an exception of this type and re-thrown.
     */
    private OIDCTokens getValidOIDCTokens(KeycloakTokenSession session, String username, String password, String clientId, String tokenUri) throws IdentityProviderException {

        boolean isTokenAboutToExpire = false;

        if (session == null || session.getOIDCTokens() == null) {
        	
            isTokenAboutToExpire = true;
       
        } else {
        	
            long timeLeft = session.getOIDCTokens().getAccessToken().getLifetime() - ((System.currentTimeMillis() - session.getTokenCreationTime()) / 1000);
            // If the token has less than 5 seconds of life, set isTokenAboutToExpire to true
            if (timeLeft < 5) {
            	
            	try {
            		
            		session.close();
            	
            	} catch(Exception e) {
            	
            		LOGGER.warn(BgxLogMarkers.DEV, String.format("Could not log out from KeyCloack session (clientId: %s, username: %s).", clientId, username), e);
            	}
            	isTokenAboutToExpire = true;
            }

        }

        if (isTokenAboutToExpire) {


            try {

                Secret passwordSecret = new Secret(password);
                AuthorizationGrant passwordGrant = new ResourceOwnerPasswordCredentialsGrant(username, passwordSecret);

                // The credentials to authenticate the client at the token endpoint
                ClientID clientID = new ClientID(clientId);

                // The request scope for the token
                Scope scope = new Scope(BgxConstants.OPENID_SCOPE);

                // The token endpoint
                URI tokenEndpoint = new URI(tokenUri);

                // Make the token request
                TokenRequest request = new TokenRequest(tokenEndpoint, clientID, passwordGrant, scope);
                HTTPRequest httpRequest = request.toHTTPRequest();
                
                // we configure the socket factory if we use SSL.
                //
                if (this.sslUtils.isSSL(httpRequest.getURL())) {
                	
                	httpRequest.setSSLSocketFactory(this.sslUtils.getSSLSocketFactory());
                }
                HTTPResponse response = httpRequest.send();

                TokenResponse tokenResponse = OIDCTokenResponseParser.parse(response);

                OIDCTokenResponse successResponse = null;
                if (!tokenResponse.indicatesSuccess()) {
               
                    TokenErrorResponse errorResponse = tokenResponse.toErrorResponse();
                    LOGGER.error(BgxLogMarkers.DEV, "tokenError {}", errorResponse.toJSONObject().toJSONString());
                    
                } else {
                	
                    successResponse = (OIDCTokenResponse) tokenResponse.toSuccessResponse();
                }

                return (successResponse == null ? null : successResponse.getOIDCTokens());

            } catch (IOException | ParseException | URISyntaxException ex) {

                throw new IdentityProviderException(String.format("An error occurred while trying to refresh tokens (clientId: %s, username: %s).", clientId, username), ex);
            }
        }
        return null;
    }

    /**
     * This method extracts the value of the public key associated to a realm from the information
     * that are passed as an argument to the method. This is a utility method that is used
     * internally.
     * 
     * @param keyInfo a {@link Map} implementation that contains the details of the public keys
     *        associated to a given realm. This {@link Map} is returned by the method
     *        {@link ManagedIdentityProviderClientImpl#getRealmPublicKeyInformation(KeycloakTokenSession, String)} which
     *        contains all the details about the public keys associated to a realm.
     * 
     * @param index an {@literal int} value representing the index of the key of interest to
     *        extract.
     * 
     * @return a {@link String} representing the value of the selected public key.
     */
    private String extractPublicKey(Map<String, Object> keyInfo, int index) {

        @SuppressWarnings("unchecked")
		List<Object> keys = (List<Object>) keyInfo.get(ManagedIdentityProviderClientImpl.REALM_KEYS_ATTRIBUTE);
        @SuppressWarnings("unchecked")
		Map<String, Object> key = (Map<String, Object>) keys.get(index);
        return (String) key.get(ManagedIdentityProviderClientImpl.REALM_PUBLIC_KEY_ATTRIBUTE);

    }


    /**
     * Creates the URL for the interacting with the one time password management extension.
     * 
     * @param realmName		a {@link String} representing the name of the realm. It is expected to not to be {@literal null}.
     * @param userId		a {@link String} representing the unique identifier of the user. It is expected to not to be {@literal null}.
     * 
     * @return	a {@link String} that contains the full URL of the OTP management endpoint, for the givn realm and user.
     */
    protected String getOtpUrl(String realmName, String userId) {

        return String.format("%s/auth/realms/%s/otp/users/%s", this.getBasePrivateUrl(), realmName, userId);

    }
    
    
    
    /**
     * This is a utility method that is used to validate the given user information and extract the unique identifier
     * of the user. If the operation is unsuccessful, then an {@link IdentityProviderException} is thrown.
     * 
     * @param userInfo		a {@link Map} implementation that contains the user information (attributes) as returned
     * 						by a federated identity provider. It is expected to not to be {@literal null}.
     * @param realmName		a {@link String} representing the name of the realm the user belongs to.
     * @param username		a {@link String} representing the name of the user.
     * 
     * @return a {@link String} representing the unique identifier of the user.
     * 
     * @throws IdentityProviderException	if <i>userInfo</i> is {@literal null} or it does not contain the key that
     * 										is mapped by {@link ManagedIdentityProviderClientImpl#USER_USERID_ATTRIBUTE}
     * 										or such key maps to a {@literal null} value.
     */
    protected String validateUserInfo(Map<String, Object> userInfo, String realmName, String username) throws IdentityProviderException {
    
    	String userId = null;
    	
    	if (userInfo == null || 
    		!userInfo.containsKey(ManagedIdentityProviderClientImpl.USER_USERID_ATTRIBUTE) || 
	        (userId = (String) userInfo.get(ManagedIdentityProviderClientImpl.USER_USERID_ATTRIBUTE)) == null)  {
	        	
	        	throw new IdentityProviderException(String.format("User NOT FOUND (realm: %s, username: %s).", realmName, username));
	    }
    	
    	return userId;
    }

}
