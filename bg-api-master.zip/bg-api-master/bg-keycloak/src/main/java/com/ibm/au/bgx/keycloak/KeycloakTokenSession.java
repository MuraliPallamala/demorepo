package com.ibm.au.bgx.keycloak;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ibm.au.bgx.model.exception.IdentityProviderException;
import com.ibm.au.bgx.model.identityprovider.LogoutClient;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.nimbusds.openid.connect.sdk.token.OIDCTokens;

/**
 * Class <b>KeycloakTokenSession</b>. This class implements {@link AutoCloseable} and provides the 
 * capability of storing the information about a specific session for a client that is interacting
 * with the federated identity provider, in particular the OpenID Connect tokens.
 * 
 * @author Bruno De Assis Marques <brunomar@au1.ibm.com>
 */
public class KeycloakTokenSession implements AutoCloseable {

    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(KeycloakTokenSession.class);

    /**
     * A {@link Long} value that contains the creation time of the authentication token.
     */
    private Long tokenCreationTime;

    /**
     * A {@link OIDCTokens} instance that holds the collection of currently active tokens.
     */
    private OIDCTokens currentOIDCTokens;

    /**
     * A {@link Map} implementation that contains a collection of attributes for a client connection.
     */
    private Map<String, String> sessionConfig;
    
    /**
     * A {@link String} representing the name of the attributes that store the unique client identifier.
     */
    public static final String CLIENT_ID = "clientId";
    /**
     * A {@link String} representing the name of the attribute that stores the information about the
     * realm the token session is attached to. 
     */
    public static final String REALM = "realm";


    /**
     * A {@link LogoutClient} instance that is used to logout the client when interacting with the
     * Keycloak instance.
     */
    private LogoutClient logoutClient;

    /**
     * Initialises an instance of {@link KeycloakTokenSession} with the given components.
     * 
     * @param logoutClient			a {@link LogoutClient} implementation that is used to log out the
     * 								OpenID Connect client that is attached to the current session.
     * @param currentOIDCTokens		a {@link OIDCTokens} that contains the list of tokens that are
     * 								associated to the session.
     * @param sessionConfig			a {@link Map} implementation containing the collection of attributes
     * 								that are relevant to the session. At this point in time only two
     * 								attributes are stored the client id and the realm associated to the
     * 								session, mapped by {@link KeycloakTokenSession#CLIENT_ID} and {@link 
     * 								KeycloakTokenSession#REALM}. 
     * 
     * @throws IllegalArgumentException	if one of the following occurs:
     * 									<ul>
     * 									<li><i>logoutClient</i> is {@literal null}</li>
     * 									<li><i>currentOIDCTokens</i> is {@literal null}</li>
     * 									<li><i>sessionConfig</i> is {@literal null}</li>
     * 									<li><i>sessionConfig</i> does not contain client identifier and realm
     * 									information</li>
     * 									</ul>
     */
    public KeycloakTokenSession(LogoutClient logoutClient, OIDCTokens currentOIDCTokens, Map<String, String> sessionConfig) {
        
    	if (logoutClient == null) {
    		
    		throw new IllegalArgumentException("Parameter 'logoutClient' cannot be null.");
    	}
    	
    	if (currentOIDCTokens == null) {
    		
    		throw new IllegalArgumentException("Parameter 'currentOIDCTokens' cannot be null.");
    	}
    	
    	
    	if (sessionConfig == null || 
        	!sessionConfig.containsKey(KeycloakTokenSession.REALM) || 
        	!sessionConfig.containsKey(KeycloakTokenSession.CLIENT_ID)) {
            
    		throw new IllegalArgumentException("Parameter 'sessionConfig' is either null or does not contain the required attributes.");
        }

        this.tokenCreationTime = System.currentTimeMillis();

        this.currentOIDCTokens = currentOIDCTokens;
        this.logoutClient = logoutClient;
        this.sessionConfig = sessionConfig;
    }

    /**
     * Implements the {@link AutoCloseable} pattern. This method internally calls {@link KeycloakTokenSession#close()}.
     * 
     * @throws IdentityProviderException	if there is any error while logging out the client.
     */
    @Override
    public void close() throws Exception {
    	
        this.logout();
    }

    /**
     * Logs out the current client. This method first checks whether the client has any token and
     * the associated refresh token. It the token is found the client is logged out.
     * 
     * @throws IdentityProviderException if there is any error being thrown during the creation of
     *         the realm, it is wrapped into an exception of this type and re-thrown.
     */
    private void logout() throws IdentityProviderException {

        if (this.currentOIDCTokens == null || this.currentOIDCTokens.getRefreshToken() == null) {

            LOGGER.warn(BgxLogMarkers.DEV, "Cant find refresh token, not logging out.");

        } else {
        	
            String clientId = this.sessionConfig.get(KeycloakTokenSession.CLIENT_ID);
            String realm = this.sessionConfig.get(KeycloakTokenSession.REALM);

            this.logoutClient.logout(clientId, null, this.currentOIDCTokens.getRefreshToken().getValue(), realm);
            this.currentOIDCTokens = null;
        }
    }

    /**
     * Gets the OpenID Connect tokens that have been retrieved for the current session.
     * 
     * @return	a {@link OIDCTokens} instance containing the tokens.
     */
    protected OIDCTokens getOIDCTokens() {
        return this.currentOIDCTokens;
    }

    /**
     * Gets the time of the creation of the token in Unix Epoch time format.
     * 
     * 
     * @return	a {@literal long} value representing the number of milliseconds 
     * 			elapsed since January 1, 1970.
     */
    public long getTokenCreationTime() {
    	
        return this.tokenCreationTime;
    }


}
