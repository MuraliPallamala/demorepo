package com.ibm.au.bgx.keycloak;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

/**
 * Class <b>LoggingRequestInterceptor</b>. This class implements {@link ClientHttpRequestInterceptor}
 * and provides the capability of logging the content of the request and response objects that are
 * exchanged with the Keycloak federated identity provider.
 * 
 * @author Bruno De Assis Marques <brunomar@au1.ibm.com>
 */
public class LoggingRequestInterceptor implements ClientHttpRequestInterceptor {

	/**
	 * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(LoggingRequestInterceptor.class);
	
	
	/**
	 * A {@literal boolean} flag that controls whether the interceptor is logging the
	 * request body to {@literal true} or not {@literal false}.
	 */
	private boolean logRequestBody;

	/**
	 * A {@literal boolean} flag that controls whether the interceptor is logging the
	 * response body to {@literal true} or not {@literal false}.
	 */
	private boolean logResponseBody;
	
	/**
	 * Initialises an instance of the {@link LoggingRequestInterceptor} and sets the logging
	 * of both request and response body to {@literal true}.
	 */
	public LoggingRequestInterceptor() {
		this(true, true);
	}
	
	/**
	 * Initialises an instance of the {@link LoggingRequestInterceptor} and sets the logging of 
	 * both request and response boty to the value of <i>logBody</i>.
	 * 
	 * @param logBody	a {@literal boolean} value indicating whether the content of response body
	 * 					and request body should be logged {@literal true} or not {@literal false}. 
	 */
	public LoggingRequestInterceptor(boolean logBody) {
		
	}
	
	/**
	 * Initialises an instance of the {@link LoggingRequestInterceptor} and sets the logging of 
	 * both request and response body to the value of <i>logRequestBody</i> and <i>logResponseBody</i>.
	 * 
	 * 
	 * @param logRequestBody	a {@literal boolean} value indicating whether the content of the request 
	 * 							body should be logged {@literal true} or not {@literal false}.
	 * @param logResponseBody	a {@literal boolean} value indicating whether the content of the response
	 * 							body should be logged {@literal true} or not {@literal false}.
	 */
	public LoggingRequestInterceptor(boolean logRequestBody, boolean logResponseBody) {
		
		this.logRequestBody = logRequestBody;
		this.logResponseBody = logResponseBody;
	}
	
	/**
	 * Gets a {@literal boolean} value indicating whether the interceptor is logging the request body.
	 * 
	 * @return	{@literal true} if the request body is logged, {@literal false} otherwise.
	 */
	public boolean isLogRequestBody() {
		
		return this.logRequestBody;
	}

	/**
	 * Gets a {@literal boolean} value indicating whether the interceptor is logging the response body.
	 * 
	 * @return	{@literal true} if the response body is logged, {@literal false} otherwise.
	 */
	public boolean isLogResponseBody() {
		
		return this.logResponseBody;
	}

	/**
	 * Main intercept method. This method invokes {@link LoggingRequestInterceptor#traceRequest(HttpRequest, byte[])}
	 * before executing the HTTP request and {@link LoggingRequestInterceptor#traceResponse(ClientHttpResponse)} once
	 * the response has been received.
	 * 
	 * @param request		a {@link HttpRequest} instance that contains information about the request being submitted
	 * 						to the server.  
	 * @param body			a {@literal byte} array that contains the request body.
	 * @param execution		a {@link ClientHttpRequestExecution} instance that is used to execute the request.
	 * 
	 * @throws IOException	if there is any error with the HTTP exchange with the server.
	 */
	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
		
		this.traceRequest(request, body);
		ClientHttpResponse response = execution.execute(request, body);
		this.traceResponse(response);
		
		return response;
	}
	
	/**
	 * Traces the content of the HTTP request. This method dumps to the log the URI, HTTP method, headers collection, 
	 * and body of the request. The latter is logged if {@link LoggingRequestInterceptor#isLogRequestBody()} is {@literal true}
	 * and converted into a string by interpreting as UTF-8 string.
	 * 
	 * @param request		a {@link HttpRequest} instance that contains information about the request being submitted
	 * 						to the server.  
	 * @param body			a {@literal byte} array that contains the request body.
	 * 
	 * @throws IOException	if the conversion into string of the body fails.
	 */
	private void traceRequest(HttpRequest request, byte[] body) throws IOException {
		LOGGER.trace("===========================request begin================================================");
		LOGGER.trace("URI         : {}", request.getURI());
		LOGGER.trace("Method      : {}", request.getMethod());
		LOGGER.trace("Headers     : {}", request.getHeaders());
		
		if (this.isLogRequestBody()) {
			LOGGER.trace("Request body: {}", new String(body, "UTF-8"));
		}
		
		LOGGER.trace("==========================request end================================================");
	}

	/**
	 * Traces the content of the HTTP response. This method dumps to the log the URI, HTTP method, headers collection, 
	 * and body of the request. The latter is only logged if {@link LoggingRequestInterceptor#isLogResponseBody()} is
	 * set to {@literal true}, in that case the entire body of the response is read and logged as a string.
	 * 
	 * @param response		a {@link ClientHttpResponse} instance that contains information about the request being submitted
	 * 						to the server.
	 * 
	 * @throws IOException	if there is any issue in reading the input stream of the response.
	 */
	private void traceResponse(ClientHttpResponse response) throws IOException {
		
		LOGGER.trace("============================response begin==========================================");
		LOGGER.trace("Status code  : {}", response.getStatusCode());
		LOGGER.trace("Status text  : {}", response.getStatusText());
		LOGGER.trace("Headers      : {}", response.getHeaders());
		
		if (this.isLogResponseBody()) {
			
			StringBuilder inputStringBuilder = new StringBuilder();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(response.getBody(), "UTF-8"));
			String line = bufferedReader.readLine();
			while (line != null) {
				inputStringBuilder.append(line);
				inputStringBuilder.append('\n');
				line = bufferedReader.readLine();
			}
			LOGGER.trace("Response body: {}", inputStringBuilder);
		}
		LOGGER.trace("=======================response end=================================================");
	}
	

}