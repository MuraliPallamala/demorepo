package com.ibm.au.bgx.keycloak;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.exception.IdentityProviderException;
import com.ibm.au.bgx.model.identityprovider.LogoutClient;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;

/**
 * Class <b>LogoutClientImpl</b>. Default implementation of {@link LogoutClient} that uses Keycloak 
 * as the identity provider. Logout is not part of the OIDC specification. Therefore, each identity 
 * provider will have its own way of logging out.
 * 
 * @author Bruno Marques <brunomar@au1.ibm.com>
 *
 */
@Component
public class LogoutClientImpl extends AbstractClient implements LogoutClient {

    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(LogoutClientImpl.class);

    /**
     * {@inheritDoc}
     */
    @Override   
    public void logout(String clientId, String clientSecret, String refreshTokenString, String realmName) throws IdentityProviderException {
    	
    	
    	LOGGER.debug(BgxLogMarkers.AUTH, "Logging out JWT token associated with refresh token (realm: {}, clientId: {}, token: {}).", realmName, clientId, refreshTokenString);
    	

        // POST ->
        // https://bg-keycloak.sl.cloud9.ibm.com:8443/auth/realms/newco-admin/protocol/openid-connect/logout
        String url = String.format("%s/auth/realms/%s/protocol/openid-connect/logout", this.getBasePrivateUrl(), realmName);

        // HEADER -> Content-Type: application/x-www-form-urlencoded
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        // BODY
        // -> client_id
        // -> client_secret
        // -> refresh_token
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add(BgxConstants.OAUTH_CLIENT_ID, clientId);
        if (clientSecret != null) {
            map.add(BgxConstants.OAUTH_CLIENT_SECRET, clientSecret);
        }
        map.add(BgxConstants.OAUTH_REFRESH_TOKEN, refreshTokenString);

        try {
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);

            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = getRestTemplate().exchange(url, HttpMethod.POST, request, Map.class);

            LOGGER.debug(BgxLogMarkers.AUTH,"Logout response status: {}.",  response.getStatusCodeValue());
            
            
        } catch (Exception e) {
        	
            LOGGER.warn(BgxLogMarkers.AUTH, String.format("An error occurred during logout (realm: %s, clientId: %s, token: %s).", realmName, clientId, refreshTokenString), e);
        }

    }

}
