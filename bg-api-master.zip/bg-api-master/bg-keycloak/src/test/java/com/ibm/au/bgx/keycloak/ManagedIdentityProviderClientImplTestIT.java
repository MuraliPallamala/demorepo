package com.ibm.au.bgx.keycloak;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.model.exception.IdentityProviderException;
import com.ibm.au.bgx.model.identityprovider.LogoutClient;
import com.ibm.au.bgx.model.identityprovider.ManagedIdentityProviderClient;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;
import com.ibm.au.bgx.model.pojo.OpenIdConfig.Provider;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

/**
 * Integration tests for the ManagedIdentityProviderClient keycloak implementation
 *
 * @author Bruno Marques <brunomar@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ManagedIdentityProviderClientImpl.class, LogoutClientImpl.class, SSLUtils.class})
@EnableEncryptableProperties
@PropertySource("classpath:application-test.properties")
public class ManagedIdentityProviderClientImplTestIT {

    @Autowired
    ManagedIdentityProviderClient managedIdentityProviderClient;

    @Autowired
    LogoutClient logoutClient;

    private String realmName;
    private String displayName;
    private String userClientId;
    private String apiClientId;
    private List<String> redirectUrls;
    private String username;
    private String firstName;
    private String lastName;

    private String password;

    @Before
    public void setUp() {
        this.realmName = "IntegrationTests-" + RandomStringUtils.random(5, true, false) + new Date().getTime();
        this.displayName = RandomStringUtils.random(10, true, false);
        this.redirectUrls = new ArrayList<String>();
        this.redirectUrls.add("https://bank-guarantee.res.ibm.com:444/*");
        this.redirectUrls.add("https://bank-test.res.ibm.com:444/*");
        this.userClientId = "bg-user-test";
        this.apiClientId = "bg-api-test";
        this.username = "test@au1.ibm.com";
        this.firstName = "John";
        this.lastName = "Smith";
        this.password = "passWord1!";
    }

    @Test
    public void createRealm() throws Exception {
        // given a realmName, displayName

        // when
        Map<String, Object> realm =
                        managedIdentityProviderClient.createRealm(realmName, displayName);

        // then
        assertNotNull(realm);
        assertThat(realm.get("realmName")).isEqualTo(realmName);
        assertNotNull(realm.get("publicKey"));
    }

    @Test
    public void getRealm() throws Exception {
        // given an existing realm
        Map<String, Object> existingRealm =
                        managedIdentityProviderClient.createRealm(realmName, displayName);


        // when
        Map<String, Object> realm = managedIdentityProviderClient.getRealm(realmName);

        // then
        assertNotNull(realm);
        assertThat(realm.get("realmName")).isEqualTo(realmName);
        assertThat(existingRealm.get("realmName")).isEqualTo(realm.get("realmName"));
        assertNotNull(realm.get("publicKey"));
        assertThat(existingRealm.get("publicKey")).isEqualTo(realm.get("publicKey"));
    }


    @Test(expected = IdentityProviderException.class)
    public void duplicatedRealm() throws Exception {
        // given
        this.createRealm();

        // when
        managedIdentityProviderClient.createRealm(this.realmName, this.displayName);

        // then
        // An exception should be thrown
    }

    @Test
    public void createUser() throws Exception {
        // given
        this.createRealm();

        // when
        Map<String, Object> user = managedIdentityProviderClient.createUser(realmName, username, firstName, lastName);

        // then
        assertNotNull(user);
        assertNotNull(user.get("id"));
        assertThat(user.get("id").toString()).isNotEmpty();

    }

    @Test
    public void updateUser() throws Exception {
    	
        // given
        this.createRealm();
        Map<String, Object> user = managedIdentityProviderClient.createUser(realmName, username, firstName, lastName);

        // then
        assertNotNull(user);
        assertNotNull(user.get("id"));
        assertThat(user.get("id").toString()).isNotEmpty();

        // when update occurs
        String firstName2 = firstName + UUID.randomUUID().toString();
        String lastName2 = lastName + UUID.randomUUID().toString();
        user = managedIdentityProviderClient.updateUser(realmName, username,
            firstName2, lastName2);

        // then
        assertNotNull(user);
        assertNotNull(user.get("id"));
        assertThat(user.get("id").toString()).isNotEmpty();
        assertThat(user.get("firstName").toString()).isNotEmpty();
        assertThat(user.get("firstName").toString()).isEqualTo(firstName2);
        assertThat(user.get("lastName").toString()).isNotEmpty();
        assertThat(user.get("lastName").toString()).isEqualTo(lastName2);

    }

//    @Test
    public void userOtpSetup() throws Exception {
        // given
        this.createRealm();
        Map<String, Object> user = managedIdentityProviderClient.createUser(realmName, username,
            firstName, lastName);

        // http://localhost:8080/auth/realms/vXqhF1536209840849/otp/users/f9cf528a-9c9d-4b97-be66-dcfb0e3ba7d8
        // then
        assertNotNull(user);
        assertNotNull(user.get("id"));
        assertThat(user.get("id").toString()).isNotEmpty();

        // when get OTP setup occurs
        Map<String, Object> otpInfo = managedIdentityProviderClient.generateOtpSetup(realmName, username);

        // then
        assertNotNull(otpInfo);
        assertNotNull(otpInfo.get("totpSecret"));
        assertNotNull(otpInfo.get("totpSecretEncoded"));
        assertNotNull(otpInfo.get("totpSecretQrCode"));
        assertNotNull(otpInfo.get("totpSecretQrCode"));

        // Set OTP seed should throw error because of wrong token
        // since we cannot generate the token we are just testing for the error
        try {
            managedIdentityProviderClient
                .setOtp(realmName, username, (String) otpInfo.get("totpSecretEncoded"), "123456");
        } catch (IdentityProviderException e) {
            // expected exception
        }

        // Delete OTP seed should throw no error
        managedIdentityProviderClient.deleteOtp(realmName, username);
    }


    @Test(expected = IdentityProviderException.class)
    public void duplicatedUser() throws Exception {
        // given there is a realm, realName, userClientId and redirectUrls
        this.createUser();

        // when
        managedIdentityProviderClient.createUser(realmName, username, firstName, lastName);

        // then
        // An exception should be thrown
    }

    @Test
    public void createUserClient() throws Exception {
        // given there is a realm, realName, userClientId and redirectUrls
        this.createUser();
        managedIdentityProviderClient.setPassword(realmName, username, password);

        // when
        OpenIdConfig clientConfig = managedIdentityProviderClient.createUserClient(realmName,
                        userClientId, redirectUrls);

        // then
        String baseUrl = ((ManagedIdentityProviderClientImpl) managedIdentityProviderClient).getBasePublicUrl();
        String realmUri = String.format("%s/auth/realms/%s", baseUrl, realmName);
        String issuer = realmUri;
        String authorizationUri = String.format("%s/protocol/openid-connect/auth", realmUri);
        String accessTokenUri = String.format("%s/protocol/openid-connect/token", realmUri);

        assertNotNull(clientConfig);
        assertThat(clientConfig.getClientId()).isEqualTo(userClientId);
        assertThat(clientConfig.getClientSecret()).isNotEmpty();
        assertThat(clientConfig.getGrantType()).isEqualTo("password");
        assertThat(clientConfig.getAccessTokenUri()).isEqualTo(accessTokenUri);
        assertThat(clientConfig.getIssuer()).isEqualTo(issuer);
        assertThat(clientConfig.getIssuerPublicKey()).isNotEmpty();
        assertThat(clientConfig.getProvider()).isEqualTo(Provider.KEYCLOAK);
        assertThat(clientConfig.getRedirectUri()).isNull();
        assertThat(clientConfig.getScopes()).contains("openid");
        assertThat(clientConfig.getUserAuthorizationUri()).isEqualTo(authorizationUri);

        // User clients should only have client_credentials grant type enabled.
        assertThat(getAccessTokenAccordingToGrantType(clientConfig.getClientId(),
                        clientConfig.getClientSecret(), "password", username, password, null)
                                        .get("access_token")).isNotEmpty();

        // Api clients should only have client_credentials grant type enabled.
        boolean thrown = false;
        try {
            getAccessTokenAccordingToGrantType(clientConfig.getClientId(),
                            clientConfig.getClientSecret(), "client_credentials", null, null, null);
        } catch (Throwable e) {
            thrown = true;
        }
        assertThat(thrown).isTrue();
    }

    @Test
    public void createApiClient() throws Exception {
        // given there is a realm, and a user
        this.createUser();
        managedIdentityProviderClient.setPassword(realmName, username, password);

        // when
        OpenIdConfig clientConfig =
                        managedIdentityProviderClient.createApiClient(realmName, apiClientId);


        // then
        String baseUrl = ((ManagedIdentityProviderClientImpl) managedIdentityProviderClient).getBasePublicUrl();
        String realmUri = String.format("%s/auth/realms/%s", baseUrl, realmName);
        String issuer = realmUri;
        String authorizationUri = String.format("%s/protocol/openid-connect/auth", realmUri);
        String accessTokenUri = String.format("%s/protocol/openid-connect/token", realmUri);

        assertNotNull(clientConfig);
        assertThat(clientConfig.getClientId()).isEqualTo(apiClientId);
        assertThat(clientConfig.getClientSecret()).isNotEmpty();
        assertThat(clientConfig.getGrantType()).isEqualTo("client_credentials");
        assertThat(clientConfig.getAccessTokenUri()).isEqualTo(accessTokenUri);
        assertThat(clientConfig.getIssuer()).isEqualTo(issuer);
        assertThat(clientConfig.getIssuerPublicKey()).isNotEmpty();
        assertThat(clientConfig.getProvider()).isEqualTo(Provider.KEYCLOAK);
        assertThat(clientConfig.getRedirectUri()).isNull();
        assertThat(clientConfig.getScopes()).contains("openid");
        assertThat(clientConfig.getUserAuthorizationUri()).isEqualTo(authorizationUri);

        // Api clients should only have client_credentials grant type enabled.
        assertThat(getAccessTokenAccordingToGrantType(clientConfig.getClientId(),
                        clientConfig.getClientSecret(), "client_credentials", null, null, null)
                                        .get("access_token")).isNotEmpty();

        // Api clients should only have client_credentials grant type enabled.
        boolean thrown = false;
        try {
            getAccessTokenAccordingToGrantType(clientConfig.getClientId(), clientConfig.getClientSecret(), "password", username, password, null);
        } catch (Throwable e) {
            thrown = true;
        }
        assertThat(thrown).isTrue();
    }

    @Test
    public void getClient() throws Exception {
        // given an existing client
        this.createUserClient();

        // when
        OpenIdConfig clientConfig =
                        managedIdentityProviderClient.getClient(realmName, userClientId);

        // then
        String baseUrl = ((ManagedIdentityProviderClientImpl) managedIdentityProviderClient) .getBasePublicUrl();
        String realmUri = String.format("%s/auth/realms/%s", baseUrl, realmName);
        String issuer = realmUri;
        String authorizationUri = String.format("%s/protocol/openid-connect/auth", realmUri);
        String accessTokenUri = String.format("%s/protocol/openid-connect/token", realmUri);

        assertNotNull(clientConfig);
        assertThat(clientConfig.getClientId()).isEqualTo(userClientId);
        assertThat(clientConfig.getClientSecret()).isNotEmpty();
        assertThat(clientConfig.getGrantType()).isEqualTo("password");
        assertThat(clientConfig.getAccessTokenUri()).isEqualTo(accessTokenUri);
        assertThat(clientConfig.getIssuer()).isEqualTo(issuer);
        assertThat(clientConfig.getIssuerPublicKey()).isNotEmpty();
        assertThat(clientConfig.getProvider()).isEqualTo(Provider.KEYCLOAK);
        assertThat(clientConfig.getRedirectUri()).isNull();
        assertThat(clientConfig.getScopes()).contains("openid");
        assertThat(clientConfig.getUserAuthorizationUri()).isEqualTo(authorizationUri);

        // User clients should only have client_credentials grant type enabled.
        assertThat(getAccessTokenAccordingToGrantType(clientConfig.getClientId(),
                        clientConfig.getClientSecret(), "password", username, password, null)
                                        .get("access_token")).isNotEmpty();
    }

    @Test
    public void removeRealm() throws Exception {
        // given an existing realm
        this.createRealm();

        // when
        managedIdentityProviderClient.removeRealm(realmName);

        // then
        assertThat(managedIdentityProviderClient.getRealm(realmName)).isNull();
    }

    @Test
    public void removeClient() throws Exception {
        // given an existing realm
        this.createUserClient();

        // when
        managedIdentityProviderClient.removeClient(realmName, userClientId);

        // then
        assertThat(managedIdentityProviderClient.getClient(realmName, userClientId)).isNull();
    }

    @Test
    public void removeUser() throws Exception {
        // given an existing realm
        managedIdentityProviderClient.createRealm(realmName, displayName);
        OpenIdConfig clientConfig = managedIdentityProviderClient.createUserClient(realmName, userClientId, redirectUrls);
        managedIdentityProviderClient.createUser(realmName, username, firstName, lastName);
        managedIdentityProviderClient.setPassword(realmName, username, password);
        assertThat(getAccessTokenAccordingToGrantType(clientConfig.getClientId(),
                        clientConfig.getClientSecret(), "password", username, password, null)
                                        .get("access_token")).isNotEmpty();

        // when
        managedIdentityProviderClient.removeUser(realmName, username);

        // then
        boolean thrown = false;
        try {
            getAccessTokenAccordingToGrantType(clientConfig.getClientId(),
                            clientConfig.getClientSecret(), "password", username, password, null);
        } catch (Throwable e) {
            thrown = true;
        }
        assertThat(thrown).isTrue();

        assertThat(managedIdentityProviderClient.userExists(realmName, username)).isFalse();
    }

    @Test
    public void logout() throws Exception {
        // given
        managedIdentityProviderClient.createRealm(realmName, displayName);
        OpenIdConfig clientConfig = managedIdentityProviderClient.createUserClient(realmName,
                        userClientId, redirectUrls);
        managedIdentityProviderClient.createUser(realmName, username, firstName, lastName);
        managedIdentityProviderClient.setPassword(realmName, username, password);

        Map<String, String> token = getAccessTokenAccordingToGrantType(clientConfig.getClientId(),
                        clientConfig.getClientSecret(), "password", username, password, null);
        
        Map<String, String> newTokenFromRefreshToken = getAccessTokenAccordingToGrantType(
                        clientConfig.getClientId(), clientConfig.getClientSecret(), "refresh_token",
                        null, null, token.get("refresh_token"));
        assertThat(newTokenFromRefreshToken.get("access_token")).isNotEmpty();

        Map<String, String> newTokenFromRefreshToken2 = getAccessTokenAccordingToGrantType(
                        clientConfig.getClientId(), clientConfig.getClientSecret(), "refresh_token",
                        null, null, token.get("refresh_token"));
        assertThat(newTokenFromRefreshToken2.get("access_token")).isNotEmpty();

        // when
        logoutClient.logout(clientConfig.getClientId(), clientConfig.getClientSecret(),
                        token.get("refresh_token"), realmName);

        // then
        boolean thrown = false;
        try {
            getAccessTokenAccordingToGrantType(clientConfig.getClientId(),
                            clientConfig.getClientSecret(), "refresh_token", null, null,
                            token.get("refresh_token"));
        } catch (RuntimeException e) {
            thrown = true;
            assertThat(e.getMessage()).contains("Could not retrieve token");
        }
        assertThat(thrown).isTrue();

    }

    /**
     * Helper method to get an access token according to a specific grant type.
     * 
     * @param clientId
     * @param clientSecret
     * @param grantType
     * @param username
     * @param password
     * @return
     */
    @SuppressWarnings("unchecked")
	private Map<String, String> getAccessTokenAccordingToGrantType(String clientId, String clientSecret, String grantType, String username, String password, String refreshToken) {
        ManagedIdentityProviderClientImpl clientImpl =
                        (ManagedIdentityProviderClientImpl) managedIdentityProviderClient;

        String url = String.format("%s/auth/realms/%s/protocol/openid-connect/token", clientImpl.getBasePrivateUrl(), realmName);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);


        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("grant_type", grantType);

        switch (grantType) {
            case "client_credentials":
                String authorizationSourceString = String.format("%s:%s", clientId, clientSecret);
                String authorizationToken = Base64.getEncoder()
                                .encodeToString(authorizationSourceString.getBytes());

                headers.add("Authorization", "basic " + authorizationToken);
                break;
            case "password":
                map.add("username", username);
                map.add("password", password);
                map.add("client_id", clientId);
                map.add("client_secret", clientSecret);
                break;
            case "refresh_token":
                map.add("client_id", clientId);
                map.add("client_secret", clientSecret);
                map.add("refresh_token", refreshToken);
                break;
            default:
                break;
        }


        try {
            RestTemplate restTemplate = new RestTemplate();
            HttpEntity<MultiValueMap<String, String>> request =
                            new HttpEntity<MultiValueMap<String, String>>(map, headers);

            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response =
                            restTemplate.exchange(url, HttpMethod.POST, request, Map.class);
            return response.getBody();
        } catch (HttpClientErrorException httpEx) {
            throw new RuntimeException("Could not retrieve token");
        }
    }


    @After
    public void tearDown() throws Exception {
        try {
            managedIdentityProviderClient.removeRealm(this.realmName);
        } catch (IdentityProviderException e) {
            Throwable cause = e.getCause();
            if (cause instanceof HttpClientErrorException) {

                HttpClientErrorException error = (HttpClientErrorException) cause;
                if (!HttpStatus.NOT_FOUND.equals(error.getStatusCode())) {
                    throw e;
                }
            }
        }
    }
}

