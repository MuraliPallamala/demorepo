# bg-api
API Repository for Bank Guarantees used by the banks, landlords and tenants to communicate with the blockchain.

For instruction on how to compile and run the api as well as the portal in the development environment, go to https://github.ibm.com/bank-guarantees/dev/blob/master/README.md

For debugging in development mode, you can debug each api component (bg-newco-admin-api, bg-newco-api, bg-issuer-api, bg-service-api) by using Java Debug Wire Protocol (JDWP) and attaching your IDE to the following debug ports:

|    Vertical   |      Component     | HTTP Port | JDWP Port |
|:-------------:|:------------------:|:---------:|:---------:|
| Admin         | bg-newco-admin-api | 9082      | 8000      |
|               | bg-service-api     | 9083      | 8010      |
| User          | bg-newco-api       | 9080      | 8001      |
|               | bg-service-api     | 9081      | 8011      |
| ANZ           | bg-issuer-api      | 9090      | 8002      |
|               | bg-service-api     | 9091      | 8012      |
| Commbank      | bg-issuer-api      | 9092      | 8003      |
|               | bg-service-api     | 9093      | 8013      |
| Westpac       | bg-issuer-api      | 9094      | 8004      |
|               | bg-service-api     | 9095      | 8014      |
| TestIssuer    | bg-issuer-api      | 9096      | 8005      |
|               | bg-service-api     | 9097      | 8015      |
