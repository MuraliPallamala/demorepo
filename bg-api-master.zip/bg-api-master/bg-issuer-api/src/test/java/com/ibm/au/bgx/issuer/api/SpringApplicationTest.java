package com.ibm.au.bgx.issuer.api;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Parent test class for all Spring tests that will require different beans during test than they do
 * at runtime. Extending this test class will apply the transient repository beans to repository
 * interfaces.
 */
@RunWith(SpringRunner.class)
@TestPropertySource(locations = "classpath:application-test.properties")
public class SpringApplicationTest {

    @Test
    public void contextLoads() {
    }

}
