package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedAsicProxyResource;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>AsicProxyResource</b>. Extends {@link SharedAsicProxyResource} and exposes
 * the endpoints defined in the above class for the issuer vertical. This class does not
 * define any further capability, it simply makes available the operations of the base
 * class as a REST controller in the API packaged with this web application.
 * 
 * @see SharedAsicProxyResource
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RestController
public class AsicProxyResource extends SharedAsicProxyResource {

}
