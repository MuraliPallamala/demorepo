package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedUserResource;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>UserResource</b>. This class inherits {@link SharedUserResource} and exposes the
 * exposes the end-points for user management defined in the base class for the issuer (single-tenant) 
 * vertical. It does not add any further operation, it simply includes all the capabilities defined
 * in the base class as a REST controller in the current web application package.
 * 
 * @see SharedUserResource
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RestController
public class UserResource extends SharedUserResource { }
