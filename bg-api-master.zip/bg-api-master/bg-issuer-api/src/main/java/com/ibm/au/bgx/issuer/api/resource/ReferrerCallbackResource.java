package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedReferrerCallbackResource;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>ReferrerCallbackResource</b>. This class inherits {@link SharedReferrerCallbackResource} 
 * and exposes the callback notification endpoints defined in the base class for the issuer (single-tenant) 
 * vertical. It does not add any further operation, it simply includes all the capabilities defined
 * in the base class as a REST controller in the current web application package.
 * 
 * @see SharedReferrerCallbackResource
 * 
 * @author Peter Ilfrich <peter.ilfrich@au1.ibm.com>
 */
@RestController
public class ReferrerCallbackResource extends SharedReferrerCallbackResource {

    // inherits from shared class
}
