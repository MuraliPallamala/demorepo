package com.ibm.au.bgx.issuer.api;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;

import com.ibm.au.bgx.api.shared.AbstractOpenAPIConfig;

/**
 * Class <b>OpenAPIConfig</b>. Extends {@link AbstractOpenAPIConfig} to expose
 * the configuration capabilities defined in the base class in the web application
 * that is defined in this project. The class does not define any further business
 * logic, it simply exposes the base class by adding the {@link Configuration}
 * annotation to the type and the specification of the {@link ConditionaProperty} 
 * that controls the generation of the documentation via the application property
 * <i>apidoc.generation</i>. If set to {@literal true}, the generation of the 
 * OpenAPI specification will be enabled.
 * 
 * @see AbstractOpenAPIConfig
 */
@Configuration
@ConditionalOnProperty(name = "apidoc.generation")
public class OpenAPIConfig extends AbstractOpenAPIConfig {
}
