package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedNetworkResource;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>NetworkResource</b>. Extends {@link SharedNetworkResource} and exposes the endpoints 
 * for API-to-API synchronisation in the issuer (single-tenant) vertical. This class does not define 
 * any further operation, it simply makes available the operations of the base class as a REST
 * controller in the API packaged with this web application.
 * 
 * @see SharedGxResource
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RestController
public class NetworkResource extends SharedNetworkResource {

}
