package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedReferrerResource;

import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>ProfileResource</b>. This class extends {@link SharedReferrerResource}
 * and exposes the endpoints for assisted on-boarding management in the issuer
 * (single-tenant) vertical. It does not define any further operation, it simply
 * makes availables the capabilities defined in the base class as a REST controller
 * in this web application.
 * 
 * @see SharedReferrerResource
 */
@RestController
@Tag(name="Organisation Onboarding", description="Capabilities for onboarding an organisation.")
public class ProfileResource extends SharedReferrerResource {

}
