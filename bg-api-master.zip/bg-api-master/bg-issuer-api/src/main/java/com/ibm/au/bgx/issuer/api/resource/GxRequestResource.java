package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedGxRequestResource;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>GxRequestResource</b>. Extends {@link SharedGxRequestResource} and exposes the 
 * endpoints for guarantees request management in the issuer (single-tenant) vertical. This 
 * class does not define any further operation, it simply makes available the operations of 
 * the base class as a REST controller in the API packaged with this web application.
 * 
 * @see SharedGxRequestResource
 * 
 */
@RestController
public class GxRequestResource extends SharedGxRequestResource {
}
