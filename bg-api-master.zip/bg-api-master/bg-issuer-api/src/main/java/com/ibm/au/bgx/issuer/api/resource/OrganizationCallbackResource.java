package com.ibm.au.bgx.issuer.api.resource;

import org.springframework.web.bind.annotation.RestController;

import com.ibm.au.bgx.api.shared.resource.SharedOrganizationCallbackResource;

/**
 * Class <b>OrganizationCallbackResource</b>. This class inherits {@link SharedOrganizationCallbackResource} 
 * and exposes the callback notification endpoints defined in the base class for the issuer (single-tenant) 
 * vertical. It does not add any further operation, it simply includes all the capabilities defined in the
 * base class as a REST controller in the current web application package.
 * 
 * @see SharedOrganizationCallbackResource
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
@RestController
public class OrganizationCallbackResource extends SharedOrganizationCallbackResource {

}