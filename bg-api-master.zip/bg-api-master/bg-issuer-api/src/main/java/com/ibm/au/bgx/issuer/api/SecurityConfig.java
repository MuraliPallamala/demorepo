package com.ibm.au.bgx.issuer.api;

import com.ibm.au.bgx.api.shared.AbstractSecurityConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

/**
 * Class <b>SecurityConfig</b>. This class extends {@link AbstractSecurityConfig} and specialises the
 * base security profile for the issuer (single tenant) vertical. It simply annotates the class with
 * the required annotation to be interpreted as a security configuration.
 * 
 * @author Bruno Marques <brunomar@au1.ibm.com>
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends AbstractSecurityConfig {

}
