package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedTermsAndCondResource;

import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>TermsAndCondResource</b>. This class inherits {@link SharedTermsAndCondResource} and
 * exposes the terms and conditions query end-points of the base class for the issuer (single-tenant) 
 * vertical. This class does not add any further operation, it simply includes all the capabilities 
 * defined in the base class as a REST controller in the current web application package.
 * 
 * @see SharedTermsAndCondResource
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RestController
@Tag(name="Terms and Conditions", description="Capabilities for accessing the terms and conditions documents of the platform.")
public class TermsAndCondResource extends SharedTermsAndCondResource {

}
