package com.ibm.au.bgx.issuer.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

/**
 * Class <b>Application</b>. This is the main driver of the web application that
 * host the API for the admin (single-tenant) vertical. It extends the base class
 * {@link SpringBootServletInitializer} to specify the package root for scanning
 * the resources and Spring components to expose in the API. Everything (component, 
 * configuration, and rest controller) under the package <i>com.ibm.au.bgx</i> will 
 * be loaded.
 */
@SpringBootApplication(scanBasePackages = "com.ibm.au.bgx")
@EnableEncryptableProperties
public class Application extends SpringBootServletInitializer {

	/**
	 * Main entry point of the application. This is the method that is invoked to
	 * start the API.
	 * 
	 * @param args	a {@link String} array containing the application arguments. At
	 * 				present time there are no specific application arguments used.
	 */
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}


	/**
	 * Adds to the given {@link SpringApplicationBuilder} instance the type definition
	 * of the current instance to build the Spring application.
	 * 
	 * @return  the {@link SpringApplicationBuilder} passed as argument configured with
	 * 			the type definition of this instance.
	 */
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(Application.class);
	}
}