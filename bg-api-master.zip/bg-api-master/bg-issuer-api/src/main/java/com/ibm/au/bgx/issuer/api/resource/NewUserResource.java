package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedNewUserResource;
import org.springframework.web.bind.annotation.RestController;


/**
 * Class <b>NewUserResource</b>. This class extends {@link SharedNewUserResource} and specialises the 
 * services of the above class for the API that are associated to a specific issuer. This implementation 
 * does not add additional functionality simply exposes the endpoints defined in the base class as a REST 
 * controller within this web application package.
 * 
 * @see SharedNewUserResource
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
@RestController
public class NewUserResource extends SharedNewUserResource { }
