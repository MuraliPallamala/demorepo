package com.ibm.au.bgx.issuer.api;

import com.ibm.au.bgx.core.BasicStartupComponent;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Class <b>StartupComponent</b>. This class extends {@link BasicStartupComponent} and defies
 * the initialisation sequence for the API vertical it is defined in. This implementation does
 * not define any additional logic besides the initialisation procedure which essentially relies
 * on operations defined in the base class.
 * 
 * @see  BasicStartupComponent
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class StartupComponent extends BasicStartupComponent {

	/**
	 * An {@link Logger} implementation that is used to collect all the log messages
	 * produced by the instances of this class.
	 */
    private static final Logger LOGGER = LoggerFactory.getLogger(StartupComponent.class);

    /**
     * This method initialisalises the API by performing the following operations:
     * <ul>
     * <li>registering all the application components required by the APIs</li>
     * <li>registering the default Blockchain identity under which the API operate</li>
     * <li>checking the bank guarantee channnels and the connectivity to them</li>
     * <li>checking the connectity to the queues</li>
     * <li>registering the vertical with the administrative vertical of the platform</li>
     * <li>initialising the purpose formats</li>
     * <li>assessing whether any data migration is required prior to make the API available</li>
     * </ul>
     * The method is annotated with the {@link PostConstruct} annotation and it is executed
     * automatically by the Spring runtime after the creation and configuration of the instance
     * with the declared application component.
     * 
     * @throws Exception	if there is any error in the startup process an {@link Exception}
     * 						is thrown.
     */
    @PostConstruct
    public void execute() throws Exception {
    	

        this.registerComponent();
        
        this.registerDefaultChannelUser();
        
        this.checkGuaranteeChannels();
        this.checkQueues();
        this.bootstrap();
        
        this.purposeFormatManager.init();

        // this runs last after all data and connections have been initialised
        this.checkAndRunMigration();

        LOGGER.debug(BgxLogMarkers.DEV, " > " + String.format("API '%s' is ready!!", this.bgxIdentity));
        this.setReady();
    }

}
