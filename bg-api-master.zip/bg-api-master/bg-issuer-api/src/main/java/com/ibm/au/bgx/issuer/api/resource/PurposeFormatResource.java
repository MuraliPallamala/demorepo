package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedPurposeFormatResource;

import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>PurposeFormatResource</b>. This class inherits {@link SharedPurposeFormatResource} and
 * exposes the query end-points for purpose formats of the base class for the issuer (single-tenant) 
 * vertical. It does not add any further operation, it simply includes all the capabilities defined
 * in the base class as a REST controller in the current web application package.
 * 
 * @see SharedPurposeFormatResource
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RestController
@Tag(name="Purpose Format Management", description="Capabilities for retrieving purpose formats available in the platform.")
public class PurposeFormatResource extends SharedPurposeFormatResource {
}
