package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedUserTaskResource;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>UserTaskResource</b>. This class inherits {@link SharedUserTaskResource} and
 * exposes the notification management endpoints of the base class for the API of the
 * issuer vertical. This class does not add any further capability simply includes all the 
 * capabilities defined in the base class as a REST controller in the current web application 
 * package.
 * 
 * @see SharedUserTaskResource
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RestController
public class UserTaskResource extends SharedUserTaskResource {

}
