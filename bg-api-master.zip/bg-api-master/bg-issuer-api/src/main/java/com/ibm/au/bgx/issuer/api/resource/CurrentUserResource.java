package com.ibm.au.bgx.issuer.api.resource;

import com.ibm.au.bgx.api.shared.resource.SharedCurrentUserResource;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class <b>CurrentUserResource</b>. Extends {@link SharedCurrentUserResource} and exposes
 * the endpoints for accessing and managing the profile of the current user for the issuer 
 * (single-tenant) vertical. This class does not define any further operation, it simply makes
 * available the operations of the base class as a REST controller in the API packaged with 
 * this web application.
 * 
 * @see SharedCurrentUserResource
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RestController
public class CurrentUserResource extends SharedCurrentUserResource {

}
