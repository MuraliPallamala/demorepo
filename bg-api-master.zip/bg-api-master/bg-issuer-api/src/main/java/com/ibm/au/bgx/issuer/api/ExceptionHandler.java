package com.ibm.au.bgx.issuer.api;

import org.springframework.web.bind.annotation.RestController;

import com.ibm.au.bgx.api.shared.DefaultApiExceptionHandler;

/**
 * Class <b>ExceptionHandler</b>. This class extends {@link DefaultApiExceptionHandler}
 * and exposes the exception handling and mapping capabilities defined in the base class
 * in the web application defined by this package. This method does not define any further
 * exception handling logic, it simply annotates the class as REST Controller to make it
 * detectable by package scanning.
 * 
 * @see DefaultApiExceptionHandler
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RestController
public class ExceptionHandler extends DefaultApiExceptionHandler {
}
