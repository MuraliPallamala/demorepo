# bg-issuer-api
REST API implementation of Issuer API.

## Pre-requisites in order to be able to compile the source code

```
$ cd $<GO_PATH>
$ git clone git@github.ibm.com:aur-blockchain/weave-client-java.git
$ cd weave-client-java
$ ./install.sh
$ go install

$ cd $<GO_PATH>
$ git clone git@github.ibm.com:aur-blockchain/weave-cc-go.git
$ cd weave-cc-go
$ ./install.sh
$ go install

$ cd $<GO_PATH>
$ go get golang.org/x/tools/cmd/goimports

$ cd $<GO_PATH>
$ git clone git@github.ibm.com:bank-guarantees/bg-chaincode-model.git
$ make build

$ cd $<GO_PATH>
$ git clone git@github.ibm.com:bank-guarantees/bg-chaincode.git
$ make generate-models

$ git clone git@github.ibm.com:bank-guarantees/bg-api.git
$ cd bg-api
$ mvn clean install
```

## Launching the application in development mode

In order to launch the application in development mode

First make sure you have an instance of couchDB

```
docker run -e COUCHDB_USER=admin -e COUCHDB_PASSWORD=password -d -p 5984:5984 couchdb
```

Then simply run the following command:

```
mvn clean spring-boot:run
```

This command will use the ```dev``` maven profile and build the application as a jar file with an embedded Jetty web container and run it using the development maven profile as well as load the development application.properties file that is in the resources folder and should only be used in development mode.

## Launching the application in test and production mode inside a dockerized environment

For test and production environment, there is a maven profile named ```dockerized```.
That profile packages and runs the application for these environments in a way that keeps the application configuration independent from the the compiled package files. If you want to run the generated war file outside a dockerized environment, you will need to install an external web container or application container like Liberty, and follow the steps below.

In order to trigger that profile and generate a war file with all the dependencies the following command can be used:

```
mvn clean package -Dspring.profiles.active=dockerized
```

This project has a Dockerfile that creates a docker image based on WLP, and allows the deployer agent to specify, via a docker volume, a configuration directory (```/config```) containing all the web application configuration including spring properties files.
If no volume is specified when the docker container is run, the contents of the configuration directory will point to the contents of the ```docker``` folder in this repository (```bg-api/docker```).

In order to create the docker image, run:

```
make clean build
```

In order to start the web application using your own spring configuration, run something similar to the following:

```
docker run -d -p 80:9080 -p 443:9443 -v /Users/user/go/src/github.ibm.com/bank-guarantees/env:/config/spring --name bg-rest bgx/bg-rest
```


