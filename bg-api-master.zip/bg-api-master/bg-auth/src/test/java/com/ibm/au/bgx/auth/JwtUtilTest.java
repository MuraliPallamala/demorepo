package com.ibm.au.bgx.auth;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public class JwtUtilTest {

    @Test
    public void extractOrgKeyFromIssuer() throws Exception {

        String orgKey = "ORG_KEY";
        String issuer = String.format("https://bg-keycloak.sl.cloud9.ibm.com:8443/auth/realms/%s", orgKey);
        assertEquals(orgKey, JwtUtil.extractOrgKeyFromIssuer(issuer));
    }

}