package com.ibm.au.bgx.auth;

import com.ibm.au.bgx.common.util.ErrorCodeUtil;
import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.api.exceptions.ApiException;
import com.ibm.au.bgx.model.api.exceptions.ApiForbiddenException;
import com.ibm.au.bgx.model.auth.BgxUserDetailService;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.chain.profile.UserProfileManager;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.UserProfile.Status;
import java.math.BigInteger;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.NotImplementedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * @author Bruno Marques <brunomar@au1.ibm.com>
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Service
public class OpenIdUserDetailsService implements BgxUserDetailService {

    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(OpenIdUserDetailsService.class);
    
	/**
	 * 
	 */
    public static final String PARALLEL_LOGIN = "User '%s' has another login session active till '%s'. Please logout, or wait until the other login session expires.";


    @Autowired
    UserProfileManager userProfileManager;

    @Autowired
    OrganizationManager organizationManager;

    @Autowired
    BgxComponentProvider componentProvider;

    @Autowired
    ApplicationContext applicationContext;

    @Value("${bgx.api.auth.parallelLogin.enable:false}")
    protected boolean parallelLoginEnabled;


    @Override
    public UserDetails loadUserByUsername(String orgId, String username, String jwt,
        Instant jwtIssuedAt, Instant jwtExpiry)
        throws UsernameNotFoundException, ApiException {

        try {

            // Note, the api-to-api call needs to be handled separately since those JWT does not
            // correspond to any user in the database
            UserProfile userProfile = null;
            if (!username.startsWith(BgxConstants.API_AUTH_CLIENT_PREFIX)) {
                LOGGER.debug(BgxLogMarkers.AUTH, String
                    .format("Loading profile using orgId %s and username %s", orgId, username));

                if (orgId == null) {
                    throw new IllegalArgumentException("Org ID cannot be null");
                }

                userProfile = userProfileManager.getByEmail(orgId, username);
                if (userProfile == null) {
                    throw new IllegalArgumentException(
                        String.format("User '%s' is not found", username));
                }

                if (userProfile.getStatus() != Status.ACTIVE) {
                    throw new ApiForbiddenException(null,
                        String.format("User '%s' is not active", username), null);
                }

                LOGGER.debug(BgxLogMarkers.AUTH,
                    String.format("Found user profile '%s' of organization '%s'", username,
                        userProfile.getPrimaryOrgId()));

                if (!parallelLoginEnabled) {
                    userProfile = this.checkForParallelLogin(userProfile, jwt, jwtIssuedAt, jwtExpiry);
                }

                return this.prepareJwtUser(userProfile, false);
            } else {
                // mock a user profile for remote api client
                userProfile = new UserProfile();
                userProfile.setPrimaryOrgId(orgId);
                userProfile.setEmail(username); // we use username as the email for the profile
                userProfile.setFirstName(username);

                return this.prepareJwtUser(userProfile, true);
            }


        } catch (RuntimeException e) {
            throw e;
        } catch (ApiException apiEx) {
            throw apiEx;
        } catch (Exception e) {
            throw new UsernameNotFoundException(String.format("User '%s' not found", username), e);
        }
    }

    private JwtUser prepareJwtUser(UserProfile userProfile, boolean isApiClient) {

        try {
            LOGGER.debug(BgxLogMarkers.AUTH,
                String.format("Creating user details for '%s'", userProfile.getEmail()));
            SimpleGrantedAuthority authority = new SimpleGrantedAuthority("ROLE_ANOTHER");
            Collection<GrantedAuthority> authorities = new ArrayList<>();
            authorities.add(authority);

            Organization org = null;
            String channelUserName = null;
            if (userProfile.getPrimaryOrgId() != null) {
                org = organizationManager.getById(userProfile.getPrimaryOrgId());
                channelUserName = org.getId();
            }

            return new JwtUser(userProfile, 
            				   org, 
            				   authorities, 
            				   true, 
            				   false, 
            				   false, 
            				   false,
            				   componentProvider, 
            				   applicationContext, 
            				   isApiClient, 
            				   channelUserName);

        } catch (Exception e) {
            throw new UsernameNotFoundException(
                String.format("User '%s' not found", userProfile.getEmail()), e);
        }
    }

    /**
     * Load user by apiKey
     */
    @Override
    public UserDetails loadUserByApiKey(String apiKey) throws UsernameNotFoundException {

        try {
            LOGGER.debug(BgxLogMarkers.AUTH, "Loading user using API Key {}", apiKey);

            UserProfile userProfile = userProfileManager.getByApiKey(apiKey);
            if (userProfile == null) {
                throw new IllegalArgumentException(
                    String.format("User not found with API key", apiKey));
            }

            if (userProfile.getStatus() != Status.ACTIVE) {
                throw new IllegalArgumentException(
                    String.format("User '%s' is not active", userProfile.getEmail()));
            }

            LOGGER.debug(BgxLogMarkers.AUTH, String
                .format("Found user profile '%s' of organization '%s'", userProfile.getEmail(),
                    userProfile.getPrimaryOrgId()));

            return this.prepareJwtUser(userProfile, false);

        } catch (Exception e) {
            throw new UsernameNotFoundException(
                String.format("User not found with API key", apiKey), e);
        }
    }

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        throw new NotImplementedException(
            "Method not implemented. Use the other method that requires orgId and email");
    }


    /**
     * This method checks for parallel login and also performs new login if required
     * @param userProfile
     * @param jwt
     * @param jwtIssuedAt
     * @param jwtExpiry
     * @return
     * @throws ApiForbiddenException if parallel login is detected
     */
    private UserProfile checkForParallelLogin(final UserProfile userProfile, String jwt, Instant jwtIssuedAt, Instant jwtExpiry)
        throws ApiForbiddenException {

        LOGGER.debug(BgxLogMarkers.AUTH,
            "Checking for parallel login for user '{}' with JWT {} issuedAt: {}, expiry: {}",
            userProfile.getEmail(), DigestUtils.sha256Hex(jwt), jwtIssuedAt, jwtExpiry);

        // compute the values that can be reused
        boolean hasActiveSession = userProfileManager
            .hasAnotherActiveLoginSession(userProfile, jwt, jwtIssuedAt);
        boolean unusedAuthToken = userProfileManager.isUnusedAuthToken(userProfile, jwt);

        // If we have active session and the token is not among one of the allowed ones, it is a
        // parallel login attempt
        if (hasActiveSession == true && unusedAuthToken == false) {

            // duplicate session, compute error message and error code
            String errorMessage = String.format(OpenIdUserDetailsService.PARALLEL_LOGIN,
                userProfile.getEmail(),
                userProfile.getLastAuthTokenExpiry());

            BigInteger errorCode = ErrorCodeUtil
                .getPrefixedErrorCode(ErrorCodeUtil.ErrorTopic.LOGIN,
                    ErrorCodeUtil.AUTH_DUPLICATE_SESSION);

            // throw specific exception to be handled in the frontend
            throw new ApiForbiddenException(null, errorMessage, null, errorCode, null);
        }
        LOGGER.debug(BgxLogMarkers.AUTH, "No parallel login detected for for {}");

        // Update last login with this jwt only if:
        //      user is not logged in | the last token has expired  || one of the valid tokens
        if (userProfile.getLastAuthTokenHash() == null // not logged in
            || userProfile.getLastAuthTokenExpiry() == null // not logged in
            || userProfile.getLastAuthTokenExpiry().isBefore(jwtIssuedAt) // expired
            || unusedAuthToken // unused token
            ) {

            LOGGER.debug(BgxLogMarkers.AUTH, "Updating last login for {} expiresAt {}",
                userProfile.getEmail(), jwtExpiry);

            return userProfileManager
                .updateLastLogin(userProfile.getId(), jwt, jwtExpiry);
        }

        return userProfile;
    }
}
