package com.ibm.au.bgx.auth;

import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * This class provide a method for retrieving BgxPrincipal
 *
 * @author brunomar
 */
public class OpenIdUtil {

    /**
     * Retrieved the BgxPrincipal from the current security context (servlet context).
     *
     * @return a BgxPrincipal (aka JwtUser)
     * @deprecated Currently we don't need this for the the regular request handling. I suspect
     * however, that we might find use in the web-socket handler, because I'm not 100% sure the
     * endpoint handler there allows for the injection of the BgxPrincipal.
     */
    @Deprecated
    public static final BgxPrincipal getBgxPrincipal() {
        BgxPrincipal principal = (BgxPrincipal) SecurityContextHolder.getContext()
            .getAuthentication().getPrincipal();
        return principal;
    }

}
