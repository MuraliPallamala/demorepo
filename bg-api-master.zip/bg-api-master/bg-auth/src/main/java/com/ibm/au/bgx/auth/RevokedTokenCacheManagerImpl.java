package com.ibm.au.bgx.auth;

import com.ibm.au.bgx.model.api.RevokedTokenCacheManager;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Implementation of the manager for the cache of revoked tokens.
 *
 * TODO Create an implementation that relies on Redis.
 *
 * @author brunomar
 */
@Component
public class RevokedTokenCacheManagerImpl implements RevokedTokenCacheManager {

    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private final Logger LOGGER = LoggerFactory.getLogger(RevokedTokenCacheManagerImpl.class);
    /**
     * The map stores the username and a integer representing the expiration time in milliseconds.
     */
    private Map<String, Long> cache = new HashMap<String, Long>();

    @Override
    public synchronized void addToken(String authToken, Long expirationInMilliseconds) {
        this.cleanUpExpired();
        this.cache.put(this.computeAuthTokenHash(authToken), expirationInMilliseconds);
    }

    @Override
    public boolean tokenExists(String authToken) {
        this.cleanUpExpired();
        String tokenHash = this.computeAuthTokenHash(authToken);
        this.cache.forEach((key, value) -> LOGGER.debug(String.format("Token cache entry: %s:%s", key, value)));

        return this.cache.containsKey(tokenHash);
    }

    @Override
    public synchronized void removeToken(String authToken) {
        String tokenHash = this.computeAuthTokenHash(authToken);
        if (this.cache.containsKey(tokenHash)) {
            this.cache.remove(this.computeAuthTokenHash(tokenHash));
        }
    }

    @Override
    public synchronized void cleanUpExpired() {
        Long now = System.currentTimeMillis();
        this.cache.entrySet().removeIf(entry -> entry.getValue() < now);
    }

    /**
     * Compute hash of the auth token
     * @param authToken
     * @return
     */
    private String computeAuthTokenHash(String authToken) {
        return DigestUtils.sha256Hex(authToken);
    }

}
