package com.ibm.au.bgx.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.rest.ApiConstants;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.util.JacksonUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

/**
 * This utility class provide function for JWT token validation.
 *
 * @author Bruno Marques <brunomar@au1.ibm.com>
 */
@Component
public class JwtUtil {

    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(JwtUtil.class);

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    private final String WEBSOCKET_HEADER_NAME = "Sec-WebSocket-Protocol";

    @Autowired
    OrganizationManager organizationManager;

    @Value("${bootstrap.publicKey:" + BgxConstants.PROPERTY_NOT_SET + "}")
    private String bootstrapPublicKey;

    /**
     * Used to decode the JWT payload without necessarily validating its signature.
     */
    @SuppressWarnings("unchecked")
	public static Map<String,Object> decodeJwtPayload(String jwtToken) throws UnsupportedEncodingException, ParseException {
       
    	String payload = jwtToken.split("\\.")[1];
        byte[] bytes = payload.getBytes("UTF-8");
        byte[] decoded = Base64.getMimeDecoder().decode(bytes);
        String output = new String(decoded);
        JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);
        return (Map<String,Object>) parser.parse(output);
    }

    /**
     * Parse the orgkey from JWT issuer link
     * <p>
     * e.g. https://bg-keycloak.sl.cloud9.ibm.com:8443/auth/realms/<realmName> where <realmName> is
     * the organization key
     */
    public static String extractOrgKeyFromIssuer(String issuer) {

        String orgKey = null;

        int lastIndex = issuer.lastIndexOf("/");
        if ((lastIndex + 1) < issuer.length()) {
            orgKey = issuer.substring(lastIndex + 1);
        }

        if (orgKey == null) {
            throw new IllegalArgumentException(
                    String.format("Could not extract orgKey from issuer information: %s", issuer));
        }

        return orgKey;
    }

    /**
     * Retrieves the JWT token from a request. This can either be done by retrieving the
     * Authorization header or by accessing the special websocket headers and reading the token from
     * their (for wss:// requests)
     *
     * @param request - the incoming http request
     */
    @SuppressWarnings("null")
	public String getAuthToken(HttpServletRequest request) {
        String authToken = null;

        final String requestHeader = request.getHeader(BgxConstants.AUTHORIZATION_HEADER);

        boolean isWebSocketConnection = request.getHeader(WEBSOCKET_HEADER_NAME) != null;
        if ((requestHeader != null && requestHeader.startsWith(BgxConstants.BEARER_PREFIX))
                || isWebSocketConnection) {
            // retrieve the auth token either from the auth header or from the websocket header
            if (isWebSocketConnection) {
                authToken = request.getHeader(WEBSOCKET_HEADER_NAME).split(",")[1];
            } else {
                authToken = requestHeader.substring(BgxConstants.BEARER_PREFIX.length());
            }
        }

        if (authToken != null) {
            LOGGER.debug(BgxLogMarkers.AUTH, "Extracted auth token length: {}", authToken.length());
        }
        return authToken;
    }

    /**
     * Retrieves the public key to decrypt the JWT token for the specific authentication scenario.
     *
     * @param authToken   - the authentication token (required, except during bootstrap)
     * @param request     - an optional HTTP request (only required for bootstrap)
     * @param requestHash - an optional request hash (only required for API to API communication)
     * @return - the public key which can be used to decrypt the jtw token
     */
    public String getPublicKey(String authToken, HttpServletRequest request, String requestHash)
            throws IOException {
        String publicKeyString;
        if (request != null && request.getHeader(BgxConstants.HEADER_BOOTSTRAP_MARKER) != null) {
            publicKeyString = bootstrapPublicKey;
        } else if (requestHash != null) {
            LOGGER.debug("Verifying JWT for remote API call.");
            publicKeyString = this.getPublicKey(authToken, true);
        } else {
            LOGGER.debug("Verifying JWT for user requests.");
            publicKeyString = this.getPublicKey(authToken, false);
        }

        if (publicKeyString == null || publicKeyString.isEmpty()) {
            throw new IllegalArgumentException(
                    String
                            .format("Public key could not be found for auth token %s", authToken));
        }

        return publicKeyString;
    }

    public Claims extractUserClaims(String authToken, String publicKeyString) throws NoSuchAlgorithmException, InvalidKeySpecException, IOException {
        if (authToken == null) {
            return null;
        }

        if (publicKeyString == null) {
            publicKeyString = getPublicKey(authToken, false);
        }

        KeyFactory kf = KeyFactory.getInstance("RSA");
        byte[] byteKey = Base64.getDecoder().decode(publicKeyString);
        X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
        PublicKey publicKey = kf.generatePublic(X509publicKey);

        Claims claims = Jwts.parser().setSigningKey(publicKey).parseClaimsJws(authToken)
                .getBody();

        LOGGER.debug(BgxLogMarkers.AUTH, "Claims: " + claims.toString());
        return claims;
    }


    /**
     * Retrieves the user claims of an incoming HTTP request. This will first attempt to retrieve
     * the auth token and a public key to decrypt it. If both is successful, the user claims can be
     * extracted from the JWT token.
     *
     * @param request - the incoming HTTP request
     */
    public Claims getUserClaims(HttpServletRequest request)
            throws NoSuchAlgorithmException, InvalidKeySpecException, IOException {

        StringBuilder buffer = new StringBuilder();
        Enumeration<String> headers = request.getHeaderNames();
        while (headers.hasMoreElements()) {
            buffer.append(headers.nextElement());
            buffer.append(" | ");
        }
        LOGGER.debug(BgxLogMarkers.AUTH, String.format("Available headers: %s", buffer.toString()));

        try {
            LOGGER.debug(BgxLogMarkers.AUTH, "Authorization header exists: {}",
                request.getHeader(BgxConstants.AUTHORIZATION_HEADER) != null);
            LOGGER.debug(BgxLogMarkers.AUTH, "Bootstrap Marker exists: {}",
                    request.getHeader(BgxConstants.HEADER_BOOTSTRAP_MARKER) != null);
            LOGGER.debug(BgxLogMarkers.AUTH, "Referrer header exists: {}",
                    request.getHeader(ApiConstants.REQUEST_HASH) != null);

            // retrieve auth token and optionally request hash
            String authToken = this.getAuthToken(request);
            String requestHash = request.getHeader(ApiConstants.REQUEST_HASH);

            // if we could find an auth token in the request headers (API and WS)
            if (authToken != null) {
                // retrieve public key and extract claims
                String publicKeyString = getPublicKey(authToken, request, requestHash);
                return this.extractUserClaims(authToken, publicKeyString);
            }

            // no user claims found
            LOGGER.warn(BgxLogMarkers.AUTH,
                    "Couldn't find bearer string, will ignore the header");
            return null;

        } catch (Exception e) {
            LOGGER.warn("Not authenticated. Error retrieving user claims.", e);
            throw e;
        }
    }

    /**
     * Return the public key of the issuer
     * <p>
     * It parses the JWT to find the `iss` (i.e. issuer) and the returns the corresponding publick
     * key from off-chain
     *
     * @param jtws JWT string
     */
    protected String getPublicKey(String jtws, boolean isRemoteSvc) throws IOException {

        // extract the iss
        String[] parts = jtws.split("\\."); // split at dot requires escaping twice
        LOGGER.debug(BgxLogMarkers.AUTH, "Found {} parts in JWT", parts.length);
        if (parts.length != 3) {
            throw new IllegalArgumentException(String.format(
                    "Invalid JWT token. Expected three parts separated by dot, found %d",
                    parts.length));
        }

        @SuppressWarnings("unchecked")
		Map<String, Object> claims = (Map<String, Object>) MAPPER.readValue(Base64.getDecoder().decode(parts[1]), Map.class);
        if (!claims.containsKey(BgxConstants.OAUTH_ISS)) {
            throw new IllegalArgumentException("JWT does not contain iss");
        }

        // extract the realm
        String issuer = (String) claims.get(BgxConstants.OAUTH_ISS);
        // get the public key from offchain
        List<Organization> orgs = null;

        if (isRemoteSvc) {
            orgs = organizationManager.getByApiAuthJwtIssuer(issuer);

            if (orgs == null || orgs.size() == 0) {
                throw new IllegalArgumentException(String.format(
                        "Remote service's JWT issuer '%s' could not be found", issuer));
            }
            LOGGER.debug(BgxLogMarkers.DEV,
                    "Found JWT issuer entity: " + orgs.get(0).getProfile().getEntityName());
            // pick the public key from the first record
            return orgs.get(0).getSettings().getApiAuth().getIssuerPublicKey();
        } else {
            orgs = organizationManager.getByUserAuthJwtIssuer(issuer);

            if (orgs == null || orgs.size() == 0) {
                throw new IllegalArgumentException(
                        String.format("User's JWT issuer '%s' could not be found", issuer));
            }

            // pick the public key from the first record
            return orgs.get(0).getSettings().getUserAuth().getIssuerPublicKey();
        }

    }
}
