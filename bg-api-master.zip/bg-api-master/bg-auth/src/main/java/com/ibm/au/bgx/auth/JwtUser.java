package com.ibm.au.bgx.auth;

import com.ibm.au.bgx.core.approvalmodel.FourEyeApprovalModel;
import com.ibm.au.bgx.core.approvalmodel.SoleApproverApprovalModel;
import com.ibm.au.bgx.core.auth.AbstractBgxPrincipal;
import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.GxPrefillRequestManager;
import com.ibm.au.bgx.model.RequestManager;
import com.ibm.au.bgx.model.chain.gx.GxManager;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.exception.BgxForbiddenException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Permission;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.pojo.approvalmodel.OrgApprovalModelSettings;
import com.ibm.au.bgx.model.user.BgxPrincipal;

import java.security.Principal;
import java.util.Collection;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.GrantedAuthority;

// TODO convert to scoped prototype component?

/**
 * @author Bruno Marques <brunomar@au1.ibm.com>
 */
public class JwtUser extends AbstractBgxPrincipal {

    /**
	 * 
	 */
	private static final long serialVersionUID = -3048510719063727545L;

	private static final Logger LOGGER = LoggerFactory.getLogger(JwtUser.class);

    protected transient ApplicationContext applicationContext;

    private boolean isApiClient = false;

    private String channelUserName;

    public JwtUser(UserProfile userProfile, JwtUser user) {
        super(userProfile, 
        	  user.getOrganization(), 
        	  user.getAuthorities(), 
        	  user.isEnabled(),
        	  user.isAccountNonExpired(), 
        	  user.isAccountNonLocked(), 
        	  user.isCredentialsNonExpired(),
        	  user.getComponentProvider()
        	 );
    }

    public JwtUser(UserProfile userProfile, 
    			   Organization organization,
    			   Collection<GrantedAuthority> authorities,
    			   boolean enabled, 
    			   boolean accountExpired, 
    			   boolean accountLocked,
    			   boolean credentialsExpired, 
    			   BgxComponentProvider componentProvider,
    			   ApplicationContext applicationContext, 
    			   boolean isApiClient, 
    			   String channelUserName) {

        super(userProfile, 
        	  organization, 
        	  authorities, 
        	  enabled, 
        	  accountExpired, 
        	  accountLocked, 
        	  credentialsExpired, 
        	  componentProvider);

        if (applicationContext == null) {
            throw new IllegalArgumentException("Application context cannot be null.");
        }

        this.applicationContext = applicationContext;
        this.isApiClient = isApiClient;
        this.channelUserName = channelUserName;

        this.requestManager = (RequestManager) applicationContext.getBean("requestManager", this);

        // NOTE organization does not exist during bootstrapping phase
        // TODO refactor
        if (organization != null) {

            if (this.isActingOnBehalf()) {
                LOGGER.debug(BgxLogMarkers.AUTH, 
                			 "Principal '{}' of org '{}' is acting on behalf of '{}' with channel user '{}'",
                			 this.getEmail(), 
                			 this.getPrimaryOrgId(), 
                			 this.getConfiguredForOrgId(), 
                			 this.getChannelUserName());

            }

            if (organization.getProfile().getEntityType().equals(OrgProfile.EntityType.APPLICANT_OR_BENEFICIARY)) {

                LOGGER.debug(BgxLogMarkers.AUTH, "Initializing principal {} with GxManager for org type {}", this.getEmail(), organization.getProfile().getEntityType());

                // Initialize GXManager if channel user is not null
                // channel user can be null for subsidiary org acting-on-behalf of parent, which means
                // subsidiary should not try to access the chain as parent
                //
                if (this.getChannelUserName() != null && !this.getChannelUserName().isEmpty()) {
                    
                	// Log the channel user
                    // channel user can be null for subsidiary acting-on-behalf of parent and for remote API clients
                	//
                    LOGGER.debug(BgxLogMarkers.AUTH, 
                    		     "Principal '{}' of org '{}' has channel user '{}' for org '{}'", 
                    		     this.getEmail(), 
                    		     this.getPrimaryOrgId(), 
                    		     this.getChannelUserName(), 
                    		     this.getConfiguredForOrgId());
                    
                    this.gxManager = (GxManager) applicationContext.getBean("appBenGxManager", this);
                }
            } else if (organization.getProfile().getEntityType().equals(OrgProfile.EntityType.ISSUER)) {

                LOGGER.debug(BgxLogMarkers.AUTH, 
                		     "Initializing principal {} with GxManager for org type {}", 
                		     this.getEmail(), 
                		     organization.getProfile().getEntityType());

                this.gxManager = (GxManager) applicationContext.getBean("issuerGxManager", this);
            } else {

                LOGGER.debug(BgxLogMarkers.AUTH, 
                			 "Skipping initialization of principal {} with GxManager for org type {}", 
                			 this.getEmail(), 
                			 organization.getProfile().getEntityType());

                this.gxManager = null;
            }

            OrgApprovalModelSettings orgApprovalModelSettings = organization.getSettings().getApprovalModel();
            // Approval models are optional, so organizations may not set one
            if (orgApprovalModelSettings != null) {
                ApprovalModelInfo.Name approvalModelName = organization.getSettings().getApprovalModel().getName();
                if (approvalModelName == ApprovalModelInfo.Name.SOLE_APPROVER) {
                    this.approvalModel = (SoleApproverApprovalModel) applicationContext.getBean("soleApproverApprovalModel", this);
                } else if (approvalModelName == ApprovalModelInfo.Name.FOUR_EYE) {
                    this.approvalModel = (FourEyeApprovalModel) applicationContext.getBean("fourEyeApprovalModel", this);
                } else {
                    this.approvalModel = null;
                }
            } else {
                this.approvalModel = null;
            }
            
            // [CV] TODO: this should not be set if we are in the admin vertical, because it is not needed.
            //
            //
            this.gxPrefillRequestManager = (GxPrefillRequestManager) applicationContext.getBean("gxPrefillRequestManager", this);
        } else {
            this.gxManager = null;
            this.approvalModel = null;
            this.gxPrefillRequestManager = null;
        }

    }

    public boolean isApiClient() {
        return this.isApiClient;
    }

    // USE WITH CARE!!! Since it can allow subsidiary to act-on-behalf of parent
    @Override
    public BgxPrincipal forOrg(Relationship relationship, String targetOrgId, List<Permission> orgPermissions) throws BgxForbiddenException {

        if (this.isSpawned()) {
            throw new BgxForbiddenException(String.format("Principal {} is already a spawned instance. Multiple spawning is not permitted.", this.getPrimaryOrgId()));
        }

        LOGGER.debug(BgxLogMarkers.AUTH, "Initializing principal for target org: {} with permissions: {}", targetOrgId, orgPermissions);

        if (targetOrgId == null || targetOrgId.isEmpty()) {
            throw new IllegalArgumentException("Target org Id cannot be empty");
        }

        if (orgPermissions == null || orgPermissions.isEmpty()) {
            throw new IllegalArgumentException("Org permissions cannot be empty");
        }

        if (this.getPrimaryOrgId().equals(targetOrgId)) {
            return this;
        }

        OrganizationManager organizationManager = this.applicationContext.getBean(OrganizationManager.class);
        if (organizationManager == null) {
            throw new IllegalStateException("Precondition failed, could not retrieve an instance of OrganizationManager to access principal organisation details.");
        }

        Organization targetOrg = null;
        try {
        	
            targetOrg = organizationManager.getById(targetOrgId);

        } catch (ProfileNotFoundException | ProfileChainException e) {
        	
            throw new BgxForbiddenException(String.format("Organisation (id: %s) does not exist. Cannot impersonate an non existing organisation.", targetOrgId));
        }

        Organization principalOrg = null;
        try {

            principalOrg = organizationManager.getById(this.getPrimaryOrgId());

        } catch (ProfileNotFoundException | ProfileChainException e) {

            throw new BgxForbiddenException(String.format("Principal organisation (id: %s) does not exist.", this.getPrimaryOrgId()));
        }

        // Check if principal's org is parent of the target org and has the required permissions
        RelationshipInfo allowedRelInfo = organizationManager.getAllowedRelationship(principalOrg, targetOrgId, orgPermissions, relationship);
        if (allowedRelInfo == null) {
            throw new BgxForbiddenException(String.format("Principal's organisation (id: %s) has no relationship with target organisation (id: %s). Impersonation not allowed.", 
            											  this.getPrimaryOrgId(),
            											  targetOrgId)
            							   );
        }
        
        // Check that user has roles for the target org if it is not the ADMIN of its own org
        // We allow the admin of any linked org to pass through the check below to act-on-behalf
        //
        if (!this.hasRole(this.userProfile.getPrimaryOrgId(), BgxConstants.ROLE_ADMIN)) {

            if (
            	!this.userProfile.getUserRoles().containsKey(targetOrgId) ||
                this.userProfile.getUserRoles().get(targetOrgId).isEmpty()
            ) {

                throw new BgxForbiddenException(String.format("User does not have roles for org %s to perform operation.", targetOrgId));
            }

            // Check that user has valid roles for the target org
            if (targetOrg.getSettings()
            			 .getRoles()
            			 .containsAll(this.userProfile.getUserRoles().get(targetOrgId))) {

                throw new BgxForbiddenException(String.format("User does not have valid roles for org %s to perform operation.", targetOrgId));
            }
        }

        if (
        	allowedRelInfo.getRelationship().equals(Relationship.PARENT_OF) && 
        	(allowedRelInfo.getChannelUserName() == null || allowedRelInfo.getChannelUserName().isEmpty())
        ) {
        	
            throw new IllegalStateException(String.format("Could not find channel user name for the subsidiary: %s", targetOrgId));
        }

        // Prepare a new GxManager instance bound to the targetOrgId that the principal has relationship to
        LOGGER.debug(BgxLogMarkers.DEV, "Initializing Principal for target Org: {}", targetOrgId);

        return new JwtUser(this.userProfile, 
        				   targetOrg, 
        				   this.authorities, 
        				   this.enabled,
        				   this.accountExpired, 
        				   this.accountLocked, 
        				   this.credentialsExpired,
        				   this.componentProvider, 
        				   this.applicationContext, 
        				   false, 
        				   allowedRelInfo.getChannelUserName());
    }

    @Override
    public String getChannelUserName() {
    	
        // We first check that the organization type is an applicant or beneficiary.
        // For these organisations, fabrics users are created dynamically and they
        // are mapped to the organisationId that they represent (including parent-sub)
        //
        if (this.isUserOfOrgType(EntityType.APPLICANT_OR_BENEFICIARY)) {
        	
            return this.channelUserName;
        }

        // The remaining organisation types, are assigned a static fabric
        // user, from the identity configuration.
        //
        //
        return this.getComponentProvider()
        		   .getIdentityConfig()
        		   .getFabricUser();
    }
}
