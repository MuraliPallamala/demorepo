package com.ibm.au.bgx.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.rest.ApiConstants;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.api.RevokedTokenCacheManager;
import com.ibm.au.bgx.model.api.exceptions.ApiForbiddenException;
import com.ibm.au.bgx.model.auth.BgxUserDetailService;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.chain.profile.UserProfileManager;
import com.ibm.au.bgx.model.exception.BgxForbiddenException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.identityprovider.LogoutClient;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.nimbusds.oauth2.sdk.AuthorizationCode;
import com.nimbusds.oauth2.sdk.AuthorizationCodeGrant;
import com.nimbusds.oauth2.sdk.AuthorizationGrant;
import com.nimbusds.oauth2.sdk.AuthorizationRequest;
import com.nimbusds.oauth2.sdk.ParseException;
import com.nimbusds.oauth2.sdk.RefreshTokenGrant;
import com.nimbusds.oauth2.sdk.ResponseType;
import com.nimbusds.oauth2.sdk.Scope;
import com.nimbusds.oauth2.sdk.TokenErrorResponse;
import com.nimbusds.oauth2.sdk.TokenRequest;
import com.nimbusds.oauth2.sdk.TokenResponse;
import com.nimbusds.oauth2.sdk.auth.ClientAuthentication;
import com.nimbusds.oauth2.sdk.auth.ClientSecretBasic;
import com.nimbusds.oauth2.sdk.auth.Secret;
import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import com.nimbusds.oauth2.sdk.http.HTTPResponse;
import com.nimbusds.oauth2.sdk.id.ClientID;
import com.nimbusds.oauth2.sdk.id.State;
import com.nimbusds.oauth2.sdk.token.RefreshToken;
import com.nimbusds.openid.connect.sdk.OIDCTokenResponse;
import com.nimbusds.openid.connect.sdk.OIDCTokenResponseParser;
import io.jsonwebtoken.Claims;
import io.netty.handler.codec.http.HttpMethod;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.minidev.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * This class is responsible for validating the JWT token and checking the authorizations associated
 * with the user.
 *
 * @author Bruno Marques <brunomar@au1.ibm.com>
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public class OpenIdAuthenticationFilter extends OncePerRequestFilter {

    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private final Logger LOGGER = LoggerFactory.getLogger(OpenIdAuthenticationFilter.class);

    private final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    private String realmPrefix;

    private BgxUserDetailService userDetailsService;

    private JwtUtil jwtUtil;

    private OrganizationManager organizationManager;

    private UserProfileManager userProfileManager;

    private RevokedTokenCacheManager revokedTokenCacheManager;

    private LogoutClient logoutClient;

    private SSLUtils sslUtils;

    /**
     * If this is not null we use this for openId authentication processing
     */
    private String currentOrgId;

    public OpenIdAuthenticationFilter(BgxUserDetailService userDetailsService, JwtUtil jwtUtil,
        OrganizationManager organizationManager,
        UserProfileManager userProfileManager,
        RevokedTokenCacheManager revokedTokenCacheManager, LogoutClient logoutClient,
        SSLUtils utils, String realmPrefix) {
        super();
        this.userDetailsService = userDetailsService;
        this.jwtUtil = jwtUtil;
        this.organizationManager = organizationManager;
        this.userProfileManager = userProfileManager;
        this.currentOrgId = null;
        this.revokedTokenCacheManager = revokedTokenCacheManager;
        this.logoutClient = logoutClient;
        this.sslUtils = utils;
        this.realmPrefix = realmPrefix;

        LOGGER.debug(BgxLogMarkers.AUTH, "Initialised JwtAuthenticationFilter");
    }

    public String getCurrentOrgId() {
        return this.currentOrgId;
    }

    public void setCurrentOrgId(String orgId) {
        this.currentOrgId = orgId;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        LOGGER.debug(BgxLogMarkers.AUTH, "Request Authorization header exists: {}",
            request.getHeader(HttpHeaders.AUTHORIZATION) != null);
        try {
            // Try to do authentication using APIKEY if it exists
            if (request.getHeader(HttpHeaders.AUTHORIZATION) != null
                && request.getHeader(HttpHeaders.AUTHORIZATION)
                .startsWith(String.format("%s%s", BgxConstants.BEARER_PREFIX,
                    BgxConstants.USER_API_KEY_PREFIX))) {

                LOGGER.debug(BgxLogMarkers.AUTH, "Trying to authenticate using API key");

                // Try to authenticate using the API key
                this.doFilterUsingApiKey(request, response, chain);

            } else {

                LOGGER.debug(BgxLogMarkers.AUTH, "Trying to authenticate using JWT");

                // cleanup cache
                revokedTokenCacheManager.cleanUpExpired();


                // Try to authenticate using the JWT
                this.doFilterUsingJwt(request, response, chain);
            }
        } catch (Exception e) {
            String errorId = UUID.randomUUID().toString();
            LOGGER.debug(BgxLogMarkers.AUTH, "Error during execution of authentication filter. {}",
                errorId, e);

            // any issue with authentication, just log the issue and set status to 401
            HttpStatus httpStatus = HttpStatus.UNAUTHORIZED;

            Map<String, Object> errResp = new HashMap<>();
            errResp.put("reference", errorId);
            errResp.put("message", "Could not process authentication request");

            // if it is BgxForbidden exception, return 403 instead
            if (e instanceof BgxForbiddenException) {
                errResp.put("message", e.getMessage());
                httpStatus = HttpStatus.FORBIDDEN;
            }

            this.sendAuthResponse(response, httpStatus, errResp);
            return;
        }

        chain.doFilter(request, response);
    }

    /**
     * Performs the actual filtering. The method is wrapped by the actual doFilterInternal and any
     * exception thrown by this is handled more graceful.
     *
     * @param request - the incoming http request
     * @param response - the prepared http response
     * @param chain - the filter chain used to perform the filtering
     */
    protected void doFilterUsingApiKey(HttpServletRequest request, HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String apiKey = request.getHeader(HttpHeaders.AUTHORIZATION)
            .substring(BgxConstants.BEARER_PREFIX.length());

        // this returns us the JwtUser that implements BgxPrincipal
        JwtUser userDetails = (JwtUser) this.userDetailsService
            .loadUserByApiKey(apiKey);

        this.setSecurityContext(request, userDetails);
    }


    /**
     * Set the user in security context
     */
    private void setSecurityContext(HttpServletRequest request, JwtUser userDetails) {

        userDetails.setDetails(
            new WebAuthenticationDetailsSource().buildDetails(request));
        // update security context with principal (allows to retrieve this via
        // @AuthenticationPrincipal annotation)
        SecurityContextHolder.getContext().setAuthentication(userDetails);
    }

    /**
     * Performs the actual filtering. The method is wrapped by the actual doFilterInternal and any
     * exception thrown by this is handled more graceful.
     *
     * @param request - the incoming http request
     * @param response - the prepared http response
     * @param chain - the filter chain used to perform the filtering
     */
    protected void doFilterUsingJwt(HttpServletRequest request, HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(BgxLogMarkers.AUTH, String.format("In authentication filter: %s",
                request.getServletPath()));

            LOGGER.debug(BgxLogMarkers.AUTH, String.format("Request Method: %s | Request URI: %s",
                request.getMethod(), request.getRequestURI()));
        }

        // Validate JWT and get the user name
        Claims userClaims = null;
        String authToken = jwtUtil.getAuthToken(request);
        if (authToken != null) {
            LOGGER.debug(BgxLogMarkers.AUTH, "Found auth token");
            try {
                userClaims = jwtUtil.getUserClaims(request);
                LOGGER.debug(BgxLogMarkers.AUTH, String.format("User Claims: %s", userClaims));
            } catch (Exception e) {
                throw new IllegalArgumentException("Could not process authorization token", e);
            }
        }

        // If JWT token is available and valid, proceed with the authentication
        if (userClaims != null) {
            LOGGER.debug(BgxLogMarkers.AUTH, "Authenticating user {} with JWT claims", extractUserNameFromClaims(userClaims));
            this.authenticateUserWithUserClaims(request, response, userClaims);
        } else {
            LOGGER.debug(BgxLogMarkers.AUTH, "Requesting for authentication");
            // If we are here that means either user is making a request for access token,
            // or just trying to be redirected to identity provider for openId authentication
            this.processAuthenticationRequestFlow(request, response);
        }
    }

    /**
     * Redirect user to identity provider or retrieve access token
     */
    private void processAuthenticationRequestFlow(HttpServletRequest request,
        HttpServletResponse response)
        throws IOException {

        if (currentOrgId != null || this.hasOrgKeyAndTokenHeader(request)) {

            // Extract orgKey if it exists
            String orgKey = request.getHeader(ApiConstants.ONBOARDING_HEADER_DLT_REQUEST_KEY);

            LOGGER.debug(BgxLogMarkers.AUTH, String
                .format("Processing authentication flow for currentOrgId: %s | orgKey: %s",
                    currentOrgId, orgKey));

            // Find organization either from orgKey or the currentOrgId settings
            Organization organization = null;
            if (currentOrgId != null) {
                try {
                    organization = organizationManager.getById(currentOrgId);
                } catch (ProfileNotFoundException | ProfileChainException e) {
                    throw new IllegalStateException(
                        String.format("Could not find organization with ID: ", currentOrgId),
                        e);
                }
            } else if (orgKey != null) {
                organization = organizationManager.getByKey(orgKey);
            }

            // Validate that organization details exists
            if (organization == null || organization.getSettings() == null) {
                throw new IllegalArgumentException(
                    "Organization and its settings cannot be empty.");
            }


            // Initialize orgKey
            orgKey = organization.getSettings().getKey();

            // Check if it is a request to retrieve an access token or refresh token.
            if (request.getRequestURI().endsWith(ApiConstants.OIDC_TOKEN_ENDPOINT)
                && request.getMethod().equals(HttpMethod.GET.name())) {
                this.processTokenEndpointRequests(request, response, organization, null);
                return;
            }

            // If we are here, it means user is making a request to be redirect to the identity provider
            // Return the authorization redirect url
            LOGGER.debug(BgxLogMarkers.AUTH, String.format(
                "[PHASE 1] - Trying to get the authorization code."));

            OpenIdConfig userAuthConfig = organization.getSettings().getUserAuth();
            String authUrl = this.generateAuthorizationUri(userAuthConfig, orgKey);
            Map<String, Object> responseBody = new HashMap<>();
            responseBody.put(BgxConstants.KEY_REDIRECT_URI, authUrl);
            this.sendAuthResponse(response, HttpStatus.UNAUTHORIZED, responseBody);
        }

        // If we are here, that means something is wrong
        // However, we are logging a message rather than throwing an exception so that the filter chain can continue
        LOGGER.debug(BgxLogMarkers.AUTH,
            "Missing authentication headers or currentOrgId. Could not process authentication.");
    }

    /**
     * Process authentication using the JWT claims
     */
    private void authenticateUserWithUserClaims(HttpServletRequest request,
        HttpServletResponse response, Claims userClaims)
        throws IOException {

        String authToken = jwtUtil.getAuthToken(request);
        String username = this.extractUserNameFromClaims(userClaims);
        LOGGER.debug(BgxLogMarkers.AUTH, String.format("JWT user: %s", username));

        // Find the organization
        Organization organization = getOrganizationFromUserClaims(userClaims, username);

        // Fail early if organization is required for the user type
        // Note we don't need organization for remote API call or bootstrap call
        if (!username.startsWith(BgxConstants.API_AUTH_CLIENT_PREFIX) && organization == null) {
            throw new IllegalArgumentException(
                String.format("Organization could not be found for user '%s'", username));
        }

        // Check if the token is revoked.
        LOGGER.debug(BgxLogMarkers.AUTH, "Check if the token is revoked: "
            + revokedTokenCacheManager.tokenExists(authToken));
        if (revokedTokenCacheManager.tokenExists(authToken)) {
            handleRevokedTokens(request, response);
            this.sendAuthResponse(response, HttpStatus.UNAUTHORIZED, "You cannot use the revoked token");
            return;
        }

        // Check if it is a logout request or refresh token request.
        if (request.getRequestURI().endsWith(ApiConstants.OIDC_TOKEN_ENDPOINT)) {
            this.processTokenEndpointRequests(request, response, organization, userClaims);
            return;
        }

        // If we are here, that means the user is authenticated and requesting for access
        // to protected resources
        // So, process authenticated user and update security context
        processAuthenticatedUser(request, response, userClaims, username, organization);
    }

    /**
     * Check if header contains orgKey and token
     *
     * These headers are present for onboarding requests
     */
    private boolean hasOrgKeyAndTokenHeader(HttpServletRequest request) {
        return this.hasOrgKeyHeader(request)
            && request.getHeader(ApiConstants.ONBOARDING_HEADER_DLT_AUTH_TOKEN) == null;
    }

    /**
     * Helper method to check if header contains org key
     */
    private boolean hasOrgKeyHeader(HttpServletRequest request) {
        return request.getHeader(ApiConstants.ONBOARDING_HEADER_DLT_REQUEST_KEY) != null
            && request.getHeader(ApiConstants.ONBOARDING_HEADER_DLT_REQUEST_KEY).length()
            == BgxConstants.ORG_KEY_LEN;
    }

    /**
     * Set security context for the authenticated user
     */
    private void processAuthenticatedUser(HttpServletRequest request, HttpServletResponse response,
        Claims userClaims, String username, Organization organization) throws IOException {

        LOGGER.debug(BgxLogMarkers.AUTH,
            "[PHASE 3] - Checking authentication for user: {} | realmPrefix: {} | Issuer: {} ",
            username, realmPrefix, userClaims.getIssuer());

        if (this.userDetailsService == null) {
            throw new IllegalArgumentException("Could not find user details service instance");
        }

        try {
            // this returns us the JwtUser that implements BgxPrincipal
            String jwt = jwtUtil.getAuthToken(request);
            Instant jwtIssuedAt = userClaims.getIssuedAt().toInstant();
            Instant jwtExpiry = userClaims.getExpiration().toInstant();
            String orgId = organization != null ? organization.getId() : null;
            JwtUser userDetails = (JwtUser) this.userDetailsService
                .loadUserByUsername(orgId, username, jwt, jwtIssuedAt, jwtExpiry);

            this.setSecurityContext(request, userDetails);

        } catch (Exception ex) {
            // e.g. user is not ACTIVE
            LOGGER.error("Error during authentication: {}", ex.getMessage(), ex);
            if (ex instanceof ApiForbiddenException) {
                Map<String, Object> body = new HashMap<>();
                body.put("message", ex.getMessage());
                if (((ApiForbiddenException) ex).getResponse().getCode() != null) {
                    body.put("code", ((ApiForbiddenException) ex).getResponse().getCode().intValue());
                }
                this.sendAuthResponse(response, HttpStatus.FORBIDDEN, body);
            } else {
                this.sendAuthResponse(response, HttpStatus.UNAUTHORIZED,
                    "Could not process user details");
            }
        }
    }

    /**
     * Process any request to the OIDC token endpoint
     *
     * User may request for the following:
     * Access token: GET request with authorization header
     * Refresh token: GET request with refresh token header
     * Revoke or logout: DELETE request with access token. We require access token so that only the
     * authenticated users can logout themselves
     */
    private void processTokenEndpointRequests(HttpServletRequest request,
        HttpServletResponse response, Organization organization, Claims userClaims)
        throws IOException {

        LOGGER.debug(BgxLogMarkers.AUTH, String.format("Processing %s: %s",
            request.getMethod(), ApiConstants.OIDC_TOKEN_ENDPOINT));

        if (request.getMethod().equals(HttpMethod.GET.name())) {
            if (request.getHeader(BgxConstants.HEADER_OPENID_AUTHORIZATION_CODE) != null) {
                this.handleAccessTokenRequest(request, response, organization);
            } else if (request.getHeader(BgxConstants.HEADER_OPENID_REFRESH_TOKEN) != null) {
                this.handleRefreshTokenRequest(request, response, organization);
            }
        } else if (request.getMethod().equals(HttpMethod.DELETE.name())) {
            this.handleLogoutRequest(request, response, organization, userClaims);
        }
    }

    private void handleRevokedTokens(HttpServletRequest request, HttpServletResponse response)
        throws IOException {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }


        LOGGER.debug(BgxLogMarkers.AUTH, "Token is revoked and user was logged out");
    }

    /**
     * Find organization fro the user claims issuer information
     *
     * Issuer info contains the orgKey since we are using Keycloak. So we can use that to retrieve
     * the organization Note that if we use something other than Keycloak, this will be a problem
     * and it needs fixing
     */
    private Organization getOrganizationFromUserClaims(Claims userClaims, String username) {
        Organization organization = null;
        // only try to fetch org if it is not api-to-api auth client
        if (username != null && !username.startsWith(BgxConstants.API_AUTH_CLIENT_PREFIX)) {
            String orgKey = JwtUtil.extractOrgKeyFromIssuer(userClaims.getIssuer());

            // strip realm prefix from org key
            if (orgKey.startsWith(realmPrefix)) {
                orgKey = orgKey.replaceAll(realmPrefix, "");
            }

            organization = organizationManager.getByKey(orgKey);
            if (organization == null) {
                throw new IllegalArgumentException(String
                    .format("Organization not found with key: %s", orgKey));
            }
        }

        return organization;
    }

    /**
     * Process access token request of the suer
     */
    private void handleAccessTokenRequest(HttpServletRequest request, HttpServletResponse response,
        Organization organization)
        throws IOException {

        if (organization == null || organization.getSettings() == null) {
            throw new IllegalArgumentException("Organization and its settings cannot be empty.");
        }

        if (organization.getSettings().getUserAuth() == null) {
            throw new IllegalArgumentException("Organization's user authentication settings cannot be empty");
        }

        if (organization.getSettings().getKey() == null) {
            throw new IllegalArgumentException("Organization key cannot be empty");
        }

        OpenIdConfig userAuthConfig = organization.getSettings().getUserAuth();
        String orgKey = organization.getSettings().getKey();

        // if authorization code exists, get the access token
        String authorizationCode = request.getHeader(
            BgxConstants.HEADER_OPENID_AUTHORIZATION_CODE);

        // Validate request
        if (authorizationCode == null) {
            JSONObject body = new JSONObject();
            body.put("code", HttpStatus.BAD_REQUEST.value());
            body.put("message", "Malformed request");
            body.put("description", "Could not find authorization code in the header.");
            this.sendAuthResponse(response, HttpStatus.BAD_REQUEST, body.toJSONString());

            LOGGER.debug(BgxLogMarkers.AUTH, "Request is malformed.");

            return;
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(BgxLogMarkers.AUTH, String.format(
                "[PHASE 2] - Trying to get access token from authorization code."));
        }

        // Retrieves tokens
        JSONObject token = this.getAccessTokenFromAuthorizationCode(
            userAuthConfig, orgKey, authorizationCode);

        if (token == null) {
            throw new IllegalArgumentException("Could not retrieve token");
        }

        if (!token.containsKey(BgxConstants.JWT_ACCESS_TOKEN)) {
            throw new IllegalArgumentException("Could not find access token");
        }

        this.sendAuthResponse(response, HttpStatus.OK, token.toJSONString());
    }

    /**
     * Handle refresh token request of the user
     */
    private void handleRefreshTokenRequest(HttpServletRequest request, HttpServletResponse response,
        Organization organization)
        throws IOException {

        LOGGER.debug(BgxLogMarkers.AUTH, "Refresh token");

        if (organization == null || organization.getSettings() == null) {
            throw new IllegalArgumentException("Organization and its settings cannot be empty.");
        }

        if (organization.getSettings().getUserAuth() == null) {
            throw new IllegalArgumentException(
                "Organization's user authentication settings cannot be empty");
        }

        if (organization.getSettings().getKey() == null) {
            throw new IllegalArgumentException("Organization key cannot be empty");
        }

        OpenIdConfig userAuthConfig = organization.getSettings().getUserAuth();
        String orgKey = organization.getSettings().getKey();
        String refreshToken = request
            .getHeader(BgxConstants.HEADER_OPENID_REFRESH_TOKEN);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(BgxLogMarkers.AUTH,
                "[PHASE 4] - Getting an access token from refresh token {}", realmPrefix);
        }

        // Validate request
        if (refreshToken == null) {
            JSONObject body = new JSONObject();
            body.put("code", HttpStatus.BAD_REQUEST.value());
            body.put("message", "Malformed request");
            body.put("description", "Could not find refresh token in the header.");
            this.sendAuthResponse(response, HttpStatus.BAD_REQUEST, body.toJSONString());

            LOGGER.debug(BgxLogMarkers.AUTH, "Request is malformed.");

            return;
        }

        // Retrieves tokens
        JSONObject token = this.getAccessTokenFromRefreshToken(
            userAuthConfig, orgKey, refreshToken);

        LOGGER.debug(BgxLogMarkers.AUTH, token.keySet().toString());

        if (!token.containsKey(BgxConstants.JWT_ACCESS_TOKEN)) {
            throw new IllegalArgumentException("Could not find access token");
        }

        // update user last login with the new token
        this.updateAllowedAuthTokens(organization, token);

        this.sendAuthResponse(response, HttpStatus.OK, token.toJSONString());

        return;
    }

    private void updateAllowedAuthTokens(Organization organization,  JSONObject token) {
        try {
            String accessToken = token.getAsString(BgxConstants.JWT_ACCESS_TOKEN);
            String username = extractUserNameFromJwt(accessToken);
            Claims userClaims = jwtUtil.extractUserClaims(accessToken, null);
            UserProfile userProfile = userProfileManager.getByEmail(organization.getId(), username);
            if (userProfile == null) {
                throw new IllegalArgumentException(String.format("Could not retrieve user profile: %s", username));
            }
            userProfileManager.updateAllowedAuthTokens(userProfile.getId(), accessToken, userClaims.getExpiration().toInstant());
        } catch (NoSuchAlgorithmException | InvalidKeySpecException | IOException e) {
            throw new IllegalArgumentException("Could not parse token", e);
        }

    }

    /**
     * Handle delete token or logout request
     */
    private void handleLogoutRequest(HttpServletRequest request, HttpServletResponse response,
        Organization organization, Claims userClaims)
        throws IOException {

        if (organization == null || organization.getSettings() == null) {
            throw new IllegalArgumentException("Organization and its settings cannot be empty.");
        }

        if (organization.getSettings().getUserAuth() == null) {
            throw new IllegalArgumentException(
                "Organization's user authentication settings cannot be empty");
        }

        if (organization.getSettings().getKey() == null) {
            throw new IllegalArgumentException("Organization key cannot be empty");
        }

        if (userClaims == null) {
            throw new IllegalArgumentException("User claims cannot be null");
        }

        OpenIdConfig userAuthConfig = organization.getSettings().getUserAuth();
        String username = this.extractUserNameFromClaims(userClaims);
        String authToken = jwtUtil.getAuthToken(request);

        revokedTokenCacheManager.addToken(authToken, userClaims.getExpiration().getTime());

        try {
            String[] issuerStringArray = userClaims.getIssuer().split("/");
            String realmString = issuerStringArray[issuerStringArray.length - 1];
            String refreshToken =
                request.getHeader(BgxConstants.HEADER_OPENID_REFRESH_TOKEN);

            logoutClient.logout(userAuthConfig.getClientId(),
                userAuthConfig.getClientSecret(), refreshToken, realmString);

            // reset last login details so that next login is not blocked by parallel login blocker
            UserProfile userProfile = userProfileManager.getByEmail(organization.getId(), username);
            if (userProfile == null) {
                throw new IllegalArgumentException(
                    String.format("Could not find user profile with username: %s", username));
            }
            userProfileManager.resetLastLogin(userProfile.getId());

            this.sendAuthResponse(response, HttpStatus.NO_CONTENT, "");

        } catch (Throwable e) {
            LOGGER.error(BgxLogMarkers.AUTH, "An error occurred during logout.", e);
            this.sendAuthResponse(response, HttpStatus.UNAUTHORIZED, "");
        }
    }

    /**
     * Helper method to extract user name from JWT claims
     */
    private String extractUserNameFromClaims(Claims claims) {

        if (claims == null) {
            throw new IllegalArgumentException("Claims cannot be null");
        }

        return claims.get(BgxConstants.JWT_USERNAME).toString();
    }

    /**
     * Extract username from access token or request token which are JWT
     */
	private String extractUserNameFromJwt(String jwt) {

        // If the username is in the revokedTokenCache, make sure it is
        // removed.
        Map<String, Object> token = null;
        try {
            token = JwtUtil.decodeJwtPayload(jwt);
        } catch (Exception e) {
            throw new IllegalArgumentException("Could not parse JWT token", e);
        }

        if (!token.containsKey(BgxConstants.JWT_USERNAME)) {
            throw new IllegalArgumentException(String.format("JWT does not contain %s", BgxConstants.JWT_USERNAME));
        }

        return token.get(BgxConstants.JWT_USERNAME).toString();
    }


    /**
     * This method generates the url that will be used by the client in order to obtain an
     * authorization token. Once the client gets the token, he/she can use it to request an access
     * token.
     */
    private String generateAuthorizationUri(OpenIdConfig authConfig, String orgKey) {

        if (authConfig == null) {
            throw new IllegalArgumentException("Auth config cannot be null");
        }

        if (orgKey == null) {
            throw new IllegalArgumentException("Org key cannot be null");
        }

        // The authorisation endpoint of the server
        URI authzEndpoint = null;
        try {
            authzEndpoint = new URI(authConfig.getUserAuthorizationUri());

            // The client identifier provisioned by the server
            ClientID clientId = new ClientID(authConfig.getClientId());

            // The requested scope values for the token
            Scope scope = new Scope(authConfig.getScopes().toArray(new String[]{}));

            // The client callback URI, typically pre-registered with the server
            URI callback = new URI(this.generateCallbackUrl(authConfig, orgKey));

            // Generate random state string for pairing the response to the request
            // FIXME maybe we should store it and use to verify the authorization token
            State state = new State();

            AuthorizationRequest authRequest =
                new AuthorizationRequest.Builder(new ResponseType(ResponseType.Value.CODE),
                    clientId).scope(scope).state(state).redirectionURI(callback)
                    .endpointURI(authzEndpoint).build();

            LOGGER.debug(BgxLogMarkers.AUTH,
                String.format("Authorization URI: %s", authRequest.toURI()));

            return String.format("%s&ts=%d", authRequest.toURI().toString(), new Date().getTime());
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(String
                .format("Invalid authorization URL: %s", authConfig.getUserAuthorizationUri()), e);
        }
    }

    /**
     * Retrieves OICD tokens using an authorisation code.
     */
    private JSONObject getAccessTokenFromAuthorizationCode(OpenIdConfig authConfig, String requestKey,
        String authorizationCode) {

        // FIXME maybe we should use state to verify the authorization token

        // Construct the code grant from the code obtained from the authz endpoint
        // and the original callback URI used at the authz endpoint
        AuthorizationCode code = new AuthorizationCode(authorizationCode);

        // The client callback URI, typically pre-registered with the server
        URI callback = null;
        try {
            callback = new URI(this.generateCallbackUrl(authConfig, requestKey));
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("Invalid callback URL: %s", e);
        }

        AuthorizationGrant codeGrant = new AuthorizationCodeGrant(code, callback);

        // The client identifier provisioned by the server
        ClientID clientId = new ClientID(authConfig.getClientId());

        Secret clientSecret = new Secret(authConfig.getClientSecret());
        ClientAuthentication clientAuth = new ClientSecretBasic(clientId, clientSecret);

        // The token endpoint
        URI tokenEndpoint = null;
        try {
            tokenEndpoint = new URI(authConfig.getAccessTokenUri());
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("Invalid token URL", e);
        }

        if (LOGGER.isDebugEnabled()) {

            LOGGER.debug(BgxLogMarkers.AUTH,
                String.format("Submitting Token Request [Token Uri: %s, Callback: %s]",
                    tokenEndpoint.toString(), callback));
        }
        // Make the token request
        TokenRequest request = new TokenRequest(tokenEndpoint, clientAuth, codeGrant);
        TokenResponse tokenResponse = null;
        try {
            tokenResponse = this.submitTokenRequest(request);
        } catch (IOException | ParseException e) {
            throw new IllegalArgumentException("Could not submit token request", e);
        }

        if (!tokenResponse.indicatesSuccess()) {
            TokenErrorResponse errorResponse = tokenResponse.toErrorResponse();
            JSONObject object = errorResponse.toJSONObject();
            LOGGER.debug(BgxLogMarkers.AUTH, "Authentication failed: "
                + (object == null ? "<null>" : object.toString()));
            throw new IllegalArgumentException(
                "Could not retrieve access token from identity provider");
        }

        OIDCTokenResponse successResponse = (OIDCTokenResponse) tokenResponse.toSuccessResponse();
        return successResponse.getOIDCTokens().toJSONObject();
    }

    /**
     * Generate callback URL for the organization
     */
    private String generateCallbackUrl(OpenIdConfig authConfig, String orgKey) {

        if (authConfig == null || authConfig.getRedirectUri() == null) {
            throw new IllegalArgumentException("Could not find auth config for the organization");
        }

        // if in dev mode return localhost
        // replace the '*' with the orgKey
        return authConfig.getRedirectUri().replace("*", orgKey);
    }

    /**
     * Retrieves OICDTokens using a refresh token.
     */
    private JSONObject getAccessTokenFromRefreshToken(OpenIdConfig authConfig, String requestKey,
        String refreshTokenString) {

        RefreshToken refreshToken = new RefreshToken(refreshTokenString);
        AuthorizationGrant refreshTokenGrant = new RefreshTokenGrant(refreshToken);

        ClientID clientID = new ClientID(authConfig.getClientId());
        Secret clientSecret = new Secret(authConfig.getClientSecret());
        ClientAuthentication clientAuth = new ClientSecretBasic(clientID, clientSecret);

        URI tokenEndpoint = null;
        try {
            tokenEndpoint = new URI(authConfig.getAccessTokenUri());
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(
                String.format("Invalid access token URL: %s", authConfig.getAccessTokenUri()), e);
        }

        TokenRequest request = new TokenRequest(tokenEndpoint, clientAuth, refreshTokenGrant);
        TokenResponse tokenResponse = null;
        try {
            tokenResponse = this.submitTokenRequest(request);
        } catch (Exception e) {
            throw new IllegalArgumentException("Could not send token request", e);
        }

        if (!tokenResponse.indicatesSuccess()) {
            TokenErrorResponse errorResponse = tokenResponse.toErrorResponse();
            JSONObject object = errorResponse.toJSONObject();
            LOGGER.debug(BgxLogMarkers.AUTH, "Authentication failed: "
                + (object == null ? "<null>" : object.toString()));
            throw new IllegalArgumentException(
                "Could not retrieve access token from identity provider");
        }

        OIDCTokenResponse successResponse = (OIDCTokenResponse) tokenResponse.toSuccessResponse();
        return successResponse.getOIDCTokens().toJSONObject();
    }

    /**
     * Send the token request
     */
    private TokenResponse submitTokenRequest(TokenRequest request)
        throws IOException, ParseException {

        try {

            HTTPRequest httpRequest = request.toHTTPRequest();
            httpRequest.setSSLSocketFactory(this.sslUtils.getSSLSocketFactory());
            HTTPResponse response = httpRequest.send();

            return OIDCTokenResponseParser.parse(response);

        } catch (Throwable t) {

            LOGGER.error(BgxLogMarkers.AUTH, String.format(
                "Could not retrieve authentication token. [type: %s, message: %s]",
                t.getClass().getName(), t.getMessage()));
            throw t;
        }
    }


    /**
     * Helper method to return http response
     */
    private void sendAuthResponse(HttpServletResponse response, HttpStatus httpStatus,
        Map<String, Object> body) throws IOException {
        this.sendAuthResponse(response, httpStatus, MAPPER.writeValueAsString(body));
    }

    /**
     * Helper method to return http response
     */
    private void sendAuthResponse(HttpServletResponse response, HttpStatus httpStatus, String body)
        throws IOException {
        response.setStatus(httpStatus.value());

        if ((body != null && !body.isEmpty()) || httpStatus.equals(HttpStatus.NO_CONTENT)) {
            response.setHeader(HttpHeaders.ACCEPT, "application/json");
            response.getWriter().write(body);
        }
        response.getWriter().flush();
        response.getWriter().close();
    }
}
