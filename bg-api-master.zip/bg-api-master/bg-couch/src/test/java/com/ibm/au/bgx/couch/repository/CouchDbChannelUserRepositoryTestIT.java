package com.ibm.au.bgx.couch.repository;

import static org.junit.Assert.assertEquals;

import com.ibm.au.bgx.BgxStatusResourceMock;
import com.ibm.au.bgx.model.chain.BgxDefaultEnrollment;
import com.ibm.au.bgx.model.chain.ChannelUser;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import java.security.PrivateKey;
import java.util.UUID;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    CouchDbChannelUserRepository.class,
    BgxStatusResourceMock.class
})
@TestPropertySource(locations = "classpath:application-test.properties")
public class CouchDbChannelUserRepositoryTestIT {

    @Autowired
    CouchDbChannelUserRepository repository;

    @Test
    public void find() throws Exception {

        // check the enrollment secret is encrypted
        ChannelUser channelUser = new ChannelUser(UUID.randomUUID().toString(), "org1", "MSP1");
        channelUser.setEnrollmentSecret("secret");
        repository.addItem(channelUser);

        ChannelUser retrieved = repository.find(channelUser.getName(), channelUser.getMspId());
        assertEquals(channelUser.getEnrollmentSecret(), retrieved.getEnrollmentSecret());


        // check enrollment cert and keys are encrypted

        String key = "-----BEGIN PRIVATE KEY-----\n"								// pragma: whitelist secret
            + "MIGTAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBHkwdwIBAQQgiooxmphM6w67rP5R\n"
            + "9cu2o5VIfwfIR8QQUNAaXF/6tc6gCgYIKoZIzj0DAQehRANCAAQcUNjPex3A16sJ\n"
            + "axmc2y6EEDPS+8SvD3mkH8Uq6HkyA6QXtayA/BGGECBsv7M591YR/MnraSDXDy4V\n"
            + "Aw+XZFFJ\n"
            + "-----END PRIVATE KEY-----\n";

        String cert = "-----BEGIN CERTIFICATE-----\n"
            + "MIIB7DCCAZKgAwIBAgIUJO6hFDExNli4bbwy1A0e5PCxpZYwCgYIKoZIzj0EAwIw\n"
            + "XTELMAkGA1UEBhMCVVMxEzARBgNVBAgTCkNhbGlmb3JuaWExFjAUBgNVBAcTDVNh\n"
            + "biBGcmFuY2lzY28xDjAMBgNVBAoTBW5ld2NvMREwDwYDVQQDEwhjYS5uZXdjbzAe\n"
            + "Fw0xODExMTUwMTU0MDBaFw0xOTExMTUwMTU5MDBaMCExDzANBgNVBAsTBmNsaWVu\n"
            + "dDEOMAwGA1UEAxMFYWRtaW4wWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAAQcUNjP\n"
            + "ex3A16sJaxmc2y6EEDPS+8SvD3mkH8Uq6HkyA6QXtayA/BGGECBsv7M591YR/Mnr\n"
            + "aSDXDy4VAw+XZFFJo2wwajAOBgNVHQ8BAf8EBAMCB4AwDAYDVR0TAQH/BAIwADAd\n"
            + "BgNVHQ4EFgQU4vbgfjr26DwR3NYvvfQoaV4j2nUwKwYDVR0jBCQwIoAg1WVNU9mw\n"
            + "zPrJg9nsgqmd8XKrehq7f5QvG01aKIXmWvcwCgYIKoZIzj0EAwIDSAAwRQIhAIRr\n"
            + "RpJq1BpNEkByr1a/yZkx9IzQfKrs+KoCOgmpN2kkAiB9JTXirmt8cPyaDlvvojd4\n"
            + "6JSVYSWuxsL5uLd75k8UZQ==\n"
            + "-----END CERTIFICATE-----";

        PrivateKey pkey = BgxEncryptionUtil.parsePemPrivateKey(key, BgxEncryptionUtil.ECDSA);
        retrieved.setEnrollment(new BgxDefaultEnrollment(pkey, cert));
        repository.updateItem(retrieved);

        ChannelUser retrieved2 = repository.find(channelUser.getName(), channelUser.getMspId());
        assertEquals(retrieved.getEnrollmentSecret(), retrieved2.getEnrollmentSecret());
        assertEquals(retrieved.getEnrollment().getCert(), retrieved2.getEnrollment().getCert());
        assertEquals(retrieved.getEnrollment().getKey(), retrieved2.getEnrollment().getKey());
    }

}