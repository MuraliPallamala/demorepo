package com.ibm.au.bgx.couch.repository;

import static org.junit.Assert.*;

import com.ibm.au.bgx.BgxStatusResourceMock;
import com.ibm.au.bgx.model.pojo.crypto.CryptoKeyInfo;
import com.ibm.au.bgx.model.util.BasicBgxEncryptionUtil;
import java.util.UUID;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    CouchDbEncryptionKeyRepository.class,
    BgxStatusResourceMock.class
})
@TestPropertySource(locations = "classpath:application-test.properties")
public class CouchDbEncryptionKeyRepositoryTestIT {

    @Autowired
    CouchDbEncryptionKeyRepository repository;

    @Test
    public void getByOwnerId() throws Exception {

        String orgId = UUID.randomUUID().toString();

        CryptoKeyInfo keyInfo = new CryptoKeyInfo();
        keyInfo.setId(orgId);
        keyInfo.setOwnerId(orgId);
        keyInfo.setKeys(BasicBgxEncryptionUtil.generateKeyPair());
        repository.addItem(keyInfo);

        CryptoKeyInfo record = repository.getByOwnerId(orgId);
        assertNotNull(record);
        assertEquals(keyInfo.getKeys(), record.getKeys());
    }
}