/**
 *
 */
package com.ibm.au.bgx.couch;


/**
 * Class <b>CouchDbConnectionMetadata</b>. This class contains the useful information
 * that define a connection: url, database, username, and password. Instances of this
 * class are used by the {@link CouchDbConnectionManager} to minimise the number of
 * connections to <i>CouchDb</i> instances.
 *
 * @author Christian Vecchiola <christian.vecchola@au1.ibm.com>
 */
public class CouchDbConnectionMetadata {


    /**
     * A {@link String} constant that contains the default URL for a <i>CouchDb</i> instance.
     * This url points to the port 5984 of the localhost.
     */
    public static final String COUCHDB_DEFAULT_URL = "http://localhost:5984";


    /**
     * A {@link String} constant that contains the name of the parameter that is used to retrieve
     * the url specified by the user of the <i>CouchDb</i> instance.
     */
    public static final String COUCHDB_URL = "couchdb.url";
    /**
     * A {@link String} constant that contains the name of the parameter that is used to retrieve
     * the user name required to connect to the <i>CouchDb</i> instance. This is an optional parameter.
     */
    public static final String COUCHDB_USERNAME = "couchdb.username";
    /**
     * A {@link String} constant that contains the name of the parameter that is used to retrieve
     * the password required to connect to the <i>CouchDb</i> instance. This is an optional parameter.
     */
    public static final String COUCHDB_PASSWORD = "couchdb.password";
    /**
     * A {@link String} constant that contains the name of the parameter that is used to specify
     * the database in the <i>CouchDb</i> instance that the client needs to connect to.
     */
    public static final String COUCHDB_DATABASE = "couchdb.database";

    /**
     * A {@link String} representing the url to the <i>CouchDb<i> instance.
     */
    protected String url;
    /**
     * A {@link String} representing the name of the database referenced by the connection.
     */
    protected String database;
    /**
     * A {@link String} representing the username (if any) used to authenticate.
     */
    protected String username;
    /**
     * A {@link String} representined the password (if any) used to authenticate.
     */
    protected String password;
    
    protected Backoff backoff;

    /**
     * Initialises an instance of {@link CouchDbConnectionMetadata} with the givne parameters.
     *
     * @param url      a {@link String} representing the url to the <i>CouchDb</i> server hosting the database. It
     *                 can be {@literal null} or empty and in that case it is set to the default value {@link
     *                 CouchDbConnectionMetadata#COUCHDB_DEFAULT_URL}.
     * @param database a {@link String} representing the name of the database that the connection should give access
     *                 to. It cannot be {@literal null}.
     * @param username a {@link String} representing the username required to connect to the <i>CouchDb</i> instance.
     *                 It can be {@literal null}.
     * @param password a {@link String} representing the password required to connect to the <i>CouchDb</i> instance.
     *                 It can be {@literal null}.
     */
    public CouchDbConnectionMetadata(String url, String database, String username, String password) {

        if ((url == null) || (url.isEmpty() == true)) {

            this.url = CouchDbConnectionMetadata.COUCHDB_DEFAULT_URL;
        } else {

            this.url = url;
        }

        if (database == null) {

            throw new IllegalArgumentException("Parameter 'database' cannot be null.");
        }

        this.database = database;
        this.username = username;
        this.password = password;
    }
    
    /**
     * Sets the configuration for the backoff strategy when the client is issuing
     * too many requests to the server.
     * 
     * @param backoff	a {@link Backoff} instance that specifies the strategy for
     * 					retrying requests. It can be {@literal null}.
     */
    public void setBackoff(Backoff backoff) {
    	
    	this.backoff = backoff;
    }
    
    /**
     * Gets the configuration for the backoff strategy when the client is issuing
     * too many requests to the server.
     * 
     * @return	a {@link Backoff} instance that specifies the strategy for retrying 
     * 			requests. It can be {@literal null}.
     * 
     */
    public Backoff getBackoff() {
    	
    	return this.backoff;
    }

    /**
     * Gets a {@link String} representing the url (host and port) to the <i>CouchDb</i> instance
     * that defines the connection information.
     *
     * @return a {@link String}, it is never {@literal null}.
     */
    public String getUrl() {

        return this.url;
    }

    /**
     * Gets a {@link String} representing the name of the user that will be used to authenticate
     * against the <i>CouchDb</i> instance defined by this connection information.
     *
     * @return a {@link String}, it can be {@literal null} if no user credentials are required.
     */
    public String getUsername() {

        return this.username;
    }

    /**
     * Gets a {@link String} representing the password of the user that will be used to authenticate
     * against the <i>CouchDb</i> instance defined by this connection information.
     *
     * @return a {@link String}, it can be {@literal null} if no user credentials are required.
     */
    public String getPassword() {

        return this.password;
    }

    /**
     * Gets a {@link String} representing the name of the database references in the <i>CouchDb</i>
     * instance defined by this connection information.
     *
     * @return a {@link String}, it is never null.
     */
    public String getDatabase() {

        return this.database;
    }

    /**
     * Checks whether the current instance is equal to the given <i>obj</i>. The current instanc is
     * equal to <i>obj</i> if one of the following occurs:
     * <ul>
     * <li>the current instance and <i>obj</i> hold a refernce to the same object</li>
     * <li><i>obj</i> is of type {@link CouchDbMetadata} and <i>database</i>, <i>url</i>, <i>username</i>
     * and <i>password</i> are the same</li>
     * </ul>
     * 
     * @param obj	an instance that is provided to test for equality. 
     * 
     * @return	{@literal true} if the current instance is equal to <i>obj</i>, {@literal false}
     * 			otherwise.
     */
    @Override
    public boolean equals(Object obj) {
    	
    	if (this == obj) {
    		return true;
    	}
    	
        if (!(obj instanceof CouchDbConnectionMetadata)) {
            return false;
        }

        CouchDbConnectionMetadata ccmd = (CouchDbConnectionMetadata) obj;
        return ccmd.getDatabase().equals(this.database) &&
                ccmd.getUrl().equals(this.url) &&
                ccmd.getUsername().equals(this.username) &&
                ccmd.getPassword().equals(this.password);
    }

    /**
     * This function computes the hash of the four parameter passed to provide a unique identifier for the combination
     * of parameters. This is used to uniquely identify connection that because have the same parameters can be reused
     * across clients that require them.
     **/
    @Override
    public int hashCode() {

        return this.url.hashCode() +
               (this.username != null ? this.username.hashCode() : 0) +
               (this.password != null ? this.password.hashCode() : 0) +
               this.database.hashCode() + 
               (this.backoff != null ? this.backoff.hashCode() : 0);


    }

    /**
     * Provides a string representation of the {@link CouchDbConnectionMetadata} instance.
     *
     * @return a {@link String} in the following form:
     * <p>
     * [url: <i>url</i>, database: <i>database</i>, username: <i>username|&lt;null&gt;</i>, password: <i>********|&lt;null&gt;</i>]
     * </p>
     */
    @Override
    public String toString() {
    	
    	
    	return String.format("[url: %1$s, database: %2$s, username: %3$s, password: %4$s, backoff: %5$s]", 
    						 this.url, 
    						 this.database, 
    						 this.username == null ? "<null>" : this.username, 
    						 this.password == null ? "<null>" : "************",
    						 this.backoff == null ? "<null>" : this.backoff.toString());
    }


}
