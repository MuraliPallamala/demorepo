package com.ibm.au.bgx.couch.repository;

import com.ibm.au.bgx.couch.model.CouchDbGxPrefillRequest;
import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;
import com.ibm.au.bgx.model.repository.GxPrefillRequestRepository;
import org.ektorp.support.View;
import org.ektorp.support.Views;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * Class <b>CouchDbGxPrefillRequestRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link GxPrefillRequest} and implements the interface {@link GxPrefillRequestRepository}
 * thus allowing the use of a CouhcDb database as persistent storage for the web notifications in the solution.
 *
 * @author Dain Liffman <dainliff@au1.ibm.com>
 * @see GxPrefillRequestRepository
 * @see GxPrefillRequest
 */
@Repository
@Primary
@Views({
        @View(name = CouchDbGxPrefillRequestRepository.VIEW_BY_ORGID, map = "function(doc) { if(doc.cdbPrefillRequest && doc.content.visibleToOrgIds) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit(doc.content.visibleToOrgIds[i], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbGxPrefillRequestRepository.VIEW_BY_GXREQUESTID, map = "function(doc) { if(doc.cdbPrefillRequest && doc.content.gxRequestId) {" +
                "emit(doc.content.gxRequestId, doc._id)" +
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbGxPrefillRequestRepository.VIEW_BY_ORGID_GXREQUESTID, map = "function(doc) { if(doc.cdbPrefillRequest && doc.content.visibleToOrgIds && doc.content.gxRequestId) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit([doc.content.visibleToOrgIds[i], doc.content.gxRequestId], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        )
})
public class CouchDbGxPrefillRequestRepository extends AbstractCouchDbRepository<CouchDbGxPrefillRequest, GxPrefillRequest> implements GxPrefillRequestRepository {

    protected final static String PREFIX = "by";
    protected final static String SEPARATOR = "_";
    protected final static String ORG_ID = "orgId";
    protected final static String GX_REQUEST_ID = "gxRequestId";

    /**
     * A {@link String} constant that maps the name of the view allowing an application
     * client to retrieve the request by organisation identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected final static String VIEW_BY_ORGID = PREFIX + SEPARATOR + ORG_ID;

    /**
     * A {@link String} constant that maps the name of the view allowing an application
     * client to retrieve the request by guarantee identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */


    protected final static String VIEW_BY_GXREQUESTID = PREFIX + SEPARATOR + GX_REQUEST_ID;
    protected final static String VIEW_BY_ORGID_GXREQUESTID = VIEW_BY_ORGID + SEPARATOR + GX_REQUEST_ID;

    /**
     * Initialises an instance of {@link CouchDbGxPrefillRequestRepository}.
     */
    public CouchDbGxPrefillRequestRepository() {
        super(CouchDbGxPrefillRequest.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a
     * specific configuration value the default injected value is set to <i>
     * requests</i>.
     * </p>
     *
     * @param database a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.requests:requests}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<GxPrefillRequest> find(String orgId, String gxRequestId) {
        if (orgId == null && gxRequestId == null) {
            return getAll();
        }
        List<String> args = new ArrayList<>();
        String view = PREFIX;

        if (orgId != null) {
            args.add(orgId);
            view += SEPARATOR + ORG_ID;
        }
        if (gxRequestId != null) {
            args.add(gxRequestId);
            view += SEPARATOR + GX_REQUEST_ID;
        }

        List<CouchDbGxPrefillRequest> result;
        if (args.size() == 1) {
            result = this.proxy.getView(view, args.get(0));
        } else {
            result = this.proxy.getView(view, args.stream().toArray(Object[]::new));
        }

        return this.unwrap(result);

        // [CV] NOTE: we should not duplicate code, we have a utility method for it
        //
        // List<PrefillRequest> output = new ArrayList<>();
        // for (CouchDbGxPrefillRequest entry : result) {
        //    output.add(entry.getContent());
        // }
        // return output;
    }
}
