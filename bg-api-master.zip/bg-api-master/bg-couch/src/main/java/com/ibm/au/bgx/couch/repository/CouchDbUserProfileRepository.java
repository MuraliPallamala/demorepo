package com.ibm.au.bgx.couch.repository;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.couch.model.CouchDbUserProfile;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.repository.UserProfileRepository;

import org.ektorp.support.View;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * Class <b>CouchDbUserProfileRepository</b>. This class implements the {@link UserProfileRepository}
 * interface and provides the bindings for storing {@link UserProfile} instances in a CouchDb Database.
 * </p>
 * <p>
 * The class inherits most of its capabilities from the base class {@link AbstractCouchDbRepository}
 * by specialising with instances of {@link CouchDbUserProfile} and adding those capabilities that are
 * specific to the user profile repository.
 * </p>
 * 
 * @see UserProfile
 * @see UserProfileRepository
 * @see AbstractCouchDbRepository
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Repository
@Primary
public class CouchDbUserProfileRepository extends
    AbstractCouchDbRepository<CouchDbUserProfile, UserProfile> implements
    UserProfileRepository {

	/**
	 * A {@link String} containing the name of the view that allows retrieving
	 * user profiles via email and primary organisation identifier.
	 * 
	 * @see CouchDbUserProfileRepository#getByEmail(String, String)
	 */
    public static final String VIEW_BY_EMAIL = "by_email";

    /**
     * A {@link String} containing the name of the view that allows retrieving 
     * user profiles by their primary organisation identifier.
     * 
	 * @see CouchDbUserProfileRepository#getByPrimaryOrgId(String)
     */
    public static final String VIEW_BY_PRIMARY_ORG_ID = "by_primaryOrgId";

    /**
     * A {@link String} containing the name of the view that allows retrieving 
     * user profiles by their a given role within the organisation.
     * 
	 * @see CouchDbUserProfileRepository#getByOrgRole(String, String)
     */
    public static final String VIEW_BY_ORG_ROLE = "by_orgAndRole";

    public static final String VIEW_BY_ORG_ROLE_PRIMARY = "by_orgRolePrimary";

    /**
     * A {@link String} containing the name of the view that allows retrieving
     * a user by a given login key.
     * 
	 * @see CouchDbUserProfileRepository#getByKey(String)
     */
    public static final String VIEW_BY_KEY = "by_key";

    /**
     * A {@link String} containing the name of the view that allows retrieving
     * a user by a given api key.
     *
     * @see CouchDbUserProfileRepository#getByApiKey(String)
     */
    public static final String VIEW_BY_API_KEY = "by_apiKey";

    public static final String VIEW_BY_PRIMARY_ORG_ID_STATUS = "by_primaryOrgIdStatus";

    /**
     * Initialises an instance of the {@link CouchDbUserProfileRepository}.
     */
    public CouchDbUserProfileRepository() {
        super(CouchDbUserProfile.class);
    }

    /**
     * <p>
     * Sets the couchDb database name that is used as a backing storage for the
     * user profiles.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a 
     * specific configuration value the default injected value is set to <i>
     * user-profiles</i>.
     * </p>
     * 
     * @param database	a {@link String} containing the name of the database to 
     * 					connect to store/retrieve user profiles.
     */
    @Override
    @Value("${couchdb.database.userProfiles:user-profiles}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    /**
     * Retrieves the user profile that is matched by the given email and primary
     * organisation identifier. The method retrieves the database documents by
     * using the view {@link CouchDbUserProfileRepository#VIEW_BY_EMAIL}.
	 * 
	 * @param primaryOrgId		a {@link String} representing the unique identifier of
	 * 							the organisation the user belongs to.It cannot be an
	 * 							empty string or {@literal null}.
	 * @param email				a {@link String} representing the email of the user.
	 * 							It cannot be {@literal null} or an empty string.
	 * 
	 * @return	a {@link UserProfile} instance that matches the search criteria, or
	 * 			{@literal null} if there is no match.
	 * 
	 * @throws IllegalArgumentException if <i>primaryOrgId</i> or <i>email</i> are
	 * 									{@literal null} or an empty string.
	 * 
	 * @throws IllegalStateException	if there is more of one document returned
	 * 									from the database.
     */
    @Override
    @View(name = VIEW_BY_EMAIL, map = "function(doc) { if(doc.content && doc.content.primaryOrgId && doc.content.email && doc.content.status !== 'DELETED') {emit([doc.content.primaryOrgId, doc.content.email], doc._id)} }")
    public UserProfile getByEmail(String primaryOrgId, String email) {

        if (primaryOrgId == null || primaryOrgId.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'primaryOrgId' cannot be null or an empty string.");
        }

        if (email == null || email.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'email' cannot be null or an empty string.");
        }
        
        List<CouchDbUserProfile> cdbRequests = this.proxy.getView(CouchDbUserProfileRepository.VIEW_BY_EMAIL, primaryOrgId, email);

        
        return this.unwrapOne(cdbRequests, email);

    }

    /**
     * <p>
     * Retrieves the user profiles that belong to a specific organisation identified
     * by the given identifier. For any {@link UserProfile} instance returned in the
     * result set the following condition will be satisfied: {@link UserProfile#getPrimaryOrgId()}
     * is equal to <i>id</i>.
     * </p>
     * <p>
     * The method uses the view {@link CouchDbUserProfileRepository#VIEW_BY_PRIMARY_ORG_ID}
     * to retrieve the documents from the database.
     * </p>
     * 
     * @param orgId	a {@link String} representing the unique identifier of the organisation
     * 				the user belong to. It cannot be an empty string or {@literal null}.
     * 
     * @return	a {@link List} containing {@link UserProfile} instances mapping the
     * 			users belong to the organisation identified by <i>id</i>.
	 * 
	 * @throws 	IllegalArgumentException if <i>id</i> is {@literal null} or an empty string.
     * 
     */
    @Override
    @View(name = VIEW_BY_PRIMARY_ORG_ID, map = "function(doc) { if(doc.content && doc.content.primaryOrgId && doc.content.status !== 'DELETED') {emit(doc.content.primaryOrgId, doc._id)} }")
    public List<UserProfile> getByPrimaryOrgId(String orgId) {
    	
        if (orgId == null || orgId.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'orgId' cannot be null or an empty string.");
        }

        List<CouchDbUserProfile> cdbRequests = this.proxy.getView(CouchDbUserProfileRepository.VIEW_BY_PRIMARY_ORG_ID, orgId);
        
        return this.unwrap(cdbRequests);

    }
    /**
     * Retrieves the user profiles that belong to a given organisation and a have specific
     * role. The method uses the view {@link CouchDbUserProfileRepository#VIEW_BY_ORG_ROLE}
     * to retrieve the documents from the database.
     * 
     * @param orgId	a {@link String} representing the unique identifier of the organisation 
     * 				the user belong to. It cannot be an empty string or {@literal null}.
     * @param role	a {@link String} represnting the unique name of the role within the
     * 				organisation. It cannot be {@literal null} or an empty string.
	 * 
	 * @return	a {@link UserProfile} instance that matches the search criteria, or
	 * 			{@literal null} if there is no match.
	 * 
	 * @throws 	IllegalArgumentException if <i>orgId</i> or <i>email</i> are {@literal null}
	 * 									or an empty string.
     */
    @Override
    @View(name = VIEW_BY_ORG_ROLE,
        map ="function(doc) {\n"
            + "    if (doc.content && doc.content.userRoles && doc.content.status !== 'DELETED') {\n"
            + "      for (var orgId in doc.content.userRoles) {\n"
            + "        if (!doc.content.userRoles.hasOwnProperty(orgId)) continue;\n"
            + "        var roles = doc.content.userRoles[orgId];\n"
            + "        for (var index = 0; index < roles.length; index++) {\n"
            + "          emit([orgId, roles[index]], doc._id)\n"
            + "         } \n"
            + "      }\n"
            + "    }\n"
            + "}"
    )
    public List<UserProfile> getByOrgRole(String orgId, String role) {

        if (orgId == null || orgId.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'orgId' cannot be null or empty.");
        }

        if (role == null || role.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'role' cannot be null or empty.");
        }
        List<CouchDbUserProfile> cdbRecords = this.proxy.getView(VIEW_BY_ORG_ROLE, orgId, role);
        
        return this.unwrap(cdbRecords);

    }

    @Override
    @View(name = VIEW_BY_ORG_ROLE_PRIMARY,
            map ="function(doc) {\n"
                    + "    if (doc.content && doc.content.userRoles && doc.content.status !== 'DELETED') {\n"
                    + "      for (var orgId in doc.content.userRoles) {\n"
                    + "        if (!doc.content.userRoles.hasOwnProperty(orgId)) continue;\n"
                    + "        var roles = doc.content.userRoles[orgId];\n"
                    + "        for (var index = 0; index < roles.length; index++) {\n"
                    + "          emit([doc.content.primaryOrgId, orgId, roles[index]], doc._id)\n"
                    + "         } \n"
                    + "      }\n"
                    + "    }\n"
                    + "}"
    )
    public List<UserProfile> getByOrgRolePrimary(String primaryOrgId, String roleOrgId, String role) {
        return this.unwrap(this.proxy.getView(VIEW_BY_ORG_ROLE_PRIMARY, primaryOrgId, roleOrgId, role));
    }

    /**
     * Retrieves the user profile that is matched by the given login key.. The method 
     * retrieves the database documents by using the view {@link CouchDbUserProfileRepository#VIEW_BY_KEY}.
     * 
     * @param loginKey	a {@link String} representing the unique login key. It cannot be
     * 				{@literal null} or an empty string.
	 * 
	 * @return	a {@link UserProfile} instance that matches the search criterion, or
	 * 			{@literal null} if there is no match.
	 * 
	 * @throws IllegalArgumentException if <i>loginKey</i> is {@literal null} or an empty string.
	 * 
	 * @throws IllegalStateException	if there is more of one document returned
	 * 									from the database.
     */
    @Override
    @View(name = VIEW_BY_KEY, map = "function(doc) { if(doc.content.credentials.key && doc.content.status !== 'DELETED') {emit(doc.content.credentials.key, doc._id)} }")
    public UserProfile getByKey(String loginKey) {
        if (loginKey == null || loginKey.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'loginKey' cannot be null or an empty string.");
        }

        List<UserProfile> records = this.getFromView(VIEW_BY_KEY, loginKey, false);
        return this.getOne(records, loginKey);
    }


    /**
     * Retrieves the user profile that is matched by the given api key.. The method
     * retrieves the database documents by using the view {@link CouchDbUserProfileRepository#VIEW_BY_API_KEY}.
     *
     * @param apiKey a {@link String} representing the unique API key. It cannot be
     * 				{@literal null} or an empty string.
     *
     * @return	a {@link UserProfile} instance that matches the search criterion, or
     * 			{@literal null} if there is no match.
     *
     * @throws IllegalArgumentException if <i>apiKey</i> is {@literal null} or an empty string.
     *
     * @throws IllegalStateException	if there is more of one document returned
     * 									from the database.
     */
    @Override
    @View(name = VIEW_BY_API_KEY,
        map = "function(doc) {\n"
            + "    if (doc.content.apiKeys && doc.content.status !== 'DELETED') {\n"
            + "        for (var keyId in doc.content.apiKeys) {\n"
            + "          emit(doc.content.apiKeys[keyId].key, doc._id)\n"
            + "        }\n"
            + "    }\n"
            + "}"
    )
    public UserProfile getByApiKey(String apiKey) {
        if (apiKey == null || apiKey.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'apiKey' cannot be null or an empty string.");
        }

        List<UserProfile> records = this.getFromView(VIEW_BY_API_KEY, apiKey, false);
        
        return this.getOne(records, apiKey);
    }

    @Override
    @View(name = VIEW_BY_PRIMARY_ORG_ID_STATUS, map = "function(doc) { if (doc.content.primaryOrgId && doc.content.status) { emit([doc.content.primaryOrgId, doc.content.status], doc._id) } }")
    public List<UserProfile> getByPrimaryOrgIdAndStatus(String orgId, String status) {
        return this.unwrap(this.proxy.getView(VIEW_BY_PRIMARY_ORG_ID_STATUS, orgId, status));
    }
}
