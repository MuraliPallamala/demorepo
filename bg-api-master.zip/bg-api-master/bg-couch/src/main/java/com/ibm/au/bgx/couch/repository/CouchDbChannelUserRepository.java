package com.ibm.au.bgx.couch.repository;

import com.ibm.au.bgx.couch.model.CouchDbChannelUser;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.chain.BgxDefaultEnrollment;
import com.ibm.au.bgx.model.chain.ChannelUser;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.repository.ChannelUserRepository;
import com.ibm.au.bgx.model.util.BasicBgxEncryptionUtil;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import java.security.PrivateKey;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.ektorp.support.View;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

/**
 * Class <b>CouchChannelUserRepository</b>. This class extends {@link
 * com.ibm.au.bgx.couch.AbstractCouchDbService} and implements the capabilities defined in {@link
 * AbstractCouchDbRepository} for instances of type of {@link ChannelUser}. This is because the
 * latter does not belong to the inheritance tree defined by {@link com.ibm.au.bgx.model.Entity}.
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 * @see ChannelUser
 * @see ChannelUserRepository
 */
@Repository
@Primary
public class CouchDbChannelUserRepository
    extends AbstractEncryptedCouchDbRepository<CouchDbChannelUser, ChannelUser>
    implements ChannelUserRepository {

    /**
     * A {@link Logger} implementation that is used to record the messages that
     * are produced by the logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(CouchDbChannelUserRepository.class);

    // Default value will be overwritten with that in the properties
    @Value("${bgx.encryption.repository.channelUsers.enabled:false}")
    protected boolean enableEncryption;

    /**
     * A {@link String} constant containing the name of the view that enables to retrieve all the
     * users that are affiliated to a given organization domain name.
     */
    public static final String VIEW_BY_MSP_ID = "by_orgMspId";

    /**
     * A {@link String} constant containing the name of the view that enables to retrieve the
     * user that are associated to a given organization.
     */
    public static final String VIEW_BY_USERNAME_ORG_MSP = "by_usernameOrgIdMsp";

    /**
     * A {@link String} constant containing the name of the view that enables to retrieve all the
     * users that are affiliated to a given organization.
     */
    public static final String VIEW_BY_AFFILIATION = "by_affiliation";

    /**
     * Initialises an instance of {@link CouchDbChannelUserRepository}.
     */
    public CouchDbChannelUserRepository() {
        super(CouchDbChannelUser.class);
    }

    private String prepareUserId(String username, String mspId) {
        return String.format("%1$s@%2$s", username, mspId);
    }

    /**
     * Finds a user with the corresponding given <i>username</i> and <i>organization</i>. Since the
     * two attributes compose the unique identifier of the user, this method does generate the
     * corresponding unique identifier of the user, and then invokes the
     * {@link CouchDbChannelUserRepository#getItem(String)}.
     *
     * @param username a {@link String} representing the username of the user. It cannot be
     * {@literal null}.
     * @param mspId a {@link String} representing the MspId of the user. It cannot be {@literal
     * null}.
     * @return a {@link ChannelUser} that matches the given <i>username</i> and <i>
     * organization</i>, or {@literal null} if not found.
     * @throws IllegalArgumentException if <i>username></i> or <i>organization</i> is {@literal
     * null}.
     */
    @Override
    public ChannelUser find(String username, String mspId) {

        if (username == null) {
            throw new IllegalArgumentException("Parameter 'username' cannot be null.");
        }

        if (mspId == null) {
            throw new IllegalArgumentException("Parameter 'mspId' cannot be null.");
        }

        String id = this.prepareUserId(username, mspId);
        try {
            return this.getItem(id);
        } catch (DataNotFoundException noDocEx) {
            LOGGER.error(String.format("Could not find fabric user '%s'", id));
        }

        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_USERNAME_ORG_MSP,
        map =
            "function(doc) { if(doc.content.orgId && doc.content.name && doc.content.mspId) {emit([doc.content.name, doc.content.orgId, doc.content.mspId], "
                + "doc._id)} }")
    public ChannelUser findUserByOrgId(String username, String orgId, String mspId) {

        if (mspId == null) {
            throw new IllegalArgumentException("Parameter 'mspId' cannot be null.");
        }

        List<CouchDbChannelUser> cdbUsers = this.proxy
            .getView(CouchDbChannelUserRepository.VIEW_BY_USERNAME_ORG_MSP, username, orgId, mspId);

        return this.unwrapOne(cdbUsers, username);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_MSP_ID,
        map = "function(doc) { if(doc.content.mspId) {emit(doc.content.mspId, " + "doc._id)} }")
    public List<ChannelUser> findAllByMspId(String mspId) {

        if (mspId == null) {
            throw new IllegalArgumentException("Parameter 'mspId' cannot be null.");
        }
        List<CouchDbChannelUser> cdbUsers = this.proxy
            .getView(CouchDbChannelUserRepository.VIEW_BY_MSP_ID, mspId);

        return this.unwrap(cdbUsers);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_AFFILIATION,
        map = "function(doc) { if(doc.content.affiliation) {emit(doc.content.affiliation, doc._id)} }")
    public List<ChannelUser> findAllByAffiliation(String affiliation) {

        if (affiliation == null) {
            throw new IllegalArgumentException("Parameter 'affiliation' cannot be null.");
        }

        List<CouchDbChannelUser> cdbUsers = this.proxy
            .getView(CouchDbChannelUserRepository.VIEW_BY_AFFILIATION, affiliation);

        return this.unwrap(cdbUsers);

    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a
     * specific configuration value the default injected value is set to <i>
     * fabric-users</i>.
     * </p>
     *
     * @param database a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.organizationuser:fabric-users}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    @Override
    ChannelUser encrypt(final ChannelUser item) {

        if (!enableEncryption) {
            LOGGER.debug("Encryption is disabled for channel user repository");
            return item;
        }

        LOGGER.debug("Encrypting enrollment details of channel user {}",
            item.getId());

        // encrypt enrollment secret if it exists
        Map<String, String> encrypted = new HashMap<>();
        if (item.getEnrollmentSecret() != null) {
            encrypted.put(BgxConstants.META_ENROLLMENT_SECRET, BasicBgxEncryptionUtil
                .encrypt(item.getEnrollmentSecret(), encryptionPassword, encryptionSalt));
        }

        // encrypt enrollment if it exists
        if (item.getEnrollment() != null) {
            String encodedKey = BgxEncryptionUtil.toPem(item.getEnrollment().getKey());

            encrypted.put(BgxConstants.META_CERT, BasicBgxEncryptionUtil
                .encrypt(item.getEnrollment().getCert(), encryptionPassword, encryptionSalt));

            encrypted.put(BgxConstants.META_PRIVATE_KEY,
                BasicBgxEncryptionUtil.encrypt(encodedKey, encryptionPassword, encryptionSalt));

        }

        // set the encrypted fields
        ChannelUser cloned = this.clone(item);
        if (cloned.getMeta() == null) {
            cloned.setMeta(new HashMap<>());
        }

        cloned.getMeta().put(BgxConstants.META_RESTRICTED, encrypted);

        this.updateEncryptionVersion(cloned.getMeta());

        // force nullify
        cloned.setEnrollmentSecret(null);
        cloned.setEnrollment(null);

        return cloned;
    }

    @Override
    ChannelUser decrypt(final ChannelUser item) {

        if (item.getMeta() == null || !item.getMeta()
            .containsKey(BgxConstants.META_ENCRYPTION_VERSION)) {
            return item;
        }

        this.validateEncryptionVersion(item.getMeta());

        LOGGER.debug("Decrypting enrollment details of channel user {}",
            item.getId());

        // Create a clone and put back the enrollment secret
        ChannelUser cloned = this.clone(item);

        // decrypt enrollment secret
        @SuppressWarnings("unchecked")
		Map<String, String> encrypted = (Map<String,String>) item.getMeta().get(BgxConstants.META_RESTRICTED);
        if (encrypted.containsKey(BgxConstants.META_ENROLLMENT_SECRET)) {
            String enrollmentSecret = BasicBgxEncryptionUtil
                .decrypt(encrypted.get(BgxConstants.META_ENROLLMENT_SECRET), encryptionPassword,
                    encryptionSalt);

            cloned.setEnrollmentSecret(enrollmentSecret);
        }

        // decrypt the enrollment certificate and key
        if (encrypted.containsKey(BgxConstants.META_CERT) && encrypted.containsKey(BgxConstants.META_PRIVATE_KEY)) {

            String key = BasicBgxEncryptionUtil
                .decrypt(encrypted.get(BgxConstants.META_PRIVATE_KEY), encryptionPassword,
                    encryptionSalt);

            String cert = BasicBgxEncryptionUtil
                .decrypt(encrypted.get(BgxConstants.META_CERT), encryptionPassword, encryptionSalt);

            PrivateKey pkey = BasicBgxEncryptionUtil
                .parsePemPrivateKey(key, BgxEncryptionUtil.ECDSA);

            BgxDefaultEnrollment enrollment = new BgxDefaultEnrollment(pkey, cert);

            cloned.setEnrollment(enrollment);
        }

        return cloned;
    }

}
