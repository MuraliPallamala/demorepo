package com.ibm.au.bgx.couch.repository;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.ibm.au.bgx.couch.AbstractCouchDbService;
import com.ibm.au.bgx.couch.model.CouchDbEntity;
import com.ibm.au.bgx.model.exception.DataExistsException;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.repository.DefaultRepository;
import com.ibm.au.bgx.model.Entity;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;

import org.apache.commons.lang.StringUtils;
import org.ektorp.*;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.support.DesignDocument;
import org.ektorp.support.DesignDocumentFactory;
import org.ektorp.support.GenerateView;
import org.ektorp.support.StdDesignDocumentFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Class <b>AbstractCouchDbRepository</b> is a wrapper around CouchDb service It
 * initializes the connection to a <i>CouchDb</i> instance using a internal
 * CouchDbProxy class.
 * 
 * @see CouchDbEntity
 * @see AbstractCouchDbService
 * @see DefaultRepository
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public abstract class AbstractCouchDbRepository<Z extends CouchDbEntity<T>, T extends Entity>
        extends AbstractCouchDbService
        implements DefaultRepository<T> {

    /**
     * A {@link Logger} implementation that is used to record the messages that
     * are produced by the logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractCouchDbRepository.class);

    /**
     * A {@link Class} instance containing the type information about the
     * concrete type that has been used to specialize this generic type.
     */
    protected Class<Z> theType;

    /**
     * An instance of {@link CouchDbProxy} that has been configured to retrieve
     * and manage document of the type configured with the specialized
     * implementation of this generic type.
     */
    protected CouchDbProxy<Z> proxy;

    /**
     * A {@link String} representing the name of the database referenced by the connection.
     */
    protected String database;

    /**
     * Initializes an instance of {@link AbstractCouchDbRepository} with the
     * given type information.
     *
     * @param theType a {@link Class} instance containing the type information about
     *                the concrete type that has been used to specialize this
     *                generic type. It cannot be {@literal null}.
     * @throws IllegalArgumentException if <i>theType</i> is {@literal null}.
     */
    protected AbstractCouchDbRepository(Class<Z> theType) {
        if (theType == null) {
            throw new IllegalArgumentException("Parameter 'theType' cannot be null.");
        }
        this.theType = theType;
    }

    /**
     * This is the callback that specializes the behaviour of the
     * instance for binding with <i>CouchDb</i> based repository. The method
     * retrieves the connection parameters from the Environment
     * implementation and initialize the internal components required to access
     * <i>CouchDb</i>.
     *
     * @param connector a {@link CouchDbConnector} instance that represents the connectivity
     *                  to the database.
     */
    @Override
    protected void init(CouchDbConnector connector, boolean bInitViews) {

        // Note Creation of proxy will create the default views
        this.proxy = new CouchDbProxy<Z>(this.theType, connector);

        if (bInitViews) {

            // let the views generated for the sub classes
            DesignDocumentFactory designDocumentFactory = new StdDesignDocumentFactory();
            this.proxy.initViews(designDocumentFactory, this);

        }
    }
    
    /**
     * Gets the currently configured database for the repository.
     * 
     * @return a {@link String} containing the database name.
     */
    @Override
    protected String getDatabase() {
        return this.database;
    }

    /**
     * Returns the collection of items that are in the repository.
     *
     * @return a {@link List} implementation that contains the collection of
     * 		   instances store in the repository.
     */
    @Override
    public List<T> getAll() {
        List<Z> items = this.proxy.getAll();
        
        return this.unwrap(items);
    }

    /**
     * Returns the item that corresponds to the given <i>id</i>.
     *
     * @param id 	a {@link String} representing the unique identifier of the
     *           	item. It cannot be {@literal null}.
     *           
     * @return the instance that corresponds to <i>id</i> if found, {@literal null} otherwise.
     * 
     * @throws IllegalArgumentException  if <i>id</i> is {@literal null}.
     * @throws DataNotFoundException if <i>record</i> is not found.
     */
    @Override
    public T getItem(String id) {
    	
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'id' cannot be null or empty.");
        }
        

        Z doc = this.proxy.getItem(id);
        return this.unwrap(doc);
    }

    /**
     * Adds the given item to the repository.
     *
     * @param item 	the item to add. It cannot be {@literal null}.
     * 
     * @throws IllegalArgumentException if <i>item</i> is {@literal null} or an empty string.
     */
    @Override
    public T addItem(T item) {
    	
        if (item == null) {
            throw new IllegalArgumentException("Parameter 'item' cannot be null.");
        }

        try {
            // set createdAt if empty
            item.setCreatedAt(ZonedDateTime.now().toInstant());

            // TODO set createdBy

            Z doc = this.theType.newInstance();
            doc.setContent(item);

            // if id is not empty, use it. Otherwise, let CouchDb generate an ID
            if (item.getId() != null && !item.getId().isEmpty()) {
                doc.setId(item.getId());
            }

            this.proxy.add(doc);
            if (item.getId() == null || item.getId().isEmpty()) {
                item.setId(doc.getId());
            }

            Z saved = this.proxy.getItem(item.getId());
            if (saved == null) {
                throw new IllegalStateException(String.format("Could not retrieve saved item: %s", item.getId()));
            }

            if (saved.getContent().getId() == null || saved.getContent().getId().isEmpty()) {
                saved.getContent().setId(saved.getId());
                this.proxy.update(saved);
            }

            return this.getItem(saved.getId());

        } catch (ReflectiveOperationException e) {
        	
            throw new RuntimeException(String.format("Error instantiating object of type: %s ", this.theType), e);
        } catch (UpdateConflictException uce) {
            throw new DataExistsException(uce);
        }
    }

    /**
     * Updates the given item to the repository. The method updates the item in the repository
     * by looking up a document that has the same identifier and then replaces it with the given
     * item. It then returns the updated item by querying it by identifier and retrieving the
     * updated document from the database.
     *
     * @param item 	the item to update. It cannot be {@literal null}.
     * 
     * @return the updated item.
     * 
     * @throws IllegalArgumentException if <i>item</i> is {@literal null} or an empty string.
     * @throws IllegalStateException 	if <i>item</i> does not map to an existing user.
     */
    @Override
    public T updateItem(T item) {

        if (item == null || item.getId() == null || item.getId().isEmpty()) {
            throw new IllegalArgumentException( "Parameter 'item', and properties 'item:id', cannot be null or empty.");
        }

        try {
            // set updatedAt if empty
            item.setUpdatedAt(ZonedDateTime.now().toInstant());

            // TODO set updatedBy

            Z existing = this.proxy.getItem(item.getId());
            existing.setContent(item);
            this.proxy.update(existing);

            Z saved = this.proxy.getItem(item.getId());
            if (saved == null) {
                throw new IllegalStateException(String.format("Could not retrieve saved item: %s", item.getId()));
            }

            return this.getItem(saved.getId());
        } catch (UpdateConflictException uce) {
            throw new DataExistsException(uce);
        }
    }

    /**
     * Removes all the documents from the repository.
     */
    @Override
    public void removeAll() {
    	
        this.proxy.removeAll();
    }

    /**
     * Removes the given document from the repository.If the item is not present in the repository
     * the method terminates gracefully by not attempting to remove the document. 
     *
     * @param id the id of the item to remove. It cannot be {@literal null}.
     * @throws IllegalArgumentException if <i>id</i> is {@literal null} or an empty string.
     * @throws DataNotFoundException if <i>id</i> does not match any existing entity.
     */
    @Override
    public void removeItem(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'id' cannot be null or an empty string.");
        }
        Z item = this.proxy.getItem(id);
        if (item != null) {
            this.proxy.remove(item);
        }
    }

    /**
     * Helper method to create the endKey for range query with partial match. For
     * more details see:
     * <ul>
     * <li>http://mail-archives.apache.org/mod_mbox/couchdb-user/201010.mbox/%3C96704073-F087-4252-8E68-572899DA822F@gmail.com%3E</li>
     * <li>https://stackoverflow.com/questions/5585919/creating-unicode-character-from-its-number</li>
     * </ul>
     * 
     * @param startKey 	a {@link String} representing the start key value for the
     * 					partial match. It is expected to not to be {@literal null}.
     *
     * @return a {@link String} containing the partial match end key.
     * 
     * @throws IllegalArgumentException	if <i>startKey</i> is {@literal null}.
     */
    public String createPartialMatchEndKey(String startKey) {

    	if (startKey == null) {
    		
    		throw new IllegalArgumentException("Parameter 'key' cannot be null.");
    	}

        // last unicode character
        return startKey + Character.toString((char) 0x9999);
    }
    


    /**
     * Extracts the list of {@link Entity} instances from the execution of a view.
     *
     * @param viewName 		a {@link String} representing the name of the view to execute.
     * @param startKey 		a {@link String} representing the initial key to start from
     * 						when retrieving the user profiles. It can be {@literal null}.
     * 
     * @param prefixMatch 	a {@literal boolean} value indicating whether <i>startKey</i>
     * 						should be used as a prefix match as in SQL of `LIKE "<startKey>%">`
     * 						or not.
     * 
     * @return	a {@link List} containing the list of {@link Entity} instances matched
     * 			by the view.
     */
    protected List<T> getFromView(String viewName, String startKey, boolean prefixMatch) {

        List<Z> cdbRecords;

        if (!prefixMatch) {
            cdbRecords = this.proxy.getView(viewName, startKey);
        } else {
            String endKey = this.createPartialMatchEndKey(startKey);
            cdbRecords = this.proxy.getViewWithRange(viewName, startKey, endKey);
        }
        
        return this.unwrap(cdbRecords);

    }
    
    /**
     * This is a utility method that unwraps the items from their {@link CouchDbEntity}
     * containers and returns them as list.
     * 
     * @param items	a {@link List} containing a collection of {@link CouchDbEntity}
     * 				wrappers.
     * 
     * @return	a {@link List} implementation containing the wrapped {@link Entity}
     * 			specific classes.
     */
    protected List<T> unwrap(List<Z> items) {
    	
        List<T> casted = new ArrayList<>();
        for (Z item : items) {
            casted.add(this.unwrap(item));
        }
        return casted;
    }

    /**
     * This is a utility method that unwraps the items from their {@link CouchDbEntity}
     * containers and returns them as list.
     *
     * @param item	a {@link CouchDbEntity} wrapper
     *
     * @return	the wrapped {@link Entity} specific class.
     */
    protected T unwrap(Z item) {
        T content = item.getContent();
        content.setId(item.getId());
        return content;
    }

    /**
     * This is a utility method that is used to extract one item from the given list. The method first
     * checks that the list contains one or zero elements. If none of these conditions are met the method
     * throws a {@link IllegalStateException}. In case there is one element in the list, this is returned.
     * 
     * @param items 	a {@link List} containing the instance to extract.
     * @param key		a {@link String} that contains the unique identifier of the key that should
     * 					match the single instance if found. This is primarily used to provide an
     * 					informative message in the exception that is thrown.
     * 
     * @return	a {@link List} containing the list of unwrapped instances.
     */
    protected T getOne(List<T> items, String key) {
    	
		T item = null;
		
		if (items.size() == 1) {
		    item = items.get(0);
		}
		
		if (items.size() > 1) {
		    throw new IllegalStateException(String.format("Multiple records found same key: %s", key));
		}
		
		return item;
    }
    
    /**
     * This is a utility method that is used to unwrap one instance from the result set that
     * has been returned by CouchDb. This method first checks that the list contains only one
     * entity or it is empty, and if none of these conditions are met throws an {@link IllegalStateException}.
     * In case the list contains a single element, the value of {@link CouchDbEntity#getContent()}
     * for that element is returned.
     * 
     * @param items 	a {@link List} containing the {@link CouchDbEntity} instance to unwrap.
     * @param key		a {@link String} that contains the unique identifier of the key that should
     * 					match the single instance if found. This is primarily used to provide an
     * 					informative message in the exception that is thrown.
     * 
     * @return	the unwrapped instance.
     * 
     * @throws IllegalStateException	if 
     */
    protected T unwrapOne(List<Z> items, String key) {
    	
    	T unwrapped = null;
		
		if (items.size() == 1) {
			
			Z item = items.get(0);
			if (item != null) {
				unwrapped = this.unwrap(item);
			}
		}
		
		if (items.size() > 1) {
		    throw new IllegalStateException(String.format("Multiple records found same key: %s", key));
		}
		
		return unwrapped;
    }

    /**
     * Class <b>CouchDbProxy</b>. This class extends {@link CouchDbRepositorySupport} and
     * provides a simple extension to use the methods of {@link CouchDbRepositorySupport}
     * with the type that will specialize instances of the outer class.
     *
     * @author Christian Vecchiola
     */
    protected class CouchDbProxy<Y extends CouchDbEntity<T>> extends CouchDbRepositorySupport<Y> {
    	

        /**
         * A {@link Class} instance that keeps track of the type that specialize
         * this generic class.
         */
        protected Class<Y> theType;

        /**
         * Initializes an instance of {@link CouchDbProxy} with the given
         * connection and type information.
         *
         * @param type a {@link Class} instance containing the type information
         *             about the type that specializes the instances of this
         *             generic class. It cannot be {@literal null}.
         * @param db   a {@link CouchDbConnector} implementation that provides
         *             connection to a <i>CouchDb</i> database.
         */
        public CouchDbProxy(Class<Y> type, CouchDbConnector db) {
            super(type, db);
            this.theType = type;
            this.initStandardDesignDocument();
        }

        /**
         * Gets the list of all the documents contained in the database, which
         * match the type that has been configured for this instance.
         *
         * @return a {@link List} implementation that contains the documents in
         * <i>CouchDb</i> that match the type configured with this
         * instance.
         */
        @GenerateView
        @Override
        public List<Y> getAll() {
        	
            ViewQuery vq = this.createQuery("all").includeDocs(true).descending(true);
            
            this.logViewQuery(vq.getViewName(), null);
            return this.db.queryView(vq, this.theType);
        	
        }

        /**
         * Removes all the documents contained in the database, which match the
         * type that has been configured for this instance.
         */
        public void removeAll() {
            for (Y item : this.getAll()) {
                this.remove(item);
            }
        }

        /**
         * Gets the document that matches the given identifier.
         *
         * @param id a {@link String} representing the unique identifier of the
         *           document to retrieve. It is assumed to not to be
         *           {@literal null}.
         * @return the item matching the given <i>id</i> or {@literal null}.
         */
        public Y getItem(String id) {
            try {
                return this.db.get(this.theType, id);
            } catch (DocumentNotFoundException dne) {
                throw new DataNotFoundException(dne);
            }
        }

        /**
         * Returns the connection to the database that has been used by the
         * proxy.
         *
         * @return a {@link CouchDbConnector} implementation, which represents
         * the database connection configured with the instance.
         */
        public CouchDbConnector getDb() {
            return this.db;
        }

        /**
         * Returns the list of documents that match the given view.
         *
         * @param viewId a {@link String} representing the identifier of the view.
         * @param id     a {@link String} representing the unique key.
         * @return a {@link List} of documents that is retrieved by executing
         * the query defined by the view.
         */
        public List<Y> getView(String viewId, String id) {
        	
            this.logViewQuery(viewId,id);
            return this.queryView(viewId, id);
        }

        /**
         * Returns the list of documents that match the given view.
         *
         * @param viewId a {@link String} representing the identifier of the view.
         * @param keys   a list of values representing a unique complex key
         * @return a {@link List} of documents that is retrieved by executing
         * the query defined by the view.
         */
        public List<Y> getView(String viewId, Object... keys) {
            String params = StringUtils.join(keys, ",");
        	this.logViewQuery(viewId, params);
            return this.queryView(viewId, ComplexKey.of(keys));
        }

        /**
         * Returns the list of documents that match the given view.
         *
         * @param viewId a {@link String} representing the identifier of the view.
         * @return a {@link List} of documents that is retrieved by executing
         * the query defined by the view.
         */
        public List<Y> getView(String viewId) {
        	
        	this.logViewQuery(viewId, null);
            return this.queryView(viewId);
        }
        
        /**
         * Returns the list of documents that match the given view query. 
         * 
         * @param query 	a {@link ViewQuery} instance that contains the query to
         * 					execute to return the documents. It cannot be {@literal null}.
         * 
         * @return	a {@link List} of documents that matches the query passed as argument.
         */
        public List<Y> getView(ViewQuery query) {

        	this.logViewQuery(query.getViewName(), null);
        	return this.db.queryView(query, this.theType);
        }


        /**
         * Returns the list of documents that match the given view query.
         * Returns ViewResult instead of concrete type of document
         *
         * @param query 	a {@link ViewQuery} instance that contains the query to
         * 					execute to return the documents. It cannot be {@literal null}.
         *
         * @return	a {@link ViewResult} of documents that matches the query passed as argument.
         */
        public ViewResult getViewRaw(ViewQuery query) {

            this.logViewQuery(query.getViewName(), null);
            return this.db.queryView(query);
        }

        /**
         * Returns the list of documents that match the given view.
         *
         * @param viewId   a {@link String} representing the identifier of the view.
         * @param startKey an object representing the start key for a range search
         * @param endKey   an object representing the end key for a range search
         * @return a {@link List} of documents that is retrieved by executing
         * the query defined by the view.
         */
        public List<Y> getViewWithRange(String viewId, Object startKey, Object endKey) {

        	this.logViewQuery(viewId, String.format("%1$s, %2$s", startKey, endKey));
        	
            return this.db.queryView(createQuery(viewId).includeDocs(true).startKey(startKey).endKey(endKey), type);
        }

        public ViewQuery createQuery(String viewId) {
            return super.createQuery(viewId);
        }

        /**
         * Initialize views for the given object
         *
         * It is a helper method to generate views based on the @GenerateView
         * annotation Copied from CouchDbRepositorySupport<T> class, however we
         * allow passing an external object and DesignDocumentFactory
         */
        public void initViews(DesignDocumentFactory designDocumentFactory, Object obj) {
            this.initViewsInternal(0, designDocumentFactory, obj);
        }

        /**
         * Create views with a backoff operation if it fails first time
         *
         * Copied from CouchDbRepositorySupport<T> class, however we allow
         * passing an external object and DesignDocumentFactory
         */
        private void initViewsInternal(int invocations, DesignDocumentFactory designDocumentFactory, Object obj) {

            DesignDocument designDoc;

            if (this.db.contains(stdDesignDocumentId)) {
                designDoc = designDocumentFactory.getFromDatabase(this.db, stdDesignDocumentId);
            } else {
                designDoc = designDocumentFactory.newDesignDocumentInstance();
                designDoc.setId(stdDesignDocumentId);
            }

            // new views
            DesignDocument generated = designDocumentFactory.generateFrom(obj);

            boolean changed = designDoc.mergeWith(generated);
            if (LOGGER.isDebugEnabled()) {
                this.debugDesignDoc(designDoc);
            }

            if (changed) {
                LOGGER.debug("DesignDocument changed or new. Updating database");
                try {
                    this.db.update(designDoc);
                } catch (UpdateConflictException e) {
                    LOGGER.warn("Update conflict occurred when trying to update design document: {}", designDoc.getId());
                    if (invocations == 0) {
                        this.backOffDelay();
                        LOGGER.warn("retrying initView for design document: {}", designDoc.getId());
                        this.initViewsInternal(1, designDocumentFactory, obj);
                    }
                }
            } else {
                LOGGER.debug("DesignDocument was unchanged. Database was not updated.");
            }

        }

        /**
         * Wait a short while in order to prevent racing initializations from
         * other repositories.
         *
         * Copied from CouchDbRepositorySupport<T> class
         */
        protected void backOffDelay() {
            this.backOffDelay(new Random().nextInt(400));
        }
        
        /**
         * Wait a given amount of milliseconds. This method executes a {@link Thread#sleep(long)}
         * to pause the execution of the current thread for the given amount of milliseconds.
         * 
         * @param amountMillis	the number of milliseconds to wait.
         */
        protected void backOffDelay(long amountMillis) {
        	try {
                Thread.sleep(amountMillis);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            }
        }
        
        /**
         * This method is used to logs the invocation of any specific view for a given database.
         * The method uses the performance log marker to keep track of these events.
         * 
         * @param viewId	a {@link String} representing the unique identifier of the view. The
         * 					view name.
         * @param info		a {@link String} containing additional information about the view execution
         * 					such as its parameters.
         */
        protected void logViewQuery(String viewId, String info) {
        	
        	LOGGER.debug(BgxLogMarkers.PERFORMANCE, "QUERY: {}:{}[{}]", this.db.getDatabaseName(), viewId, info);
        	
        } 
    }

}
