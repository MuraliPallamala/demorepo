package com.ibm.au.bgx.couch.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ibm.au.bgx.model.pojo.audit.AuditEvent;

import org.ektorp.support.TypeDiscriminator;

/**
 * Class <b>CouchDbAuditEvent</b>. This a simple CouchDb POJO wrapper for 
 * the {@link AuditEvent} type.
 * 
 * @see CouchDbEntity 
 * @see AuditEvent
 * 
 * @author Peter Ilfrich <peter.ilfrich@au1.ibm.com>
 */
public class CouchDbAuditEvent extends CouchDbEntity<AuditEvent> {

	/**
	 * A {@link Long} value used to discriminate among different instances that
	 * have the same class name (but may not be the same) during serialization.
	 */
	private static final long serialVersionUID = 4153485660425548226L;

	/**
	 * A {@link String} field used as type discriminator for JSON documnt that
	 * should be mapped to instances of the defined type. A field annotated with
	 * the {@link TypeDiscriminator} annotation provides Ektorp with information
	 * on how to retrieve all the elements that are to be cast to a specific 
	 * type.
	 */
	@TypeDiscriminator
    @JsonProperty("cdbAuditEvent")
    private final String cdbAuditEvent = "AuditEvent";


}
