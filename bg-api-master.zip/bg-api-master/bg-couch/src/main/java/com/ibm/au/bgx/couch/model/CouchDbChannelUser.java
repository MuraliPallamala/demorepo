package com.ibm.au.bgx.couch.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.ibm.au.bgx.model.chain.ChannelUser;
import org.ektorp.support.TypeDiscriminator;

/**
 * Class <b>CouchDbChannelUser</b>. This class is a simple CouchDb POJO wrapper
 * for the {@link ChannelUser} type.
 * 
 * @see CouchDbEntity
 * @see ChannelUser
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
public class CouchDbChannelUser extends CouchDbEntity<ChannelUser> {

    /**
     * This is a {@literal long} value that uniquely identifies the instances
     * of this particular implementation of this class. This is to prevent that
     * instances that are serialized across JVMs that point to different definitions
     * of the same class are mixed together.
     */
    private static final long serialVersionUID = 6143311408815457012L;

	/**
	 * A {@link String} field used as type discriminator for JSON documnt that
	 * should be mapped to instances of the defined type. A field annotated with
	 * the {@link TypeDiscriminator} annotation provides Ektorp with information
	 * on how to retrieve all the elements that are to be cast to a specific 
	 * type.
	 */
    @TypeDiscriminator
    @JsonProperty("cdbChannelUser")
    private final String cdbChannelUser = "ChannelUser";
}
