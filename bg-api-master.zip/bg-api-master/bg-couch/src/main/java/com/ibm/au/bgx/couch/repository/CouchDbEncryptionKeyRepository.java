package com.ibm.au.bgx.couch.repository;

import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.util.BasicBgxEncryptionUtil;
import java.util.HashMap;
import java.util.List;

import java.util.Map.Entry;
import org.ektorp.support.View;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.ibm.au.bgx.couch.model.CouchDbCryptoKeyInfo;
import com.ibm.au.bgx.model.pojo.crypto.CryptoKeyInfo;
import com.ibm.au.bgx.model.repository.EncryptionKeyRepository;

/**
 * Class <b>CouchDbEncryptionKeyRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link CryptoKeyInfo} and implements the interface {@link EncryptionKeyRepository}
 * thus allowing the use of a CouhcDb database as persistent storage for the web notifications in the 
 * solution.
 * 
 * @see EncryptionKeyRepository
 * @see CryptoKeyInfo
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Repository
@Primary
public class CouchDbEncryptionKeyRepository 
		extends AbstractEncryptedCouchDbRepository<CouchDbCryptoKeyInfo, CryptoKeyInfo>
		implements EncryptionKeyRepository {

    private static final Logger LOGGER = LoggerFactory
        .getLogger(CouchDbEncryptionKeyRepository.class);

    // Default value will be overwritten with that in the properties
    @Value("${bgx.encryption.repository.cryptoKeys.enabled:false}")
    protected boolean enableEncryption;

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * encryption key by unique identifier of the owner.
	 * 
	 * @see CouchDbEncryptionKeyRepository#getByOwnerId(String)
	 */
    public static final String VIEW_BY_OWNER_ID = "by_ownerId";
    
    /**
     * Initialises an instance of {@link CouchDbEncryptionKeyRepository}.
     */
    public CouchDbEncryptionKeyRepository () {
        super(CouchDbCryptoKeyInfo.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a 
     * specific configuration value the default injected value is set to <i>
     * crypto-keys</i>.
     * </p>
     * 
     * @param database	a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.crypto.keys:crypto-keys}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    /**
     * {@inheritDoc}
     */
    @View(name = VIEW_BY_OWNER_ID,
        map = "function(doc) { if(doc.content.ownerId) {emit(doc.content.ownerId, doc._id)} }")
    public CryptoKeyInfo getByOwnerId(String ownerId) {
        if (ownerId == null) {
            throw new IllegalArgumentException("Parameter 'ownerId' cannot be null.");
        }

        List<CryptoKeyInfo> records = this.getFromView(VIEW_BY_OWNER_ID, ownerId, false);
        
        return this.getOne(records, ownerId);
    }

    @Override
    CryptoKeyInfo encrypt(final CryptoKeyInfo item) {

        if (!this.enableEncryption) {
            LOGGER.debug(BgxLogMarkers.DEV, "Encryption is disabled for crypto-keys repository");
            return item;
        }


        CryptoKeyInfo clone = this.clone(item);

        // encrypt everything in the keys map
        for (Entry<String, String> entry : clone.getKeys().entrySet()) {
            String encrypted = BasicBgxEncryptionUtil.encrypt(entry.getValue(), encryptionPassword, encryptionSalt);
            clone.getKeys().put(entry.getKey(), encrypted);
        }

        if (clone.getMeta() == null) {
            clone.setMeta(new HashMap<>());
        }

        this.updateEncryptionVersion(clone.getMeta());

        return clone;
    }

    @Override
    CryptoKeyInfo decrypt(final CryptoKeyInfo item) {

        if (item.getMeta() == null || !item.getMeta().containsKey(BgxConstants.META_ENCRYPTION_VERSION)) {
            return item;
        }

        this.validateEncryptionVersion(item.getMeta());


        CryptoKeyInfo clone = this.clone(item);
        for (Entry<String, String> entry : clone.getKeys().entrySet()) {
            String encrypted = entry.getValue().toString();
            String decrypted = BasicBgxEncryptionUtil.decrypt(encrypted, encryptionPassword, encryptionSalt);
            clone.getKeys().put(entry.getKey(), decrypted);
        }

        return clone;
    }
}
