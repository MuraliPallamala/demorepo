package com.ibm.au.bgx.couch.model;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ibm.au.bgx.model.pojo.Request;
import org.ektorp.support.TypeDiscriminator;

/**
 * Class <b>CouchDbRequest</b>. This a simple CouchDb POJO wrapper for 
 * the {@link Request} type.
 * 
 * @see CouchDbEntity 
 * @see Request
 * 
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class CouchDbRequest extends CouchDbEntity<Request> {
	
	/**
	 * A {@link Long} value used to discriminate among different instances that
	 * have the same class name (but may not be the same) during serialization.
	 */
	private static final long serialVersionUID = 3499739425161358192L;
	
	// TODO remove and replace getAll with inbuilt getAll operation (no custom view)
    
	/**
	 * A {@link String} field used as type discriminator for JSON documnt that
	 * should be mapped to instances of the defined type. A field annotated with
	 * the {@link TypeDiscriminator} annotation provides Ektorp with information
	 * on how to retrieve all the elements that are to be cast to a specific 
	 * type.
	 */
	@TypeDiscriminator
    private final String _id = "_id";


}
