package com.ibm.au.bgx.couch.model;

import com.ibm.au.bgx.model.Entity;

/**
 * Class <b>CouchDbEntity</b>. This class is the root class for all the classes that
 * are used to read from and write to POJOs into CouchDb. The class is designed to 
 * fit into the Ektorp object model without adding Ektorp-specific fields to the POJOs
 * that are persisted in CouchDb. To achive this each of the types inheriting from this
 * class will specialise the {@link CouchDbEntity#content} field with the actual type
 * that they act as a wrapper for.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
public class CouchDbEntity<T extends Entity> extends org.ektorp.support.CouchDbDocument {

    /**
     * A {@literal long} value that represents the unique identifier for this class
     * definition. This value it is used to match classes definitions across JVMs.
     */
    private static final long serialVersionUID = 6713773577926671654L;

    /**
     * The POJO that is being wrapped by instances of this class.
     */
    protected T content;

    /**
     * Gets the instance wrapped by this type.
     * 
     * @return	the instance.
     */
    public T getContent() {
        return this.content;
    }
    /**
     * Sets the instance that is wrapped by this type.
     * 
     * @param content	the instance.
     */
    public void setContent(T content) {
        this.content = content;
    }
}
