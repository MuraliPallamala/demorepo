package com.ibm.au.bgx.couch.repository;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.couch.model.CouchDbEntity;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.Entity;
import com.ibm.au.bgx.model.repository.DefaultRepository;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.io.IOException;
import java.time.Instant;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;

/**
 * This is used to encrypt and decrypt fields selectively. Child class needs to
 * implement the encrypt and decrypt abstract methods.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public abstract class AbstractEncryptedCouchDbRepository<Z extends CouchDbEntity<T>, T extends Entity>
        extends AbstractCouchDbRepository<Z, T>
        implements DefaultRepository<T> {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();


    // Default value will be overwritten with that in the properties
    @Value("${bgx.encryption.password:PROPERTY_NOT_SET}")
    protected String encryptionPassword;

    // Default value will be overwritten with that in the properties
    @Value("${bgx.encryption.salt:PROPERTY_NOT_SET}")
    protected String encryptionSalt;

    // Default value will be overwritten with that in the properties
    @Value("${bgx.encryption.version:v1.0.0}")
    protected String encryptionVersion;

    /**
     * Initializes an instance of {@link AbstractCouchDbRepository} with the
     * given type information.
     *
     * @param theType a {@link Class} instance containing the type information about the concrete type
     * that has been used to specialize this generic type. It cannot be {@literal null}.
     * @throws IllegalArgumentException if <i>theType</i> is {@literal null}.
     */
    protected AbstractEncryptedCouchDbRepository(Class<Z> theType) {
        super(theType);
    }

    /**
     * Encrypt the item as required.
     *
     * Child class may choose to encrypt all or encrypt fields selectively
     *
     * Also note, it is expected that the parameter item is not modified, and a clone is returned
     * with the encrypted fields
     *
     * @param item
     * @return
     */
    abstract T encrypt(final T item);

    /**
     * Decrypt the item
     *
     * Child class needs to decrypt following its encryption policy as implemented in the encrypt method
     *
     * Also note, it is expected that the parameter item is not modified, and a clone is returned
     * with the decrypted fields
     *
     * @param item
     * @return
     */
    abstract T decrypt(final T item);

    /**
     * Adds the given item to the repository.
     *
     * It optionally encrpts fields if required
     *
     * @param item 	the item to add. It cannot be {@literal null}.
     *
     * @throws IllegalArgumentException if <i>item</i> is {@literal null} or an empty string.
     */
    @Override
    public T addItem(T item) {
        return super.addItem(this.encrypt(item));
    }

    @Override
    public T updateItem(T item) {
        return super.updateItem(this.encrypt(item));
    }

    /**
     * This is a utility method that unwraps the items from their {@link CouchDbEntity}
     * containers and returns them as list.
     *
     * @param item	a {@link CouchDbEntity} wrapper
     *
     * @return	the wrapped {@link Entity} specific class.
     */
    protected T unwrap(Z item) {
        T content = item.getContent();
        content.setId(item.getId());
        return this.decrypt(content);
    }

    /**
     * We serialize and deserialize to make a deep copy
     *
     * @param item
     * @return
     */
    protected T clone(final T item) {
        try {
            return MAPPER.readValue(MAPPER.writeValueAsBytes(item), MAPPER.getTypeFactory().constructType(item.getClass()));
        } catch (IOException e) {
            throw new IllegalArgumentException(String.format("Could not clone item %s", item.getClass()), e);
        }
    }

    /**
     * Helper method to inject encryption version and time
     *
     * Child classes should always call this to inject the encryption version into item's meta data
     *
     * @param meta
     */
    protected void updateEncryptionVersion(Map<String, Object> meta) {

        if (meta == null) {
            throw new IllegalArgumentException("Meta is cannot be null");
        }

        meta.put(BgxConstants.META_ENCRYPTION_VERSION, encryptionVersion);
        meta.put(BgxConstants.META_ENCRYPTION_DATE, Instant.now());
    }

    /**
     * Validated that that item encryption version match with current version
     * @param meta
     */
    protected void validateEncryptionVersion(Map<String, Object> meta) {

        if (meta == null) {
            throw new IllegalArgumentException("Meta field cannot be null");
        }

        if (!meta.get(BgxConstants.META_ENCRYPTION_VERSION).equals(encryptionVersion)) {
            throw new IllegalArgumentException(
                String.format(
                    "Encryption version of the record does not match with current encryption version",
                    meta.get(BgxConstants.META_ENCRYPTION_VERSION), encryptionVersion));
        }
    }
}
