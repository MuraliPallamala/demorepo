package com.ibm.au.bgx.couch.model;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.fasterxml.jackson.annotation.JsonProperty;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;

import org.ektorp.support.TypeDiscriminator;

/**
 * Class <b>CouchDbApprovalModelFlowRequest</b>. This a simple CouchDb POJO wrapper for 
 * the {@link ApprovalModelFlowRequest} type.
 * 
 * @see CouchDbEntity 
 * @see ApprovalModelFlowRequest
 * 
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
public class CouchDbApprovalModelFlowRequest extends CouchDbEntity<ApprovalModelFlowRequest> {


	/**
	 * A {@link Long} value used to discriminate among different instances that
	 * have the same class name (but may not be the same) during serialization.
	 */
	private static final long serialVersionUID = -7411410900314428793L;

	/**
	 * A {@link String} field used as type discriminator for JSON documnt that
	 * should be mapped to instances of the defined type. A field annotated with
	 * the {@link TypeDiscriminator} annotation provides Ektorp with information
	 * on how to retrieve all the elements that are to be cast to a specific 
	 * type.
	 */
	@TypeDiscriminator
    @JsonProperty("cdbApprovalModelFlowRequest")
    private final String cdbApprovalModelFlowRequest = "ApprovalModelFlowRequest";



}
