package com.ibm.au.bgx.couch.repository;

import com.ibm.au.bgx.couch.model.CouchDbOrgChangeRequest;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import com.ibm.au.bgx.model.repository.OrgChangeRequestRepository;

import java.util.List;
import org.ektorp.support.View;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

/**
 * Class <b>CouchDbOrgChangeRequestRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link OrgChangeRequest} and implements the interface {@link OrgChangeRequestRepository} 
 * thus allowing the use of a CouhcDb database as persistent storage for the web notifications in the solution.
 * 
 * @see OrgChangeRequestRepository
 * @see OrgChangeRequest
 * 
 * @author Peter Ilfrich <peter.ilfrich@au1.ibm.com>
 * 
 */
@Repository
@Primary
public class CouchDbOrgChangeRequestRepository extends
    AbstractCouchDbRepository<CouchDbOrgChangeRequest, OrgChangeRequest> implements
    OrgChangeRequestRepository {


	/**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the organization change requests by organization identifier.
	 * 
	 * @see CouchDbOrgChangeRequestRepository#findByOrgId(String)
	 */
    private static final String VIEW_ORG_ID = "by_orgId";
    /**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the organization change requests by organization identifier 
	 * and status.
	 * 
	 * @see CouchDbOrgChangeRequestRepository#findByOrgIdAndStatus(String,Status)
	 */
    private static final String VIEW_ORG_ID_STATUS = "by_orgIdAndStatus";
    /**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the organization change requests by organization identifier,
	 * status and type.
	 * 
	 * @see CouchDbOrgChangeRequestRepository#findByOrgIdStatusAndType(String,String,String)
	 */
    private static final String VIEW_ORG_ID_STATUS_TYPE = "by_orgIdStatusAndType";
    /**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the organization change requests by organization identifier,
	 * status and type.
	 * 
	 * @see CouchDbOrgChangeRequestRepository#findByLinkOrgId(String,Status)
	 */
    private static final String VIEW_LINK_ORG_ID = "by_linkOrgId";
    /**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the organization change requests by organization status.
	 * 
	 * @see CouchDbOrgChangeRequestRepository#findByStatus(Status)
	 */
    private static final String VIEW_STATUS = "by_status";

    /**
     * Initialises an instance of {@link CouchDbOrgChangeRequestRepository}
     */
    public CouchDbOrgChangeRequestRepository() {
        super(CouchDbOrgChangeRequest.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a 
     * specific configuration value the default injected value is set to <i>
     * org-chamge-requests</i>.
     * </p>
     * 
     * @param database	a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.orgChange:org-change-requests}")
    protected void setDatabase(String database) {
        this.database = database;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_ORG_ID, map = "function(doc) { if(doc.content.orgId) {emit(doc.content.orgId, doc._id)} }")
    public List<OrgChangeRequest> findByOrgId(String orgId) {
        if (orgId == null) {
            throw new IllegalArgumentException("Parameter 'orgId' cannot be null.");
        }
        List<CouchDbOrgChangeRequest> requests = this.proxy.getView(CouchDbOrgChangeRequestRepository.VIEW_ORG_ID, orgId);
        
        return this.unwrap(requests);
        
        // [CV] NOTE: we don't need to replicate code, we have a utility method for it.
        //
        // List<OrgChangeRequest> orgRequests = new ArrayList<>();
        // for (CouchDbOrgChangeRequest request : requests) {
        //    orgRequests.add(request.getContent());
        // }
        //
        // return orgRequests;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_ORG_ID_STATUS, map = "function(doc) { if(doc.content.orgId && doc.content.status) {emit([doc.content.orgId, doc.content.status], doc._id)} }")
    public List<OrgChangeRequest> findByOrgIdAndStatus(String orgId, Status requestStatus) {

        if (orgId == null || requestStatus == null) {
            throw new IllegalArgumentException(
                "Parameter 'orgId' and 'requestStatus' cannot be null.");
        }
        
        List<CouchDbOrgChangeRequest> requests = this.proxy.getView(CouchDbOrgChangeRequestRepository.VIEW_ORG_ID_STATUS, orgId, requestStatus.value());
        
        return this.unwrap(requests);
        
        // [CV] NOTE: we don't need to replicate code, we have a utility method for it.
        //
        // List<OrgChangeRequest> orgRequests = new ArrayList<>();
        // for (CouchDbOrgChangeRequest request : requests) {
        //    orgRequests.add(request.getContent());
        // }
        //
        // return orgRequests;

    }



    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_LINK_ORG_ID, map = "function(doc) { if (['LINK_ORGANIZATION', 'UNLINK_ORGANIZATION'].indexOf(doc.content.requestType) != -1) { emit([doc.content.payload.id, doc.content.status], doc._id) } }")
    public List<OrgChangeRequest> findByLinkOrgId(String linkOrgId, Status requestStatus) {
        if (linkOrgId == null || requestStatus == null) {
            throw new IllegalArgumentException(
                "Parameter 'linkOrgId' and 'requestStatus' cannot be null.");
        }
        List<CouchDbOrgChangeRequest> requests = this.proxy.getView(CouchDbOrgChangeRequestRepository.VIEW_LINK_ORG_ID, linkOrgId, requestStatus.value());
        
        return this.unwrap(requests);
        
        // [CV] NOTE: we don't need to replicate code, we have a utility method for it.
        //
        // List<OrgChangeRequest> orgRequests = new ArrayList<>();
        // for (CouchDbOrgChangeRequest request : requests) {
        //    orgRequests.add(request.getContent());
        // }
        //
        // return orgRequests;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_STATUS, map = "function(doc) { if(doc.content.status) {emit(doc.content.status, doc._id)} }")
    public List<OrgChangeRequest> findByStatus(Status requestStatus) {

        if (requestStatus == null) {
            throw new IllegalArgumentException("Parameter 'requestStatus' cannot be null.");
        }
        List<CouchDbOrgChangeRequest> requests = this.proxy.getView(CouchDbOrgChangeRequestRepository.VIEW_STATUS, requestStatus.value());
        
        return this.unwrap(requests);
        
        // [CV] NOTE: we don't need to replicate code, we have a utility method for it.
        //
        // List<OrgChangeRequest> orgRequests = new ArrayList<>();
        // for (CouchDbOrgChangeRequest request : requests) {
        //    orgRequests.add(request.getContent());
        // }
        //
        // return orgRequests;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_ORG_ID_STATUS_TYPE, map = "function(doc) { if(doc.content.orgId && doc.content.status && doc.content.requestType) {emit([doc.content.orgId, doc.content.status, doc.content.requestType], doc._id)} }")
    public List<OrgChangeRequest> findByOrgIdStatusAndType(String orgId, String requestStatus, String requestType) {

        if (requestStatus == null || requestType == null) {
            throw new IllegalArgumentException(
                "Parameter 'requestStatus' and 'requestType' cannot be null.");
        }
        List<CouchDbOrgChangeRequest> requests = this.proxy.getView(CouchDbOrgChangeRequestRepository.VIEW_ORG_ID_STATUS_TYPE, orgId, requestStatus, requestType);
        
        return this.unwrap(requests);
        
        // [CV] NOTE: we don't need to replicate code, we have a utility method for it.
        //
        // List<OrgChangeRequest> orgRequests = new ArrayList<>();
        // for (CouchDbOrgChangeRequest request : requests) {
        //    orgRequests.add(request.getContent());
        // }
        //
        // return orgRequests;
    }
}
