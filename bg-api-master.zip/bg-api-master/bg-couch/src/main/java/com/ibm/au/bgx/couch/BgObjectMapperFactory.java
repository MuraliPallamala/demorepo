package com.ibm.au.bgx.couch;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.ektorp.CouchDbConnector;
import org.ektorp.impl.ObjectMapperFactory;
import org.ektorp.impl.jackson.EktorpJacksonModule;
import org.ektorp.util.Assert;


// This class is a workaround for https://github.com/helun/Ektorp/issues/69
// It is almost entirely copied from StdObjectMapperFactory

/**
 * Class <b>BgObjectMapperFactory</b>. Implements {@link ObjectMapperFactory} and provides
 * a modified implementation of the more commonly used class <i>StdObjectMapperFactory</i>
 * to provide a work-ardound of the <a href="https://github.com/helun/Ektorp/issues/69">
 * Ektorp issue 69</a>.
 *
 */
public class BgObjectMapperFactory implements ObjectMapperFactory {
	
	/**
	 * Nested instance of the {@link ObjectMapper} implementation used to deserialise the
	 * JSON documents into corresponding POJOs and vice versa.
	 */
    private ObjectMapper instance;
    
    /**
     * A {@literal boolean} flag indicating whether the dates should be serialised as time stamps
     * or not. The default value is {@literal false}.
     */
    private boolean writeDatesAsTimestamps = false;

    /**
     * Default constructor, initialises an instance of the {@link BgObjectMapperFactory}
     * class.
     */
    public BgObjectMapperFactory() {
    }

    /**
     * Creates an instance of the {@link ObjectMapper} and applies to it the default configuration. Given that this factory treats 
     * the mapper as a singleton, if there is already an existing instance of {@link ObjectMapper} this is returned rather than 
     * creating a new one. If there is no previous instance, the method creates an instance of {@link ObjectMapper} and configures 
     * it according to the implementation of {@link BgObjectMapperFactory#applyDefaultConfiguration(ObjectMapper)}.
     *
     * @return an {@link ObjectMapper} instance. This reference is guaranteed to not to be {@literal null}.
     */
    public synchronized ObjectMapper createObjectMapper() {
        ObjectMapper result = this.instance;
        if (result == null) {
            result = new ObjectMapper();
            this.applyDefaultConfiguration(result);
            this.instance = result;
        }

        return result;
    }

    /**
     * Creates an instance of {@link ObjectMapper} and configures it with an extension module that is used to process the CouchDb
     * annotation based on the given <i>connector</i>. This method relies on the logic of {@link BgObjectMapperFactory#createObjectMapper()}
     * which prepares an instance of {@link ObjectMapper} with the base configuration we need for each {@link ObjectMapper} instance
     * in this context.
     * 
     * @param connector 	an instance of {@link CouchDbConnector} which is used to connect to a CouchDb instance and retrieve or
     * 						submit CouchDb documents. This is expected to not to be {@literal null} and it is used to initialise the
     * 						{@link EktorpJacksonModule} that is added to the default mapper.
     * 
     * @return 	an instance of {@link ObjectMapper} that is extended with an instance of {@link EktorpJacksonModule} configured with
     * 			default mapper and the given <i>connector</i>. This reference is guaranteed to not to be {@literal null}.
     */
    public ObjectMapper createObjectMapper(CouchDbConnector connector) {
    	
    	// NOTE: this line is what actually implements the fix for issue 69. The default implementation of this method in the class
    	//       StdObjectMapperFactory does not rely on createObjectMapper() but invokes the constructor of ObjectMapper directly,
    	//       thus losing all the default configuration we would like to apply.
    	//
        ObjectMapper objectMapper = this.createObjectMapper(); 
        
        // The rest is the same.
        //
        objectMapper.registerModule(new EktorpJacksonModule(connector, objectMapper));
        return objectMapper;
    }

    /**
     * Sets the shared {@link ObjectMapper} instance to the given <i>om</i>. This method prevents the creation of a {@link ObjectMapper} 
     * instance with the default configuration as specified by {@link BgObjectMapperFactory#applyDefaultConfiguration(ObjectMapper)} and
     * sets the default mapper to use.
     * 
     * @param om	an instance of {@link ObjectMapper} to be used as default mapper for the serialisation/deserialisation of POJOs to 
     * 				and from JSON documents. This cannot be {@literal null}.
     * 
     * @throws NullPointerException	if <i>om</i> is {@literal null}.
     */
    public synchronized void setObjectMapper(ObjectMapper om) {
        Assert.notNull(om, "ObjectMapper may not be null");
        this.instance = om;
    }

    /**
     * Configures the serialisation behaviour of dates.	
     * 
     * @param writeDatesAsTimestamps	a {@literal boolean} value indicating the intended serialisation behaviour. When {@literal true}
     * 									{@link java.util.Date} objects will be serialised as timestamps.
     */
    public void setWriteDatesAsTimestamps(boolean writeDatesAsTimestamps) {
        this.writeDatesAsTimestamps = writeDatesAsTimestamps;
    }

    /**
     * Applies the default configuration to the given mapper <i>om</i>. This method configures the serialisation feature 
     * {@link SerializationFeature#WRITE_DATES_AS_TIMESTAMPS} as specified by the corresponding method attribute {@link 
     * BgObjectMapperFactory#writeDatesAsTimestamps} and instructs the mapper to serialise only those attributes that are
     * not {@literal null}.
     * 
     * @param om	an instance of {@link ObjectMapper} that is the targer of the configuration applied by this method.
     * 				It is expected to not to be {@literal null}.
     */
    protected void applyDefaultConfiguration(ObjectMapper om) {
        om.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, this.writeDatesAsTimestamps);
        om.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }
}
