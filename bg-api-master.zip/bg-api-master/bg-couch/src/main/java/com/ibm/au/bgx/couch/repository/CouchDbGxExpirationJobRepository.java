package com.ibm.au.bgx.couch.repository;

import com.ibm.au.bgx.couch.model.CouchDbGxExpirationJob;
import com.ibm.au.bgx.model.pojo.task.GxExpirationJob;
import com.ibm.au.bgx.model.repository.GxExpirationJobRepository;

import org.ektorp.support.View;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Peter Ilfrich
 */
@Repository
@Primary
public class CouchDbGxExpirationJobRepository extends AbstractCouchDbRepository<CouchDbGxExpirationJob, GxExpirationJob> implements GxExpirationJobRepository {

    private static final String VIEW_LATEST = "by_latest";
    private static final Logger LOGGER = LoggerFactory.getLogger(CouchDbGxExpirationJobRepository.class);

    public CouchDbGxExpirationJobRepository() {
        super(CouchDbGxExpirationJob.class);
    }

    @Override
    @Value("${couchdb.database.gxexpirations:gx-expiration-jobs}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    @Override
    @View(name = VIEW_LATEST, map = "function(doc) { if (doc.content.status === 'EMAILS_PROCESSED' && doc.content.expiredGuarantees != null && doc.content.expiredGuarantees.length > 0) { emit(doc._id, doc._id) } }")
    public GxExpirationJob findLatest() {
        List<GxExpirationJob> result = this.unwrap(this.proxy.getView(VIEW_LATEST));
        if (result.isEmpty()) {
            return null;
        }

        if (result.size() > 1) {
            LOGGER.error("Found multiple GxExpirationJobs that need processing. Only returning the first: {}", result.get(0).getId());
        }

        return result.get(0);
    }
}
