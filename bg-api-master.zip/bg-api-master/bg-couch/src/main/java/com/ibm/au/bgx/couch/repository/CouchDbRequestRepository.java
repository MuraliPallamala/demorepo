package com.ibm.au.bgx.couch.repository;


import com.ibm.au.bgx.couch.model.CouchDbRequest;
import com.ibm.au.bgx.model.pojo.Request;
import com.ibm.au.bgx.model.repository.RequestRepository;
import org.ektorp.support.View;
import org.ektorp.support.Views;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

/**
 * Class <b>CouchDbRequestRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link Request} and implements the interface {@link RequestRepository} thus
 * allowing the use of a CouhcDb database as persistent storage for the web notifications in the solution.
 *
 * @author Dain Liffman <dainliff@au1.ibm.com>
 * @see RequestRepository
 * @see Request
 */
@Repository
@Primary
@Views({
        @View(name = CouchDbRequestRepository.VIEW_BY_ORGID, map = "function(doc) { if(doc.content.visibleToOrgIds) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit(doc.content.visibleToOrgIds[i], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbRequestRepository.VIEW_BY_GUARANTEEID, map = "function(doc) { if(doc.content.guaranteeId) {" +
                "emit(doc.content.guaranteeId, doc._id)" +
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbRequestRepository.VIEW_BY_STATUS, map = "function(doc) { if(doc.content.status) {" +
                "emit(doc.content.status, doc._id)" +
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbRequestRepository.VIEW_BY_ORGID_GUARANTEEID, map = "function(doc) { if(doc.content.visibleToOrgIds && doc.content.guaranteeId) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit([doc.content.visibleToOrgIds[i], doc.content.guaranteeId], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbRequestRepository.VIEW_BY_ORGID_STATUS, map = "function(doc) { if(doc.content.visibleToOrgIds && doc.content.status) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit([doc.content.visibleToOrgIds[i], doc.content.status], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbRequestRepository.VIEW_BY_GUARANTEEID_STATUS, map = "function(doc) { if(doc.content.guaranteeId && doc.content.status) {" +
                "emit([doc.content.guaranteeId, doc.content.status], doc._id)" +
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbRequestRepository.VIEW_BY_ORGID_GUARANTEEID_STATUS, map = "function(doc) { if(doc.content.visibleToOrgIds && doc.content.guaranteeId && doc.content.status) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit([doc.content.visibleToOrgIds[i], doc.content.guaranteeId, doc.content.status], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
})
public class CouchDbRequestRepository extends AbstractCouchDbRepository<CouchDbRequest, Request> implements RequestRepository {
    protected static final String PREFIX = "by";
    protected static final String SEPARATOR = "_";
    protected static final String ORG_ID = "orgId";
    protected static final String GUARANTEE_ID = "guaranteeId";
    protected static final String STATUS = "status";

    /**
     * A {@link String} constant that maps the name of the view allowing an application
     * client to retrieve the request by organisation identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected static final String VIEW_BY_ORGID = PREFIX + SEPARATOR + ORG_ID;

    /**
     * A {@link String} constant that maps the name of the view allowing an application
     * client to retrieve the request by guarantee identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected static final String VIEW_BY_GUARANTEEID = PREFIX + SEPARATOR + GUARANTEE_ID;
    protected static final String VIEW_BY_STATUS = PREFIX + SEPARATOR + STATUS;

    /**
     * A {@link String} constant that maps the name of the view allowing an application
     * client to retrieve the request by organisation identifier and guarantee identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected static final String VIEW_BY_ORGID_GUARANTEEID = VIEW_BY_ORGID + SEPARATOR + GUARANTEE_ID;
    protected static final String VIEW_BY_ORGID_STATUS = VIEW_BY_ORGID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_GUARANTEEID_STATUS = VIEW_BY_GUARANTEEID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_ORGID_GUARANTEEID_STATUS = VIEW_BY_ORGID_GUARANTEEID + SEPARATOR + STATUS;


    /**
     * Initialises an instance of {@link CouchDbRequestRepository}.
     */
    public CouchDbRequestRepository() {
        super(CouchDbRequest.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a
     * specific configuration value the default injected value is set to <i>
     * requests</i>.
     * </p>
     *
     * @param database a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.requests:requests}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Request> find(String orgId, String guaranteeId, String status) {
        if (orgId == null && guaranteeId == null && status == null) {
            return getAll();
        }
        List<String> args = new ArrayList<>();
        String view = PREFIX;
        if (orgId != null) {
            args.add(orgId);
            view += SEPARATOR + ORG_ID;
        }
        if (guaranteeId != null) {
            args.add(guaranteeId);
            view += SEPARATOR + GUARANTEE_ID;
        }
        if (status != null) {
            args.add(status);
            view += SEPARATOR + STATUS;
        }

        List<CouchDbRequest> result;
        if (args.size() == 1) {
            result = this.proxy.getView(view, args.get(0));
        } else {
            result = this.proxy.getView(view, args.stream().toArray(Object[]::new));
        }

        return this.unwrap(result);

        // [CV] NOTE: we should not duplicate code, we have a method for it.
        //
        // List<Request> output = new ArrayList<>();
        // for (CouchDbRequest entry : result) {
        //    output.add(entry.getContent());
        // }
        // return output;
    }


}
