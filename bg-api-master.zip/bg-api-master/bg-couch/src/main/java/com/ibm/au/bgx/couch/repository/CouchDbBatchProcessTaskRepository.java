package com.ibm.au.bgx.couch.repository;

import java.util.List;

import org.ektorp.support.View;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.ibm.au.bgx.couch.model.CouchDbBatchProcessTask;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask.Status;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask.Type;
import com.ibm.au.bgx.model.repository.BatchProcessTaskRepository;

/**
 * Class <b>CouchDbBatchProcessTaskRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link BatchProcessTask} and implements the interface {@link BatchProcessTaskRepository}
 * thus allowing the use of a CouhcDb database as persistent storage for the web notifications in the solution.
 * 
 * @see BatchProcessTaskRepository
 * @see BatchProcessTask
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Repository
@Primary
public class CouchDbBatchProcessTaskRepository extends
    AbstractCouchDbRepository<CouchDbBatchProcessTask, BatchProcessTask> implements
    BatchProcessTaskRepository {

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * batch process tasks by type and status.
	 * 
	 * @see CouchDbBatchProcessTaskRepository#getByTypeAndStatus(Type,Status)
	 */
    private static final String VIEW_BY_TYPE_STATUS = "by_processTypeAndStatus";

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * batch process tasks by organisation identifier.
	 * 
	 * @see CouchDbBatchProcessTaskRepository#getByOrgId(String)
	 */
    private static final String VIEW_BY_ORG = "by_orgId";

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * batch process tasks by user identifier.
	 * 
	 * @see CouchDbBatchProcessTaskRepository#getByUserId(String, String)
	 */
    private static final String VIEW_BY_USER = "by_userId";
    
    /**
     * Initialises an instance of {@link CouchDbBatchProcessTaskRepository}.
     */
    public CouchDbBatchProcessTaskRepository() {
        super(CouchDbBatchProcessTask.class);
    }
    
    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a 
     * specific configuration value the default injected value is set to <i>
     * batch-process-tasks</i>.
     * </p>
     * 
     * @param database	a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.batchprocessconfig:batch-process-tasks}")
    protected void setDatabase(String database) {
        this.database = database;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_USER, map = "function(doc) { if (doc.content.orgId && doc.content.userId) { emit([doc.content.orgId, doc.content.userId], doc._id) } }")
    public List<BatchProcessTask> findByUserId(String orgId, String userId) {

        List<CouchDbBatchProcessTask> result = this.proxy.getView(VIEW_BY_USER, orgId, userId);

        return this.unwrap(result);
        
        // [CV] NOTE: we don't need to replicate code, we do have an utility method for this.
        //
        // List<BatchProcessTask> output = new ArrayList<>();
        // for (CouchDbBatchProcessTask entry : result) {
        //    output.add(entry.getContent());
        // }
        //
        // return output;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_ORG, map = "function(doc) { if (doc.content.orgId) { emit([doc.content.orgId], doc._id) } }")
    public List<BatchProcessTask> findByOrgId(String orgId) {

        List<CouchDbBatchProcessTask> result = this.proxy.getView(VIEW_BY_ORG, orgId);
        
        return this.unwrap(result);
        
        // [CV] NOTE: we don't need to replicate code, we do have an utility method for this.
        //
        // List<BatchProcessTask> output = new ArrayList<>();
        // for (CouchDbBatchProcessTask entry : result) {
        //    output.add(entry.getContent());
        // }
        //
        // return output;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_TYPE_STATUS, map = "function(doc) { if (doc.content.type) { emit([doc.content.type, doc.content.status], doc._id) } }")
    public List<BatchProcessTask> findByTypeAndStatus(Type type, Status status) {

        List<CouchDbBatchProcessTask> result = this.proxy.getView(VIEW_BY_TYPE_STATUS, type, status);
        
        return this.unwrap(result);
        
        // [CV] NOTE: we don't need to replicate code, we do have an utility method for this.
        //
        // List<BatchProcessTask> output = new ArrayList<>();
        // for (CouchDbBatchProcessTask entry : result) {
        //    output.add(entry.getContent());
        // }
        //
        // return output;
    }
}
