package com.ibm.au.bgx.couch;

/**
 * <p>
 * Class <b>StdBackoff</b>. Default implementation of {@link Backoff}. This class
 * allows for modelling no-wait, linear, and exponential backoff algorithms.
 * </p>
 * <p>
 * A {@link StdBackoff} instance is controlled by three parameters: 
 * <ul>
 * <li>the number of retries it will attempt</li>
 * <li>the initial delay it will wait</li>
 * <li>the multiplier used to increase the delay at each attempt</li>
 * </ul>
 * A linear backoff has a multiplier of one, while an exponential backoff has a
 * multiplier of two.
 * </p>
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class StdBackoff extends Backoff{
	
	/**
	 * a {@literal long} defining the initial number of milliseconds
	 * to wait before attempting another retry. This number cannot be
	 * negative or zero.
	 */
	protected long initialDelay = 500;
	/**
	 * A {@literal int} representing the multiplying factor applied to the
	 * initial delay after any retry. This number canont be negative or
	 * zero.
	 */
	protected int multiplier = 1;
	

	/**
	 * Initialises an instance of {@link StdBackoff} with the given parameters.
	 * 
	 * @param initialDelay	a {@literal long} value defining the initial number of
	 * 						milliseconds to wait before another attempt. This parameter
	 * 						cannot be a negative number of zero.
	 * @param retries		a {@literal int} value defining the number of attempts
	 * 						to make before the backoff is ceased. This parameter cannot
	 * 						be a negative number.
	 * @param multiplier	a {@literal int} value defining the multiplying factor to 
	 * 						apply to the delay before any subsequent attempt. To implement
	 * 						a linear backoff set this value to 1, for an exponential backoff
	 * 						set this value to 2.
	 * 
	 * @throws IllegalArgumentException	if one of the following conditions occurs:
	 * 									<ul>
	 * 									<li><i>delay</i> is zero or a negative number</li>
	 * 									<li><i>retry</i> is a negative number</li>
	 * 									<li><i>multiplier</i> is zero or a negative number</li>
	 * 									</ul>
	 */
	public StdBackoff(long initialDelay, int retries, int multiplier) {
		super(retries);
		
		if (multiplier < 1) {
			throw new IllegalArgumentException("Parameter 'multiplier' must be positive number.");
		}
		
		if (initialDelay < 1) {
			throw new IllegalArgumentException("Paramter 'initialDelay' must be a positive number.");
		}
		
		this.initialDelay = initialDelay;
		this.multiplier = multiplier;
	
	}
	
	/**
	 * Returns the value of the initial configured delay.
	 * 
	 * @return the initial value of the delay. This number is never zero.
	 */
	public long initialDelay() {
		
		return this.initialDelay;
	}
	
	/**
	 * Gets the value of the configured multiplier.
	 * 
	 * @return	a {@literal int} value representing the value of the configured
	 * 			multiplier.
	 */
	public int getMultiplier() {
		return this.multiplier;
	}
	

	/**
	 * Creates an exponential backoff with initial delay set to <i>delay</i> and 
	 * number of retries set to <i>retries</i>. This method internally invokes
	 * {@link StdBackoff#StdBackoff(long, int, int)} by passing the first two arguments
	 * and setting the third parameter to 2.
	 * 
	 * @param delay		a {@literal long} defining the initial delay in terms of 
	 * 					milliseconds. This argument cannot be 0 or a negative number.
	 * @param retries	a {@literal int} defining the number of retries. This argument
	 * 					cannot be a negative number.
	 * 
	 * @return	a {@link StdBackoff} instance whose value of {@link StdBackoff#getDelay()} is
	 * 			set to <i>delay</i>, value of {@link StdBackoff#getRetries()} is set to
	 * 			<i>retries</i>, and value of {@link StdBackoff#getMultiplier()} is set to
	 * 			2.
	 * 
	 * @throws IllegalArgumentException	if one of the following conditions occurs:
	 * 									<ul>
	 * 									<li><i>delay</i> is zero or a negative number</li>
	 * 									<li><i>retry</i> is a negative number</li>
	 * 									</ul>
	 */
	public static StdBackoff exponential(long delay, int retries) {
		return new StdBackoff(delay, retries, 2);
	}

	/**
	 * Creates a linear backoff with initial delay set to <i>delay</i> and number
	 * of retries set to <i>retries</i>. This method internally invokes {@link 
	 * StdBackoff#StdBackoff(long, int, int)} by passing the first two arguments and 
	 * setting the third parameter to 2.
	 * 
	 * @param delay		a {@literal long} defining the initial delay in terms of 
	 * 					milliseconds. This argument cannot be 0 or a negative number.
	 * @param retries	a {@literal int} defining the number of retries. This argument
	 * 					cannot be a negative number.
	 * 
	 * @return	a {@link StdBackoff} instance whose value of {@link StdBackoff#getDelay()} is
	 * 			set to <i>delay</i>, value of {@link StdBackoff#getRetries()} is set to
	 * 			<i>retries</i>, and value of {@link  StdBackoff#getMultiplier()} is set to
	 * 			1.
	 * 
	 * @throws IllegalArgumentException	if one of the following conditions occurs:
	 * 									<ul>
	 * 									<li><i>delay</i> is zero or a negative number</li>
	 * 									<li><i>retry</i> is a negative number</li>
	 * 									</ul>
	 */
	public static StdBackoff linear(long delay, int retries) {
		
		return new StdBackoff(delay, retries, 1);
	}
	/**
	 * Creates a null backoff that does not make any attempt. This is equivalent to call
	 * {@link StdBackoff#StdBackoff(long,int, int)} with the second parameter set to 0.
	 * 
	 * @return	a {@link StdBackoff} instance whose value of {@link StdBackoff#getDelay()} is
	 * 			set to <i>1</i>, value of {@link StdBackoff#getRetries()} is set to
	 * 			<i>0</i>, and value of {@link StdBackoff#getMultiplier()} is set to 1.
	 */
	public static StdBackoff none() {
		return new StdBackoff(1, 0, 1);
	}
	
	/**
	 * Returns a {@link String} representation of the instance.
	 * 
	 * @return  a {@link String} containing the information about the initial delay, 
	 * 			the multiplier, attempts and configured retries.
	 */
	@Override
	public String toString() {
		
		return String.format("[%1$d x %2$d, %3$d/%4$d]", this.initialDelay, this.multiplier, this.attempts, this.retries);
	}
	
	/**
	 * Checks whether the current instance is equal to the given instance <i>other</i>.
	 * 
	 * @param other		an object that is passed for comparison test. This object is 
	 * 					expected to be non {@literal null} and of type {@link StdBackoff}.
	 * 
	 * @return 	{@literal true} if <i>other</i> is a non {@literal null} instance of
	 * 			{@link StdBackoff} and the values of {@link StdBackoff#getAttempts()}, 
	 * 			{@link StdBackoff#getRetries()}, {@link StdBackoff#getInitialDelay()} 
	 * 			and {@link StdBackoff#getMultiplier()} match.
	 */
	@Override
	public boolean equals(Object other) {
		
		if (other instanceof StdBackoff) {
			
			StdBackoff b = (StdBackoff) other;
			return this.initialDelay == b.delay && 
				   this.retries == b.retries && 
				   this.attempts == b.attempts &&
				   this.multiplier == b.multiplier;
		}
		
		return false;
	}
	
	/**
	 * Returns the hash code for this instance. This value is be used in hash tables
	 * to quickly index instances of type {@link StdBackoff}.
	 * 
	 * @return	a {@literal int} value representing the hashcode of the string representation
	 * 			of this instance.
	 */
	@Override
	public int hashCode() {
		
		return this.toString().hashCode();
	}
	
	/**
	 * Clones the current instance of {@link StdBackoff}. This method creates a 
	 * fresh new instance of the same type with all of its fields set to the 
	 * same values.
	 * 
	 * @return	a {@link StdBackoff} instance that contains the current setup
	 * 			of the current instance.
	 */
	@Override
	public Object clone() {
		
		StdBackoff cloned = new StdBackoff(this.initialDelay, this.retries, this.multiplier);
		
		// these methods need to be set to ensure that the object is
		// exactly in the same state of the one that has been cloned.
		//
		cloned.delay = this.delay;
		cloned.attempts = this.attempts;
		
		return cloned;
	}

	/**
	 * Computes the updated value of the delay to use for the wait interval that is
	 * used in {@link Backoff#backoff()} topause the current thread before releasing
	 * control to the execution context.
	 * 
	 * @return	a {@literal long} value that represents the value of the exponential
	 * 			sequence that starts with <i>initialDelay</i> and grows according to
	 * 			<i>multiplier</i> at very attempt.
	 */
	@Override
	protected long computeDelay() {
		
		return (this.attempts == 1 ? this.initialDelay : this.delay * this.multiplier);
	}

}
