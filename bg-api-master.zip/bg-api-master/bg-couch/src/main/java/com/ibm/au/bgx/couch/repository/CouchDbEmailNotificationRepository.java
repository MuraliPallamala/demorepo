package com.ibm.au.bgx.couch.repository;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.ibm.au.bgx.couch.model.CouchDbEmailNotification;
import com.ibm.au.bgx.model.pojo.notification.EmailNotification;
import com.ibm.au.bgx.model.repository.EmailNotificationRepository;

/**
 * Class <b>CouchDbEmailNotificationRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link EmailNotification} and implements the interface {@link EmailNotificationRepository}
 * thus allowing the use of a CouhcDb database as persistent storage for the web notifications in the solution.
 * 
 * @see EmailNotificationRepository
 * @see EmailNotification
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Repository
@Primary
public class CouchDbEmailNotificationRepository 
		extends AbstractCouchDbRepository<CouchDbEmailNotification, EmailNotification> 
		implements EmailNotificationRepository {
    
    /**
     * Initialises an instance of {@link CouchDbEmailNotificationRepository}.
     */
    public CouchDbEmailNotificationRepository() {
        super(CouchDbEmailNotification.class);
    }
    
    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a 
     * specific configuration value the default injected value is set to <i>
     * notifications-email</i>.
     * </p>
     * 
     * @param database	a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.emailnotification:notifications-email}")
    protected void setDatabase(String database) {
        this.database = database;
    }
}
