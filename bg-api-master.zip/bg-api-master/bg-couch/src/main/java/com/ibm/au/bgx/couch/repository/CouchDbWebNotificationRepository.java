package com.ibm.au.bgx.couch.repository;

import com.ibm.au.bgx.couch.model.CouchDbWebNotification;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.repository.WebNotificationRepository;

import org.ektorp.ComplexKey;
import org.ektorp.support.View;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.List;

/**
 * Class <b>CouchDbWebNotificationRepository</b>. This class specialises the {@link
 * AbstractCouchDbRepository} for instances of type {@link WebNotification} and implements the
 * interface {@link WebNotificationRepository} thus allowing the use of a CouhcDb database as
 * persistent storage for the web notifications in the solution.
 *
 * @author Peter Ilfrich <peter.ilfrich@au1.ibm.com>
 * 
 * @see WebNotificationRepository
 * @see WebNotification
 */
@Repository
@Primary
public class CouchDbWebNotificationRepository
        extends AbstractCouchDbRepository<CouchDbWebNotification, WebNotification>
        implements WebNotificationRepository {

    private static final String VIEW_BY_RECEIVER_DATE = "by_receiverDate";
    private static final String VIEW_BY_RECEIVER_ID = "by_receiverId";
    private static final String VIEW_BY_REFERENCE_ID_ACTION = "by_referenceIdAction";
    private static final String VIEW_BY_RECEIVER_TOPIC_TYPE_STATUS = "by_receiverTopicTypeStatus";
    private static final String VIEW_BY_RECEIVER_TYPE_STATUS = "by_receiverTypeStatus";
    private static final String VIEW_BY_RECEIVER_STATUS = "by_receiverStatus";
    private static final String VIEW_BY_RECEIVER_TYPE = "by_receiverType";
    private static final String VIEW_BY_RECEIVER_TOPIC_TYPE = "by_receiverTopicType";
    private static final String VIEW_BY_RECEIVER_TOPIC_STATUS = "by_receiverTopicStatus";
    private static final String VIEW_BY_RECEIVER_TOPIC = "by_receiverTopic";
    private static final String VIEW_BY_RECEIVER_ACTION = "by_receiverAction";

    /**
     * Initialises an instance of {@link CouchDbWebNotificationRepository}.
     */
    public CouchDbWebNotificationRepository() {
        super(CouchDbWebNotification.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured value specified in
     * the {@link Value} annotation. In the absence of a specific configuration value the default
     * injected value is set to <i> notifications-web</i>.
     * </p>
     *
     * @param database a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.webnotification:notifications-web}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_RECEIVER_ID, map = "function(doc) { if (doc.content.receiverId) { emit(doc.content.receiverId, doc._id) } }")
    public List<WebNotification> findByReceiverId(String receiverId) {
        return this.unwrap(this.proxy.getView(VIEW_BY_RECEIVER_ID, receiverId));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_RECEIVER_DATE,
            map = "function(doc) { if(doc.content.receiverId) {emit([doc.content.receiverId, doc.content.createdAt], doc._id)} }")
    public List<WebNotification> findByReceiverIdDate(String receiverId, String minDate) {

        return this.complexQuery(VIEW_BY_RECEIVER_DATE, minDate, receiverId);
    }

    @Override
    @View(name = VIEW_BY_REFERENCE_ID_ACTION,
            map = "function(doc) { if(doc.content.referenceId) {emit([doc.content.referenceId, doc.content.actionRequired, doc.content.actionDone], doc._id)} }")
    public List<WebNotification> findByReferenceIdAction(String referenceId, boolean actionRequired,
                                                         boolean actionDone) {
        return this.unwrap(this.proxy
                .getView(VIEW_BY_REFERENCE_ID_ACTION, referenceId, actionRequired, actionDone));
    }

    @Override
    @View(name = VIEW_BY_RECEIVER_ACTION,
            map = "function(doc) { if(doc.content.receiverId) {emit([doc.content.receiverId, doc.content.actionRequired, doc.content.actionDone], doc._id)} }")
    public List<WebNotification> findByReceiverAction(String receiverId, boolean actionRequired, boolean actionDone) {
        return this.unwrap(this.proxy.getView(VIEW_BY_RECEIVER_ACTION, receiverId, actionRequired, actionDone));
    }

    @Override
    @View(name = VIEW_BY_RECEIVER_TOPIC_TYPE_STATUS,
            map = "function(doc) { if(doc.content.receiverId) {emit([doc.content.receiverId, doc.content.referenceType, doc.content.messageType, doc.content.status, doc.content.createdAt], doc._id)} }")
    public List<WebNotification> findByReceiverTopicTypeStatus(String receiverId, String topic,
                                                               String type, String status, String minDate) {

        return this.complexQuery(VIEW_BY_RECEIVER_TOPIC_TYPE_STATUS, minDate, receiverId, topic, type, status);
    }

    @Override
    @View(name = VIEW_BY_RECEIVER_TOPIC,
            map = "function(doc) { if(doc.content.receiverId) {emit([doc.content.receiverId, doc.content.referenceType, doc.content.createdAt], doc._id)} }")
    public List<WebNotification> findByReceiverTopic(String receiver, String topic,
                                                     String startDate) {
        return this.complexQuery(VIEW_BY_RECEIVER_TOPIC, startDate, receiver, topic);
    }

    @Override
    @View(name = VIEW_BY_RECEIVER_TOPIC_STATUS,
            map = "function(doc) { if(doc.content.receiverId) {emit([doc.content.receiverId, doc.content.referenceType, doc.content.status, doc.content.createdAt], doc._id)} }")
    public List<WebNotification> findByReceiverTopicStatus(String receiver, String topic,
                                                           String status, String startDate) {
        return this.complexQuery(VIEW_BY_RECEIVER_TOPIC_STATUS, startDate, receiver, topic, status);
    }

    @View(name = VIEW_BY_RECEIVER_TOPIC_TYPE,
            map = "function(doc) { if(doc.content.receiverId) {emit([doc.content.receiverId, doc.content.referenceType, doc.content.messageType, doc.content.createdAt], doc._id)} }")
    @Override
    public List<WebNotification> findByReceiverTopicType(String receiver, String topic, String type,
                                                         String startDate) {
        return this.complexQuery(VIEW_BY_RECEIVER_TOPIC_TYPE, startDate, receiver, topic, type);
    }

    @Override
    @View(name = VIEW_BY_RECEIVER_TYPE,
            map = "function(doc) { if(doc.content.receiverId) {emit([doc.content.receiverId, doc.content.messageType, doc.content.createdAt], doc._id)} }")
    public List<WebNotification> findByReceiverType(String receiver, String type,
                                                    String startDate) {
        return this.complexQuery(VIEW_BY_RECEIVER_TYPE, startDate, receiver, type);
    }

    @Override
    @View(name = VIEW_BY_RECEIVER_STATUS,
            map = "function(doc) { if(doc.content.receiverId) {emit([doc.content.receiverId, doc.content.status, doc.content.createdAt], doc._id)} }")
    public List<WebNotification> findByReceiverStatus(String receiver, String status,
                                                      String startDate) {
        return this.complexQuery(VIEW_BY_RECEIVER_STATUS, startDate, receiver, status);
    }

    @Override
    @View(name = VIEW_BY_RECEIVER_TYPE_STATUS,
            map = "function(doc) { if(doc.content.receiverId) {emit([doc.content.receiverId, doc.content.messageType, doc.content.status, doc.content.createdAt], doc._id)} }")
    public List<WebNotification> findByReceiverTypeStatus(String receiver, String type,
                                                          String status, String startDate) {
        return this.complexQuery(VIEW_BY_RECEIVER_TYPE_STATUS, startDate, receiver, type, status);
    }

    protected List<WebNotification> complexQuery(String queryName, String minDate, Object... keys) {
        int startKeyLength = minDate != null ? keys.length + 1 : keys.length;
        Object[] startKeys = Arrays.copyOf(keys, startKeyLength);
        Object[] endKeys = Arrays.copyOf(keys, keys.length + 1);

        if (minDate != null) {
            startKeys[keys.length] = minDate;
        }
        endKeys[keys.length] = "\ufff0";

        ComplexKey startKey = ComplexKey.of(startKeys);
        ComplexKey endKey = ComplexKey.of(endKeys);

        List<CouchDbWebNotification> result = this.proxy.getViewWithRange(queryName, startKey, endKey);
        return this.unwrap(result);
    }
}
