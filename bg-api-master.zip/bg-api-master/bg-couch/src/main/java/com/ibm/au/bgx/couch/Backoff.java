/**
 * 
 */
package com.ibm.au.bgx.couch;

import java.util.concurrent.TimeUnit;

/**
 * <p>
 * Class <b>Backoff</b>. This class maintains the configuration and implements
 * the algorithm to execute backoff while the submission of a request fails. 
 * </p>
 * <p>
 * The following code demonstrates how to use the backoff:
 * <code>
 * 
 *     Backoff linear = <create a backoff instance>
 *     while(!linear.isDone()) {
 *     
 *        // try something ...
 *        // if succeed, exit this loop and
 *        // set the success condition.
 *        //
 *        
 *        
 *        // otherwise wait...
 *        linear.wait();
 *     }
 *     
 *     // if the success condition is not met
 *     // throw exception.
 *     
 *     
 * </code>
 * </p>
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
public abstract class Backoff implements Cloneable {
	
	/**
	 * a {@literal int} defining the number of attempts to make before
	 * declaring the backoff completed. This number cannot be negative.
	 */
	protected int retries = 0;
	
	/**
	 * A internal counter representing the number of attempts already made.
	 */
	protected int attempts = 0;
	
	/**
	 * The current and updated value of the delay.
	 */
	protected long delay = 0;
	
	/**
	 * Initialises an instance of {@link Backoff} with the given number of retries.
	 * 
	 * @param retries		a {@literal int} value defining the number of attempts
	 * 						to make before the backoff is ceased. This parameter cannot
	 * 						be a negative number.
	 * 
	 * @throws IllegalArgumentException	if <i>retry</i> is a negative number.
	 */
	public Backoff(int retries) {
		
		if (retries < 0) {
			throw new IllegalArgumentException("Parameter 'retries' cannot be negative.");
		}
		this.retries = retries;
	}
	/**
	 * Gets the number of attempts that have been currently made. This 
	 * number returns the number of times that {@link Backoff#backoff()}
	 * has been invoked.
	 * 
	 * @return	an integer representing the number of attempts.
	 */
	public int getAttempts() {
		return this.attempts;
	}
	/**
	 * Returns the value of the last delay. This value corresponds to the
	 * amount of milliseconds that the thread waited that the last invocation 
	 * of {@link Backoff#backoff()} led to.
	 * 
	 * @return last delay used. This number is never negative.
	 */
	public long getDelay() {
		return this.delay;
	}
	
	/**
	 * Returns the configured number of retries.
	 * 
	 * @return configured number of retries. This number is never negative.
	 */
	public int getRetries() {
		return this.retries;
	}
	/**
	 * Checks whether the backoff has been executed for the configured
	 * number of retries.
	 * 
	 * @return 	{@literal true} if {@link Backoff#backoff()} has been executed
	 * 			at least the configured number of retries, {@literal false}
	 * 			otherwise.
	 */
	public boolean isDone() {
		
		return this.attempts < this.retries;
	}
	
	/**
	 * Resets the backoff counter. After this mthod is invoked. The status of the
	 * instance is equivalent to its state after creation. This means that the number
	 * of attempts and the current delay is set to 0.
	 */
	public void reset() {
		
		this.attempts = 0;
		this.delay = 0;
	}
	
	/**
	 * This methods computes the updated value of the delay based on the number
	 * pf previous invocations, and then executes a sleep for the amount of time
	 * indicated by the updated delay by using {@link TimeUnit#MILLISECONDS}.
	 * 
	 * @throws InterruptedException	in case the thread is being interrupted. This
	 * 								exception needs to be appropriately managed by
	 * 								calling context to terminate the execution thread.
	 */
	public void backoff() throws InterruptedException {
		
		
		this.attempts++;
		
		this.delay = this.computeDelay();
		
		TimeUnit.MILLISECONDS.sleep(this.delay);
			
		
	}
	
	/**
	 * This method clones the current instance of {@link Backoff}. Inherited classes
	 * must implement this method to return the specialised instance of {@link Backoff}
	 * that matches that class.
	 * 
	 * @return a cloned instance of the current instance.
	 */
	@Override
	public abstract Object clone();
	
	/**
	 * This is a callback method for inherited classes to specialise the algorithm
	 * that is used to update the delay at every invocation of the {@link Backoff#backoff()}
	 * method.
	 * 
	 * @return	a {@literal long} value representing the update value of the delay
	 * 			according to the specified backoff algorithm.
	 */
	protected abstract long computeDelay();
}
