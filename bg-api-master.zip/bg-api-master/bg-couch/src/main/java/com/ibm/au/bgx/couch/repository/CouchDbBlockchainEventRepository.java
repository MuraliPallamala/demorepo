package com.ibm.au.bgx.couch.repository;

import com.ibm.au.bgx.couch.model.CouchDbBlockchainEventMetaData;
import com.ibm.au.bgx.model.pojo.chain.BlockchainEventMetaData;
import com.ibm.au.bgx.model.repository.BlockchainEventRepository;

import org.ektorp.ComplexKey;
import org.ektorp.ViewResult;
import org.ektorp.support.View;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import java.time.Instant;

/**
 * @author Peter Ilfrich
 */
@Repository
@Primary
public class CouchDbBlockchainEventRepository extends
        AbstractCouchDbRepository<CouchDbBlockchainEventMetaData, BlockchainEventMetaData> implements
        BlockchainEventRepository {

    private static final String VIEW_GET_LAST = "getLast";

    public CouchDbBlockchainEventRepository() {
        super(CouchDbBlockchainEventMetaData.class);
    }

    @Override
    @Value("${couchdb.database.blockchainevents:blockchain-events}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    @Override
    @View(name = VIEW_GET_LAST, map = "function(doc) { emit([doc.content.channelName, doc.content.timestamp], doc._id) }")
    public BlockchainEventMetaData getLast(String channelName) {
        Object startKey = ComplexKey.of(new Object[] { channelName, Instant.now().toString() });
        ViewResult res = this.proxy.getDb()
                .queryView(this.proxy.createQuery(VIEW_GET_LAST)
                        .includeDocs(true)
                        .startKey(startKey)
                        .descending(true)
                        .limit(1));
        if (res.getRows().size() == 1) {
            return this.getItem(res.getRows().get(0).getId());
        }

        return null;
    }
}
