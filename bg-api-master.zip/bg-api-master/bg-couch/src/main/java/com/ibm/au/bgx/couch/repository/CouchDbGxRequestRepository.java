package com.ibm.au.bgx.couch.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.ibm.au.bgx.couch.model.CouchDbGxRequest;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.api.PaginatedResponse;
import com.ibm.au.bgx.model.exception.DataExistsException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.gx.GxActiveRequestsBitmaskWrapper;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.BasicBgxEncryptionUtil;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.ektorp.ComplexKey;
import org.ektorp.ViewQuery;
import org.ektorp.ViewResult;
import org.ektorp.support.View;
import org.ektorp.support.Views;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

/**
 * Class <b>CouchDbGxRequestRepository</b>. This class specialises the {@link
 * AbstractCouchDbRepository} for instances of type {@link GxRequest} and implements the interface
 * {@link GxRequestRepository} thus allowing the use of a CouhcDb database as persistent storage for
 * the web notifications in the solution.
 *
 * @author Dain Liffman <dainliff@au1.ibm.com>
 * @see GxRequestRepository
 * @see GxRequest
 */
@Repository
@Primary
@Views({
    @View(name = CouchDbGxRequestRepository.VIEW_BY_ORGID, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToOrgIds) {" +
            "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
            "emit(doc.content.visibleToOrgIds[i], doc._id)" +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_CHANNELUSERNAME, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToChannelUsernames) {" +
            "for (var i=0; i<doc.content.visibleToChannelUsernames.length; i++) {" +
            "emit(doc.content.visibleToChannelUsernames[i], doc._id)" +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_GUARANTEEID, map =
        "function(doc) { if(doc.cdbGxRequest) {" +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<gxIds.length; i++) {" +
            "emit(gxIds[i], doc._id)" +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_STATUS, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.status) {" +
            "emit(doc.content.status, doc._id)" +
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.type) {" +
            "emit(doc.content.type, doc._id)" +
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_ORGID_GUARANTEEID, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToOrgIds && doc.content.guaranteeId) {"
            +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
            "for (var j=0; j<gxIds.length; j++) {" +
            "emit([doc.content.visibleToOrgIds[i], gxIds[j]], doc._id)" +
            "}" + //for
            "}" + //for

            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_CHANNELUSERNAME_GUARANTEEID, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToChannelUsernames && doc.content.guaranteeId) {"
            +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<doc.content.visibleToChannelUsernames.length; i++) {" +
            "for (var j=0; j<gxIds.length; j++) {" +
            "emit([doc.content.visibleToChannelUsernames[i], gxIds[j]], doc._id)" +
            "}" + //for
            "}" + //for

            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_ORGID_STATUS, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToOrgIds && doc.content.status) {"
            +
            "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
            "emit([doc.content.visibleToOrgIds[i], doc.content.status], doc._id)" +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_CHANNELUSERNAME_STATUS, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToChannelUsernames && doc.content.status) {"
            +
            "for (var i=0; i<doc.content.visibleToChannelUsernames.length; i++) {" +
            "emit([doc.content.visibleToChannelUsernames[i], doc.content.status], doc._id)" +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_ORGID_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToOrgIds && doc.content.type) {"
            +
            "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
            "emit([doc.content.visibleToOrgIds[i], doc.content.type], doc._id)" +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_CHANNELUSERNAME_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToChannelUsernames && doc.content.type) {"
            +
            "for (var i=0; i<doc.content.visibleToChannelUsernames.length; i++) {" +
            "emit([doc.content.visibleToChannelUsernames[i], doc.content.type], doc._id)" +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_GUARANTEEID_STATUS, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.guaranteeId && doc.content.status) {" +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<gxIds.length; i++) {" +
            "emit([gxIds[i], doc.content.status], doc._id)" +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_ORGID_GUARANTEEID_STATUS, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToOrgIds && doc.content.guaranteeId && doc.content.status) {"
            +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
            "for (var j=0; j<gxIds.length; j++) {" +
            "emit([doc.content.visibleToOrgIds[i], gxIds[j], doc.content.status], doc._id)" +
            "}" + //for
            "}" + //for

            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_CHANNELUSERNAME_GUARANTEEID_STATUS, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToChannelUsernames && doc.content.guaranteeId && doc.content.status) {"
            +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<doc.content.visibleToChannelUsernames.length; i++) {" +
            "for (var j=0; j<gxIds.length; j++) {" +
            "emit([doc.content.visibleToChannelUsernames[i], gxIds[j], doc.content.status], doc._id)" +
            "}" + //for
            "}" + //for

            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_GUARANTEEID_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.guaranteeId && doc.content.type) { " +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<gxIds.length; i++) {" +
            "emit([gxIds[i], doc.content.type], doc._id)" +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_ORGID_GUARANTEEID_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToOrgIds && doc.content.guaranteeId && doc.content.type) {"
            +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
            "for (var j=0; j<gxIds.length; j++) {" +
            "emit([doc.content.visibleToOrgIds[i], gxIds[j], doc.content.type], doc._id)" +
            "}" + //for
            "}" + //for

            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_CHANNELUSERNAME_GUARANTEEID_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToChannelUsernames && doc.content.guaranteeId && doc.content.type) {"
            +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<doc.content.visibleToChannelUsernames.length; i++) {" +
            "for (var j=0; j<gxIds.length; j++) {" +
            "emit([doc.content.visibleToChannelUsernames[i], gxIds[j], doc.content.type], doc._id)" +
            "}" + //for
            "}" + //for

            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_STATUS_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.status && doc.content.type) {" +
            "emit([doc.content.status, doc.content.type], doc._id)" +
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_ORGID_STATUS_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToOrgIds && doc.content.status && doc.content.type) {"
            +
            "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
            "emit([doc.content.visibleToOrgIds[i], doc.content.status, doc.content.type], doc._id)"
            +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_CHANNELUSERNAME_STATUS_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToChannelUsernames && doc.content.status && doc.content.type) {"
            +
            "for (var i=0; i<doc.content.visibleToChannelUsernames.length; i++) {" +
            "emit([doc.content.visibleToChannelUsernames[i], doc.content.status, doc.content.type], doc._id)"
            +
            "}" + //for
            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_GUARANTEEID_STATUS_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.guaranteeId && doc.content.status && doc.content.type) {"
            +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<gxIds.length; i++) {" +
            "emit([gxIds[i], doc.content.status, doc.content.type], doc._id)" +
            "}" + //for

            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_ORGID_GUARANTEEID_STATUS_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToOrgIds && doc.content.guaranteeId && doc.content.status && doc.content.type) {"
            +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
            "for (var j=0; j<gxIds.length; j++) {" +
            "emit([doc.content.visibleToOrgIds[i], gxIds[j], doc.content.status, doc.content.type], doc._id)" +
            "}" + //for
            "}" + //for

            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.VIEW_BY_CHANNELUSERNAME_GUARANTEEID_STATUS_TYPE, map =
        "function(doc) { if(doc.cdbGxRequest && doc.content.visibleToChannelUsernames && doc.content.guaranteeId && doc.content.status && doc.content.type) {"
            +
            "var gxIds = [];" +
            "if (doc.content.guaranteeId) {" +
            "gxIds.push(doc.content.guaranteeId)" +
            "}" + // if
            "if (doc.content.meta && doc.content.meta.newGuaranteeId) {" +
            "gxIds.push(doc.content.meta.newGuaranteeId)" +
            "}" + // if

            "for (var i=0; i<doc.content.visibleToChannelUsernames.length; i++) {" +
            "for (var j=0; j<gxIds.length; j++) {" +
            "emit([doc.content.visibleToChannelUsernames[i], gxIds[j], doc.content.status, doc.content.type], doc._id)" +
            "}" + //for
            "}" + //for

            "}" + // if
            "}" // function
    ),
    @View(name = CouchDbGxRequestRepository.ACTIVE_REQUESTS_BY_GUARANTEEID,
        map = "function(doc) { if (doc.cdbGxRequest && doc.content.guaranteeId && doc.content.status == \"ACTIVE\") { var allowedTypes = [\"AMEND\", \"CANCEL\", \"DEMAND\", \"PAYWALK\", \"TRANSFER\"]; var map = { AMEND: 1, CANCEL: 2, DEMAND: 4, PAYWALK: 8, TRANSFER: 16 }; var gxRequest = doc.content; if (gxRequest && allowedTypes.indexOf(gxRequest.type) != -1) { emit(gxRequest.guaranteeId, map[gxRequest.type]) } } }",
        reduce = "function (keys, values, rereduce) { return values.reduce(function(a, b) { return a | b }) }"
    ),
    @View(name = CouchDbGxRequestRepository.ACTIVE_REQUESTS_BY_ORGID_GUARANTEEID,
        map = "function(doc) { if (doc.cdbGxRequest && doc.content.guaranteeId && doc.content.visibleToOrgIds && doc.content.status == \"ACTIVE\") { var allowedTypes = [\"AMEND\", \"CANCEL\", \"DEMAND\", \"PAYWALK\", \"TRANSFER\"]; var map = { AMEND: 1, CANCEL: 2, DEMAND: 4, PAYWALK: 8, TRANSFER: 16 }; var gxRequest = doc.content; if (gxRequest && allowedTypes.indexOf(gxRequest.type) != -1) { for (var i = 0; i < gxRequest.visibleToOrgIds.length; i++) { emit([gxRequest.visibleToOrgIds[i], gxRequest.guaranteeId], map[gxRequest.type]); } } } }",
        reduce = "function (keys, values, rereduce) { return values.reduce(function(a, b) { return a | b }) }"
    )
})
public class CouchDbGxRequestRepository
    extends AbstractEncryptedCouchDbRepository<CouchDbGxRequest, GxRequest>
    implements GxRequestRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(CouchDbGxRequestRepository.class);
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();
    private static final ObjectReader KEY_READER = MAPPER.readerFor(new TypeReference<Object>() {
    });

    // Default value will be overwritten with that in the properties
    @Value("${bgx.encryption.repository.gxRequest.enabled:false}")
    protected boolean enableEncryption;

    protected static final String PREFIX = "by";
    protected static final String SEPARATOR = "_";
    protected static final String ORG_ID = "orgId";
    protected static final String CHANNEL_USERNAME = "channelUsername";
    protected static final String GUARANTEE_ID = "guaranteeId";
    protected static final String STATUS = "status";
    protected static final String TYPE = "type";
    protected static final String ACTIVE_REQUESTS_PREFIX = "activeRequests";

    /**
     * A {@link String} constant that maps the name of the view allowing an application client to
     * retrieve the request by organisation identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected static final String VIEW_BY_ORGID = PREFIX + SEPARATOR + ORG_ID;

    /**
     * A {@link String} constant that maps the name of the view allowing an application client to
     * retrieve the request by channel username.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected static final String VIEW_BY_CHANNELUSERNAME = PREFIX + SEPARATOR + CHANNEL_USERNAME;

    /**
     * A {@link String} constant that maps the name of the view allowing an application client to
     * retrieve the request by guarantee identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected static final String VIEW_BY_GUARANTEEID = PREFIX + SEPARATOR + GUARANTEE_ID;

    protected static final String VIEW_BY_STATUS = PREFIX + SEPARATOR + STATUS;
    protected static final String VIEW_BY_TYPE = PREFIX + SEPARATOR + TYPE;
    /**
     * A {@link String} constant that maps the name of the view allowing an application client to
     * retrieve the request by organisation identifier and guarantee identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */

    protected static final String VIEW_BY_GUARANTEEID_STATUS =
        VIEW_BY_GUARANTEEID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_GUARANTEEID_TYPE =
        VIEW_BY_GUARANTEEID + SEPARATOR + TYPE;
    protected static final String VIEW_BY_STATUS_TYPE =
        VIEW_BY_STATUS + SEPARATOR + TYPE;

    protected static final String VIEW_BY_GUARANTEEID_STATUS_TYPE =
        VIEW_BY_GUARANTEEID_STATUS + SEPARATOR + TYPE;

    protected static final String VIEW_BY_ORGID_GUARANTEEID =
        VIEW_BY_ORGID + SEPARATOR + GUARANTEE_ID;
    protected static final String VIEW_BY_ORGID_STATUS = VIEW_BY_ORGID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_ORGID_TYPE = VIEW_BY_ORGID + SEPARATOR + TYPE;

    protected static final String VIEW_BY_ORGID_GUARANTEEID_STATUS =
        VIEW_BY_ORGID_GUARANTEEID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_ORGID_GUARANTEEID_TYPE =
        VIEW_BY_ORGID_GUARANTEEID + SEPARATOR + TYPE;
    protected static final String VIEW_BY_ORGID_STATUS_TYPE =
        VIEW_BY_ORGID_STATUS + SEPARATOR + TYPE;
    protected static final String VIEW_BY_ORGID_GUARANTEEID_STATUS_TYPE =
        VIEW_BY_ORGID_GUARANTEEID_STATUS + SEPARATOR + TYPE;

    protected static final String VIEW_BY_CHANNELUSERNAME_GUARANTEEID =
        VIEW_BY_CHANNELUSERNAME + SEPARATOR + GUARANTEE_ID;
    protected static final String VIEW_BY_CHANNELUSERNAME_STATUS = VIEW_BY_CHANNELUSERNAME + SEPARATOR + STATUS;
    protected static final String VIEW_BY_CHANNELUSERNAME_TYPE = VIEW_BY_CHANNELUSERNAME + SEPARATOR + TYPE;

    protected static final String VIEW_BY_CHANNELUSERNAME_GUARANTEEID_STATUS =
        VIEW_BY_CHANNELUSERNAME_GUARANTEEID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_CHANNELUSERNAME_GUARANTEEID_TYPE =
        VIEW_BY_CHANNELUSERNAME_GUARANTEEID + SEPARATOR + TYPE;
    protected static final String VIEW_BY_CHANNELUSERNAME_STATUS_TYPE =
        VIEW_BY_CHANNELUSERNAME_STATUS + SEPARATOR + TYPE;
    protected static final String VIEW_BY_CHANNELUSERNAME_GUARANTEEID_STATUS_TYPE =
        VIEW_BY_CHANNELUSERNAME_GUARANTEEID_STATUS + SEPARATOR + TYPE;

    /**
     * Bitmasks for whether there are active requests for the guarantee
     */
    protected static final String ACTIVE_REQUESTS_BY_GUARANTEEID =
        ACTIVE_REQUESTS_PREFIX + SEPARATOR + GUARANTEE_ID;
    protected static final String ACTIVE_REQUESTS_BY_ORGID_GUARANTEEID =
        ACTIVE_REQUESTS_PREFIX + SEPARATOR + ORG_ID + SEPARATOR + GUARANTEE_ID;


    /**
     * Initialises an instance of {@link CouchDbGxRequestRepository}.
     */
    public CouchDbGxRequestRepository() {
        super(CouchDbGxRequest.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured value specified in
     * the {@link Value} annotation. In the absence of a specific configuration value the default
     * injected value is set to <i> requests</i>.
     * </p>
     *
     * @param database a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.requests:requests}")
    protected void setDatabase(String database) {
        this.database = database;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public PaginatedResponse<GxRequest> find(String orgId, String channelUsername, String guaranteeId, String status,
        String type,
        String start, Integer limit) {
        String view;
        List<String> args = new ArrayList<>();
        if (orgId == null && channelUsername == null && guaranteeId == null && status == null) {
            view = "all";
        } else {
            if (orgId != null && channelUsername != null) {
                throw new IllegalArgumentException("Cannot specify both orgId and channelUsername");
            }
            view = PREFIX;
            if (orgId != null) {
                args.add(orgId);
                view += SEPARATOR + ORG_ID;
            } else if (channelUsername != null){
                args.add(channelUsername);
                view += SEPARATOR + CHANNEL_USERNAME;
            }
            if (guaranteeId != null) {
                args.add(guaranteeId);
                view += SEPARATOR + GUARANTEE_ID;
            }
            if (status != null) {
                args.add(status);
                view += SEPARATOR + STATUS;
            }
            if (type != null) {
                args.add(type);
                view += SEPARATOR + TYPE;
            }
        }

        ViewQuery viewQuery = new ViewQuery()
            .designDocId(String.format("_design/%s", CouchDbGxRequest.class.getSimpleName()))
            .viewName(view)
            .includeDocs(true);

        if (start != null) {
            viewQuery.startDocId(start);
        }

        if (limit != null) {
            viewQuery.limit(limit + 1);
        }

        if (args.size() == 1) {
            viewQuery.key(args.get(0));
        } else if (args.size() > 1) {
            viewQuery.key(ComplexKey.of(args.stream().toArray(Object[]::new)));
        }

        LOGGER.debug(BgxLogMarkers.DEV,
            "Querying gxRequests with viewName {} args {} start {} limit {}", view, args, start,
            limit);

        PaginatedResponse<GxRequest> paginatedResponse = new PaginatedResponse<>();
        List<CouchDbGxRequest> result = this.proxy.getView(viewQuery);

        if (limit != null && result.size() > limit) {
            CouchDbGxRequest nextRequest = result.remove(result.size() - 1);
            paginatedResponse.setNext(nextRequest.getId());
        }
        paginatedResponse.setResult(this.unwrap(result));

        return paginatedResponse;
    }



    @Override
    public PaginatedResponse<GxRequest> find(BgxPrincipal principal, String guaranteeId, String status,
        String type,
        String start, Integer limit) {
        // TODO extend to support all GxFlowsSearchRequest fields
        String orgId;
        String channelUsername;

        if (principal == null) {
            orgId = null;
            channelUsername = null;
        } else if (principal.isActingOnBehalf()) {
            orgId = null;
            channelUsername = principal.getChannelUserName();
        } else {
            orgId = principal.getPrimaryOrgId();
            channelUsername = null;
        }

        return find(orgId, channelUsername, guaranteeId, status, type, start, limit);
    }

    @Override
    public PaginatedResponse<GxRequest> find(String orgId, String channelUsername, GxFlowsSearchRequest searchRequest) {
        // TODO extend to support all GxFlowsSearchRequest fields
        return find(orgId,
            channelUsername,
            searchRequest.getGuaranteeId(),
            searchRequest.getStatus() == null ? null : searchRequest.getStatus().value(),
            searchRequest.getType() == null ? null : searchRequest.getType().value(),
            searchRequest.getStart(),
            searchRequest.getLimit() == null ? null : searchRequest.getLimit().intValue());
    }


    @Override
    public PaginatedResponse<GxRequest> find(BgxPrincipal principal, GxFlowsSearchRequest searchRequest) {
        // TODO extend to support all GxFlowsSearchRequest fields
        return find(principal,
            searchRequest.getGuaranteeId(),
            searchRequest.getStatus() == null ? null : searchRequest.getStatus().value(),
            searchRequest.getType() == null ? null : searchRequest.getType().value(),
            searchRequest.getStart(),
            searchRequest.getLimit() == null ? null : searchRequest.getLimit().intValue());
    }



    @Override
    public List<GxActiveRequestsBitmaskWrapper> findActiveRequestsMask(String orgId,
        List<String> guaranteeIds) throws IOException {
        String view;
        @SuppressWarnings("rawtypes")
		List keys;
        if (orgId != null) {
            view = CouchDbGxRequestRepository.ACTIVE_REQUESTS_BY_ORGID_GUARANTEEID;
            keys = new ArrayList<ComplexKey>();
            for (String guaranteeId : guaranteeIds) {
                keys.add(ComplexKey.of(orgId, guaranteeId));
            }
        } else {
            view = CouchDbGxRequestRepository.ACTIVE_REQUESTS_BY_GUARANTEEID;
            keys = guaranteeIds;
        }

        LOGGER.debug("Checking active requests for bulk Gx for orgId {}", orgId);

        ViewQuery viewQuery = new ViewQuery()
            .designDocId(String.format("_design/%s", CouchDbGxRequest.class.getSimpleName()))
            .viewName(view)
            .keys(keys)
            .group(true);
        ViewResult viewResult = this.proxy.getViewRaw(viewQuery);
        List<GxActiveRequestsBitmaskWrapper> bitmaskWrapperList = new ArrayList<>();
        for (ViewResult.Row row : viewResult.getRows()) {
            JsonNode keyNode = row.getKeyAsNode();
            GxActiveRequestsBitmaskWrapper bitmaskWrapper = new GxActiveRequestsBitmaskWrapper();
            if (keyNode.isArray()) {
                List<String> list = CouchDbGxRequestRepository.KEY_READER.readValue(keyNode);
                // Add gxID
                bitmaskWrapper.setGxId(list.get(1));

            } else {
                bitmaskWrapper.setGxId(keyNode.asText());
            }
            bitmaskWrapper.setMask(Integer.valueOf(row.getValueAsInt()));
            bitmaskWrapperList.add(bitmaskWrapper);
        }

        return bitmaskWrapperList;
    }


    @Override
    public GxActiveRequestsBitmaskWrapper findActiveRequestsMask(String orgId, String guaranteeId) {
        ViewQuery viewQuery = new ViewQuery()
            .designDocId(String.format("_design/%s", CouchDbGxRequest.class.getSimpleName()))
            .group(true);

        if (orgId != null) {
            viewQuery
                .viewName(CouchDbGxRequestRepository.ACTIVE_REQUESTS_BY_ORGID_GUARANTEEID)
                .key(ComplexKey.of(orgId, guaranteeId));
        } else {
            viewQuery
                .viewName(CouchDbGxRequestRepository.ACTIVE_REQUESTS_BY_GUARANTEEID)
                .key(guaranteeId);
        }

        LOGGER.debug("Checking active requests for Gx {} for orgId {}", guaranteeId, orgId);
        ViewResult viewResult = this.proxy.getViewRaw(viewQuery);

        if (viewResult.isEmpty()) {
            LOGGER.debug("No active requests for Gx {}", guaranteeId);
            return null;
        }

        GxActiveRequestsBitmaskWrapper bitmaskWrapper = new GxActiveRequestsBitmaskWrapper();
        bitmaskWrapper.setGxId(guaranteeId);
        bitmaskWrapper.setMask(viewResult.getRows().get(0).getValueAsInt());
        LOGGER.debug("{} Active requests found for Gx {}", bitmaskWrapper.getMask(), guaranteeId);

        return bitmaskWrapper;
    }

    @Override
    public GxRequest forceUpdateFields(GxRequest gxRequest, List<String> visibleChannelUserNames, int retries) {
        try {
            gxRequest.setVisibleToChannelUsernames(visibleChannelUserNames);
            return this.updateItem(gxRequest);
        } catch (DataExistsException e) {
            DataExistsException finalException = null;
            for (int i =0; i < retries; i++) {
                try {
                    gxRequest = this.getItem(gxRequest.getId());
                    gxRequest.setVisibleToChannelUsernames(visibleChannelUserNames);
                    return this.updateItem(gxRequest);
                } catch (DataExistsException e2) {
                    finalException = e2;
                }
            }
            throw new DataExistsException("Failure to force update fields", finalException);
        }
    }

    @Override
    GxRequest encrypt(final GxRequest item) {

        if (!enableEncryption) {
            LOGGER.debug("Encryption is disabled for gx request repository");
            return item;
        }

        LOGGER.debug("Encrypting payload of GxRequest {}",
            item.getId());

        Map<String, String> encrypted = new HashMap<>();

        // encrypt payload if it exists
        if (item.getPayload() != null) {
            encrypted.put(BgxConstants.META_PAYLOAD, BasicBgxEncryptionUtil
                .encrypt(item.getPayload(), encryptionPassword, encryptionSalt));
        }

        // set the encrypted fields
        GxRequest cloned = this.clone(item);
        if (cloned.getMeta() == null) {
            cloned.setMeta(new HashMap<>());
        }

        cloned.getMeta().put(BgxConstants.META_RESTRICTED, encrypted);

        this.updateEncryptionVersion(cloned.getMeta());

        // force nullify
        cloned.setPayload(null);

        return cloned;
    }

    @Override
    GxRequest decrypt(final GxRequest item) {

        if (item.getMeta() == null || !item.getMeta()
            .containsKey(BgxConstants.META_ENCRYPTION_VERSION)) {
            return item;
        }

        this.validateEncryptionVersion(item.getMeta());

        LOGGER.debug("Decrypting payload of GxRequest {}",
            item.getId());

        // Create a clone and put back the payload
        GxRequest cloned = this.clone(item);

        // decrypt payload
        @SuppressWarnings("unchecked")
		Map<String, String> encrypted = (Map<String,String>) item.getMeta().get(BgxConstants.META_RESTRICTED);
        if (encrypted.containsKey(BgxConstants.META_PAYLOAD)) {
            String payloadJSON = BasicBgxEncryptionUtil
                .decrypt(encrypted.get(BgxConstants.META_PAYLOAD), encryptionPassword,
                    encryptionSalt);

            try {
                cloned.setPayload(MAPPER.readValue(payloadJSON, Object.class));
            } catch (Exception e) {
                // cast to runtime exception
                throw new RuntimeException(e);
            }
        }

        return cloned;
    }


}
