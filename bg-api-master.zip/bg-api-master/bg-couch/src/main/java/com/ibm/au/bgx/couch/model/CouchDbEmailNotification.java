package com.ibm.au.bgx.couch.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ibm.au.bgx.model.pojo.notification.EmailNotification;
import org.ektorp.support.TypeDiscriminator;

/**
 * Class <b>CouchDbEmailNotification</b>. This a simple CouchDb POJO wrapper for 
 * the {@link EmailNotification} type.
 * 
 * @see CouchDbEntity 
 * @see EmailNotification
 * 
 * @author Peter Ilfrich <peter.ilfrich@au1.ibm.com>
 */
public class CouchDbEmailNotification extends CouchDbEntity<EmailNotification> {

	/**
	 * A {@link Long} value used to discriminate among different instances that
	 * have the same class name (but may not be the same) during serialization.
	 */
	private static final long serialVersionUID = -3423662190613321135L;

	/**
	 * A {@link String} field used as type discriminator for JSON documnt that
	 * should be mapped to instances of the defined type. A field annotated with
	 * the {@link TypeDiscriminator} annotation provides Ektorp with information
	 * on how to retrieve all the elements that are to be cast to a specific 
	 * type.
	 */
	@TypeDiscriminator
    @JsonProperty("cdbEmailNotification")
    private final String cdbEmailNotification = "EmailNotification";


}
