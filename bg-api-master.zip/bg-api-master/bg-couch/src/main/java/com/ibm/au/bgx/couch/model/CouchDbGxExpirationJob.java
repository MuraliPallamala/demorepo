package com.ibm.au.bgx.couch.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ibm.au.bgx.model.pojo.task.GxExpirationJob;

import org.ektorp.support.TypeDiscriminator;

/**
 * Class <b>CouchDbGxExpirationJob</b>. This a simple CouchDb POJO wrapper for 
 * the {@link GxExpirationJob} type.
 * 
 * @author Peter Ilfrich
 */
public class CouchDbGxExpirationJob extends CouchDbEntity<GxExpirationJob> {

    /**
     * This is a {@literal long} value that uniquely identifies the instances
     * of this particular implementation of this class. This is to prevent that
     * instances that are serialized across JVMs that point to different definitions
     * of the same class are mixed together.
     */
	private static final long serialVersionUID = -1166726837634387621L;
	

	/**
	 * A {@link String} field used as type discriminator for JSON documnt that
	 * should be mapped to instances of the defined type. A field annotated with
	 * the {@link TypeDiscriminator} annotation provides Ektorp with information
	 * on how to retrieve all the elements that are to be cast to a specific 
	 * type.
	 */
	@TypeDiscriminator
    @JsonProperty("cdbGxExpirationJob")
    private final String cdbGxExpirationJob = "GxExpirationJob";
}
