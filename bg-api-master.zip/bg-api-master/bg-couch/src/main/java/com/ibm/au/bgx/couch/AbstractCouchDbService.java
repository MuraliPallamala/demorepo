/**
 *
 */
package com.ibm.au.bgx.couch;

import com.ibm.au.bgx.model.api.SystemStatusResource;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import org.ektorp.CouchDbConnector;
import org.ektorp.DbAccessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;

/**
 * Class <b>AbstractCouchDbService</b>. Base root class for all the CouchDb repository
 * implementations. In this implementation a repository is attached to a single CouchDb
 * database, and this class implements the basic capabilities for the management of the
 * connectivity to the configured database instance.
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 * @author Peter Ilfrich <peter.ilfrich@au1.ibm.com>
 */
public abstract class AbstractCouchDbService {

    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractCouchDbService.class);

    /**
     * An instance of {@link CouchDbConnectionMetadata} that contains the information that is
     * required to connect to the configured <i>CouchDb</i> server and database.
     */
    protected CouchDbConnectionMetadata metadata;

    /**
     * A {@link SystemStatusResource} instance that provides information associated
     * to the  resources that are currently active and ready.
     */
    @Autowired
    SystemStatusResource systemStatus;

    /**
     * A {@link String} representing the url to the <i>CouchDb<i> instance. The
     * property is injected via the Spring {@link Value} annotation and the
     * default value is 'http://localhost:5984'.
     */
    @Value("${couchdb.url:http://localhost:5984}")
    private String url;

    /**
     * A {@link String} representing the username (if any) used to authenticate.
     * The property is injected via the Spring {@link Value} annotation and the
     * default value is 'admin'.
     */
    @Value("${couchdb.username:admin}")
    private String username;

    /**
     * A {@link String} representing the password (if any) used to authenticate.
     * The property is injected via the Spring {@link Value} annotation and the
     * default value is 'password'.
     */
    @Value("${couchdb.password:password}")
    private String password;

    /**
     * A {@link String} holding the {@literal boolean} value controlling whether
     * the service should attempt to create the configured database if not
     * existing {@literal false} or not {@literal true}. The property is
     * injected via the Spring {@link Value} annotation and the default value
     * is {@literal false}.
     */
    @Value("${couchdb.preventDatabaseCreation:false}")
    private String preventDatabaseCreation;

    /**
     * A {@link String} holding the {@literal boolean} value controlling whether
     * the service should automatically create the views that are defined in the
     * inherited classes as a support of the search methods. The property is injected
     * via the Spring {@link Value} annotation and the default value is {@literal true}.
     */
    @Value("${couchdb.initViews:true}")
    private String initViews;

    /**
     * A {@literal int} value holding the maximum number of attempts that the service
     * will make while trying to connect to the configured database with the given
     * credentials. The value is injected via the Spring {@link Value} annotation and
     * the default value is 10.
     */
    @Value("${couchdb.maxReconnectAttempts:10}")
    private int maxReconnect;

    /**
     * A {@literal int} value holding the number of milliseconds to wait before trying
     * again to reconnect. The value is injected via the Spring {@link Value} annotation and
     * the default value is 3000.
     */
    @Value("${couchdb.reconnectInterval:3000}")
    private int reconnectInterval;

    /**
     * Configures the service upon creation. This method is called by Spring and other injection
     * framework to configure the instance once it has been created with reflection. The method
     * initialises the connection to the configured database.
     *
     * @throws InterruptedException this method executes a sleep for the configured reconnect
     *                              interval before attempting again the connection. This
     *                              exception is thrown if the thread is interrupted from the
     *                              sleep mode.
     */
    @PostConstruct
    public void setup() throws InterruptedException {


        String database = this.getDatabase();

        // register the component with the system
        String systemStatusIdentifier = String.format("couch_%s", database);
        systemStatus.registerComponent(systemStatusIdentifier);
        LOGGER.debug("Connecting CouchDB repository for: {}", database);


        if (this.url == null || this.url.isEmpty()) {
            RuntimeException e = new RuntimeException("No CouchDB connection setting present, defaulting to localhost");
            LOGGER.error("Missing CouchDB URL configuration parameter", e);
            throw e;
        }

        this.metadata = new CouchDbConnectionMetadata(url, database, this.username, this.password);


        int attempts = 0;
        CouchDbConnector connector = null;
        while (attempts < this.maxReconnect && connector == null) {

            LOGGER.debug(BgxLogMarkers.DEV, "Attempt connect: '{}/{}' as '{}' ({}/{})", url, database, this.username, attempts + 1, maxReconnect);

            try {
                // create connector, check database and create views if configured
                connector = attemptConnect();

                // all good, no exception means we are connected
                LOGGER.debug(BgxLogMarkers.DEV, "Connected: '{}/{}' as '{}'", url, database, this.username);
                // finally declare the repository ready
                systemStatus.setComponentReady(systemStatusIdentifier);

            } catch (Exception e) {
                // reset connector to trigger another attempt
                connector = null;
                attempts += 1;

                // abort condition will throw exception, failing startup
                if (attempts == this.maxReconnect) {

                    LOGGER.debug(BgxLogMarkers.DEV, "Failed to connect. Spring might try to run this again.");

                    throw new DbAccessException(e);
                }

                Thread.sleep(this.reconnectInterval);

            }
        }
    }


    /**
     * This utility method attempts the connection. If the connection is successful it also configures
     * the internal {@link CouchDbConnector} based on the selected behaviour for automatic database
     * creation and view initialisation.
     *
     * @return a {@link CouchDbConnector} instance that is connected to the configured database.
     * @throws Exception if there is any error while trying to establish the connection to the database.
     */
    private CouchDbConnector attemptConnect() throws Exception {
        CouchDbConnector connector = CouchDbConnectionManager.getInstance(this.metadata);

        boolean initDatabaseFlag = preventDatabaseCreation == null || "false".equalsIgnoreCase(this.preventDatabaseCreation);

        if (initDatabaseFlag) {
            // The CouchDbConnectionManager does not create the database
            // we create it to ensure that the com.ibm.au.bgx.common.rest of the code does not
            // break.
            //
            connector.createDatabaseIfNotExists();
        }

        boolean initViewsFlag = preventDatabaseCreation != null && "true".equalsIgnoreCase(this.initViews);

        this.init(connector, initViewsFlag);

        return connector;
    }

    /**
     * This method is a callback for concrete classes to complete the initialization of the
     * component.
     *
     * @param connector a {@link CouchDbConnector} instance that represents the connectivity to the
     *                  database.
     * @param bInitView a {@literal boolean} value indicating whether the repository does need to
     *                  initialize the views or not.
     */
    protected abstract void init(CouchDbConnector connector, boolean bInitView);

    /**
     * This method should retrieve the name of the database that was set by the subclass.
     *
     * @return A {@link String} representing the name of the database referenced by the connection.
     */
    protected abstract String getDatabase();

    /**
     * This method should allow the subclass to determine the name of the database it will use
     * accordingly.
     *
     * @param database a {@link String} representing the name of the database referenced by the
     *                 connection.
     */
    protected abstract void setDatabase(String database);
}
