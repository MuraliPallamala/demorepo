package com.ibm.au.bgx.couch.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.couch.model.CouchDbTermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TcExternalContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCondContent.Type;
import com.ibm.au.bgx.model.repository.TermsAndCondRepository;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.util.List;
import org.ektorp.support.View;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

/**
 * Class <b>CouchDbTermsAndCondRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link com.ibm.au.bgx.model.pojo.tc.TermsAndCond} and implements the interface {@link TermsAndCondRepository}
 * thus allowing the use of a CouhcDb database as persistent storage for the web notifications in the 
 * solution.
 * 
 * @see TermsAndCondRepository
 * @see com.ibm.au.bgx.model.pojo.tc.TermsAndCond
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Repository
@Primary
public class CouchDbTermsAndCondRepository
		extends AbstractCouchDbRepository<CouchDbTermsAndCond, TermsAndCond>
		implements TermsAndCondRepository {



    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * terms and conditions by title and scope.
	 *
	 * @see CouchDbTermsAndCondRepository#getByTitle(String)
	 */
    public static final String VIEW_BY_TITLE = "by_title";

    /**
     * A {@link String} constant that contains the name of the view that allows retrieving
     * terms and conditions by unique identifier of the owner.
     *
     * @see CouchDbTermsAndCondRepository#getByScope(String)
     */
    public static final String VIEW_BY_SCOPE = "by_scope";

    /**
     * Initialises an instance of {@link CouchDbTermsAndCondRepository}.
     */
    public CouchDbTermsAndCondRepository() {
        super(CouchDbTermsAndCond.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a 
     * specific configuration value the default injected value is set to <i>
     * crypto-keys</i>.
     * </p>
     * 
     * @param database	a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.termsAndCond:terms-conditions}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    /**
     * {@inheritDoc}
     */
    @View(name = VIEW_BY_TITLE,
        map = "function(doc) { if(doc.content.title) {emit(doc.content.title, doc._id)} }")
    public List<TermsAndCond> getByTitle(String title) {

        if (title == null) {
            throw new IllegalArgumentException("Parameter 'title' cannot be null.");
        }

        List<CouchDbTermsAndCond> records = this.proxy.getView(VIEW_BY_TITLE, title);

        return this.unwrap(records);
    }

    /**
     * {@inheritDoc}
     */
    @View(name = VIEW_BY_SCOPE,
        map = "function(doc) { if(doc.content.scope) {emit(doc.content.scope, doc._id)} }")
    public List<TermsAndCond> getByScope(String scope) {

        if (scope == null) {
            throw new IllegalArgumentException("Parameter 'scope' cannot be null.");
        }

        List<CouchDbTermsAndCond> records = this.proxy.getView(VIEW_BY_SCOPE, scope);

        return this.unwrap(records);
    }

    @Override
    public TermsAndCond addItem(TermsAndCond item) {

        if (item == null) {
            throw new IllegalArgumentException("TC record cannot be null");
        }

        if (item != null && item.getContent() != null && item.getContent().getType() != null
            && item.getContent().getType().equals(Type.EXTERNAL)) {
            cleanTcExternal(item);
        }

        return super.addItem(item);
    }

    @Override
    public TermsAndCond updateItem(TermsAndCond item) {

        if (item == null) {
            throw new IllegalArgumentException("TC record cannot be null");
        }

        if (item != null && item.getContent() != null && item.getContent().getType() != null
            && item.getContent().getType().equals(Type.EXTERNAL)) {
            cleanTcExternal(item);
        }

        return super.updateItem(item);
    }

    private void cleanTcExternal(TermsAndCond item) {

        TcExternalContent tec = MAPPER
            .convertValue(item.getContent().getData(), TcExternalContent.class);

        tec.setPayload(null);

        item.getContent().setData(tec);
    }
}
