package com.ibm.au.bgx.couch.repository;

import java.util.ArrayList;
import java.util.List;

import com.ibm.au.bgx.model.pojo.chain.FlowStatus;
import org.ektorp.support.View;
import org.ektorp.support.Views;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.ibm.au.bgx.couch.model.CouchDbApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.repository.ApprovalModelFlowRequestRepository;

/**
 * Class <b>CouchDbApprovalModelFlowRequestRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link ApprovalModelFlowRequest} and implements the interface {@link ApprovalModelFlowRequestRepository}
 * thus allowing the use of a CouhcDb database as persistent storage for the web notifications in the solution.
 * 
 * @see ApprovalModelFlowRequestRepository
 * @see ApprovalModelFlowRequest
 * 
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Repository
@Primary
@Views({
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_ORGID, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.visibleToOrgIds) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit(doc.content.visibleToOrgIds[i], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_GXREQUESTID, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.gxRequestId) {" +
                "emit(doc.content.gxRequestId, doc._id)" +
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_GUARANTEEID, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.guaranteeId) {" +
                "emit(doc.content.guaranteeId, doc._id)" +
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_STATUS, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.status) {" +
                "emit(doc.content.status, doc._id)" +
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_ORGID_GXREQUESTID, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.visibleToOrgIds && doc.content.gxRequestId) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit([doc.content.visibleToOrgIds[i], doc.content.gxRequestId], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_ORGID_GUARANTEEID, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.visibleToOrgIds && doc.content.guaranteeId) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit([doc.content.visibleToOrgIds[i], doc.content.guaranteeId], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_ORGID_STATUS, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.visibleToOrgIds && doc.content.status) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit([doc.content.visibleToOrgIds[i], doc.content.status], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_GXREQUESTID_STATUS, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.gxRequestId && doc.content.status) {" +
                "emit([doc.content.gxRequestId, doc.content.status], doc._id)" +
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_GUARANTEEID_STATUS, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.guaranteeId && doc.content.status) {" +
                "emit([doc.content.guaranteeId, doc.content.status], doc._id)" +
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_ORGID_GXREQUESTID_STATUS, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.visibleToOrgIds && doc.content.gxRequestId && doc.content.status) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit([doc.content.visibleToOrgIds[i], doc.content.gxRequestId, doc.content.status], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
        @View(name = CouchDbApprovalModelFlowRequestRepository.VIEW_BY_ORGID_GUARANTEEID_STATUS, map = "function(doc) { if(doc.cdbApprovalModelFlowRequest && doc.content.visibleToOrgIds && doc.content.guaranteeId && doc.content.status) {" +
                "for (var i=0; i<doc.content.visibleToOrgIds.length; i++) {" +
                "emit([doc.content.visibleToOrgIds[i], doc.content.guaranteeId, doc.content.status], doc._id)" +
                "}" + //for
                "}" + // if
                "}" // function
        ),
})
public class CouchDbApprovalModelFlowRequestRepository extends AbstractCouchDbRepository<CouchDbApprovalModelFlowRequest, ApprovalModelFlowRequest> implements ApprovalModelFlowRequestRepository {

    protected static final String PREFIX = "by";
    protected static final String SEPARATOR = "_";
    protected static final String ORG_ID = "orgId";
    protected static final String GX_REQUEST_ID = "gxRequestId";
    protected static final String GUARANTEE_ID = "guaranteeId";
    protected static final String STATUS = "status";

    /**
     * A {@link String} constant that maps the name of the view allowing an application
     * client to retrieve the request by organisation identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected static final String VIEW_BY_ORGID = PREFIX + SEPARATOR + ORG_ID;

    /**
     * A {@link String} constant that maps the name of the view allowing an application
     * client to retrieve the request by guarantee identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected static final String VIEW_BY_GUARANTEEID = PREFIX + SEPARATOR + GUARANTEE_ID;

    protected static final String VIEW_BY_STATUS = PREFIX + SEPARATOR + STATUS;

    protected static final String VIEW_BY_GXREQUESTID = PREFIX + SEPARATOR + GX_REQUEST_ID;

    /**
     * A {@link String} constant that maps the name of the view allowing an application
     * client to retrieve the request by organisation identifier and guarantee identifier.
     *
     * @see CouchDbRequestRepository#find(String, String, String)
     */
    protected static final String VIEW_BY_ORGID_GXREQUESTID = VIEW_BY_ORGID + SEPARATOR + GX_REQUEST_ID;
    protected static final String VIEW_BY_ORGID_GUARANTEEID = VIEW_BY_ORGID + SEPARATOR + GUARANTEE_ID;
    protected static final String VIEW_BY_ORGID_STATUS = VIEW_BY_ORGID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_GXREQUESTID_STATUS = VIEW_BY_GXREQUESTID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_GUARANTEEID_STATUS = VIEW_BY_GUARANTEEID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_ORGID_GXREQUESTID_STATUS = VIEW_BY_ORGID_GXREQUESTID + SEPARATOR + STATUS;
    protected static final String VIEW_BY_ORGID_GUARANTEEID_STATUS = VIEW_BY_ORGID_GUARANTEEID + SEPARATOR + STATUS;

    /**
     * Initialises an instance of {@link CouchDbApprovalModelFlowRequestRepository}.
     */
    public CouchDbApprovalModelFlowRequestRepository() {
        super(CouchDbApprovalModelFlowRequest.class);
    }
    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a 
     * specific configuration value the default injected value is set to <i>
     * requests</i>.
     * </p>
     * 
     * @param database	a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.requests:requests}")
    protected void setDatabase(String database) {
        this.database = database;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public List<ApprovalModelFlowRequest> find(String orgId, String gxRequestId, String guaranteeId, FlowStatus status) {
        if (orgId == null && gxRequestId == null && guaranteeId == null && status == null) {
            return getAll();
        }
        List<String> args = new ArrayList<>();
        String view = PREFIX;

        if (orgId != null) {
            args.add(orgId);
            view += SEPARATOR + ORG_ID;
        }
        if (gxRequestId != null) {
            args.add(gxRequestId);
            view += SEPARATOR + GX_REQUEST_ID;
        } else {
            // gxRequestId + guaranteeId is unsupported
            if (guaranteeId != null) {
                args.add(guaranteeId);
                view += SEPARATOR + GUARANTEE_ID;
            }
        }
        if (status != null) {
            args.add(status.value());
            view += SEPARATOR + STATUS;
        }

        List<CouchDbApprovalModelFlowRequest> result;
        if (args.size() == 1) {
            result = this.proxy.getView(view, args.get(0));
        } else {
            result = this.proxy.getView(view, args.stream().toArray(Object[]::new));
        }
        
        return this.unwrap(result);
        
        // [CV] NOTE: we don't need to replicate code, there is a utility method for 
        //            this operation.
        //
        // List<ApprovalModelFlowRequest> output = new ArrayList<>();
        // for (CouchDbApprovalModelFlowRequest entry : result) {
        //     output.add(entry.getContent());
        // }
        // return output;
    }
}
