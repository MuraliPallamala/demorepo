package com.ibm.au.bgx.couch.repository;

import com.ibm.au.bgx.couch.model.CouchDbAuditEvent;
import com.ibm.au.bgx.model.audit.AuditConstants;
import com.ibm.au.bgx.model.pojo.audit.AuditEvent;
import com.ibm.au.bgx.model.repository.AuditEventRepository;
import java.util.Arrays;
import java.util.List;
import org.ektorp.ComplexKey;
import org.ektorp.ViewQuery;
import org.ektorp.support.View;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

/**
 * Class <b>CouchDbAuditEventRepository</b>. This class specialises the {@link
 * AbstractCouchDbRepository} for instances of type {@link AuditEvent} and implements the interface
 * {@link AuditEventRepository} thus allowing the use of a CouhcDb database as persistent storage
 * for the web notifications in the solution.
 *
 * @author Peter Ilfrich <peter.ilfrich@au1.ibm.com>
 * @see AuditEventRepository
 * @see AuditEvent
 */
@Repository
@Primary
public class CouchDbAuditEventRepository extends
    AbstractCouchDbRepository<CouchDbAuditEvent, AuditEvent> implements
    AuditEventRepository {

    /**
     * A {@link String} constant that contains the name of the view that allows retrieving audit
     * events by type.
     *
     * @see CouchDbAuditEventRepository#findByType(String)
     */
    private static final String VIEW_BY_TYPE = "by_type";
    /**
     * A {@link String} constant that contains the name of the view that allows retrieving audit
     * events by organisation identifier.
     *
     * @see CouchDbAuditEventRepository#findByOrgId(String, String, String)
     */
    private static final String VIEW_BY_ORG_ID = "by_orgId";
    /**
     * A {@link String} constant that contains the name of the view that allows retrieving audit
     * events by type and organisation identifier.
     *
     * @see CouchDbAuditEventRepository#findByTypeAndOrgId(String, String, String, String)
     */
    private static final String VIEW_BY_TYPE_ORG_ID = "by_typeAndOrgId";
    private static final String VIEW_BY_USER_ID = "by_userId";
    private static final String VIEW_BY_GUARANTEE_ID = "by_guaranteeId";
    private static final String VIEW_BY_TARGET_ORG_ID = "by_targetOrgId";
    private static final String VIEW_BY_TYPE_TARGET_ORG_ID = "by_typeTargetOrgId";

    /**
     * Initialises an instance of {@link CouchDbAuditEventRepository}.
     */
    public CouchDbAuditEventRepository() {
        super(CouchDbAuditEvent.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured value specified in
     * the {@link Value} annotation. In the absence of a specific configuration value the default
     * injected value is set to <i> audit-events</i>.
     * </p>
     *
     * @param database a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.auditEvents:audit-events}")
    protected void setDatabase(String database) {
        this.database = database;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_TYPE, map = "function(doc) { if(doc.content.type) {emit(doc.content.type, doc._id)} }")
    public List<AuditEvent> findByType(String type) {
        
    	List<CouchDbAuditEvent> events = this.proxy.getView(VIEW_BY_TYPE, type);
        return this.unwrap(events);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_TYPE_ORG_ID, map = "function(doc) { if(doc.content.orgId && doc.content.type) {emit([doc.content.type, doc.content.orgId, doc.content.createdAt], doc._id)} }")
    public List<AuditEvent> findByTypeAndOrgId(String type, String orgId, String beforeDate, String afterDate) {

        return this.queryView(VIEW_BY_TYPE_ORG_ID, beforeDate, afterDate, type, orgId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_ORG_ID, map = "function(doc) { if(doc.content.orgId) {emit([doc.content.orgId, doc.content.createdAt], doc._id)} }")
    public List<AuditEvent> findByOrgId(String orgId, String beforeDate, String afterDate) {

        return this.queryView(VIEW_BY_ORG_ID, beforeDate, afterDate, orgId);
    }

    @Override
    @View(name = VIEW_BY_USER_ID, map = "function(doc) { if (doc.content.userId && doc.content.orgId) { emit([doc.content.orgId, doc.content.userId, doc.content.createdAt], doc._id) } }")
    public List<AuditEvent> findByUser(String orgId, String userId, String beforeDate, String afterDate) {

        return this.queryView(VIEW_BY_USER_ID, beforeDate, afterDate, orgId, userId);
    }

    @Override
    @View(name = VIEW_BY_GUARANTEE_ID, map =
        "function(doc) { if (doc.content.data) { Object.keys(doc.content.data).forEach(function(key) { if (doc.content.data[key]['type'] == '"
            + AuditConstants.GUARANTEE
            + "') { emit([doc.content.data[key]['id'], doc.content.createdAt], doc._id) } }) } }")
    public List<AuditEvent> findByGuarantee(String gxId, String beforeDate, String afterDate) {

        return this.queryView(VIEW_BY_GUARANTEE_ID, beforeDate, afterDate, gxId);
    }

    @Override
    @View(name = VIEW_BY_TARGET_ORG_ID, map = "function(doc) { if (doc.content.data && doc.content.data.organization) { emit([doc.content.data.organization, doc.content.createdAt], doc._id) } }")
    public List<AuditEvent> findByTargetOrgId(String targetOrgId, String beforeDate, String afterDate) {

        return this.queryView(VIEW_BY_TARGET_ORG_ID, beforeDate, afterDate, targetOrgId);
    }

    @Override
    @View(name = VIEW_BY_TYPE_TARGET_ORG_ID, map = "function(doc) { if (doc.content.data && doc.content.data.organization) { emit([doc.content.type, doc.content.data.organization, doc.content.createdAt], doc._id) } }")
    public List<AuditEvent> findByTypeAndTargetOrgId(String type, String targetOrgId, String beforeDate, String afterDate) {
        return this.queryView(VIEW_BY_TARGET_ORG_ID, beforeDate, afterDate, type, targetOrgId);
    }

    protected List<AuditEvent> queryView(String viewName, String beforeDate, String afterDate,
                                         String... keys) {

        ComplexKey startKey = this.createComplexKey(afterDate, keys);
        ComplexKey endKey = this.createComplexKey(beforeDate, keys);

        if (beforeDate == null) {
            // needs to be rendered to "[orgId, {}]"
            Object[] keyValues = new Object[keys.length + 1];
            int index = 0;
            for (String key : keys) {
                keyValues[index] = key;
                index += 1;
            }
            keyValues[index] = ComplexKey.emptyObject();
            endKey = ComplexKey.of(keyValues);
        }
        if (afterDate == null) {
            // this will become [orgId, null]
            startKey = this.createComplexKey(null, keys);
        }

        ViewQuery query = new ViewQuery()
            .designDocId(String.format("_design/%s", CouchDbAuditEvent.class.getSimpleName()))
            .viewName(viewName)
            .startKey(startKey)
            .endKey(endKey)
            .includeDocs(true);

        List<CouchDbAuditEvent> events = this.proxy.getView(query);
        return this.unwrap(events);
    }

    protected ComplexKey createComplexKey(String date, String... keys) {
    	
        if (date != null) {
            String[] params = Arrays.copyOf(keys, keys.length + 1);
            // append date to key
            params[params.length - 1] = date;
            return ComplexKey.of(params);
        }

        return ComplexKey.of(keys);
    }

    // making sure, that we don't store the user name or org name, but just the id

    @Override
    public AuditEvent addItem(AuditEvent item) {
        item.setUserName(null);
        item.setOrgName(null);
        return super.addItem(item);
    }

    @Override
    public AuditEvent updateItem(AuditEvent item) {
        item.setUserName(null);
        item.setOrgName(null);
        return super.updateItem(item);
    }
}
