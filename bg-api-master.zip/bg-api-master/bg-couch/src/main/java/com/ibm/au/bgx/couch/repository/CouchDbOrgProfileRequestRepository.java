package com.ibm.au.bgx.couch.repository;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.couch.model.CouchDbOrgProfileRequest;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.repository.OrgProfileRequestRepository;

import java.util.List;
import org.ektorp.support.View;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

/**
 * Class <b>CouchDbOrgProfileRequestRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link OrgProfileRequest} and implements the interface {@link OrgProfileRequestRepository} 
 * thus allowing the use of a CouhcDb database as persistent storage for the web notifications in the solution.
 * 
 * @see OrgProfileRequestRepository
 * @see OrgProfileRequest
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * 
 */
@Repository
@Primary
public class CouchDbOrgProfileRequestRepository extends
    AbstractCouchDbRepository<CouchDbOrgProfileRequest, OrgProfileRequest> implements
    OrgProfileRequestRepository {

	/**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the profile requests by business identifier.
	 * 
	 * @see CouchDbOrgProfileRequestRepository#getByBusinessId(String,String)
	 */
    public static final String VIEW_BY_BUSINESS_ID = "by_businessId";

	/**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the profile requests by business identifier and status.
	 * 
	 * @see CouchDbOrgProfileRequestRepository#getByBusinessId(String,String,Status)
	 */
    public static final String VIEW_BY_BUSINESS_ID_STATUS = "by_businessIdAndStatus";

	/**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the profile requests by onboarding key.
	 * 
	 * @see CouchDbOrgProfileRequestRepository#getByOnboardingKey(String)
	 */
    public static final String VIEW_BY_ONBOARDING_KEY = "by_onboardingKey";

	/**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the profile requests by referral token.
	 * 
	 * @see CouchDbOrgProfileRequestRepository#getByReferralToken(String)
	 */
    public static final String VIEW_BY_REFERRAL_TOKEN = "by_referralToken";

	/**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the profile requests by referrer identifier.
	 * 
	 * @see CouchDbOrgProfileRequestRepository#getByReferralId(String)
	 */
    public static final String VIEW_BY_REFERRER_ID = "by_referrerId";
    
	/**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the profile requests by referrer identifier and status.
	 * 
	 * @see CouchDbOrgProfileRequestRepository#getByReferralIdAndStatus(String, Status)
	 */
    public static final String VIEW_BY_REFERRER_ID_STATUS = "by_referrerIdAndStatus";

	/**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the profile requests whose is status is set for review.
	 * 
	 * @see CouchDbOrgProfileRequestRepository#getForReview(Status)
	 */
    public static final String VIEW_BY_STATUS_FOR_REVIEW = "by_statusForReview";

	/**
	 * A {@link String} constant that contains the name of the view that allows
	 * retrieving the profile requests by status.
	 * 
	 * @see CouchDbOrgProfileRequestRepository#getByStatus(Status)
	 */
    public static final String VIEW_BY_STATUS = "by_status";
	
	/**
	 * Initialises an instance of the {@link CouchDbOrgProfileRequestRepository}.
	 */
    public CouchDbOrgProfileRequestRepository() {
        super(CouchDbOrgProfileRequest.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a 
     * specific configuration value the default injected value is set to <i>
     * org-profile-requests</i>.
     * </p>
     * 
     * @param database	a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.orgProfileRequests:org-profile-requests}")
    protected void setDatabase(String database) {
        this.database = database;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_BUSINESS_ID,
        map = "function(doc) { if(doc.content.profile) {emit([doc.content.referrer.id, doc.content.profile.businessId], doc._id)} }")
    public List<OrgProfileRequest> getByBusinessId(String referrerId, String bid) {

        if (referrerId == null || referrerId.isEmpty() || bid == null || bid.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'referrerId' and 'bid' cannot be null or and empty string.");
        }

        List<CouchDbOrgProfileRequest> cdbRequests = this.proxy.getView(CouchDbOrgProfileRequestRepository.VIEW_BY_BUSINESS_ID, referrerId, bid);

        return this.unwrap(cdbRequests);

    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_BUSINESS_ID_STATUS,
        map = "function(doc) { if(doc.content.profile) {emit([doc.content.referrer.id, doc.content.profile.businessId, doc.content.status], doc._id)} }")
    public List<OrgProfileRequest> getByBusinessId(String referrerId, String bid, Status status) {

        if (referrerId == null || referrerId.isEmpty() || bid == null || bid.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'referrerId', 'bid' and cannot be null or an empty string.");
        }
        
        if (status == null) {
        	throw new IllegalArgumentException("Parameter 'status' cannot be null.");
        }

        List<CouchDbOrgProfileRequest> cdbRequests = this.proxy.getView(CouchDbOrgProfileRequestRepository.VIEW_BY_BUSINESS_ID_STATUS, referrerId, bid, status);

        return this.unwrap(cdbRequests);

    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_ONBOARDING_KEY,
        map = "function(doc) { if(doc.content.credentials) {emit(doc.content.credentials.key, doc._id)} }")
    public OrgProfileRequest getByOnboardingKey(String key) {

        if (key == null || key.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'key' cannot be null or an empty string.");
        }

        List<CouchDbOrgProfileRequest> cdbRequests = this.proxy.getView(CouchDbOrgProfileRequestRepository.VIEW_BY_ONBOARDING_KEY, key);

        return this.unwrapOne(cdbRequests, key);


    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_REFERRAL_TOKEN,
        map = "function(doc) { if(doc.content.referrer.referrerToken) {emit(doc.content.referrer.referrerToken, doc._id)} }")
    public OrgProfileRequest getByReferralToken(String referralToken) {
        if (referralToken == null) {
            throw new IllegalArgumentException("Parameter 'referralToken' cannot be null.");
        }

        List<CouchDbOrgProfileRequest> cdbRequests = this.proxy.getView(CouchDbOrgProfileRequestRepository.VIEW_BY_REFERRAL_TOKEN, referralToken);

        return this.unwrapOne(cdbRequests, referralToken);

    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_REFERRER_ID,
        map = "function(doc) { if(doc.content.referrer.id) {emit(doc.content.referrer.id, doc._id)} }")
    public List<OrgProfileRequest> getByReferrerId(String referrerId) {
    	
        if (referrerId == null || referrerId.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'referrerId' cannot be null or an empty string.");
        }


        List<CouchDbOrgProfileRequest> cdbRequests = this.proxy.getView(CouchDbOrgProfileRequestRepository.VIEW_BY_REFERRER_ID, referrerId);

        return this.unwrap(cdbRequests);

    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_STATUS_FOR_REVIEW,
        map = "function(doc) { if(doc.content.status !== 'DRAFTED') {emit(doc.content.status, doc._id)} }")
    public List<OrgProfileRequest> getForReview(Status status) {

        String stringValue = null;
        if (status != null) {
            stringValue = status.toString();
        }

        List<CouchDbOrgProfileRequest> cdbRequests = this.proxy.getView(CouchDbOrgProfileRequestRepository.VIEW_BY_STATUS_FOR_REVIEW, stringValue);

        return this.unwrap(cdbRequests);

    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_STATUS,
        map = "function(doc) { if(doc.content.status) {emit(doc.content.status, doc._id)} }")
    public List<OrgProfileRequest> getByStatus(Status status) {

        if (status == null) {
            throw new IllegalArgumentException("Parameter 'status' cannot be null.");
        }


        List<CouchDbOrgProfileRequest> cdbRequests = this.proxy.getView(CouchDbOrgProfileRequestRepository.VIEW_BY_STATUS, status.toString());

        return this.unwrap(cdbRequests);

    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_REFERRER_ID_STATUS, map = "function(doc) { if(doc.content.referrer.id && doc.content.status) {emit([doc.content.referrer.id, doc.content.status], doc._id)} }")
    public List<OrgProfileRequest> getByReferrerIdAndStatus(String referrerId, Status status) {
        
    	if (referrerId == null || referrerId.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'referrerId' cannot be null or an empty string.");
        }
        if (status == null) {
            throw new IllegalArgumentException("Parameter 'status' cannot be null.");
        }

        List<CouchDbOrgProfileRequest> cdbRequests = this.proxy.getView(CouchDbOrgProfileRequestRepository.VIEW_BY_REFERRER_ID_STATUS, referrerId, status.toString());

        return this.unwrap(cdbRequests);

    }
}
