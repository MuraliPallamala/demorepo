package com.ibm.au.bgx.couch.repository;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import java.util.List;

import org.ektorp.support.View;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.ibm.au.bgx.couch.model.CouchDbOrganization;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.repository.OrganizationRepository;

/**
 * Class <b>CouchDbOrganizationRepository</b>. This class specialises the {@link AbstractCouchDbRepository}
 * for instances of type {@link Organization} and implements the interface {@link OrganizationRepository}
 * thus allowing the use of a CouhcDb database as persistent storage for the web notifications in the solution.
 * 
 * @see OrganizationRepository
 * @see Organization
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Repository
@Primary
public class CouchDbOrganizationRepository 
		extends AbstractCouchDbRepository<CouchDbOrganization, Organization> 
		implements OrganizationRepository {

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * organisations by business identifier.
     * 
     * @see CouchDbOrganizationRepository#getByBusinessId(String)
	 */
    public static final String VIEW_BY_BUSINESS_ID = "by_businessId";

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * organisations by entity name.
     * 
     * @see CouchDbOrganizationRepository#getByEntityName(String)
	 */
    public static final String VIEW_BY_ENTITY_NAME = "by_entityName";

    /**
     * A {@link String} constant that contains the name of the view that allows retrieving
     * organisations by entity type.
     *
     * @see CouchDbOrganizationRepository#getByEntityType(EntityType)
     */
    public static final String VIEW_BY_ENTITY_TYPE= "by_entityType";

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * organisations by the URL of JWT token issuer for a given organisation for user
	 * authentication.
     * 
     * @see CouchDbOrganizationRepository#getByUserAuthJwtIssuer(String)
	 */
    public static final String VIEW_BY_USER_AUTH_ISSUER = "by_userAuthIssuer";

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * organisations by the URL of JWT token issuer for a given organisation for API
	 * authentication.
     * 
     * @see CouchDbOrganizationRepository#getByApiAuthJwtIssuer(String)
	 */
    public static final String VIEW_BY_API_AUTH_ISSUER = "by_apiAuthIssuer";

	/**
	 * A {@link String} constant that contains the name of the view that allows retrieving
	 * organisations by login key.
     * 
     * @see CouchDbOrganizationRepository#getByKey(String)
	 */
    public static final String VIEW_BY_KEY = "by_key";
    
    /**
     * Initialises an instance of {@link CouchDbOrganizationRepository}.
     */
    public CouchDbOrganizationRepository() {
        super(CouchDbOrganization.class);
    }

    /**
     * <p>
     * Sets the name of the CouchDb database that will be used this repository.
     * </p>
     * <p>
     * This method is also used by the Spring runtime to inject the configured
     * value specified in the {@link Value} annotation. In the absence of a 
     * specific configuration value the default injected value is set to <i>
     * organizations</i>.
     * </p>
     * 
     * @param database	a {@link String} containing the name of the database.
     */
    @Override
    @Value("${couchdb.database.organizations:organizations}")
    protected void setDatabase(String database) {
        this.database = database;
    }




    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_BUSINESS_ID,
        map = "function(doc) { if(doc.content.profile) {emit(doc.content.profile.businessId, doc._id)} }")
    public List<Organization> getByBusinessId(String bid) {

        if (bid == null) {
            throw new IllegalArgumentException("Parameter 'bid' cannot be null.");
        }

        return this.getFromView(VIEW_BY_BUSINESS_ID, bid, true);
    }




    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_ENTITY_NAME,
        map = "function(doc) { if(doc.content.profile.entityName) {emit(doc.content.profile.entityName, doc._id)} }")
    public List<Organization> getByEntityName(String name) {

        if (name == null) {
            throw new IllegalArgumentException("Parameter 'name' cannot be null.");
        }

        return this.getFromView(VIEW_BY_ENTITY_NAME, name, true);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_ENTITY_TYPE,
        map = "function(doc) { if(doc.content.profile.entityType) {emit(doc.content.profile.entityType, doc._id)} }")
    public List<Organization> getByEntityType(EntityType type) {

        if (type == null) {
            throw new IllegalArgumentException("Parameter 'type' cannot be null.");
        }

        return this.getFromView(VIEW_BY_ENTITY_TYPE, type.value(), false);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_API_AUTH_ISSUER,
        map = "function(doc) { if(doc.content.settings.apiAuth) {emit(doc.content.settings.apiAuth.issuer, doc._id)} }")
    public List<Organization> getByApiAuthJwtIssuer(String iss) {
        if (iss == null) {
            throw new IllegalArgumentException("Parameter 'iss' cannot be null.");
        }

        return this.getFromView(VIEW_BY_API_AUTH_ISSUER, iss, false);
    }



    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_USER_AUTH_ISSUER,
        map = "function(doc) { if(doc.content.settings.userAuth) {emit(doc.content.settings.userAuth.issuer, doc._id)} }")
    public List<Organization> getByUserAuthJwtIssuer(String iss) {
        if (iss == null) {
            throw new IllegalArgumentException("Parameter 'iss' cannot be null.");
        }

        return this.getFromView(VIEW_BY_USER_AUTH_ISSUER, iss, false);
    }



    /**
     * {@inheritDoc}
     */
    @Override
    @View(name = VIEW_BY_KEY,
        map = "function(doc) { if(doc.content.settings.key) {emit(doc.content.settings.key, doc._id)} }")
    public Organization getByKey(String key) {
    	
        if (key == null) {
            throw new IllegalArgumentException("Parameter 'key' cannot be null.");
        }

        List<Organization> records = this.getFromView(VIEW_BY_KEY, key, false);
        
        return this.getOne(records, key);
        
        // [CV] NOTE: we should not duplicate code, we have an utility method for it.
        //
        // if (records.size() == 1) {
        //    return records.get(0);
        // }
        //
        // if (records.size() > 1) {
        //    throw new IllegalStateException(String.format("Multiple records found for the same key: %s", key));
        // }
        // return null;
    }

}
