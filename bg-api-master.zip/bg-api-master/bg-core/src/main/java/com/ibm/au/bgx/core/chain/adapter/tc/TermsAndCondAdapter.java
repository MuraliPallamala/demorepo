package com.ibm.au.bgx.core.chain.adapter.tc;

import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditions;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditions.Builder;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditionsScope;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * A implementation of adapter interface {@link ChainDataAdapter} to perform on-chain and off-chain
 * data model conversion for terms and conditions record
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class TermsAndCondAdapter implements ChainDataAdapter<TermsConditions, TermsAndCond> {

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    TcContentAdapter contentAdapter;

    /**
     * Map of TermsAndCond off-chain scope to on-chain scope values
     * In off-chain we keep scope as string, but on-chain it is a number
     */
    public static final Map<TermsAndCond.Scope, TermsConditionsScope> ONCHAIN_SCOPE_MAP = new HashMap<>();
    public static final Map<TermsConditionsScope, TermsAndCond.Scope> OFFCHAIN_SCOPE_MAP = new HashMap<>();

    // initialize the scope mapping
    static {

        // create TC scope mapping from off-chain to on-chain
        ONCHAIN_SCOPE_MAP.put(Scope.PLATFORM, TermsConditionsScope.PLATFORM);
        ONCHAIN_SCOPE_MAP.put(Scope.BANK_GUARANTEE, TermsConditionsScope.BANK_GUARANTEE);
        ONCHAIN_SCOPE_MAP.put(Scope.USER, TermsConditionsScope.USER);

        // reverse ONCHAIN_SCOPE_MAP for its off-chain counter part
        for (Map.Entry<TermsAndCond.Scope, TermsConditionsScope> entry : ONCHAIN_SCOPE_MAP
            .entrySet()) {
            OFFCHAIN_SCOPE_MAP.put(entry.getValue(), entry.getKey());
        }
    }


    @Override
    public TermsConditions toOnChainModel(TermsAndCond tc) {
        if (tc == null) {
            throw new IllegalArgumentException("Input TermsAndCond cannot be null");
        }

        if (!ONCHAIN_SCOPE_MAP.containsKey(tc.getScope())) {
            throw new IllegalArgumentException(
                String.format("Invalid T&C scope. No mapping for scope found.", tc.getScope()));

        }

        Builder b = TermsConditions.newBuilder();
        if (tc.getId() == null) {
            tc.setId(UUID.randomUUID().toString());
        }
        b.setId(tc.getId());
        b.setTitle(tc.getTitle());
        b.setScope(ONCHAIN_SCOPE_MAP.get(tc.getScope()));
        b.setContent(contentAdapter.toOnChainModel(tc.getContent()));

        return b.build();
    }

    @Override
    public TermsAndCond toOffchainModel(TermsConditions tcChain) {

        if (tcChain == null) {
            throw new IllegalArgumentException("Input TermsConditions cannot be null");
        }

        if (!OFFCHAIN_SCOPE_MAP.containsKey(tcChain.getScope())) {
            throw new IllegalArgumentException(
                String.format("Invalid T&C scope. No mapping for scope found.", tcChain.getScope()));

        }

        TermsAndCond tc = new TermsAndCond();

        tc.setId(tcChain.getId());
        tc.setTitle(tcChain.getTitle());

        if (tcChain.getScope() != null) {
            tc.setScope(OFFCHAIN_SCOPE_MAP.get(tcChain.getScope()));
        }

        if (tcChain.getContent() != null) {
            tc.setContent(contentAdapter.toOffchainModel(tcChain.getContent()));
        }

        tc.setCreatedAt(timestampDataAdapter.toOffchainModel(tcChain.getCreatedAt()));
        tc.setCreatedBy(tcChain.getCreatedBy());

        if (tcChain.getUpdatedAt() != null) {
            tc.setUpdatedAt(timestampDataAdapter.toOffchainModel(tcChain.getUpdatedAt()));
        }

        tc.setUpdatedBy(tcChain.getUpdatedBy());

        return tc;
    }
}
