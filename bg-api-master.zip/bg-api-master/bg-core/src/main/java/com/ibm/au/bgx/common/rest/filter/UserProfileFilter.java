package com.ibm.au.bgx.common.rest.filter;

import com.ibm.au.bgx.model.pojo.Credentials;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Component;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@Component
public class UserProfileFilter extends AbstractApiEntityFilter<UserProfile> {

    @Override
    public UserProfile filterOne(UserProfile item, BgxPrincipal principal) {

        if (item == null) {
            return null;
        }

        // filter out unnecessary info
        // list of allowed auth token is only for internal purposes and user does not need to know
        item.setAllowedAuthTokens(null);
        item.setApiKeys(null);

        // we don't filter anything else for newco and newco-admin users
        if (principal != null && principal.isConsortiumUser()) {
            return item;
        }

        if (principal != null) {

            // keep the user role relevant to principal's org
            Map<String, List<String>> userRoles = new HashMap<>();
            if (item.getUserRoles() != null && item.getUserRoles().containsKey(principal.getConfiguredForOrgId())) {
                userRoles.put(principal.getConfiguredForOrgId(), item.getUserRoles().get(principal.getConfiguredForOrgId()));
            }
            item.setUserRoles(userRoles);

            // keep the user gx limit relevant to principal's org
            Map<String, BigInteger> gxLimit = new HashMap<>();
            if (item.getGxLimit() != null && item.getGxLimit().containsKey(principal.getConfiguredForOrgId())) {
                gxLimit.put(principal.getConfiguredForOrgId(), item.getGxLimit().get(principal.getConfiguredForOrgId()));
            }
            item.setGxLimit(gxLimit);

            // filter credential
            Credentials credentials = new Credentials();
            if (!principal.isAdminForOrg(principal.getConfiguredForOrgId())
                && item.getCredentials() != null) {
                // admin only needs to know the users token
                credentials.setToken(item.getCredentials().getToken());
                credentials.setCreatedAt(item.getCredentials().getCreatedAt());
            }
            item.setCredentials(credentials);

            return item;
        }

        // filter out when principal is not specified
        item.setCredentials(null);
        item.setUserRoles(null);
        item.setGxLimit(null);

        return item;
    }
}
