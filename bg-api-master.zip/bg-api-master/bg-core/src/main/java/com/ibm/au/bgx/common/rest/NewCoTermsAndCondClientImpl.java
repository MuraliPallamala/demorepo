package com.ibm.au.bgx.common.rest;

import com.ibm.au.bgx.model.api.NewCoTermsAndCondClient;
import com.ibm.au.bgx.model.api.PaginatedResponse;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.pojo.tc.TcExternalContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import java.util.ArrayList;
import java.util.List;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@Component
public class NewCoTermsAndCondClientImpl extends AbstractNewCoAdminClient implements
    NewCoTermsAndCondClient {

    private static final String BASE_URL = "/platform/terms-and-conditions";

    public String getUrl(String title, String type) {
        String url = getBaseUrl() + BASE_URL;

        List<String> queryParameter = new ArrayList<>();
        if (title != null) {
            queryParameter.add(String.format("title=%s", title));
        }
        if (type != null) {
            queryParameter.add(String.format("type=%s", type));
        }

        if (queryParameter.size() > 0) {
            url += String.format("?%s", String.join("&", queryParameter));
        }

        return url;
    }

    public String getBaseUrl() {
        String url = super.getBaseUrl() + BASE_URL;
        return url;
    }

    @Override
    public PaginatedResponse<TermsAndCond> getAll(String title, String type) throws Exception {
        String url = this.getUrl(title, type);
        RestTemplate rest = this.getRestTemplate(url);

        HttpHeaders headers = getHeaders();
        HttpEntity<String> request = new HttpEntity<>(title, headers);

        ResponseEntity<PaginatedResponse<TermsAndCond>> response = rest
            .exchange(url, HttpMethod.GET, request,
                new ParameterizedTypeReference<PaginatedResponse<TermsAndCond>>() {
                });

        return response.getBody();
    }

    @Override
    public TcExternalContent getDocumentPayload(String id) throws Exception {
        String url = String.format("%s/%s/document", getBaseUrl(), id);
        RestTemplate rest = this.getRestTemplate(url);

        HttpHeaders headers = getHeaders();
        HttpEntity<String> request = new HttpEntity<>(headers);

        try {
            ResponseEntity<TcExternalContent> response = rest
                .exchange(url, HttpMethod.GET, request, TcExternalContent.class);

            return response.getBody();
        } catch (HttpClientErrorException e) { // FIXME need to handle API errors properly
            if (e.getRawStatusCode() == HttpStatus.NOT_FOUND.value()) {
                throw new DataNotFoundException(String
                    .format("Record not found with id: %s", id));
            }

            throw e;
        }
    }

    @Override
    public TermsAndCond getById(String id) throws Exception {

        String url = String.format("%s/%s", getBaseUrl(), id);
        RestTemplate rest = this.getRestTemplate(url);

        HttpHeaders headers = getHeaders();
        HttpEntity<String> request = new HttpEntity<>(headers);

        try {
            ResponseEntity<TermsAndCond> response = rest
                .exchange(url, HttpMethod.GET, request, TermsAndCond.class);

            return response.getBody();
        } catch (HttpClientErrorException e) { // FIXME need to handle API errors properly
            if (e.getRawStatusCode() == HttpStatus.NOT_FOUND.value()) {
                throw new DataNotFoundException(String
                    .format("Record not found with id: %s", id));
            }

            throw e;
        }
    }
}
