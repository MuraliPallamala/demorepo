package com.ibm.au.bgx.core.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.util.ErrorCodeUtil;
import com.ibm.au.bgx.common.util.ErrorCodeUtil.ErrorTopic;
import com.ibm.au.bgx.core.cache.OrgCache;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.chain.FlowStatus;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxActionApprovePayload;
import com.ibm.au.bgx.model.pojo.gx.GxActionType;
import com.ibm.au.bgx.model.pojo.gx.GxAmendPayload;
import com.ibm.au.bgx.model.pojo.gx.GxCancelPayload;
import com.ibm.au.bgx.model.pojo.gx.GxDemandPayload;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxOrgType;
import com.ibm.au.bgx.model.pojo.gx.GxPayWalkPayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.gx.GxStatusType;
import com.ibm.au.bgx.model.pojo.gx.GxTransferPayload;
import com.ibm.au.bgx.model.pojo.purpose.PurposeField;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;
import com.ibm.au.bgx.model.purpose.PurposeFormatManager;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.math.BigInteger;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * 
 * @author fl0yd
 *
 */
// TODO refactor the explicit caching to instead use Spring Caching implicitly https://spring.io/guides/gs/caching/
@Component
public class GxValidatorImpl implements GxValidator {


    /**
     * A {@link ObjectMapper} implementation that is used serialise/deserialise entities
     * into their corresponding JSON representation for the purpose of verification.
     */
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();


    /**
     * 
     */
    private static final String ERROR_NOT_PART_OF_GX_REQUEST = "Org is not part of GxRequest";

    /**
     * 
     */
    private static final String ERROR_GX_NOT_ACTIVE = "Guarantee is not active";

    /**
     * 
     */
    @Autowired
    protected OrgCache orgCache;

    /**
     * 
     */
    @Autowired
    protected TermsAndCondManager termsAndCondManager;

    /**
     * 
     */
    @Autowired
    protected PurposeFormatManager purposeFormatManager;


    /**
     * {@inheritDoc}
     */
    @Override
    public void validateGxRequest(GxRequest gxRequest, BgxPrincipal principal, Gx gx) throws IllegalArgumentException, GuaranteeForbiddenException {

        if (gxRequest == null) {
            throw new IllegalArgumentException("GxRequest cannot be null.");
        }

        if (principal == null) {
            throw new IllegalArgumentException("Principal cannot be null.");
        }

        if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
        	
        	if (gx != null) {
        		throw new IllegalArgumentException(String.format("ISSUE requests cannot have an existing guaranteed (id: %s).", gx.getId()));
        	}
        	
            // Issue requests
            if (!this.isPartOfGxRequest(gxRequest, principal, gx)) {
                throw new GuaranteeForbiddenException(GxValidatorImpl.ERROR_NOT_PART_OF_GX_REQUEST);
            }
            this.validateGxIssue(gxRequest, principal);
            
        } else {
        	
            // Non-Issue requests
            if (gx == null) {
                throw new IllegalArgumentException("Gx cannot be null for non issue requests.");
            }

            if (!this.isPartOfGxRequest(gxRequest, principal, gx)) {
                throw new GuaranteeForbiddenException(GxValidatorImpl.ERROR_NOT_PART_OF_GX_REQUEST);
            }

            if (!gx.getStatus().equals(GxStatusType.ACTIVE)) {
                throw new GuaranteeForbiddenException(GxValidatorImpl.ERROR_GX_NOT_ACTIVE);
            }

            if (!this.validateNoExistingSameRequestType(gxRequest, gx, principal)) {
                throw new GuaranteeForbiddenException(String.format("There is an existing %s %s gx request. Cannot create another.", FlowStatus.ACTIVE, gxRequest.getType()));
            }

            switch (gxRequest.getType()) {
                case AMEND:
                    this.validateGxAmend(gxRequest, principal, gx);
                    break;
                case DEMAND:
                    this.validateGxDemand(gxRequest, principal, gx);
                    break;
                case CANCEL:
                    this.validateGxCancel(gxRequest, principal, gx);
                    break;
                case PAYWALK:
                    this.validateGxPaywalk(gxRequest, principal, gx);
                    break;
                case TRANSFER:
                    this.validateGxTransfer(gxRequest, principal, gx);
                    break;
                case EXPIRE:
                    // No validation
                    break;
                default:
                    // No validation
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateGxAction(GxAction gxAction, BgxPrincipal principal, Gx gx, GxRequest gxRequest, List<GxAction> externalActions) throws IllegalArgumentException, GuaranteeForbiddenException {

        if (gxAction == null) {
            throw new IllegalArgumentException("GxAction cannot be null.");
        }

        if (principal == null) {
            throw new IllegalArgumentException("Principal cannot be null.");
        }

        if (gxRequest == null) {
            throw new IllegalArgumentException("GxRequest cannot be null.");
        }

        if (externalActions == null) {
            throw new IllegalArgumentException("Actions cannot be null.");
        }

        if (!gxRequest.getStatus().equals(FlowStatus.ACTIVE)) {
            String message = String.format("Cannot perform action, as the request is no longer active. The guarantee request status is %s", gxRequest.getStatus().toString().toLowerCase());
            int codeBase;
            switch (gxRequest.getStatus()) {
                case APPROVED:
                    codeBase = ErrorCodeUtil.NON_ACTIVE_APPROVED_REQUEST_ACTION;
                    break;
                case CANCELLED:
                    codeBase = ErrorCodeUtil.NON_ACTIVE_CANCELLED_REQUEST_ACTION;
                    break;
                case REJECTED:
                    codeBase = ErrorCodeUtil.NON_ACTIVE_REJECTED_REQUEST_ACTION;
                    break;
                case WITHDRAWN:
                    codeBase = ErrorCodeUtil.NON_ACTIVE_WITHDRAWN_REQUEST_ACTION;
                    break;
                case EXPIRED:
                    codeBase = ErrorCodeUtil.NON_ACTIVE_EXPIRED_REQUEST_ACTION;
                    break;
                default:
                    codeBase = ErrorCodeUtil.NON_ACTIVE_UNKNOWN_REQUEST_ACTION;
            }
            BigInteger code = ErrorCodeUtil.getPrefixedErrorCode(ErrorTopic.BANK_GUARANTEE, codeBase);

            throw new GuaranteeForbiddenException(message, code);
        }

        if (gx == null) {
            if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
                // Use issue payload as GX for issue requests
                gx = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
            } else {
                throw new IllegalArgumentException("Gx cannot be null for non issue requests");
            }
        } else {
            if (!gx.getStatus().equals(GxStatusType.ACTIVE)) {
                throw new GuaranteeForbiddenException(GxValidatorImpl.ERROR_GX_NOT_ACTIVE);
            }
        }

        if (!this.isPartOfGxRequest(gxRequest, principal, gx)) {
            throw new GuaranteeForbiddenException(GxValidatorImpl.ERROR_NOT_PART_OF_GX_REQUEST);
        }

        switch (gxAction.getType()) {
            case APPROVE:
                this.validateGxActionApprove(gxAction, principal, gx, gxRequest, externalActions);
                break;
            case REJECT:
                this.validateGxActionReject(gxAction, principal, gx, gxRequest, externalActions);
                break;
            case CANCEL:
                this.validateGxActionCancel(gxAction, principal, gx, gxRequest, externalActions);
                break;
            case REVOKE:
                this.validateGxActionRevokeApprove(gxAction, principal, gx, gxRequest, externalActions);
                break;
            case DEFER:
                this.validateGxActionDefer(gxAction, principal, gx, gxRequest, externalActions);
                break;

            default:
                throw new IllegalArgumentException("Unknown type");
        }
    }

    /**
     * 
     * @param purposeType
     * @param purpose
     * @param isAmend
     */
    protected void validatePurpose(String purposeType, Map<String, Object> purpose, boolean isAmend) {
    	
        PurposeFormat format = this.purposeFormatManager.get(purposeType);
        if (format == null || (format.getActive() == false && !isAmend)) {
            throw new IllegalArgumentException("Purpose type is invalid or inactive.");
        }

        if (isAmend && purpose == null) {
            // purpose hasn't changed, skip purpose validation
            return;
        }

        this.validatePurposeFields(purpose, format.getFields(), isAmend);
    }

    /**
     * 
     * @param purpose
     * @param fields
     * @param isAmend
     */
    @SuppressWarnings("unchecked")
	protected void validatePurposeFields(Map<String, Object> purpose, List<PurposeField> fields, boolean isAmend) {
    	
        for (PurposeField field : fields) {
            
            // general check for field existence
            if (!isAmend && !field.getOptional() && !purpose.containsKey(field.getName())) {
                throw new IllegalArgumentException(String.format("Field %s is missing in the purpose payload", field.getName()));
            }
            
            if (field.getType().equals(PurposeField.Type.OBJECT)) {
                // validate complex field
                if (purpose.containsKey(field.getName())) {
                    // validate sub fields of complex field
                    this.validatePurposeFields((Map<String, Object>) purpose.get(field.getName()), field.getSubFields(), isAmend);
                }
            } else {
                // skip missing payload in amend requests and filter out optional fields, where the value is not provided
                if (!purpose.containsKey(field.getName()) && (isAmend || field.getOptional())) {
                    continue;
                }

                // parse constraints and validate field
                for (Object constraintRaw : field.getConstraints()) {
                    purposeFormatManager.validatePurposeFieldConstraint(constraintRaw, field, purpose);
                }
            }
        }
    }


    /**
     * Validate Gx Issue
     *
     * @throws IllegalArgumentException if required params are null or empty
     * @throws GuaranteeForbiddenException if there is any validation error
     */
    private void validateGxIssue(GxRequest gxRequest, BgxPrincipal principal) {
    	
        if (gxRequest.getPayload() == null) {
            throw new IllegalArgumentException("Issue payload cannot be null");
        }

        GxIssuePayload gxIssuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);

        this.validateGxIssueCommon(gxRequest, principal, gxIssuePayload);

        GxOrgType whoAmI = this.getWho(principal.getConfiguredForOrgId(), gxIssuePayload, gxRequest);

        if (whoAmI.equals(GxOrgType.APPLICANT) || whoAmI.equals(GxOrgType.ISSUER)) {
            // Applicant initiated, or Issuer prefilling for applicant
            this.validateGxIssueApplicant(gxRequest, principal, gxIssuePayload);
        } else {
            // is beneficiary
            this.validateGxIssueBeneficiary(gxRequest, principal, gxIssuePayload);
        }
    }

    /**
     * 
     * @param gxRequest
     * @param principal
     * @param gxIssuePayload
     */
    private void validateGxIssueApplicant(GxRequest gxRequest, BgxPrincipal principal, GxIssuePayload gxIssuePayload) {
    	
        if (gxIssuePayload.getIssuer() == null) {
            throw new GuaranteeForbiddenException("Issuer must be specified for applicant initiated issues");
        }
        try {
            Organization issuer = orgCache.get(gxIssuePayload.getIssuer());
            if (!issuer.getProfile().getEntityType().equals(EntityType.ISSUER)) {
                throw new GuaranteeForbiddenException(String.format("Org %s specified as the issuer, is not an issuer", gxIssuePayload.getIssuer()));
            }
        } catch (Exception e) {
            throw new GuaranteeForbiddenException(String.format("Error validating issuer of ID %s", gxIssuePayload.getIssuer()), e);
        }
    }

    /**
     * 
     * @param gxRequest
     * @param principal
     * @param gxIssuePayload
     */
    private void validateGxIssueBeneficiary(GxRequest gxRequest, BgxPrincipal principal, GxIssuePayload gxIssuePayload) {
    	
        if (gxIssuePayload.getIssuer() != null && !gxIssuePayload.getIssuer().equals("")) {
            throw new GuaranteeForbiddenException("Issuer cannot be specified for beneficiary initiated issues");
        }
    }

    /**
     * 
     * @param gxRequest
     * @param principal
     * @param gxIssuePayload
     */
    private void validateGxIssueCommon(GxRequest gxRequest, BgxPrincipal principal, GxIssuePayload gxIssuePayload) {
    	

        if (gxIssuePayload.getApplicants() == null || gxIssuePayload.getApplicants().isEmpty()) {
            throw new GuaranteeForbiddenException("Applicants cannot be empty");
        }

        if (gxIssuePayload.getApplicants().size() > 1) {
            throw new GuaranteeForbiddenException("System currently only supports a single applicant");
        }


        for (String applicantId : gxIssuePayload.getApplicants()) {
            if (gxIssuePayload.getBeneficiaries().contains(applicantId)) {
                throw new GuaranteeForbiddenException(String.format("Applicant '%s' cannot be a Beneficiary or vice versa", applicantId));
            }
        }

        if (gxIssuePayload.getBeneficiaries() == null || gxIssuePayload.getBeneficiaries().isEmpty()) {
            throw new GuaranteeForbiddenException("Beneficiaries cannot be empty");
        }

        if (gxIssuePayload.getBeneficiaries().size() > 1) {
            throw new GuaranteeForbiddenException("System currently only supports a single beneficiary");
        }

        try {
        	
            Organization beneficiary = this.orgCache.get(gxIssuePayload.getBeneficiaries().get(0));
            
            if (!beneficiary.getProfile().getEntityType().equals(EntityType.APPLICANT_OR_BENEFICIARY)) {
                
            	throw new GuaranteeForbiddenException(String.format("Org %s specified as the beneficiary, is not a beneficiary",
                        											gxIssuePayload.getBeneficiaries().get(0)));
            }
        } catch (Exception e) {
        	
        	// [CV] TODO: if we have only GuaranteeForbiddenException we shoul rethrow and not nest into another one of the samee type.
        	//
            throw new GuaranteeForbiddenException(String.format("Error validating beneficiary of ID %s", 
            													gxIssuePayload.getBeneficiaries().get(0)),
            									  e);
        }

        try {
            Organization applicant = this.orgCache.get(gxIssuePayload.getApplicants().get(0));
            if (!applicant.getProfile().getEntityType().equals(EntityType.APPLICANT_OR_BENEFICIARY)) {
                throw new GuaranteeForbiddenException(String.format("Org %s specified as the applicant, is not an applicant",
                        											gxIssuePayload.getApplicants().get(0)));
            }
        } catch (Exception e) {
            throw new GuaranteeForbiddenException(String.format("Error validating applicant of ID %s", gxIssuePayload.getApplicants().get(0)), e);
        }

        if (gxIssuePayload.getAmount() == null) {
            throw new GuaranteeForbiddenException("Gx amount cannot be empty");
        }

        if (gxIssuePayload.getAmount().getOutstanding() == null) {
            throw new GuaranteeForbiddenException("Outstanding amount cannot be null");
        }

        if (gxIssuePayload.getAmount().getOutstanding().compareTo(BigInteger.ZERO) <= 0) {
            throw new GuaranteeForbiddenException("Gx outstanding amount cannot be negative or zero");
        }

        if (   gxIssuePayload.getAmount().getCurrency() == null
            || gxIssuePayload.getAmount().getCurrency().value() == null
            || gxIssuePayload.getAmount().getCurrency().value().isEmpty()) {

            throw new GuaranteeForbiddenException("Gx amount currency cannot be null");
        }

        if (gxIssuePayload.getExpiresAt() != null && gxIssuePayload.getExpiresAt().isBefore(Instant.now())) {
            throw new GuaranteeForbiddenException(String.format("Gx expiry %s cannot be in the past.", gxIssuePayload.getExpiresAt()));
        }

        if (gxIssuePayload.getIssuedAt() != null) {
            throw new GuaranteeForbiddenException(String.format("Gx issue date %s cannot be specified.", gxIssuePayload.getIssuedAt()));
        }

        if (gxIssuePayload.getTcId() == null) {
            throw new GuaranteeForbiddenException("tcId must be specified");
        }


        TermsAndCond tc;
        try {
            tc = this.termsAndCondManager.getById(gxIssuePayload.getTcId());
        } catch (ProfileChainException e) {
            throw new GuaranteeForbiddenException("Unable to find tc matching tcId", e);
        }

        if (!tc.getScope().equals(Scope.BANK_GUARANTEE)) {
            throw new GuaranteeForbiddenException("Invalid tcId specified");
        }

        this.validatePurpose(gxIssuePayload.getPurposeType(), gxIssuePayload.getPurpose(), false);
    }

    /**
     * Validate Gx Amend
     *
     * @throws IllegalArgumentException if required params are null or empty
     * @throws GuaranteeForbiddenException if there is any validation error
     */
    private void validateGxAmend(GxRequest gxRequest, BgxPrincipal principal, Gx gx) {
    	
        if (gxRequest.getPayload() == null) {
            throw new IllegalArgumentException("Amend payload cannot be null");
        }

        GxAmendPayload gxAmendPayload = MAPPER.convertValue(gxRequest.getPayload(), GxAmendPayload.class);

        if (   gxAmendPayload.getAmount() != null
            && gxAmendPayload.getAmount().compareTo(BigInteger.ZERO) <= 0) {
            throw new GuaranteeForbiddenException("Gx outstanding amount cannot be negative or zero");
        }

        if (gxAmendPayload.getExpiresAt() != null && gxAmendPayload.getExpiresAtOpenEnded() != null && gxAmendPayload.getExpiresAtOpenEnded()) {
            throw new GuaranteeForbiddenException("Cannot set expiresAt to a non-null value and have expiresAtOpenEnded set to true");
        }

        // transfer purpose type from gx to amend request payload
        gxAmendPayload.setPurposeType(gx.getPurposeType());
        gxRequest.setPayload(gxAmendPayload);
        // validate purpose
        this.validatePurpose(gx.getPurposeType(), gxAmendPayload.getPurpose(), true);
    }


    /**
     * Validate Gx Demand
     *
     * @throws IllegalArgumentException if required params are null or empty
     * @throws GuaranteeForbiddenException if there is any validation error
     */
    private void validateGxDemand(GxRequest gxRequest, BgxPrincipal principal, Gx gx) {
    	
        if (gxRequest.getPayload() == null) {
            throw new IllegalArgumentException("Demand payload cannot be null");
        }

        GxDemandPayload gxDemandPayload = MAPPER.convertValue(gxRequest.getPayload(), GxDemandPayload.class);
        if (gxDemandPayload.getAmount() == null) {
            throw new GuaranteeForbiddenException("Demand amount must be specified");
        }

        if (gxDemandPayload.getAmount().compareTo(BigInteger.ZERO) <= 0) {
            throw new GuaranteeForbiddenException("Demand amount cannot be negative or zero");
        }

        if (gxDemandPayload.getAmount().compareTo(gx.getAmount().getOutstanding()) > 0) {
            throw new GuaranteeForbiddenException("Demand amount cannot be greater than outstanding amount");
        }

        GxOrgType whoAmI = this.getWho(principal.getConfiguredForOrgId(), gx, gxRequest);

        if (!whoAmI.equals(GxOrgType.BENEFICIARY)) {
            throw new GuaranteeForbiddenException("Only beneficiaries of a guarantee can submit an demand request");
        }
    }

    /**
     * Validate Gx Paywalk
     *
     * @throws IllegalArgumentException if required params are null or empty
     * @throws GuaranteeForbiddenException if there is any validation error
     */
    private void validateGxPaywalk(GxRequest gxRequest, BgxPrincipal principal, Gx gx) {
        if (gxRequest.getPayload() != null) {
            // validates that payload is in correct format
            MAPPER.convertValue(gxRequest.getPayload(), GxPayWalkPayload.class);

        }

        GxOrgType whoAmI = this.getWho(principal.getConfiguredForOrgId(), gx, gxRequest);
        if (!whoAmI.equals(GxOrgType.ISSUER)) {
            throw new GuaranteeForbiddenException("Only issuer of a guarantee can submit an issue request");
        }
    }


    /**
     * Validate Gx Cancel
     *
     * @throws IllegalArgumentException if required params are null or empty
     * @throws GuaranteeForbiddenException if there is any validation error
     */
    private void validateGxCancel(GxRequest gxRequest, BgxPrincipal principal, Gx gx) {
    	
        if (gxRequest.getPayload() != null) {

            // validates that payload is in correct format
            MAPPER.convertValue(gxRequest.getPayload(), GxCancelPayload.class);
        }
    }


    /**
     * 
     * @param gxRequest
     * @param principal
     * @param gx
     */
    // [CV] TODO: ensure that the new beneficiary is not the applicant.
    //
    private void validateGxTransfer(GxRequest gxRequest, BgxPrincipal principal, Gx gx) {
    	
        if (gxRequest.getPayload() == null) {
            throw new IllegalArgumentException("Transfer payload cannot be null");
        }

        GxTransferPayload gxTransferPayload = MAPPER.convertValue(gxRequest.getPayload(), GxTransferPayload.class);

        if (   gxTransferPayload.getBeneficiaries() == null
            || gxTransferPayload.getBeneficiaries().isEmpty()) {
            throw new GuaranteeForbiddenException("Beneficiaries cannot be empty");
        }

        if (gxTransferPayload.getBeneficiaries().size() > 1) {
            throw new GuaranteeForbiddenException("System currently only supports a single beneficiary");
        }

        try {
            Organization beneficiary = this.orgCache.get(gxTransferPayload.getBeneficiaries().get(0));
            if (!beneficiary.getProfile().getEntityType().equals(EntityType.APPLICANT_OR_BENEFICIARY)) {
            	
                throw new GuaranteeForbiddenException(String.format("Org %s specified as the beneficiary, is not a beneficiary", 
                													gxTransferPayload.getBeneficiaries().get(0)));
            }
        } catch (Exception e) {
        	
            throw new GuaranteeForbiddenException(String.format("Error validating beneficiary of ID %s", 
            													gxTransferPayload.getBeneficiaries().get(0)),
            													e);
        }

        // check that beneficiary has changed
        if (gx.getBeneficiaries().containsAll(gxTransferPayload.getBeneficiaries())) {
        	
            throw new GuaranteeForbiddenException(String.format("Gx can only be transferred to new beneficiary. Original beneficiary %s and new beneficiary %s is same.",
                												gx.getBeneficiaries().toString(),
                												gxTransferPayload.getBeneficiaries().toString()));
        }

        GxOrgType whoAmI = this.getWho(principal.getConfiguredForOrgId(), gx, gxRequest);

        if (!whoAmI.equals(GxOrgType.APPLICANT) && !whoAmI.equals(GxOrgType.BENEFICIARY)) {
            throw new GuaranteeForbiddenException("Only applicants and beneficiaries of a guarantee can submit a transfer request");
        }
    }

    /**
     * 
     * @param approve
     * @param principal
     * @param gx
     * @param gxRequest
     * @param externalActions
     */
    private void validateGxActionApprove(GxAction approve, BgxPrincipal principal, Gx gx, GxRequest gxRequest, List<GxAction> externalActions) {
    	
        if (gxRequest.getCreatedBy().equals(principal.getConfiguredForOrgId())) {
            throw new GuaranteeForbiddenException("Request creator cannot approve");
        }
        GxOrgType whoAmI = this.getWho(principal.getConfiguredForOrgId(), gx, gxRequest);
        GxOrgType creatorWho = this.getWho(gxRequest.getCreatedBy(), gx, gxRequest);

        List<GxAction> activeApprovals = this.activeApprovals(externalActions);
        if (activeApprovals.stream()
        				   .anyMatch(a -> a.getCreatedBy().equals(principal.getConfiguredForOrgId()))) {
            throw new GuaranteeForbiddenException("Organization cannot approve again");
        }

        int requiredApprovalsNum = 2;
        if ((gxRequest.getType().equals(GxRequestType.CANCEL) && creatorWho.equals(GxOrgType.BENEFICIARY)) || gxRequest.getType().equals(GxRequestType.DEMAND)) {
            requiredApprovalsNum = 1;
        } else if (gxRequest.getType().equals(GxRequestType.TRANSFER) && creatorWho.equals(GxOrgType.APPLICANT)) {
            requiredApprovalsNum = 3;
        }

        if (whoAmI.equals(GxOrgType.ISSUER)) {
            if (activeApprovals.size() != requiredApprovalsNum - 1) {
                throw new GuaranteeForbiddenException("Issuer cannot approve yet");
            }
        }

        if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
            if (creatorWho.equals(GxOrgType.BENEFICIARY) && whoAmI.equals(GxOrgType.APPLICANT)) {
            	
                GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
                if (approve.getPayload() == null) {
                    throw new GuaranteeForbiddenException("Issuer must be specified");
                }
                GxActionApprovePayload actionApprovePayload = MAPPER.convertValue(approve.getPayload(), GxActionApprovePayload.class);
                if (actionApprovePayload.getIssuer() == null || actionApprovePayload.getIssuer() == "") {
                    throw new GuaranteeForbiddenException("Issuer must be specified");
                }

                if (issuePayload.getIssuer() == null) {
                    try {
                        Organization issuer = this.orgCache.get(actionApprovePayload.getIssuer());
                        if (!issuer.getProfile().getEntityType().equals(EntityType.ISSUER)) {
                            throw new GuaranteeForbiddenException("Organization specified as issuer, is not an issuer");
                        }
                    } catch (Exception e) {
                    	
                    	// [CV] TODO: if we have only GuaranteeForbiddenException we shoul rethrow and not nest into another one of the samee type.
                    	//
                        throw new GuaranteeForbiddenException(String.format("Error validating issuer of ID %s", actionApprovePayload.getIssuer()), e);
                    }
                } else if (!issuePayload.getIssuer().equals(actionApprovePayload.getIssuer())) {
                    throw new GuaranteeForbiddenException("Issuer cannot be changed after revoking");
                }
            }
        }
    }

    /**
     * 
     * @param reject
     * @param principal
     * @param gx
     * @param gxRequest
     * @param externalActions
     */
    private void validateGxActionReject(GxAction reject, BgxPrincipal principal, Gx gx, GxRequest gxRequest, List<GxAction> externalActions) {
    	
        if (externalActions.size() == 1 && externalActions.get(0).getType().equals(GxActionType.PREFILL)) {
            // prefill requests
            if (!gx.getApplicants().contains(principal.getConfiguredForOrgId())) {
                throw new GuaranteeForbiddenException("Only applicants can reject prefill");
            }

        } else {
            // normal requests
            if (gxRequest.getCreatedBy().equals(principal.getConfiguredForOrgId())) {
                throw new GuaranteeForbiddenException("Request creator cannot reject");
            }
        }
        if (gxRequest.getType().equals(GxRequestType.DEMAND)) {
            throw new GuaranteeForbiddenException("Demand cannot be rejected");
        }
    }

    /**
     * 
     * @param cancel
     * @param principal
     * @param gx
     * @param gxRequest
     * @param externalActions
     */
    private void validateGxActionCancel(GxAction cancel, BgxPrincipal principal, Gx gx, GxRequest gxRequest, List<GxAction> externalActions) {
    	
        if (!gxRequest.getCreatedBy().equals(principal.getConfiguredForOrgId())) {
            throw new GuaranteeForbiddenException("Only Request creator can cancel");
        }
    }

    /**
     * 
     * @param revoke
     * @param principal
     * @param gx
     * @param gxRequest
     * @param externalActions
     */
    private void validateGxActionRevokeApprove(GxAction revoke, BgxPrincipal principal, Gx gx,
        GxRequest gxRequest, List<GxAction> externalActions) {

        if (revoke.getActionId() == null) {
            throw new GuaranteeForbiddenException("actionId must be specified");
        }

        List<GxAction> activeApprovals = this.activeApprovals(externalActions);
        for (GxAction action : activeApprovals) {
            if (action.getId().equals(revoke.getActionId())) {
                if (!action.getCreatedBy().equals(principal.getConfiguredForOrgId())) {
                    throw new GuaranteeForbiddenException("Revoke another organizations approval");
                }
                return;
            }
        }

        throw new GuaranteeForbiddenException(String.format("Could not find approval of id %s to revoke", revoke.getActionId()));
    }

    /**
     * 
     * @param defer
     * @param principal
     * @param gx
     * @param gxRequest
     * @param externalActions
     */
    private void validateGxActionDefer(GxAction defer, BgxPrincipal principal, Gx gx, GxRequest gxRequest, List<GxAction> externalActions) {
    	
        if (!gxRequest.getType().equals(GxRequestType.DEMAND)) {
            throw new GuaranteeForbiddenException("Only demands can be deferred");
        }

        GxOrgType whoAmI = this.getWho(principal.getConfiguredForOrgId(), gx, gxRequest);
        if (!whoAmI.equals(GxOrgType.ISSUER)) {
            throw new GuaranteeForbiddenException("Only issuers can defer");
        }

        if (externalActions.stream().anyMatch(a -> a.getType().equals(GxActionType.DEFER))) {
            throw new GuaranteeForbiddenException("Request has already been deferred");

        }
    }


    private List<GxAction> activeApprovals(List<GxAction> actions) {
    	
        Map<String, Boolean> revokedMap = new HashMap<>();
        for (GxAction action : actions) {
            if (action.getType().equals(GxActionType.REVOKE)) {
                revokedMap.put(action.getActionId(), true);
            }
        }

        return actions.stream().filter(a -> a.getType().equals(GxActionType.APPROVE) && !revokedMap.containsKey(a.getId()))
        					   .collect(Collectors.toList());
    }

    private boolean isPartOfGuarantee(Gx gx, BgxPrincipal principal) {
    	
        List<String> orgIds = new ArrayList<>();
        orgIds.addAll(gx.getApplicants());
        orgIds.addAll(gx.getBeneficiaries());
        orgIds.add(gx.getIssuer());

        return orgIds.contains(principal.getConfiguredForOrgId());
    }

    private boolean isPartOfGxRequest(GxRequest gxRequest, BgxPrincipal principal, Gx gx) {
    	
        switch (gxRequest.getType()) {

            case ISSUE:
                GxIssuePayload gxIssuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
                return isPartOfGuarantee(gxIssuePayload, principal);
            case TRANSFER:
                if (isPartOfGuarantee(gx, principal)) {
                    return true;
                }

                GxTransferPayload gxTransferPayload = MAPPER.convertValue(gxRequest.getPayload(), GxTransferPayload.class);

                return gxTransferPayload.getBeneficiaries().contains(principal.getConfiguredForOrgId());

            default:
                // Do nothing
        }
        return isPartOfGuarantee(gx, principal);
    }

    private GxOrgType getWho(String orgId, Gx gx, GxRequest gxRequest) {
    	
        if (gx == null) {
            throw new IllegalArgumentException("Gx cannot be empty");
        }

        if (gx.getApplicants()
            .contains(orgId)) {
            return GxOrgType.APPLICANT;
        }
        if (gx.getBeneficiaries().contains(orgId)) {
            return GxOrgType.BENEFICIARY;
        }
        if (gx.getIssuer().equals(orgId)) {
            return GxOrgType.ISSUER;
        }
        if (gxRequest.getType().equals(GxRequestType.TRANSFER)) {
            GxTransferPayload gxTransferPayload = MAPPER.convertValue(gxRequest.getPayload(), GxTransferPayload.class);

            if (gxTransferPayload.getBeneficiaries().contains(orgId)) {
                return GxOrgType.NEW_BENEFICIARY;
            }
        }

        throw new GuaranteeForbiddenException(
            String.format("Could not figure out gx org role for org %s", orgId));
    }

    private boolean validateNoExistingSameRequestType(GxRequest gxRequest, Gx gx, BgxPrincipal principal) {
    	
        // Check for existing non-prefill active requests of the same type on the guarantee
        int activeGxRequestsFlag = GxUtil.getActiveGxRequestsFlagForRequestType(gxRequest.getType());
        
        if (gx.getActiveRequests() != 0 && ((activeGxRequestsFlag & gx.getActiveRequests()) == activeGxRequestsFlag)) {
            // Check that it's not a prefill
            // TODO potentially pass into validateGxRequest as an argument
            GxFlowsSearchRequest flowsSearchRequest = new GxFlowsSearchRequest();
            flowsSearchRequest.setGuaranteeId(gxRequest.getGuaranteeId());
            flowsSearchRequest.setStatus(FlowStatus.ACTIVE);

            List<GxRequest> activeRequests = principal.getGxManager()
            										  .searchFlows(flowsSearchRequest)
            										  .getFlows();
            
            boolean hasNonPrefillRequest = activeRequests.stream().anyMatch(r -> (r.getPrefill() == null || !r.getPrefill()) && r.getType().equals(gxRequest.getType()));
            if (hasNonPrefillRequest) {
                return false;
            }
        }

        return true;
    }
}
