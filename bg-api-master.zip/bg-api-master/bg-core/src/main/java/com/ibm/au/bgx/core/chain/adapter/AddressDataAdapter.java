package com.ibm.au.bgx.core.chain.adapter;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.PostalAddress;
import com.ibm.au.bgx.model.shared.Common.Address;
import org.springframework.stereotype.Component;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class AddressDataAdapter implements ChainDataAdapter<Address, PostalAddress> {

    @Override
    public Address toOnChainModel(PostalAddress postalAddress) {
        Address.Builder builder = Address.newBuilder();

        if (postalAddress.getStreetAddress() !=  null) {
            builder.setStreetAddress(postalAddress.getStreetAddress());
        }

        if (postalAddress.getAddressLocality() != null) {
            builder.setAddressLocality(postalAddress.getAddressLocality());
        }

        if (postalAddress.getAddressRegion() != null) {
            builder.setAddressRegion(postalAddress.getAddressRegion());
        }

        if (postalAddress.getAddressCountry() != null) {
            builder.setAddressCountry(postalAddress.getAddressCountry());
        }

        if (postalAddress.getPostalCode() != null) {
            builder.setPostalCode(postalAddress.getPostalCode());
        }

        if (postalAddress.getPostOfficeBoxNumber() != null) {
            builder.setPostOfficeBoxNumber(postalAddress.getPostOfficeBoxNumber());
        }

        return builder.build();
    }

    @Override
    public PostalAddress toOffchainModel(Address address) {
        PostalAddress postalAddress = new PostalAddress();
        postalAddress.setStreetAddress(address.getStreetAddress());
        postalAddress.setAddressLocality(address.getAddressLocality());
        postalAddress.setAddressRegion(address.getAddressRegion());
        postalAddress.setAddressCountry(address.getAddressCountry());
        postalAddress.setPostalCode(address.getPostalCode());
        postalAddress.setPostOfficeBoxNumber(address.getPostOfficeBoxNumber());
        return postalAddress;
    }
}
