/**
 * 
 */
package com.ibm.au.bgx.core.chain.channel.gx;


/**
 * Interface <b>GxChannelProvider</b>. This interface abstracts away the process
 * of fetching the configured guarantee channels configured for the current 
 * execution context.
 * 
 * The information about guarantee channels is exposed through {@link GxChannelMetadata}
 * instances that can wrap additional information besides the name and the associated
 * prefix.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public interface GxChannelProvider {
	
	/**
	 * Gets the list of channels that have been configured for the current
	 * execution context to manage bank guarantees.
	 * 
	 * @return	an array containing {@link GxChannelMetadata} instances for 
	 * 			each of the channels configured with the vertical. If there
	 * 			are no channels configured, the array is empty.
	 */
	GxChannelMetadata[] getChannels();
	
	/**
	 * Gets the list of names of the channels that have been configured for the
	 * current execution context to manage bank guarantees.
	 * 
	 * @return	an array containing the names of the channels configured with
	 * 			the vertical. If there are no channels configured, the array is
	 * 			empty. 
	 */
	String[] getChannelNames();
	
	
	/**
	 * Gets the metadata of the channel that is identified by the given <i>name</i>.
	 * 
	 * @param name 	a {@link String} containing the name of the channel. It cannot
	 * 				be {@literal null} or an empty string.
	 * 
	 * @return	a {@link GxChannelMetadata} instance that contains the metadata of the
	 * 			channel mapped by <i>name</i> or {@literal null} if the name does not
	 * 			match any configured channel.
	 * 
	 * @throws IllegalArgumentException if <i>name</i> is {@literal null} or an empty
	 * 									string.
	 */
	GxChannelMetadata getChannelByName(String name);
	
	
	/**
	 * Gets the metadata of the channel that is identified by the given <i>prefix</i>.
	 * 
	 * @param prefix 	a {@link String} containing the prefix used to compose bank
	 * 				    guarantees identifiers in the channel. It cannot be {@literal 
	 * 					null} or an empty string.
	 * 
	 * @return	a {@link GxChannelMetadata} instance that contains the metadata of the
	 * 			channel mapped by <i>prefix</i> or {@literal null} if the prefix does not
	 * 			match any configured channel.
	 * 
	 * @throws IllegalArgumentException if <i>prefix</i> is {@literal null} or an empty
	 * 									string.
	 */
	GxChannelMetadata getChannelByPrefix(String prefix);

}
