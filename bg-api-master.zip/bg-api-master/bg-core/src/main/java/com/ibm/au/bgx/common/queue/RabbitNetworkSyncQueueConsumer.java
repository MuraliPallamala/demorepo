package com.ibm.au.bgx.common.queue;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.chain.profile.UserProfileManager;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.notification.NetworkSyncNotification;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.notification.WebNotification.MessageType;
import com.ibm.au.bgx.model.pojo.notification.WebNotification.ReferenceType;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.queue.QueueConsumer.NetworkSyncQueueConsumer;
import com.ibm.au.bgx.model.queue.QueueHandler;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

/**
 * Handle {@link NetworkSyncNotification} messages
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class RabbitNetworkSyncQueueConsumer implements NetworkSyncQueueConsumer {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();
    private static final Logger LOGGER = LoggerFactory
        .getLogger(RabbitNetworkSyncQueueConsumer.class);

    /**
     * A {@link BigInteger} containing the allowed value of max retry count of the message
     *
     * After these many times it gives up retrying the processing of the message.
     * We put a default high value of 10000 which should be more than enough like doing it forever.
     * However, we should stop retrying any dead message anyway, and therefore we put this limit.
     */
    @Value("${queue.message.maxRetryCount:10000}")
    private BigInteger maxRetryCount;

    @Autowired(required = false)
    private QueueHandler<NetworkSyncNotification> handler;

    @Autowired
    private UserProfileManager userProfileManager;

    @Override
    public void registerConsumer(String queueName, QueueClient client) throws IOException {
        RabbitQueueClient queueClient = (RabbitQueueClient) client;
        queueClient.getChannel()
            .basicConsume(queueName, false,
                this.getConsumer(queueClient, queueClient.getChannel()));
    }

    public Consumer getConsumer(QueueClient queueClient, Channel channel) {
        RabbitNetworkSyncQueueConsumer self = this;
        if (self.handler == null) {
            throw new IllegalArgumentException(
                "No QueueHandler<NetworkSyncNotification> available.");
        }

        return new DefaultConsumer(channel) {

            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                BasicProperties properties, byte[] body) throws IOException {

                LOGGER.debug(BgxLogMarkers.DEV, "Handling delivery of message: Started");

                NetworkSyncNotification notification = MAPPER
                    .readValue(body, NetworkSyncNotification.class);

                try {
                    LOGGER.debug(BgxLogMarkers.DEV, "Sending network sync notification to: {}",
                        notification.getTargetId());

                    self.handler.handle(notification);

                    // confirm receipt and processing
                    channel.basicAck(envelope.getDeliveryTag(), false);

                    LOGGER.debug("Handling delivery of message: Acknowledged");

                } catch (IOException e) {
                    LOGGER.error("IO during handling of NetworkSyncNotification", e);

                    // FIXME Potentially we could put this retry logic in
                    // an Abstract/Custom class to reuse

                    // fallback if retry count hasn't been initialized
                    if (notification.getRetryCount() == null) {
                        notification.setRetryCount(BigInteger.ZERO);
                    }

                    notification.setRetryCount(notification.getRetryCount().add(BigInteger.ONE));
                    LOGGER.error("Retry count for the failed message: {}",
                        notification.getRetryCount());

                    if (notification.getRetryCount().compareTo(maxRetryCount) > 0) {

                        LOGGER.error(BgxLogMarkers.DEV,
                            "Max retry has reached, dropping the message:{}",
                            new String(body, StandardCharsets.UTF_8), e);

                        channel.basicAck(envelope.getDeliveryTag(), false);

                        // send a notification to org admins about this dead message
                        LOGGER.debug(BgxLogMarkers.DEV,
                            "Sending notification to admin for the dead message.");
                        List<UserProfile> admins = userProfileManager
                            .getByOrgRole(notification.getSourceId(), BgxConstants.ROLE_ADMIN);
                        if (admins.size() == 0) {
                            LOGGER.error(BgxLogMarkers.DEV, "No admin found to be notified.");
                        }

                        for (UserProfile admin : admins) {
                            WebNotification webNotification = new WebNotification();
                            webNotification.setReceiverId(admin.getId());
                            webNotification.setMessageType(MessageType.SYSTEM_MESSAGE);
                            webNotification.setReferenceType(ReferenceType.NETWORK_SYNC);
                            webNotification.setPayload(new HashMap<>());
                            webNotification.getPayload()
                                .put(BgxConstants.NETWORK_SYNC_PAYLOAD, notification);

                            LOGGER.debug(BgxLogMarkers.DEV,
                                "Sending notification about dead message to admin {}.",
                                admin.getEmail());
                            queueClient.addWebNotification(webNotification);
                        }

                        return; // ignore the exception since we are giving up on this dead message.
                    }

                    // requeue to try again later since service is unavailable now
                    if (channel.isOpen()
                        && e.getCause() != null
                        && (e.getCause() instanceof ServiceUnavailableException
                        || e.getCause() instanceof HttpClientErrorException
                    )) {
                        LOGGER.debug(BgxLogMarkers.DEV,
                            "Requeue NetworkSyncNotification since network error occurred for remote service.",
                            e);

                        // Note: We need to Ack and then Publish to put the message at the end of
                        // the queue. Otherwise it keeps the message where originally it was.
                        channel.basicAck(envelope.getDeliveryTag(), false);

                        channel.basicPublish(RabbitQueueClient.EXCHANGE_NAME,
                            QueueClient.CHANNEL_NETWORK, null,
                            MAPPER.writeValueAsBytes(notification));

                    } else {
                        throw e;
                    }
                }

            }
        };
    }
}
