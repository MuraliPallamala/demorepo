package com.ibm.au.bgx.core.chain.event;

import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.profile.OrganizationsEventHandlerService;
import com.ibm.au.bgx.model.profile.OrganizationsEventHandlerService.EventHandler;

import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Event handler for the organizations chaincode.
 *
 * @author Peter Ilfrich
 */
@Component
public class OrganizationsEventHandler extends AbstractEventHandler implements EventHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrganizationsEventHandler.class);

    /**
     * Registers the profile chain events for the provided channel.
     *
     * @param channel - the channel for which to register the profile events for
     */
    @Override
    public void registerEvents(Channel channel) {
        try {
            LOGGER.debug(BgxLogMarkers.DEV, "Registering organisation event handlers for channel {}",
                        channel.getName());

            Set<String> handles = this.getEventHandleSet(channel);

            handles.add(OrganizationsEventHandlerService.registerCreateOrganizationEvent(channel,this));
            handles.add(OrganizationsEventHandlerService.registerProfileChangeEvent(channel,this));
            handles.add(OrganizationsEventHandlerService.registerCreatePurposeFormatEvent(channel, this));
            handles.add(OrganizationsEventHandlerService.registerUpdatePurposeFormatEvent(channel, this));
        } catch (InvalidArgumentException iae) {
            LOGGER.error("Error registering organisation events", iae);
            throw new IllegalArgumentException("Error registering organisation events", iae);
        }
    }
}
