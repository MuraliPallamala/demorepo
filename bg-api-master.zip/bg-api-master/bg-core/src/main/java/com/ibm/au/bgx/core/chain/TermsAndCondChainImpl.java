package com.ibm.au.bgx.core.chain;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.core.chain.adapter.tc.TermsAndCondAdapter;
import com.ibm.au.bgx.model.chain.TermsAndCondChain;
import com.ibm.au.bgx.model.exception.ChainInitializationException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.profile.TermsConditionsAPI;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditions;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditionsSearchRequest;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditionsUpdateRequest;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditionsList;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditionsScope;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditionsScopeValue;
import com.ibm.au.bgx.model.shared.Common.IDValue;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This implements methods to persist and retrieve records from chain
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class TermsAndCondChainImpl extends AbstractChain<TermsConditionsAPI> implements
    TermsAndCondChain {

    private static final Logger LOGGER = LoggerFactory.getLogger(TermsAndCondChainImpl.class);

    @Autowired
    TermsAndCondAdapter tcAdapter;

    @Override
    protected TermsConditionsAPI getChain(String channelUserName) throws ChainInitializationException {
        TermsConditionsAPI api = null;

        if (channelUserName == null || channelUserName.isEmpty()) {
            throw new IllegalArgumentException(
                "Channel user ID cannot be empty.`");
        }

        try {
            api = selector.getTermsConditionsApi(channelUserName);
        } catch (Exception e) {
            throw new ChainInitializationException("Could not initialize T&C chain", e);
        }

        return api;
    }

    @Override
    public TermsAndCond create(TermsAndCond tc) throws ProfileChainException {
        try {
            LOGGER
                .debug(BgxLogMarkers.DEV, "Creating '{}' T&C using channel user {}", tc.getTitle(),
                    this.channelUserName);
            IDValue resp = getChain(this.channelUserName)
                .Create(tcAdapter.toOnChainModel(tc), false, true);
            return this.getById(resp.getValue());
        } catch (Exception e) {
            throw new ProfileChainException("Could not create TC", e);
        }
    }

    @Override
    public TermsAndCond getById(String id) throws ProfileChainException {

        TermsAndCond tc = null;
        try {
            IDValue req = IDValue.newBuilder().setValue(id).build();
            TermsConditions tcChain = getChain(this.channelUserName).Get(req);
            if (tcChain == null) {
                return null;
            }
            tc = tcAdapter.toOffchainModel(tcChain);
        } catch (Exception e) {
            LOGGER.debug(BgxLogMarkers.DEV, String.format("Could not get T&C by ID: %s", id), e);
        }

        return tc;
    }

    @Override
    public List<TermsAndCond> getAll(String title, String type) throws ProfileChainException {

        try {
            List<TermsAndCond> tcs = new ArrayList<>();
            type = type.toUpperCase();

            TermsConditionsSearchRequest.Builder builder = TermsConditionsSearchRequest
                .newBuilder();

            if (title != null && !title.isEmpty()) {
                builder.setTitle(title);
            }

            if (type != null && !type.isEmpty()) {
                builder.setScope(TermsConditionsScopeValue.newBuilder()
                    .setValue(TermsConditionsScope.valueOf(type)).build());
            }

            TermsConditionsList records = getChain(this.channelUserName).Search(builder.build());

            if (records != null) {
                for (TermsConditions tcChain : records.getTermsConditionsList()) {
                    tcs.add(tcAdapter.toOffchainModel(tcChain));
                }
            }

            return tcs;
        } catch (Exception e) {
            throw new ProfileChainException("Could not retrieve T&Cs", e);
        }
    }

    @Override
    public List<TermsAndCond> getActive(String title, String type) throws ProfileChainException {

        try {
            List<TermsAndCond> tcs = new ArrayList<>();
            type = type.toUpperCase();

            TermsConditionsSearchRequest.Builder builder = TermsConditionsSearchRequest
                .newBuilder();

            builder.setActiveStatus(true);

            if (title != null && !title.isEmpty()) {
                builder.setTitle(title);
            }

            if (type != null && !type.isEmpty()) {
                builder.setScope(TermsConditionsScopeValue.newBuilder()
                    .setValue(TermsConditionsScope.valueOf(type)).build());
            }

            TermsConditionsList records = getChain(this.channelUserName).Search(builder.build());

            if (records != null) {
                for (TermsConditions tcChain : records.getTermsConditionsList()) {
                    tcs.add(tcAdapter.toOffchainModel(tcChain));
                }
            }

            return tcs;
        } catch (Exception e) {
            throw new ProfileChainException("Could not retrieve T&Cs", e);
        }
    }

    @Override
    public void updateActiveStatus(String id, boolean activeStatus) throws ProfileChainException {
        try {
            // call the update
            TermsConditionsAPI api = getChain(this.channelUserName);
            TermsConditionsUpdateRequest.Builder builder = TermsConditionsUpdateRequest.newBuilder();
            builder.setActiveStatus(activeStatus);
            builder.setId(id);
            api.Update(builder.build());
        } catch (Exception chainEx) {
            throw new ProfileChainException("Error updating terms and conditions status", chainEx);
        }
    }
}
