package com.ibm.au.bgx.common.rest;

import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;
import com.nimbusds.oauth2.sdk.AuthorizationGrant;
import com.nimbusds.oauth2.sdk.ClientCredentialsGrant;
import com.nimbusds.oauth2.sdk.ParseException;
import com.nimbusds.oauth2.sdk.RefreshTokenGrant;
import com.nimbusds.oauth2.sdk.TokenErrorResponse;
import com.nimbusds.oauth2.sdk.TokenRequest;
import com.nimbusds.oauth2.sdk.TokenResponse;
import com.nimbusds.oauth2.sdk.auth.ClientAuthentication;
import com.nimbusds.oauth2.sdk.auth.ClientSecretBasic;
import com.nimbusds.oauth2.sdk.auth.Secret;
import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import com.nimbusds.oauth2.sdk.http.HTTPResponse;
import com.nimbusds.oauth2.sdk.id.ClientID;
import com.nimbusds.oauth2.sdk.token.AccessToken;
import com.nimbusds.oauth2.sdk.token.RefreshToken;
import com.nimbusds.openid.connect.sdk.OIDCTokenResponse;
import com.nimbusds.openid.connect.sdk.OIDCTokenResponseParser;
import com.nimbusds.openid.connect.sdk.token.OIDCTokens;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import net.minidev.json.JSONObject;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This class can be used to get a new access token for remote api-to-api class
 *
 * Internally it caches the access token indexed by API clientId and accessToken Url,
 * and refresh using refresh token if required
 *
 * Since ideally there will be few API clients for each deployment, we are keeping the tokens in the
 * memory for each unique pair of accessTokenUrl and clientId
 *
 * If however this class needs to be used for a large number of clients, we should logout the client
 * or, remove token (and cache eviction) if caching of token for the client is not needed anymore.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@Component
public class AccessTokenProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(AccessTokenProvider.class);

    private Map<String, Map<String, Object>> tokenCache = new HashMap<>();

    private static final String KEY_AUTH_TOKENS = "tokens";

    private static final String KEY_TOKEN_CREATED_AT = "createdAt";

    @Autowired
    private SSLUtils sslUtils;

    /**
     * This is a mutex that controls the synchronized access to the cached tokens
     */
    private Object tokenLock = new Object();


    private String createTokensKey(OpenIdConfig authConfig) {
       return DigestUtils.sha256Hex(String.format("%s%s", authConfig.getAccessTokenUri(), authConfig.getClientId()));
    }


    public AccessToken getAccessToken(OpenIdConfig authConfig) {

        if (authConfig.getAccessTokenUri() == null || authConfig.getAccessTokenUri().isEmpty()) {
            throw new IllegalArgumentException("Access token URL cannot be empty");
        }

        if (authConfig.getClientId() == null || authConfig.getClientId().isEmpty()) {
            throw new IllegalArgumentException("Client Id cannot be empty");
        }

        synchronized (this.tokenLock) {
            LOGGER.debug(BgxLogMarkers.AUTH, "Trying to get access for '{}' from '{}'", authConfig.getClientId(), authConfig.getAccessTokenUri());

            try {
                Instant createdAt = null;
                OIDCTokens tokens = null;
                boolean updateCache = false;

                // fetch from cache if possible
                String tokenKey = this.createTokensKey(authConfig);
                if (this.tokenCache.containsKey(tokenKey)) {

                    createdAt = (Instant) this.tokenCache.get(tokenKey).get(KEY_TOKEN_CREATED_AT);
                    tokens = (OIDCTokens) this.tokenCache.get(tokenKey).get(KEY_AUTH_TOKENS);

                    long timeLeft = tokens.getAccessToken().getLifetime() - (
                        (System.currentTimeMillis() - createdAt.getEpochSecond() * 1000) / 1000);

                    LOGGER.debug(BgxLogMarkers.AUTH, "Found access token in cache, created At {} and expiring in {}s", createdAt, timeLeft);

                    if (timeLeft >= 0 && timeLeft < 5 ) { // if it expires in 5s, refresh it

                        // refresh token
                        LOGGER.debug(BgxLogMarkers.AUTH,
                            "Trying to refresh token from {} for {}.",
                            authConfig.getAccessTokenUri(), authConfig.getClientId());

                        updateCache = true;

                        tokens = this.getOIDCToken(authConfig, tokens.getRefreshToken());
                    } else if (timeLeft < 0) {
                        tokens = null; // force it to be null if expired so that we fetch a new
                    }
                }

                // If it is a cache miss, or the access token has already expired we fetch new.
                //
                // Note we fetch new token here even if refresh token might be still valid.
                // This is because, since we need make an API request anyway, we retrieve a fresh
                // copy with fresh refresh token. This might be a little less efficient, but it lets
                // us avoid handling refresh token expiry.
                if (tokens == null){
                    LOGGER.debug(BgxLogMarkers.AUTH, "Could not find valid access token in cache, trying to fetch new.");

                    tokens = this.getOIDCToken(authConfig, null);

                    updateCache = true;
                }

                // tokens cannot be null at this point. So we throw exception.
                if (tokens == null) {
                    throw new IllegalStateException(
                        String.format("Could not retrieve access token for %s from %s",
                            authConfig.getClientId(), authConfig.getAccessTokenUri()));

                }

                // update cache
                if (updateCache) {
                    LOGGER.debug(BgxLogMarkers.AUTH, "Updating access token in cache");
                    this.storeToken(tokens, authConfig);
                }

                return tokens.getAccessToken();
            } catch (Exception e) {
                throw new IllegalArgumentException(
                    "Could not retrieve access token for internal error.", e);
            }
        }
    }

    /**
     * Get new token
     *
     * If refreshToken is provided, it tries to refresh token otherwise it tries to get a new
     * access token
     */
    public OIDCTokens getOIDCToken(OpenIdConfig authConfig, RefreshToken refreshToken)
        throws URISyntaxException, IOException, ParseException {

        AuthorizationGrant authorizationGrant = null;
        if (refreshToken != null) {
            authorizationGrant = new RefreshTokenGrant(refreshToken);
        } else {
            authorizationGrant = new ClientCredentialsGrant();
        }

        ClientID clientID = new ClientID(authConfig.getClientId());
        Secret clientSecret = new Secret(authConfig.getClientSecret());
        ClientAuthentication clientAuth = new ClientSecretBasic(clientID, clientSecret);

        URI tokenEndpoint = new URI(authConfig.getAccessTokenUri());

        TokenRequest request = new TokenRequest(tokenEndpoint, clientAuth, authorizationGrant);
        TokenResponse tokenResponse = this.submitTokenRequest(request);

        if (!tokenResponse.indicatesSuccess()) {
            TokenErrorResponse errorResponse = tokenResponse.toErrorResponse();
            JSONObject object = errorResponse.toJSONObject();

            String msg = "Authentication failed: " + (object == null ? "<null>" : object.toString());
            throw new IllegalArgumentException(msg);
        }

        OIDCTokenResponse successResponse = (OIDCTokenResponse) tokenResponse.toSuccessResponse();

        return successResponse.getOIDCTokens();
    }

    /**
     * Send token request to remote URL using custom ssl client
     *
     * @param request
     * @return
     * @throws IOException
     * @throws ParseException
     */
    private TokenResponse submitTokenRequest(TokenRequest request)
        throws IOException, ParseException {

        try {

            HTTPRequest httpRequest = request.toHTTPRequest();
            httpRequest.setSSLSocketFactory(this.sslUtils.getSSLSocketFactory());
            HTTPResponse response = httpRequest.send();

            return OIDCTokenResponseParser.parse(response);

        } catch (Throwable t) {

            LOGGER.error(BgxLogMarkers.AUTH, String.format(
                "Could not retrieve authentication token. [type: %s, message: %s]",
                t.getClass().getName(), t.getMessage()));
            throw t;
        }
    }

    /**
     * Remove token for the given client
     *
     * @param authConfig
     */
    public void removeToken(OpenIdConfig authConfig) {

        synchronized (this.tokenLock) {
            String tokenKey = this.createTokensKey(authConfig);
            this.tokenCache.remove(tokenKey);
        }
    }

    /**
     * Store the token for the client
     *
     * If an entry exists, it updates it. Otherwise it creates a new entry in the local cache.
     *
     * @param tokens
     * @param authConfig
     * @throws IOException
     */
    public void storeToken(OIDCTokens tokens, OpenIdConfig authConfig) throws IOException {

        synchronized (this.tokenLock) {
            String tokenKey = this.createTokensKey(authConfig);

            if (!this.tokenCache.containsKey(tokenKey)) {
                this.tokenCache.put(tokenKey, new HashMap<>());
            }

            this.tokenCache.get(tokenKey).put(KEY_TOKEN_CREATED_AT, Instant.now());
            this.tokenCache.get(tokenKey).put(KEY_AUTH_TOKENS, tokens);
        }
    }

    /**
     * Clear all tokens
     */
    public void clearAll() {
        synchronized (this.tokenLock) {
            this.tokenCache = new HashMap<>();
        }
    }
}
