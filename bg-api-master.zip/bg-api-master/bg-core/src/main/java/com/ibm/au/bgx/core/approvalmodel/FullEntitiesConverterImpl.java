package com.ibm.au.bgx.core.approvalmodel;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.cache.OrgCache;
import com.ibm.au.bgx.core.cache.OrgCacheImpl;
import com.ibm.au.bgx.core.cache.UserProfileCache;
import com.ibm.au.bgx.core.cache.UserProfileCacheImpl;
import com.ibm.au.bgx.model.chain.gx.FullEntitiesConverter;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxActionFullEntities;
import com.ibm.au.bgx.model.pojo.gx.GxFullEntities;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayloadFullEntities;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestFullEntities;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.gx.GxTransferPayload;
import com.ibm.au.bgx.model.pojo.gx.GxTransferPayloadFullEntities;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FullEntitiesConverterImpl implements FullEntitiesConverter {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    OrgCache orgCache;

    @Autowired
    UserProfileCache userProfileCache;

    @Override
    public GxFullEntities from(Gx gx) throws ProfileNotFoundException, ProfileChainException {
    	
        List<OrgProfile> applicants = new ArrayList<>();
        for (String orgId : gx.getApplicants()) {
            applicants.add(OrgCacheImpl.filterOrgProfile(this.orgCache.get(orgId).getProfile()));
        }
        List<OrgProfile> beneficiaries = new ArrayList<>();
        for (String orgId : gx.getBeneficiaries()) {
            beneficiaries.add(OrgCacheImpl.filterOrgProfile(this.orgCache.get(orgId).getProfile()));
        }
        // Issuer can be unspecified for beneficiary initiated
        OrgProfile issuer = null;
        if (gx.getIssuer() != null) {
            issuer = OrgCacheImpl.filterOrgProfile(this.orgCache.get(gx.getIssuer()).getProfile());
        }

        GxFullEntities gxFullEntities = new GxFullEntities();
        gxFullEntities.setId(gx.getId());
        gxFullEntities.setStatus(gx.getStatus());
        gxFullEntities.setAmount(gx.getAmount());
        gxFullEntities.setPurpose(gx.getPurpose());
        gxFullEntities.setPurposeType(gx.getPurposeType());
        gxFullEntities.setBankReference(gx.getBankReference());
        gxFullEntities.setExpiresAt(gx.getExpiresAt());
        gxFullEntities.setPrevGxId(gx.getPrevGxId());
        gxFullEntities.setApplicants(applicants);
        gxFullEntities.setBeneficiaries(beneficiaries);
        gxFullEntities.setIssuer(issuer);
        gxFullEntities.setIssuedAt(gx.getIssuedAt());
        gxFullEntities.setUpdatedAt(gx.getUpdatedAt());
        gxFullEntities.setActiveRequests(gx.getActiveRequests());
        gxFullEntities.setOnchainActiveRequests(gx.getOnchainActiveRequests());
        gxFullEntities.setTcId(gx.getTcId());

        return gxFullEntities;
    }

    @Override
    public GxRequestFullEntities from(GxRequest gxRequest)  throws ProfileNotFoundException, ProfileChainException {
    	
        OrgProfile createdBy = OrgCacheImpl.filterOrgProfile(this.orgCache.get(gxRequest.getCreatedBy()).getProfile());
        Object gxPayload;

        if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
            GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);

            // HACK
            GxIssuePayloadFullEntities issuePayloadFullEntities = MAPPER.convertValue(this.from(issuePayload), GxIssuePayloadFullEntities.class);

            issuePayloadFullEntities.setOffchainCreatedAt(issuePayload.getOffchainCreatedAt());
            gxPayload = issuePayloadFullEntities;
            
        } else if (gxRequest.getType().equals(GxRequestType.TRANSFER)) {
        	
            GxTransferPayload transferPayload = MAPPER.convertValue(gxRequest.getPayload(), GxTransferPayload.class);
            GxTransferPayloadFullEntities transferPayloadFullEntities = new GxTransferPayloadFullEntities();
            List<OrgProfile> beneficiaries = new ArrayList<>();
            for (String orgId : transferPayload.getBeneficiaries()) {
                beneficiaries.add(OrgCacheImpl.filterOrgProfile(this.orgCache.get(orgId).getProfile()));
            }
            transferPayloadFullEntities.setBeneficiaries(beneficiaries);
            transferPayloadFullEntities.setReason(transferPayload.getReason());
            // Gx is null on submission (TODO potentially change)
            if (transferPayload.getGx() != null) {
                transferPayloadFullEntities.setGx(this.from(transferPayload.getGx()));
            }
            transferPayloadFullEntities.setNewGuaranteeId(transferPayload.getNewGuaranteeId());
            gxPayload = transferPayloadFullEntities;
        } else {
            gxPayload = gxRequest.getPayload();
        }

        GxRequestFullEntities gxRequestFullEntities = new GxRequestFullEntities();
        gxRequestFullEntities.setId(gxRequest.getId());
        gxRequestFullEntities.setStatus(gxRequest.getStatus());
        gxRequestFullEntities.setType(gxRequest.getType());
        gxRequestFullEntities.setGuaranteeId(gxRequest.getGuaranteeId());
        gxRequestFullEntities.setPayload(gxPayload);
        gxRequestFullEntities.setCreatedAt(gxRequest.getCreatedAt());
        gxRequestFullEntities.setCreatedBy(createdBy);

        return gxRequestFullEntities;
    }

    @Override
    public GxActionFullEntities from(GxAction gxAction) throws ProfileNotFoundException, ProfileChainException {

        // authoredBy is only set for internal actions
        UserProfile authoredBy = null;
        if (gxAction.getAuthoredBy() != null) {
            authoredBy = UserProfileCacheImpl.filterUserProfile(this.userProfileCache.get(gxAction.getAuthoredBy()));
        }

        // createdBy can be stripped out of GxActions
        OrgProfile createdBy = null;
        if (gxAction.getCreatedBy() != null) {
            createdBy = OrgCacheImpl.filterOrgProfile(this.orgCache.get(gxAction.getCreatedBy()).getProfile());
        }

        GxActionFullEntities gxActionFullEntities = new GxActionFullEntities();
        gxActionFullEntities.setId(gxAction.getId());
        gxActionFullEntities.setGxRequestId(gxAction.getGxRequestId());
        gxActionFullEntities.setPayload(gxAction.getPayload());
        gxActionFullEntities.setActionId(gxAction.getActionId());
        gxActionFullEntities.setScope(gxAction.getScope());
        gxActionFullEntities.setType(gxAction.getType());
        gxActionFullEntities.setAuthoredBy(authoredBy);
        gxActionFullEntities.setCreatedBy(createdBy);
        gxActionFullEntities.setCreatedAt(gxAction.getCreatedAt());
        return gxActionFullEntities;
    }
}
