package com.ibm.au.bgx.common.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.nimbusds.oauth2.sdk.token.AccessToken;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;
import java.io.IOException;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public abstract class AbstractRemoteClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractRemoteClient.class);

    protected static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    protected IdentityConfiguration identityConfig;

    @Autowired
    protected OrganizationManager organizationManager;

    @Autowired
    private BgxEncryptionUtil bgxEncryptionUtil;

    @Autowired
    private SSLUtils sslUtils;

    @Autowired
    private AccessTokenProvider accessTokenProvider;

    @Autowired
    private IdentityConfiguration identity;

    /**
     * Maximum number of retry attempts to connect to an API
     */
    @Value("${connection.retry.maxAttempt:120}")
    private int retryMaxAttempts;

    /**
     * Sleep time in milliseconds between reconnect attempts
     */
    @Value("${connection.retry.sleepTime:1000}")
    private int retrySleepTime;

    /**
     * Create JWT token
     * <p>
     * Here we use openId client to get the access token using the apiAuth
     */
    protected String getAccessTokenHeader(String accessTokenUri, String clientId, String clientSecret) {

        OpenIdConfig apiAuth = new OpenIdConfig();
        apiAuth.setClientId(clientId);
        apiAuth.setClientSecret(clientSecret);
        apiAuth.setAccessTokenUri(accessTokenUri);

        return this.getAccessTokenHeader(apiAuth);
    }

    protected String getAccessTokenHeader(OpenIdConfig apiAuth) {
        AccessToken accessToken = this.getAccessToken(apiAuth);
        return accessToken.toAuthorizationHeader();
    }

    protected AccessToken getAccessToken(OpenIdConfig apiAuth) {
        return accessTokenProvider.getAccessToken(apiAuth);
    }

    public HttpHeaders getHeaders() throws ServiceUnavailableException {

        LOGGER.debug(BgxLogMarkers.DEV, "Preparing headers for remote API calls.");

        Organization organization = null;
        try {
            organization = organizationManager.getById(identity.getIdentity());
        } catch (ProfileNotFoundException | ProfileChainException e) {
            throw new IllegalArgumentException(
                    String.format("Organization could not be found with ID: %s", identity.getIdentity()), e);
        }

        if (organization.getSettings() == null
                || organization.getSettings().getApiAuth() == null) {
            throw new IllegalStateException("Organization does not have open ID configuration");
        }

        OpenIdConfig apiAuth = organization.getSettings().getApiAuth();
        if (apiAuth.getAccessTokenUri() == null || apiAuth.getAccessTokenUri().isEmpty()) {
            throw new IllegalArgumentException("OpenId Access token URL is empty");
        }

        if (apiAuth.getClientId() == null || apiAuth.getClientId().isEmpty()) {
            throw new IllegalArgumentException("OpenId client Id is empty");
        }

        if (apiAuth.getClientSecret() == null || apiAuth.getClientSecret().isEmpty()) {
            throw new IllegalArgumentException("OpenId client secret is empty");
        }

        try {
            if (!this.isHostReachable(apiAuth.getAccessTokenUri(), 10)) {
                throw new ServiceUnavailableException(String.format("URL %s is not reachable", apiAuth.getAccessTokenUri()));
            }
        } catch (ServiceUnavailableException e) {
            throw e;
        } catch (InterruptedException | URISyntaxException | IOException e) {
            throw new ServiceUnavailableException(String.format("URL %s is not reachable", apiAuth.getAccessTokenUri()), e);
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", this.getAccessTokenHeader(apiAuth));

        headers.add(IdentityConfiguration.SOURCE_IDENTITY_HEADER_INTERNAL, this.identityConfig.getInternalUrl());
        headers.add(IdentityConfiguration.SOURCE_IDENTITY_HEADER_NAME, this.identityConfig.getIdentity());

        try {
            LOGGER.debug("Headers: {}",MAPPER.writeValueAsString(headers));
        } catch (JsonProcessingException e) {
            LOGGER.debug("Could not read headers", e);
        }

        return headers;
    }

    /**
     * Helper function to check if a socket can be opened against a URL (host and port)
     *
     * @throws URISyntaxException
     * @throws IOException
     */
    protected boolean isHostReachable(String urlString, int maxAttempts)
            throws InterruptedException, URISyntaxException, IOException {

        URI uri = new URI(urlString);

        boolean isHTTPS = this.sslUtils.isSSL(uri);

        SocketFactory factory = (isHTTPS ? this.sslUtils.getSSLSocketFactory() : SSLSocketFactory.getDefault());
        int port = (uri.getPort() == -1 ? (isHTTPS ? 443 : 80) : uri.getPort());


        int attempt = 0;
        boolean isAvailable = false;

        LOGGER.debug(
                "Trying to connect to URL '{}' with max attempt '{}' and sleep time '{}' milliseconds",
                urlString, maxAttempts, retrySleepTime);

        if (maxAttempts < 0) {
            maxAttempts = retryMaxAttempts;
        }

        Socket s = null;
        while (!isAvailable && attempt < maxAttempts) {
            try {

                s = factory.createSocket(uri.getHost(), port);
                isAvailable = true;

            } catch (IOException | HttpStatusCodeException e) {
                // nothing to do here with the exception since we shall keep trying

                LOGGER.debug(BgxLogMarkers.DEV,
                        String.format(
                                "Host unreachable at: '%s'. "
                                        + "Reconnect in '%d' ms. "
                                        + "Attempted '%d' times out of maximum '%d'.",
                                urlString, retrySleepTime, attempt, maxAttempts));

            } finally {
                try {
                    if (s != null) {
                        s.close();
                    }
                } catch (IOException e) {
                    // nothing to do but we keep a stack trace in the log for later debugging
                    LOGGER.warn(BgxLogMarkers.DEV, "Could not close socket", e);

                }

                Thread.sleep(retrySleepTime); // sleep 1 sec
                attempt++;
            }
        }

        return isAvailable;
    }

    protected boolean isApiReady(String baseUrl, int maxAttempts)
            throws InterruptedException {

        int attempt = 0;
        boolean isAvailable = false;

        if (maxAttempts < 0) {
            maxAttempts = retryMaxAttempts;
        }

        String statusUrl = String.format("%s/_status/ready", baseUrl);
        LOGGER.debug(BgxLogMarkers.DEV, "Checking if API is ready: {}", statusUrl);
        try {
            RestTemplate rest = this.getRestTemplate(baseUrl);

            while (!isAvailable && attempt < maxAttempts) {

                try {
                    LOGGER.debug(BgxLogMarkers.DEV, "Retrying if API is ready: {}, attempts ({}/{})", statusUrl, attempt, maxAttempts);
                    // call _status/ready endpoint to find out if host is able to receive requests
                    ResponseEntity<String> response = rest
                            .exchange(statusUrl, HttpMethod.GET,
                                    new HttpEntity<>(null, new HttpHeaders()), String.class);

                    // status code has to be 200
                    if (response.getStatusCode().equals(HttpStatus.OK)) {
                        isAvailable = true;
                    } else {
                        throw new IOException("Status check failed, host not reachable");
                    }
                } catch (IOException | ResourceAccessException e) {

                    // just log a short message without the exception stack trace
                    LOGGER.debug(BgxLogMarkers.DEV,
                        "API unreachable at: '{}', attempt {} / {}.",
                        statusUrl, attempt, maxAttempts);

                    // log with the stack trace
                    LOGGER.warn(
                        "API unreachable at: '{}', attempt {} / {}.",
                        statusUrl, attempt, maxAttempts, e);
                }

                // sleep 1 sec
                Thread.sleep(retrySleepTime);
                attempt++;
            }

        } catch (IOException | URISyntaxException ioex) {
           LOGGER.error(BgxLogMarkers.DEV, String.format("Invalid API URI (uri: %s)", baseUrl), ioex);
        }

        return isAvailable;
    }

    /**
     * Add request hash header based on the payload
     * <p>
     * It computes a signature using the fabric user of the given orgId Usually orgId refers to the
     * bgxIdentity property
     */
    protected void addRequestHash(HttpHeaders headers, Object payload, String orgId) {

        if (orgId == null) {
            orgId = this.identity.getIdentity();
        }

        String requestHash = this.bgxEncryptionUtil.computeRequestHash(payload, orgId);

        LOGGER.debug(BgxLogMarkers.DEV, "Adding request hash: {}", requestHash);
        headers.add(ApiConstants.REQUEST_HASH, requestHash);

        LOGGER.debug(BgxLogMarkers.DEV, 
        			 "Request hash is verifiable: {}", 
        			 this.bgxEncryptionUtil.verifyRequestHash(payload, requestHash, this.identity.getIdentity())
        			);
    }


    protected RestTemplate getRestTemplate(String baseUrl) throws IOException, URISyntaxException {

        ClientHttpRequestFactory requestFactory;

        if (this.sslUtils.isSSL(baseUrl)) {

            SSLConnectionSocketFactory factory = this.sslUtils.getSSLConnectionSocketFactory();
            HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(factory).build();
            requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

        } else {

            requestFactory = new SimpleClientHttpRequestFactory();
        }
        RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(requestFactory));
        restTemplate.getMessageConverters().add(0, mappingJacksonHttpMessageConverter());

        return restTemplate;
    }


    private MappingJackson2HttpMessageConverter mappingJacksonHttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(JacksonUtil.createObjectMapper());
        return converter;
    }
}
