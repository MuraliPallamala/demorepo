package com.ibm.au.bgx.common.user;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.ibm.au.bgx.common.util.ListUtil;
import com.ibm.au.bgx.common.util.PojoUtil;
import com.ibm.au.bgx.common.util.TraceUtil;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.audit.AuditConstants;
import com.ibm.au.bgx.model.audit.AuditManager;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.chain.profile.UserProfileManager;
import com.ibm.au.bgx.model.exception.BgxForbiddenException;
import com.ibm.au.bgx.model.exception.IdentityProviderException;
import com.ibm.au.bgx.model.identityprovider.ManagedIdentityProviderClient;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.notification.WebNotificationManager;
import com.ibm.au.bgx.model.pojo.AgreementInfo;
import com.ibm.au.bgx.model.pojo.ApiKey;
import com.ibm.au.bgx.model.pojo.AuthTokenInfo;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.Credentials;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Role;
import com.ibm.au.bgx.model.pojo.Role.Source;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.UserProfile.Status;
import com.ibm.au.bgx.model.pojo.api.request.ApiKeyRequest;
import com.ibm.au.bgx.model.pojo.api.request.SetOtpRequest;
import com.ibm.au.bgx.model.pojo.api.request.UserProfileUpdateRequest;
import com.ibm.au.bgx.model.pojo.api.request.UserTaskRequest;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.system.SystemActionType;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.pojo.task.UserBatchUpdateTaskDetail;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.repository.BatchProcessTaskRepository;
import com.ibm.au.bgx.model.repository.UserProfileRepository;

import java.io.IOException;
import java.math.BigInteger;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.EmailValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Class <b>UserProfileManagerImpl</b>. This is the default implementation of the {@link UserProfileManager}
 * interface which uses a configured implementation of {@link UserProfileRepository} to manage the user 
 * profiles associated to the solution.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 * 
 * @see com.ibm.au.bgx.model.repository.UserProfileRepository
 * @see com.ibm.au.bgx.model.chain.profile.UserProfileManager
 */

@Component
public class UserProfileManagerImpl implements UserProfileManager {

	/**
	 * A {@link Logger} implementation that is used to collect all the log messages for all
	 * the instances of this class.
	 */
    private static final Logger LOGGER = LoggerFactory.getLogger(UserProfileManagerImpl.class);

    
    /**
     * A {@link EmailValidator} instance that is used to verify the emails of th
     * users that are submitted during the creation of user profiles.
     */
    private static EmailValidator validator = EmailValidator.getInstance();

    /**
     * A {@link UserProfileRepository} that is used to store the user profile managed by
     * this component. The repository implements a basic CRUD data store with some additional
     * query capabilities to facilitate the operations of the manager.
     */
    @Autowired
    protected UserProfileRepository repository;

    @Autowired
    protected BatchProcessTaskRepository taskRepository;

    @Autowired
    protected AuditManager auditManager;

    @Autowired
    protected QueueClient queueClient;

    @Value("${bgx.auth.maxAllowedAuthTokens:5}")
    protected int maxAllowedAuthTokens;


    /*******************************************************************************************/
    /**  CREATE METHODS                                                                        */
    /*******************************************************************************************/

    /**
     * <p>
     * Creates the corresponding {@link UserProfile} instances for the contacts that are
     * listed within the given <i>organization</i> and assigns them the given <i>status</i>.
     * </p>
     * <p>
     * The method only creates those user profile that do not already exist, if there is an
     * existing profile, the method will skip the creation.
     * </p>
     *
     * @param orgId a {@link String} containing the organization Id of a newly created organization
     *
     * @param contacts a {@link List} containing contacts for the organization
     *
     * @param orgRoles a {@link List} containing default roles {@link Role} of the organization
     *
     * @param status        a {@link Status} value that represents the value of the status that
     * 						will be assigned to the newly created {@link UserProfile} instances.
     *
     * @return a {@link List} of {@link UserProfile} instances that represent the corresponding
     * 			{@link UserProfile} that match the contact list passed through the <i>organization</i>
     * 			argument.
     *
     * @throws IllegalArgumentException
     *
     * 			an exception of this type is called in any of the following cases:
     * 			<ul>
     * 			<li><i>orgId</i> is {@literal null}</li>
     * 			<li><i>contacts</i> is {@literal null}</li>
     * 			<li><i>orgRoles</i> is {@literal null}</li>
     * 			<li>the list of default roles is not included in <i>organization</i> or is empty</li>
     * 			<li><i>status</i> is {@literal null}</li>
     * 			</ul>
     */
    @Override
    public List<UserProfile> createOrganizationUsers(String orgId, List<ContactInfo> contacts, List<Role> orgRoles, Status status) {
    	
    	
    	if (orgId == null) {
    		
    		throw new IllegalArgumentException("Parameter 'orgId' cannot be null.");
    	}

        if (orgRoles == null || orgRoles.isEmpty()) {

            throw new IllegalArgumentException("Parameter 'orgRoles' cannot be empty.");
        }

        if (contacts == null) {
    	    throw new IllegalArgumentException("Parameter 'contacts' cannot be empty.");
        }

    	if (status == null) {
    		
    		throw new IllegalArgumentException("Parameter 'status' cannot be null.");
    	}

        List<UserProfile> records = new ArrayList<>();

        // create users
        for (ContactInfo contact : contacts) {
        	
        	
        	TraceUtil.trace(LOGGER, "Found contact information: %s", contact);


            // do not create the same user in the same org
            UserProfile existing = this.getByEmail(orgId, contact.getEmail());

            if (existing == null) {
                UserProfile userProfile = new UserProfile();
                userProfile.setFirstName(contact.getFirstName());
                userProfile.setLastName(contact.getLastName());
                userProfile.setEmail(contact.getEmail().toLowerCase());
                userProfile.setPrimaryOrgId(orgId);
                userProfile.setPhone(contact.getPhone());
                userProfile.setUserRoles(new HashMap<>());
                userProfile.setCredentials(contact.getCredentials());
                userProfile.setStatus(status);
                userProfile.setAgreement(contact.getAgreement());

                List<String> roles = new ArrayList<>();
                for (String roleName : contact.getRoles()) {
                    for (Role role : orgRoles) {
                        if (role.getSource() != null
                            && role.getSource().equals(Source.SYSTEM)
                            && role.getRoleName().equals(roleName)
                            && !roles.contains(roleName)) {

                            roles.add(roleName);
                        }

                    }
                }

                if (roles.isEmpty()) {
                    throw new IllegalArgumentException("User roles could not be found in default roles of the organization");
                }

                // If user is ACTIVE add the USER role if it is not set already
                if (status == Status.ACTIVE && !roles.contains(BgxConstants.ROLE_USER)) {
                    roles.add(BgxConstants.ROLE_USER);
                }

                userProfile.getUserRoles().put(orgId, roles);
                
                records.add(this.create(userProfile));

                if (status == Status.ACTIVE) {
                    Map<String, Object> auditData = new HashMap<>();
                    auditData.put(AuditConstants.AUDIT_DATA_USER, userProfile);
                    auditData.put(AuditConstants.AUDIT_DATA_ROLE, userProfile.getUserRoles().get(orgId));
                    auditData.put(AuditConstants.AUDIT_DATA_STATUS, Status.ACTIVE);
                    auditManager.logAuditEvent(SystemActionType.UPDATE_USER_STATUS.toString(), orgId, userProfile.getId(), auditData);
                }
                
                if (LOGGER.isDebugEnabled()) {

                	LOGGER.debug(String.format("Create user profile (email: %s, key: %s)", userProfile.getEmail(), userProfile.getCredentials().getKey()));
                
                }

            } else {

            	LOGGER.debug("Found user (email: {})", existing.getEmail());
            	
                records.add(existing);
            }
        }

        return records;
    }
    
    /**
     * <p>
     * Adds a new user profile. This method processes and validates the given <i>userProfile</i>
     * and if all of its properties are compliant with the requirements for a new profile record
     * the information is stored into the repository. 
     * </p>
     * <p>
     * This method takes care of:
     * <ul>
     * <li>creating a unique identifier for the user profile if not defined.</li>
     * <li>formatting in lower case the email of the user.</li>
     * </p>
     * 
	 * 
	 * @param userProfile	a {@link UserProfile} instance that is expected to not to be
	 * 					{@literal null}.
	 * 
	 * @return	an instance of {@link UserProfile} with the updated details.
	 * 
	 * @throws IllegalArgumentException	if any of the parameters are invalid.
	 * 
	 * @see com.ibm.au.bgx.model.chain.profile.UserProfileManager#create(UserProfile)
     */
    @Override
    public UserProfile create(UserProfile userProfile) {

        // check that mandatory fields are initialized
        if (userProfile.getPrimaryOrgId() == null || userProfile.getPrimaryOrgId().isEmpty()) {
            throw new IllegalArgumentException("Primary org ID is required");
        }

        if (userProfile.getFirstName() == null || userProfile.getFirstName().isEmpty()) {
            throw new IllegalArgumentException("First name is required");
        }

        if (userProfile.getLastName() == null || userProfile.getLastName().isEmpty()) {
            throw new IllegalArgumentException("Last name is required");
        }

        if (userProfile.getUserRoles() == null || userProfile.getUserRoles().isEmpty()) {
            throw new IllegalArgumentException("Roles are required");
        }
        
        
        String email = userProfile.getEmail();

        if (email == null || email.isEmpty()) {
            throw new IllegalArgumentException("Email is required");
        }
        if (!UserProfileManagerImpl.validator.isValid(email)) {
        	throw new IllegalArgumentException("The provided user profile email is not valid.");
        }
        if (userProfile.getCredentials() == null) {
        	
        	throw new IllegalArgumentException("Credentials information cannot be null.");
        }
        
        userProfile.setEmail(email.toLowerCase());
        
        String key = userProfile.getCredentials().getKey();
        if (key == null || key.isEmpty()) {

            throw new IllegalArgumentException("Key is required");
        }
        if (key.length() != BgxConstants.USER_KEY_LEN) {
            throw new IllegalArgumentException(String.format("Key should of length %d, found %d", BgxConstants.USER_KEY_LEN, key.length()));
        }

        if (this.repository.getByKey(key) != null) {
        	
            throw new IllegalArgumentException(String.format("User exists with key: %s", key));
        }

        // duplicate check for orgId and email
        if (this.getByEmail(userProfile.getPrimaryOrgId(), email) != null) {
            throw new IllegalArgumentException(String.format("User exists with email: %s", email));
        }
        
        userProfile.setId(UUID.randomUUID().toString());

        if (userProfile.getApiKeys() == null) {
            userProfile.setApiKeys(new HashMap<>());
        }

        if (userProfile.getGxLimit() == null) {
            userProfile.setGxLimit(new HashMap<>());
        }

        if (!userProfile.getGxLimit().containsKey(userProfile.getPrimaryOrgId())
            || userProfile.getGxLimit().get(userProfile.getPrimaryOrgId()) == null) {
            userProfile.getGxLimit().put(userProfile.getPrimaryOrgId(), BgxConstants.UNLIMITED_GX_LIMIT);
        }

        if (userProfile.getEnabled2fAuth() == null) {
            userProfile.setEnabled2fAuth(false);
        }

        return this.repository.addItem(userProfile);
    }
    
    
    /*******************************************************************************************/
    /**  QUERY METHODS                                                                        */
    /*******************************************************************************************/


    /**
     * {@inheritDoc}
     */
    public boolean isPrimaryUser(UserProfile userProfile) {
    	
    	if (userProfile == null) {
    		
    		throw new IllegalArgumentException("User profile cannot be null.");
    	}
    	
        String primaryOrgId = userProfile.getPrimaryOrgId();
        Map<String,List<String>> userRoles = userProfile.getUserRoles();
        List<String> roles = userRoles.get(primaryOrgId);
        
        return roles != null && roles.contains(BgxConstants.ROLE_PRIMARY);
    }

    /**
     * {@inheritDoc}
     */
    public boolean isAdminUser(UserProfile userProfile) {
    	
    	if (userProfile == null) {
    		
    		throw new IllegalArgumentException("User profile cannot be null.");
    	}
    	
        String primaryOrgId = userProfile.getPrimaryOrgId();
        Map<String,List<String>> userRoles = userProfile.getUserRoles();
        
        List<String> roles = userRoles.get(primaryOrgId);
        
        return roles != null && roles.contains(BgxConstants.ROLE_ADMIN);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public UserProfile getById(String id) {
        return this.repository.getItem(id);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public UserProfile getByEmail(String primaryOrgId, String email) {
    	
    	
    	if (primaryOrgId == null || primaryOrgId.isEmpty()) {
    		
    		throw new IllegalArgumentException("Primary Organisation identifier cannot be empty or null.");
    	}
    
    	
    	if (email == null || email.isEmpty()) {
    		
    		throw new IllegalArgumentException("User email cannot be null or an empty string.");
    	}
    	
        return this.repository.getByEmail(primaryOrgId, email.toLowerCase());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public List<UserProfile> getByPrimaryOrgId(String orgId) {
        return this.repository.getByPrimaryOrgId(orgId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<UserProfile> getByOrgRole(String orgId, String roleName) {
    	
    	return this.repository.getByOrgRole(orgId, roleName);
    }

    /**
     * {@inheritDoc}
     */	
    public boolean hasKey(String key) {
    	
    	
    	if (key == null || key.isEmpty()) {
    		
    		throw new IllegalArgumentException("Parameter 'key' cannot be null or an empty string.");
    	}
    	
    	return this.repository.getByKey(key) != null;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public UserProfile getByKeyAndToken(String key, String token) {

        if (key == null || key.isEmpty()) {
            throw new IllegalArgumentException("Key is required");
        }

        if (token == null || token.isEmpty()) {
            throw new IllegalArgumentException("Token is required");
        }

        UserProfile userProfile = this.repository.getByKey(key);

        if (userProfile != null
                && userProfile.getCredentials() != null
                && userProfile.getCredentials().getToken() != null
                && token.equals(userProfile.getCredentials().getToken())
        ) {

            return userProfile;

        }

        return null;
    }

    @Override
    public List<UserProfile> getByStatusAndOrgId(String orgId, String status) {
        return this.repository.getByPrimaryOrgIdAndStatus(orgId, status);
    }

    /*******************************************************************************************/
    /**  UPDATE METHODS                                                                        */
    /*******************************************************************************************/
    
    
    /**
     * {@inheritDoc}
     */
    @Override
    public UserProfile updateRoles(String id, List<String> roles) {
    	
    	return this.updateRoles(id, null, roles);

    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile updateRoles(String id, String orgId, List<String> roles) {

    	
        UserProfile profile = this.retrieveProfile(id);
    	
    	if (orgId == null || orgId.isEmpty()) {
    		orgId = profile.getPrimaryOrgId();
    	}
    	
    	Map<String, List<String>> userRoles = profile.getUserRoles();
    	List<String> addedRoles = ListUtil.getAddedItems(profile.getUserRoles().get(orgId), roles);
        @SuppressWarnings("unchecked")
		List<String> removedRoles = (List<String>) ListUtil.getRemovedItems(profile.getUserRoles().get(orgId), roles);

    	// in this case we are going to completely remove the roles for 
    	// an organisation, which means that we also have to remove the
    	// mapping for a given organisation.
    	//
    	if (roles == null || roles.isEmpty()) {
    		
    		// if the roles we are trying to remove are those of the primary
    		// organisation, we cannot allow to remove all the roles.
    		//
    		if (orgId.equals(profile.getPrimaryOrgId())) {
    			
    			throw new IllegalStateException("Cannot remove all roles from primary organisation.");
    		}
    		
    		userRoles.remove(orgId);
    	
    	} else {

    	    // remove null roles and empty strings
            roles = roles.stream().filter(role -> role != null && !role.isEmpty()).collect(Collectors.toList());
            // filter out duplicates
            roles = new ArrayList<>(new HashSet<>(roles));

            // update user roles of this user
    		userRoles.put(orgId, roles);

            LOGGER.debug(BgxLogMarkers.DEV,
                "Updating user {} of org {} with roles {} for org {}",
                profile.getEmail(), profile.getPrimaryOrgId(), roles, orgId);
    	}

    	if (!addedRoles.isEmpty() || !removedRoles.isEmpty()) {
            // handle notification for user role update
            WebNotification notification = new WebNotification();
            notification.setMessageType(WebNotification.MessageType.UPDATE_APPROVAL_ROLES);
            notification.setReferenceType(WebNotification.ReferenceType.ORG_UPDATE_REQUEST);
            notification.setPayload(new HashMap<>());
            notification.getPayload().put(WebNotificationManager.PAYLOAD_ROLES_ADD, addedRoles);
            notification.getPayload().put(WebNotificationManager.PAYLOAD_ROLES_REMOVE, removedRoles);
            notification.setReferenceId(profile.getId());
            notification.setReceiverId(profile.getId());
            try {
                queueClient.addWebNotification(notification);
            } catch (IOException ioe) {
                // not mission critical, just log the exception
                LOGGER.error("Could not send web notification for user role update", ioe);
            }
        }

        return this.repository.updateItem(profile);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void delete(String id) {
        UserProfile profile = this.repository.getItem(id);
        profile.setStatus(Status.DELETED);
        this.repository.updateItem(profile);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile updateGxLimit(String id, String orgId, BigInteger gxLimit) {

        UserProfile profile = this.retrieveProfile(id);
        if (profile.getGxLimit() == null) {
            profile.setGxLimit(new HashMap<>());
        }

        return updateGxLimit(profile, orgId, gxLimit);
    }

    /**
     * 
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile updateGxLimit(UserProfile profile, String orgId, BigInteger gxLimit) {

        if (profile == null) {
            throw new IllegalArgumentException("User profile cannot be null");
        }

        if (orgId == null) {
            throw new IllegalArgumentException("OrgId cannot ben null");
        }

        if (gxLimit != null && gxLimit.compareTo(BigInteger.ZERO) < 0) {
            throw new IllegalArgumentException("Gx Limit cannot be negative");
        }

        if (gxLimit == null) {
            profile.getGxLimit().remove(orgId);
        } else {
            profile.getGxLimit().put(orgId, gxLimit);
        }

        return repository.updateItem(profile);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger getGxLimit(String id, String orgId) {
        UserProfile profile = this.retrieveProfile(id);
        return getGxLimit(profile, orgId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BigInteger getGxLimit(UserProfile profile, String orgId) {
        if (profile == null) {
            throw new IllegalArgumentException("User profile cannot be null");
        }

        if (orgId == null) {
            throw new IllegalArgumentException("OrgId cannot ben null");
        }

        if (profile.getGxLimit().containsKey(orgId)) {
            return profile.getGxLimit().get(orgId);
        }

        return BigInteger.ZERO;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void setPassword(String id,
    						final String password,
    						final String realmName,
    						final ManagedIdentityProviderClient identityUserClient) throws IdentityProviderException {


        if (password == null || password.isEmpty()) {
            throw new IllegalArgumentException("Password is required");
        }

        // check if password satisfies the password policy
        if (!password.matches(BgxConstants.PASSWORD_REGEX)) {

            throw new IllegalArgumentException("Password does not conform to the valid password policy");

        }

    	UserProfile userProfile = this.retrieveProfile(id);

        if (!identityUserClient.userExists(realmName, userProfile.getEmail())) {

            throw new IllegalArgumentException( "User does not exists in federated identity provider.");
        }

        identityUserClient.setPassword(realmName, userProfile.getEmail(), password);


        LOGGER.debug(BgxLogMarkers.DEV, "Set password was successful for user (email: {})", userProfile.getEmail());


    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile updateUserDetails(String id,
    									 final UserProfileUpdateRequest userProfileRequest,
    									 final String realmName,
    									 final ManagedIdentityProviderClient identityUserClient,
                                         final String targetOrgId) throws IdentityProviderException {


        if (id == null) {
            throw new IllegalArgumentException("Id cannot be null");
        }

        if (userProfileRequest == null) {
            throw new IllegalArgumentException("User profile request payload cannot be null");
        }

        if (realmName == null) {
            throw new IllegalArgumentException("Realm name cannot be null");
        }

        if (identityUserClient == null) {
            throw new IllegalArgumentException("Identity user client cannot be null.");
        }

        if (targetOrgId == null) {
            throw new IllegalArgumentException("Target org Id cannot be null, and ideally it should be principal's primary org Id");
        }

    	UserProfile existing = this.retrieveProfile(id);
        List<String> oldRoles = existing.getUserRoles().get(targetOrgId);
    	
        if (this.copyValuesForUpdate(existing, userProfileRequest, targetOrgId)) {
            

        	// NOTE: this may be a problem as it is not transactional.
        	//       we should ensure that we either update both or
        	//       just one.
        	//
            if (identityUserClient.userExists(realmName, existing.getEmail())) {

                identityUserClient.updateUser(realmName, existing.getEmail(),
                    existing.getFirstName(),
                    existing.getLastName());
            }

            LOGGER.debug("Performing update of user details for user {}", id);
            this.repository.updateItem(existing);

            // check if the roles have updated
            List<String> newRoles = existing.getUserRoles().get(targetOrgId);
            List<String> addedRoles = ListUtil.getAddedItems(oldRoles, newRoles);
            @SuppressWarnings("unchecked")
			List<String> removedRoles = ListUtil.getRemovedItems(oldRoles, newRoles);

            if (!addedRoles.isEmpty() || !removedRoles.isEmpty()) {
                // handle notification for user role update
                WebNotification notification = new WebNotification();
                notification.setMessageType(WebNotification.MessageType.UPDATE_APPROVAL_ROLES);
                notification.setReferenceType(WebNotification.ReferenceType.ORG_UPDATE_REQUEST);
                notification.setPayload(new HashMap<>());
                notification.getPayload().put(WebNotificationManager.PAYLOAD_ROLES_ADD, addedRoles);
                notification.getPayload().put(WebNotificationManager.PAYLOAD_ROLES_REMOVE, removedRoles);
                notification.setReferenceId(existing.getId());
                notification.setReceiverId(existing.getId());
                try {
                    queueClient.addWebNotification(notification);
                } catch (IOException ioe) {
                    LOGGER.error("Could not send web notification for user role update.", ioe);
                }
            }
        }

        return existing;

    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile updateUserStatus(String id, UserProfile.Status status) {
    	
    	if (status == null) {
    		
    		throw new IllegalArgumentException("User status cannot be null.");
    	}
    	
    	UserProfile userProfile = this.retrieveProfile(id);
    	
    	userProfile.setStatus(status);
    	
    	Credentials credentials = null;

    	// we ensure that the user cannot login anymore
    	// with PIN and token.
    	//
    	if (status.equals(Status.ACTIVE) && 
    		((credentials = userProfile.getCredentials()) != null) &&
    		(credentials.getKey() != null)) {
    		
    		// NOTE: We could nullify the entire set of credentials.
    		//
    		credentials.setKey(null);
    		credentials.setToken(null);
	        
    	}

        // If user is ACTIVE add the USER role if it is not set already
        if (status == Status.ACTIVE
            && !userProfile.getUserRoles()
                .get(userProfile.getPrimaryOrgId())
                .contains(BgxConstants.ROLE_USER)) {

                userProfile.getUserRoles()
                    .get(userProfile.getPrimaryOrgId()).add(BgxConstants.ROLE_USER);
        }

    	return this.repository.updateItem(userProfile);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile updateAgreement(String id, AgreementInfo agreement) {
    	
    	UserProfile userProfile = this.retrieveProfile(id);
    	
    	userProfile.setAgreement(agreement);
    	
    	return this.repository.updateItem(userProfile);   	
    }



    
    /*******************************************************************************************/
    /**  HELPER METHODS                                                                        */
    /*******************************************************************************************/
    
    
    
    /**
     * <p>
     * Copies the properties that are in the given user profile request into the given {@link 
     * UserProfile} instance. The method only copies those properties that are allowed according
     * to {@link BgxConstants#allowedUserFieldsForUpdate} and if these are not {@literal null}
     * or empty.
     * </p>
     * <p>
     * The method modifies the input parameter `updated` and return {@literal true} if update is required.
     * </p>
     * 
     * @param updated				a {@link UserProfile} to update.
     * @param userProfileRequest	a {@link UserProfileRequest} instance that is used as source
     * 								of parameters for the update.
     * 
     * @return {@literal true} if any allowed attribute has been updated, {@literal false} otherwise.
     */
    protected boolean copyValuesForUpdate(UserProfile updated, final UserProfileUpdateRequest userProfileRequest, String targetOrgId) {


        boolean requireUpdate = false;

        // only update the allowed fields
        for (String field : BgxConstants.allowedUserFieldsForUpdate) {
            switch (field) {

                case BgxConstants.USER_FIRST_NAME:

                    if (userProfileRequest.getFirstName() != null && !userProfileRequest.getFirstName().isEmpty()) {
                        updated.setFirstName(userProfileRequest.getFirstName());
                        requireUpdate = true;
                    }

                    break;

                case BgxConstants.USER_LAST_NAME:

                    if (userProfileRequest.getLastName() != null && !userProfileRequest.getLastName().isEmpty()) {
                        updated.setLastName(userProfileRequest.getLastName());
                        requireUpdate = true;
                    }

                    break;

                case BgxConstants.USER_PHONE:

                    if (userProfileRequest.getPhone() != null && !userProfileRequest.getPhone().isEmpty()) {
                        updated.setPhone(userProfileRequest.getPhone());
                        requireUpdate = true;
                    }

                    break;

                // [CV] NOTE: this is not a capability that we implement through the
                //			  user details method. For the update of roles we should
                //            use update roles.
                //    
                case BgxConstants.USER_ROLES:

                    // It expects the validity of the roles has been done already so that it can set
                    // the roles from the input payload
                    LOGGER.debug("User profile with roles {}, existing role {}", userProfileRequest.getRoles(), updated.getUserRoles());
                    if (userProfileRequest.getRoles() != null && !userProfileRequest.getRoles().isEmpty()) {
                        updated.getUserRoles().put(targetOrgId, userProfileRequest.getRoles());
                        requireUpdate = true;
                    }

                    break;

                case BgxConstants.GX_LIMIT:
                    if (userProfileRequest.getGxLimit() != null) {

                        if (updated.getGxLimit() == null) {
                            updated.setGxLimit(new HashMap<>());
                        }

                        // Note, we assume appropriate access control has already been done for the targetOrgId
                        // Here, targetOrgId can be either the user's primaryOrgId or id of another linked organization
                        updated.getGxLimit().put(targetOrgId, userProfileRequest.getGxLimit());

                        requireUpdate = true;
                    }

                    break;

                default:
                    break;
            }
        }

        return requireUpdate;
    }
    
    /**
     * Retrieves the user profile that matches the given user identifier. This is an utility method
     * that is used internally to shared the common need of retrieving a profile from a given 
     * identifier used by more selective update methods.
     * 
     * @param id	a {@link String} representing the unique identifier of the user. It cannot be 
     * 				{@literal null} or an empty string.
     * @return
     */
    private UserProfile retrieveProfile(String id) {
    	
    	if (id == null || id.isEmpty()) {
    		
    		throw new IllegalArgumentException("Parameter 'id' cannot be null or an empty string.");
    	}

    	UserProfile userProfile = this.repository.getItem(id);
    	
    	if (userProfile == null) {
    		
    		throw new IllegalStateException(String.format("User profile matching %s does not exit.", id));
    	}
    	
    	return userProfile;
	}

    @Override
    public BatchProcessTask addTask(UserProfile userProfile, UserTaskRequest taskRequest) {
        return addTask(userProfile, taskRequest, userProfile.getPrimaryOrgId(), userProfile.getPrimaryOrgId());
    }

    /**
     * Add task for the given user
     *
     * @param userProfile A {@link UserProfile} of the user creating the task
     * @param taskRequest A {@link UserTaskRequest} containing the task request
     * @param sourceOrgId A {@link String} containing the org id of the users to be updated
     * @param targetOrgId a {@link String} containing the org id of the roles the users will be assigned to
     * @return
     */
    @Override
    public synchronized BatchProcessTask addTask(UserProfile userProfile, UserTaskRequest taskRequest, String sourceOrgId, String targetOrgId) {


        if (userProfile == null) {
            throw new IllegalArgumentException("User profile is required");
        }

        if (taskRequest == null) {
            throw new IllegalArgumentException("Task is required");
        }
    	
        LOGGER.debug(BgxLogMarkers.DEV,
        			 "Creating {} task for user {} with sourceOrg {} and targetOrg {}",
        			 taskRequest.getType(), userProfile.getEmail(), sourceOrgId, targetOrgId);


        if (BgxConstants.VALID_USER_TASK_TYPES.contains(taskRequest.getType())) {


            UserBatchUpdateTaskDetail taskDetail = null;
        	Object zombie = taskRequest.getPayload().get(BgxConstants.TASK);
        	if (zombie instanceof UserBatchUpdateTaskDetail) {
        		taskDetail = (UserBatchUpdateTaskDetail) zombie;
        	} else {
        		@SuppressWarnings("unchecked")
    			Map<String, Object> raw = (Map<String,Object>) zombie;
                taskDetail = PojoUtil.toPojo(raw, UserBatchUpdateTaskDetail.class);
        	}
        	
        	

            if (taskDetail.getScope() == null
                || !taskDetail.getScope().containsKey(BgxConstants.TASK_SCOPE_ROLE)) {

                throw new IllegalArgumentException(String
                    .format("Scope '%s' is required for bulk user update tasks.",
                        BgxConstants.TASK_SCOPE_ROLE));
            }

            // overwrite or set appropriately
            taskDetail.setSourceOrgId(sourceOrgId); // users of this org
        	taskDetail.setTargetOrgId(targetOrgId); // configure for this org. e.g. roles of this org
            taskRequest.getPayload().put(BgxConstants.TASK, taskDetail);
        }

        // prepare the batch process task
        BatchProcessTask batchTask = new BatchProcessTask();
        batchTask.setOrgId(userProfile.getPrimaryOrgId()); // we don't use targetOrgId since it may cause confusion
        batchTask.setUserId(userProfile.getId());
        batchTask.setPayload(taskRequest.getPayload());
        batchTask.setType(taskRequest.getType());
        batchTask.setAsync(taskRequest.getAsync());
        batchTask.setResult(new HashMap<>());
        batchTask.setErrorLogs(new ArrayList<>());
        batchTask.setBatchSize(BigInteger.valueOf(BgxConstants.MAX_TASK_BATCH_SIZE));
        batchTask.setLastProcessed(null);
        batchTask.setProcessed(BigInteger.ZERO);

        batchTask.setStatus(BatchProcessTask.Status.PENDING);

        return taskRepository.addItem(batchTask);
    }

    @Override
    public synchronized void deleteTask(UserProfile userProfile, String taskId) {

        BatchProcessTask task = taskRepository.getItem(taskId);

        if (!task.getUserId().equals(userProfile.getId())) {
            throw new IllegalArgumentException("Task does not belong to the user and cannot be deleted");
        }

        if (!task.getStatus().equals(BatchProcessTask.Status.COMPLETED)) {
            throw new IllegalStateException(String.format("Cannot delete a task that is not in %s status.", BatchProcessTask.Status.COMPLETED));
        }

        this.taskRepository.removeItem(taskId);
    }

    @Override
    public List<BatchProcessTask> retrieveTasks(UserProfile userProfile) {

        if (userProfile == null) {
            throw new IllegalArgumentException("User profile is required");
        }

        return this.taskRepository.findByUserId(userProfile.getPrimaryOrgId(), userProfile.getId());
    }

    // [CV] TODO: Fix this there is an exception here that swallows everything that happens,
    //            we should properly handle this scenario and bubble up the relevant exceptions.
    /**
     * {@inheritDoc}
     */
    @Override
    public BatchProcessTask getTask(UserProfile userProfile, String taskId) {
        try {
            BatchProcessTask task = this.taskRepository.getItem(taskId);
            if (task != null && 
            	task.getOrgId().equals(userProfile.getPrimaryOrgId()) && 
            	task.getUserId().equals(userProfile.getId())) {
                return task;
            }
            
        } catch (Exception e) {
        	
        	LOGGER.error("Could not retrieve task with id {} [error: {}, type: {}] ", taskId, e.getMessage(), e.getClass().getName(), e);
        }

        return null;

	}
    /**
     * Remove all the roles of the org base on role source type
     *
     * For example, this method can be used to remove all roles related to APPROVAL_MODEL
     *
     * @param org
     * @param userProfile
     * @param organizationManager
     * @param roleSource
     * @return
     */
    public synchronized UserProfile removeOrgRolesByRoleSource(Organization org, UserProfile userProfile, OrganizationManager organizationManager, Source roleSource) {

        if (!userProfile.getUserRoles().containsKey(org.getId())) {
            return userProfile;
        }

        List<String> rolesToRemove = new ArrayList<>();
        for (String existingRole : userProfile.getUserRoles().get(org.getId())) {
            Role role = organizationManager.getOrgRole(org, existingRole);

            if (role == null || role.getSource().equals(roleSource)) {
                rolesToRemove.add(existingRole);
            }

        }
        List<String> roles = userProfile.getUserRoles().get(org.getId());

        for (String existingRole : rolesToRemove) {
            roles.remove(existingRole);
        }

        return this.updateRoles(userProfile.getId(), org.getId(), roles);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized ApiKey generateApiKey(String userId, ApiKeyRequest apiKeyRequest) {

        if (userId == null) {
            throw new IllegalArgumentException("User Id cannot be null");
        }

        UserProfile userProfile = this.getById(userId);

        if (userProfile.getId() == null || userProfile.getId().isEmpty()) {
            throw new IllegalArgumentException("User profile does not have ID. An existing user profile is needed");
        }

        if (apiKeyRequest == null) {
            throw new IllegalArgumentException("Api key request cannot be empty");
        }

        if (userProfile.getApiKeys() == null) {
            userProfile.setApiKeys(new HashMap<>());
        }

        // create key
        ApiKey apiKey = new ApiKey();
        apiKey.setId(UUID.randomUUID().toString());
        apiKey.setDescription(apiKeyRequest.getDescription());
        apiKey.setKey(BgxConstants.USER_API_KEY_PREFIX + UUID.randomUUID().toString()); // For now we just use a UUID
        apiKey.setCreatedAt(Instant.now());
        userProfile.getApiKeys().put(apiKey.getId(), apiKey);

        // store in the user profile
        this.repository.updateItem(userProfile);

        return apiKey;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile deleteApiKey(String userId, String keyId) {

        if (userId == null) {
            throw new IllegalArgumentException("User Id cannot be null");
        }

        UserProfile userProfile = this.getById(userId);

        if (userProfile.getApiKeys() == null || !userProfile.getApiKeys().containsKey(keyId)) {
            throw new IllegalArgumentException(
                String.format("API key couldn't be found with id: %s", keyId));
        }

        userProfile.getApiKeys().remove(keyId);
        return this.repository.updateItem(userProfile);
    }



    /**
     * {@inheritDoc}
     */
    @Override
    public UserProfile getByApiKey(String apiKey) {
        return this.repository.getByApiKey(apiKey);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile enable2FAuth(String userId, String realmName,
        ManagedIdentityProviderClient identityClient, SetOtpRequest otpRequest)
        throws IdentityProviderException {

        UserProfile userProfile = this.retrieveProfile(userId);

        identityClient.setOtp(realmName, userProfile.getEmail(),
            otpRequest.getSecret(),
            otpRequest.getToken());

        // set the flag
        userProfile.setEnabled2fAuth(true);

        return this.repository.updateItem(userProfile);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile disable2FAuth(String userId, String realmName,
        ManagedIdentityProviderClient identityClient) throws IdentityProviderException {

        UserProfile userProfile = this.retrieveProfile(userId);

        identityClient.deleteOtp(realmName, userProfile.getEmail());

        // set the flag
        userProfile.setEnabled2fAuth(false);

        return this.repository.updateItem(userProfile);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile updateLastLogin(String userId, String authToken, Instant authTokenExpiry) {

        if (userId == null || userId.isEmpty()) {
            throw new IllegalArgumentException("User Id cannot be empty.");
        }

        if (authToken == null || authToken.isEmpty()) {
            throw new IllegalArgumentException("Auth token cannot be empty");
        }

        if (authTokenExpiry == null) {
            throw new IllegalArgumentException("Auth token expiry cannot be empty");
        }

        UserProfile userProfile = this.retrieveProfile(userId);
        userProfile.setLastAuthTokenHash(computeAuthTokenHash(authToken));
        userProfile.setLastAuthTokenExpiry(authTokenExpiry);
        userProfile.setLastLoginAt(Instant.now());


        // add new and prune allowed auth tokens
        return this.updateAllowedAuthTokens(userProfile, authToken, authTokenExpiry);
    }
    
    /**
     * 
     * @param userProfile
     * @param authToken
     * @param authTokenExpiry
     * @return
     */
    private synchronized UserProfile updateAllowedAuthTokens(UserProfile userProfile, String authToken, Instant authTokenExpiry) {

        // include new
        if (authToken != null && authTokenExpiry != null) {
            userProfile.getAllowedAuthTokens()
                .add(prepareAuthTokenInfo(authToken, authTokenExpiry));
        }

        // prune allowed auth tokens
        List<AuthTokenInfo> prunedList = pruneAllowedAuthTokens(userProfile);
        if (prunedList.size() > maxAllowedAuthTokens) {
            throw new BgxForbiddenException(
                String.format("Reached the max limit of auth tokens: %d. Cannot store the new token.", maxAllowedAuthTokens));
        }
        userProfile.setAllowedAuthTokens(prunedList);

        return this.repository.updateItem(userProfile);
    }

    @Override
    public synchronized UserProfile updateAllowedAuthTokens(String userId, String authToken, Instant authTokenExpiry) {

        if (userId == null || userId.isEmpty()) {
            throw new IllegalArgumentException("User Id cannot be empty.");
        }

        UserProfile userProfile = this.retrieveProfile(userId);
        return this.updateAllowedAuthTokens(userProfile, authToken, authTokenExpiry);
    }

    private AuthTokenInfo prepareAuthTokenInfo(String authToken, Instant authTokenExpiry) {

        if (authToken == null || authToken.isEmpty()) {
            throw new IllegalArgumentException("Auth token cannot be empty");
        }

        if (authTokenExpiry == null) {
            throw new IllegalArgumentException("Auth token expiry cannot be empty");
        }

        AuthTokenInfo newTokenInfo = new AuthTokenInfo();
        newTokenInfo.setTokenHash(computeAuthTokenHash(authToken));
        newTokenInfo.setExpireAt(authTokenExpiry);

        return newTokenInfo;
    }

    private List<AuthTokenInfo> pruneAllowedAuthTokens(UserProfile userProfile) {
        List<AuthTokenInfo> allowedTokens = new ArrayList<>();
        @SuppressWarnings("unchecked")
		Map<String, Instant> tokenMap = new HashedMap(); // to avoid duplicates

        if (userProfile.getAllowedAuthTokens() == null) {
            return allowedTokens;
        }

        Instant curTime = Instant.now();
        for(AuthTokenInfo tokenInfo : userProfile.getAllowedAuthTokens()) {
            if (tokenInfo.getExpireAt().isAfter(curTime)
                && !tokenMap.containsKey(tokenInfo.getTokenHash())) {

                allowedTokens.add(tokenInfo);
                tokenMap.put(tokenInfo.getTokenHash(), tokenInfo.getExpireAt());
            }
        }

        return allowedTokens;
    }

    @Override
    public boolean hasAnotherActiveLoginSession(UserProfile userProfile, String authToken, Instant authTokenIssuedAt) {

        if (userProfile == null) {
            throw new IllegalArgumentException("User profile cannot be empty.");
        }

        if (authToken == null || authToken.isEmpty()) {
            throw new IllegalArgumentException("Auth token cannot be empty");
        }

        if (authTokenIssuedAt == null) {
            throw new IllegalArgumentException("Auth token issuedAt cannot be empty");
        }

        // if no token is stored, then user is not logged in
        if (userProfile.getLastAuthTokenHash() == null) {
            return false;
        }

        // if tokenHash matches with existing, then it is not different login session
        String tokenHash = computeAuthTokenHash(authToken);
        if (tokenHash.equals(userProfile.getLastAuthTokenHash())) {
            return false;
        }

        // If previous auth token has expired and a new token is issued after the expiry
        // there is no other active session
        //
        // This scenario happens if user has not logged out from previous session
        if (userProfile.getLastAuthTokenExpiry() == null
            || userProfile.getLastAuthTokenExpiry().isBefore(authTokenIssuedAt)) {
            return false;
        }

        // If we are here then it means
        // User is trying to login using a new JWT token but the previous one has not expired yet

        return true;
    }

    @Override
    public AuthTokenInfo getAllowedAuthTokenInfo(UserProfile userProfile, String authToken) {

        if (userProfile == null) {
            throw new IllegalArgumentException("User profile cannot be null");
        }

        if (StringUtils.isEmpty(authToken)) {
            throw new IllegalArgumentException("Jwt parameter cannot be null");
        }

        if (userProfile.getAllowedAuthTokens() == null) {
            return null;
        }

        String tokenHash = computeAuthTokenHash(authToken);
        for(AuthTokenInfo authTokenInfo : userProfile.getAllowedAuthTokens()) {
            if (!StringUtils.isEmpty(authTokenInfo.getTokenHash())
                && authTokenInfo.getTokenHash().equals(tokenHash)) {
                return authTokenInfo;
            }
        }

        return null;
    }

    @Override
    public boolean isUnusedAuthToken(UserProfile userProfile, String authToken ) {

        if (userProfile == null) {
            throw new IllegalArgumentException("User profile cannot be null");
        }

        if (StringUtils.isEmpty(authToken)) {
            throw new IllegalArgumentException("Jwt parameter cannot be null");
        }

        AuthTokenInfo authTokenInfo = getAllowedAuthTokenInfo(userProfile, authToken);

        // Return true, if it is an allowed token, not in use and not expired
        return authTokenInfo != null // allowed token
            && !authTokenInfo.getTokenHash().equals(userProfile.getLastAuthTokenHash()) // not in use
            && authTokenInfo.getExpireAt().isAfter(Instant.now()); // not expired
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized UserProfile resetLastLogin(String userId) {

        UserProfile userProfile = this.retrieveProfile(userId);
        userProfile.setLastAuthTokenHash(null);
        userProfile.setLastAuthTokenExpiry(null);
        userProfile.setLastLoginAt(null);
        userProfile.setAllowedAuthTokens(new ArrayList<>());

        return this.repository.updateItem(userProfile);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public String computeAuthTokenHash(String authToken) {
        return DigestUtils.sha256Hex(authToken);
    }
}
