package com.ibm.au.bgx.core.chain.adapter.flow;

import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.chain.FlowAction;
import com.ibm.au.bgx.model.shared.Flow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class FlowActionDataAdapter implements ChainDataAdapter<Flow.FlowActionRequest, FlowAction> {

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    FlowActionRequestTypeDataAdapter flowActionRequestTypeDataAdapter;

    @Override
    public Flow.FlowActionRequest toOnChainModel(FlowAction input) {
        Flow.FlowActionRequest.Builder builder = Flow.FlowActionRequest.newBuilder()
                .setFlowId(input.getFlowId());

        if (input.getActionType() != null) {
            builder.setRequestType(flowActionRequestTypeDataAdapter.toOnChainModel(input.getActionType()));
        }

        if (input.getActionId() != null) {
            builder.setActionId(input.getActionId());
        }

        if (input.getMessage() != null) {
            builder.setMessage(input.getMessage());
        }

        if (input.getBankReference() != null) {
            builder.setBankReference(input.getBankReference());
        }

        if (input.getId() != null) {
            builder.setId(input.getId());
        }

        if (input.getNewGxId() != null) {
            builder.setNewGxId(input.getNewGxId());
        }

        return builder.build();
    }

    @Override
    public FlowAction toOffchainModel(Flow.FlowActionRequest input) {
        FlowAction output = new FlowAction();

        output.setId(input.getId());
        output.setFlowId(input.getFlowId());
        output.setActionId(input.getActionId());
        output.setActionType(flowActionRequestTypeDataAdapter.toOffchainModel(input.getRequestType()));
        output.setMessage(input.getMessage());
        output.setBankReference(input.getBankReference());
        output.setNewGxId(input.getNewGxId());
        output.setCreatedBy(input.getCreatedBy());
        output.setCreatedAt(timestampDataAdapter.toOffchainModel(input.getCreatedAt()));
        output.setUpdatedBy(input.getUpdatedBy());
        output.setUpdatedAt(timestampDataAdapter.toOffchainModel(input.getUpdatedAt()));

        return output;
    }
}
