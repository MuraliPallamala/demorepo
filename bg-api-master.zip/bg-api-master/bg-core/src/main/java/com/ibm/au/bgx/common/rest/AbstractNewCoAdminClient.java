package com.ibm.au.bgx.common.rest;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import org.springframework.beans.factory.annotation.Value;

/**
 * Abstract class for various client implementation that communicate with NewCo Admin API
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public abstract class AbstractNewCoAdminClient extends AbstractRemoteClient {

    @Value("${api.newco.admin.url:http://localhost:9082}")
    public String newcoAdminUrl;

    public String getBaseUrl() {
        return this.newcoAdminUrl;
    }
}
