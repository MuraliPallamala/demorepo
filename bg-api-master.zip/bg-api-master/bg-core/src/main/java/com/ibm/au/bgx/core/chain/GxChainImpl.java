package com.ibm.au.bgx.core.chain;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.chain.GxChain;
import com.ibm.au.bgx.model.exception.ChainInitializationException;
import com.ibm.au.bgx.model.exception.GuaranteeChainException;
import com.ibm.au.bgx.model.exception.GuaranteeException;
import com.ibm.au.bgx.model.guarantee.GXAPI;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchResponse;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchResponse;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.text.ParseException;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

/**
 * This implements methods to persist and retrieve records from chain
 *
 * @author Dain LIffman <dainliff@au1.ibm.com>
 */
public class GxChainImpl extends AbstractPrincipalChain<GXAPI> implements GxChain {

    private static final Logger LOGGER = LoggerFactory.getLogger(GxChainImpl.class);

    @Autowired
    BaseGxChain baseGxChain;

    @Value("${bgx.chain.invoke.attempts:3}")
	protected int numberOfAttempts;
    
    @Value("${bgx.chain.invoke.delayInMillis:1000}")
	protected int sleepTimeInMillis;

    public GxChainImpl(BgxPrincipal principal, String channelUserName) {
        super(principal, channelUserName);

    }


    protected GXAPI getChain(String channelName) throws ChainInitializationException {
        GXAPI api;

        if (channelUserName == null || channelUserName.isEmpty()) {
            throw new IllegalArgumentException("Default channel user is empty.");
        }

        try {
            LOGGER.debug(BgxLogMarkers.DEV, "Connecting to channel {} with user {}.", channelName,
                channelUserName);
            api = selector.getGuaranteeApi(channelUserName, channelName);
        } catch (Exception e) {
            throw new ChainInitializationException("Could not initialize GX chain", e);
        }

        return api;
    }

    @Override
    public GxRequest startIssue(String channelName, GxRequest gxRequest) throws GuaranteeException {
        try {
            return baseGxChain.startIssue(getChain(channelName), gxRequest);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxRequest startAmend(String channelName, GxRequest gxRequest) throws GuaranteeException {
        try {
            return baseGxChain.startAmend(getChain(channelName), gxRequest);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxRequest startCancel(String channelName, GxRequest gxRequest)
        throws GuaranteeException {
        try {
            return baseGxChain.startCancel(getChain(channelName), gxRequest);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxRequest startDemand(String channelName, GxRequest gxRequest)
        throws GuaranteeException {
        try {
            return baseGxChain.startDemand(getChain(channelName), gxRequest);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxRequest startPayWalk(String channelName, GxRequest gxRequest)
        throws GuaranteeException {
        try {
            return baseGxChain.startPayWalk(getChain(channelName), gxRequest);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxRequest startTransfer(String channelName, GxRequest gxRequest)
        throws GuaranteeException {
        try {
            return baseGxChain.startTransfer(getChain(channelName), gxRequest);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxRequest expire(String channelName, GxRequest gxRequest) throws GuaranteeException {
        try {
            return baseGxChain.expire(getChain(channelName), gxRequest);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxAction actionApprove(String channelName, GxAction action) throws GuaranteeException {
        try {
            return baseGxChain.actionApprove(getChain(channelName), action);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxAction actionCancel(String channelName, GxAction action) throws GuaranteeException {
        try {
            return baseGxChain.actionCancel(getChain(channelName), action);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxAction actionRevoke(String channelName, GxAction action) throws GuaranteeException {
        try {
            return baseGxChain.actionRevoke(getChain(channelName), action);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxAction actionReject(String channelName, GxAction action) throws GuaranteeException {
        try {
            return baseGxChain.actionReject(getChain(channelName), action);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxAction actionDefer(String channelName, GxAction action) throws GuaranteeException {
        try {
            return baseGxChain.actionDefer(getChain(channelName), action);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxAction actionRecallIssue(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallIssue(getChain(channelName), flowId, gxRequest);
        } catch (ChainInitializationException e) {
            throw new GuaranteeException(e);
        }

    }

    @Override
    public GxAction actionRecallAmend(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallAmend(getChain(channelName), flowId, gxRequest);
        } catch (ChainInitializationException e) {
            throw new GuaranteeException(e);
        }

    }

    @Override
    public GxAction actionRecallCancel(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallCancel(getChain(channelName), flowId, gxRequest);
        } catch (ChainInitializationException e) {
            throw new GuaranteeException(e);
        }

    }

    @Override
    public GxAction actionRecallDemand(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallDemand(getChain(channelName), flowId, gxRequest);
        } catch (ChainInitializationException e) {
            throw new GuaranteeException(e);
        }

    }

    @Override
    public GxAction actionRecallTransfer(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallTransfer(getChain(channelName), flowId, gxRequest);
        } catch (ChainInitializationException e) {
            throw new GuaranteeException(e);
        }
    }

	@Override
	public GxSearchResponse search(String channelName, GxSearchRequest searchRequest) throws GuaranteeException {
		// Workaround for the "Channel shutdownNow invoked" error that is thrown by
		// the Channel class of hyperledger fabric SDK (io.grpc) when performing the
		// first guarantee search after the API is restarted. It seems to be related to
		// https://jira.hyperledger.org/browse/FAB-10604?attachmentOrder=desc
		while (this.numberOfAttempts > 0) {

			try {
				LOGGER.debug(BgxLogMarkers.DEV,
						"Retrieving Gx from channel '{}' using channel user '{}' and principal's org '{}'", channelName,
						channelUserName, getPrincipal().getPrimaryOrgId());

				return baseGxChain.search(getChain(channelName), searchRequest);
			} catch (ChainInitializationException | ParseException e) {
				throw new GuaranteeException(e);
			} catch (GuaranteeChainException e) {
				LOGGER.warn("GuaranteeChainException has been raised");
				
				if (e != null && e.getFabricMessage() != null
						&& e.getFabricMessage().getDescription().toLowerCase().contains("shutdown")) {
					LOGGER.warn("Failed to perform guarantee search on attempt number {}",
							numberOfAttempts - numberOfAttempts, e);

					try {
						Thread.sleep(this.sleepTimeInMillis);
					} catch (InterruptedException ie) {
						Thread.currentThread().interrupt();
					}
					numberOfAttempts--;

					if (numberOfAttempts == 0) {
						throw e;
					}
				} else {
					throw e;
				}

			}
		}
		
		return null;
	}

    @Override
    public Gx get(String channelName, String guaranteeId) throws GuaranteeException {
        try {
            return baseGxChain.get(getChain(channelName), guaranteeId);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxFlowsSearchResponse searchFlows(String channelName,
        GxFlowsSearchRequest flowsSearchRequest) throws GuaranteeException {
        try {
            LOGGER.debug(BgxLogMarkers.DEV,
                "Retrieving flows from channel '{}' using channel user '{}' and principal's org '{}'",
                channelName, channelUserName, getPrincipal().getPrimaryOrgId());

            if (baseGxChain == null) {
                throw new IllegalStateException("BaseGxChain has not been initialized");
            }

            return baseGxChain.searchFlows(getChain(channelName), flowsSearchRequest);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxRequest getFlow(String channelName, String flowId) throws GuaranteeException {
        try {
            return baseGxChain.getFlow(getChain(channelName), flowId);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public List<GxAction> getFlowActions(String channelName, String flowId)
        throws GuaranteeException {
        try {
            return baseGxChain.getFlowActions(getChain(channelName), flowId);
        } catch (ChainInitializationException | ParseException e) {
            throw new GuaranteeException(e);
        }
    }


}
