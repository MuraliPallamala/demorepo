package com.ibm.au.bgx.common;

import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.KeyGenerator;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.stereotype.Component;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class KeyGeneratorImpl implements KeyGenerator {

    @Override
    public String newKey(int len) {
        return RandomStringUtils.random(len, true, true);
    }

    @Override
    public String newNumeric(int len) {
        return RandomStringUtils.random(len, false, true);
    }

    @Override
    public String getCompositeKey(String orgKey, String userKey) {

        if (orgKey.length() != BgxConstants.ORG_KEY_LEN) {
            throw new IllegalArgumentException(String.format("Org key must of of length: %d", BgxConstants.ORG_KEY_LEN));
        }

        if (userKey.length() != BgxConstants.USER_KEY_LEN) {
            throw new IllegalArgumentException(String.format("User key must of of length: %d", BgxConstants.USER_KEY_LEN));
        }

        return String.format("%s%s", orgKey, userKey);
    }

    @Override
    public String getOrgKey(String compositeKey) {

        if (!this.isValidCompositeKey(compositeKey)) {
            throw new IllegalArgumentException(String.format("Composite key is not valid"));
        }

        return compositeKey.substring(0, BgxConstants.ORG_KEY_LEN);
    }

    @Override
    public String getUserKey(String compositeKey) {
        if (!this.isValidCompositeKey(compositeKey)) {
            throw new IllegalArgumentException(String.format("Composite key is not valid"));
        }

        return compositeKey.substring(BgxConstants.ORG_KEY_LEN, BgxConstants.ORG_KEY_LEN + BgxConstants.USER_KEY_LEN);
    }

    @Override
    public boolean isValidCompositeKey(String compositeKey) {
        int requiredLength = BgxConstants.ORG_KEY_LEN + BgxConstants.USER_KEY_LEN;
        return (compositeKey.length() == requiredLength);
    }
}
