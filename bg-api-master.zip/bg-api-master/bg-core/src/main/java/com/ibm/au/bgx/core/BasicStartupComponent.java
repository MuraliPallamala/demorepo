package com.ibm.au.bgx.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.rest.IdentityConfiguration;
import com.ibm.au.bgx.core.chain.channel.gx.GxChannelProvider;
import com.ibm.au.bgx.core.migration.purposeformat.PurposeFormatMigrator;
import com.ibm.au.bgx.model.migration.DataMigrator;
import com.ibm.au.bgx.model.purpose.PurposeFormatManager;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import com.ibm.au.bgx.model.chain.ChannelUser;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.api.NewCoAdminBootstrapClient;
import com.ibm.au.bgx.model.api.SystemStatusResource;
import com.ibm.au.bgx.model.chain.ChannelSelector;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.chain.profile.UserProfileManager;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.Credentials;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.UserProfile.Status;
import com.ibm.au.bgx.model.pojo.api.request.BootstrapRequest;
import com.ibm.au.bgx.model.pojo.api.response.BootstrapResponse;
import com.ibm.au.bgx.model.pojo.crypto.CryptoKeyInfo;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.notification.WebNotification.MessageType;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.repository.EncryptionKeyRepository;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

/**
 * This is a pure development component, that sends an echo message with a new user on startup.
 *
 * @author Peter Ilfrich
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public class BasicStartupComponent {

    private static final Logger LOGGER = LoggerFactory.getLogger(BasicStartupComponent.class);

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    private static final String SYSTEM_STATUS_COMPONENT_NAME = "bootstrap";

    @Autowired
    protected ChannelSelector selector;

    @Autowired
    protected QueueClient queue;

    @Autowired
    protected NewCoAdminBootstrapClient bootstrapClient;

    @Autowired
    protected OrganizationManager organizationManager;

    @Autowired
    protected UserProfileManager userProfileManager;

    @Autowired
    protected EncryptionKeyRepository encryptionKeyRepository;

    @Autowired
    protected KeyGenerator keyGenerator;

    @Autowired
    protected SystemStatusResource systemStatus;

    @Autowired
    protected IdentityConfiguration identityConfiguration;

    @Autowired
    protected PurposeFormatManager purposeFormatManager;

    @Autowired
    protected PurposeFormatMigrator migrationPurposeFormat;

    @Value("${bgx.identity:PROPERTY_NOT_SET}")
    protected String bgxIdentity;

    @Value("${bgx.internalUrl:PROPERTY_NOT_SET}")
    private String apiUrl;

    @Value("${fabric.config.api.identity:PROPERTY_NOT_SET}")
    protected String configIdentity;

    // @Value("${fabric.guarantee.channel.list:PROPERTY_NOT_SET}")
    // protected String channelList;
    
    /**
     * An instance of {@link GxChannelProvider} which provides information
     * about the list of channels for bank guarantee management that are
     * configured with this vertical.
     */
    @Autowired
    protected GxChannelProvider channelProvider;

    @Value("${fabric.organization.channel:PROPERTY_NOT_SET}")
    protected String profileChannel;
    /**
     * This is used to determine a suffix to the resource/profile/<identity>.json (in local this is
     * "-dev", which only makes sure Bob and Carole exist.
     */
    @Value("${bootstrap.profileSuffix:-dev}")
    protected String bootstrapProfileSuffix;

    /**
     * Redirect uri for user This is one of the uri specified in the redirectUriList
     */
    @Value("${bootstrap.userAuth.redirectUri:https://bank-guarantee.res.ibm.com/portal/cb/*}")
    private String userAuthRedirectUri;

    @Value("${bootstrap.profile.path:}")
    private String bootstrapProfilePath;
    
    /**
     * List of redirect uri that need to be registered
     */
    @Value("${bootstrap.userAuth.redirectUriList:https://bank-guarantee.res.ibm.com/portal/cb/*,https://bg-pilot-qa.sl.cloud9.ibm.com:444/cb/*,http://locahost:9080/cb/*}")
    private String userAuthRedirectUriList;

    @Value("${bootstrap.tempPassword:passWord1!}")
    private String tempPassword;

    protected void checkAndRunMigration() throws Exception {
        // populate list of data migration tools
        List<DataMigrator> migrators = new ArrayList<>();
        migrators.add(migrationPurposeFormat);

        LOGGER.debug(BgxLogMarkers.DEV, "Checking data migration for {} migrators", migrators.size());
        // run migration
        for (DataMigrator migrator : migrators) {
            if (migrator.check()) {
                migrator.run();
                migrator.cleanup();
            }
        }
    }

    /**
     * Check blockchain channel connections
     */
    protected void checkGuaranteeChannels() throws Exception {


        if (bgxIdentity == null || bgxIdentity.isEmpty()) {
            throw new IllegalArgumentException("API identity is missing");
        }

        if (configIdentity == null || configIdentity.isEmpty()) {
            throw new IllegalArgumentException("Fabric config identity is missing");
        }

        if (this.channelProvider == null ){ 
            throw new IllegalArgumentException("Guarantee channel list is missing");
        }
        
        String[] channelNames = this.channelProvider.getChannelNames();
        if (channelNames.length <= 0) {
            throw new IllegalArgumentException("No guarantee channel is found");
        }

        // Register and enroll the channel user
        ChannelUser user = selector.getEnrolledUser(identityConfiguration.getFabricUser(), identityConfiguration.getIdentity(), true);
        if (user == null) {
            throw new IllegalStateException(
                String.format("Could not enrol fabric user for %s", identityConfiguration.getFabricUser()));
        }

        // Check channel integration
        LOGGER.debug(BgxLogMarkers.DEV, " > ***Checking channel integration***");
        for (String testChannel : channelNames) {
            selector.getGuaranteeApi(identityConfiguration.getFabricUser(), testChannel);
            // we used to send an echo message here, but Dain removed it ;-(
            // discussion revealed alternative during startup to do a cache sync, which we need to implement anyway
        }
        LOGGER.debug(BgxLogMarkers.DEV, " > ***Channel integration check was successful***");
    }

    /**
     * Check connections to the work queues
     */
    protected void checkQueues() throws Exception {
        LOGGER.debug(BgxLogMarkers.DEV, " > ***Checking queue integration***");

        // Check queue integration
        WebNotification notification = new WebNotification();
        notification.setReceiverId(MessageType.BOOTSTRAP.toString());
        notification.setMessageType(MessageType.BOOTSTRAP);
        queue.addWebNotification(notification);

        LOGGER.debug(BgxLogMarkers.DEV, " > ***Queue integration check was successful***");
    }


    protected BootstrapRequest prepareBootstrapRequest() throws Exception {
        // enroll the user and then extract the fabric user's certificate
        LOGGER.debug(BgxLogMarkers.DEV, "Getting channel user {} for org {}", identityConfiguration.getFabricUser(), identityConfiguration.getIdentity());
        ChannelUser user = selector.getEnrolledUser(identityConfiguration.getFabricUser(), identityConfiguration.getIdentity(), true);

        if (user == null) {
            throw new IllegalStateException(
                String.format("Could not enrol fabric user for %s", identityConfiguration.getIdentity()));
        }

        String cert = user.getEnrollment().getCert();
        LOGGER.debug(BgxLogMarkers.DEV,
            String.format("Enrolled user %s and found certificate", user.getName()));
        LOGGER.debug(String.format("-> Certificate %s", cert));

        // prepare the bootstrap request
        BootstrapRequest request = new BootstrapRequest();
        
        InputStream orgProfile = null;
        if (bootstrapProfilePath != null && !bootstrapProfilePath.isEmpty()) {
            File profileFile = new File(bootstrapProfilePath);
            if (profileFile.exists()) {
                LOGGER.debug(BgxLogMarkers.DEV,
                                String.format("Reading profile file: %s", bootstrapProfilePath));
                orgProfile = new FileInputStream(profileFile);
            }
        }
        if (orgProfile == null) {
            LOGGER.debug(BgxLogMarkers.DEV, String.format("Reading profile file: %s",
                            String.format("/profiles/%s%s.json", bgxIdentity, bootstrapProfileSuffix)));
            orgProfile = BasicStartupComponent.class.getResourceAsStream(
                            String.format("/profiles/%s%s.json", bgxIdentity, bootstrapProfileSuffix));
        }
        
        OrgProfile profile = MAPPER.readValue(orgProfile, OrgProfile.class);
        request.setProfile(profile);

        List<String> redirectUriList = Arrays.asList(userAuthRedirectUriList.split(","));
        if (redirectUriList.size() == 0) {
            throw new IllegalArgumentException("User redirect URI list cannot be empty");
        }

        // set the identity and certificate
        Map<String, Object> config = new HashMap<>();
        config.put(BgxConstants.BOOTSTRAP_ORG_ID, bgxIdentity);
        config.put(BgxConstants.BOOTSTRAP_ORG_API_URL, apiUrl);
        config.put(BgxConstants.BOOTSTRAP_ORG_CERT, cert); // for chain
        config.put(BgxConstants.BOOTSTRAP_USER_REDIRECT_URI_LIST, redirectUriList);
        config.put(BgxConstants.BOOTSTRAP_USER_TEMP_SECRET, tempPassword);

        LOGGER.debug(BgxLogMarkers.DEV, "bgx.internalUrl for {}: {} ", bgxIdentity, apiUrl);

        // generate and set encryption key
        CryptoKeyInfo keyInfo = encryptionKeyRepository.getByOwnerId(bgxIdentity);
        if (keyInfo == null || keyInfo.getKeys() == null) {
            Map<String, String> encryptionKeys = BgxEncryptionUtil.generateKeyPair();
            keyInfo = new CryptoKeyInfo();
            keyInfo.setId(identityConfiguration.getFabricUser()); // we force each org to have one entry
            keyInfo.setKeys(encryptionKeys);
            keyInfo.setOwnerId(bgxIdentity);
            encryptionKeyRepository.addItem(keyInfo);
        }

        if (!keyInfo.getKeys().containsKey(BgxConstants.CRYPTO_PUBLIC_KEY) || !keyInfo.getKeys()
            .containsKey(BgxConstants.CRYPTO_PRIVATE_KEY)) {
            throw new IllegalStateException("Key info does not contain both keys");
        }

        // include the public key to be used for api-to-api payload encryption when required
        config.put(BgxConstants.CRYPTO_PUBLIC_KEY,
            keyInfo.getKeys().get(BgxConstants.CRYPTO_PUBLIC_KEY));

        // set the config
        request.setConfig(config);

        return request;
    }

    protected boolean requireBootstrap(String orgId) {

        boolean requireBootstrap = false;

        // check if profile can be fetched from profile channel or not.
        Organization organization = null;

        try {
            organization = this.organizationManager.getById(orgId);
        } catch (ProfileChainException | ProfileNotFoundException e) {
            LOGGER.debug(BgxLogMarkers.DEV, e.getMessage());
            // nothing to do
        }

        // determine if bootstrapping is required or not
        if (organization == null || 
            !organization.getMeta().containsKey(BgxConstants.SERVICE_READY) || 
            organization.getMeta().get(BgxConstants.SERVICE_READY) == Boolean.FALSE) {

            requireBootstrap = true;
        }

        if (organization != null) {
            LOGGER.debug(BgxLogMarkers.DEV, String.format("Service ready: %s", organization.getMeta().get(BgxConstants.SERVICE_READY)));
        }

        LOGGER.debug(BgxLogMarkers.DEV, String.format("Require bootstrap: %s", requireBootstrap));

        return requireBootstrap;
    }

    /**
     * Bootstrap this organization
     *
     * It bootstraps the organization based on `bgxIdentity` and `profile.json` file stored in
     * resources folder. Also note that this components assumes a fabric user is enrolled with id
     * `bgxIdentity`, which is same as the organization ID
     *
     * This method is invoked by the api component of the `issuers` and `newco` during startup.
     */
    protected void bootstrap() throws Exception {

        LOGGER.debug(BgxLogMarkers.DEV, " > ***Checking organization bootstrapping***");

        boolean requireBootstrap = this.requireBootstrap(this.bgxIdentity);

        if (requireBootstrap) {

            LOGGER.debug(BgxLogMarkers.DEV, String.format("Organization %s is not found. Bootstrapping %s", bgxIdentity, bgxIdentity));

            BootstrapRequest request = this.prepareBootstrapRequest();

            // bootstrap the organization
            BootstrapResponse response = this.bootstrapClient.bootstrap(request);
            LOGGER.debug(BgxLogMarkers.DEV, String.format("Bootstrapping request for %s was successful", bgxIdentity));

            // check that now we can fetch the organization
            // note fetch from chain also creates a record in offchain-cache
            LOGGER.debug(BgxLogMarkers.DEV, String.format("Trying to fetch organization profile from chain for %s", bgxIdentity));

            Organization organization = this.organizationManager.getById(bgxIdentity);
            if (organization == null) {
                throw new ProfileNotFoundException(String.format("Profile %s was not found even after bootstrapping", bgxIdentity));
            }

            LOGGER.debug(BgxLogMarkers.DEV, String.format("Found profile in chain after bootstrapping for %s", bgxIdentity));

            // overwrite profile and contacts with the bootstrap response
            organization.setProfile(response.getProfile());

            // Also update the auth config
            organization.getSettings().setKey(response.getProfile().getId());
            organization.getSettings().setUserAuth(response.getUserAuth());
            organization.getSettings().setApiAuth(response.getApiAuth());

            // update the newcoAdmin record locally for callback authentication
            this.organizationManager.updateCache(response.getNewcoAdminInfo());

            this.postBootstrap(organization);

            // Flag the service to be ready
            organization.getMeta().put(BgxConstants.SERVICE_READY, true);

            this.organizationManager.updateCache(organization);

        } else {
        	
            LOGGER.debug(BgxLogMarkers.DEV, String.format("Found profile in chain for %s", bgxIdentity));
        }

        LOGGER.debug(BgxLogMarkers.DEV, String.format(" > ***Bootstrapping check for %s was successful***", bgxIdentity));
    }

    public void registerComponent() {
        this.systemStatus.registerComponent(SYSTEM_STATUS_COMPONENT_NAME);
    }

    public void setReady() {
        this.systemStatus.setComponentReady(SYSTEM_STATUS_COMPONENT_NAME);
    }

    protected Organization postBootstrap(Organization organization)
        throws ProfileNotFoundException, ProfileChainException {

        // set the redirect URI base
        organization.getSettings().getUserAuth().setRedirectUri(userAuthRedirectUri);

        // set login key
        if (organization.getSettings().getKey() == null || organization.getSettings().getKey()
            .isEmpty()) {
            organization.getSettings().setKey(keyGenerator.newKey(BgxConstants.ORG_KEY_LEN));
        }

        organization = organizationManager.setDefaultRoles(organization);

        // generate keys for the users if it is not set already
        List<ContactInfo> contacts = new ArrayList<>();
        for (ContactInfo contact : organization.getProfile().getContacts()) {
            if (contact.getCredentials() == null) {
                contact.setCredentials(new Credentials());
            }

            if (contact.getCredentials().getKey() == null || contact.getCredentials().getKey()
                .isEmpty()) {
                contact.getCredentials().setKey(keyGenerator.newKey(BgxConstants.USER_KEY_LEN));
            }

            contacts.add(contact);
        }

        LOGGER.debug(String.format("Creating users for org %s (%s, %s)",
            organization.getProfile().getEntityName(),
            organization.getId(),
            organization.getSettings().getKey()
        ));

        userProfileManager.createOrganizationUsers(
            organization.getId(),
            contacts,
            organization.getSettings().getRoles(),
            Status.ACTIVE);

        return organization;
    }

    protected ChannelUser registerDefaultChannelUser() throws Exception {

        // Register and enroll the channel user
        ChannelUser user = selector.getEnrolledUser(identityConfiguration.getFabricUser(), identityConfiguration.getIdentity(), true);
        if (user == null) {
            throw new IllegalStateException(
                String.format("Could not enrol fabric user for %s", identityConfiguration.getFabricUser()));
        }

        return user;
    }
}
