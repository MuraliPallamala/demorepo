package com.ibm.au.bgx.core.approvalmodel;

import com.ibm.au.bgx.model.approvalmodel.ApprovalModel;
import com.ibm.au.bgx.model.chain.profile.ApprovalModelCatalog;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;

public class FourEyeApprovalModel extends AbstractApprovalModel implements ApprovalModel {

    @Autowired
    ApprovalModelCatalog catalog;

    public FourEyeApprovalModel(BgxPrincipal principal) {
        super(principal);
    }

    @Override
    public ApprovalModelInfo getApprovalModelInfo() throws IOException {
        return this.catalog.getApprovalModel(ApprovalModelInfo.Name.FOUR_EYE);
    }
}
