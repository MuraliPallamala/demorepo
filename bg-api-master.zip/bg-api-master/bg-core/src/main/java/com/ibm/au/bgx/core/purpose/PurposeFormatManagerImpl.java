package com.ibm.au.bgx.core.purpose;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.util.TimeZoneUtil;
import com.ibm.au.bgx.model.api.exceptions.ApiException;
import com.ibm.au.bgx.model.api.exceptions.ApiPreconditionFailsException;
import com.ibm.au.bgx.model.api.exceptions.ApiRecordNotFoundException;
import com.ibm.au.bgx.model.chain.PurposeFormatChain;
import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.purpose.MaxValueConstraint;
import com.ibm.au.bgx.model.pojo.purpose.MinValueConstraint;
import com.ibm.au.bgx.model.pojo.purpose.NewPurposeField;
import com.ibm.au.bgx.model.pojo.purpose.NewPurposeFormat;
import com.ibm.au.bgx.model.pojo.purpose.OneOfConstraint;
import com.ibm.au.bgx.model.pojo.purpose.PatternConstraint;
import com.ibm.au.bgx.model.pojo.purpose.PurposeField;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFieldConstraint;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;
import com.ibm.au.bgx.model.purpose.PurposeFormatManager;
import com.ibm.au.bgx.model.util.JacksonUtil;

import org.apache.commons.text.StringSubstitutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Manager implementation for the purpose format. The manager provides methods to create, update and
 * read purpose formats from the blockchain and provides a purpose format cache that offers quicker
 * access.
 *
 * @author Peter Ilfrich
 */
@Component
public class PurposeFormatManagerImpl implements PurposeFormatManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(PurposeFormatManagerImpl.class);

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    protected PurposeFormatChain purposeFormatChain;
    
    @Value("${purpose.format.default:<not-defined>}")
    protected String defaultValue;

    protected Map<String, PurposeFormat> cache = new HashMap<>();


    @Override
    public void init() throws ProfileChainException {
        List<PurposeFormat> formats = purposeFormatChain.getAll();
        for (PurposeFormat format : formats) {
            try {
                LOGGER.debug("Found purpose format during getAll: {}", MAPPER.writeValueAsString(format));
            } catch (JsonProcessingException jpe) {
                LOGGER.error("Could not serialise json format.", jpe);
            }
            cache.put(format.getId(), format);
        }
    }

    @Override
    public List<DataValidationException> validate(NewPurposeFormat newPurposeFormat) {
        List<DataValidationException> exceptions = new ArrayList<>();
        exceptions.addAll(this.validatePurposeFormatReferences(newPurposeFormat));

        if (newPurposeFormat.getId() != null) {
            if (cache.containsKey(newPurposeFormat.getId())) {
                exceptions.add(new DataValidationException("Purpose format ID already exists."));
            }
        }

        return exceptions;
    }

    @Override
    public PurposeFormat create(NewPurposeFormat newPurposeFormat) throws ApiException {
        PurposeFormat format = this.resolveReferences(newPurposeFormat);
        try {
            return purposeFormatChain.create(format);
        } catch (ProfileChainException e) {
            throw new ApiPreconditionFailsException(null, "Could not create purpose format", e);
        }
    }

    @Override
    public PurposeFormat updateActiveStatus(String formatId, boolean newActiveStatus) throws ApiException {
        PurposeFormat format = this.get(formatId);
        if (format == null) {
            throw new ApiRecordNotFoundException(null, String.format("Could not find format with id '%s'", formatId), null);
        }

        try {
            purposeFormatChain.updateActiveStatus(formatId, newActiveStatus);
        } catch (ProfileChainException pe) {
            throw new ApiException(null, "Could not update active status", pe);
        }

        // reload updated record from chain and return it
        this.refreshCache(formatId);
        return this.get(formatId);
    }

    @Override
    public PurposeFormat get(String formatId) {
        if (cache.containsKey(formatId)) {
            return cache.get(formatId);
        }
        PurposeFormat f = null;
        try {
            f = purposeFormatChain.getById(formatId);
            cache.put(f.getId(), f);
            LOGGER.debug("Loaded purpose format from chain: {}", MAPPER.writeValueAsString(f));
            return f;
        } catch (ProfileChainException pce) {
            LOGGER.error(String.format("Could not retrieve purpose format with id '%s'", formatId), pce);
        } catch (JsonProcessingException jpe) {
            LOGGER.error("Could not serialise purpose format, returning it anyway", jpe);
            return f;
        }

        return null;
    }

    @Override
    public List<PurposeFormat> getAll() {
        if (this.cache.values().isEmpty()) {
            try {
                this.init();
            } catch (ProfileChainException pe) {
                LOGGER.error("Could not load purpose formats from the chain.", pe);
            }
        }
        return new ArrayList<>(this.cache.values());
    }

    @Override
    public List<PurposeFormat> getAll(boolean activeFlag) {
    	
        return this.getAll()
                   .stream()
                   .filter(pf -> pf.getActive().equals(activeFlag))
                   .collect(Collectors.toList());
    }

    @Override
    public void refreshCache(String formatId) {
        if (this.cache.containsKey(formatId)) {
            this.cache.remove(formatId);
        }

        this.get(formatId);
    }

    @Override
    public void validatePurposeFieldConstraint(Object constraintRaw, PurposeField field, Map<String, Object> purpose) throws DataValidationException {

        if (constraintRaw == null || purpose == null || field == null) {
            throw new IllegalArgumentException("All inputs to purpose field constraint validation are required.");
        }

        PurposeFieldConstraint constraint = this.parseConstraint(constraintRaw);

        if (constraint instanceof MinValueConstraint) {
            this.validateMinValueConstraint(purpose.get(field.getName()), (MinValueConstraint) constraint);
        } else if (constraint instanceof MaxValueConstraint) {
            this.validateMaxValueConstraint(purpose.get(field.getName()), (MaxValueConstraint) constraint);
        } else if (constraint instanceof PatternConstraint) {
            this.validatePatternConstraint(purpose.get(field.getName()), (PatternConstraint) constraint);
        } else if (constraint instanceof OneOfConstraint) {
            this.validateOneOfConstraint(purpose.get(field.getName()), (OneOfConstraint) constraint);
        } else {
            // should not happen
            throw new IllegalArgumentException("Unknown constraint type detected.");
        }

    }

    @Override
    public String stringifyPurpose(PurposeFormat purposeFormat, Map<String, Object> purpose) {
        Map<String, String> values = new HashMap<>();
        
        this.populateFlatPurposeMap(values, purposeFormat.getFields(), purpose, null);
               
        StringSubstitutor substitutor = new StringSubstitutor(values);
        return substitutor.replace(purposeFormat.getStringTemplate());
    }

    /**
     * Recursively populates the provided map with string versions of the leave nodes of the purpose
     * provided.
     *
     * @param map     - the map to populate
     * @param fields  - the list of fields currently iterating over.
     * @param purpose - the purpose or part of a purpose to extract the data from, which gets
     *                converted to strings.
     * @param prefix  - the current key prefix for the map entries
     */
    protected void populateFlatPurposeMap(Map<String, String> map, List<PurposeField> fields, Map<String, Object> purpose, String prefix) {
        
    	for (PurposeField field : fields) {
            if (field.getType().equals(PurposeField.Type.OBJECT)) {
                // recursive call
                this.populateFlatPurposeMap(map, field.getSubFields(), (Map<String, Object>) purpose.get(field.getName()), field.getName() + ".");
            } else if (purpose != null && purpose.containsKey(field.getName())) {
                // leave node
                String key = String.format("%s%s", prefix != null ? prefix : "", field.getName());
                Object val = purpose.get(field.getName());
                if (val == null) {
                	map.put(key, this.defaultValue);
                } else if (val instanceof Double) {
                    map.put(key, Double.toString((Double) val));
                } else if (val instanceof Integer) {
                    map.put(key, Integer.toString((Integer) val));
                } else if (val instanceof String) {
                    map.put(key, (String) val);
                } else if (val instanceof Instant) {
                    map.put(key, TimeZoneUtil.formatDateDefault((Instant) val));
                } else if (val instanceof Boolean) {
                    map.put(key, ((Boolean) val) == true ? "Yes" : "No");
                }
            } else {
            	String key = String.format("%s%s", prefix != null ? prefix : "", field.getName());
            	map.put(key, this.defaultValue);
            }
        }
    }

    /**
     * Parses the raw constraint into a map to detect the constraint type and then converts it into
     * the corresponding {@link PurposeFieldConstraint} sub type.
     *
     * @param constraintRaw - the raw constraint, which has to be a {@link LinkedHashMap}
     * @return the parsed sub-type of {@link PurposeFieldConstraint}
     * @throws IllegalArgumentException in case of any parse errors or invalid data provided.
     */
    protected PurposeFieldConstraint parseConstraint(Object constraintRaw) throws DataValidationException {
    	
    	if (constraintRaw == null) {
    		
    		throw new IllegalArgumentException("Constraint cannot be null.");
    	}
    	
    	PurposeFieldConstraint constraint = null;
    	
    	
        if (constraintRaw instanceof LinkedHashMap) {
        	
            @SuppressWarnings("unchecked")
			Map<String, Object> constraintMap = (LinkedHashMap<String, Object>) constraintRaw;
            
            if (!constraintMap.containsKey("constraintType") || !(constraintMap.get("constraintType") instanceof String)) {
                throw new DataValidationException("Provided constraint doesn't contain a constraintType");
            }
            try {
	            switch ((String) constraintMap.get("constraintType")) {
	                case "MIN_VALUE": 
	                    constraint = MAPPER.convertValue(constraintMap, MinValueConstraint.class);
	                break;
	                case "MAX_VALUE": 
	                    constraint = MAPPER.convertValue(constraintMap, MaxValueConstraint.class);
	                break;
	                case "PATTERN": 
	                    constraint = MAPPER.convertValue(constraintMap, PatternConstraint.class);
	                break;
	                case "ONE_OF": 
	                    constraint = MAPPER.convertValue(constraintMap, OneOfConstraint.class);
	                break;
	                default: {
	                    throw new DataValidationException(String.format("Invalid constraint type provided: '%s'", constraintMap.get("constraintType")));
	                }
	            }
            } catch(IllegalArgumentException ilex) {
            	
            	throw new DataValidationException(String.format("Invalid constraint content (reason: %s).", ilex.getMessage()), ilex);
            } 
        } else if (constraintRaw instanceof MinValueConstraint) {
        	
            constraint = (MinValueConstraint) constraintRaw;
        
        } else if (constraintRaw instanceof MaxValueConstraint) {
        
        	constraint = (MaxValueConstraint) constraintRaw;
        
        } else if (constraintRaw instanceof PatternConstraint) {
        
        	constraint = (PatternConstraint) constraintRaw;
        
        } else if (constraintRaw instanceof OneOfConstraint) {
        
        	constraint = (OneOfConstraint) constraintRaw;
        
        } else {
        
        	throw new DataValidationException(String.format("Provided constraint is unknown (raw type: %s)",  constraintRaw.getClass().getCanonicalName()));
        }
        
        return constraint;
    }

    /**
     * Validates a min value constraint by first checking the numeric type of the value and the
     * constraint and then evaluating the provided constraint against the provided value.
     *
     * @param value      - the value to check
     * @param constraint - the constraint providing the minimum value
     * @throws IllegalArgumentException in case of a failed validation
     */
    protected void validateMinValueConstraint(Object value, MinValueConstraint constraint) throws DataValidationException {

    	if (value == null) {
    		throw new IllegalArgumentException("Value cannot be null.");
    	}
    	
        boolean valid;

        if (value instanceof Double) {
            if (constraint.getIncludeMin()) {
                valid = (Double) value >= constraint.getMinValue();
            } else {
                valid = (Double) value > constraint.getMinValue();
            }
        } else if (value instanceof Integer) {
            if (constraint.getIncludeMin()) {
                valid = (Integer) value >= constraint.getMinValue();
            } else {
                valid = (Integer) value > constraint.getMinValue();
            }
        } else {
            throw new DataValidationException("The provided value does not match the type of the MinValueConstraint minimum");
        }

        if (valid) {
            return;
        }

        throw new DataValidationException("Provided value does not fulfill the provided MinValueConstraint");
    }

    /**
     * Validates a max value constraint by first checking the numeric type of the value and the
     * constraint and then evaluating the provided constraint against the provided value.
     *
     * @param value      - the value to check
     * @param constraint - the constraint providing the maximum value
     * @throws IllegalArgumentException in case of a failed validation
     */
    protected void validateMaxValueConstraint(Object value, MaxValueConstraint constraint) throws DataValidationException {
        
    	if (value == null) {
    		throw new IllegalArgumentException("Value cannot be null.");
    	}
    	
    	boolean valid;

        if (value instanceof Double) {
            if (constraint.getIncludeMax()) {
                valid = (Double) value <= constraint.getMaxValue();
            } else {
                valid = (Double) value < constraint.getMaxValue();
            }
        } else if (value instanceof Integer) {
            if (constraint.getIncludeMax()) {
                valid = (Integer) value <= constraint.getMaxValue();
            } else {
                valid = (Integer) value < constraint.getMaxValue();
            }
        } else {
            throw new DataValidationException("The provided value does not match the type of the MaxValueConstraint maximum");
        }

        if (valid) {
            return;
        }

        throw new DataValidationException("Provided value does not fulfill the provided MaxValueConstraint");
    }

    /**
     * Validates a pattern constraint running a regexp validation against the provided value.
     *
     * @param value      - the value to match
     * @param constraint - the constraint providing the regexp pattern
     * @throws IllegalArgumentException in case of a failed validation
     */
    protected void validatePatternConstraint(Object value, PatternConstraint constraint) throws DataValidationException {
    	
    	if (value == null) {
    		throw new IllegalArgumentException("Value cannot be null.");
    	}
    	
        if (value instanceof String) {
            String pattern = constraint.getPattern();
            // the following 2 checks allow the user to use `/<regexp>/` rather than just the pure regexp
            if (pattern.startsWith("/")) {
                pattern = pattern.substring(1);
            }
            if (pattern.endsWith("/")) {
                pattern = pattern.substring(0, pattern.length() - 1);
            }

            Pattern p = Pattern.compile(pattern);
            Matcher m = p.matcher((String) value);
            if (m.matches()) {
                return;
            }
            throw new DataValidationException("Provided value does not match the provided pattern.");
        }

        throw new DataValidationException("Provided value is not a String");

    }

    /**
     * Checks whether the provided value matches any of the available values provided by the {@link
     * OneOfConstraint}
     *
     * @param value      - the value to check
     * @param constraint - the constraint containing the list of valid values
     * @throws IllegalArgumentException in case the value is not contained in the list of valid
     *                                  values
     */
    protected void validateOneOfConstraint(Object value, OneOfConstraint constraint) throws DataValidationException {
    	
    	
    	if (value == null) {
    		throw new IllegalArgumentException("Value cannot be null.");
    	}
    	
        if (value instanceof String) {
            if (constraint.getAvailableValues().contains(value)) {
                return;
            }

            throw new DataValidationException("Provided value is not one of the required ones.");
        }
        throw new DataValidationException("Provided value is not a String");
    }

    /**
     * Validates the format of purpose field references on the root-level of a purpose format
     * request. Note that sub-fields currently don't support references. The method will check the
     * format of the reference and attempt to resolve the reference.
     *
     * @param request - the purpose format request to validate
     * @return a list of exceptions thrown during validation. If the list is empty, the validation
     * has passed.
     */
    protected List<DataValidationException> validatePurposeFormatReferences(NewPurposeFormat request) {
    	
    	
    	if (request == null) {
    		throw new IllegalArgumentException("Value cannot be null.");
    	}
    	
    	
        List<DataValidationException> exceptions = new ArrayList<>();
        for (NewPurposeField field : request.getFields()) {
            try {
                if (field.getType().equals(PurposeField.Type.REFERENCE)) {
                    if (field.getFieldReference() == null || !field.getFieldReference().contains(".")) {
                        throw new DataValidationException(String.format("Field reference '%s' is invalid.", field.getFieldReference()));
                    }
                    FieldReference ref = new FieldReference(field.getFieldReference());
                    PurposeField pf = resolveReference(ref);
                    if (pf == null) {
                        throw new DataValidationException(String.format("Could not find field reference '%s'", field.getFieldReference()));
                    }
                }

            } catch (DataValidationException ae) {
                exceptions.add(ae);
            }
        }
        return exceptions;
    }

    /**
     * This will resolve the references contained in a purpose format request. Note that only
     * root-level references are allowed. Sub fields of an OBJECT field cannot have references.
     *
     * @param request - the purpose format request submitted via the newco-admin API.
     * @return the final purpose format that will be ingested into the blockchain with all its
     * references resolved.
     */
    protected PurposeFormat resolveReferences(NewPurposeFormat request) {
        // create base data
        PurposeFormat format = new PurposeFormat();
        format.setId(request.getId());
        format.setName(request.getName());
        format.setVersion(request.getVersion());
        format.setActive(request.getActive());
        format.setDescription(request.getDescription());
        format.setLabel(request.getLabel());
        format.setPdfTemplateId(request.getPdfTemplateId());
        format.setStringTemplate(request.getStringTemplate());

        // process fields
        format.setFields(new ArrayList<>());

        for (NewPurposeField field : request.getFields()) {
            if (field.getType().equals(PurposeField.Type.REFERENCE)) {
                PurposeField target = resolveReference(new FieldReference(field.getFieldReference()));
                format.getFields().add(target);
            } else {
                format.getFields().add(convertField(field));
            }
        }

        return format;
    }

    protected PurposeField convertField(NewPurposeField field) {
        PurposeField target = new PurposeField();
        target.setOptional(field.getOptional());
        target.setConstraints(field.getConstraints());
        target.setType(field.getType());
        target.setName(field.getName());
        target.setAppearance(field.getAppearance());
        target.setSubFields(field.getSubFields());

        return target;
    }

    protected PurposeField resolveReference(FieldReference ref) {
        PurposeFormat format = null;
        for (PurposeFormat pf : getAll()) {
            if (pf.getName().equals(ref.formatName)) {
                format = pf;
            }
        }

        if (format == null) {
            return null;
        }

        PurposeField result = null;
        List<PurposeField> fields = format.getFields();
        for (String path : ref.fieldPath) {
            for (PurposeField candidate : fields) {
                if (candidate.getName().equals(path)) {
                    result = candidate;
                    if (result.getSubFields() != null && !result.getSubFields().isEmpty()) {
                        fields = result.getSubFields();
                    }
                }
            }
        }

        return result;
    }

    /**
     * Simple structure to provide the parsing of a field reference.
     */
    private class FieldReference {
        public String formatName;
        public List<String> fieldPath;

        public FieldReference(String ref) {
            StringTokenizer st = new StringTokenizer(ref, ".");

            formatName = st.nextToken();

            fieldPath = new ArrayList<>();
            while (st.hasMoreTokens()) {
                fieldPath.add(st.nextToken());
            }
        }
    }
}
