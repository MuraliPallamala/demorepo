package com.ibm.au.bgx.common.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.NetworkSyncNotificationClient;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.notification.NetworkSyncNotification;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

/**
 * A remote client implementation to send network sysc notifications
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@Component
public class NetworkSyncNotificationClientImpl
    extends AbstractRemoteClient
    implements NetworkSyncNotificationClient {

    private static Logger LOGGER = LoggerFactory.getLogger(NetworkSyncNotificationClient.class);

    private static ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Override
    public void notify(String baseUrl, String notificationUrl, NetworkSyncNotification notification)
        throws ServiceUnavailableException {

        LOGGER.debug(BgxLogMarkers.DEV,
            "Trying to send network sync notification to {}: {}",
            notification.getTargetId(), notificationUrl);

        try {

            if (!this.isApiReady(baseUrl, 5)) {
                throw new ServiceUnavailableException(
                    String.format("API '%s' is not ready", notificationUrl));
            }

            HttpHeaders headers = null;
            try {
                headers = this.getHeaders();
            } catch (Exception e) {
                throw new IllegalArgumentException("Could not prepare headers", e);
            }

            this.addRequestHash(headers, notification, this.identityConfig.getIdentity());

            HttpEntity<NetworkSyncNotification> request = new HttpEntity<>(notification, headers);

            RestTemplate rest = this.getRestTemplate(notificationUrl);

            LOGGER
                .debug("Sending network sync notification: {}",
                    MAPPER.writeValueAsString(notification));

            LOGGER.debug(BgxLogMarkers.DEV,
                "Sending network sync notification to {}: POST {}",
                notification.getTargetId(), notification.getSyncType(), notificationUrl);

            rest.exchange(notificationUrl, HttpMethod.POST, request, Map.class); // we don't expect any response

        } catch (ServiceUnavailableException | HttpClientErrorException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalArgumentException(String
                .format("Could not send network sync notification to {}", notificationUrl), e);
        }
    }
}
