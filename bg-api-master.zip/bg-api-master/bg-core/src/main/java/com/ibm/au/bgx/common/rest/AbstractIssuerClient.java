package com.ibm.au.bgx.common.rest;

import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import org.springframework.http.HttpHeaders;

/**
 * Abstract client implementation for communication with any issuer API. Any request needs to pass
 * enough information to know which issuer API to call (as there are multiple).
 *
 * This covers requests TO the issuer API.
 *
 * @author Peter Ilfrich
 */
public abstract class AbstractIssuerClient extends AbstractRemoteClient {

    @Override
    public HttpHeaders getHeaders() throws ServiceUnavailableException {

        HttpHeaders headers = super.getHeaders();

        // TODO maybe the below fields are redundant, or move it from the parent if this is only for the issuers
        headers.add(IdentityConfiguration.SOURCE_IDENTITY_HEADER_INTERNAL, identityConfig.getInternalUrl());
        headers.add(IdentityConfiguration.SOURCE_IDENTITY_HEADER_NAME, identityConfig.getIdentity());
        return headers;
    }
}
