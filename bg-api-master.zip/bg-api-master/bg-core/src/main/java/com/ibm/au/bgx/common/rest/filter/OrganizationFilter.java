package com.ibm.au.bgx.common.rest.filter;

import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.user.BgxPrincipal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Filters whole organisations by using the {@link OrgProfileFilter} and {@link OrgSettingsFilter}
 *
 * @author Peter Ilfrich
 */
@Component
public class OrganizationFilter extends AbstractApiEntityFilter<Organization> {

    @Autowired
    OrgProfileFilter orgProfileFilter;

    @Override
    public Organization filterOne(Organization item, BgxPrincipal principal) {

        item.setProfile(orgProfileFilter.filterOne(item.getProfile(), principal));
        // TODO:
        // we need to reset all for now, before refactoring AuditManager to provide a principal,
        // currently test adaptation effort is too expensive
        item.setSettings(null);

        return item;
    }
}
