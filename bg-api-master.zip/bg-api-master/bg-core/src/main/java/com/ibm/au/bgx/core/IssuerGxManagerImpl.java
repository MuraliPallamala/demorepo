package com.ibm.au.bgx.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.rest.GxPrefillClientImpl;
import com.ibm.au.bgx.core.approvalmodel.ApprovalModelUtil;
import com.ibm.au.bgx.core.util.GxUtil;
import com.ibm.au.bgx.model.AbstractPrincipalProvider;
import com.ibm.au.bgx.model.GxPrefillRequestManager;
import com.ibm.au.bgx.model.api.PaginatedResponse;
import com.ibm.au.bgx.model.chain.ChannelGxChain;
import com.ibm.au.bgx.model.chain.gx.GxActionRequestConverter;
import com.ibm.au.bgx.model.chain.gx.GxManager;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.exception.GuaranteeChainException;
import com.ibm.au.bgx.model.exception.GuaranteeException;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.exception.GuaranteeNotFoundException;
import com.ibm.au.bgx.model.exception.GuaranteePreconditionFailsException;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.pojo.ActionScopeType;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.chain.FlowStatus;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxActiveRequestsBitmaskWrapper;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchResponse;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchResponse;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

public class IssuerGxManagerImpl extends AbstractPrincipalProvider implements GxManager {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    private ChannelGxChain gxChain;

    @Autowired
    private GxRequestRepository gxRequestRepository;

    @Autowired
    private GxPrefillClientImpl gxPrefillClient;

    @Autowired
    private GxPrefillRequestManager prefillRequestManager;

    @Autowired
    private GxUtil gxUtil;

    @Autowired
    private GxActionRequestConverter gxActionRequestConverter;

    public IssuerGxManagerImpl(ApplicationContext applicationContext, BgxPrincipal principal) {
        super(principal);
        this.gxChain = (ChannelGxChain) applicationContext.getBean("channelGxChain", principal, principal.getChannelUserName());
    }


    @Override
    public GxRequest submitRequest(GxRequest gxRequest)
        throws IllegalArgumentException, GuaranteeException, GuaranteeForbiddenException {
        switch (gxRequest.getType()) {
            case ISSUE:
                return this.prefillIssue(gxRequest);
            case AMEND:
                return this.prefillAmend(gxRequest);
            case DEMAND:
                return this.startDemand(gxRequest);
            case CANCEL:
                return this.prefillCancel(gxRequest);
            case PAYWALK:
                return this.startPayWalk(gxRequest);
            case TRANSFER:
                return this.startTransfer(gxRequest);
            default:
            	throw new IllegalArgumentException("Could not parse Request into known ledger type");
        }
    }

    @Override
    public GxAction submitAction(GxAction gxAction) throws IllegalArgumentException, GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        switch (gxAction.getType()) {
            case APPROVE:
                return this.actionApprove(gxAction);
            case CANCEL:
                return this.actionCancel(gxAction);
            case REVOKE:
                return this.actionRevoke(gxAction);
            case REJECT:
                return this.actionReject(gxAction);
            case DEFER:
                return this.actionDefer(gxAction);
            default:
            	throw new IllegalArgumentException("Could not parse GxActionRequest into known ledger type");
        }
    }

    private GxRequest prefillIssue(GxRequest gxRequest) throws GuaranteeException, GuaranteeForbiddenException {
    	
        GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
        List<String> visibleOrgIds = issuePayload.getApplicants();
        List<String> involvedOrgIds = ApprovalModelUtil.concatenate(issuePayload.getApplicants(), issuePayload.getBeneficiaries());
        gxRequest.setVisibleToOrgIds(visibleOrgIds);
        // Can't set visibleToChannelUsernames here as issuer api has no knowledge
        gxRequest.setInvolvedOrgIds(involvedOrgIds);
        gxRequest.setOffchainOnly(true);
        gxRequest.setCreatedBy(issuePayload.getApplicants().get(0));

        // TODO throw forbidden error
        try {
            return this.processPrefillRequest(gxRequest);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private GxRequest prefillAmend(GxRequest gxRequest)
        throws GuaranteeException, GuaranteeForbiddenException {
        Gx gx;
        try {
            gx = get(gxRequest.getGuaranteeId());
        } catch (GuaranteeNotFoundException e) {
            throw new GuaranteeForbiddenException(e);
        }
        List<String> visibleOrgIds = gx.getApplicants();
        List<String> involvedOrgIds = ApprovalModelUtil
            .concatenate(gx.getApplicants(), gx.getBeneficiaries());
        gxRequest.setVisibleToOrgIds(visibleOrgIds);
        // Not setting visibleToChannelUsernames here as issuer api has no knowledge
        gxRequest.setInvolvedOrgIds(involvedOrgIds);
        gxRequest.setOffchainOnly(true);
        gxRequest.setCreatedBy(gx.getApplicants().get(0));

        try {
            return this.processPrefillRequest(gxRequest);
        } catch (Exception e) {
            throw new GuaranteeException(e);
        }
    }

    private GxRequest prefillCancel(GxRequest gxRequest)
        throws GuaranteeException, GuaranteeForbiddenException {
        Gx gx;
        try {
            gx = get(gxRequest.getGuaranteeId());
        } catch (GuaranteeNotFoundException e) {
            throw new GuaranteeForbiddenException(e);
        }
        List<String> visibleOrgIds = gx.getApplicants();
        List<String> involvedOrgIds = ApprovalModelUtil
            .concatenate(gx.getApplicants(), gx.getBeneficiaries());
        gxRequest.setVisibleToOrgIds(visibleOrgIds);
        // Not setting visibleToChannelUsernames here as issuer api has no knowledge
        gxRequest.setInvolvedOrgIds(involvedOrgIds);
        gxRequest.setOffchainOnly(true);
        gxRequest.setCreatedBy(gx.getApplicants().get(0));

        try {
            return this.processPrefillRequest(gxRequest);
        } catch (Exception e) {
            throw new GuaranteeException(e);
        }
    }

    private GxRequest startIssue(GxRequest gxRequest) throws GuaranteeException {
        throw new GuaranteeException("Operation unsupported");
    }

    private GxRequest startAmend(GxRequest gxRequest) throws GuaranteeException {
        throw new GuaranteeException("Operation unsupported");
    }

    private GxRequest startCancel(GxRequest gxRequest) throws GuaranteeException {
        throw new GuaranteeException("Operation unsupported");
    }

    private GxRequest startDemand(GxRequest gxRequest) throws GuaranteeException {
        throw new GuaranteeException("Operation unsupported");
    }

    private GxRequest startPayWalk(GxRequest gxRequest)
        throws GuaranteeException, GuaranteeForbiddenException {
        try {
            GxRequest result = gxChain.startPayWalk(gxRequest);
            gxUtil.hackySynchroniseOffChainOnchainRequest(result.getId());
            return result;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxRequest startTransfer(GxRequest gxRequest) throws GuaranteeException {
        throw new GuaranteeException("Operation unsupported");
    }


    private GxAction actionApprove(GxAction action)
        throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            GxAction result = gxChain.actionApprove(action);
            gxUtil.hackySynchroniseOffChainOnchainRequest(result.getGxRequestId());
            return result;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 410:
                    throw new GuaranteePreconditionFailsException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxAction actionCancel(GxAction action)
        throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            GxAction result = gxChain.actionCancel(action);
            gxUtil.hackySynchroniseOffChainOnchainRequest(result.getGxRequestId());
            return result;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 410:
                    throw new GuaranteePreconditionFailsException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxAction actionRevoke(GxAction action)
        throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            GxAction result = gxChain.actionRevoke(action);
            gxUtil.hackySynchroniseOffChainOnchainRequest(result.getGxRequestId());
            return result;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 410:
                    throw new GuaranteePreconditionFailsException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxAction actionReject(GxAction action)
        throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            GxAction result = gxChain.actionReject(action);
            gxUtil.hackySynchroniseOffChainOnchainRequest(result.getGxRequestId());
            return result;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 410:
                    throw new GuaranteePreconditionFailsException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxAction actionDefer(GxAction action)
        throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            GxAction result = gxChain.actionDefer(action);
            gxUtil.hackySynchroniseOffChainOnchainRequest(result.getGxRequestId());
            return result;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 410:
                    throw new GuaranteePreconditionFailsException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxSearchResponse search(GxSearchRequest searchRequest)
        throws GuaranteeException, GuaranteeForbiddenException {
        try {
            GxSearchResponse gxSearchResponse = gxChain.search(searchRequest);
            gxUtil.addActiveRequestBitmaskToGxList(gxSearchResponse.getGxs(), null);

            return gxSearchResponse;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException e) {
            throw new GuaranteeException(e);
        }

    }

    @Override
    public Gx get(String guaranteeId)
        throws GuaranteeException, GuaranteeNotFoundException, GuaranteeForbiddenException {
        try {
            Gx gx = gxChain.get(guaranteeId);

            GxActiveRequestsBitmaskWrapper bitmaskWrapper = gxRequestRepository
                .findActiveRequestsMask(null, guaranteeId);
            if (bitmaskWrapper == null) {
                gx.setActiveRequests(0);
            } else {
                gx.setActiveRequests(bitmaskWrapper.getMask());
            }

            return gx;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 404:
                    throw new GuaranteeNotFoundException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException e) {
            throw new GuaranteeException(e);
        }

    }

    @Override
    public GxFlowsSearchResponse searchFlows(GxFlowsSearchRequest flowsSearchRequest) {
        PaginatedResponse<GxRequest> flows = gxRequestRepository.find(null, flowsSearchRequest);

        // Filter fields from gxRequest
        flows.setResult(
            flows.getResult().stream()
                .map(e -> this.gxUtil.filterGxRequest(getPrincipal(), e))
                .collect(Collectors.toList())
        );

        GxFlowsSearchResponse resp = new GxFlowsSearchResponse();
        resp.setFlows(flows.getResult());
        resp.setNext(flows.getNext());

        return resp;
    }

    @Override
    public GxRequest getFlow(String flowId)
        throws GuaranteeException, GuaranteeForbiddenException, GuaranteeNotFoundException {
        try {
            GxRequest offchainRequest = gxRequestRepository.getItem(flowId);
            // Only use offchain for offchain only requests or active requests
            if ((offchainRequest.getOffchainOnly() != null && offchainRequest.getOffchainOnly())
                || offchainRequest.getStatus().equals(FlowStatus.ACTIVE)) {
                return offchainRequest;
            }
        } catch (DataNotFoundException e) {
            throw new GuaranteeNotFoundException(e);
        }
        try {
            return gxChain.getFlow(flowId);
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 404:
                    throw new GuaranteeNotFoundException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public List<GxAction> getFlowActions(String flowId)
        throws GuaranteeException, GuaranteeForbiddenException, GuaranteePreconditionFailsException {

        GxRequest gxRequest = null;
        List<GxAction> gxActions = null;

        GxRequest offchainRequest = null;
        boolean offchainOnly = false;

        // Check if GxRequest belongs to channel
        // HACK

        // Don't search the ledger if the record is offchain-only

        try {
            gxRequest = this.gxRequestRepository.getItem(flowId);
            if (gxRequest.getOffchainOnly() != null) {
                offchainOnly = gxRequest.getOffchainOnly();
            }
        } catch (DataNotFoundException e) {
            throw new GuaranteePreconditionFailsException(e);
        }

        if (!offchainOnly) {
        try {
            gxRequest = gxChain.getFlow(flowId);
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 404:
                    // Do nothing as will check offchain
                    break;
                default:
                    throw new GuaranteeException(e);
            }
        } catch (ParseException e) {
            throw new GuaranteeException(e);
        }

            // handle onchain
            try {
                gxActions = gxChain.getFlowActions(flowId);
            } catch (GuaranteeChainException e) {
                switch (e.getFabricMessage().getChaincodeStatusCode()) {
                    case 403:
                        throw new GuaranteeForbiddenException(e);
                    case 410:
                        throw new GuaranteePreconditionFailsException(e);
                    default:
                        throw new GuaranteeException(e);
                }
            } catch (ParseException e) {
                throw new GuaranteeException(e);
            }

        } else {
            // handle offchain
            try {
                gxRequest = gxRequestRepository.getItem(flowId);
                gxActions = gxRequest.getOffchainActions();
                for (GxAction action : gxActions) {
                    action.setScope(ActionScopeType.EXTERNAL);
                }
            } catch (DataNotFoundException e) {
                throw new GuaranteePreconditionFailsException(e);
            }
        }

        if (gxActions == null) {
            gxActions = new ArrayList<>();
        }
        // END HACK

        List<ApprovalModelFlowRequest> approvalModelFlowRequests = this.getPrincipal()
            .getApprovalModel().getApprovalFlows(flowId, null, null);

        List<GxPrefillRequest> prefillRequests = this.getPrincipal()
            .getGxPrefillRequestManager()
            .find(flowId);
        if (prefillRequests.size() > 0) {
            gxActions.add(gxActionRequestConverter.from(prefillRequests.get(0)));
        }

        for (ApprovalModelFlowRequest approvalModelFlowRequest : approvalModelFlowRequests) {
            gxActions.addAll(gxActionRequestConverter.fromChildren(approvalModelFlowRequest));
        }

        gxActions.sort(Comparator.comparing(GxAction::getCreatedAt));
        return gxActions;
    }


    @Override
    public GxAction getFlowAction(String flowId, String actionId)
        throws GuaranteeException, GuaranteeNotFoundException, GuaranteeForbiddenException, GuaranteePreconditionFailsException {
        List<GxAction> actions = this.getFlowActions(flowId);
        for (GxAction action : actions) {
            if (action.getId().equals(actionId)) {
                return action;
            }
        }
        throw new GuaranteeNotFoundException(
            String.format("Could not find action with Id %s", actionId));
    }

    private GxRequest processPrefillRequest(GxRequest gxRequest)
        throws ServiceUnavailableException {
        gxRequest.setStatus(FlowStatus.ACTIVE);
        gxRequest.setChannelName(
                        gxUtil.getChannelNameFromIssuerId(getPrincipal().getConfiguredForOrgId()));
        gxRequest.setPrefill(true);

        // Send prefill to newco
        GxPrefillRequest prefillRequest = gxPrefillClient
            .sendGxPrefillNotification(getPrincipal(), gxRequest);

        // store prefill request in prefillRequestRepository (without payload)
        prefillRequest.setPayload(null);
        prefillRequestManager.add(prefillRequest);

        // store GxRequest
        return gxRequestRepository.addItem(gxRequest);
    }
}
