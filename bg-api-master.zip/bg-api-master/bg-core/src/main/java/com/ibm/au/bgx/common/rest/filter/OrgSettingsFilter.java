package com.ibm.au.bgx.common.rest.filter;

import com.ibm.au.bgx.model.pojo.OrgSettings;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.springframework.stereotype.Component;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@Component
public class OrgSettingsFilter extends AbstractApiEntityFilter<OrgSettings> {

    @Override
    public OrgSettings filterOne(OrgSettings item, BgxPrincipal principal) {
        if (item == null) {
            return item;
        }

        // we don't filter for newco and newco-admin users
        if (principal != null && principal.isConsortiumUser()) {
            return item;
        }

        // filter identity API auth details
        item.setApiAuth(null);
        item.setUserAuth(null);

        return item;
    }
}
