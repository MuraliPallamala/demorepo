package com.ibm.au.bgx.common.rest;

import com.ibm.au.bgx.core.cache.OrgCache;
import com.ibm.au.bgx.model.api.GxPrefillClient;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.ReferredGxAction;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;

/**
 * @author Peter Ilfrich
 */
@Component
public class GxPrefillClientImpl extends AbstractNewCoClient implements
        GxPrefillClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(GxPrefillClientImpl.class);

    @Autowired
    private OrgCache orgCache;


    @Override
    public GxPrefillRequest sendGxPrefillNotification(BgxPrincipal principal, GxRequest gxRequest) throws ServiceUnavailableException {
        HttpHeaders headers;
        try {
            headers = this.getHeaders();
        } catch (Exception e) {
            throw new IllegalArgumentException("Could not prepare headers", e);
        }

        String url = String.format("%s%s", this.getBaseUrl(), ApiConstants.GX_NOTIFICATION_ENDPOINT);

        GxPrefillRequest notification = new GxPrefillRequest();
        notification.setPayload(gxRequest);
        notification.setInvolvedOrgIds(gxRequest.getInvolvedOrgIds());
        notification.setVisibleToOrgIds(gxRequest.getVisibleToOrgIds());
        notification.setGxRequestId(gxRequest.getId());
        notification.setCreatedBy(principal.getPrimaryOrgId());

        // Any API-to-API request requires the referrer headers to be added which is basically a signature of the payload
        notification.setReferrerId(this.identityConfig.getIdentity());
        this.addRequestHash(headers, notification, this.identityConfig.getIdentity());

        HttpEntity<?> httpRequest = new HttpEntity<>(notification, headers);

        LOGGER.debug(BgxLogMarkers.DEV, "> POST {}", url);

        try {

            RestTemplate rest = this.getRestTemplate(url);
            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = rest.exchange(url, HttpMethod.POST, httpRequest, Map.class);
            if (!response.getStatusCode().equals(HttpStatus.OK)) {

                // just log the error, no need to take action or throw an exception
                LOGGER.error(BgxLogMarkers.DEV,
                        "Sending delete request notification returned an invalid status code: {}",
                        response.getStatusCode());
            }

        } catch (IOException | URISyntaxException ioex) {

            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }

        return notification;
    }

    // Sends to Issuer
    @Override
    public ReferredGxAction sendOffchainGxActionNotification(String issuerId, GxAction gxAction) throws ProfileNotFoundException, ProfileChainException, ServiceUnavailableException {
        HttpHeaders headers;
        try {
            headers = this.getHeaders();
        } catch (Exception e) {
            throw new IllegalArgumentException("Could not prepare headers", e);
        }

        Organization organization = this.orgCache.get(issuerId);

        String url = String.format("%s%s", organization.getSettings().getApiUrl(), ApiConstants.GX_ACTIONS_NOTIFICATION_ENDPOINT);

        ReferredGxAction notification = new ReferredGxAction();
        notification.setPayload(gxAction);
        notification.setCreatedBy(gxAction.getCreatedBy());

        // Any API-to-API request requires the referrer headers to be added which is basically a signature of the payload
        notification.setReferrerId(this.identityConfig.getIdentity());
        this.addRequestHash(headers, notification, this.identityConfig.getIdentity());

        HttpEntity<?> httpRequest = new HttpEntity<>(notification, headers);

        LOGGER.debug(BgxLogMarkers.DEV, "> POST {}", url);

        try {

            RestTemplate rest = this.getRestTemplate(url);
            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = rest.exchange(url, HttpMethod.POST, httpRequest, Map.class);
            if (!response.getStatusCode().equals(HttpStatus.OK)) {

                // just log the error, no need to take action or throw an exception
                LOGGER.error(BgxLogMarkers.DEV,
                    "Sending delete request notification returned an invalid status code: {}",
                    response.getStatusCode());
            }

        } catch (IOException | URISyntaxException ioex) {

            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }

        return notification;
    }

}
