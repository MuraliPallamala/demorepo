package com.ibm.au.bgx.core.chain.event;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.util.JsonFormat;

import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.chain.BlockchainEvent;
import com.ibm.au.bgx.model.queue.QueueClient;

import org.hyperledger.fabric.sdk.BlockEvent;
import org.hyperledger.fabric.sdk.ChaincodeEvent;
import org.hyperledger.fabric.sdk.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Abstract class providing base functionality to register and process blockchain events. It uses a
 * handle set to prevent duplicate event execution and also stores handles for each registered
 * event.
 *
 * @author Peter Ilfrich
 */
public abstract class AbstractEventHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractEventHandler.class);
    private static final Set<String> handledHandles = new HashSet<>();
    protected Map<String, Set<String>> eventHandles = new HashMap<>();
    protected List<BlockchainEvent> temporaryQueue;
    protected boolean temporaryQueueActive = false;
    @Autowired
    private QueueClient queueClient;

    /**
     * Registers events for a specific event handler. The type of events registered depends on the
     * actual implementation of the event handler.
     *
     * @param channel - the channel for which to register events
     */
    public abstract void registerEvents(Channel channel);


    /**
     * Handle an incoming blockchain event.
     *
     * @param message        - the payload emitted through the blockchain event from the chaincode
     * @param handle         - a unique identifier for the event
     * @param blockEvent     - the actual block event received from the blockchain
     * @param chaincodeEvent - the actual chaincode event received from the blockchain
     */
    public void handle(Object message, String handle, BlockEvent blockEvent,
                       ChaincodeEvent chaincodeEvent) {

        if (!this.addHandle(chaincodeEvent.getTxId())) {
            // abort handling if already handled by a different thread
            return;
        }

        BlockchainEvent event = new BlockchainEvent();
        try {
            event.setChannelId(blockEvent.getChannelId());
            event.setTxId(chaincodeEvent.getTxId());
            event.setEventName(chaincodeEvent.getEventName());
            event.setPayload(JsonFormat.printer().print((Message) message));

            synchronized (this) {
                // either directly process the event or add it to a temporary queue
                if (temporaryQueueActive) {
                    temporaryQueue.add(event);
                } else {
                    queueClient.addBlockchainEvent(event);
                }
            }

        } catch (InvalidProtocolBufferException ipe) {
            LOGGER.error("Error extracting information from blockchain event.", ipe);
        } catch (IOException ioe) {
            LOGGER.error("Error submitting new blockchain event to queue.", ioe);
        }

        this.cleanupHandle(chaincodeEvent.getTxId());
    }

    /**
     * When the event hub disconnects, this will enable a temporary queue that buffers new incoming
     * events, while it processes events that have been emitted, while the eventhub was
     * disconnected.
     *
     * @param activate - a flag indicating whether to turn the temporary queue on or off.
     */
    public void setTemporaryQueue(boolean activate) {
        if (activate == true) {
            // init fresh temp queue
            LOGGER.debug(BgxLogMarkers.DEV, "Enabling temporary queue");
            temporaryQueue = new LinkedList<>();
            temporaryQueueActive = true;
        } else {
            // process temporary queue
            synchronized (this) {
                LOGGER.debug(BgxLogMarkers.DEV, "Disabling temporary queue and processing temporary queue of size {}", temporaryQueue.size());
                for (BlockchainEvent event : temporaryQueue) {
                    try {
                        queueClient.addBlockchainEvent(event);
                    } catch (Exception e) {
                        LOGGER.error("Failed to add event to the blockchain event queue", e);
                    }
                }
                temporaryQueue = null;
                temporaryQueueActive = false;
            }
        }
    }

    /**
     * Method to remove any event registrations for the currently stored event handles that have
     * been captured during event registration.
     *
     * @param channel - the channel for which to unregister
     * @throws Exception in case of any error during unregistration of chaincode event listeners
     */
    public void unregisterEvents(Channel channel) throws Exception {
        if (this.eventHandles != null && this.eventHandles.containsKey(channel.getName())) {
            Set<String> handles = this.eventHandles.get(channel.getName());
            for (String handle : handles) {
                LOGGER.debug(BgxLogMarkers.DEV, "Unregister event for channel {} and handle {}", channel.getName(), handle);
                channel.unregisterChaincodeEventListener(handle);
            }
        }
        // reset the current list of handles
        this.eventHandles.put(channel.getName(), new HashSet<>());
    }

    /**
     * Getter for the different event handles cache for each channel.
     *
     * @param channel - the channel for which to retrieve the list of handles representing the
     *                registered events
     * @return a set of identifiers representing registered events.
     */
    protected Set<String> getEventHandleSet(Channel channel) {
        if (eventHandles == null) {
            eventHandles = new HashMap<>();
        }
        if (!eventHandles.containsKey(channel.getName())) {
            eventHandles.put(channel.getName(), new HashSet<>());
        }

        Set<String> handles = eventHandles.get(channel.getName());
        return handles;
    }

    /**
     * Cleans up a given handle after 5 seconds. Leaving the handle for 5 seconds, will prevent
     * double execution of the event handler.
     *
     * @param handle - the handle to remove
     */
    protected void cleanupHandle(String handle) {

        Thread t = new Thread(() -> {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ie) {
                // should not happen
                Thread.currentThread().interrupt();
            }

            // remove the handle
            synchronized (handledHandles) {
                handledHandles.remove(handle);
            }
        });

        t.start();
    }

    /**
     * Will attempt to add the given handle to the handle list, which avoids double execution of the
     * event handler.
     *
     * @param handle - the handle to add
     * @return true if the handle could be added and false, if the handle already exists (another
     * thread is already handling this)
     */
    protected boolean addHandle(String handle) {
        synchronized (handledHandles) {
            if (!handledHandles.contains(handle)) {
                handledHandles.add(handle);
                return true;
            } else {
                // nothing to do, event already handled
                return false;
            }
        }
    }
}
