package com.ibm.au.bgx.common.rest;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ibm.au.bgx.model.api.CacheRefreshClient;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.CacheRefreshRequest;

import com.ibm.au.bgx.model.pojo.api.response.ExceptionResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.Set;

/**
 * <p>
 * Class <b>CacheRefreshClientImpl</b>. This is default implementation of the {@link CacheRefreshClient}
 * interface. It specialises the capabilities of {@link AbstractRemoteClient} to include methods for
 * triggering updates to the in-memory caches of an API deployment.
 * </p>
 * <p>
 * This client is designed to interact with the cache refresh endpoint {@link CacheRefreshClient#CACHE_REQUESTS}
 * and create instance of {@link CacheRefreshRequest} instance with the collection and entries identifiers
 * to refresh, which is then submitted to that endpoint.
 * </p>
 * 
 * @author Peter Ilfrich
 */
@Component
public class CacheRefreshClientImpl extends AbstractRemoteClient implements CacheRefreshClient {

	/**
	 * A {@link Logger} implementation that collects all the log messages produced by instances
	 * of this class.
	 */
    private static final Logger LOGGER = LoggerFactory.getLogger(CacheRefreshClientImpl.class);

    /**
     * A {@link String} representing the endpoint of the APIs that are the target of the cache
     * refresh. This field is set by via the Spring property <i>bgx.internalUrl</i>, which is
     * set to the internal URL of the API deployment of a vertical.
     */
    @Value("${bgx.internalUrl:http://localhost:9080}")
    public String mainApiUrl;

    /**
     * {@inheritDoc}
     */
    @Override
    public void sendOrganizationCacheRefresh(String orgId) throws ServiceUnavailableException  {
    	
    	if (orgId == null || orgId.isEmpty()) {
    		throw new IllegalArgumentException("Parameter 'orgId' cannot be null or empty.");
    	}
    	
        CacheRefreshRequest request = this.createRequest(CacheRefreshRequest.Collection.ORGANIZATIONS, orgId);
        this.sendRequest(request);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void sendPurposeFormatCacheRefresh(String formatId) throws ServiceUnavailableException {

    	if (formatId == null || formatId.isEmpty()) {
    		throw new IllegalArgumentException("Parameter 'formatId' cannot be null or empty.");
    	}
    	
        CacheRefreshRequest request = this.createRequest(CacheRefreshRequest.Collection.PURPOSE_FORMATS, formatId);
        this.sendRequest(request);
    }
    
    /**
     * Creates a {@link CacheRefreshRequest} instance for the given <i>collection</i> and sets as entries
     * to be updated, the identifiers stored in entries.
     * 
     * @param collection	the identifier of the collection that stores the identifiers that are passed
     * 						in <i>entries</i>. It is expected to not to be {@literal null}.
     * 
     * @param entries		a {@link String} array containing the list of identifier in the collection
     * 						specified by <i>collection</i> to refresh. This array is expected to not to
     * 						be {@literal null}, empty, and not to contains duplicates.
     * 
     * @return	a {@link CacheRefreshRequest} instance. It is guarateed to not to be {@literal null}.
     */
    protected CacheRefreshRequest createRequest(CacheRefreshRequest.Collection collection, String... entries) {
    	
    	CacheRefreshRequest request = new CacheRefreshRequest();
    	request.setCollection(collection);
    	
    	Set<String> entities = new HashSet<>();
    	for(String entity : entries) {
    		entities.add(entity);
    	}
    	
    	request.setEntities(entities);
    	
    	return request;
    }
    
    /**
     * Sends the given request to the configured API deployment, to trigger the update of the cache
     * for the specified collection and entries. This method computes the signed hash of <i>request</i>,
     * it then adds it as a {@link ApiConstants#REQUEST_HASH} header, and submits the request to the
     * {@link CacheRefreshClient#CACHE_REQUESTS} endpoint of the configured API deployment.
     * 
     * @param request		a {@link CacheRefreshRequest} instance containing the details of the
     * 						collection and entry to refresh. It is expected to not to be {@literal 
     * 						null}.
     * 
     * @throws ServiceUnavailableException	if the remote API deployment is not reachable, for any other
     * 										type of error, the information returned by the API endpoint
     * 										is logged.
     */
    protected void sendRequest(CacheRefreshRequest request) throws ServiceUnavailableException {
    	
    	try {

            String url = String.format("%s%s", this.mainApiUrl, CacheRefreshClient.CACHE_REQUESTS);

            LOGGER.debug(BgxLogMarkers.DEV, "Sending cache refresh request (url: {}, collection: {}, entities: {}) ...", url, request.getCollection(), request.getEntities().size());
            
            RestTemplate rest = this.getRestTemplate(url);


            HttpHeaders headers = this.getHeaders();
            this.addRequestHash(headers, request, this.identityConfig.getIdentity());

            HttpEntity<CacheRefreshRequest> httpRequest = new HttpEntity<>(request, headers);
            ResponseEntity<String> response = rest.exchange(url, HttpMethod.POST, httpRequest, String.class);
            
            LOGGER.debug(BgxLogMarkers.DEV, "Response status code: {}", response.getStatusCodeValue());
            if (response.getStatusCodeValue() != 204) {

            	try {
            		
            		ExceptionResponse error = MAPPER.readValue(response.getBody(), ExceptionResponse.class);
            		LOGGER.error("Error code: {}, Error message: {}", error.getCode(), error.getMessage());
            	
            	} catch(JsonMappingException | JsonParseException e) {
            		
            		LOGGER.error("Could not interpret error response from API (error: {}).", e.getMessage());
            	}
            }

        } catch (IOException | URISyntaxException ioe) {
        	
            throw new ServiceUnavailableException("Could not complete successfully remote cache update.", ioe);
        }
    }
    
}
