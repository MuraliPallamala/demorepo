package com.ibm.au.bgx.core.cache;

import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.pojo.Organization;

/**
 * 
 * @author 
 *
 */
public interface OrgCache {

	/**
	 * 
	 * @param orgId
	 * @return
	 * @throws ProfileNotFoundException
	 * @throws ProfileChainException
	 */
    Organization get(String orgId) throws ProfileNotFoundException, ProfileChainException;

    /**
     * 
     * @param orgId
     */
    void refresh(String orgId);
}
