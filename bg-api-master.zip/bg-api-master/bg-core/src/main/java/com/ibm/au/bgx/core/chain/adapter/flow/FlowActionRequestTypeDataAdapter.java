package com.ibm.au.bgx.core.chain.adapter.flow;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.chain.FlowActionRequestType;
import com.ibm.au.bgx.model.shared.Flow;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class FlowActionRequestTypeDataAdapter implements ChainDataAdapter<Flow.FlowActionRequestType, FlowActionRequestType> {

    @Override
    public Flow.FlowActionRequestType toOnChainModel(FlowActionRequestType input) {
        switch (input) {
            case SUBMIT:
                return Flow.FlowActionRequestType.FLOW_ACTION_REQUEST_SUBMIT;
            case APPROVE:
                return Flow.FlowActionRequestType.FLOW_ACTION_REQUEST_APPROVE;
            case CANCEL:
                return Flow.FlowActionRequestType.FLOW_ACTION_REQUEST_CANCEL;
            case REVOKE:
                return Flow.FlowActionRequestType.FLOW_ACTION_REQUEST_REVOKE;
            case REJECT:
                return Flow.FlowActionRequestType.FLOW_ACTION_REQUEST_REJECT;
            case DEFER:
                return Flow.FlowActionRequestType.FLOW_ACTION_REQUEST_DEFER;
        }
        throw new IllegalArgumentException("Unable to map FlowActionRequestType to on chain model");
    }

    @Override
    public FlowActionRequestType toOffchainModel(Flow.FlowActionRequestType input) {
        switch (input) {
            case FLOW_ACTION_REQUEST_SUBMIT:
                return FlowActionRequestType.SUBMIT;
            case FLOW_ACTION_REQUEST_APPROVE:
                return FlowActionRequestType.APPROVE;
            case FLOW_ACTION_REQUEST_CANCEL:
                return FlowActionRequestType.CANCEL;
            case FLOW_ACTION_REQUEST_REVOKE:
                return FlowActionRequestType.REVOKE;
            case FLOW_ACTION_REQUEST_REJECT:
                return FlowActionRequestType.REJECT;
            case FLOW_ACTION_REQUEST_DEFER:
                return FlowActionRequestType.DEFER;
            default:
            	throw new IllegalArgumentException("Unable to map FlowActionRequestType to off chain model");
            	
        }
    }
}
