package com.ibm.au.bgx.core.cache;

import com.ibm.au.bgx.core.cache.OrgCache;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.Organization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class OrgCacheImpl implements OrgCache {

    @Autowired
    OrganizationManager organizationManager;

    Map<String, Organization> map = new HashMap<>();

    @Override
    public synchronized Organization get(String orgId) throws ProfileNotFoundException, ProfileChainException {
        Organization resp = map.get(orgId);
        if (resp != null) {
            return resp;
        }

        resp = organizationManager.getById(orgId);

        if (resp != null) {
            map.put(resp.getId(), resp);
        }

        return resp;
    }

    @Override
    public synchronized void refresh(String orgId) {
        if (!map.containsKey(orgId)) {
            // if the cache doesn't contain the orgId, don't bother
            return;
        }
        map.remove(orgId);
    }

    public static OrgProfile filterOrgProfile(OrgProfile orgProfile) {
        OrgProfile filtered = new OrgProfile();
        filtered.setId(orgProfile.getId());
        filtered.setEntityName(orgProfile.getEntityName());
        filtered.setBusinessId(orgProfile.getBusinessId());
        filtered.setContacts(null);
        filtered.setAttachments(null);

        return filtered;
    }
}
