package com.ibm.au.bgx.core;

import java.io.IOException;
import java.text.ParseException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.rest.GxPrefillClientImpl;
import com.ibm.au.bgx.core.util.GxUtil;
import com.ibm.au.bgx.core.util.ImpersonatedOrgPrincipal;
import com.ibm.au.bgx.model.AbstractPrincipalProvider;
import com.ibm.au.bgx.model.api.PaginatedResponse;
import com.ibm.au.bgx.model.approvalmodel.ApprovalModel;
import com.ibm.au.bgx.model.chain.GxChain;
import com.ibm.au.bgx.model.chain.gx.GxActionRequestConverter;
import com.ibm.au.bgx.model.chain.gx.GxManager;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.exception.GuaranteeChainException;
import com.ibm.au.bgx.model.exception.GuaranteeException;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.exception.GuaranteeNotFoundException;
import com.ibm.au.bgx.model.exception.GuaranteePreconditionFailsException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.notification.WebNotificationManager;
import com.ibm.au.bgx.model.pojo.ActionScopeType;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.chain.FlowStatus;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxActionApprovePayload;
import com.ibm.au.bgx.model.pojo.gx.GxActionDefaultPayload;
import com.ibm.au.bgx.model.pojo.gx.GxActionType;
import com.ibm.au.bgx.model.pojo.gx.GxActiveRequestsBitmaskWrapper;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchResponse;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.gx.GxSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchResponse;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.notification.WebNotification.MessageType;
import com.ibm.au.bgx.model.pojo.notification.WebNotification.ReferenceType;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;

/**
 * This class wraps over GxChain and the GxRepository and manages all Guarantee operations
 *
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
public class AppBenGxManagerImpl extends AbstractPrincipalProvider implements
    GxManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(AppBenGxManagerImpl.class);

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    
    @Autowired
    OrganizationManager organizationManager;
    ApplicationContext applicationContext;
    private GxChain gxChain;

    @Autowired
    private GxPrefillClientImpl gxPrefillClient;
    
    @Autowired
    @Qualifier("channelResolverRequestCache")
    private ChannelResolver gxRequestChannelResolver; // For request IDs
    
    @Autowired
    private ChannelResolverNamePrefixImpl gxChannelResolver; // For Gx IDs
    
    @Autowired
    private GxRequestRepository gxRequestRepository;
    
    @Autowired
    private QueueClient queueClient;
    
    @Autowired
    private WebNotificationManager notificationManager;
    
    @Autowired
    private GxUtil gxUtil;
    
    @Autowired
    private GxActionRequestConverter gxActionRequestConverter;


    /**
     * This public constructor is to create the bean
     * <p>
     * However, before making any other method call, we need to call forOrg() to get a properly
     * configured instance that has properly initialized GxChain instance
     */
    public AppBenGxManagerImpl(ApplicationContext applicationContext, BgxPrincipal principal) {
        super(principal);
        this.applicationContext = applicationContext;
        this.gxChain = (GxChain) applicationContext
            .getBean("gxChain", principal, principal.getChannelUserName());
    }


    @Override
    public GxRequest submitRequest(GxRequest gxRequest) throws IllegalArgumentException, GuaranteeException, GuaranteeForbiddenException {
        switch (gxRequest.getType()) {
            case ISSUE:
                if (this.getPrincipal()
                		.getOrganization()
                		.getProfile()
                		.getEntityType()
                		.equals(OrgProfile.EntityType.ISSUER)) {
                	
                    return this.prefillIssue(gxRequest);
                }
                return this.startIssue(gxRequest);
            case AMEND:
                if (this.getPrincipal()
                		.getOrganization()
                		.getProfile()
                		.getEntityType()
                		.equals(OrgProfile.EntityType.ISSUER)) {
                	
                    return this.prefillAmend(gxRequest);
                }
                return this.startAmend(gxRequest);
            case DEMAND:
                return this.startDemand(gxRequest);
            case CANCEL:
                if (this.getPrincipal()
                		.getOrganization()
                		.getProfile()
                		.getEntityType()
                		.equals(OrgProfile.EntityType.ISSUER)) {
                	
                    return this.prefillCancel(gxRequest);
                }
                return this.startCancel(gxRequest);
            case PAYWALK:
                return this.startPayWalk(gxRequest);
            case TRANSFER:
                return this.startTransfer(gxRequest);
                
            default:
            	throw new IllegalArgumentException("Could not parse Request into known ledger type");
        }
        
    }

    @Override
    public GxAction submitAction(GxAction gxAction) throws IllegalArgumentException, GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        switch (gxAction.getType()) {
            case APPROVE:
                return this.actionApprove(gxAction);
            case CANCEL:
                return this.actionCancel(gxAction);
            case REVOKE:
                return this.actionRevoke(gxAction);
            case REJECT:
                return this.actionReject(gxAction);
            case DEFER:
                return this.actionDefer(gxAction);
            default:
            	throw new IllegalArgumentException("Could not parse GxActionRequest into known ledger type");
        }
    }

    private GxRequest prefillIssue(GxRequest gxRequest) throws GuaranteeException {
        throw new GuaranteeException("Operation unsupported");
    }

    private GxRequest prefillAmend(GxRequest gxRequest) throws GuaranteeException {
        throw new GuaranteeException("Operation unsupported");
    }

    private GxRequest prefillCancel(GxRequest gxRequest) throws GuaranteeException {
        throw new GuaranteeException("Operation unsupported");
    }

    private GxRequest startIssue(GxRequest gxRequest) throws GuaranteeException, GuaranteeForbiddenException {
    	
        GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);

        // Beneficiary initiated issuing peforms an offchain request instead of onchain if issuer is unspecified
        if (this.actsAsBeneficiary(issuePayload) && issuePayload.getIssuer() == null) {

            // Set Created At now, so that it occurs after approval model requests
            gxRequest.setCreatedAt(Instant.now());

            // Set involved and visible orgs (same)
            List<String> involvedOrgs = new ArrayList<>();
            involvedOrgs.addAll(issuePayload.getApplicants());
            involvedOrgs.addAll(issuePayload.getBeneficiaries());
            gxRequest.setInvolvedOrgIds(involvedOrgs);
            gxRequest.setVisibleToOrgIds(involvedOrgs);
            gxRequest.setVisibleToChannelUsernames(gxUtil.getVisibleToChannelUsernames(gxRequest));

            issuePayload.setOffchainCreatedAt(gxRequest.getCreatedAt());
            gxRequest.setPayload(issuePayload);
            List<GxAction> offchainActions = new ArrayList<>();
            GxAction submitAction = new GxAction();
            submitAction.setType(GxActionType.SUBMIT);
            submitAction.setScope(ActionScopeType.EXTERNAL);
            submitAction.setCreatedAt(gxRequest.getCreatedAt());
            submitAction.setCreatedBy(gxRequest.getCreatedBy());
            offchainActions.add(submitAction);
            gxRequest.setOffchainActions(offchainActions);
            gxRequest.setOffchainOnly(true);

            // Upsert GxRequest
            GxRequest resp;
            try {
                this.gxRequestRepository.getItem(gxRequest.getId());
                resp = this.gxRequestRepository.updateItem(gxRequest);
            } catch (DataNotFoundException e) {
                resp = this.gxRequestRepository.addItem(gxRequest);
            }

            // send notification to applicant
            WebNotification notification = new WebNotification();
            notification.setMessageType(MessageType.START_GX_ISSUE);
            notification.setReferenceType(ReferenceType.GX_REQUEST);
            notification.setReferenceId(resp.getId());
            notification.setActionRequired(true);
            notification.setActionDone(false);
            this.notificationManager.populateGxIssueData(notification, resp, false);

            // retrieve beneficiary organisation to resolve
            Organization beneficiaryOrg = null;
            if (getPrincipal().getConfiguredForOrgId()
                .equals(getPrincipal().getOrganization().getId())) {
                beneficiaryOrg = getPrincipal().getOrganization();
            } else {
                try {
                    beneficiaryOrg = this.organizationManager.getById(getPrincipal().getConfiguredForOrgId());
                } catch (ProfileNotFoundException | ProfileChainException pe) {
                    LOGGER.error(String.format("Could not find beneficiary organisation '%s'", this.getPrincipal().getConfiguredForOrgId()), pe);
                }
            }
            // update payload with beneficiary org name
            if (beneficiaryOrg != null) {
                this.notificationManager.addEntityInformation(notification, beneficiaryOrg.getProfile());
            }

            try {
                for (String orgId : issuePayload.getApplicants()) {
                    this.queueClient.addWebNotification(notification, orgId);
                }
            } catch (IOException ioe) {
                LOGGER.error("Error sending web notification for beneficiary initiated guarantee issue request.");
            }

            return resp;
        }
        gxRequest.setPayload(issuePayload);
        String channelName = this.gxUtil.getChannelNameFromIssuerId(issuePayload.getIssuer());
        gxRequest.setChannelName(channelName);

        // TODO remove once we synchronise with service api
        // Upsert GxRequest in order to link to channel
        gxRequest.setVisibleToOrgIds(Collections.singletonList(gxRequest.getCreatedBy()));
        gxRequest.setVisibleToChannelUsernames(gxUtil.getVisibleToChannelUsernames(gxRequest));
        try {
            this.gxRequestRepository.getItem(gxRequest.getId());
            this.gxRequestRepository.updateItem(gxRequest);
        } catch (DataNotFoundException e) {
            this.gxRequestRepository.addItem(gxRequest);
        }
        // END TODO

        try {
            GxRequest result = this.gxChain.startIssue(channelName, gxRequest);
            this.gxUtil.hackySynchroniseOffChainOnchainRequest(result.getId());
            return result;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxRequest startAmend(GxRequest gxRequest) throws GuaranteeException, GuaranteeForbiddenException {
    	
        String channelName = this.gxChannelResolver.get(gxRequest.getGuaranteeId());
        // TODO remove once we synchronise with service api
        // Upsert GxRequest in order to link to channel
        gxRequest.setChannelName(channelName);
        gxRequest.setVisibleToOrgIds(Collections.singletonList(gxRequest.getCreatedBy()));
        gxRequest.setVisibleToChannelUsernames(this.gxUtil.getVisibleToChannelUsernames(gxRequest));
        try {
            this.gxRequestRepository.getItem(gxRequest.getId());
            this.gxRequestRepository.updateItem(gxRequest);
        } catch (DataNotFoundException e) {
        	this.gxRequestRepository.addItem(gxRequest);
        }
        // END TODO

        try {
            GxRequest result = this.gxChain.startAmend(channelName, gxRequest);
            this.gxUtil.hackySynchroniseOffChainOnchainRequest(result.getId());
            return result;
            
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }

    }

    private GxRequest startCancel(GxRequest gxRequest) throws GuaranteeException, GuaranteeForbiddenException {
    	
        String channelName = this.gxChannelResolver.get(gxRequest.getGuaranteeId());
        // TODO remove once we synchronise with service api
        // Upsert GxRequest in order to link to channel
        gxRequest.setChannelName(channelName);
        gxRequest.setVisibleToOrgIds(Collections.singletonList(gxRequest.getCreatedBy()));
        gxRequest.setVisibleToChannelUsernames(this.gxUtil.getVisibleToChannelUsernames(gxRequest));
        try {
            this.gxRequestRepository.getItem(gxRequest.getId());
            this.gxRequestRepository.updateItem(gxRequest);
            
        } catch (DataNotFoundException e) {
            this.gxRequestRepository.addItem(gxRequest);
        }
        // END TODO

        try {
            
        	GxRequest result = this.gxChain.startCancel(channelName, gxRequest);
            this.gxUtil.hackySynchroniseOffChainOnchainRequest(result.getId());
            return result;
            
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxRequest startDemand(GxRequest gxRequest)throws GuaranteeException, GuaranteeForbiddenException {
    	
        String channelName = this.gxChannelResolver.get(gxRequest.getGuaranteeId());
        // TODO remove once we synchronise with service api
        // Upsert GxRequest in order to link to channel
        gxRequest.setChannelName(channelName);
        gxRequest.setVisibleToOrgIds(Collections.singletonList(gxRequest.getCreatedBy()));
        gxRequest.setVisibleToChannelUsernames(this.gxUtil.getVisibleToChannelUsernames(gxRequest));
        
        try {
            this.gxRequestRepository.getItem(gxRequest.getId());
            this.gxRequestRepository.updateItem(gxRequest);
            
        } catch (DataNotFoundException e) {
            this.gxRequestRepository.addItem(gxRequest);
        }
        // END TODO

        try {
        	
            GxRequest result = this.gxChain.startDemand(channelName, gxRequest);
            this.gxUtil.hackySynchroniseOffChainOnchainRequest(result.getId());
            return result;
            
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxRequest startPayWalk(GxRequest gxRequest) throws GuaranteeException, GuaranteeForbiddenException {
    	
        String channelName = this.gxChannelResolver.get(gxRequest.getGuaranteeId());
        // TODO remove once we synchronise with service api
        // Upsert GxRequest in order to link to channel
        gxRequest.setChannelName(channelName);
        gxRequest.setVisibleToOrgIds(Collections.singletonList(gxRequest.getCreatedBy()));
        gxRequest.setVisibleToChannelUsernames(this.gxUtil.getVisibleToChannelUsernames(gxRequest));
        try {
            
        	this.gxRequestRepository.getItem(gxRequest.getId());
            this.gxRequestRepository.updateItem(gxRequest);
            
        } catch (DataNotFoundException e) {
            this.gxRequestRepository.addItem(gxRequest);
        }
        // END TODO

        try {
            
        	GxRequest result = this.gxChain.startPayWalk(channelName, gxRequest);
            this.gxUtil.hackySynchroniseOffChainOnchainRequest(result.getId());
            return result;
            
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxRequest startTransfer(GxRequest gxRequest) throws GuaranteeException, GuaranteeForbiddenException {
    	
        String channelName = this.gxChannelResolver.get(gxRequest.getGuaranteeId());
        // TODO remove once we synchronise with service api
        // Upsert GxRequest in order to link to channel
        gxRequest.setChannelName(channelName);
        gxRequest.setVisibleToOrgIds(Collections.singletonList(gxRequest.getCreatedBy()));
        gxRequest.setVisibleToChannelUsernames(this.gxUtil.getVisibleToChannelUsernames(gxRequest));
        try {
        	
            this.gxRequestRepository.getItem(gxRequest.getId());
            this.gxRequestRepository.updateItem(gxRequest);
        
        } catch (DataNotFoundException e) {
            this.gxRequestRepository.addItem(gxRequest);
        }
        // END TODO

        try {
        	
            GxRequest result = this.gxChain.startTransfer(channelName, gxRequest);
            this.gxUtil.hackySynchroniseOffChainOnchainRequest(result.getId());
            return result;
        
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }


    private GxAction actionApprove(GxAction action) throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        
    	String channelName = this.gxRequestChannelResolver.get(action.getGxRequestId());
        LOGGER.debug(BgxLogMarkers.DEV, "Approving action {} for request {} in channel {}", action.getId(), action.getGxRequestId(), channelName);
        String flowId = action.getGxRequestId();

        GxActionApprovePayload approvePayload = MAPPER.convertValue(action.getPayload(), GxActionApprovePayload.class);

        // NOTE currently assumes issuerId is only set for approving a beneficiary initiated issuing
        if (channelName == null && approvePayload.getIssuer() != null) {
            try {
                GxRequest gxRequest = this.gxRequestRepository.getItem(flowId);
                GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);

                if (!issuePayload.getApplicants().contains(this.getPrincipal().getConfiguredForOrgId())) {
                    throw new GuaranteeForbiddenException("Organization does not have access rights to perform this request");

                }

                issuePayload.setIssuer(approvePayload.getIssuer());
                gxRequest.setPayload(issuePayload);

                // TODO remove once we synchronise with service api
                // Upsert GxRequest in order to link to channel
                gxRequest.setChannelName(this.gxUtil.getChannelNameFromIssuerId(approvePayload.getIssuer()));
                gxRequest.setVisibleToOrgIds(Collections.singletonList(gxRequest.getCreatedBy()));
                gxRequest.setVisibleToChannelUsernames(this.gxUtil.getVisibleToChannelUsernames(gxRequest));
                this.gxRequestRepository.updateItem(gxRequest);
                // END TODO

                // Submit request onchain as beneficiary
                Organization benOrg = this.organizationManager.getById(gxRequest.getCreatedBy());
                ImpersonatedOrgPrincipal benPrincipal = new ImpersonatedOrgPrincipal(benOrg, this.applicationContext);

                benPrincipal.getGxManager().submitRequest(gxRequest);

                channelName = this.gxUtil.getChannelNameFromIssuerId(approvePayload.getIssuer());
            } catch (Exception e) {
                throw new GuaranteeException(e.getMessage(), e);
            }
        }

        try {
        
        	GxAction result = this.gxChain.actionApprove(channelName, action);
            this.gxUtil.hackySynchroniseOffChainOnchainRequest(action.getGxRequestId());
            LOGGER.debug("Finish actionApprove chaincode call with result (gxRequestId): {}", result.getGxRequestId());
            return result;
        
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 410:
                    throw new GuaranteePreconditionFailsException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxAction actionCancel(GxAction action)throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        
    	String channelName = this.gxRequestChannelResolver.get(action.getGxRequestId());

        // Check if GxRequest belongs to channel
        if (channelName != null) {
            try {
            	
                GxAction result = this.gxChain.actionCancel(channelName, action);
                this.gxUtil.hackySynchroniseOffChainOnchainRequest(action.getGxRequestId());
                return result;
            
            } catch (GuaranteeChainException e) {
                switch (e.getFabricMessage().getChaincodeStatusCode()) {
                    case 403:
                        throw new GuaranteeForbiddenException(e);
                    case 410:
                        throw new GuaranteePreconditionFailsException(e);
                    default:
                        throw new GuaranteeException(e);
                }

            } catch (ParseException | InterruptedException e) {
                throw new GuaranteeException(e);
            }
        }

        // Handle off-chain requests
        GxRequest gxRequest = this.gxRequestRepository.getItem(action.getGxRequestId());

        // off-chain requests only currently supported for issuing
        if (!gxRequest.getType().equals(GxRequestType.ISSUE)) {
            throw new GuaranteeException("This operation is not supported");
        }

        if (!gxRequest.getCreatedBy().equals(getPrincipal().getConfiguredForOrgId())) {
            throw new GuaranteeForbiddenException("Organization does not have permissions to perform this request");
        }

        this.notificationManager.markActionsDone(gxRequest.getId());

        gxRequest.setStatus(FlowStatus.CANCELLED);
        List<GxAction> actions = gxRequest.getOffchainActions();
        action.setId(UUID.randomUUID().toString());
        action.setScope(ActionScopeType.EXTERNAL);
        action.setType(GxActionType.CANCEL);
        action.setCreatedAt(Instant.now());
        action.setCreatedBy(getPrincipal().getConfiguredForOrgId());
        actions.add(action);
        gxRequest.setOffchainActions(actions);
        this.gxRequestRepository.updateItem(gxRequest);

        return action;
    }

    private GxAction actionRevoke(GxAction action) throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        
    	String channelName = this.gxRequestChannelResolver.get(action.getGxRequestId());
        try {
        	
            GxAction result = this.gxChain.actionRevoke(channelName, action);
            this.gxUtil.hackySynchroniseOffChainOnchainRequest(action.getGxRequestId());
            return result;
        
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 410:
                    throw new GuaranteePreconditionFailsException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    private GxAction actionReject(GxAction action) throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        
    	String channelName = this.gxRequestChannelResolver.get(action.getGxRequestId());
        List<GxAction> existingActions = this.getFlowActions(action.getGxRequestId());
        LOGGER.debug(BgxLogMarkers.DEV, "Executing Action: REJECT on request {}", action.getGxRequestId());
        // Check if GxRequest belongs to channel
        if (channelName != null && !isOffchainOnly(existingActions)) {
            try {
                
            	GxAction result = this.gxChain.actionReject(channelName, action);
                this.gxUtil.hackySynchroniseOffChainOnchainRequest(action.getGxRequestId());
                return result;
                
            } catch (GuaranteeChainException e) {
                switch (e.getFabricMessage().getChaincodeStatusCode()) {
                    case 403:
                        throw new GuaranteeForbiddenException(e);
                    case 410:
                        throw new GuaranteePreconditionFailsException(e);
                    default:
                        throw new GuaranteeException(e);
                }

            } catch (ParseException | InterruptedException e) {
                throw new GuaranteeException(e);
            }
        }

        // Handle off-chain requests
        GxRequest gxRequest = this.gxRequestRepository.getItem(action.getGxRequestId());
        
        boolean isPrefill = existingActions.size() > 0 && 
        					existingActions.get(0).getType().equals(GxActionType.PREFILL);

        // Check if is responding to ben init issue or prefill
        if (!gxRequest.getType().equals(GxRequestType.ISSUE) && !isPrefill) {
            throw new GuaranteeException("Operation unsupported");
        }

        Gx gx;
        if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
            GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
            gx = issuePayload;
        } else {
            try {
                gx = get(gxRequest.getGuaranteeId());
            } catch (GuaranteeNotFoundException e) {
                throw new GuaranteePreconditionFailsException(e);
            }
        }

        // Currently only two requests that reach this state are prefills + beneficiary initiated
        // In both cases only the applicant has the rights to reject
        if (!gx.getApplicants().contains(getPrincipal().getConfiguredForOrgId())) {
            throw new GuaranteeForbiddenException("Organization does not have permissions access rights to perform this request");
        }

        gxRequest.setStatus(FlowStatus.REJECTED);
        List<GxAction> offchainActions = gxRequest.getOffchainActions();
        action.setId(UUID.randomUUID().toString());
        action.setScope(ActionScopeType.EXTERNAL);
        action.setType(GxActionType.REJECT);
        action.setCreatedAt(Instant.now());
        action.setCreatedBy(getPrincipal().getConfiguredForOrgId());
        offchainActions.add(action);
        gxRequest.setOffchainActions(offchainActions);
        this.gxRequestRepository.updateItem(gxRequest);

        if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
            // check if this is an issue request created by the beneficiary and rejected by the applicant
            if (gx.getBeneficiaries().contains(gxRequest.getCreatedBy())) {
                // send notification to bene that the applicant has rejected the request
                WebNotification notification = new WebNotification();
                notification.setMessageType(MessageType.WITHDRAW_GX_ISSUE);
                notification.setReferenceType(ReferenceType.GX_REQUEST);
                notification.setReferenceId(gxRequest.getId());
                this.notificationManager.populateGxIssueData(notification, gxRequest, false);
                try {
                    for (String beneOrgId : gx.getBeneficiaries()) {
                        this.queueClient.addWebNotification(notification, beneOrgId);
                    }
                } catch (IOException ioe) {
                    LOGGER.error("Failed to send web notification for rejection of beneficiary-initiated guarantee request", ioe);
                }

                for (String applicantOrgId : gx.getApplicants()) {
                    notificationManager.markActionsDone(applicantOrgId, gxRequest.getId());
                }
            }
        }

        if (isPrefill) {
            try {
            
            	this.gxPrefillClient.sendOffchainGxActionNotification(GxUtil.getIssuerIdFromChannelName(channelName), action);
           
            } catch (Exception e) {
                throw new GuaranteeException("Failed to alert issuer to prefill action", e);
            }
        }
        return action;
    }

    private GxAction actionDefer(GxAction action) throws GuaranteeException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        
    	String channelName = this.gxRequestChannelResolver.get(action.getGxRequestId());
        try {
        
        	GxAction result = this.gxChain.actionDefer(channelName, action);
            this.gxUtil.hackySynchroniseOffChainOnchainRequest(action.getGxRequestId());
            return result;
        
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 410:
                    throw new GuaranteePreconditionFailsException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException | InterruptedException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public GxSearchResponse search(GxSearchRequest searchRequest) throws GuaranteeException, GuaranteeForbiddenException {
    	
        LOGGER.debug(BgxLogMarkers.DEV, "Retrieving all Gx.");

        if (gxChain == null) {
            throw new IllegalStateException("GxChain is null and hasn't been initialized.");
        }

        if (searchRequest.getIssuerId() == null) {
            throw new IllegalArgumentException("IssuerId is required for Gx search");
        }

        String channelName = this.gxUtil.getChannelNameFromIssuerId(searchRequest.getIssuerId());

        try {
            GxSearchResponse gxSearchResponse = this.gxChain.search(channelName, searchRequest);
            // Add active requests bitmask
            this.gxUtil.addActiveRequestBitmaskToGxList(gxSearchResponse.getGxs(), getPrincipal());

            return gxSearchResponse;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException e) {
            throw new GuaranteeException(e);
        }
    }

    @Override
    public Gx get(String guaranteeId)
        throws GuaranteeException, GuaranteeForbiddenException, GuaranteeNotFoundException {

        if (this.gxChannelResolver == null) {
            throw new IllegalStateException("Channel resolver is not initialized");
        }

        String channelName = this.gxChannelResolver.get(guaranteeId);

        LOGGER.debug(BgxLogMarkers.DEV, 
        			 "Getting Gx {} from {} using principal {} for org {}",
        			 guaranteeId, 
        			 channelName, 
        			 this.getPrincipal().getEmail(),
        			 this.getPrincipal().getConfiguredForOrgId());

        if (channelName == null) {
            throw new GuaranteeNotFoundException("Invalid ID, could not associate with channel");
        }

        try {
            Gx gx = this.gxChain.get(channelName, guaranteeId);

            GxActiveRequestsBitmaskWrapper bitmaskWrapper = this.gxRequestRepository.findActiveRequestsMask(getPrincipal().getConfiguredForOrgId(), guaranteeId);
            if (bitmaskWrapper == null) {
                gx.setActiveRequests(0);
            } else {
                gx.setActiveRequests(bitmaskWrapper.getMask());
            }

            return gx;
        } catch (GuaranteeChainException e) {
            switch (e.getFabricMessage().getChaincodeStatusCode()) {
                case 403:
                    throw new GuaranteeForbiddenException(e);
                case 404:
                    throw new GuaranteeNotFoundException(e);
                default:
                    throw new GuaranteeException(e);
            }

        } catch (ParseException e) {
            throw new GuaranteeException(e);
        }

    }

    @Override
    public GxFlowsSearchResponse searchFlows(GxFlowsSearchRequest flowsSearchRequest) {
        LOGGER.debug(BgxLogMarkers.DEV, "Searching Gx requests.");

        PaginatedResponse<GxRequest> flows = this.gxRequestRepository.find(getPrincipal(), flowsSearchRequest);
        // Filter fields from gxRequest
        flows.setResult(
            flows.getResult()
            	 .stream()
                 .map(e -> this.gxUtil.filterGxRequest(getPrincipal(), e))
                 .collect(Collectors.toList())
        );

        GxFlowsSearchResponse resp = new GxFlowsSearchResponse();
        resp.setFlows(flows.getResult());
        resp.setNext(flows.getNext());

        return resp;
    }

    @Override
    public GxRequest getFlow(String flowId)
        throws GuaranteeException, GuaranteeForbiddenException, GuaranteeNotFoundException {

        if (this.gxRequestChannelResolver == null) {
            throw new IllegalStateException("Channel resolver is not initialized");
        }

        GxRequest gxRequest = null;

        try {
            LOGGER.debug(BgxLogMarkers.DEV, String.format("Attempting to read gx flow %s from offchain", flowId));
            gxRequest = this.gxRequestRepository.getItem(flowId);

            // Validate that applicant/beneficiary is part of Gx has sufficient read priviledges
            validateOffchainGxRequestOrgAccess(gxRequest);
        } catch (DataNotFoundException e) {
            // Couldn't find in cache
            // do nothing
        }

        // read onchain
        if (gxRequest == null) {
            String channelName = this.gxRequestChannelResolver.get(flowId);
            if (channelName == null) {
                throw new GuaranteeNotFoundException("Could not retrieve request from offchain or isolate it to channel");
            }

            try {
               
            	LOGGER.debug(BgxLogMarkers.DEV, String.format("Attempting to read gx flow %s from onchain", flowId));
                gxRequest = this.gxChain.getFlow(channelName, flowId);
                
            } catch (GuaranteeChainException e) {
                switch (e.getFabricMessage().getChaincodeStatusCode()) {
                    case 404:
                        throw new GuaranteeNotFoundException(String.format("Failed to read gx flow %s from onchain", flowId), e);
                    default:
                        throw new GuaranteeException(e);
                }
            } catch (ParseException e) {
                throw new GuaranteeException(e);
            }
        }


        // Filter fields from gxRequest
        gxRequest = this.gxUtil.filterGxRequest(getPrincipal(), gxRequest);

        return gxRequest;
    }

    @Override
    public List<GxAction> getFlowActions(String flowId) throws GuaranteeException, GuaranteeForbiddenException, GuaranteePreconditionFailsException {
        
    	if (this.gxRequestChannelResolver == null) {
            throw new IllegalStateException("Channel resolver is not initialized");
        }

        String channelName = this.gxRequestChannelResolver.get(flowId);

        GxRequest gxRequest = null;
        List<GxAction> gxActions = null;

        GxRequest offchainRequest = null;
        boolean offchainOnly = false;

        // Check if GxRequest belongs to channel
        // HACK
        if (channelName != null) {

            // Don't search the ledger if the record is offchain-only

            try {
                gxRequest = this.gxRequestRepository.getItem(flowId);
                if (gxRequest.getOffchainOnly() != null) {
                    offchainOnly = gxRequest.getOffchainOnly();
                }
            } catch (DataNotFoundException e) {
                throw new GuaranteePreconditionFailsException(e);
            }

            if (!offchainOnly) {
                try {
                    gxRequest = this.gxChain.getFlow(channelName, flowId);
                } catch (GuaranteeChainException e) {
                    switch (e.getFabricMessage().getChaincodeStatusCode()) {
                        case 403:
                            throw new GuaranteeForbiddenException(e);
                        case 404:
                            // Do nothing as will check offchain
                            break;
                        default:
                            throw new GuaranteeException(e);
                    }
                } catch (ParseException e) {
                    LOGGER.debug(BgxLogMarkers.DEV, "Error parsing fabric message {}", e.getMessage());
                }

                if (gxRequest != null) {
                    try {
                        gxActions = this.gxChain.getFlowActions(channelName, flowId);
                    } catch (GuaranteeChainException e) {
                        switch (e.getFabricMessage().getChaincodeStatusCode()) {
                            case 403:
                                throw new GuaranteeForbiddenException(e);
                            case 410:
                                throw new GuaranteePreconditionFailsException(e);
                            default:
                                throw new GuaranteeException(e);
                        }
                    } catch (ParseException e) {
                        LOGGER.debug(BgxLogMarkers.DEV, "There's something happening here {}", e.getMessage());
                    }
                }
            }
        }
        if (gxRequest == null) {
            // Handle purely off-chain requests
            try {
                gxRequest = this.gxRequestRepository.getItem(flowId);
                validateOffchainGxRequestOrgAccess(gxRequest);
                gxActions = gxRequest.getOffchainActions();
                for (GxAction action : gxActions) {
                    action.setScope(ActionScopeType.EXTERNAL);
                }
            } catch (DataNotFoundException e) {
                throw new GuaranteePreconditionFailsException(e);
            }
        }
        if (gxActions == null) {
            gxActions = new ArrayList<>();
        }
        // END HACK


        List<ApprovalModelFlowRequest> approvalModelFlowRequests;
        ApprovalModel approvalModel = null;
        try {
           approvalModel = this.getPrincipal().getApprovalModel();
        } catch (IllegalArgumentException e) {
            // approval model isn't set
        }
        // get approval model requests
        if (approvalModel == null) {
            // approval model isn't set
           approvalModelFlowRequests = new ArrayList<>();
        } else {
           approvalModelFlowRequests =  approvalModel.getApprovalFlows(flowId, null, null);
        }

        List<GxPrefillRequest> prefillRequests = this.getPrincipal().getGxPrefillRequestManager().find(flowId);
        
        if (!prefillRequests.isEmpty()) {
            gxActions.add(this.gxActionRequestConverter.from(prefillRequests.get(0)));
        }
        for (ApprovalModelFlowRequest approvalModelFlowRequest : approvalModelFlowRequests) {
            gxActions.addAll(this.gxActionRequestConverter.fromChildren(approvalModelFlowRequest));
        }

        // TODO remove log
        LOGGER.debug(BgxLogMarkers.DEV, "gxActions {}", gxActions);
        gxActions.sort(Comparator.comparing(GxAction::getCreatedAt));

        boolean checkWithdrawnActions = false;
        if (!gxRequest.getStatus().equals(FlowStatus.APPROVED)) {
            if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
                GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
                Gx gx = issuePayload;

                if (gx.getBeneficiaries().contains(getPrincipal().getConfiguredForOrgId())) {
                    checkWithdrawnActions = true;
                }
            } else if (gxRequest.getType().equals(GxRequestType.AMEND)) {
                try {
                    Gx gx = this.gxChain.get(channelName, gxRequest.getGuaranteeId());

                    if (gx.getBeneficiaries().contains(getPrincipal().getConfiguredForOrgId())) {
                        checkWithdrawnActions = true;
                    }
                } catch (GuaranteeChainException e) {
                    throw new GuaranteeException(e);
                } catch (ParseException e) {
                    throw new GuaranteeException(e);
                }
            }
        }

        if (checkWithdrawnActions) {
            gxActions = gxActions.stream().filter(a -> a.getCreatedBy().equals(getPrincipal().getConfiguredForOrgId()) ||
                !(a.getType().equals(GxActionType.APPROVE) || a.getType().equals(GxActionType.REVOKE)))
                .collect(Collectors.toList());

            for (GxAction gxActionRequest : gxActions) {
                if ((gxActionRequest.getType().equals(GxActionType.CANCEL) || gxActionRequest
                    .getType().equals(GxActionType.REJECT))
                    && !gxActionRequest.getCreatedBy()
                    .equals(getPrincipal().getConfiguredForOrgId())
                ) {
                    gxActionRequest.setType(GxActionType.WITHDRAW);
                    gxActionRequest.setCreatedBy(null);
                    // Remove reason
                    if (gxActionRequest.getPayload() != null) {
                        GxActionDefaultPayload defaultPayload = MAPPER.convertValue(gxActionRequest.getPayload(), GxActionDefaultPayload.class);
                        defaultPayload.setReason(null);
                        gxActionRequest.setPayload(defaultPayload);
                    }
                }
            }
        }

        return gxActions;
    }

    @Override
    public GxAction getFlowAction(String flowId, String actionId)
        throws GuaranteeException, GuaranteeNotFoundException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
    	
    	if (flowId == null) {
    		throw new IllegalArgumentException("Request identifier cannot be null.");
    	}
    	
    	if (actionId == null) {
    		throw new IllegalArgumentException("Action identifier cannot be null.");
    	}
    	
        List<GxAction> actions = this.getFlowActions(flowId);
        for (GxAction action : actions) {
            if (action.getId().equals(actionId)) {
                return action;
            }
        }
        throw new GuaranteeNotFoundException(
            String.format("Could not find action with Id %s", actionId));
    }

    /**
     * Determines whether the given user has beneficiary access to the given GxIssue request.
     *
     * @param issue - the GX issuing request payload
     * @return true if the current user is part of the beneficiary org of this issue request.
     */
    protected boolean actsAsBeneficiary(GxIssuePayload issue) {
        if (issue.getBeneficiaries().contains(getPrincipal().getConfiguredForOrgId())) {
            // we're primary member of beneficiary org
            return true;
        }

        // TODO: in theory, the getPrincipal().getUserProfile().getRoles() should contain all orgs the user has access to, but doesn't seem to be the case. Below is a workaround
        for (String orgId : issue.getBeneficiaries()) {
            try {
                Organization org = this.organizationManager.getById(orgId);
                for (RelationshipInfo rel : org.getSettings().getRelationships()) {
                    if (rel.getId().equals(getPrincipal().getConfiguredForOrgId()) && rel.getRelationship().equals(RelationshipInfo.Relationship.SUBSIDIARY_OF)) {
                        return true;
                    }
                }
            } catch (Exception e) {
                // skip this entry
                LOGGER.warn(String.format("Could not find organisation with org ID '%s'", orgId), e);
            }
        }

        return false;
    }


    /**
     * Checks if a list of actions contains only offchain actions
     */
    private boolean isOffchainOnly(List<GxAction> actions) {
    	
        for (GxAction action : actions) {
            if (action.getScope().equals(ActionScopeType.EXTERNAL) && !action.getType().equals(GxActionType.PREFILL)) {
                return false;
            }
        }
        return true;
    }


    private void validateOffchainGxRequestOrgAccess(GxRequest gxRequest) {
    	
        if (!getPrincipal().isActingOnBehalf()) {
        	
            if (!gxRequest.getVisibleToOrgIds().contains(getPrincipal().getConfiguredForOrgId())) {
            	
                throw new GuaranteeForbiddenException("Organization does not have access to guarantee request");
            }
        } else if (!gxRequest.getVisibleToChannelUsernames().contains(getPrincipal().getChannelUserName())) {
        	
            throw new GuaranteeForbiddenException("Organization does not have access to guarantee request");
        }
    }

}
