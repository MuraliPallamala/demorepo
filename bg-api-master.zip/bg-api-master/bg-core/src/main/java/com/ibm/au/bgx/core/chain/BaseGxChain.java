package com.ibm.au.bgx.core.chain;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.core.chain.adapter.gx.GxDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.gx.GxFlowActionDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.gx.GxFlowsSearchRequestDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.gx.GxSearchRequestDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.gx.GxStartRequestDataAdapter;
import com.ibm.au.bgx.core.util.GxUtil;
import com.ibm.au.bgx.fabric.model.FabricMessage;
import com.ibm.au.bgx.model.exception.GuaranteeChainException;
import com.ibm.au.bgx.model.guarantee.GXAPI;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchResponse;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.gx.GxSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchResponse;
import com.ibm.au.bgx.model.shared.Common;
import com.ibm.au.bgx.model.shared.Flow;
import java.text.ParseException;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This implements methods to persist and retrieve records from chain
 *
 * @author Dain LIffman <dainliff@au1.ibm.com>
 */
@Component
public class BaseGxChain {

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseGxChain.class);

    @Autowired
    GxDataAdapter gxDataAdapter;

    @Autowired
    GxStartRequestDataAdapter gxStartRequestDataAdapter;

    @Autowired
    GxFlowActionDataAdapter gxFlowActionDataAdapter;

    @Autowired
    GxSearchRequestDataAdapter gxSearchRequestDataAdapter;

    @Autowired
    GxFlowsSearchRequestDataAdapter gxFlowsSearchRequestDataAdapter;

    public BaseGxChain() {
    }

    private GxRequest submitRequest(GXAPI gxApi, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        try {
            return gxStartRequestDataAdapter.toOffchainModel(
                gxApi.StartFlow(gxStartRequestDataAdapter.toOnChainModel(gxRequest))
            );
        } catch (Exception e) {
            LOGGER.error("Error submitting GxRequest", e);
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }


    public GxRequest startIssue(GXAPI gxApi, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return submitRequest(gxApi, gxRequest);
    }

    public GxRequest startAmend(GXAPI gxApi, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return submitRequest(gxApi, gxRequest);
    }

    public GxRequest startCancel(GXAPI gxApi, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return submitRequest(gxApi, gxRequest);
    }

    public GxRequest startDemand(GXAPI gxApi, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return submitRequest(gxApi, gxRequest);
    }

    public GxRequest startPayWalk(GXAPI gxApi, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return submitRequest(gxApi, gxRequest);
    }

    public GxRequest startTransfer(GXAPI gxApi, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return submitRequest(gxApi, gxRequest);
    }

    public GxRequest expire(GXAPI gxApi, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return submitRequest(gxApi, gxRequest);
    }

    public GxAction actionApprove(GXAPI gxApi, GxAction action)
        throws GuaranteeChainException, ParseException {
        try {
            return gxFlowActionDataAdapter.toOffchainModel(
                Gxs.GXFlowActionRequest.newBuilder().setFlowActionRequest(
                    gxApi.ApproveFlow(
                        gxFlowActionDataAdapter.toOnChainModel(action).getFlowActionRequest())
                ).build()
            );
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

    public GxAction actionCancel(GXAPI gxApi, GxAction action)
        throws GuaranteeChainException, ParseException {
        try {
            return gxFlowActionDataAdapter.toOffchainModel(
                Gxs.GXFlowActionRequest.newBuilder().setFlowActionRequest(
                    gxApi.CancelFlow(
                        gxFlowActionDataAdapter.toOnChainModel(action).getFlowActionRequest())
                ).build()
            );
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

    public GxAction actionRevoke(GXAPI gxApi, GxAction action)
        throws GuaranteeChainException, ParseException {
        try {
            return gxFlowActionDataAdapter.toOffchainModel(
                Gxs.GXFlowActionRequest.newBuilder().setFlowActionRequest(
                    gxApi.RevokeAction(
                        gxFlowActionDataAdapter.toOnChainModel(action).getFlowActionRequest())
                ).build()
            );
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

    public GxAction actionReject(GXAPI gxApi, GxAction action)
        throws GuaranteeChainException, ParseException {
        try {
            return gxFlowActionDataAdapter.toOffchainModel(
                Gxs.GXFlowActionRequest.newBuilder().setFlowActionRequest(
                    gxApi.RejectFlow(
                        gxFlowActionDataAdapter.toOnChainModel(action).getFlowActionRequest())
                ).build()
            );
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

    public GxAction actionDefer(GXAPI gxApi, GxAction action)
        throws GuaranteeChainException, ParseException {
        try {
            return gxFlowActionDataAdapter.toOffchainModel(
                Gxs.GXFlowActionRequest.newBuilder().setFlowActionRequest(
                    gxApi.DeferFlow(
                        gxFlowActionDataAdapter.toOnChainModel(action).getFlowActionRequest())
                ).build()
            );
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

    private GxAction submitRecall(GXAPI gxApi, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        Gxs.GXRecallRequest recallRequest = Gxs.GXRecallRequest.newBuilder()
            .setFlowId(flowId)
            .setUpdatedRequest(gxStartRequestDataAdapter.toOnChainModel(gxRequest))
            .build();
        try {
            return gxFlowActionDataAdapter.toOffchainModel(
                Gxs.GXFlowActionRequest.newBuilder()
                    .setRecallRequest(gxApi.RecallFlow(recallRequest)).build()
            );
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }

    }

    public GxAction actionRecallIssue(GXAPI gxApi, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return submitRecall(gxApi, flowId, gxRequest);

    }

    public GxAction actionRecallAmend(GXAPI gxApi, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return submitRecall(gxApi, flowId, gxRequest);
    }

    public GxAction actionRecallCancel(GXAPI gxApi, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return submitRecall(gxApi, flowId, gxRequest);
    }

    public GxAction actionRecallDemand(GXAPI gxApi, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return submitRecall(gxApi, flowId, gxRequest);
    }

    public GxAction actionRecallTransfer(GXAPI gxApi, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return submitRecall(gxApi, flowId, gxRequest);
    }

    public GxSearchResponse search(GXAPI gxApi, GxSearchRequest searchRequest)
        throws GuaranteeChainException, ParseException {
        try {
            Gxs.GXSearchResponse resp = gxApi
                .Search(gxSearchRequestDataAdapter.toOnChainModel(searchRequest));
            List<Gx> gxs = resp.getGxsList().stream()
                .map(e -> gxDataAdapter.toOffchainModel(e))
                .collect(Collectors.toList());

            GxSearchResponse searchResponse = new GxSearchResponse();
            searchResponse.setGxs(gxs);
            searchResponse.setNext(resp.getNext());
            return searchResponse;
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

    public Gx get(GXAPI gxApi, String guaranteeId)
        throws GuaranteeChainException, ParseException {
        try {
            Common.IDValue idValue = Common.IDValue.newBuilder().setValue(guaranteeId).build();
            Gxs.GX resp = gxApi.Get(idValue);
            Gx gx = gxDataAdapter.toOffchainModel(resp);
            return gx;
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

    public GxFlowsSearchResponse searchFlows(GXAPI gxApi, GxFlowsSearchRequest flowsSearchRequest)
        throws GuaranteeChainException, ParseException {
        try {
            Gxs.GXFlowSearchRequest searchRequest = gxFlowsSearchRequestDataAdapter
                .toOnChainModel(flowsSearchRequest);

            Gxs.GXFlowSearchResponse resp = gxApi.SearchFlows(searchRequest);
            List<GxRequest> flows = resp.getFlowsList().stream()
                .map(e -> gxStartRequestDataAdapter.toOffchainModel(e))
                .collect(Collectors.toList());

            GxFlowsSearchResponse searchResponse = new GxFlowsSearchResponse();
            searchResponse.setFlows(flows);
            searchResponse.setNext(resp.getNext());
            return searchResponse;
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

    public GxRequest getFlow(GXAPI gxApi, String flowId)
        throws GuaranteeChainException, ParseException {
        try {
            Flow.FlowIDValue flowIDValue = Flow.FlowIDValue.newBuilder().setValue(flowId).build();
            Gxs.GXStartRequest pbFlow = gxApi.GetFlow(flowIDValue);
            GxRequest flow = gxStartRequestDataAdapter.toOffchainModel(pbFlow);
            if (flow.getType().equals(GxRequestType.ISSUE)) {
                GxIssuePayload gxIssuePayload = (GxIssuePayload) flow.getPayload();
                gxIssuePayload.setIssuer(GxUtil.getIssuerIdFromChannelName(gxApi.getChannel().getName()));
                flow.setPayload(gxIssuePayload);
            }
            return flow;
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

    public List<GxAction> getFlowActions(GXAPI gxApi, String flowId)
        throws GuaranteeChainException, ParseException {
        try {
            Flow.FlowIDValue flowIDValue = Flow.FlowIDValue.newBuilder().setValue(flowId).build();
            List<Gxs.GXFlowActionRequest> resp = gxApi.GetFlowActions(flowIDValue)
                .getRequestsList();
            return resp.stream()
                .map(e -> gxFlowActionDataAdapter.toOffchainModel(e))
                .collect(Collectors.toList());
        } catch (Exception e) {
            FabricMessage message = FabricMessage.parse(e.getMessage());
            throw new GuaranteeChainException(message);
        }
    }

}
