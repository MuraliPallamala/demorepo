package com.ibm.au.bgx.common;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.au.bgx.model.api.SystemStatusResource;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;

import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author Peter Ilfrich
 */
@Tag(name="Internal Operations", description="Support capabilities internally used by the platform to operate or to support development.")
@RestController
public class BgxStatusResource implements SystemStatusResource {

    private Logger LOGGER = LoggerFactory.getLogger(BgxStatusResource.class);

    private boolean ready = false;
    private boolean live = false;

    private Map<String, Boolean> readyMap = new HashMap<>();

    @Value("${bgx.startupComponentCount}")
    private int numberOfStartupComponents;

    @EventListener(ApplicationReadyEvent.class)
    public void applicationReadyHook() {
        LOGGER.debug(BgxLogMarkers.DEV, "Setting application status to 'live'");
        this.setLive(true);
    }

    @GetMapping("/_status/ready")
    public ResponseEntity<Void> getReadyState() {
        if (this.isReady()) {
            return new ResponseEntity<>(HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
    }

    @GetMapping("/_status/live")
    public ResponseEntity<?> getLiveState() {
        if (this.isLive()) {
            return new ResponseEntity<>(HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
    }


    @Override
    public boolean isReady() {
        return live && ready;
    }

    @Override
    public void registerComponent(String componentIdentifier) {
        if (readyMap.containsKey(componentIdentifier)) {
            // Note this occurs when you have multiple components using the same database
            // TODO: currently, if CouchDB fails to connect, it seems to start the @PostConstruct again, we might let it have it's 2nd attempt.
            LOGGER.warn(
                    String.format("Attempting to register component '%s' more than once", componentIdentifier));
            // throw new RuntimeException(String.format("Attempting to register component '%s' more than once", componentIdentifier));
        } else {
            // too many components, increment the bgx.startupComponentCount configuration
            if (readyMap.size() + 1 > numberOfStartupComponents) {
                throw new RuntimeException(
                    String.format(
                        "Attempting to register another component, but already reached max '%d'.", numberOfStartupComponents));
            }

            LOGGER.debug(String.format("Creating registration for %s (%d / %d)", componentIdentifier,
                    readyMap.size() + 1, numberOfStartupComponents));

            readyMap.put(componentIdentifier, false);
            ready = false;

        }

    }

    @Override
    public void setComponentReady(String componentIdentifier) {
        if (!readyMap.containsKey(componentIdentifier)) {
            throw new RuntimeException(String.format(
                "Attempting to set component '%s' ready, even though it was never declared.",
                componentIdentifier));
        }

        LOGGER.debug(String
            .format("Finishing registration for %s (%d / %d)", componentIdentifier, readyMap.size(),
                numberOfStartupComponents));

        readyMap.put(componentIdentifier, true);

        // check all components
        boolean allValid = true;
        for (boolean value : readyMap.values()) {
            allValid = allValid && value;
        }

        // only if all are valid and we have all components started up
        if (!ready && allValid && readyMap.size() == numberOfStartupComponents) {
            LOGGER.debug(BgxLogMarkers.DEV, "Setting application status to 'ready'");
            ready = true;
        }
    }

    @Override
    public int getTotalReady() {

        int count = 0;
        for (boolean value : readyMap.values()) {
            if (value) {
                count++;
            }
        }

        return count;
    }

    @Override
    public boolean isLive() {
        return live;
    }

    @Override
    public void setLive(boolean live) {
        this.live = live;
    }
}
