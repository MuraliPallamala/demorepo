package com.ibm.au.bgx.core.chain.adapter.flow;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.chain.FlowStatus;
import com.ibm.au.bgx.model.shared.Flow;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class FlowStatusDataAdapter implements ChainDataAdapter<Flow.FlowStatus, FlowStatus> {

    @Override
    public Flow.FlowStatus toOnChainModel(FlowStatus input) {
        switch (input) {
            case ACTIVE:
                return Flow.FlowStatus.FLOW_ACTIVE;
            case CANCELLED:
                return Flow.FlowStatus.FLOW_CANCELLED;
            case REJECTED:
                return Flow.FlowStatus.FLOW_REJECTED;
            case WITHDRAWN:
                return Flow.FlowStatus.FLOW_WITHDRAWN;
            case APPROVED:
                return Flow.FlowStatus.FLOW_APPROVED;
            case EXPIRED:
                return Flow.FlowStatus.FLOW_EXPIRED;
        }
        throw new IllegalArgumentException("Unable to map FlowStatus to on chain model");
    }

    @Override
    public FlowStatus toOffchainModel(Flow.FlowStatus input) {
        switch (input) {
            case FLOW_ACTIVE:
                return FlowStatus.ACTIVE;
            case FLOW_CANCELLED:
                return FlowStatus.CANCELLED;
            case FLOW_REJECTED:
                return FlowStatus.REJECTED;
            case FLOW_WITHDRAWN:
                return FlowStatus.WITHDRAWN;
            case FLOW_APPROVED:
                return FlowStatus.APPROVED;
            case FLOW_EXPIRED:
                return FlowStatus.EXPIRED;
            default:
            	throw new IllegalArgumentException("Unable to map FlowStatus to off chain model");
        }
    }
}
