package com.ibm.au.bgx.core.util;

import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxActionType;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.util.List;

/**
 * Interface <b>GxValidator</b>. This interface provides methods for the
 * validation of operations and entities that are connected to bank guarantees.
 * In particular, it offers capabilities for validating bank guarantee requests,
 * and actions on bank guarantee requests to ensure that those actions are 
 * valid and allowed.
 *
 */
public interface GxValidator {
	
	/**
	 * <p>
	 * Validates the given bank guarantee request within the context of the given <i>principal</i> and associated bank guarantee if any.
	 * </p>
	 * <p>
	 * The validation of a bank guarantee request depends on the type of request.
	 * <ul>
	 * <li>
	 * for <i>issue</i> requests (i.e. {@link GxRequest#getType()} is {@link GxRequestType#ISSUE} the following conditions must be met: 
	 * <ul>
	 * <li>the list of applicants cannot be {@literal null} or empty, and it must contain at most one entry</li>
	 * <li>the list of beneficiaries cannot be {@literal null} or empty, and it must contain at most one entry</li>
	 * <li>the applicant and the beneficiary organisation must exist and be of type {@link EntityType#APPLICANT_OR_BENEFICIARY}</li>
	 * <li>the amount of the bank guarantee need to be a valid positive number</li>
	 * <li>the outstanding amount of the bank guarantee need to be a valid and positive number (and it should match the amount)</li>
	 * <li>the currency cannot be {@literal null}</li>
	 * <li>the terms and conditions must be present and match a terms and condition instance of scope {@link Scope#BANK_GUARANTEE}</li>
	 * <li>the purpose must be of a recognised type and valid (i.e. containing all the required fields with accepted values)</li>
	 * <li>the expiration date if set must be in the future</li>
	 * </ul>
	 * </li>
	 * <li>
	 * for <i>amendment</i> requests (i.e. {@link GxRequest#getType()} is {@link GxRequestType#AMEND}) the following conditions must be met: 
	 * <ul>
	 * <li>the payload of the request cannot be {@literal null} and must contain some of the attributes of the bank guarantee that are subject
	 * to amendment (there are: amount, expiration date, purpose)</li>
	 * <li>if specified the amount cannot be a negative number</li>
	 * <li>if specified the expiration date cannot be in the past</li>
	 * <li>if specified the purpose must be of the same type of the one of the original bank guarantee</li>
	 * <li>if specified the purpose must be valid in all its required fields</li>
	 * </ul>
	 * </li>
	 * <li>
	 * for <i>cancellation</i> requests (i.e. {@link GxRequest#getType()} is {@link GxRequestType#CANCEL}) the payload may contain an optional
	 * field <i>reason</i> that provides details about the cancellation request.
	 * </li>
	 * <li>
	 * for <i>demand</i> requests (i.e. {@link GxRequest#getType()} is {@link GxRequestType#TRANSFER} the following conditions must be met: 
	 * <ul>
	 * <li>the request may only be initiated by the beneficiary of the bank guarantee (extended to parent organisation if there is a parent-sub 
	 * relationship)</li>
	 * <li>the payload of the request must contain a non-{@literal null} and greater than zero amount, which cannot be bigger than the outstanding
	 * amount of the bank guarantee</li>
	 * </ul>
	 * </li>
	 * <li>
	 * for <i>transfer</i> requests (i.e. {@link GxRequest#getType()} is {@link GxRequestType#TRANSFER} the following conditions must be met:
	 * <ul>
	 * <li>there must be specified a beneficiary that is the prospective recipient of the bank guarantee</li>
	 * <li>there must be only one beneficiary specified</li>
	 * <li>the organisation identified as beneficiary must exist and be of type {@link EntityType#APPLICANT_OR_BENEFICIARY}</li>
	 * <li>the request can only be initiated by the applicant or the beneficiary involved in the bank guarantee (extended to parent organisation
	 * in case of a parent-subsidiary relationship)</li>
	 * <li>the prospective beneficiary cannot be the current applicant of the guarantee</li>
	 * </ul>
	 * </li>
	 * <li>
	 * for <i>expiration</i> requests (i.e. {@link GxRequest#getType()} is {@link GxRequestType#TRANSFER}) there is nothing to validate as the
	 * request does not have payload.
	 * </li>
	 * <li>
	 * for <i>pay and walk</i> requests (i.e. {@link GxRequest#getType()} is {@link GxRequestType#TRANSFER}) the the payload may contain an optional
	 * field <i>reason</i> that provides details about the reason of the payment and the request may only be initiated by the issuer of the bank
	 * guarantee.
	 * </li>
	 * </ul>
	 * </p>
	 * 
	 * 
	 * @param gxRequest		a {@link GxRequest} instance containing the details of the bank guarantee request to validate. It cannot be {@literal 
	 * 						null}. 
	 * 
	 * @param principal		a {@link BgxPrincipal} implementation that represents the identity that is currently bound to the execution context
	 * 						that it is currently submitting the request to the platform. It cannot be {@literal null} and it is expected to be
	 * 						one of the participants within the bank guarantee represented by <i>gxRequest</i>. Parent-subsidiary relationships
	 * 						must be taken into account when checking the inclusion of the principal in the bank guarantee.
	 * 
	 * @param gx			a {@link Gx} instance representing the underlying bank guarantee that <i>gxRequest</i> refers to. This can only be
	 * 						{@literal null} if the type of request for <i>gxRequest</i> is {@link GxRequestType#ISSUE}. In all other cases this
	 * 						argument must be the related guarantee to <i>gxRequest</i>. This means that {@link GxRequest#getGuaranteeId()} must
	 * 						match the value of {@link Gx#getId()}. 
	 * 
	 * @throws IllegalArgumentException			if one of the following occurs:
	 * 											<ul>
	 * 											<li><i>gxRequest</i> is {@literal null}</li>
	 * 											<li><i>principal</i> is {@literal null}</li>
	 * 											<li><i>gx</i> is {@literal null} and <i>gxRequest</i> is an issuance request</li>
	 * 											</ul>
	 * @throws GuaranteeForbiddenException		if there is any other validation error. This exception may include the original cause that 
	 * 											provides more information about the validation error and also an error code that provides
	 * 											an additional reference to the error.
	 */
	// [CV] TODO: remove IllegalArgumentException from the method signature and keep it only for null values.
	// [CV] TODO: replace GuaranteeForbiddenException with DataValidationException.
	// [CV] TODO: define more error codes to cover the validation of the bank guarantee requests.
    void validateGxRequest(GxRequest gxRequest, BgxPrincipal principal, Gx gx) throws IllegalArgumentException, GuaranteeForbiddenException;

    /**
     * <p>
     * Validates the given request action as submitted by <i>principal</i>, within the context provided by <i>gxRequest</i>, <i>gx</i> and <i>
     * externalActions</i>.
     * </p>
     * <p>
     * The validation of a request action includes the following checks common to all the actions:
     * <ul>
     * <li>the <i>principal</i> must be involved in the underlying bank guarantee request (and therefore bank guarantee if already existing)</li>
     * <li>the <i>gxRequest</i> must still be an active request</li>
     * <li>the <i>gx</i> (in case where the request is not an issuer request) must still be active (i.e. not expired, cancelled, or fully demanded)</li>
     * </ul>
     * Moreover, for each specific type of action, additional checks are required:
     * <ul>
     * <li>for <i>approve</i> actions (i.e. {@link GxAction#getType()} is equal to {@link GxActionType#APPROVE}) the following constraints must be observed:
     * <ul>
     * <li>the <i>principal</i> submitting the action cannot be the originator of the request</li>
     * <li>the <i>principal</i> cannot submit this action more than one time (implementations must check the history of the request for previous occurrences 
     * of the same action from the same <i>principal</i>)</li>
     * <li>if <i>principal</i> represents the issuer of the underlying bank guarantee, the action cannot be submitted until all the other parties
     * have cast their approval. The number of approvals required depends on the type of request:
     * <ul>
     * <li><i>cancel</i> request initiated by the beneficiary require no approval prior to the issuer casting its approval</li>
     * <li><i>demand</i> request initiated by the beneficiary required no approval prior to the issuer casting its approval</li>
     * <li><i>transfer</i> request require the approval of the applicant and the two beneficiary, prior to the issuer casting its approval</li>
     * <li>all the other request require one approvals (applicant or beneficiary, depending on who started the request) priors to the issuer casting
     * its approval</li>
     * </ul>
     * </li>
     * <li>if <i>principal</i> represents the applicant and the request was not started by the applicant, then the payload of the action must contain
     * a specification of the issuer (implementations must check that the specified organisation is an issuer)</li>
     * <li>the specification of the issuer if present in the approve action, cannot be different from the original specification of the issuer if any
     * (this prevents from changing issuers within APPROVE - REVOKE - APPROVE flows, in the same applicant organisation)</li> 
     * </ul>
     * </li>
     * <li>for <i>reject</i> actions (i.e. {@link GxAction#getType()} is equal to {@link GxActionType#REJECT}) the following constraints must be
     * observed:
     * <ul>
     * <li>if the reject action occurs within the context of a pre-fill flow, the <i>principal</i> must represent the applicant</li>
     * <li>the <i>principal</i> cannot cast a reject action if it is the originator of the request</li>
     * <li>reject actions are not allowed for demand request</li>
     * </ul>
     * </li>
     * <li>for <i>cancel</i> actions (i.e. {@link GxAction#getType()} is equal to {@link GxActionType#CANCEL}) only the creator of the request can
     * submit this type of action (implementation must check that <i>principal</i> is bound to the organisation that created the request (parent
     * subsidiary relationship must be taken into account)
     * </li>
     * <li>for <i>revoke</i> actions (i.e. {@link GxAction#getType()} is equal to {@link GxActionType#REVOKE}) the following conditions must be met:
     * <ul>
     * <li>the payload of the action must contain the identifier of the <i>action</i> that is being revoked, and this action must exist in the
     * history of the request (implementations must check the <i>externalActions</i> list)
     * </li>
     * <li>the principal can only revoke actions that were casted by its identity</li>
     * </ul>
     * <li>for <i>defer</i> actions (i.e. {@link GxAction#getType()} is equal to {@link GxActionType#DEFER}) the following conditions must be met:
     * <ul>
     * <li>the <i>gxRequest</i> must be of type {@link GxRequestType#DEMAND}</li>
     * <li>the <i>principal</i> casting the action must be the issuer involved in the bank guarantee, the demand request refers to</li>
     * <li>there should not be a previous defer action</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @param gxAction		a {@link GxAction} instance that represents the action submitted against the guarantee request <i>gxRequest</i> that
     * 						is object of validation. It cannot be {@literal null}.
     * 
	 * @param gxRequest		a {@link GxRequest} instance representing the underlying bank guarantee request that the action is submitted against.
	 * 						It cannot be {@literal null}.
	 * 
	 * @param principal		a {@link BgxPrincipal} implementation that represents the identity that is currently bound to the execution context
	 * 						that it is currently submitting the action to the platform. It cannot be {@literal null} and it is expected to be
	 * 						one of the participants within the bank guarantee represented by <i>gx</i>. Parent-subsidiary relationships must be 
	 * 						taken into account when checking the inclusion of the principal in the bank guarantee.
	 * 
	 * @param gx			a {@link Gx} instance representing the underlying bank guarantee that <i>gxRequest</i> refers to. This can only be
	 * 						{@literal null} if the type of request for <i>gxRequest</i> is {@link GxRequestType#ISSUE}. In all other cases this
	 * 						argument must be the related guarantee to <i>gxRequest</i>. This means that {@link GxRequest#getGuaranteeId()} must
	 * 						match the value of {@link Gx#getId()}. 
	 * 
     * @param externalActions	a {@link List} of {@link GxAction} instances that represent the actions that have occurred within the organisation
     * 							associated to the given <i>principal</i> that constitute the internal approval workflow leading to <i>gxAction</i>.
     * 							It cannot be {@literal null}.
     * 
	 * 
	 * @throws IllegalArgumentException			if one of the following occurs:
	 * 											<ul>
	 * 											<li><i>gxAction</i> is {@literal null}</li>
	 * 											<li><i>gxRequest</i> is {@literal null}</li>
	 * 											<li><i>principal</i> is {@literal null}</li>
	 * 											<li><i>gx</i> is {@literal null} and <i>gxRequest</i> is an issuance request</li>
	 * 											<li><i>externalActions</i> is {@literal null}</li>
	 * 											</ul>
	 * 
	 * @throws GuaranteeForbiddenException		if there is any other validation error. This exception may include the original cause that 
	 * 											provides more information about the validation error and also an error code that provides
	 * 											an additional reference to the error.
     */
	// [CV] TODO: remove IllegalArgumentException from the method signature and keep it only for null values.
	// [CV] TODO: replace GuaranteeForbiddenException with DataValidationException.
	// [CV] TODO: define more error codes to cover the validation of the bank guarantee requests actions.
    void validateGxAction(GxAction gxAction, 
    					  BgxPrincipal principal, 
    					  Gx gx, 
    					  GxRequest gxRequest,
    					  List<GxAction> externalActions) throws IllegalArgumentException, GuaranteeForbiddenException;
}