package com.ibm.au.bgx.core.chain.channel;

import com.ibm.au.bgx.model.chain.IbpConfigLoader;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

/**
 * Abstract class for IBP config loader
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public abstract class AbstractIbpConfigLoader implements IbpConfigLoader {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractIbpConfigLoader.class);

    /**
     * Path to channel to IBP config mapping properties file
     */
    @Value("${fabric.config.ibp.channel.mapping:../properties/ibp-channel-mapping.properties}")
    protected String configMappingPath;

    /**
     * A {@link Properties} instance that stores all the mappings of IBP config file paths for each
     * channel
     *
     * For example:
     *
     * platform:/opt/dlt/config/platform.json
     * anz:/opt/dlt/config/anz.json
     * nab:/opt/dlt/config/nab.json
     *
     *
     * Note we also support different channel name to be mapped to the same file if the peer is
     * connected to multiple channel
     *
     * platform:/opt/dlt/config/anz.json
     * anz:/opt/dlt/config/anz.json
     *
     *
     * For mock IBP we only need the URL suffix for the configuration as below:
     *
     * platform-channel=newco
     * anz-channel=newco // newco peer is connected to anz channel
     *
     * But otherwise, we need path (relative or absolute) to the configuration file as
     * below.:
     *
     * platform-channel=../properties/newco-ibp-config.json
     * anz-channel=/opt/dlt/data/conf/ibp/anz-ibp-config.json
     * nab-channel=src/main/resources/nab-ibp-config.json
     */
    protected Properties configMappings;

    /**
     * Load channel to IBP config file mapping
     */
    public void loadMappings() {

        LOGGER.debug(BgxLogMarkers.DEV, "Loading IBP config mappings from : {}", configMappingPath);
        this.configMappings = new Properties();

        InputStream mapping = null;

        try {

            mapping = new FileInputStream(configMappingPath);

            if (mapping != null) {
                this.configMappings.load(mapping);
            }

            LOGGER.debug(BgxLogMarkers.DEV, "Finished loading IBP config {}", this.configMappings);

        } catch (IOException e) {
            throw new IllegalArgumentException(String.format("Could not load channel mapping from file: %s", configMappingPath), e);
        } finally {

            if (mapping != null) {

                try {

                    mapping.close();

                } catch (IOException ioex) {

                    LOGGER.error("Error closing mapping stream.", ioex);
                }
            }
        }

    }
}
