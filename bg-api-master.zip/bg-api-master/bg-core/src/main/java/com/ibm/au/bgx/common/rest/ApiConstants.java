package com.ibm.au.bgx.common.rest;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


/**
 * Static class for various API related constants
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public class ApiConstants {

    /**
     * X-DLT-Request-Key is the component of the url that is sent to the business contact
     * This is passed in the header to fetch the related On-boarding request
     */
    public static final String ONBOARDING_HEADER_DLT_REQUEST_KEY = "X-DLT-Request-Key";

    /**
     * X-DLT-Auth-Token is the associated authentication token
     * This contains the auth PIN provided by the user when they visit the URL sent to them in email
     */
    public static final String ONBOARDING_HEADER_DLT_AUTH_TOKEN = "X-DLT-Auth-Token";

    public static final String REQUEST_HASH = "X-DLT-Request-Hash";

    public static final String FIELD_ONBOARDING_TOKEN = "token";


    public static final String ONBOARDING_HEADER_REQUEST_ID= "ProfileRequestId";

    public static final String ONBOARDING_HEADER_REFERRER_TOKEN = "ReferrerToken";

    public static final String KEY_DEFAULT = "default";

    public static final String ACTION_PAYLOAD_PROFILE =  "profile";

    // endpoints

    public static final String REFERRALS_NOTIFICATION_ENDPOINT = "/notifications/referrals";
    
    public static final String OIDC_TOKEN_ENDPOINT = "/auth/oidc/token";

    public static final String ONBOARDING_NOTIFICATION_ENDPOINT = "/notifications/onboardings";

    public static final String NETWORK_SYNC_NOTIFICATION_ENDPOINT = "/network/sync";

    public static final String ORG_CHANGE_NOTIFICATION_ENDPOINT = "/notifications/requests";

    public static final String GX_NOTIFICATION_ENDPOINT = "/notifications/guarantees";
    public static final String GX_ACTIONS_NOTIFICATION_ENDPOINT = "/notifications/guarantees/actions";

    public static final String TARGET_ORG = "X-DLT-Target-Org";
}
