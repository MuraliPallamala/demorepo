package com.ibm.au.bgx.core.cache;

import com.ibm.au.bgx.core.cache.UserProfileCache;
import com.ibm.au.bgx.model.chain.profile.UserProfileManager;
import com.ibm.au.bgx.model.pojo.UserProfile;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserProfileCacheImpl implements UserProfileCache {

    @Autowired
    UserProfileManager userProfileManager;

    Map<String, UserProfile> map = new HashMap<>();


    @Override
    public UserProfile get(String userId) {
        UserProfile resp = map.get(userId);
        if (resp != null) {
            return resp;
        }

        resp = userProfileManager.getById(userId);

        if (resp != null) {
            map.put(resp.getId(), resp);
        }

        return resp;
    }

    @Override
    public void refresh(String userId) {
        if (!map.containsKey(userId)) {
            // if the cache doesn't contain the userId, don't bother
            return;
        }
        map.remove(userId);
    }

    public static UserProfile filterUserProfile(UserProfile userProfile) {
        UserProfile filtered = new UserProfile();
        filtered.setId(userProfile.getId());
        filtered.setFirstName(userProfile.getFirstName());
        filtered.setLastName(userProfile.getLastName());
        filtered.setEmail(userProfile.getEmail());
        filtered.setEnabled2fAuth(null);
        filtered.setAttachments(null);

        return filtered;
    }
}
