package com.ibm.au.bgx.common.rest;

import com.ibm.au.bgx.model.api.NewCoAdminOrganizationClient;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest;
import com.ibm.au.bgx.model.pojo.api.request.OrgChangePayloadEntity;
import com.ibm.au.bgx.model.pojo.api.response.OrgRequestActionResponse;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import java.io.IOException;
import java.net.URISyntaxException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * @author Peter Ilfrich
 */
@Component
public class NewCoAdminOrganizationClientImpl extends AbstractNewCoAdminClient implements
    NewCoAdminOrganizationClient {

    private static final Logger LOGGER = LoggerFactory
        .getLogger(NewCoAdminOrganizationClientImpl.class);

    @Override
    public OrgChangeRequest sendOrganizationChangeRequest(String orgId,
        OrgChangePayloadEntity payload) throws ServiceUnavailableException {

        // prepare URL
        String url = String.format("%s/profile/orgs/%s/requests", getBaseUrl(), orgId);

        LOGGER.debug(BgxLogMarkers.DEV, String
            .format("> POST %s | Sending newco-admin an org change for org '%s'",
                url, orgId));

        HttpHeaders headers = getHeaders();
        addRequestHash(headers, payload, orgId);


        try {
            
            RestTemplate rest = this.getRestTemplate(url);
            HttpEntity<OrgChangePayloadEntity> request = new HttpEntity<>(payload, headers);
            ResponseEntity<OrgChangeRequest> response = rest
                            .exchange(url, HttpMethod.POST, request, OrgChangeRequest.class);

            return response.getBody();
        
        
        } catch(IOException | URISyntaxException ioex) {
                
            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }
    }


    @Override
    public OrgRequestActionResponse sendOrganiationChangeRequestAction(String orgId,
                                                                       String requestId, OrgRequestActionRequest actionRequest)
        throws ServiceUnavailableException {

        // prepare URL
        String url = String.format("%s/profile/orgs/%s/requests/%s/actions", getBaseUrl(), orgId, requestId);

        LOGGER.debug(BgxLogMarkers.DEV, String
            .format("> POST %s | Sending newco-admin an org change update for org '%s'",
                url, orgId));

        // add request hash header
        HttpHeaders headers = getHeaders();
        this.addRequestHash(headers, actionRequest, orgId);

        try {
            
            RestTemplate rest = this.getRestTemplate(url);
            HttpEntity<OrgRequestActionRequest> request = new HttpEntity<>(actionRequest, headers);
            ResponseEntity<OrgRequestActionResponse> response = rest
                .exchange(url, HttpMethod.POST, request, OrgRequestActionResponse.class);
    
            return response.getBody();
            
        } catch(IOException | URISyntaxException ioex) {
            
            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }
    }
}
