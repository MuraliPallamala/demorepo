package com.ibm.au.bgx.core.chain.adapter.gx;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxRequestTypeDataAdapter implements ChainDataAdapter<Gxs.GXStartRequest.RequestCase, GxRequestType> {

    @Override
    public Gxs.GXStartRequest.RequestCase toOnChainModel(GxRequestType input) {
        switch (input) {
            case ISSUE:
                return Gxs.GXStartRequest.RequestCase.GX_ISSUE_REQUEST;
            case AMEND:
                return Gxs.GXStartRequest.RequestCase.GX_AMEND_REQUEST;
            case DEMAND:
                return Gxs.GXStartRequest.RequestCase.GX_DEMAND_REQUEST;
            case CANCEL:
                return Gxs.GXStartRequest.RequestCase.GX_CANCEL_REQUEST;
            case PAYWALK:
                return Gxs.GXStartRequest.RequestCase.GX_PAY_WALK_REQUEST;
            case TRANSFER:
                return Gxs.GXStartRequest.RequestCase.GX_TRANSFER_REQUEST;
            default:
            	throw new IllegalArgumentException("Unable to map GxRequestType to on chain model");
        }
    }

    @Override
    public GxRequestType toOffchainModel(Gxs.GXStartRequest.RequestCase input) {
        switch (input) {
            case GX_ISSUE_REQUEST:
                return GxRequestType.ISSUE;
            case GX_AMEND_REQUEST:
                return GxRequestType.AMEND;
            case GX_DEMAND_REQUEST:
                return GxRequestType.DEMAND;
            case GX_PAY_WALK_REQUEST:
                return GxRequestType.PAYWALK;
            case GX_CANCEL_REQUEST:
                return GxRequestType.CANCEL;
            case GX_TRANSFER_REQUEST:
                return GxRequestType.TRANSFER;
            default:
                throw new IllegalArgumentException("Unable to map GxRequestType to off chain model");
        }
    }
}
