package com.ibm.au.bgx.core.util;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.util.ListUtil;
import com.ibm.au.bgx.core.approvalmodel.ApprovalModelUtil;
import com.ibm.au.bgx.core.chain.channel.gx.GxChannelProvider;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.exception.GuaranteeException;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;
import com.ibm.au.bgx.model.pojo.chain.FlowStatus;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxActiveRequestsBitmaskWrapper;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.gx.GxTransferPayload;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;

/**
 * 
 * @author fl0yd
 *
 */
@Component
public class GxUtil {

    /**
     * 
     */
	private static ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

	/**
	 * 
	 */
    @Autowired
    private GxRequestRepository gxRequestRepository;

    /**
     * 
     */
    @Autowired
    private OrganizationManager organizationManager;

    /**
     * 
     */
    @Autowired
    private GxChannelProvider gxChannelProvider;

    // Onchain only requests
    /**
     * 
     */
    public static final int ONCHAIN_ACTIVE_GX_REQUESTS_AMEND =      0b00000001;
    /**
     * 
     */
    public static final int ONCHAIN_ACTIVE_GX_REQUESTS_CANCEL =     0b00000010;
    /**
     * 
     */
    public static final int ONCHAIN_ACTIVE_GX_REQUESTS_DEMAND =     0b00000100;
    /**
     * 
     */
    public static final int ONCHAIN_ACTIVE_GX_REQUESTS_TRANSFER =    0b00001000;

    // Onchain+Offchain requests
    /**
     * 
     */
    public static final int ACTIVE_GX_REQUESTS_AMEND = 0b00000001;
    /**
     * 
     */
    public static final int ACTIVE_GX_REQUESTS_CANCEL = 0b00000010;
    /**
     * 
     */
    public static final int ACTIVE_GX_REQUESTS_DEMAND = 0b00000100;
    /**
     * 
     */
    public static final int ACTIVE_GX_REQUESTS_PAYWALK = 0b00001000;
    /**
     * 
     */
    public static final int ACTIVE_GX_REQUESTS_TRANSFER = 0b00010000;

    // HACK for error detection
    /**
     * 
     */
    public static final String ERROR_NOT_FOUND = "not found";
    /**
     * 
     */
    public static final String ERROR_FORBIDDEN = "does not have permissions";
    /**
     * 
     */
    public static final String ERROR_PARENT_RESOURCE = "parent resource missing";


    // NOTE will change if issuerId format changes
    // Convention is channel name should be <issuerId>-<channelSuffix>
    /**
     * 
     * @param issuerId
     * @return
     */
    public String getChannelNameFromIssuerId(String issuerId) {
        issuerId = issuerId.toLowerCase();
        String[] channelNames = gxChannelProvider.getChannelNames();
        for (int i = 0; i < channelNames.length; i++) {
            if (channelNames[i].startsWith(issuerId + "-")) {
                return channelNames[i];
            }
        }
        return null;     
    }

    // NOTE will change if issuerId format changes
    // Convention is channel name should be <issuerId>-<channelSuffix>
    /**
     * 
     * @param channelName
     * @return
     */
    public static String getIssuerIdFromChannelName(String channelName) {
        return channelName.split("-")[0];
    }

    /**
     * 
     * @param bitmaskWrapperList
     * @return
     */
    public static Map<String, Integer> createActiveRequestBitmaskMap(
        List<GxActiveRequestsBitmaskWrapper> bitmaskWrapperList) {
        Map<String, Integer> result = new HashMap<>();
        for (GxActiveRequestsBitmaskWrapper bitmaskWrapper : bitmaskWrapperList) {
            result.put(bitmaskWrapper.getGxId(), bitmaskWrapper.getMask());
        }
        return result;
    }

    /**
     * 
     * @param bitMask
     * @return
     */
    public static List<GxRequestType> resolveActiveRequestBitmask(int bitMask) {
        List<GxRequestType> types = new ArrayList<>();
        if ((bitMask & ACTIVE_GX_REQUESTS_AMEND) == ACTIVE_GX_REQUESTS_AMEND) {
            types.add(GxRequestType.AMEND);
        }

        if ((bitMask & ACTIVE_GX_REQUESTS_CANCEL) == ACTIVE_GX_REQUESTS_CANCEL) {
            types.add(GxRequestType.CANCEL);
        }

        if ((bitMask & ACTIVE_GX_REQUESTS_DEMAND) == ACTIVE_GX_REQUESTS_DEMAND) {
            types.add(GxRequestType.DEMAND);
        }

        if ((bitMask & ACTIVE_GX_REQUESTS_PAYWALK) == ACTIVE_GX_REQUESTS_PAYWALK) {
            types.add(GxRequestType.PAYWALK);
        }

        if ((bitMask & ACTIVE_GX_REQUESTS_TRANSFER) == ACTIVE_GX_REQUESTS_TRANSFER) {
            types.add(GxRequestType.TRANSFER);
        }

        return types;
    }
    
    /**
     * 
     * @param gxs
     * @param principal
     * @return
     */
    public List<Gx> addActiveRequestBitmaskToGxList(List<Gx> gxs, BgxPrincipal principal) {
        // Add active request information
        List<String> gxIds = gxs.stream()
        						.map(e -> e.getId())
        						.collect(Collectors.toList());

        List<GxActiveRequestsBitmaskWrapper> bitmaskList;
        try {
            if (principal != null) {
                bitmaskList = gxRequestRepository.findActiveRequestsMask(principal.getConfiguredForOrgId(), gxIds); // For app ben
            } else {
                bitmaskList = gxRequestRepository.findActiveRequestsMask(null, gxIds); // For issuers + consortium
            }
        } catch (IOException e) {
            throw new GuaranteeException("Unable to retrieve gx activeRequest bitmasks", e);
        }

        Map<String, Integer> bitmaskMap = GxUtil.createActiveRequestBitmaskMap(bitmaskList);

        for (int i = 0; i < gxs.size(); i++) {
            Gx gx = gxs.get(i);

            Integer activeRequest = bitmaskMap.get(gx.getId());
            if (activeRequest != null) {
                gx.setActiveRequests(activeRequest);
            } else {
                gx.setActiveRequests(0);
            }
        }

        return gxs;
    }

    /**
     * Validate that GxLimit is not negative and is less than the MAX possible value
     * @param gxLimit
     */
    public static void validateGxLimitValue(BigInteger gxLimit) {

        if (gxLimit == null) {
            throw new IllegalArgumentException("GxLimit cannot be null");
        }

        if (gxLimit.compareTo(BgxConstants.MAX_POSSIBLE_GX_LIMIT) > 0) {
            throw new IllegalArgumentException(String.format("Gx Limit %s cannot be more than %s", gxLimit, BgxConstants.MAX_POSSIBLE_GX_LIMIT));
        }

        // check for negatives, but allow the special constant UNLIMITED_GX_LIMIT -1
        if (gxLimit.compareTo(BgxConstants.UNLIMITED_GX_LIMIT) < 0) {
            throw new IllegalArgumentException(String.format("Gx Limit %s cannot be less than the constant UNLIMITED_GX_LIMIT (%s)", gxLimit, BgxConstants.UNLIMITED_GX_LIMIT));
        }
    }

    /**
     * Gets the ActiveGxRequestFlag for the corresponding GxRequest requestType
     *
     * @return ActiveGxRequestFlag or 0 if there is no corresponding flag
     */
    public static int getActiveGxRequestsFlagForRequestType(GxRequestType requestType) {
        switch (requestType) {
            case AMEND:
                return GxUtil.ACTIVE_GX_REQUESTS_AMEND;
            case DEMAND:
                return GxUtil.ACTIVE_GX_REQUESTS_DEMAND;
            case CANCEL:
                return GxUtil.ACTIVE_GX_REQUESTS_CANCEL;
            case PAYWALK:
                return GxUtil.ACTIVE_GX_REQUESTS_PAYWALK;
            case TRANSFER:
                return GxUtil.ACTIVE_GX_REQUESTS_TRANSFER;
        }
        return 0;
    }
    /**
     * 
     * @param gxRequest
     * @param gx
     * @return
     */
    public static List<String> getInvolvedOrgIdsForGxRequest(GxRequest gxRequest, Gx gx) {
        if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
            GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
            return ApprovalModelUtil.concatenate(issuePayload.getApplicants(), issuePayload.getBeneficiaries());
        } else if (gxRequest.getType().equals(GxRequestType.TRANSFER)) {
            GxTransferPayload transferPayload = MAPPER.convertValue(gxRequest.getPayload(), GxTransferPayload.class);
            return ApprovalModelUtil.concatenate(gx.getApplicants(), gx.getBeneficiaries(), transferPayload.getBeneficiaries());
        }

        return ApprovalModelUtil.concatenate(gx.getApplicants(), gx.getBeneficiaries());
    }

    // TODO remove once api is synced properly with service api
    /**
     * 
     * @param gxRequestId
     * @throws InterruptedException
     */
    public void hackySynchroniseOffChainOnchainRequest(String gxRequestId)
        throws InterruptedException {
        GxRequest existingOffchainRequest = null;
        try {
            existingOffchainRequest = gxRequestRepository.getItem(gxRequestId);
        } catch (DataNotFoundException e) {
            // do nothing
        }
        // waits a max of 5 minutes
        GxRequest offchainRequest = null;
        for (int i = 0; i < 10 * 60; i++) {
            try {
                offchainRequest = gxRequestRepository.getItem(gxRequestId);
            } catch (DataNotFoundException e) {
                // do nothing
            }
            if (offchainRequest != null) {

                // check if there's been an update, NOTE should really just use couchdb revisions
                if (existingOffchainRequest == null || (
                    offchainRequest.getOffchainUpdateCount() != existingOffchainRequest.getOffchainUpdateCount())) {
                    break;
                }
            }

            TimeUnit.MILLISECONDS.sleep(500);
        }
    }

    /**
     * 
     * @param gxRequest
     * @return
     * @throws GuaranteeException
     */
    public List<String> getVisibleToChannelUsernames(GxRequest gxRequest)
        throws GuaranteeException {
        if (gxRequest.getVisibleToOrgIds() == null) {
            throw new IllegalArgumentException("Visible to OrgIds must be set.");
        }
        List<String> visibleToChannelUsernames = new ArrayList<>();
        visibleToChannelUsernames.addAll(gxRequest.getVisibleToChannelUsernames());
        for (String orgId : gxRequest.getVisibleToOrgIds()) {
            try {
                Organization org = organizationManager.getById(orgId);
                for (RelationshipInfo rel : org.getSettings().getRelationships()) {
                    if (rel.getRelationship().equals(Relationship.SUBSIDIARY_OF)) {
                        // Get parent's side of the relationship
                        Organization parent = organizationManager.getById(rel.getId());
                        RelationshipInfo parentRel = parent.getSettings().getRelationships()
                            .stream().filter(r -> r.getId().equals(org.getId())).findFirst().get();
                        visibleToChannelUsernames =ListUtil.addAllNoDuplicates(visibleToChannelUsernames,
                            Collections.singletonList(parentRel.getChannelUserName()));
                    }
                }
            } catch (Exception e) {
                throw new GuaranteeException("Could not find organization", e);
            }
        }
        return visibleToChannelUsernames;
    }
    
    public GxRequest filterGxRequest(BgxPrincipal principal, GxRequest gxRequest) {
        // Remove offchain actions
        gxRequest.setOffchainActions(null);
        // If is ISSUE request and status is not APPROVED
        if (gxRequest.getType().equals(GxRequestType.ISSUE) && !gxRequest.getStatus().equals(FlowStatus.APPROVED.value())) {

            // If is beneficiary
            GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
            Gx gx = issuePayload;
            if (gx.getBeneficiaries().contains(principal.getConfiguredForOrgId())) {

                // delete issuer
                gx.setIssuer(null);
                gxRequest.setPayload(issuePayload);
            }
        }

        return gxRequest;
    }
}
