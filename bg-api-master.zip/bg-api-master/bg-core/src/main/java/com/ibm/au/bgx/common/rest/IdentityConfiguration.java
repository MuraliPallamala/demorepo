package com.ibm.au.bgx.common.rest;

import com.ibm.au.bgx.model.IdentityConfig;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.repository.OrganizationRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * @author Peter Ilfrich
 */
@Component
public class IdentityConfiguration implements IdentityConfig {

    public static final String SOURCE_IDENTITY_HEADER_INTERNAL = "identitySourceInternal";
    public static final String SOURCE_IDENTITY_HEADER_NAME = "identitySourceName";

    @Value("${api.self.portal:}")
    private String selfPortalUrl;

    @Value("${bgx.fabricUser:}")
    private String fabricUser;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Value("${bgx.internalUrl}")
    private String internalUrl;

    @Value("${bgx.identity}")
    private String identity;

    @Value("${api.newco.user.portal:}")
    private String newcoPortalUrl;

    // cached value
    private OrgProfile.EntityType orgType;

    @PostConstruct
    public void init() {
        if (this.fabricUser.isEmpty()) {
            this.fabricUser = identity;
        }
    }

    @Override
    public boolean isNewCoAdmin() {
        if (this.orgType == null) {
            this.determineOrgType();

        }
        return this.orgType.equals(OrgProfile.EntityType.CONSORTIUM) && identity.endsWith("-admin");
    }

    @Override
    public boolean isIssuer() {
        if (this.orgType == null) {
            this.determineOrgType();
        }
        return this.orgType.equals(OrgProfile.EntityType.ISSUER);

    }

    protected void determineOrgType() {
        Organization org = this.organizationRepository.getItem(identity);
        orgType = org.getProfile().getEntityType();
    }

    @Override
    public String getPortalUrl() {
        return this.selfPortalUrl;
    }

    @Override
    public String getNewcoPortalUrl() {
        return this.newcoPortalUrl;
    }

    @Override
    public String getInternalUrl() {
        return this.internalUrl;
    }

    public void setInternalUrl(String internalUrl) {
        this.internalUrl = internalUrl;
    }

    @Override
    public String getIdentity() {
        return this.identity;
    }

    @Override
    public void setIdentity(String newIdentity) {
        this.identity = newIdentity;
        this.determineOrgType();
    }

    @Override
    public String getFabricUser() {
        return this.fabricUser;
    }
}
