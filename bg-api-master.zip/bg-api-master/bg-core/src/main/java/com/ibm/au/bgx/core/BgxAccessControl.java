package com.ibm.au.bgx.core;

import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Centralized access control helper methods
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@Component
public class BgxAccessControl {

    private static final Logger LOGGER = LoggerFactory.getLogger(BgxAccessControl.class);


    /**
     * Check that principal has access to certain org settings
     * @param principal
     * @param targetOrgId
     * @param element
     * @throws GuaranteeForbiddenException if it is not allowed
     */
    public void validateAccessToTargetOrgSettings(BgxPrincipal principal, String targetOrgId, String element) {

        // access control
        LOGGER.debug(BgxLogMarkers.DEV, "Checking for access to org settings {} of target org {}", element, targetOrgId);
        List<String> allowedFields = Arrays.asList("approvalModel", "roles");
        if (principal.isActingOnBehalf(targetOrgId) && !allowedFields.contains(element)) {
            throw new GuaranteeForbiddenException(String.format("You are not allowed to view %s from org settings of org %s", element, targetOrgId));
        }
        LOGGER.debug(BgxLogMarkers.DEV, "Access available to org settings {} of target org {}", element, targetOrgId);
    }


    /**
     * Check if principal is allowed to access parent org's users
     *
     * @param principal
     * @param targetOrgId
     */
    public void validateAccessToParentUserList(BgxPrincipal principal, String targetOrgId) {
        LOGGER.debug(BgxLogMarkers.DEV, "Checking for access to org users of target org {}", targetOrgId);

        LOGGER.debug(BgxLogMarkers.DEV, "Check if principal {} has access to parent {}", principal.getEmail(), targetOrgId);
        for (RelationshipInfo relInfo : principal.getOrganization().getSettings().getRelationships()) {
            if (relInfo.getId().equals(targetOrgId)
                && relInfo.getRelationship().equals(Relationship.SUBSIDIARY_OF) &&
                    (relInfo.getStatus().equals(RelationshipInfo.Status.LINKED) || relInfo.getStatus().equals(RelationshipInfo.Status.UNLINK_PENDING))) {
                LOGGER.debug(BgxLogMarkers.DEV, "Access available to org users of target org {}", targetOrgId);
                return;
            }
        }

        throw new GuaranteeForbiddenException(String.format("You are not allowed to access users of org %s", targetOrgId));
    }
}
