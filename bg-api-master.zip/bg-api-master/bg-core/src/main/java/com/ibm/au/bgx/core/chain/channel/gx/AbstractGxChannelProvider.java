/**
 * 
 */
package com.ibm.au.bgx.core.chain.channel.gx;

import java.util.List;
import java.util.Optional;

/**
 * <p>
 * Class <b>AbstractGxChannelProvider</b>. This class implements the  {@link GxChannelProvider}
 * interface and provides to concrete classes that inherit from this type the basic plumbing for
 * retrieving metadata about bank guarantee channels, configured for the current execution context
 * </p>
 * <p>
 * The only elements that is left to the concrete classes to implement is the population of the
 * protected field <i>channels</i> which contains is expected to contain the list of the configured
 * bank guarantee channels.
 * </p>
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class AbstractGxChannelProvider implements GxChannelProvider {
	
	
	/**
	 * A {@link List} implementation that is used to store the list of the
	 * available channels.
	 */
	protected List<GxChannelMetadata> channels;

	/**
	 * This method retrieves the list of channels that are configured in the
	 * current execution context to manage bank guarantees. 
	 * 
	 * @return 	an array of {@link GxChannelMetadata} instances containing the
	 * 			information about the channel. If there are no channels configured
	 * 			the returned array is empty.
	 */
	@Override
	public GxChannelMetadata[] getChannels() {
		
		GxChannelMetadata[] array = new GxChannelMetadata[this.channels.size()];
		this.channels.toArray(array);
		
		return array;
	}

	/**
	 * This method retrieves the list of channel names that are configured in the
	 * current execution context to manage bank guarantees.
	 * 
	 * @return	an array of String containing the names of the channels. If there is
	 * 			no channel configured the array is empty.
	 */
	@Override
	public String[] getChannelNames() {
	
		int scan=0;
		String[] names = new String[this.channels.size()];
		for(GxChannelMetadata metadata : this.channels) {
			
			names[scan] = metadata.getName();
			scan++;
		}
		
		return names;
	}
	

	/**
	 * Retrieves the metadata of the channel that is mapped by <i>name</i>.
	 * 
	 * @param name 	a {@link String} representing the name of the channel
	 * 				to retrieve. It cannot be {@literal null} or an empty
	 * 				string.
	 * 
	 * @returns a {@link GxChannelMetadata} instance that is mapped by <i>name</i>
	 * 			or {@literal null} if there is no such channel with the given name.
	 * 
	 * @throws IllegalArgumentException 	if <i>name</i> is {@literal null} or
	 * 										an empty string.
	 */
	@Override
	public GxChannelMetadata getChannelByName(String name) {
	
		this.checkNullOrEmpty(name, "name");
		
		Optional<GxChannelMetadata> opt = this.channels.stream()
			 								   .filter(m -> m.getName().equals(name))
			 								   .findAny();

		return (opt.isPresent() ? opt.get() : null);	
	}


	/**
	 * Retrieves the metadata of the channel that is identified by <i>prefix</i>.
	 * 
	 * @param prefix 	a {@link String} containing the value of the prefix used to
	 * 					compose bank guarantee identifiers in the channel of interest.
	 * 					This value is unique to each channel. It cannot be {@literal
	 * 					null} or an empty string.
	 * 
	 * @returns a {@link GxChannelMetadata} instance that is mapped by <i>prefix</i>
	 * 			or {@literal null} if there is no such channel associated to that prefix.
	 * 
	 * @throws IllegalArgumentException 	if <i>prefix</i> is {@literal null} or
	 * 										an empty string.
	 */
	@Override
	public GxChannelMetadata getChannelByPrefix(String prefix) {

		this.checkNullOrEmpty(prefix, "prefix");
				
		Optional<GxChannelMetadata> opt = this.channels.stream()
					 								   .filter(m -> m.getPrefix().equals(prefix))
					 								   .findAny();
		
		return (opt.isPresent() ? opt.get() : null);
	}
	
	/**
	 * This is a utility method that is used to validate the parameters passed to the
	 * public method of the type. The method checks whether the given <i>parameter</i> 
	 * is {@literal null} or an empty string. Should any of these two conditions result
	 * to {@literal true} it throws an {@link IllegalArgumentException}
	 * 
	 * 
	 * @param parameter		a {@link String} containing the parameter to check.
	 * @param name			a {@link String} containing the name of the parameter. This
	 * 						argument is used to compose a more specialised text for the
	 * 						{@link IllegalArgumentException} thrown if <i>parameter</i>
	 * 						fails the validation test.
	 * 
	 * @throws IllegalArgumentException	if <i>parameter</i> is {@literal null} or empty.
	 */
	protected void checkNullOrEmpty(String parameter, String name) {
		
		if (parameter == null || parameter.isEmpty()) {
			
			throw new IllegalArgumentException(String.format("Parameter '%1$s' cannot be null or an empty string.", name));
		}
	}
	
	

}
