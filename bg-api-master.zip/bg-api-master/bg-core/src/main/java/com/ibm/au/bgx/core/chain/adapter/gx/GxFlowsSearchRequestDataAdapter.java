package com.ibm.au.bgx.core.chain.adapter.gx;

import com.ibm.au.bgx.core.chain.adapter.AddressDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.flow.FlowStatusDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.shared.Flow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxFlowsSearchRequestDataAdapter implements ChainDataAdapter<Gxs.GXFlowSearchRequest, GxFlowsSearchRequest> {

    @Autowired
    AddressDataAdapter addressDataAdapter;

    @Autowired
    GxStatusTypeDataAdapter gxStatusTypeDataAdapter;

    @Autowired
    FlowStatusDataAdapter flowStatusDataAdapter;

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    GxSearchOrderByTypeDataAdapter gxSearchOrderByTypeDataAdapter;

    @Autowired
    GxSearchOrderTypeDataAdapter gxSearchOrderTypeDataAdapter;

    @Override
    public Gxs.GXFlowSearchRequest toOnChainModel(GxFlowsSearchRequest input) {
        Gxs.GXFlowSearchRequest.Builder builder = Gxs.GXFlowSearchRequest.newBuilder();
        if (input.getStatus() != null) {
            builder.setStatus(
                    Flow.FlowStatusValue.newBuilder().setValue(this.flowStatusDataAdapter.toOnChainModel(input.getStatus()))
            );
        }
        if (input.getStart() != null) {
            builder.setStart(input.getStart());
        }
        if (input.getGuaranteeId() != null) {
            builder.setGxId(input.getGuaranteeId());
        }
        if (input.getLimit() != null) {
            builder.setLimit(input.getLimit().intValue());
        }

        return builder.build();
    }

    @Override
    public GxFlowsSearchRequest toOffchainModel(Gxs.GXFlowSearchRequest input) {
        // Not implemented
        return null;
    }
}
