package com.ibm.au.bgx.common.rest;

import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.api.NewCoNotificationClient;
import com.ibm.au.bgx.model.chain.profile.OrgProfileRequestManager;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.model.pojo.onboarding.OnboardingNotification;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@Component
public class NewCoNotificationClientImpl extends AbstractRemoteClient implements
        NewCoNotificationClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(NewCoNotificationClientImpl.class);

    @Value("${api.newco.url:http://localhost:9082}")
    private String newcoUrl;

    public String getBaseUrl() {
        return this.newcoUrl;
    }

    // onboarding
    @Override
    public void sendOrganizationApprovedNotification(OrgProfileRequest request,
                                                     Map<String, Object> payload) throws ServiceUnavailableException {

        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }

        String url = String
                .format("%s%s", this.getBaseUrl(), ApiConstants.ONBOARDING_NOTIFICATION_ENDPOINT);

        HttpHeaders headers = this.getHeaders();
        OnboardingNotification notification = new OnboardingNotification();
        notification.setPayload(payload);

        // Set referrer info
        notification.getPayload().put(BgxConstants.KEY_REFERRER_ID, identityConfig.getIdentity());

        // Add referrer header
        this.addRequestHash(headers, notification, identityConfig.getIdentity());

        LOGGER.debug(BgxLogMarkers.DEV, "> POST {}", url);

        try {

            RestTemplate rest = this.getRestTemplate(url);
            HttpEntity<?> httpRequest = new HttpEntity<>(notification, headers);
            ResponseEntity<?> response = rest.exchange(url, HttpMethod.POST, httpRequest, String.class);
            LOGGER.debug(BgxLogMarkers.DEV, "Notification response: {}", response);

            if (!response.getStatusCode().equals(HttpStatus.OK)) {
                // just log the error, no need to take action or throw an exception
                LOGGER.error(
                        "Sending notification returned an invalid status code: {}",
                        response.getStatusCode()
                );
            }

        } catch (IOException | URISyntaxException ex) {

            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ex);
        }
    }


    /**
     * Sends a notification to NewCo, when NewCo admin has approved or rejected an org change
     * request of type CHANGE_DETAILS (affecting entity name and postal address)
     *
     * @param request - the original org change request - the org change request that got rejected
     *                or approved
     * @param action  - the approve/reject action containing the reason in case of rejection
     */
    @Override
    public void sendOrgChangeAdminNotification(OrgChangeRequest request, OrgRequestAction action)
            throws ServiceUnavailableException {

        // create payload and sign request payload
        Map<String, Object> payload = new HashMap<>();
        payload.put("id", request.getId());
        payload.put(OrgProfileRequestManager.KEY_ACTION, action);
        payload.put(BgxConstants.KEY_REFERRER_ID, identityConfig.getIdentity());

        // compose URL
        String url = String.format("%s/profile/orgs/%s/%s", this.getBaseUrl(), request.getOrgId(),
                ApiConstants.ORG_CHANGE_NOTIFICATION_ENDPOINT);

        // retrieve headers for API to API communication
        HttpHeaders headers = this.getHeaders();
        this.addRequestHash(headers, payload, this.identityConfig.getIdentity());

        try {

            // call endpoint
            RestTemplate rest = this.getRestTemplate(url);
            HttpEntity<Map<?,?>> httpRequest = new HttpEntity<>(payload, headers);
            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = rest.exchange(url, HttpMethod.POST, httpRequest, Map.class);

            // evaluate response
            if (response.getStatusCode().equals(HttpStatus.CREATED)) {
                return;
            }

            LOGGER.error(String.format("Invalid response when trying to send approval/rejection to NewCo. Status %d, Response: {}",
                    response.getStatusCodeValue()), response);
            throw new ServiceUnavailableException("Could not send approval/rejection to NewCo due to error with response");

        } catch (IOException | URISyntaxException ioex) {

            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }
    }

}
