package com.ibm.au.bgx.common.rest.filter;

import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.util.ArrayList;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

/**
 * Organization profile filter
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@Component
public class OrgProfileFilter extends AbstractApiEntityFilter<OrgProfile> {

    @Override
    public OrgProfile filterOne(OrgProfile item, BgxPrincipal principal) {

        if (item == null) {
            return null;
        }

        // we don't filter for newco and newco-admin users
        if (principal != null && principal.isConsortiumUser()) {
            return item;
        }

        // filter fields
        if (principal != null
            && !StringUtils.isEmpty(principal.getConfiguredForOrgId())
            && !StringUtils.isEmpty(item.getId())
            && item.getId().equals(principal.getConfiguredForOrgId())) {

            if (item.getContacts() != null) {
                for (ContactInfo contactInfo : item.getContacts()) {
                    contactInfo.setCredentials(null);
                }
            } else {
                item.setContacts(new ArrayList<>()); // reset with array
            }

            // return item for the org belonging to the principal
            return item;
        }

        // filter fields for other orgs
        item.setContacts(new ArrayList<>());
        item.setAgreement(null);

        return item;
    }
}
