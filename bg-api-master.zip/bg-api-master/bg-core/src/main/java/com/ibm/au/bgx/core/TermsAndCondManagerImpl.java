package com.ibm.au.bgx.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.DocumentStore;
import com.ibm.au.bgx.model.chain.TermsAndCondChain;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.api.exceptions.ApiException;
import com.ibm.au.bgx.model.api.exceptions.ApiRecordNotFoundException;
import com.ibm.au.bgx.model.pojo.tc.TcExternalContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCondContent.Type;
import com.ibm.au.bgx.model.repository.TermsAndCondRepository;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.time.Instant;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * This class manages life cycle of terms and condition records
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class TermsAndCondManagerImpl implements TermsAndCondManager {

    @Autowired
    TermsAndCondChain tcChain;

    @Autowired
    TermsAndCondRepository repository;

    @Autowired
    DocumentStore documentStore;

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Value("${bgx.tc.sync.interval:300}")
    private long syncInterval;

    // For synchronization
    private Object syncLock = new Object();

    private Instant lastSync = null;

    /**
     * Create a record in the chain
     */
    @Override
    public TermsAndCond create(TermsAndCond tc) throws ProfileChainException {
    	
    	if (tc == null) {
    		throw new IllegalArgumentException("Terms and conditions cannot be null.");
    	}

        if (tc.getId() == null || tc.getId().isEmpty()) {
            tc.setId(UUID.randomUUID().toString());
        }

        // if it is of type external, save the document and clean before storing on-chain
        if (Type.EXTERNAL.equals(tc.getContent().getType())) {
            TcExternalContent external = this.prepareNewExternalContent(tc);

            // store in the off-chain
            // Note that it is stored only in newco-admin database since newco-admin creates TC
            tc.getContent().setData(external);
        }

        // Create record on-chain
        TermsAndCond saved = this.tcChain.create(tc);

        // save meta in off-chain
        if (tc.getMeta() != null && tc.getMeta().containsKey(BgxConstants.META_FILE)) {
            tc.getMeta().remove(BgxConstants.META_FILE);
        }
        saved.setMeta(tc.getMeta());
        return this.updateCache(saved);
    }

    @Override
    public TermsAndCond getById(String id) throws ProfileChainException {

        // try to load from off-chain
        try {
            return this.repository.getItem(id);
        } catch (DataNotFoundException e) {
            // ignore if it failed to load from offchian
        }

        // Try to load from chain
        TermsAndCond item = this.tcChain.getById(id);

        // Cache it
        if (item != null) {
            this.repository.addItem(item);
        }

        return item;
    }

    @Override
    public List<TermsAndCond> getByTitle(String title) throws ProfileChainException {
        return repository.getByTitle(title);
    }

    @Override
    public List<TermsAndCond> getByScope(String scope) throws ProfileChainException {
        return repository.getByScope(scope);
    }

    @Override
    public List<TermsAndCond> getActiveByTitle(String title) throws ProfileChainException {
        return tcChain.getActive(title, null);
    }

    @Override
    public List<TermsAndCond> getActiveByScope(String scope) throws ProfileChainException {
        return tcChain.getActive(null, scope);
    }

    @Override
    public void refreshCacheFromChain() throws ProfileChainException {

        synchronized (this.syncLock) {

            Instant now = Instant.now();

            if (this.lastSync == null
                || this.lastSync.plusSeconds(this.syncInterval).isBefore(now)) {

                // get all records from chain
                List<TermsAndCond> records = tcChain.getAll("", "");

                for (TermsAndCond tc : records) {
                    this.updateCache(tc);
                }

                this.lastSync = now;
            }
        }
    }

    @Override
    public TermsAndCond updateExternalData(String id, TcExternalContent externalContent) {
    	
    	
        TermsAndCond existing = null;
        try {
        
        	existing = this.getById(id);
            
        } catch (ProfileChainException e) {
            throw new DataNotFoundException(String.format("T&C could not be found with id '%s'", id), e);
        }

        if (existing == null) {
            throw new DataNotFoundException(String.format("T&C could not be found with id '%s'", id));
        }
        

        if (externalContent == null) {
        	throw new IllegalArgumentException("Terms and condition external content cannot be null.");
        }
           
    	Map<String, Object> meta = this.prepareMetaForTcDocument(existing);
    	this.documentStore.createDocumentWithBase64(id, externalContent.getPayload(), meta);
        

        return existing;
    }

    /**
     * Load the payload form repository for the external TC
     */
    @Override
    public TcExternalContent loadExternalContent(String id) {
    	
        TermsAndCond tc = this.repository.getItem(id);
        if (!tc.getContent().getType().equals(Type.EXTERNAL)) {
            throw new IllegalArgumentException("T&C is not of type EXTERNAL");
        }

        TcExternalContent tec = MAPPER.convertValue(tc.getContent().getData(), TcExternalContent.class);

        // read the document
        if (this.documentStore.hasDocument(id)) {
            String payload = this.documentStore.readDocumentAsBase64(id);
            // set the payload
            tec.setPayload(payload);
        }

        return tec;
    }

    private TermsAndCond updateCache(TermsAndCond item) {
        TermsAndCond existing = null;
        try {
            existing = this.repository.getItem(item.getId());
        } catch (DataNotFoundException e) {

        }

        if (existing == null) {
            return this.repository.addItem(item);
        } else {
            item.setId(existing.getId());
            item.setMeta(existing.getMeta());
            return this.repository.updateItem(item);
        }
    }

    /**
     * Tuple to identify keys in the cache for the getAll query above.
     */
    protected class TitleTypeTuple {

        public final String title;
        public final String type;

        public TitleTypeTuple(String title, String type) {
            this.title = title;
            this.type = type;
        }

        @Override
        public int hashCode() {
            return new HashCodeBuilder().append(this.title).append(this.type).toHashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof TitleTypeTuple)) {
                return false;
            }
            TitleTypeTuple ttt = (TitleTypeTuple) obj;
            return new EqualsBuilder().append(ttt.title, this.title).append(ttt.type, this.type)
                .isEquals();
        }
    }

    /**
     * Helper method to compute hash
     *
     * @param payload base64 string of the payload
     */
    public static String computeHash(String payload) {
        return DigestUtils.sha256Hex(payload);
    }

    /**
     * Encode file data into base64
     *
     * @param fileData
     * @return
     */
    public static String encodeFilePayload(byte[] fileData) {
        return Base64.getEncoder().encodeToString(fileData);
    }


    /**
     * Prepare new external content by adding a hash and inserting documentId
     */
    private TcExternalContent prepareNewExternalContent(TermsAndCond tc) {
        // compute hash
        TcExternalContent tec = MAPPER.convertValue(tc.getContent().getData(), TcExternalContent.class);

    	// [CV] TODO: Remove reference to TermsAndCondManagerImpl and move method
    	//
        tec.setHash(computeHash(tec.getPayload()));

        // create document
        Map<String, Object> meta = this.prepareMetaForTcDocument(tc);
        this.documentStore.createDocumentWithBase64(tc.getId(), tec.getPayload(), meta);

        // empty the payload
        tec.setPayload(null);

        // reuse the entity ID.
        // We still have the field, because we may use a different id based on the underlying repository
        tec.setDocumentId(tc.getId());

        return tec;
    }

    private Map<String, Object> prepareMetaForTcDocument(TermsAndCond tc) {

        // copy given meta
        Map<String, Object> meta = new HashMap<>();
        if (tc.getMeta() != null) {
            for (Entry<String, Object> entry : tc.getMeta().entrySet()) {
               meta.put(entry.getKey(), entry.getValue());
            }
        }

        // inject extra meta data
        meta.put(BgxConstants.META_CONTENT_TYPE, tc.getContent().getContentType());

        return meta;
    };

    @Override
    public TermsAndCond updateActiveStatus(String id, boolean activeStatus) throws ApiException, ProfileChainException {
        TermsAndCond tc = this.getById(id);
        if (tc == null) {
            throw new ApiRecordNotFoundException(null, String.format("Could not find T&C with id '%s'", id), null);
        }

        try {
            tcChain.updateActiveStatus(id, activeStatus);
        } catch (ProfileChainException pe) {
            throw new ApiException(null, "Could not update active status", pe);
        }

        // reload updated record from chain and return it
        this.updateCache(this.getById(id));
        return this.getById(id);
    };

}

