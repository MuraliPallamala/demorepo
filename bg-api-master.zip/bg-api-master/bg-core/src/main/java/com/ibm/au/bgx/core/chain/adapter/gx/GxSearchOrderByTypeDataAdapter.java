package com.ibm.au.bgx.core.chain.adapter.gx;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxSearchOrderByType;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxSearchOrderByTypeDataAdapter implements ChainDataAdapter<Gxs.GXSearchOrderBy, GxSearchOrderByType> {

    @Override
    public Gxs.GXSearchOrderBy toOnChainModel(GxSearchOrderByType input) {
        switch (input) {
            case ISSUED_AT:
                return Gxs.GXSearchOrderBy.GX_SEARCH_ORDER_BY_ISSUED_AT;
            case EXPIRED_AT:
                return Gxs.GXSearchOrderBy.GX_SEARCH_ORDER_BY_EXPIRED_AT;
            case AMOUNT:
                return Gxs.GXSearchOrderBy.GX_SEARCH_ORDER_BY_AMOUNT;
            case APPLICANT:
                return Gxs.GXSearchOrderBy.GX_SEARCH_ORDER_BY_APPLICANT;
            case BENEFICIARY:
                return Gxs.GXSearchOrderBy.GX_SEARCH_ORDER_BY_BENEFICIARY;
            case STATUS:
                return Gxs.GXSearchOrderBy.GX_SEARCH_ORDER_BY_STATUS;
        }
        throw new IllegalArgumentException("Unable to map GxOrderByType to on chain model");
    }

    @Override
    public GxSearchOrderByType toOffchainModel(Gxs.GXSearchOrderBy input) {
        switch (input) {
            case GX_SEARCH_ORDER_BY_ISSUED_AT:
                return GxSearchOrderByType.ISSUED_AT;
            case GX_SEARCH_ORDER_BY_EXPIRED_AT:
                return GxSearchOrderByType.EXPIRED_AT;
            case GX_SEARCH_ORDER_BY_AMOUNT:
                return GxSearchOrderByType.AMOUNT;
            case GX_SEARCH_ORDER_BY_APPLICANT:
                return GxSearchOrderByType.APPLICANT;
            case GX_SEARCH_ORDER_BY_BENEFICIARY:
                return GxSearchOrderByType.BENEFICIARY;
            case GX_SEARCH_ORDER_BY_STATUS:
                return GxSearchOrderByType.STATUS;
        }
        throw new IllegalArgumentException("Unable to map GxOrderByType to off chain model");
    }
}
