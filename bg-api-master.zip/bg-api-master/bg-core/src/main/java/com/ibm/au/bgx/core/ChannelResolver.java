package com.ibm.au.bgx.core;


/**
 * Interface <b>ChannelResolver</b>. This interface defines the contract
 * for resolving channel information. The interface exposes only one method
 * that allows for retrieving the channel name given some form of identifier.
 * 
 * @author Dain Liffman <dainliff@au1.ibm.com>
 *
 */
public interface ChannelResolver {
	
	/**
	 * Retrieves the channel name that matches the given identifier.
	 * 
	 * @param id	a {@link String} representing an identifier for the channel.
	 * 				This argument is not expected to be {@literal null}.
	 * 
	 * @return	the name of the channel that matches <i>id</i>
	 * 
	 * @throws IllegalArgumentException		if <i>id</i> is invalid or does not
	 * 										map to any channel name.
	 */
    String get(String id);
}
