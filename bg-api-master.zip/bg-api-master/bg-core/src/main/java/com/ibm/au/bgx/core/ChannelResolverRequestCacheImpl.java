package com.ibm.au.bgx.core;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.repository.GxRequestRepository;

@Component
@Qualifier("channelResolverRequestCache")
public class ChannelResolverRequestCacheImpl implements ChannelResolver {

    @Autowired
    GxRequestRepository gxRequestRepository;


    Map<String, String> map = new HashMap<>();

    @Override
    public String get(String requestId) {
        String channelName = map.get(requestId);
        if (channelName != null) {
            return channelName;
        }

        try {
            GxRequest gxRequest = gxRequestRepository.getItem(requestId);
            channelName = gxRequest.getChannelName();
            map.put(requestId, channelName);
            return channelName;
        } catch (DataNotFoundException e) {
            // could not find request, return null
            return null;
        }
    }
}
