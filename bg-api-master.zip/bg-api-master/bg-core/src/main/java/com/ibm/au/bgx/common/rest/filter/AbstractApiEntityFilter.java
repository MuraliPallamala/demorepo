package com.ibm.au.bgx.common.rest.filter;

import com.ibm.au.bgx.model.api.filter.ApiEntityFilter;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * Class <b>AbstractApiEntityFilter</b>. This class provides an base implementation
 * of {@link ApiEntityFilter} and reduces the implementation efforts to only to those
 * methods that really require custom logic.
 * </p>
 * <p>
 * <b>NOTE:</b> for performance reason inherited classes may decide to override the
 * definition of some of these methods in this class to provide a more efficient 
 * implementation of the same functionality.
 * </p>
 * 
 * @param <T> the type of the entity being filtered.
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public abstract class AbstractApiEntityFilter<T> implements ApiEntityFilter<T> {

	/**
	 * {@inheritDoc}
	 */
    @Override
    public T filterOne(T item) {
        return this.filterOne(item, null);
    }

	/**
	 * {@inheritDoc}
	 */
    @Override
    public List<T> filterMany(List<T> items) {
       return this.filterMany(items, null);
    }

	/**
	 * {@inheritDoc}
	 */
    @Override
    public List<T> filterMany(List<T> items, BgxPrincipal principal) {

        if (items == null) {
            throw new IllegalArgumentException("Items cannot be null");
        }

        List<T> filtered = new ArrayList<>();
        for (T item : items) {
            filtered.add(this.filterOne(item, principal));
        }

        return filtered;
    }

}
