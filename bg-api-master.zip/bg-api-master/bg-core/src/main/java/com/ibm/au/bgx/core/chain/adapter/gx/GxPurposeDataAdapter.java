package com.ibm.au.bgx.core.chain.adapter.gx;

import com.google.protobuf.BoolValue;
import com.google.protobuf.DoubleValue;
import com.google.protobuf.Int32Value;
import com.google.protobuf.StringValue;
import com.google.protobuf.UInt32Value;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;

import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Data adapter to transform between the on-chain purpose and the off-chain purpose.
 *
 * @author Peter Ilfrich
 */
@Component
public class GxPurposeDataAdapter implements ChainDataAdapter<Map<String, Gxs.GxPurposeElement>, Map<String, Object>> {

    @Override
    public Map<String, Gxs.GxPurposeElement> toOnChainModel(Map<String, Object> input) {

        Map<String, Gxs.GxPurposeElement> output = new LinkedHashMap<>();
        for (String key : input.keySet()) {
            if (input.get(key) instanceof Map) {
                Map<String, Gxs.GxPurposeElement> subElement = this.toOnChainModel((Map<String, Object>) input.get(key));
                Gxs.GxPurposeElement.Builder builder = Gxs.GxPurposeElement.newBuilder();
                builder.setElementType(Gxs.GxPurposeElementType.MAP);
                builder.putAllMapValue(subElement);
                output.put(key, builder.build());
            } else {
                Gxs.GxPurposeElement.Builder builder = Gxs.GxPurposeElement.newBuilder();

                Object val = input.get(key);

                if (val instanceof Boolean) {
                    builder.setElementType(Gxs.GxPurposeElementType.BOOL);
                    builder.setBoolValue(BoolValue.newBuilder().setValue((Boolean) val).build());
                } else if (val instanceof String) {
                    builder.setElementType(Gxs.GxPurposeElementType.STRING);
                    builder.setStringValue(StringValue.newBuilder().setValue((String) val).build());
                } else if (val instanceof Double) {
                    builder.setElementType(Gxs.GxPurposeElementType.DOUBLE);
                    builder.setDoubleValue(DoubleValue.newBuilder().setValue((Double) val).build());
                } else if (val instanceof Integer) {
                    builder.setElementType(Gxs.GxPurposeElementType.INT);
                    builder.setIntValue(Int32Value.newBuilder().setValue((Integer) val).build());
                }
                output.put(key, builder.build());
            }
        }

        return output;
    }

    @Override
    public Map<String, Object> toOffchainModel(Map<String, Gxs.GxPurposeElement> input) {
        Map<String, Object> output = new LinkedHashMap<>();
        for (String key : input.keySet()) {
            Gxs.GxPurposeElement value = input.get(key);
            switch (value.getElementType()) {
                case MAP: {
                    output.put(key, this.toOffchainModel(value.getMapValueMap()));
                    break;
                }
                case INT: {
                    output.put(key, value.getIntValue().getValue());
                    break;
                }
                case DOUBLE: {
                    output.put(key, value.getDoubleValue().getValue());
                    break;
                }
                case BOOL: {
                    output.put(key, value.getBoolValue().getValue());
                    break;
                }
                case STRING: {
                    output.put(key, value.getStringValue().getValue());
                    break;
                }
            }
        }
        return output;
    }
}
