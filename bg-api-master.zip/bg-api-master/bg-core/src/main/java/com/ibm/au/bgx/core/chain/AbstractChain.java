package com.ibm.au.bgx.core.chain;

import com.ibm.au.bgx.common.rest.IdentityConfiguration;
import com.ibm.au.bgx.model.chain.ChannelSelector;
import com.ibm.au.bgx.model.exception.ChainInitializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public abstract class AbstractChain<T> {

    @Autowired
    ChannelSelector selector;

    @Autowired
    IdentityConfiguration identityConfiguration;

    protected String channelUserName;

    @PostConstruct
    public void init() {
        this.channelUserName = identityConfiguration.getFabricUser();
    }

    protected abstract T getChain(String channelUserName) throws ChainInitializationException;
}
