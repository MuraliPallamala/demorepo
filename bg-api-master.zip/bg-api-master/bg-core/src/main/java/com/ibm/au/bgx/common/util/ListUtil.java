package com.ibm.au.bgx.common.util;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This utility class will perform various operations and analysis on lists.
 *
 * @author Peter Ilfrich
 */
public class ListUtil {
	
	/**
	 * Private constructor for preventing instantiation of an instance of
	 * a class that has only static methods.
	 */
	private ListUtil() {
		
	}

    /**
     * Retrieves a diff between the oldList and newList, returning all items that have been added.
     *
     * @param oldList - the old list
     * @param newList - the current list
     * @return - a list of items that are in newList, but not in oldList
     */
    public static List<String> getAddedItems(List<String> oldList, List<String> newList) {
        
    	if (newList == null) {
    		newList = new ArrayList<>();
    	}
    	
    	return (oldList == null ? newList : newList.stream()
        			  							   .filter(el -> !oldList.contains(el))
        			  							   .collect(Collectors.toList()));
    }

    /**
     * Retrieves a diff between the oldList and newList, returning all items that have been
     * removed.
     *
     * @param oldList - the old list
     * @param newList - the current list
     * @return - a list of items that are in oldList, but not in newList
     */
    public static List<String> getRemovedItems(List<String> oldList, List<String> newList) {
        // inverting the arguments will give us the removed items
        return ListUtil.getAddedItems(newList, oldList);
    }

    /**
     * Combines the 2 lists into one eliminating any duplicate strings in the resulting list. This
     * will also omit duplicates contained within just one of the lists, not just duplicates that
     * are at the intersection between the 2 lists. The result will be sorted by retaining the sort
     * order of the 2 lists, with items from the first list coming first in the resulting list.
     *
     * @param one - the first list to add
     * @param two - the second list to add
     * @return a list containing all items from both inputs without any duplicates.
     */
    public static List<String> addAllNoDuplicates(List<String> one, List<String> two) {
        Set<String> tempSet = new LinkedHashSet<>(one);
        tempSet.addAll(two);
        return new ArrayList<>(tempSet);
    }
}
