package com.ibm.au.bgx.core.chain.adapter;

import com.google.protobuf.Timestamp;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import java.time.Instant;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class TimestampDataAdapter implements ChainDataAdapter<Timestamp, Instant> {

    @Override
    public Timestamp toOnChainModel(Instant input) {
        return Timestamp.newBuilder()
            .setSeconds(input.getEpochSecond())
            .setNanos(input.getNano())
            .build();
    }

    @Override
    public Instant toOffchainModel(Timestamp input) {
        // Return null for default instances

        if (input.getDefaultInstanceForType()
            == input) { // NOTE do not change to .equal, we want the exact object
            return null;
        }
        return Instant.ofEpochSecond(input.getSeconds(), input.getNanos());
    }
}
