package com.ibm.au.bgx.core.chain;

import com.ibm.au.bgx.core.chain.adapter.purpose.PurposeFormatDataAdapter;
import com.ibm.au.bgx.model.chain.PurposeFormatChain;
import com.ibm.au.bgx.model.exception.ChainInitializationException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;
import com.ibm.au.bgx.model.profile.PurposeFormatsAPI;
import com.ibm.au.bgx.model.shared.Common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @author Peter Ilfrich
 */
@Component
public class PurposeFormatChainImpl extends AbstractChain<PurposeFormatsAPI> implements PurposeFormatChain {

    @Autowired
    PurposeFormatDataAdapter purposeFormatDataAdapter;


    @Override
    protected PurposeFormatsAPI getChain(String channelUserName) throws ChainInitializationException {

        PurposeFormatsAPI api;

        if (channelUserName == null || channelUserName.isEmpty()) {
            throw new IllegalArgumentException(
                    "Channel user name cannot be empty.");
        }

        try {
            api = selector.getPurposeFormatApi(channelUserName);
        } catch (Exception e) {
            throw new ChainInitializationException(
                    "Could not initialize purpose format chain API", e);
        }

        return api;
    }

    @Override
    public PurposeFormat create(PurposeFormat format) throws ProfileChainException {
        if (format == null) {
            throw new IllegalArgumentException("Purpose format is a required parameter.");
        }
        if (format.getId() == null) {
            format.setId(UUID.randomUUID().toString());
        }
        try {
            PurposeFormatsAPI api = getChain(this.channelUserName);
            Common.IDValue val = api.Create(purposeFormatDataAdapter.toOnChainModel(format), false, true);
            PurposeFormat pf = purposeFormatDataAdapter.toOffchainModel(api.Get(val));
            return pf;

        } catch (Exception chainEx) {
            throw new ProfileChainException("Error creating purpose format", chainEx);
        }
    }

    @Override
    public PurposeFormat getById(String id) throws ProfileChainException {
        try {
            PurposeFormatsAPI api = getChain(this.channelUserName);
            Common.IDValue.Builder idBuilder = Common.IDValue.newBuilder();
            return purposeFormatDataAdapter.toOffchainModel(api.Get(idBuilder.setValue(id).build()));
        } catch (Exception chainEx) {
            throw new ProfileChainException("Error retrieving purpose format", chainEx);
        }
    }

    @Override
    public List<PurposeFormat> getAll() throws ProfileChainException {
        try {
            // fetch list
            PurposeFormatsAPI api = getChain(this.channelUserName);
            Common.Empty.Builder builder = Common.Empty.newBuilder();
            Common.PurposeFormatList list = api.GetAll(builder.build());

            // process the result list
            List<PurposeFormat> result = new ArrayList<>();
            for (Common.PurposeFormat format : list.getFormatsList()) {
                result.add(purposeFormatDataAdapter.toOffchainModel(format));
            }
            return result;
        } catch (Exception chainEx) {
            throw new ProfileChainException("Error retrieving all purpose formats", chainEx);
        }
    }

    @Override
    public void updateActiveStatus(String id, boolean activeStatus) throws ProfileChainException {
        try {
            // call the update
            PurposeFormatsAPI api = getChain(this.channelUserName);
            Common.PurposeFormatUpdate.Builder builder = Common.PurposeFormatUpdate.newBuilder();
            builder.setActiveStatus(activeStatus);
            builder.setFormatId(id);
            api.UpdateActiveStatus(builder.build());
        } catch (Exception chainEx) {
            throw new ProfileChainException("Error updating purpose format status", chainEx);
        }
    }
}
