package com.ibm.au.bgx.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.chain.FlowStatus;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import com.ibm.au.bgx.model.AbstractPrincipalProvider;
import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.chain.ChannelSelector;
import com.ibm.au.bgx.model.chain.ChannelUser;
import com.ibm.au.bgx.model.chain.ProfileChain;
import com.ibm.au.bgx.model.chain.profile.OrgChangeRequestManager;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.exception.DataExistsException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.notification.WebNotificationManager;
import com.ibm.au.bgx.model.pojo.BankAccount;
import com.ibm.au.bgx.model.pojo.BaseRequest.RequestType;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.notification.WebNotification.MessageType;
import com.ibm.au.bgx.model.pojo.notification.WebNotification.ReferenceType;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.repository.ChannelUserRepository;
import com.ibm.au.bgx.model.repository.OrgChangeRequestRepository;
import com.ibm.au.bgx.model.repository.OrganizationRepository;
import com.ibm.au.bgx.model.repository.UserProfileRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;

import java.util.Collections;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.PublicKey;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * This is an implementation of the organisation change-request manager. It provides methods to
 * submit new change request and handle those requests, perform changes directly that don't require
 * approval. The manager is bound to a principal and should be constructed using the BgxPrincipal.
 *
 * @author Peter Ilfrich
 */
public class OrgChangeRequestManagerImpl extends AbstractPrincipalProvider implements OrgChangeRequestManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrgChangeRequestManagerImpl.class);
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();


    private OrgChangeRequestRepository repository;

    private OrganizationRepository organizationRepository;

    private ChannelSelector channelSelector;

    private ProfileChain profileChain;

    private ChannelUserRepository channelUserRepository;

    private QueueClient queueClient;

    private UserProfileRepository userRepository;

    private OrganizationManager organizationManager;

    private WebNotificationManager notificationManager;

    private GxRequestRepository gxRequestRepository;

    /**
     * Private constructor called from the static method that is exposed publicly.
     *
     * @param principal              - the currently logged in user
     * @param repository             - the repository containing organisation change-requests
     * @param organizationRepository - the repository containing organisations
     */
    private OrgChangeRequestManagerImpl(BgxPrincipal principal,
                                        OrgChangeRequestRepository repository, OrganizationRepository organizationRepository,
                                        ChannelSelector channelSelector, ProfileChain profileChain,
                                        ChannelUserRepository channelUserRepository, QueueClient queueClient,
                                        UserProfileRepository userProfileRepository,
                                        OrganizationManager organizationManager, WebNotificationManager notificationManager, GxRequestRepository gxRequestRepository
    ) {

        super(principal);
        this.repository = repository;
        this.organizationRepository = organizationRepository;
        this.channelSelector = channelSelector;
        this.profileChain = profileChain;
        this.channelUserRepository = channelUserRepository;
        this.queueClient = queueClient;
        this.userRepository = userProfileRepository;
        this.organizationManager = organizationManager;
        this.notificationManager = notificationManager;
        this.gxRequestRepository = gxRequestRepository;
    }

    /**
     * Retrieves a new instance of the OrgChangeRequestManager, which is bound to the principal
     * passed into it.
     *
     * @param principal         - the currently logged in user
     * @param componentProvider - the component provider to avoid long constructor signatures.
     * @return - an instance of an OrgChangeRequestManager
     */
    public static OrgChangeRequestManager getComponent(BgxPrincipal principal, BgxComponentProvider componentProvider) {

        return new OrgChangeRequestManagerImpl(principal,
							                   componentProvider.getOrgChangeRequestRepository(),
							                   componentProvider.getOrganizationRepository(),
							                   componentProvider.getChannelSelector(),
							                   componentProvider.getProfileChain(),
							                   componentProvider.getChannelUserRepository(),
							                   componentProvider.getQueueClient(),
							                   componentProvider.getUserProfileRepository(),
							                   componentProvider.getOrganizationManager(),
							                   componentProvider.getWebNotificationManager(),
							                   componentProvider.getGxRequestRepository()
        );
    }

    /**
     * This method will create a local record in the offchain-db with the given request payload.
     *
     * @param request - the request object holding the data
     * @return - the org change request including its ID and revision.
     */
    @SuppressWarnings("unchecked")
    @Override
    public OrgChangeRequest createOrgChangeRequest(OrgChangeRequest request) {

        if (request.getStatus() == null) {
            request.setStatus(Status.CONFIRMED);
        }

        OrgChangeRequest req;

        // special handling for link/unlink
        if (request.getRequestType().equals(RequestType.LINK_ORGANIZATION) || request.getRequestType().equals(RequestType.UNLINK_ORGANIZATION)) {

            RelationshipInfo info = MAPPER.convertValue(request.getPayload(), RelationshipInfo.class);

            Organization sourceOrg = this.organizationRepository.getItem(request.getOrgId());
            Organization targetOrg = this.organizationRepository.getItem(info.getId());

            // do not create duplicate pending link/unlink request
            RelationshipInfo.Status pendingStatus = request.getRequestType().equals(RequestType.LINK_ORGANIZATION) ? RelationshipInfo.Status.LINK_PENDING : RelationshipInfo.Status.UNLINK_PENDING;

            for (Organization org : new Organization[]{sourceOrg, targetOrg}) {
                for (RelationshipInfo rel : org.getSettings().getRelationships()) {
                    // check if the relationship is with the other org and in status LINKED
                    if ((rel.getId().equals(sourceOrg.getId()) || rel.getId().equals(targetOrg.getId())) && rel.getStatus().equals(pendingStatus)) {

                        throw new GuaranteeForbiddenException(String.format("Cannot create a duplicate pending %s request", rel.getStatus()));
                    }
                }
            }

            req = this.repository.addItem(request);

            info.setStatus(request.getRequestType().equals(RequestType.LINK_ORGANIZATION)
                    ? RelationshipInfo.Status.LINK_PENDING : RelationshipInfo.Status.UNLINK_PENDING);

            info.setRequestId(req.getId());

            // update request with new info
            req.setPayload(MAPPER.convertValue(info, Map.class));
            req = this.repository.updateItem(req);

            // update orgs

            if (sourceOrg.getSettings().getApprovalModel() == null) {
                throw new IllegalArgumentException(String.format("Organization '%s' needs to have approval model set before linking.", sourceOrg.getProfile().getEntityName()));
            }

            if (targetOrg.getSettings().getApprovalModel() == null) {
                throw new IllegalArgumentException(String.format("Organization '%s' needs to have approval model set before linking.", targetOrg.getProfile().getEntityName()));
            }

            this.addOrgLinkInformation(req, sourceOrg, targetOrg, info);

            // send notification
            MessageType type = MessageType.LINK_CREATE;
            if (request.getRequestType().equals(RequestType.UNLINK_ORGANIZATION)) {
                type = MessageType.UNLINK_CREATE;
            }
            this.sendWebNotification(type, req, targetOrg.getId(), true);
        } else {

            try {
                // populate original profile information with name and address
                OrgProfile originalProfile = new OrgProfile();
                Organization org = this.organizationManager.getById(request.getOrgId());

                originalProfile.setEntityName(org.getProfile().getEntityName());
                originalProfile.setEntityAddress(org.getProfile().getEntityAddress());
                // add original profile information
                request.setOriginalProfile(originalProfile);
                
            } catch (ProfileChainException | ProfileNotFoundException pe) {
            	
                LOGGER.error(String.format("Could not find organisation %s due to profile chain exception", request.getOrgId()), pe);
            }

            // add it to the offchain store
            req = this.repository.addItem(request);
        }

        // add request to store
        return req;
    }

    /**
     * Adds the relationship info to the 2 given orgs.
     *
     * @param request   - the org change request for this change
     * @param sourceOrg - the source organisation (requesting org)
     * @param targetOrg - the target organisation (affected org)
     * @param info      - the relationship details including permissions
     */
    protected void addOrgLinkInformation(OrgChangeRequest request, Organization sourceOrg, Organization targetOrg, RelationshipInfo info) {

        // ensure both orgs have a relationship list
        if (sourceOrg.getSettings().getRelationships() == null) {
            sourceOrg.getSettings().setRelationships(new ArrayList<>());
        }
        if (targetOrg.getSettings().getRelationships() == null) {
            targetOrg.getSettings().setRelationships(new ArrayList<>());
        }

        // handle status
        if (request.getRequestType().equals(RequestType.LINK_ORGANIZATION)) {
            // creating new relationship objects
            LOGGER.debug(BgxLogMarkers.DEV, "Creating new relationship objects");
            RelationshipInfo sourceRel = new RelationshipInfo();
            RelationshipInfo targetRel = new RelationshipInfo();
            sourceRel.setCreatedAt(Instant.now());
            targetRel.setCreatedAt(Instant.now());
            sourceRel.setRequestId(request.getId());
            targetRel.setRequestId(request.getId());

            sourceRel.setId(this.prepareRelationshipLinkId(targetOrg));
            targetRel.setId(this.prepareRelationshipLinkId(sourceOrg));

            sourceRel.setRelatedEntityName(targetOrg.getProfile().getEntityName());
            targetRel.setRelatedEntityName(sourceOrg.getProfile().getEntityName());

            sourceRel.setRelationship(info.getRelationship());
            targetRel.setRelationship(info.getRelationship().equals(Relationship.PARENT_OF) ? Relationship.SUBSIDIARY_OF  : Relationship.PARENT_OF);

            sourceRel.setPermission(info.getPermission());
            targetRel.setPermission(info.getPermission());

            sourceRel.setStatus(RelationshipInfo.Status.LINK_PENDING);
            targetRel.setStatus(RelationshipInfo.Status.LINK_PENDING);

            sourceRel.setInitiatorFlag(true);
            targetRel.setInitiatorFlag(false);

            // updating the orgs
            sourceOrg.getSettings().getRelationships().add(sourceRel);
            targetOrg.getSettings().getRelationships().add(targetRel);

        } else {
            // update existing relationship info with new status of both orgs
            LOGGER.debug(BgxLogMarkers.DEV, "Update existing relationship info with new status of both orgs");
            for (Organization org : new Organization[]{sourceOrg, targetOrg}) {
                for (RelationshipInfo rel : org.getSettings().getRelationships()) {
                	
                    // check if the relationship is with the other org and in status LINKED
                	//
                    if ((rel.getId().equals(sourceOrg.getId()) || rel.getId().equals(targetOrg.getId())) && rel.getStatus().equals(RelationshipInfo.Status.LINKED)) {

                        // update status and requestId of this relationship
                        LOGGER.debug(BgxLogMarkers.DEV, "Updating prev {} relationship request Id {} with new {}", rel.getRelationship(), rel.getRequestId(), request.getId());

                        rel.setStatus(RelationshipInfo.Status.UNLINK_PENDING);
                        rel.setRequestId(request.getId());
                        rel.setUpdatedAt(Instant.now());

                        if (org.equals(sourceOrg)) {
                            rel.setInitiatorFlag(true);
                        } else {
                            rel.setInitiatorFlag(false);
                        }
                    }
                }
            }
        }

        // finally update both organisations with the updated relationships
        this.organizationRepository.updateItem(sourceOrg);
        this.organizationRepository.updateItem(targetOrg);
    }

    /**
     * Helper function to create relationship link ID
     */
    private String prepareRelationshipLinkId(Organization relatedOrg) {
        // relationship ID is set to the orgId of the other side of the relationship link
        return relatedOrg.getId();
    }


    /**
     * This is for NewCo admin. The method will add the given action to the request provided by the
     * requestId.
     *
     * @param requestId - the id of the org change request affected
     * @param action    - the action request including the payload
     * @return the updated org change request
     */
    @Override
    public OrgChangeRequest addNewcoAdminOrgChangeRequestAction(String requestId,
                                                                OrgRequestActionRequest action) {

        // retrieve request
        OrgChangeRequest request = getById(requestId);

        OrgRequestAction oa = new OrgRequestAction();
        oa.setActionType(action.getType());
        oa.setPayload(action.getPayload());
        oa.setId(UUID.randomUUID().toString());

        // add action to store
        if (request.getActions() == null) {
            request.setActions(new ArrayList<>());
        }
        request.getActions().add(oa);

        // execute any post action depending on the type of the action
        switch (action.getType()) {
            case RECALL:
                // just an update of data
                break;

            case CANCEL:
                // set request to abandoned
                request.setStatus(Status.ABANDONED);
                break;

            case VERIFY:
                // nothing to do, just adding the action
                break;

            case REVOKE:
                // nothing to do, just adding the action
                break;

            case REJECT:

                // set status to rejected
                request.setStatus(Status.REJECTED);
                break;

            case APPROVE:
                // perform update, post-processing handles approve action for org change
                request.setStatus(Status.APPROVED);
                break;

        }

        request = repository.updateItem(request);
        return request;
    }


    /**
     * Retrieves all org change requests for the currently logged in user.
     *
     * @return - a list of all org change requests (any status, including completed)
     */
    @Override
    public List<OrgChangeRequest> getAll() {
        LOGGER.debug(BgxLogMarkers.DEV, "Finding org change requests by org id {}", this.getPrincipal().getPrimaryOrgId());
        return this.repository.findByOrgId(this.getPrincipal().getPrimaryOrgId());
    }

    /**
     * Returns all org change requests that match the status provided as arguemnt. It will also only
     * return org change requests that belong to the organisation of the currently logged in user.
     *
     * @param status - the status to filter for
     * @return a list of org change requests.
     */
    @Override
    public List<OrgChangeRequest> getByStatus(Status status) {
        if (status == null) {
            throw new IllegalArgumentException("Parameter 'status' cannot be null.");
        }
        return this.repository.findByOrgIdAndStatus(this.getPrincipal().getPrimaryOrgId(), status);
    }

    /**
     * Returns a request by the given ID. This is just a simple repository lookup.
     *
     * @param id - the ID of the request
     * @return - the request found in the database for the given ID
     */
    @Override
    public OrgChangeRequest getById(String id) {
        return this.repository.getItem(id);
    }

    /**
     * Retrieves a list of org change requests created for a given organisation.
     *
     * @param orgId - the ID of the organisation
     * @return - a list of org change requests for this organisation
     */
    @Override
    public List<OrgChangeRequest> getByOrgId(String orgId) {
        return this.repository.findByOrgId(orgId);
    }

    /**
     * Retrieves records related to a specific org of a specific type in a specific state
     *
     * @param status - the status of the requests to retrieve
     * @param type   - the type of change request to retrieve
     * @return a list of org change requests matching the filter criteria
     */
    @Override
    public List<OrgChangeRequest> getByOrgIdStatusAndType(Status status, RequestType type) {
        return this.repository.findByOrgIdStatusAndType(getPrincipal().getPrimaryOrgId(), status.toString(), type.toString());
    }


    @Override
    public List<OrgChangeRequest> getByOrgIdAndStatus(String orgId, Status status) {
        return this.repository.findByOrgIdAndStatus(orgId, status);
    }

    /**
     * Add banking details to the currently logged in user / organisation. This will perform
     * duplicate check and add it to the offchain store.
     *
     * @param bankAccount - the bank account information to add
     * @return the updated organisation
     */
    @Override
    public Organization addBusinessAccount(BankAccount bankAccount) {

        if (bankAccount == null) {
            throw new IllegalArgumentException("Parameter 'bankAccount' cannot be null.");
        }

        Organization org = getPrincipal().getOrganization();

        if (org == null) {
            throw new IllegalArgumentException("Principal did not provide an organisation.");
        }

        if (org.getSettings().getBankAccounts() == null) {
            org.getSettings().setBankAccounts(new ArrayList<>());
        }

        // duplicate check
        for (BankAccount ba : org.getSettings().getBankAccounts()) {
            if (ba.getAccountNumber().equals(bankAccount.getAccountNumber())
                && ba.getDescription().equals(bankAccount.getDescription())
                && ba.getType().equals(bankAccount.getType())
            ) {
                throw new DataExistsException(String.format("Bank account (%s, %s, %s) already exists.",
                            								bankAccount.getType(),
                            								bankAccount.getDescription(),
                            								bankAccount.getAccountNumber()
                            				  ));
            }
        }

        bankAccount.setId(UUID.randomUUID().toString());
        bankAccount.setCreatedAt(Instant.now());
        org.getSettings().getBankAccounts().add(bankAccount);

        return organizationRepository.updateItem(org);
    }

    /**
     * Updates the current organisations business account with new information
     * @param accountId - the id of the account to modify
     * @param accountInfo - the new data of the bank account (type, description, account number)
     * @return the updated organisation record
     */
    @Override
    public Organization updateBusinessAccount(String accountId, BankAccount accountInfo) {
        if (accountInfo == null || accountId == null) {
            throw new IllegalArgumentException("Parameter 'accountInfo' and 'accountId' cannot be null");
        }

        Organization org = this.getPrincipal().getOrganization();
        if (org == null) {
            throw new IllegalArgumentException(String.format("Principal did not provide an organisation."));
        }
        // fetch existing bank account
        BankAccount existing = getAccount(org, accountId);
        if (existing == null) {
            throw new IllegalArgumentException("Account specified by 'accountId' doesn't exist.");
        }

        // overwrite values
        existing.setType(accountInfo.getType());
        existing.setAccountNumber(accountInfo.getAccountNumber());
        existing.setDescription(accountInfo.getDescription());

        // update meta information
        existing.setUpdatedAt(Instant.now());
        existing.setUpdatedBy(this.getPrincipal().getUserProfile().getId());

        // update org with updated bank account info
        return organizationRepository.updateItem(org);
    }

    /**
     * Remove banking details from the currently logged in user / organisation.
     *
     * @param accId - the internal ID of the bank account details to remove
     * @return the updated organisation
     */
    @Override
    public Organization removeBusinessAccount(String accId) {
        // resolve organisation
        Organization org = getPrincipal().getOrganization();

        // org not found
        if (org == null) {
            throw new IllegalArgumentException(String.format("Principal does not provide an organisation."));
        }

        // account number not found
        BankAccount toBeDeleted = getAccount(org, accId);
        if (toBeDeleted == null) {
            throw new IllegalArgumentException(String.format("Organization '%s' does not have a bank account with ID: %s", org.getId(), accId));
        }

        // remove the bank account
        org.getSettings().getBankAccounts().remove(toBeDeleted);

        // update organisation and return the updated record
        return this.organizationRepository.updateItem(org);
    }

    /**
     * Checks the local database if an organisation with the given id exists or not.
     *
     * @param orgId - the id of the organisation to search for
     * @return - true, if an organisation with that id exists
     */
    @Override
    public boolean checkOrganizationExists(String orgId) {
        try {
            this.organizationRepository.getItem(orgId);
            return true;
        } catch (DataNotFoundException dne) {
            return false;
        }
    }

    /**
     * Retrieves a list of org change requests affecting the org of the currently logged in user.
     *
     * @param requestStatus - optional filter for the request status (default: 'CONFIRMED')
     */
    @Override
    public List<OrgChangeRequest> getByLinkedOrgId(Status requestStatus) {
    	
        if (requestStatus == null) {
            requestStatus = Status.CONFIRMED;
        }

        return this.repository.findByLinkOrgId(getPrincipal().getPrimaryOrgId(), requestStatus);
    }

    /**
     * Executed when an org user approves a link request affecting the organisation of that user.
     *
     * @param request       - the org change request for the link
     * @param approveAction - the approve action triggering the link creation
     */
    @Override
    public OrgChangeRequest createOrganizationLink(OrgChangeRequest request, OrgRequestAction approveAction) {

        LOGGER.debug(BgxLogMarkers.DEV, "Creating organization links for request: {} and org: {}", request.getId(), request.getOrgId());

        RelationshipInfo relInfo = parseRelationshipInfo(request.getPayload());

        Organization sourceOrg = this.organizationRepository.getItem(request.getOrgId());
        Organization targetOrg = this.organizationRepository.getItem(relInfo.getId());

        if (!getPrincipal().getPrimaryOrgId().equals(targetOrg.getId())) {
            throw new RuntimeException("Only the target org can approve a link request");
        }

        // update existing relationship info status
        sourceOrg.getSettings().setRelationships(
                this.updateRelationshipsRequestApproval(sourceOrg, request.getId()));
        targetOrg.getSettings().setRelationships(
                this.updateRelationshipsRequestApproval(targetOrg, request.getId()));

        // process channel user for the relationship
        try {
            this.updateChannelUserForRelationship(sourceOrg, targetOrg, request, true);
        } catch (Exception e) {
            throw new RuntimeException("Could not process channel user for the relationship", e);
        }

        this.organizationRepository.updateItem(sourceOrg);
        this.organizationRepository.updateItem(targetOrg);

        // set user roles for parent org
        Organization parent;
        Organization subsidiary;

        // extract default roles of the subsidiary so that we can set those for the parent users
        if (relInfo.getRelationship().equals(Relationship.SUBSIDIARY_OF)) {
            parent = targetOrg;
            subsidiary = sourceOrg;
        } else {
            parent = sourceOrg;
            subsidiary = targetOrg;
        }

        // set the default roles of subsidiary for the parent users with role USER
        this.organizationManager.scheduleRoleUpdateTask(parent.getId(), subsidiary.getId(), BgxConstants.orgApprovalModelDefaultRoles);

        // Web notifications
        this.sendWebNotification(MessageType.LINK_APPROVE, request, sourceOrg.getId(), false);

        // send notification to admin or subsidiary org
        List<UserProfile> profiles = this.userRepository.getByPrimaryOrgId(subsidiary.getId());
        for (UserProfile profile : profiles) {
            if (profile.getUserRoles().containsKey(subsidiary.getId()) && profile.getUserRoles().get(subsidiary.getId()).contains(BgxConstants.ROLE_ADMIN)) {
                // send notification
                WebNotification message = new WebNotification();
                message.setMessageType(MessageType.LINK_FINISH_APPROVAL_ROLES);
                message.setReferenceType(ReferenceType.ORG_ONBOARDING_REQUEST); // [CV] TODO: Change this to  ORG_LINK_REQUEST
                message.setReferenceId(parent.getId());
                message.setActionRequired(true);
                message.setActionDone(false);
                message.setReceiverId(profile.getId());
                try {
                    this.queueClient.addWebNotification(message);
                } catch (IOException ioe) {
                    LOGGER.error("Could not add web notification to queue. Continuing.", ioe);
                }
            }
        }

        return this.addFinalRequestAction(request, approveAction);
    }

    /**
     * Executed when an org user rejects a link/unlink request affecting the organisation of that
     * user.
     *
     * @param request      - the org change request to reject
     * @param rejectAction - the reject action
     */
    @Override
    public OrgChangeRequest rejectLinkRequest(OrgChangeRequest request,
                                              OrgRequestAction rejectAction) {

        RelationshipInfo payload = parseRelationshipInfo(request.getPayload());
        Organization targetOrg = organizationRepository.getItem(payload.getId());

        if (!getPrincipal().getPrimaryOrgId().equals(targetOrg.getId())) {
            throw new RuntimeException("Only the target org can approve a link request");
        }

        // update orgs
        Organization sourceOrg = this.organizationRepository.getItem(request.getOrgId());
        this.removeOrgLinkInformation(request, sourceOrg, targetOrg);

        // send web notification
        MessageType type = MessageType.LINK_REJECT;
        if (request.getRequestType().equals(RequestType.UNLINK_ORGANIZATION)) {
            type = MessageType.UNLINK_REJECT;
        }
        this.sendWebNotification(type, request, sourceOrg.getId(), false, rejectAction.getPayload());

        return request;
    }

    /**
     * Cancels an organisation link request
     * @param request - the link request to cancel
     * @return - the updated org change request
     */
    @Override
    public OrgChangeRequest cancelOrganizationLink(OrgChangeRequest request) {
        // fetch the 2 orgs
        Organization sourceOrg = this.organizationRepository.getItem(request.getOrgId());
        Organization targetOrg = this.organizationRepository.getItem(MAPPER.convertValue(request.getPayload(), RelationshipInfo.class).getId());

        // call the method to remove the link information
        this.removeOrgLinkInformation(request, sourceOrg, targetOrg);

        // send notification to target
        MessageType type = MessageType.LINK_CANCEL;
        if (request.getRequestType().equals(RequestType.UNLINK_ORGANIZATION)) {
            type = MessageType.UNLINK_CANCEL;
        }
        this.sendWebNotification(type, request, targetOrg.getId(), false);

        // return the original request
        return request;
    }

    /**
     * Executed when an org user approves a unlink request affecting the organisation of that user.
     *
     * @param request       - the org change request for the unlink
     * @param approveAction - the approve action triggering the unlink.
     */
    @Override
    public OrgChangeRequest deleteOrganizationLink(OrgChangeRequest request,
                                                   OrgRequestAction approveAction) {

        RelationshipInfo relInfo = parseRelationshipInfo(request.getPayload());
        LOGGER.debug(BgxLogMarkers.DEV, "Deleting {} link to org {} with request Id {}",
                relInfo.getRelationship(), relInfo.getId(), relInfo.getRequestId());

        Organization sourceOrg = organizationRepository.getItem(request.getOrgId());
        Organization targetOrg = organizationRepository.getItem(relInfo.getId());

        if (!getPrincipal().getPrimaryOrgId().equals(targetOrg.getId())) {
            throw new RuntimeException("Only the target org can approve a link request");
        }

        // process channel user for the relationship
        try {
            this.updateChannelUserForRelationship(sourceOrg, targetOrg, request, false);
        } catch (Exception e) {
            throw new RuntimeException("Could not process channel user for the relationship", e);
        }

        // submit a batch job to remove roles from parent org users
        if (relInfo.getRelationship().equals(Relationship.SUBSIDIARY_OF)) {
            organizationManager.scheduleRoleUpdateTask(relInfo.getId(), request.getOrgId(), new ArrayList<>());
        } else if (relInfo.getRelationship().equals(Relationship.PARENT_OF)) {
            organizationManager.scheduleRoleUpdateTask(request.getOrgId(), relInfo.getId(), new ArrayList<>());

        }

        // update organisations
        LOGGER.debug(BgxLogMarkers.DEV, "Source org's relationships: {}", sourceOrg.getSettings().getRelationships());
        LOGGER.debug(BgxLogMarkers.DEV, "Destination org's relationships: {}", sourceOrg.getSettings().getRelationships());
        LOGGER.debug(BgxLogMarkers.DEV, "Updating org relationships");
        sourceOrg.getSettings().getRelationships().removeIf(e -> e.getId().equals(relInfo.getId()) && e.getRequestId().equals(request.getId()));
        targetOrg.getSettings().getRelationships().removeIf(e -> e.getId().equals(sourceOrg.getId()) && e.getRequestId().equals(request.getId()));

        organizationRepository.updateItem(sourceOrg);
        organizationRepository.updateItem(targetOrg);

        LOGGER.debug(BgxLogMarkers.DEV, "Source org's relationships: {}", sourceOrg.getSettings().getRelationships());
        LOGGER.debug(BgxLogMarkers.DEV, "Destination org's relationships: {}", sourceOrg.getSettings().getRelationships());
        LOGGER.debug(BgxLogMarkers.DEV, "Updated org relationships");

        this.sendWebNotification(MessageType.UNLINK_APPROVE, request, sourceOrg.getId(), false);
        return this.addFinalRequestAction(request, approveAction);
    }


    /**
     * Removes org link information
     *
     * @param request   - the org change request that was rejected or abandoned
     * @param sourceOrg - the organisation who originally triggered the request
     * @param targetOrg - the organisation that is the target of the relationship request
     */
    protected void removeOrgLinkInformation(OrgChangeRequest request, Organization sourceOrg,
                                            Organization targetOrg) {

        sourceOrg.getSettings().setRelationships(
                this.updateRelationshipsRequestCancellation(sourceOrg, request.getId()));
        targetOrg.getSettings().setRelationships(
                this.updateRelationshipsRequestCancellation(targetOrg, request.getId()));
        LOGGER.debug(BgxLogMarkers.DEV, "Updating source [{}] and target [{}] organisation", sourceOrg.getId(), targetOrg.getId());

        this.organizationRepository.updateItem(sourceOrg);
        this.organizationRepository.updateItem(targetOrg);

    }


    protected void updateChannelUserForRelationship(Organization sourceOrg, Organization targetOrg,
                                                    OrgChangeRequest request, boolean activate) throws Exception {

        RelationshipInfo sourceRelInfo = this.getRelationship(sourceOrg, request.getId());
        RelationshipInfo targetRelInfo = this.getRelationship(targetOrg, request.getId());


        if (sourceRelInfo == null || targetRelInfo == null) {
            LOGGER.warn("Relation could not be found in source Org '{}' with ID '{}'", sourceOrg.getId(), request.getId());
            return;
        }

        Organization parent;
        Organization subsidiary;
        if (sourceRelInfo.getRelationship().equals(Relationship.PARENT_OF)) {
            parent = sourceOrg;
            subsidiary = targetOrg;
        } else {
            parent = targetOrg;
            subsidiary = sourceOrg;
        }

        // Checking for one of the relation to be LINKED is enough
        if (activate) {
            this.activateChannelUserForRelationship(parent, subsidiary, request.getId());
        } else {
            this.deactivateChannelUserForRelationship(parent, subsidiary, request.getId());
        }
    }

    protected RelationshipInfo getRelationship(Organization organization, String changeRequestId) {

        for (RelationshipInfo relInfo : organization.getSettings().getRelationships()) {
            if (relInfo.getRequestId() == null) {
                throw new IllegalArgumentException(String.format("Request ID in the relationship info '%s' of org '%s' is null", relInfo.getId(), organization.getId()));
            }

            if (relInfo.getRequestId().equals(changeRequestId)) {
                return relInfo;
            }
        }

        return null;

    }

    /**
     * After an approved org link/unlink request, the list of relationships need to be updated. The
     * existing relationship info LINK_PENDING need to be updated to LINKED and UNLINK_PENDING needs
     * to be removed.
     *
     * @param org             - org to be updated with the relationship status
     * @param changeRequestId - the org change request id that allows us to find the affected item
     *                        in the list
     * @return the updated list of relationship info
     */
    protected List<RelationshipInfo> updateRelationshipsRequestApproval(Organization org,
                                                                        String changeRequestId) {

        List<RelationshipInfo> newSourceRels = new ArrayList<>();

        for (RelationshipInfo relInfo : org.getSettings().getRelationships()) {

            if (relInfo.getRequestId().equals(changeRequestId)) {

                boolean activate = false;

                switch (relInfo.getStatus()) {

                    case LINK_PENDING: 
                        LOGGER.debug(BgxLogMarkers.DEV, "Setting relationship {} to org {}", relInfo.getRelationship(), relInfo.getId());
                        // update status to linked
                        relInfo.setStatus(RelationshipInfo.Status.LINKED);
                        relInfo.setUpdatedAt(Instant.now());

                        activate = true;
                    break;

                    case UNLINK_PENDING: 
                        // will be removed
                    break;

                    default: 
                        // do nothing, will be removed (invalid status anyway)
                    break;
                    
                }

                // add relationship info (UNLINK_PENDING will be filtered out and thus removed)
                if (activate) {
                    newSourceRels.add(relInfo);
                }
            } else {
                newSourceRels.add(relInfo);
            }
        }
        return newSourceRels;
    }

    /**
     * Create or reuse existing channel user for the relationship
     */
    protected Organization activateChannelUserForRelationship(Organization parent,
                                                              Organization subsidiary, String relId) throws Exception {

        LOGGER.debug(BgxLogMarkers.DEV, "Activating channel user for parent: {}, subsidiary: {} and relationShipId: {}", parent.getId(), subsidiary.getId(), relId);

        RelationshipInfo relInfo = this.getRelationship(parent, relId);
        ChannelUser channelUser = this.getChannelUserForRelationship(parent, subsidiary, relInfo, true);

        if (channelUser == null) {
            throw new IllegalArgumentException(String.format("Could not create channel user for the organization relationship between parent %s and subsidiary %s", 
            												 parent.getId(), 
            												 subsidiary.getId()));
        }

        LOGGER.debug(BgxLogMarkers.DEV, "Using channel user: {}", channelUser.getId());

        if (channelUser.getEnrollment() == null || channelUser.getEnrollment().getCert() == null) {
        	
            throw new IllegalArgumentException("Channel user does not have enrollment.");
        }

        // active the user's public key in chain

        PublicKey publicKey = BgxEncryptionUtil.certToPublicKey(channelUser.getEnrollment().getCert());

        LOGGER.debug(BgxLogMarkers.DEV, "Activating channel user's public key in subsidiary: {} {}", subsidiary.getId(), BgxEncryptionUtil.toPem(publicKey));

        profileChain.activateKey(subsidiary.getId(), publicKey);

        // update the user to be active
        LOGGER.debug(BgxLogMarkers.DEV, "Setting channel user be active: {}", channelUser.getId());
        channelUser.setActiveStatus(true);
        this.channelUserRepository.updateItem(channelUser);

        // update parent org relInfo
        LOGGER.debug(BgxLogMarkers.DEV, "Setting channel user in parent org relationship: {}", relId);
        relInfo.setChannelUserName(channelUser.getName());

        // NOTE could miss requests that are created between searching and updating.
        // However guarantee requests + org linking occur infrequently enough that this is basically a non-issue.
        // If required a cron job could be used to maintain the visibleToChannelUsernames field
        //
        List<GxRequest> gxRequests = this.gxRequestRepository.find(subsidiary.getId(), null, null, FlowStatus.ACTIVE.value(), null, null, 100000).getResult();
        for (GxRequest gxRequest : gxRequests) {
            
        	gxRequest.getVisibleToChannelUsernames().addAll(Collections.singleton(channelUser.getName()));
            this.gxRequestRepository.forceUpdateFields(gxRequest, gxRequest.getVisibleToChannelUsernames(), 5);
        }

        return organizationRepository.updateItem(parent);
    }

    /**
     * Helper function to prepare channel username for the relationship
     *
     * We need to have it in a deterministic manner so that the same user can be reused per
     * relationship pair.
     *
     * We use SHA256 Hash of <parent id>-<subsidiary id> because otherwise the id is more that 64
     * characters long and fabric CA does not allow to create a user with that username
     */
    private String prepareChannelUserNameForRelationShip(final Organization parent,
                                                         final Organization subsidiary,
                                                         final RelationshipInfo relInfo) {

        String userRelId = String.format("%s-%s", parent.getId(), subsidiary.getId());

        // Hash it so that it becomes 64 character long and unique (it is very unlikely to have a collision for sha256)
        return DigestUtils.sha256Hex(userRelId.getBytes());

    }

    /**
     * Helper function to retrieve the channel user for org relationship
     */
    protected ChannelUser getChannelUserForRelationship(Organization parent,
                                                        Organization subsidiary, RelationshipInfo relInfo, boolean createIfNotExist) {

        // try to retrieve the channel user for the link ( if the link has to be re-established)
        ChannelUser channelUser = null;

        String channelUserName = relInfo.getChannelUserName();
        if (createIfNotExist && (channelUserName == null || channelUserName.isEmpty())) {
            channelUserName = this
                    .prepareChannelUserNameForRelationShip(parent, subsidiary, relInfo);
        }

        try {

            if (createIfNotExist) {
                channelUser = this.channelSelector.getEnrolledUser(channelUserName, parent.getId(), true);

                // set the relationship information in the meta if the user is created
                if (channelUser.getMeta() == null) {
                    channelUser.setMeta(new HashMap<>());
                }

                channelUser.getMeta().put(BgxConstants.FABRIC_USER_RELATIONSHIP_ID, relInfo.getId()); // maybe unnecessary because it is same as subsidiary Id

                channelUser.getMeta().put(BgxConstants.FABRIC_USER_SUBSIDIARY_ORG_ID, subsidiary.getId());

                channelUser = this.channelUserRepository.updateItem(channelUser);
            } else {
                channelUser = this.channelSelector.getUser(channelUserName, parent.getId(), false);
            }

        } catch (Exception e) {
            throw new IllegalArgumentException(String.format("Could not get channel user for relationship for parent %s and relation %s", parent.getId(), relInfo.getId()), e);
        }

        return channelUser;
    }

    /**
     * Unset the channel user for the relationship
     *
     * Currently we just nullify the channelUserName from the relationshipInfo and keep the user
     * record in deactivated state if the user exists
     *
     * If the channe user is not found, the method ignores the channel user processing
     */
    protected Organization deactivateChannelUserForRelationship(Organization parent,
                                                                Organization subsidiary, String relId) {

        LOGGER.debug(BgxLogMarkers.DEV, "Deactivating channel user for parent: {}, subsidiary: {} and relationShipId: {}", parent.getId(), subsidiary.getId(), relId);

        try {
            RelationshipInfo relInfo = this.getRelationship(parent, relId);

            ChannelUser channelUser = this
                    .getChannelUserForRelationship(parent, subsidiary, relInfo, false);

            if (channelUser == null) {
                LOGGER.warn(BgxLogMarkers.DEV, "Channel user could not be found and cannot be deactivated in chain.");
            }

            if (channelUser != null) {

                LOGGER.debug(BgxLogMarkers.DEV, "Using channel user: {}", channelUser.getId());

                // deactivate the user

                LOGGER.debug(BgxLogMarkers.DEV, "Deactivating channel user: {}", channelUser.getId());

                channelUser.setActiveStatus(false);
                this.channelUserRepository.updateItem(channelUser);

                if (channelUser.getEnrollment() == null
                        || channelUser.getEnrollment().getCert() == null) {
                    throw new IllegalArgumentException("Channel user does not have enrollment.");
                }

                // deactivate the user's public key in chain
                PublicKey publicKey = BgxEncryptionUtil
                        .certToPublicKey(channelUser.getEnrollment().getCert());

                LOGGER.debug(BgxLogMarkers.DEV, "Deactivating channel user's public key in subsidiary: {} {}", subsidiary.getId(), BgxEncryptionUtil.toPem(publicKey));

                this.profileChain.deactivateKey(subsidiary.getId(), publicKey);
            }

            // update parent org relInfo
            relInfo.setChannelUserName(null);
            return this.organizationRepository.updateItem(parent);

        } catch (Exception e) {
            throw new IllegalArgumentException(String.format("Could not deactivate channel user for org relationship : %s", relId), e);
        }

    }

    protected List<RelationshipInfo> updateRelationshipsRequestCancellation(Organization org,
                                                                            String requestId) {

        List<RelationshipInfo> result = new ArrayList<>();
        for (RelationshipInfo relInfo : org.getSettings().getRelationships()) {

            boolean activate = false;
            if (relInfo.getRequestId().equals(requestId)) {
                switch (relInfo.getStatus()) {
                    case UNLINK_PENDING: 
                        // revert change to LINKED
                        relInfo.setStatus(RelationshipInfo.Status.LINKED);
                        activate = true;
                    break;

                    case LINK_PENDING: 
                        // do nothing, this will remove the link
                    break;
                    
                    default: 
                        // do nothing
                    break;
                    
                }
            } else {
                activate = true;
            }

            if (activate) {
                result.add(relInfo);
            }
        }
        return result;
    }


    /**
     * Adds a final action to the given request and updates its status to APPROVED, REJECTED or
     * ABANDONED.
     *
     * @param request     - the request to update
     * @param finalAction - the final action to add
     * @return the updated org change request
     */
    @Override
    public OrgChangeRequest addFinalRequestAction(OrgChangeRequest request,
                                                  OrgRequestAction finalAction) {
        // add action to request
        if (finalAction.getId() == null) {
            finalAction.setId(UUID.randomUUID().toString());
        }
        finalAction.setCreatedAt(Instant.now());

        switch (finalAction.getActionType()) {
            case APPROVE	:  	request.setStatus(Status.APPROVED);  	break;
            case REJECT		:	request.setStatus(Status.REJECTED); 	break;
            case CANCEL		: 	request.setStatus(Status.ABANDONED);	break;
            case RECALL		: 	break; 	// nothing required, just adding the action
            default:
                LOGGER.error("Invalid action type provided to final request action");
                throw new IllegalArgumentException("Invalid action type");
            
        }

        if (request.getActions() == null) {
            request.setActions(new ArrayList<>());
        }
        request.getActions().add(finalAction);

        return this.repository.updateItem(request);
    }


    /**
     * Parses the request payload of an org change request and returns a RelationShipInfo object,
     * which is the parsed request payload. If the payload cannot be parsed, an
     * IllegalArgumentException is throw.
     *
     * @param requestPayload - the org change request payload as a map.
     */
    protected RelationshipInfo parseRelationshipInfo(Map<String, Object> requestPayload) {
        
    	try {
            return MAPPER.convertValue(requestPayload, RelationshipInfo.class);
            
        } catch (Exception e) {
            
        	throw new IllegalArgumentException("Could not de/serialise request payload", e);
        }
    }

    /**
     * Retrieves the bank account with the given id from the provided organisation.
     *
     * @param organization - the organisation potentially holding the account in question
     * @param accountId    - the id of the account to retrieve
     * @return the account with the given ID from the provided organisation or null if it cannot be
     * found.
     */
    protected BankAccount getAccount(Organization organization, String accountId) {
        if (organization.getSettings().getBankAccounts() == null) {
            return null;
        }

        for (BankAccount acc : organization.getSettings().getBankAccounts()) {
            if (acc.getId().equals(accountId)) {
                return acc;
            }
        }

        return null;
    }

    protected void sendWebNotification(MessageType type, OrgChangeRequest changeRequest, String receivingOrgId, boolean actionRequired) {
        this.sendWebNotification(type, changeRequest, receivingOrgId, actionRequired, null);
    }

    protected void sendWebNotification(MessageType type, OrgChangeRequest changeRequest, String receivingOrgId, boolean actionRequired, Map<String, Object> payload) {

        // create notification
        WebNotification notification = new WebNotification();
        notification.setMessageType(type);
        notification.setReferenceId(changeRequest.getId());
        notification.setActionRequired(actionRequired);
        notification.setPayload(payload);
        
        if (actionRequired) {
            notification.setActionDone(false);
        }

        Organization detailsOrg = null;

        // find out the sub-type of reference
        switch (changeRequest.getRequestType()) {
            case CHANGE_DETAILS: 
                notification.setReferenceType(ReferenceType.ORG_UPDATE_REQUEST);
                try {
                    detailsOrg = this.organizationManager.getById(changeRequest.getOrgId());
                } catch (ProfileChainException | ProfileNotFoundException e) {
                    LOGGER.error(String.format("Could not find organization %s", changeRequest.getOrgId()), e);
                }
            break;
            
            default: 
                // for link and unlink - CAREFUL: CHANGE_STATUS case for disabling/enabling orgs??
                notification.setReferenceType(ReferenceType.ORG_LINK_REQUEST);
                RelationshipInfo info = MAPPER.convertValue(changeRequest.getPayload(), RelationshipInfo.class);
                String otherOrgId = info.getId();
                if (info.getId().equals(receivingOrgId)) {
                    otherOrgId = changeRequest.getOrgId();
                }
                detailsOrg = this.organizationRepository.getItem(otherOrgId);

                // add link type depending on the notification type, the correct linkType will be inserted
                this.notificationManager.addLinkType(notification, changeRequest);
             break;
            
        }

        if (detailsOrg != null) {
            this.notificationManager.addEntityInformation(notification, detailsOrg.getProfile());
        }

        // send it
        try {
            this.queueClient.addWebNotification(notification, receivingOrgId);
        } catch (IOException e) {
            LOGGER.error("Failed to send web notification: {}", notification);
            LOGGER.error("Could not send web notification", e);
        }
    }
}

