package com.ibm.au.bgx.common.audit;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.rest.filter.OrgProfileFilter;
import com.ibm.au.bgx.common.rest.filter.OrgProfileRequestFilter;
import com.ibm.au.bgx.common.rest.filter.OrganizationFilter;
import com.ibm.au.bgx.common.rest.filter.UserProfileFilter;
import com.ibm.au.bgx.common.util.TimeZoneUtil;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.Entity;
import com.ibm.au.bgx.model.approvalmodel.ApprovalModel;
import com.ibm.au.bgx.model.audit.AuditConstants;
import com.ibm.au.bgx.model.audit.AuditManager;
import com.ibm.au.bgx.model.audit.AuditParameter;
import com.ibm.au.bgx.model.chain.gx.GxManager;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.BankAccount;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Role;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.api.request.UserProfileRequest;
import com.ibm.au.bgx.model.pojo.audit.AuditEvent;
import com.ibm.au.bgx.model.pojo.audit.UserPermission;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import com.ibm.au.bgx.model.pojo.system.SystemActionType;
import com.ibm.au.bgx.model.repository.AuditEventRepository;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.repository.OrgChangeRequestRepository;
import com.ibm.au.bgx.model.repository.OrgProfileRequestRepository;
import com.ibm.au.bgx.model.repository.OrganizationRepository;
import com.ibm.au.bgx.model.repository.UserProfileRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.opencsv.CSVWriter;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

/**
 * The Audit Manager handles tracking and retrieval of audit events. It offers packing and unpacking
 * of audit event payloads to avoid storing personal data directly in the audit trail. Additionally,
 * the manager offers interfaces to retrieve audit events filtering by organisation, user or
 * guarantee.
 *
 * @author Peter Ilfrich
 */
@Component
public class AuditManagerImpl implements AuditManager {

    private static final String LOOKUP_MAP_PREFIX_ORG = "org_";
    private static final String LOOKUP_MAP_PREFIX_ONBOARDING_REQUEST = "onboarding_";

    private static final List<SystemActionType> GUARNTEE_RELATED_ACTIONS = Arrays.asList(
    		SystemActionType.START_ISSUE_GUARANTEE,
            SystemActionType.START_AMEND_GUARANTEE,
            SystemActionType.START_TRANSFER_GUARANTEE,
            SystemActionType.START_CANCEL_GUARANTEE,
            SystemActionType.START_PAYWALK_GUARANTEE,
            SystemActionType.START_DEMAND_GUARANTEE,
            SystemActionType.APPROVE_ISSUE_GUARANTEE,
            SystemActionType.APPROVE_AMEND_GUARANTEE,
            SystemActionType.APPROVE_TRANSFER_GUARANTEE,
            SystemActionType.APPROVE_CANCEL_GUARANTEE,
            SystemActionType.APPROVE_DEMAND_GUARANTEE,
            SystemActionType.REVOKE_APPROVE_AMEND,
            SystemActionType.REVOKE_APPROVE_CANCEL,
            SystemActionType.REVOKE_APPROVE_ISSUE,
            SystemActionType.REVOKE_APPROVE_TRANSFER,
            SystemActionType.CANCEL_ISSUE_GUARANTEE,
            SystemActionType.CANCEL_AMEND_GUARANTEE,
            SystemActionType.CANCEL_TRANSFER_GUARANTEE,
            SystemActionType.CANCEL_CANCEL_GUARANTEE,
            SystemActionType.CANCEL_DEMAND_GUARANTEE,
            SystemActionType.REJECT_ISSUE_GUARANTEE,
            SystemActionType.REJECT_TRANSFER_GUARANTEE,
            SystemActionType.REJECT_AMEND_GUARANTEE,
            SystemActionType.REJECT_CANCEL_GUARANTEE,
            SystemActionType.REJECT_DEMAND_GUARANTEE,
            SystemActionType.DEFER_DEMAND_GUARANTEE,
            SystemActionType.RECALL_ISSUE_GUARANTEE,
            SystemActionType.RECALL_AMEND_GUARANTEE,
            SystemActionType.RECALL_TRANSFER_GUARANTEE,
            SystemActionType.RECALL_CANCEL_GUARANTEE,
            SystemActionType.RECALL_DEMAND_GUARANTEE
    );
    private static final List<SystemActionType> ORGANIZATION_RELATED_ACTIONS = Arrays.asList(
    		SystemActionType.SUBMIT_ORG_ONBOARDING,
            SystemActionType.UPDATE_ORG_ONBOARDING,
            SystemActionType.REJECT_ORG_ONBOARDING,
            SystemActionType.CANCEL_ORG_ONBOARDING,
            SystemActionType.RECALL_ORG_ONBOARDING,
            SystemActionType.VERIFY_ORG,
            SystemActionType.REVOKE_VERIFY_ORG,
            SystemActionType.APPROVE_ORG_ONBOARDING,
            SystemActionType.REJECT_ORG_ONBOARDING,
            SystemActionType.SUBMIT_ORG_CHANGE_REQUEST,
            SystemActionType.CANCEL_ORG_CHANGE_REQUEST,
            SystemActionType.RECALL_ORG_CHANGE_REQUEST,
            SystemActionType.VERIFY_ORG_CHANGE,
            SystemActionType.REVOKE_VERIFY_ORG_CHANGE,
            SystemActionType.APPROVE_ORG_CHANGE,
            SystemActionType.REJECT_ORG_CHANGE,
            SystemActionType.SUBMIT_ORG_LINK_REQUEST,
            SystemActionType.CANCEL_ORG_LINK_REQUEST,
            SystemActionType.APPROVE_ORG_LINK_REQUEST,
            SystemActionType.REJECT_ORG_LINK_REQUEST,
            SystemActionType.RECALL_ORG_LINK_REQUEST,
            SystemActionType.UPDATE_BUSINESS_ACCOUNT,
            SystemActionType.ADD_BUSINESS_ACCOUNT,
            SystemActionType.DELETE_BUSINESS_ACCOUNT,
            SystemActionType.UPDATE_APPROVAL_MODEL
    );
    private static final List<SystemActionType> USER_RELATED_ACTIONS = Arrays.asList(
    		SystemActionType.SUBMIT_USER_ONBOARDING,
            SystemActionType.UPDATE_USER_ONBOARDING,
            SystemActionType.APPROVE_USER_ONBOARDING,
            SystemActionType.REJECT_USER_ONBOARDING,
            SystemActionType.CANCEL_USER_ONBOARDING,
            SystemActionType.RECALL_USER_ONBOARDING,
            SystemActionType.UPDATE_USER_PASSWORD,
            SystemActionType.UPDATE_USER_DETAILS,
            SystemActionType.UPDATE_USER_STATUS,
            SystemActionType.ADD_USER_ROLE,
            SystemActionType.DELETE_USER,
            SystemActionType.DELETE_USER_ROLE,
            SystemActionType.SET_USER_AUTH_CODE,
            SystemActionType.VERIFY_PRIMARY,
            SystemActionType.VERIFY_ADMIN,
            SystemActionType.REVOKE_VERIFY_PRIMARY,
            SystemActionType.REVOKE_VERIFY_ADMIN
    );

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();
    private static final Logger LOGGER = LoggerFactory.getLogger(AuditManagerImpl.class);

    @Autowired
    private ApplicationContext context;

    @Autowired
    private AuditEventRepository repository;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private OrgChangeRequestRepository orgChangeRequestRepository;

    @Autowired
    private OrgProfileRequestRepository orgProfileRequestRepository;

    @Autowired
    private GxRequestRepository gxRequestRepository;

    @Autowired
    private OrganizationFilter organizationFilter;

    @Autowired
    private OrgProfileRequestFilter orgProfileRequestFilter;

    @Autowired
    private UserProfileFilter userProfileFilter;

    @Autowired
    private OrgProfileFilter orgProfileFilter;

    @Override
    public List<AuditEvent> getByOrg(String orgId, String type, String beforeDate,
                                     String afterDate) {
        if (type == null) {
            return this.repository.findByOrgId(orgId, beforeDate, afterDate);
        }

        return this.repository.findByTypeAndOrgId(type, orgId, beforeDate, afterDate);
    }

    @Override
    public List<AuditEvent> getByTargetOrgId(String targetOrgId, String type, String beforeDate, String afterDate) {
        if (type == null) {
            return this.repository.findByTargetOrgId(targetOrgId, beforeDate, afterDate);
        }

        return this.repository.findByTypeAndTargetOrgId(type, targetOrgId, beforeDate, afterDate);
    }

    @Override
    public List<AuditEvent> getByUser(String orgId, String userId, String beforeDate,
                                      String afterDate) {
        return this.repository.findByUser(orgId, userId, beforeDate, afterDate);
    }

    @Override
    public List<AuditEvent> getByGuarantee(String gxId, String beforeDate, String afterDate) {
        return this.repository.findByGuarantee(gxId, beforeDate, afterDate);
    }

    @Override
    public void logAuditEvent(String eventType, String orgId, String userId, String gxId,
                              Map<String, Object> data) {
        if (data == null) {
            data = new HashMap<>();
        }

        if (gxId != null) {
            data.put(AuditConstants.AUDIT_DATA_GX, gxId);
        }

        this.logAuditEvent(eventType, orgId, userId, data);

    }

    @Override
    public void logAuditEvent(String eventType, String orgId, String userId,
                              Map<String, Object> data) {
        AuditEvent ev = new AuditEvent();
        ev.setType(eventType);
        ev.setOrgId(orgId);
        ev.setData(data);
        ev.setUserId(userId);
        this.logAuditEvent(ev);
    }

    @Override
    public void logAuditEvent(AuditEvent event) {
        // set created by
        if (event.getUserId() != null) {
            event.setCreatedBy(event.getUserId());
        }
        // pack data
        this.packData(event);
        // store item
        repository.addItem(event);
    }

    // [CV] TODO: why we don't have types such as  GUARANTEE and ONBOARDING_ACTION?
    protected String determineEntityType(Entity entity) {
        String type = null;
        if (entity instanceof OrgChangeRequest) {
            type = AuditConstants.ORG_CHANGE_REQUEST;
        } else if (entity instanceof UserProfile) {
            type = AuditConstants.USER_PROFILE;
        } else if (entity instanceof Organization) {
            type = AuditConstants.ORGANIZATION;
        } else if (entity instanceof BankAccount) {
            type = AuditConstants.BUSINESS_ACCOUNT;
        } else if (entity instanceof Role) {
            type = AuditConstants.ROLE;
        } else if (entity instanceof ApprovalModel) {
            type = AuditConstants.APPROVAL_MODEL;
        } else if (entity instanceof OrgProfileRequest) {
            type = AuditConstants.ORG_ONBOARDING_REQUEST;
        } else if (entity instanceof GxRequest) {
            type = AuditConstants.GX_REQUEST;
        }
        return type;
    }

    @Override
    public void packData(AuditEvent event) {
        if (event.getData() == null) {
            return;
        }

        Map<String, Object> result = new HashMap<>();

        // check the passed in data for off-chain documents
        for (Entry<String, Object> entry : event.getData().entrySet()) {
            // let's extract some data
            Object value = entry.getValue();
            String key = entry.getKey();

            LOGGER.debug("Setting audit data with key {}",key);

            if (entry.getValue() instanceof Entity) {
                Entity entity = (Entity) value;
                // this is an off-chain document, check the type against our constants
                String type = this.determineEntityType(entity);

                // add the id with the type as audit parameter
                if (type != null) {
                    result.put(key, new AuditParameter(type, entity.getId()));
                } else {
                    // need to pay attention to this, potentially make it a `warn`
                    LOGGER.error("Unknown data object found in payload: {}", entity);
                    result.put(key, new AuditParameter(entity.getClass().getTypeName(), entity.getId()));
                }
            } else if (value instanceof Gx) {
                // guarantee
                result.put(key, new AuditParameter(AuditConstants.GUARANTEE, ((Gx) value).getId()));
            } else if (value instanceof OrgRequestAction) {
                result.put(key, new AuditParameter(AuditConstants.ONBOARDING_ACTION, ((OrgRequestAction) value).getId()));
            } else {
                // this also covers the case, where we have already packed the data before
                LOGGER.debug("Setting audit data{} with value {}",key, value);
                result.put(key, value);
            }
        }

        event.setData(result);
    }
    // [CV] TODO: why we don't have types such as  GUARANTEE and ONBOARDING_ACTION?
    protected Object lookupEntry(AuditParameter param, BgxPrincipal principal) {
        Object o = param;
        try {
        	
        	
            switch (param.getType()) {
                case AuditConstants.ORGANIZATION: {
                    o = this.organizationFilter.filterOne(organizationRepository.getItem(param.getId()), principal);
                    break;
                }
                case AuditConstants.ORG_CHANGE_REQUEST: {
                    o = this.orgChangeRequestRepository.getItem(param.getId());
                    break;
                }
                case AuditConstants.USER_PROFILE: {
                    try {
                        o = this.userProfileFilter.filterOne(userProfileRepository.getItem(param.getId()), principal);
                    } catch (Exception e) {
                        // not found
                        o = new UserProfile();
                        ((UserProfile) o).setId(param.getId());
                        ((UserProfile) o).setFirstName("Deleted");
                        ((UserProfile) o).setLastName("User");
                    }
                    break;
                }
                case AuditConstants.ORG_ONBOARDING_REQUEST: {
                    o = this.orgProfileRequestFilter.filterOne(orgProfileRequestRepository.getItem(param.getId()), principal);
                    break;
                }
                case AuditConstants.GUARANTEE: {
                    o = ((GxManager) this.context.getBean("appBenGxManager", principal)).get(param.getId());
                    break;
                }
                case AuditConstants.GX_REQUEST: {
                    o = this.gxRequestRepository.getItem(param.getId());
                    break;
                }
                default: {
                    LOGGER.error("Tried to lookup unsupported parameter type.");
                    break;
                }
            }
        } catch (RuntimeException re) {
            // document not found
            o = String.format("Document '%s' not found", param.getId());
        }

        return o;
    }

    protected Object extractValueFromAuditData(Object value, Map<String, Object> lookupMap, BgxPrincipal principal) {
        // this is a potential audit parameter
        if (value instanceof LinkedHashMap) {
        	
            @SuppressWarnings("rawtypes")
			LinkedHashMap paramMap = (LinkedHashMap) value;

            // check if it has the correct fields
            if (paramMap.containsKey("type") && paramMap.containsKey("id")
                    && paramMap.size() == 2) {

                // this is an audit param
                AuditParameter param = MAPPER.convertValue(paramMap, AuditParameter.class);
                Object o;

                String objectId = param.getId();
                if (param.getType().equals(AuditConstants.ORGANIZATION)) {
                    objectId = LOOKUP_MAP_PREFIX_ORG + objectId;
                } else if (param.getType().equals(AuditConstants.ORG_ONBOARDING_REQUEST)) {
                    objectId = LOOKUP_MAP_PREFIX_ONBOARDING_REQUEST + objectId;
                }

                // check if we already have looked up the element
                if (lookupMap.containsKey(objectId)) {
                    // we already ran the lookup for the document
                    o = lookupMap.get(objectId);
                } else {
                    // we haven't run the lookup yet
                    o = this.lookupEntry(param, principal);

                    // add item to lookup map
                    lookupMap.put(objectId, o);
                }
                return o;
            } else {
                // map, but no audit parameter
                return value;
            }
        } else {
            // no audit parameter
            return value;
        }
    }

    @Override
    public void unpackData(AuditEvent event, Map<String, Object> lookupMap, BgxPrincipal principal) {
        if (event.getData() == null) {
            return;
        }

        if (lookupMap == null) {
            lookupMap = new HashMap<>();
        }

        Map<String, Object> result = new HashMap<>();
        // handle base fields like userId and orgId
        if (event.getOrgId() != null) {
            if (!lookupMap.containsKey(event.getOrgId())) {
                lookupMap.put(event.getOrgId(), organizationFilter.filterOne(organizationRepository.getItem(event.getOrgId()), principal));
            }
            event.setOrgName(((Organization) lookupMap.get(event.getOrgId())).getProfile().getEntityName());
        }

        if (event.getUserId() != null) {

            if (!lookupMap.containsKey(event.getUserId())) {
                if (event.getUserId().equals(BgxConstants.SYSTEM_USER)) {
                    // create fake profile for system user
                    UserProfile fakeProfile = new UserProfile();
                    fakeProfile.setId(BgxConstants.SYSTEM_USER);
                    fakeProfile.setFirstName("System");
                    fakeProfile.setLastName("");
                    lookupMap.put(event.getUserId(), fakeProfile);
                } else {
                    UserProfile profile = this.userProfileFilter.filterOne(userProfileRepository.getItem(event.getUserId()), principal);
                    if (principal != null
                        && principal.getConfiguredForOrgId() != null
                        && principal.getConfiguredForOrgId().equals(profile.getPrimaryOrgId())) {

                        lookupMap.put(event.getUserId(), profile);

                    } else {
                        // create fake profile for anonymous user
                        UserProfile fakeProfile = new UserProfile();
                        fakeProfile.setId(BgxConstants.ANONYMOUS_USER);
                        fakeProfile.setFirstName("Anonymous");
                        fakeProfile.setLastName("");
                        lookupMap.put(event.getUserId(), fakeProfile);

                        // Note: It is overwriting the actual value.
                        event.setUserId(BgxConstants.ANONYMOUS_USER);
                    }
                }
            }

            if (lookupMap.containsKey(event.getUserId())
                && lookupMap.get(event.getUserId()) instanceof UserProfile) {

                UserProfile profile = (UserProfile) lookupMap.get(event.getUserId());
                event.setUserName(
                    String.format("%s %s", profile.getFirstName(), profile.getLastName()));

                event.setUserId(profile.getId()); // required if we have overwritten actual with ANONYMOUS
            }
        }

        // handle payload
        for (Entry<String, Object> entry : event.getData().entrySet()) {
            String key = entry.getKey();
            Object value = this.extractValueFromAuditData(entry.getValue(), lookupMap, principal);
            result.put(key, value);
        }

        event.setData(result);
    }

    @Override
    public List<AuditEvent> unpackData(List<AuditEvent> events, BgxPrincipal principal) {
        LOGGER.debug("Unpacking {} audit events", events.size());
        Map<String, Object> lookupMap = new HashMap<>();
        List<AuditEvent> result = new ArrayList<>();
        for (AuditEvent event : events) {
            unpackData(event, lookupMap, principal);
            result.add(event);
        }
        return result;
    }

    @Override
    public void writeCsv(List<AuditEvent> events, OutputStream writeStream, BgxPrincipal principal) throws IOException {
        // make sure the events are unpacked
        events = this.unpackData(events, principal);
        Map<String, String> displayNameLookupMap = createDisplayNameLookup(events);

        // create the csv writer with the passed output stream
        CSVWriter writer = new CSVWriter(new OutputStreamWriter(writeStream));

        // space for 4 parameters and base data
        String[] headers = new String[]{"id", "datetime", "type", "organisation", "user",
                "parameter1", "value1", "parameter2", "value2", "parameter3", "value3", "parameter4",
                "value4"};

        writer.writeNext(headers);
        for (AuditEvent event : events) {
            writer.writeNext(this.serializeAuditEvent(event, displayNameLookupMap));
        }

        writer.close();
    }

    @Override
    public void writePermCsv(String orgId, List<UserPermission> permissions, OutputStream writeStream) throws IOException {

        List<String> allRoles = new ArrayList<>();
        allRoles.addAll(Arrays.asList("ADMIN", "USER", "PRIMARY"));
        for (UserPermission perm : permissions) {
            for (String role : perm.getRoles()) {
                if (!allRoles.contains(role)) {
                    allRoles.add(role);
                }
            }
        }

        int baseColumnCount = 7;
        Map<String, Organization> organizationCache = new HashMap<>();

        String[] headers = new String[allRoles.size() + baseColumnCount];
        headers[0] = "userId";
        headers[1] = "status";
        headers[2] = "name";
        headers[3] = "phone";
        for (int index = 4; index <= allRoles.size() + 3; index += 1) {
            headers[index] = allRoles.get(index - 4);
        }
        headers[4 + allRoles.size()] = "gxLimit";
        headers[5 + allRoles.size()] = "organisation";
        headers[6 + allRoles.size()] = "businessId";

        // create the csv writer with the passed output stream
        CSVWriter writer = new CSVWriter(new OutputStreamWriter(writeStream));
        writer.writeNext(headers);

        // write users
        for (UserPermission perm : permissions) {
            String[] value = new String[allRoles.size() + baseColumnCount];
            // user base data
            value[0] = perm.getUserId();
            value[1] = perm.getStatus();
            value[2] = perm.getName();
            value[3] = perm.getPhone();

            // add role information
            for (int index = 4; index <= allRoles.size() + 3; index += 1) {
                String currentRole = allRoles.get(index - 4);
                if (perm.getRoles().contains(currentRole)) {
                    value[index] = "Y";
                } else {
                    value[index] = "N";
                }
            }

            // add gx limit
            if (perm.getGxLimit() != null) {
                value[4 + allRoles.size()] = Double.toString(perm.getGxLimit());
                if (perm.getGxLimit() == -1.0) {
                    value[4 + allRoles.size()] = "No Limit";
                }
            } else {
                value[4 + allRoles.size()] = "n/a";
            }

            // add organisation information
            if (perm.getOrgId() != null) {
                Organization org = organizationCache.get(perm.getOrgId());
                if (org == null) {
                    org = this.organizationRepository.getItem(perm.getOrgId());
                    organizationCache.put(perm.getOrgId(), org);
                }
                value[5 + allRoles.size()] = org.getProfile().getEntityName();
                value[6 + allRoles.size()] = org.getProfile().getBusinessId();
            } else {
                value[5 + allRoles.size()] = "";
                value[6 + allRoles.size()] = "";
            }

            writer.writeNext(value);
        }

        writer.close();
    }

    @Override
    public List<AuditEvent> filterByTopic(List<AuditEvent> events, String topicFilter) {
        // determine the list of allowed actions depending on the provided type
        List<SystemActionType> allowedActions;
        switch (topicFilter) {
            case TOPIC_ORGANIZATION: {
                allowedActions = ORGANIZATION_RELATED_ACTIONS;
                break;
            }
            case TOPIC_USER: {
                allowedActions = USER_RELATED_ACTIONS;
                break;
            }
            case TOPIC_GX: {
                allowedActions = GUARNTEE_RELATED_ACTIONS;
                break;
            }
            default: {
                // invalid filter or no filter present, just return unfiltered result
                return events;
            }
        }

        // robustness check
        if (allowedActions == null) {
            return events;
        }
        // filter events by type
        return events.stream().filter(ev -> allowedActions.contains(SystemActionType.fromValue(ev.getType()))).collect(Collectors.toList());
    }

    @Override
    public List<UserPermission> getOrgUserPermissions(String orgId, String atDate,
        boolean subsidiaryFlag, BgxPrincipal principal) {

        List<AuditEvent> events = this.getOrgUserPermissionEvents(orgId, atDate, null);

        // construct the user permissions and return them
        Map<String, UserPermission> userPermissionMap = this.createUserPermissionMap(events, subsidiaryFlag, principal);
        List<UserPermission> result = new ArrayList<>();
        result.addAll(userPermissionMap.values());
        return result;
    }

    @Override
    public List<AuditEvent> getOrgUserPermissionEvents(String orgId, String beforeDate, String afterDate) {

        // find initial user creation (set password)
        List<AuditEvent> events = this.repository.findByTypeAndOrgId(SystemActionType.UPDATE_USER_STATUS.toString(), 
        															 orgId,
        															 beforeDate, 
        															 afterDate);
        // find initial user creation (set password)
        events.addAll(this.repository.findByTypeAndOrgId(SystemActionType.UPDATE_USER_DETAILS.toString(), 
        												 orgId,
        												 beforeDate, 
        												 afterDate));
        // adding user roles
        events.addAll(this.repository.findByTypeAndOrgId(SystemActionType.ADD_USER_ROLE.toString(), 
        												 orgId, 
        												 beforeDate,
        												 afterDate));
        // removing user roles
        events.addAll(this.repository.findByTypeAndOrgId(SystemActionType.DELETE_USER_ROLE.toString(), 
        												 orgId, 
        												 beforeDate,
        												 afterDate));

        // TODO: DELETE_USER ???

        // sort list by date
        events.sort(Comparator.comparing(AuditEvent::getCreatedAt));

        return events;
    }

    protected UserPermission createUserPermission(UserProfile user, List<String> roles, AuditEvent event) {
        UserPermission perm = new UserPermission();
        perm.setName(String.format("%s %s", user.getFirstName(), user.getLastName()));
        perm.setUserId(user.getId());
        perm.setRoles(roles);
        perm.setPhone(user.getPhone());
        perm.setOrgId(user.getPrimaryOrgId());
        // user has gx limit for the current org
        if (user.getGxLimit() != null && user.getGxLimit().containsKey(event.getOrgId())) {
            perm.setGxLimit(user.getGxLimit().get(event.getOrgId()).doubleValue());
        }
        return perm;
    }

    protected Map<String, UserPermission> updateUserPermissionMapByAuditEvent(
    		
        Map<String, UserPermission> userPermissionMap, 
        AuditEvent event, 
        UserProfile user,
        List<String> roles, 
        boolean subsidiaryFlag
    ) {
    	
        switch (SystemActionType.fromValue(event.getType())) {
            case UPDATE_USER_STATUS: {

                if (!userPermissionMap.containsKey(user.getId())) {
                    // make sure this is not just a standard password change, but on-boarding (first event)
                    UserPermission perm = createUserPermission(user, roles, event);

                    // finally add the perm
                    userPermissionMap.put(user.getId(), perm);
                }

                if (event.getData().containsKey(AuditConstants.AUDIT_DATA_STATUS)) {
                    userPermissionMap.get(user.getId()).setStatus(event.getData().get(AuditConstants.AUDIT_DATA_STATUS).toString());
                }

                break;
            }
            case ADD_USER_ROLE: {
                if (!userPermissionMap.containsKey(user.getId())) {
                    if (subsidiaryFlag) {
                        UserPermission perm = createUserPermission(user, roles, event);
                        userPermissionMap.put(user.getId(), perm);
                    } else {
                        LOGGER.error("Found an audit event for a user that is not yet in the user permission map (UPDATE_USER_PASSWORD event missing for this user)");
                        break;
                    }
                }
                for (String role : roles) {
                    if (userPermissionMap.get(user.getId()).getRoles().contains(role)) {
                        LOGGER.warn("User permission map already contained the role {} for user {}", role, user.getId());
                    } else {
                        userPermissionMap.get(user.getId()).getRoles().add(role);
                    }
                }
                break;
            }
            case DELETE_USER_ROLE: {
                if (!userPermissionMap.containsKey(user.getId())) {
                    LOGGER.error("Found an audit event for a user that is not yet in the user permission map (UPDATE_USER_PASSWORD event missing for this user)");
                    break;
                }
                // removal is always one role at a time
                String role = roles.get(0);
                userPermissionMap.get(user.getId()).getRoles().remove(role);
                break;
            }
            case UPDATE_USER_DETAILS: {

                UserProfileRequest profileRequest = null;
                if (event.getData().containsKey(AuditConstants.AUDIT_DATA_USER_PROFILE_REQUEST)) {
                    profileRequest = MAPPER.convertValue(event.getData().get(AuditConstants.AUDIT_DATA_USER_PROFILE_REQUEST), UserProfileRequest.class);
                }
                if (!userPermissionMap.containsKey(user.getId())) {
                    if (subsidiaryFlag) {
                        UserPermission perm = createUserPermission(user, roles, event);
                        userPermissionMap.put(user.getId(), perm);
                    } else {
                        LOGGER.error("Found an audit event for a user that is not yet in the user permission map (UPDATE_USER_PASSWORD event missing for this user)");
                        break;
                    }
                }

                if (profileRequest == null) {
                    LOGGER.error("Could not find a user profile request in the payload of an audit event UPDATE_USER_DETAILS: {}", event);
                    break;
                }

                // retrieve the user entry and update the data
                UserPermission perm = userPermissionMap.get(user.getId());
                if (profileRequest.getGxLimit() != null) {
                    perm.setGxLimit(profileRequest.getGxLimit().doubleValue());
                }
                if (profileRequest.getPhone() != null) {
                    perm.setPhone(profileRequest.getPhone());
                }
            }
            default: {
                // no other types supported for user permission update
                break;
            }
        }

        return userPermissionMap;
    }

    /**
     * Takes the list of audit events and creates a user permission map. The method will only
     * evaluate set-password, add-role, remove-role audit events and compute a permission map of all
     * mentioned users after the last audit event in the list.
     *
     * @param events - the list of audit events to evaluate
     * @return a map with userIds as keys and the user permissions as value. Deleted users will have
     * a "dummy" name (see AuditManagerImpl#unpackData(..)).
     */
    @SuppressWarnings("unchecked")
	protected Map<String, UserPermission> createUserPermissionMap(List<AuditEvent> events, boolean subsidiaryFlag, BgxPrincipal principal) {

        // unpack the data and resolve users
        events = this.unpackData(events, principal);

        Map<String, UserPermission> userPermissionMap = new HashMap<>();

        for (AuditEvent event : events) {
            if (event.getData() == null) {
                continue;
            }
            // check that the audit event contains sufficient data
            if (event.getData().containsKey(AuditConstants.AUDIT_DATA_USER)) {

                // extract data from audit event
                List<String> roles = null;
                if (event.getData().containsKey(AuditConstants.AUDIT_DATA_ROLE)) {
                    roles = (List<String>) event.getData().get(AuditConstants.AUDIT_DATA_ROLE);
                }

                UserProfile user = (UserProfile) event.getData().get(AuditConstants.AUDIT_DATA_USER);
                if (user == null) {
                    continue;
                }

                LOGGER.debug(BgxLogMarkers.DEV, "Found user {} for permission map export", user.getId());

                if (user.getId().equals(BgxConstants.SYSTEM_USER) || user.getId().equals(BgxConstants.ANONYMOUS_USER)) {
                    LOGGER.debug(BgxLogMarkers.DEV, 
                    			 "User {} is skipped since it is a system user or principal does not have right to know about this anonymous user.",
                    			 user.getId());
                    continue;
                }

                if (user.getStatus() == null ||  user.getStatus().equals(UserProfile.Status.DELETED)) {
                    LOGGER.debug(BgxLogMarkers.DEV, "User {} in DELETED status is skipped.", user.getId());
                    continue;
                }

                // filter parent/sub users
                if (event.getOrgId().equals(user.getPrimaryOrgId()) && subsidiaryFlag) {
                    // user is primary user, but we're fetching parent perms
                    continue;
                } else if (!event.getOrgId().equals(user.getPrimaryOrgId()) && !subsidiaryFlag) {
                    // parent user and not subsidiary flag set, skip entry
                    continue;
                }

                // update permission map
                userPermissionMap = this.updateUserPermissionMapByAuditEvent(userPermissionMap, event, user, roles, subsidiaryFlag);
            }
        }

        return userPermissionMap;
    }

    // easy access methods

    @Override
    public void logAuditEvent(SystemActionType eventType, BgxPrincipal principal,
                              Map<String, Object> data) {
        String orgId = principal != null ? principal.getPrimaryOrgId() : null;
        String userId = principal != null ? principal.getUserProfile().getId() : null;

        this.logAuditEvent(eventType.toString(), orgId, userId, data);
    }

    @Override
    public void logAuditEvent(String eventType, String orgId, Map<String, Object> data) {
        this.logAuditEvent(eventType, orgId, null, data);
    }

    @Override
    public void logAuditEvent(String eventType) {
        this.logAuditEvent(eventType, null, null, null, null);
    }

    @Override
    public void logAuditEvent(String eventType, Map<String, Object> data) {
        this.logAuditEvent(eventType, null, null, null, data);
    }

    @Override
    public void logAuditEvent(String eventType, String orgId) {
        this.logAuditEvent(eventType, orgId, null, null, null);
    }

    @Override
    public void logAuditEvent(String eventType, String orgId, String userId) {
        this.logAuditEvent(eventType, orgId, userId, null, null);
    }

    @Override
    public void logAuditEvent(String eventType, String orgId, String userId, String gxId) {
        this.logAuditEvent(eventType, orgId, userId, gxId, null);
    }

    protected String[] serializeAuditEvent(AuditEvent event, Map<String, String> displayMap)
            throws IOException {
        List<String> content = new ArrayList<>();

        // "id", "datetime", "type", "organisation", "user", "parameter1", "value1",
        // "parameter2", "value2", "parameter3", "value3", "parameter4", "value4"

        content.add(event.getId());
        content.add(TimeZoneUtil.convertToAEST(event.getCreatedAt()).toString());
        content.add(event.getType());
        content.add(displayMap.get(event.getOrgId()));
        content.add(displayMap.get(event.getUserId()));

        int missingParams = 4;

        if (event.getData() != null) {

            for (Entry<String, Object> entry : event.getData().entrySet()) {

                content.add(entry.getKey());
                if (entry.getValue() instanceof Entity) {
                    // use the display name
                    content.add(displayMap.get(((Entity) entry.getValue()).getId()));
                } else if (entry.getValue() instanceof String) {
                    // just print out the string
                    content.add((String) entry.getValue());
                } else if (entry.getValue() instanceof List) {
                    // list of strings expected
                    if (((List<?>) entry.getValue()).isEmpty()) {
                        content.add("");
                    } else {
                        // check type of list content
                        if (((List<?>) entry.getValue()).get(0) instanceof String) {
                            content.add(StringUtils.join((List<?>) entry.getValue(), ";"));
                        } else {
                            throw new IOException(String.format(
                                    "Unexpected payload element detected. Expected list of strings, but found list of %s",
                                    ((List<?>) entry.getValue()).get(0)).getClass().getCanonicalName());
                        }
                    }
                } else {
                    content.add(MAPPER.writeValueAsString(entry.getValue()));
                    LOGGER.warn("Audit event {} could not be serialised: {}", event.getId(), MAPPER.writeValueAsString(entry.getValue()));
                }

                missingParams -= 1;
            }
        }

        // fill empty columns
        while (missingParams > 0) {
            content.add("");
            content.add("");
            missingParams -= 1;
        }

        LOGGER.debug("Serialised audit event: {}", content);
        return content.toArray(new String[content.size()]);
    }

    protected Map<String, String> createDisplayNameLookup(List<AuditEvent> events) {
        Map<String, String> lookupMap = new HashMap<>();
        for (AuditEvent ev : events) {
            if (ev.getData() != null) {
                for (Object value : ev.getData().values()) {
                    if (value instanceof Entity) {
                        lookupMap
                                .put(((Entity) value).getId(), this.extractDisplayName((Entity) value));
                    }
                }
            }
        }

        // lookup user and org in 2nd iteration to minimize db lookups
        for (AuditEvent ev : events) {
            if (!lookupMap.containsKey(ev.getOrgId()) && ev.getOrgId() != null) {
                Organization org = organizationRepository.getItem(ev.getOrgId());
                lookupMap.put(ev.getOrgId(), org.getProfile().getEntityName());
            }
            if (!lookupMap.containsKey(ev.getUserId()) && ev.getUserId() != null) {
                String fullName;
                if (ev.getUserId().equals(BgxConstants.SYSTEM_USER)) {
                    fullName = "System";
                } else if (ev.getUserId().equals(BgxConstants.ANONYMOUS_USER)) {
                        fullName = "Anonymous";
                } else {
                    UserProfile user = userProfileRepository.getItem(ev.getUserId());
                    fullName = String.format("%s %s", user.getFirstName(), user.getLastName());
                }
                lookupMap.put(ev.getUserId(), fullName);
            }
        }

        return lookupMap;
    }

    protected String extractDisplayName(Entity entity) {
        // return organisation name
        if (entity instanceof Organization) {
            return ((Organization) entity).getProfile().getEntityName();
        }
        // return users full name
        if (entity instanceof UserProfile) {
            return String.format("%s %s", ((UserProfile) entity).getFirstName(), ((UserProfile) entity).getLastName());
            
        }

        // return name of the new organisation
        if (entity instanceof OrgProfileRequest) {
            return ((OrgProfileRequest) entity).getProfile().getEntityName();
        }

        // otherwise just return id (we don't really have a display name for requests)
        return entity.getId();

    }
}
