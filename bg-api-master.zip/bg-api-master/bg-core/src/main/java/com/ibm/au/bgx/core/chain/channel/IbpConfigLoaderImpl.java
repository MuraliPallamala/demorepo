package com.ibm.au.bgx.core.chain.channel;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.fabric.model.IbpConfig;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Loads IBP config from a file
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class IbpConfigLoaderImpl extends AbstractIbpConfigLoader {

    private static final Logger LOGGER = LoggerFactory.getLogger(IbpConfigLoaderImpl.class);

    private static final ObjectMapper MAPPER = new ObjectMapper();

    // This is used as a mutex to access the ibpConfigCache
    private Object cacheLock = new Object();

    private Map<String, IbpConfig> ibpConfigCache = new HashMap<>();

    @Override
    public IbpConfig load(String channelName) throws Exception {

        if (channelName == null || channelName.isEmpty()) {
            throw new IllegalArgumentException("Channel name cannot be null");
        }

        // we lock before we read from the IBP config cache
        synchronized (this.cacheLock) {

            if (!this.ibpConfigCache.containsKey(channelName)) {

                LOGGER.debug(BgxLogMarkers.DEV, "Loading IBP config for channel {}", channelName);

                final IbpConfig ibpConfig = this.loadFromFile(this.configPath(channelName));
                if (ibpConfig == null) {
                    throw new IllegalArgumentException(
                        String.format("Could not load IBP config for channel %s", channelName));
                }

                LOGGER.debug(BgxLogMarkers.DEV, "Caching IBP config for channel {}", channelName);

                this.ibpConfigCache.put(channelName, ibpConfig);
            }

            LOGGER.debug(BgxLogMarkers.DEV, "Retrieving IBP config for channel {}", channelName);
            return this.ibpConfigCache.get(channelName);
        }
    }

    private String configPath(String channelName) {

        if (this.configMappings == null) {
            this.loadMappings();
        }

        if (!this.configMappings.containsKey(channelName)) {
            throw new IllegalArgumentException(
                String.format("Could not find config for channel '%s'", channelName));
        }

        return this.configMappings.getProperty(channelName);
    }

    private IbpConfig loadFromFile(String configPath) throws Exception {

        LOGGER.debug(BgxLogMarkers.DEV, "Loading IBP config for from {}", configPath);

        InputStream inputStream = new FileInputStream(configPath);

        return MAPPER.readValue(inputStream, IbpConfig.class);
    }
}