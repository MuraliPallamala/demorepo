package com.ibm.au.bgx.core.chain.adapter.gx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.flow.FlowStatusDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxPayWalkPayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxPayWalkDataAdapter implements ChainDataAdapter<Gxs.GXPayWalkRequest, GxRequest> {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    FlowStatusDataAdapter flowStatusDataAdapter;

    @Override
    public Gxs.GXPayWalkRequest toOnChainModel(GxRequest input) {
        Gxs.GXPayWalkRequest.Builder builder = Gxs.GXPayWalkRequest.newBuilder()
                .setGxId(input.getGuaranteeId());

        GxPayWalkPayload payWalkPayload = MAPPER.convertValue(input.getPayload(), GxPayWalkPayload.class);

        if (input.getId() != null) {
            builder.setId(input.getId());
        }

        if (payWalkPayload.getReason() != null) {
            builder.setReason(payWalkPayload.getReason());
        }

        return builder.build();
    }

    @Override
    public GxRequest toOffchainModel(Gxs.GXPayWalkRequest input) {
    	
        GxRequest output = new GxRequest();
        output.setType(GxRequestType.PAYWALK);
        GxPayWalkPayload payload = new GxPayWalkPayload();
        payload.setReason(input.getReason());
        output.setPayload(payload);
        output.setId(input.getId());
        output.setStatus(this.flowStatusDataAdapter.toOffchainModel(input.getStatus()));
        output.setGuaranteeId(input.getGxId());
        output.setCreatedBy(input.getCreatedBy());
        output.setCreatedAt(this.timestampDataAdapter.toOffchainModel(input.getCreatedAt()));
        output.setUpdatedBy(input.getUpdatedBy());
        output.setUpdatedAt(this.timestampDataAdapter.toOffchainModel(input.getUpdatedAt()));
        return output;
    }
}
