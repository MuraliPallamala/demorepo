package com.ibm.au.bgx.core.auth;

import com.ibm.au.bgx.core.OrgChangeRequestManagerImpl;
import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.GxPrefillRequestManager;
import com.ibm.au.bgx.model.RequestManager;
import com.ibm.au.bgx.model.approvalmodel.ApprovalModel;
import com.ibm.au.bgx.model.chain.gx.GxManager;
import com.ibm.au.bgx.model.chain.profile.OrgChangeRequestManager;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Permission;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

/**
 * Abstract class for sharing common functionalities across different implementation of BgxPrincipal
 * interface
 *
 * @author Bruno Marques <brunomar@au1.ibm.com>
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public abstract class AbstractBgxPrincipal extends AbstractAuthenticationToken implements BgxPrincipal {

    /**
	 * 
	 */
	private static final long serialVersionUID = 2322878471905641910L;
	
	protected final UserProfile userProfile;
    protected final Organization organization;
    protected final Collection<GrantedAuthority> authorities;
    protected final boolean enabled;
    protected final boolean accountExpired;
    protected final boolean accountLocked;
    protected final boolean credentialsExpired;

    protected transient BgxComponentProvider componentProvider;
    protected transient GxManager gxManager;
    protected transient ApprovalModel approvalModel;
    protected transient RequestManager requestManager;
    protected transient GxPrefillRequestManager gxPrefillRequestManager;

    public AbstractBgxPrincipal(
    		UserProfile userProfile, 
    		Organization organization,
    		Collection<GrantedAuthority> authorities, 
    		Boolean enabled, 
    		Boolean accountExpired,
    		Boolean accountLocked, 
    		Boolean credentialsExpired, 
    		BgxComponentProvider componentProvider
        ) {
    	
        super(authorities);

        if (userProfile == null) {
            throw new IllegalArgumentException("User profile cannot be empty.");
        }

        if (authorities == null) {
            throw new IllegalArgumentException("Authorities cannot be null");
        }

        if (componentProvider == null) {
            throw new IllegalArgumentException("BgxComponentProvider cannot be empty.");
        }

        this.userProfile = userProfile;
        this.organization = organization; // organization can be null for remote API call
        this.authorities = authorities;
        this.enabled = enabled;
        this.accountExpired = accountExpired;
        this.accountLocked = accountLocked;
        this.credentialsExpired = credentialsExpired;
        this.componentProvider = componentProvider;

        setAuthenticated(true);
    }

    public BgxComponentProvider getComponentProvider() {
        return this.componentProvider;
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return this.userProfile.getEmail();
    }

    @Override
    public boolean isAccountNonExpired() {
        return !this.accountExpired;
    }

    @Override
    public boolean isAccountNonLocked() {
        return !this.accountLocked;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return !this.credentialsExpired;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    @Override
    public Collection<GrantedAuthority> getAuthorities() {
        return this.authorities;
    }

    @Override
    public String getName() {
        return String
            .format("%s %s", getUserProfile().getFirstName(), getUserProfile().getLastName());
    }

    @Override
    public String getEmail() {
        return getUserProfile().getEmail();
    }

    @Override
    public String getPrimaryOrgId() {
        return getUserProfile().getPrimaryOrgId();
    }

    @Override
    public UserProfile getUserProfile() {
        if (this.userProfile == null ) {
            throw new IllegalStateException("User profile is not initialized");
        }
        return this.userProfile;
    }

    @Override
    public OrgChangeRequestManager getOrgChangeRequestManager() {
        return OrgChangeRequestManagerImpl.getComponent(this, this.componentProvider);
    }

    @Override
    public GxManager getGxManager() {

        if (this.gxManager == null) {
            throw new IllegalArgumentException("GxManager is not initialized.");
        }

        return this.gxManager;
    }

    @Override
    public ApprovalModel getApprovalModel() {
        if (this.approvalModel == null) {
            throw new IllegalArgumentException("Approval model is not initialized.");
        }
        return this.approvalModel;
    }

    @Override
    public RequestManager getRequestManager() {
        if (this.requestManager == null) {
            throw new IllegalArgumentException("Request manager is not initialized.");
        }
        return this.requestManager;
    }

    @Override
    public GxPrefillRequestManager getGxPrefillRequestManager() {
        if (this.gxPrefillRequestManager== null) {
            throw new IllegalArgumentException("Gx prifill request manager is not initialized.");
        }
        return this.gxPrefillRequestManager;
    }


    @Override
    public Organization getOrganization() {
        if (this.organization == null) {
            throw new IllegalArgumentException("Organization is not initialized.");
        }
        return organization;
    }

    @Override
    public Object getCredentials() {
        return getUserProfile().getCredentials();
    }

    @Override
    public Object getPrincipal() {
        return this;
    }

    @Override
    public boolean isSpawned() {
        return this.isActingOnBehalf();
    }

    @Override
    public String getConfiguredForOrgId() {
        if (this.organization == null) {
            throw new IllegalStateException("Organization is not initialized");
        }

        return this.organization.getId();
    }

    @Override
    public BgxPrincipal forOrg(String targetOrgId, Permission permission) {
    	
    	if (permission == null) {
    		throw new IllegalArgumentException("Permission cannot be null.");
    	}

        List<Permission> permissions = new ArrayList<>();
        permissions.add(permission);
        return this.forOrg(Relationship.PARENT_OF, targetOrgId, permissions);
    }

    @Override
    public BgxPrincipal forOrg(String targetOrgId, List<Permission> permissions)  throws GuaranteeForbiddenException {
        return this.forOrg(Relationship.PARENT_OF, targetOrgId, permissions);
    }

    // USE WITH CARE!!! Since it can allow subsidiary to act-on-behalf of parent
    @Override
    public BgxPrincipal forOrg(Relationship relationship, String targetOrgId, Permission permission) {

        List<Permission> permissions = new ArrayList<>();
        permissions.add(permission);
        return this.forOrg(relationship, targetOrgId, permissions);
    }


    @Override
    public boolean hasRole(String orgId, String role) {
        if (orgId == null) {
            throw new IllegalArgumentException("Org Id cannot be null");
        }

        if (role == null) {
            throw new IllegalArgumentException("Role cannot be null");
        }

        List<String> roles = new ArrayList<>();
        roles.add(role);

        return hasRoles(orgId, roles);
    }

    @Override
    public boolean hasRoles(String orgId, List<String> roles) {
        if (orgId == null) {
            throw new IllegalArgumentException("Org Id cannot be null");
        }

        if (roles == null) {
            throw new IllegalArgumentException("Role cannot be null");
        }

        if (this.getUserProfile().getUserRoles().containsKey(orgId)
            && this.getUserProfile().getUserRoles().get(orgId).containsAll(roles)) {

            return true;
        }

        return false;
    }

    @Override
    public boolean isAdmin() {
       return this.hasRole(this.getPrimaryOrgId(), BgxConstants.ROLE_ADMIN);
    }

    @Override
    public boolean isAdminForOrg(String orgId) {
        return this.hasRole(orgId, BgxConstants.ROLE_ADMIN);
    }

    @Override
    public boolean isUserOfOrgType(EntityType entityType) {
        if (this.getOrganization() != null
            && this.getOrganization().getProfile() != null
            && this.getOrganization().getProfile().getEntityType().equals(entityType)) {
            return true;
        }
        return false;

    }

    @Override
    public boolean isConsortiumUser() {
        return this.isUserOfOrgType(EntityType.CONSORTIUM);
    }

    @Override
    public boolean isConsortiumAdminUser() {
        return this.isConsortiumUser() && isAdmin();
    }

    @Override
    public BigInteger getGxLimit() {
        return this.getGxLimit(getConfiguredForOrgId());
    }

    @Override
    public BigInteger getGxLimit(String orgId) {
        if (this.getUserProfile().getGxLimit().containsKey(orgId)) {
            return this.getUserProfile().getGxLimit().get(orgId);
        }

        return BigInteger.ZERO;
    }

    @Override
    public boolean isActingOnBehalf() {
        return !this.getPrimaryOrgId().equals(this.getConfiguredForOrgId());
    }

    @Override
    public boolean isActingOnBehalf(String targetOrgId) {
        return !this.getPrimaryOrgId().equals(targetOrgId)
            && this.getConfiguredForOrgId().equals(targetOrgId);
    }

    @Override
    public RelationshipInfo getRelationshipFor(String targetOrgId) {
        for (RelationshipInfo relInfo : this.getOrganization().getSettings().getRelationships()) {
            if (relInfo.getId().equals(targetOrgId)) {
                return relInfo;
            }
        }

        return null;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof AbstractBgxPrincipal)) {
            return false;
        }

        AbstractBgxPrincipal test = (AbstractBgxPrincipal) obj;

        if (!authorities.equals(test.authorities)) {
            return false;
        }

        if ((this.getDetails() == null) && (test.getDetails() != null)) {
            return false;
        }

        if ((this.getDetails() != null) && (test.getDetails() == null)) {
            return false;
        }

        if ((this.getDetails() != null) && (!this.getDetails().equals(test.getDetails()))) {
            return false;
        }

        if ((this.getCredentials() == null) && (test.getCredentials() != null)) {
            return false;
        }

        if ((this.getCredentials() != null)
            && !this.getCredentials().equals(test.getCredentials())) {
            return false;
        }

        if (this.getPrincipal() == null && test.getPrincipal() != null) {
            return false;
        }

        if (this.getPrincipal() != null
            && !this.getEmail().equals(test.getEmail()) && this.getPrimaryOrgId()
            .equals(test.getPrimaryOrgId())) {
            return false;
        }

        return this.isAuthenticated() == test.isAuthenticated();
    }

    @Override
    public int hashCode() {
        int code = 31;

        for (GrantedAuthority authority : authorities) {
            code ^= authority.hashCode();
        }

        if (this.getPrincipal() != null) {
            code ^= ((AbstractBgxPrincipal) this.getPrincipal()).getEmail().hashCode();
            code ^= ((AbstractBgxPrincipal) this.getPrincipal()).getPrimaryOrgId().hashCode();
        }

        if (this.getCredentials() != null) {
            code ^= this.getCredentials().hashCode();
        }

        if (this.getDetails() != null) {
            code ^= this.getDetails().hashCode();
        }

        if (this.isAuthenticated()) {
            code ^= -37;
        }

        return code;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Principal: ").append(((AbstractBgxPrincipal) this.getPrincipal()).getEmail()).append("; ");
        sb.append("Organization: ").append(((AbstractBgxPrincipal) this.getPrincipal()).getPrimaryOrgId())
            .append("; ");
        sb.append("Credentials: [PROTECTED]; ");
        sb.append("Authenticated: ").append(this.isAuthenticated()).append("; ");
        sb.append("Details: ").append(this.getDetails()).append("; ");

        if (!authorities.isEmpty()) {
            sb.append("Granted Authorities: ");

            int i = 0;
            for (GrantedAuthority authority : authorities) {
                if (i++ > 0) {
                    sb.append(", ");
                }

                sb.append(authority);
            }
        } else {
            sb.append("Not granted any authorities");
        }

        return sb.toString();
    }
}
