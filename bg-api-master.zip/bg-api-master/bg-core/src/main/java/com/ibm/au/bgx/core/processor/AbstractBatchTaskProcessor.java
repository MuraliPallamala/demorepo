package com.ibm.au.bgx.core.processor;

import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.pojo.notification.ExecutionErrorLog;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask.Status;
import com.ibm.au.bgx.model.pojo.task.TaskResult;
import com.ibm.au.bgx.model.repository.BatchProcessTaskRepository;
import com.ibm.au.bgx.model.task.processor.item.BatchItemProcessor;
import com.ibm.au.bgx.model.task.processor.BatchTaskProcessor;
import java.math.BigInteger;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Class <b>AbstractBatchTaskProcessor</b>. This class implements {@link BatchTaskProcessor}
 * and provides a set of base capabilities for batch task management that can be leveraged 
 * when implementing specific types of task processors.
 * </p>
 * <p>
 * This class provides capabilities for task initialisation and error management and support
 * for batch management. It is also integrated with a repository to persist and maintain 
 * task instances.
 * </p>
 * 
 * @see BatchProcessTaskRepository
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public abstract class AbstractBatchTaskProcessor implements BatchTaskProcessor {

	/**
	 * A {@link Logger} implementation that is used to collect all the log messages produced by
	 * instances of this class.
	 */
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractBatchTaskProcessor.class);

    /**
     * A {@link BatchProcessTaskRepository} implementation that is used to persist task instances
     * and maintain their status updated with the outcome of the task execution.
     */
    @Autowired
    protected BatchProcessTaskRepository taskRepository;

    /**
     * Initialises the <i>task</i> for execution. This method prepares the given {@link BatchProcessTask}
     * instance to its execution an puts it into the {@link Status#PROCESSING} state if marked as {@link 
     * Status#PENDING}. It then updates the repository of tasks with the new version of the task and
     * returns it to the caller.
     * 
     * @param task	a {@link BatchProcessTask} instance representing the task to be initialised. It cannot
     * 				be {@literal null}.
     * 
     * @return 	the updated <i>task</i> prepared for execution, if the task was originally in the {@link 
     * 			Status#PENDING} state, the <i>task</i> unmodified if its status was {@link Status#COMPLETED}.
     * 
     * @throws IllegalArgumentException		if <i>task</i> is {@literal null}.	
     */
    protected BatchProcessTask init(BatchProcessTask task) {
    	
    	if (task == null) {
    		throw new IllegalArgumentException("Task cannot be null.");
    	}

        // Reset before processing
        if (task.getStatus().equals(Status.PENDING)) {
            task.setStatus(Status.PROCESSING);

            task.setHasError(false);
            task.setErrorLogs(new ArrayList<>());
            task.setResult(new HashMap<>());

            if (task.getBatchSize() == null) {
                task.setBatchSize(BigInteger.valueOf(BgxConstants.MAX_TASK_BATCH_SIZE));
            }

            if (task.getProcessed() == null) {
                task.setProcessed(BigInteger.ZERO);
            }

            return taskRepository.updateItem(task);
        } else {
           return task;
        }
    }


    /**
     * <p>
     * Processes in batch all the items associated to the task. A {@link BatchProcessTask} may include multiple
     * items to be processed, this method provides the capability for processing all the items associated to the
     * task in sequence, by iterating over them and delegating the specific processing of each item to the given
     * <i>itemProcessor</i>.
     * </p>
     * <p>
     * This method also implements the capability of partially resuming the execution of a batch task that was not
     * completed by starting the execution of the items from {@link BatchProcessTask#getLastProcessed()} if not
     * {@literal null} or an empty string.
     * </p>
     * <p>
     * The execution of how many items are processed within a single invocation is controlled by the value of {@link 
     * BatchProcessTask#getBatchSize()}. If during the current execution all the items associated to the task are
     * processed then the status of the task is set to {@link Status#COMPLETED}.
     * </p>
     * 
     * @param task			a {@link BatchProcessTask} representing the task to be processed. It cannot be {@literal 
     * 						null}.
     * 
     * @param iterator		a {@link Iterator} implementation that is used to iterate over all the items associated
     * 						to <i>task</i>. The expectation is that instance is an iterator of {@link Entry} entities
     * 						where the key of type {@link String} is the identifier of the item, while the value of
     * 						type {@link Object} is the item to be processed. The specific type of the value depends
     * 						on the specific type of <i>task</i> being processed, and its execution is delegated to the
     * 						given <i>itemProcessor</i>. It cannot be {@literal null}.
     * 
     * @param itemProcessor a {@link BatchItemProcessor} instance that is used to process the items associated to the
     * 						task. It cannot be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>task</i>, <i>iterator</i>, or <i>itemProcessor</i> is {@literal null}.
     * 
     */
    protected void processInBatch(BatchProcessTask task, Iterator<?> iterator, BatchItemProcessor itemProcessor) {
    	
    	if (task == null) {
    		throw new IllegalArgumentException("Task cannot be null.");
    	}
    	
    	if (iterator == null) {
    		throw new IllegalArgumentException("Iterator cannot be null.");
    	}
    	
    	if (itemProcessor == null) {
    		throw new IllegalArgumentException("Item processor cannot be null.");
    	}

        // skip if required
        final String lastProcessed = task.getLastProcessed(); // keep a copy
        if (lastProcessed != null && !lastProcessed.isEmpty()) {
            while (iterator.hasNext()) {

                @SuppressWarnings("unchecked")
				Entry<String, Object> entry = (Entry<String, Object>) iterator.next();

                if (entry.getKey().equals(lastProcessed)) {
                    break;
                }
            }
        }

        // now process the rest
        while (iterator.hasNext()) {

            @SuppressWarnings("unchecked")
			Entry<String, Object> entry = (Entry<String, Object>) iterator.next();

            // process the item
            itemProcessor.process(task, entry);

            // save the last processed userId
            task.setLastProcessed(entry.getKey());

            // Check if this batch is finished
            task.setProcessed(task.getProcessed().add(BigInteger.ONE)); // increment processed count
            if ( task.getProcessed().compareTo(task.getBatchSize()) == 0) {
                break;
            }
        }

        // if no more item we set it as completed
        if (!iterator.hasNext()) {
            task.setStatus(Status.COMPLETED);
        }
    }

    /**
     * <p>
     * Completes and finalises the processing of the given <i>task</i>.
     * </p>
     * <p>
     * This method checks whether the task has errors and if so it marks it as a task with
     * errors by setting {@link BatchProcessTask#setHasError(Boolean)}. It then updates the
     * repository with the new details for the task.
     * </p>
     *
     * @param task	a {@link BatchProcessTask} representing the task to finalise. It cannot
     * 				be {@literal null}.
     * 
     * @return the updated task. It is guaranteed to not to be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>task</i> is {@literal null}.
     */
    protected BatchProcessTask finish(BatchProcessTask task) {
    	
    	if (task == null) {
    		throw new IllegalArgumentException("Task cannot be null.");
    	}

        if (task.getErrorLogs() != null && !task.getErrorLogs().isEmpty()) {
            task.setHasError(true);
        }


        return this.taskRepository.updateItem(task);
    }

    /**
     * <p>
     * This method collects all the information that are associated to the error that occurred while processing
     * <i>entryId</i> for the given <i>task</i> and enrich the task with the details of the error.
     * </p>
     * <p> 
     * The method associates an instance of {@link TaskResult} to <i>entryId</i>. Such result contains the
     * information about the <i>error</i> and additional error message, as well as the error log associated
     * to the processing of <i>entryId</i>.
     * </p>
     * 
     * @param task		a {@link BatchProcessTask} representing the batch task that encountered the given <i>error</i>.
     * 					It cannot be {@literal null}.
     * @param entryId	a {@link String} representing the unique identifier of the entry that caused the <i>error</i>.
     * 					It cannot be {@literal null}.
     * @param error		a {@link Exception} instance representing the error that occurred while processing <i>entryId</i>.
     * 					It cannot be {@literal null}.
     * @param message	a {@link String} representing the error message to set in the task result. It can be {@literal 
     * 					null} and in this case the value of the error message in <i>error</i> will be used.
     * 
     * @throws IllegalArgumentException	if <i>task</i>, <i>entryId</i>, or <i>error</i> is {@literal null}.
     */
    public static void addTaskError(BatchProcessTask task, String entryId, Exception error, String message) {
    	
    	if (task == null) { 
    		throw new IllegalArgumentException("Task cannot be null."); 
    	}
    	
    	if (entryId == null) { 
    		throw new IllegalArgumentException("Entry identifier cannot be null."); 
    	}
    	
    	if (error == null) { 
    		throw new IllegalArgumentException("Error cannot be null."); 
    	} 

        TaskResult taskResult = AbstractBatchTaskProcessor.prepareResultFromException(error, message);
        task.getResult().put(entryId, taskResult);

        ExecutionErrorLog errorLog = new ExecutionErrorLog();
        errorLog.setDate(Instant.now());
        errorLog.setErrorMessage(taskResult.getError());
        task.getErrorLogs().add(errorLog);

        LOGGER.error(error.getMessage(), error);
    }

    /**
     * Generates the result for the task that captures the information associated to the
     * given <i>error</i>. This method creates an instance of {@link TaskResult} and maps
     * the specific type of {@link Exception} passed as argument to an appropriated error
     * code for the task. The mapping is executed as follows:
     * <ul>
     * <li>{@link IllegalArgumentException} is mapped to {@link HttpStatus#BAD_REQUEST}</li>
     * <li>{@link DataNotFoundException} is mapped to {@link HttpStatus#NOT_FOUND}</li>
     * <li>any other exception is mapped to {@link HttpStatus#INTERNAL_SERVER_ERROR}</li>
     * </ul>
     *
     * @param error		a {@link Exception} representing the error occurred during the
     * 					execution of the task. It cannot be {@literal null}.
     * 
     * @param message 	a {@link String} representing the error message to use to inform
     * 					the originator of the task about the error that occurred. This
     * 					argument can be {@literal null} and in that case the error message
     * 					is set to the message that is contained in the <i>error</i>.
     * 
     * @return 	a {@link TaskResult} that contains the details of the error occurred. It is
     * 			guaranteed to not to be {@literal null}. The value of {@link TaskResult#getCode()}
     * 			is set as described before, while the value of {@link TaskResult#getError()} is
     * 			either set to <i>message</i> if not {@literal null} or to the value of the error
     * 			message defined by <i>error</i>.
     * 
     * @throws IllegalArgumentException	if <i>error</i> is {@literal null}.
     */
    public static TaskResult prepareResultFromException(Exception error, String message) {
    	
    	if (error == null) {	
    		throw new IllegalArgumentException("Error cannot be null.");
    	}    	
    	
        TaskResult result = new TaskResult();
        result.setError(error.getMessage());
        
        if (error instanceof IllegalArgumentException) {
        	
            result.setCode(HttpStatus.BAD_REQUEST.toString());
        
        } else if (error instanceof DataNotFoundException) {
        	
            result.setCode(HttpStatus.NOT_FOUND.toString());
        
        } else {
        
        	result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
        }

        if (message != null) {
            result.setError(message);
        }

        return result;
    }
}
