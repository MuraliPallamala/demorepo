package com.ibm.au.bgx.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.SystemActionsManager;
import com.ibm.au.bgx.model.audit.AuditConstants;
import com.ibm.au.bgx.model.audit.AuditManager;
import com.ibm.au.bgx.model.audit.AuditParameter;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.notification.WebNotificationManager;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.system.SystemActionRequest;
import com.ibm.au.bgx.model.pojo.system.SystemActionResponse;
import com.ibm.au.bgx.model.pojo.system.SystemActionType;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.repository.UserProfileRepository;
import com.ibm.au.bgx.model.repository.WebNotificationRepository;
import com.ibm.au.bgx.model.util.JacksonUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class SystemActionsManagerImpl implements SystemActionsManager {

    public static final Map<SystemActionType, Function<SystemActionRequest, SystemActionResponse>> execMap = new EnumMap<>( SystemActionType.class);
    private static final Logger LOGGER = LoggerFactory.getLogger(SystemActionsManagerImpl.class);
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();
    private final List<SystemActionType> gxStartActions = Arrays.asList(
        SystemActionType.START_ISSUE_GUARANTEE,
        SystemActionType.START_AMEND_GUARANTEE,
        SystemActionType.START_DEMAND_GUARANTEE,
        SystemActionType.START_PAYWALK_GUARANTEE,
        SystemActionType.START_CANCEL_GUARANTEE,
        SystemActionType.START_TRANSFER_GUARANTEE
    );
    private final List<SystemActionType> gxPrefillActions = Arrays.asList(
        SystemActionType.PREFILL_ISSUE_GUARANTEE,
        SystemActionType.PREFILL_AMEND_GUARANTEE,
        SystemActionType.PREFILL_CANCEL_GUARANTEE
    );

    private final List<SystemActionType> noGxYetActions = Arrays.asList(
        SystemActionType.START_ISSUE_GUARANTEE,
        SystemActionType.APPROVE_ISSUE_GUARANTEE,
        SystemActionType.REJECT_ISSUE_GUARANTEE,
        SystemActionType.CANCEL_ISSUE_GUARANTEE,
        SystemActionType.RECALL_ISSUE_GUARANTEE,
        SystemActionType.REVOKE_APPROVE_ISSUE,
        SystemActionType.PREFILL_ISSUE_GUARANTEE
    );

    private final List<SystemActionType> requestTerminatingActions = Arrays.asList(
        SystemActionType.REJECT_AMEND_GUARANTEE,
        SystemActionType.REJECT_CANCEL_GUARANTEE,
        SystemActionType.REJECT_TRANSFER_GUARANTEE,
        SystemActionType.REJECT_ISSUE_GUARANTEE,
        SystemActionType.CANCEL_AMEND_GUARANTEE,
        SystemActionType.CANCEL_CANCEL_GUARANTEE,
        SystemActionType.CANCEL_DEMAND_GUARANTEE,
        SystemActionType.CANCEL_TRANSFER_GUARANTEE,
        SystemActionType.CANCEL_ISSUE_GUARANTEE
    );

    @Autowired
    protected ApplicationContext applicationContext;

    @Autowired
    protected AuditManager auditManager;

    @Autowired
    protected GxRequestRepository gxRequestRepository;

    @Autowired
    protected UserProfileRepository userProfileRepository;

    @Autowired
    protected WebNotificationManager webNotificationManager;

    @Autowired
    protected WebNotificationRepository webNotificationRepository;


    @PostConstruct
    public void init() {
        execMap.put(SystemActionType.PREFILL_ISSUE_GUARANTEE, this::submitGxRequest);
        execMap.put(SystemActionType.PREFILL_AMEND_GUARANTEE, this::submitGxRequest);
        execMap.put(SystemActionType.PREFILL_CANCEL_GUARANTEE, this::submitGxRequest);
        execMap.put(SystemActionType.START_ISSUE_GUARANTEE, this::submitGxRequest);
        execMap.put(SystemActionType.START_AMEND_GUARANTEE, this::submitGxRequest);
        execMap.put(SystemActionType.START_DEMAND_GUARANTEE, this::submitGxRequest);
        execMap.put(SystemActionType.START_PAYWALK_GUARANTEE, this::submitGxRequest);
        execMap.put(SystemActionType.START_CANCEL_GUARANTEE, this::submitGxRequest);
        execMap.put(SystemActionType.START_TRANSFER_GUARANTEE, this::submitGxRequest);
        execMap.put(SystemActionType.APPROVE_ISSUE_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.APPROVE_AMEND_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.APPROVE_DEMAND_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.APPROVE_CANCEL_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.APPROVE_TRANSFER_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.CANCEL_ISSUE_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.CANCEL_AMEND_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.CANCEL_DEMAND_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.CANCEL_CANCEL_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.CANCEL_TRANSFER_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.REJECT_ISSUE_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.REJECT_AMEND_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.REJECT_DEMAND_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.REJECT_CANCEL_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.REJECT_TRANSFER_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.DEFER_DEMAND_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.RECALL_ISSUE_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.RECALL_AMEND_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.RECALL_DEMAND_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.RECALL_CANCEL_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.RECALL_TRANSFER_GUARANTEE, this::submitGxAction);
        execMap.put(SystemActionType.REVOKE_APPROVE_ISSUE, this::submitGxAction);
        execMap.put(SystemActionType.REVOKE_APPROVE_AMEND, this::submitGxAction);
        execMap.put(SystemActionType.REVOKE_APPROVE_CANCEL, this::submitGxAction);
        execMap.put(SystemActionType.REVOKE_APPROVE_TRANSFER, this::submitGxAction);
    }

    @Override
    public SystemActionResponse run(SystemActionRequest request) throws RuntimeException {

        LOGGER.debug("Triggering system action {}", request.getType());

        List<WebNotification> subsidiaryNotifications = this.retrieveParentNotifications(request);

        // execute the action
        SystemActionResponse response = execMap.get(request.getType()).apply(request);

        LOGGER.debug("Finished system action {} with result: {}", request.getType(),
                response.getId());
        // log the auditing
        try {
            this.handleAuditLogging(request);
        } catch (Exception e) {
            LOGGER.error(String.format("Error logging audit event for system action %s",
                    request.getType().toString()), e);
        }

        // reset notifications that require action
        try {
            this.handleWebNotificationReset(request, subsidiaryNotifications);
        } catch (Exception e) {
            LOGGER.error(String
                    .format("Error resetting require action notifications for system action %s",
                            request.getType().toString()), e);
        }

        // return the response
        return response;
    }


    private SystemActionResponse submitGxRequest(SystemActionRequest request) {
        return gxRequestToSystemActionResponse(
                request.getPrincipal().getGxManager()
                        .submitRequest(MAPPER.convertValue(request.getPayload(), GxRequest.class))
        );
    }

    private SystemActionResponse submitGxAction(SystemActionRequest request) {
        return gxActionToSystemActionResponse(
                request.getPrincipal().getGxManager()
                        .submitAction(MAPPER.convertValue(request.getPayload(), GxAction.class))
        );
    }

    // TODO move+refactor
    private SystemActionResponse gxActionToSystemActionResponse(GxAction gxAction) {
    	
        SystemActionResponse response = new SystemActionResponse();
        response.setId(gxAction.getId());
        response.setCreatedAt(gxAction.getCreatedAt());
        response.setCreatedBy(gxAction.getCreatedBy());
        response.setOriginalResponse(gxAction);
        
        return response;
    }

    // TODO move+refactor
    private SystemActionResponse gxRequestToSystemActionResponse(GxRequest gxRequest) {
    	
        SystemActionResponse response = new SystemActionResponse();
        response.setId(gxRequest.getId());
        response.setCreatedAt(gxRequest.getCreatedAt());
        response.setCreatedBy(gxRequest.getCreatedBy());
        response.setOriginalResponse(gxRequest);
        
        return response;
    }

    /**
     * Retrieves a list of web notifications from the parent organisation before the system action
     * is executed and new notifications created (e.g. through the event handling in the service
     * API).
     * @param request - the system action request that will be performed (and contains principal and
     *                GxRequest data
     * @return a list of web notifications that exist before the system action is executed for users
     * of the subsidiary of the primary org the user is acting on.
     */
    private List<WebNotification> retrieveParentNotifications(SystemActionRequest request) {
        String parentOrgId = null;
        for (RelationshipInfo info : request.getPrincipal().getOrganization().getSettings().getRelationships()) {
            if (info.getRelationship().equals(RelationshipInfo.Relationship.SUBSIDIARY_OF) &&
                    (info.getStatus().equals(RelationshipInfo.Status.LINKED) || info.getStatus().equals(RelationshipInfo.Status.UNLINK_PENDING))) {
                parentOrgId = info.getId();
            }
        }

        if (parentOrgId == null) {
            return new ArrayList<>();
        }

        String gxRequestId = this.determineRequestId(request);
        if (gxRequestId == null) {
            return new ArrayList<>();
        }

        // get parent users
        List<String> parentUsers = userProfileRepository.getByPrimaryOrgId(parentOrgId)
                .stream()
                .map(profile -> profile.getId())
                .collect(Collectors.toList());

        // get notifications for those users
        return webNotificationRepository.findByReferenceIdAction(gxRequestId, true, false)
                					    .stream()
                					    .filter(notification -> parentUsers.contains(notification.getReceiverId()))
                					    .collect(Collectors.toList());
    }


    /**
     * Determines the GxRequestID of a system action request
     * @param request - the system action request containing all the information
     * @return the gx request ID or null, if it is a prefill action
     */
    protected String determineRequestId(SystemActionRequest request) {
    	
        String gxRequestId;
        // start actions tend not to have any existing notifications attached
        if (gxStartActions.contains(request.getType()) || gxPrefillActions.contains(request.getType())) {
        	
            // not 100% sure which scenarios provide a requestId in a new request and if there are every any notifications to reset
            GxRequest gxRequest = MAPPER.convertValue(request.getPayload(), GxRequest.class);
            gxRequestId = gxRequest.getId();
            
        } else {
        	
            // regular action, clean up previous notifications
            gxRequestId = MAPPER.convertValue(request.getPayload(), GxAction.class).getGxRequestId();
        }
        return gxRequestId;
    }

    /**
     * This method will fetch web notifications relevant to the current GxRequest and update the
     * actionDone flag of those belonging to users of the same organisation as the actor of the
     * current SystemActionRequest.
     *
     * @param request - the currently executed system action request
     */
    protected void handleWebNotificationReset(SystemActionRequest request, List<WebNotification> subsidiaryNotifications) {

        // Skip notification for START_ISSUE_GUARANTEE since it is not applicable
        if (request.getType().equals(SystemActionType.START_ISSUE_GUARANTEE)) {
            return;
        }

        String gxRequestId = this.determineRequestId(request);
        if (gxRequestId == null) {
            // no request ID (probably pre-fill)
            return;
        }

        webNotificationManager.markActionsDone(request.getPrincipal().getPrimaryOrgId(), gxRequestId);
        // check relationships of the current org for a parent relationship
        for (WebNotification notification : subsidiaryNotifications) {
            notification.setActionDone(true);
            webNotificationRepository.updateItem(notification);
        }

        // also mark actions of other orgs as done, if the action is a terminating one
        if (requestTerminatingActions.contains(request.getType())) {
            webNotificationManager.markActionsDone(gxRequestId);
        }
    }

    /**
     * Extracts enough information from the provided system action request and creates an audit
     * event and logs it.
     *
     * @param request - the currently executed system action request
     */
    protected void handleAuditLogging(SystemActionRequest request) {

        Map<String, Object> auditPayload = new HashMap<>();

        if (gxStartActions.contains(request.getType()) || gxPrefillActions.contains(request.getType())) {
            // this is a start action, payload is the GxRequest
            GxRequest gxRequest = MAPPER.convertValue(request.getPayload(), GxRequest.class);
            // log the request ID
            auditPayload.put(AuditConstants.AUDIT_DATA_GX_REQUEST, gxRequest);

            // check whether we also have a guarantee
            if (!noGxYetActions.contains(request.getType())) {
                // we have a gx available, log the gx ID
                auditPayload.put(AuditConstants.AUDIT_DATA_GX, new AuditParameter(AuditConstants.GUARANTEE, gxRequest.getGuaranteeId()));
            }
        } else {
            // no start action, we have a gxRequest and potentially also a gx
            GxAction gxAction = MAPPER.convertValue(request.getPayload(), GxAction.class);
            try {
                LOGGER.debug(BgxLogMarkers.DEV, "Retrieving GxRequest using flow Id {}", gxAction.getGxRequestId());
                GxRequest gxRequest = gxRequestRepository.getItem(gxAction.getGxRequestId());

                // log the gx request ID
                auditPayload.put(AuditConstants.AUDIT_DATA_GX_REQUEST, gxRequest);

                if (!noGxYetActions.contains(request.getType())) {
                    // we have a gx available as well, log the ID
                    auditPayload.put(AuditConstants.AUDIT_DATA_GX, new AuditParameter(AuditConstants.GUARANTEE, gxRequest.getGuaranteeId()));
                }
            } catch (Exception e) {
                LOGGER.error(String.format("Error during audit logging for request type: %s", request.getType().toString()), e);
            }
        }

        // finally log the event with prepared payload
        auditManager.logAuditEvent(request.getType(), request.getPrincipal(), auditPayload);
    }
}
