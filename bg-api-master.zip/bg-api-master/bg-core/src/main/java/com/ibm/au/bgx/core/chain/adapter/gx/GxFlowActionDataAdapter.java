package com.ibm.au.bgx.core.chain.adapter.gx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.chain.adapter.flow.FlowActionDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.ActionScopeType;
import com.ibm.au.bgx.model.pojo.chain.FlowAction;
import com.ibm.au.bgx.model.pojo.chain.FlowActionRequestType;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxActionApprovePayload;
import com.ibm.au.bgx.model.pojo.gx.GxActionDefaultPayload;
import com.ibm.au.bgx.model.pojo.gx.GxActionType;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxFlowActionDataAdapter implements ChainDataAdapter<Gxs.GXFlowActionRequest, GxAction> {

    private static ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    FlowActionDataAdapter flowActionDataAdapter;

    @Override
    public Gxs.GXFlowActionRequest toOnChainModel(GxAction input) {
        FlowAction flowAction = new FlowAction();
        flowAction.setActionType(FlowActionRequestType.fromValue(input.getType().value()));
        flowAction.setFlowId(input.getGxRequestId());
        flowAction.setActionId(input.getActionId());
        if (input.getPayload() != null) {
            if (input.getType().equals(GxActionType.APPROVE)) {
                GxActionApprovePayload approvePayload = MAPPER.convertValue(input.getPayload(), GxActionApprovePayload.class);
                flowAction.setBankReference(approvePayload.getBankReference());
                flowAction.setIssuer(approvePayload.getIssuer());
            } else {
                GxActionDefaultPayload defaultPayload = MAPPER.convertValue(input.getPayload(), GxActionDefaultPayload.class);
                flowAction.setMessage(defaultPayload.getReason());
            }
        }
        flowAction.setCreatedBy(input.getCreatedBy());
        flowAction.setCreatedAt(input.getCreatedAt());

        Gxs.GXFlowActionRequest.Builder builder = Gxs.GXFlowActionRequest.newBuilder()
                .setFlowActionRequest(this.flowActionDataAdapter.toOnChainModel(flowAction));

        return builder.build();
    }

    @Override
    public GxAction toOffchainModel(Gxs.GXFlowActionRequest input) {
        GxAction output = new GxAction();
        if (input.hasFlowActionRequest()) {
            FlowAction flowAction = this.flowActionDataAdapter.toOffchainModel(input.getFlowActionRequest());
            output.setId(flowAction.getId());
            output.setScope(ActionScopeType.EXTERNAL);
            output.setGxRequestId(flowAction.getFlowId());
            output.setActionId(flowAction.getActionId());
            output.setCreatedBy(flowAction.getCreatedBy());
            output.setCreatedAt(flowAction.getCreatedAt());
            output.setType(GxActionType.valueOf(flowAction.getActionType().value()));

            if (flowAction.getActionType().equals(FlowActionRequestType.APPROVE)) {
                GxActionApprovePayload payload = new GxActionApprovePayload();
                payload.setBankReference(flowAction.getBankReference());
                payload.setIssuer(flowAction.getIssuer());
            } else {
                GxActionDefaultPayload payload = new GxActionDefaultPayload();
                payload.setReason(flowAction.getMessage());
                output.setPayload(payload);
            }
        } else if (input.hasRecallRequest()) {
            // TODO handle

        } else {
            throw new IllegalArgumentException("Unable to extract request from Gxs.GXFlowActionRequest");
        }
        return output;
    }
}
