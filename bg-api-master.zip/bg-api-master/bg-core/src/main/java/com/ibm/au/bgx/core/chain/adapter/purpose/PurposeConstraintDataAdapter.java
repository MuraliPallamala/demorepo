package com.ibm.au.bgx.core.chain.adapter.purpose;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.purpose.MaxValueConstraint;
import com.ibm.au.bgx.model.pojo.purpose.MinValueConstraint;
import com.ibm.au.bgx.model.pojo.purpose.OneOfConstraint;
import com.ibm.au.bgx.model.pojo.purpose.PatternConstraint;
import com.ibm.au.bgx.model.pojo.purpose.PurposeField;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFieldConstraint;
import com.ibm.au.bgx.model.shared.Common;
import com.ibm.au.bgx.model.util.JacksonUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Peter Ilfrich
 */
@Component
public class PurposeConstraintDataAdapter implements ChainDataAdapter<Common.PurposeConstraint, Object> {

    private static final String KEY_CONSTRAINT_TYPE = "constraintType";
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    protected PurposeFieldTypeAdapter purposeFieldTypeAdapter;

    @Override
    public Common.PurposeConstraint toOnChainModel(Object purposeFieldConstraint) {
        @SuppressWarnings("unchecked")
		Map<String, Object> constraint = (Map<String,Object>) MAPPER.convertValue(purposeFieldConstraint, LinkedHashMap.class);
        if (!constraint.containsKey(KEY_CONSTRAINT_TYPE)) {
            throw new IllegalArgumentException("Provided purpose field constraint object doesn't contain the 'constraintType' key");
        }

        Common.PurposeConstraint.Builder cBuilder = Common.PurposeConstraint.newBuilder();


        switch (PurposeFieldConstraint.ConstraintType.fromValue((String) constraint.get(KEY_CONSTRAINT_TYPE))) {
            case ONE_OF: {
                OneOfConstraint c = MAPPER.convertValue(purposeFieldConstraint, OneOfConstraint.class);
                Common.OneOfConstraint.Builder builder = Common.OneOfConstraint.newBuilder();
                if (c.getAvailableValues() != null && !c.getAvailableValues().isEmpty()) {
                    for (String av : c.getAvailableValues()) {
                        builder.addAvailableValues(av);
                    }
                }

                builder.setPurposeFieldConstraint(getOnChainPurposeFieldConstraint(c));
                cBuilder.setOneOfConstraint(builder);
                break;
            }
            case MIN_VALUE: {
                MinValueConstraint c = MAPPER.convertValue(purposeFieldConstraint, MinValueConstraint.class);
                Common.MinValueConstraint.Builder builder = Common.MinValueConstraint.newBuilder();
                // first field
                builder.setIncludeMin(c.getIncludeMin());
                builder.setMinValue(c.getMinValue());

                builder.setPurposeFieldConstraint(getOnChainPurposeFieldConstraint(c));
                cBuilder.setMinValueConstraint(builder);
                break;
            }
            case MAX_VALUE: {
                MaxValueConstraint c = MAPPER.convertValue(purposeFieldConstraint, MaxValueConstraint.class);
                Common.MaxValueConstraint.Builder builder = Common.MaxValueConstraint.newBuilder();
                // first field
                builder.setIncludeMax(c.getIncludeMax());
                builder.setMaxValue(c.getMaxValue());

                builder.setPurposeFieldConstraint(getOnChainPurposeFieldConstraint(c));
                cBuilder.setMaxValueConstraint(builder);
                break;
            }
            case PATTERN: {
                PatternConstraint c = MAPPER.convertValue(purposeFieldConstraint, PatternConstraint.class);
                Common.PatternConstraint.Builder builder = Common.PatternConstraint.newBuilder();
                // first field
                builder.setPattern(c.getPattern());

                builder.setPurposeFieldConstraint(getOnChainPurposeFieldConstraint(c));
                cBuilder.setPatternConstraint(builder);
                break;
            }
        }

        return cBuilder.build();
    }

    @Override
    public PurposeFieldConstraint toOffchainModel(Common.PurposeConstraint purposeConstraint) {

        if (purposeConstraint.hasMaxValueConstraint()) {

            MaxValueConstraint c = new MaxValueConstraint();
            c.setIncludeMax(purposeConstraint.getMaxValueConstraint().getIncludeMax());
            c.setMaxValue(purposeConstraint.getMaxValueConstraint().getMaxValue());
            c.setAppliesTo(getOffChainPurposeFieldConstraint(purposeConstraint.getMaxValueConstraint().getPurposeFieldConstraint()));
            c.setConstraintType(PurposeFieldConstraint.ConstraintType.MAX_VALUE);
            return c;

        } else if (purposeConstraint.hasMinValueConstraint()) {

            MinValueConstraint c = new MinValueConstraint();
            c.setIncludeMin(purposeConstraint.getMinValueConstraint().getIncludeMin());
            c.setMinValue(purposeConstraint.getMinValueConstraint().getMinValue());
            c.setAppliesTo(getOffChainPurposeFieldConstraint(purposeConstraint.getMinValueConstraint().getPurposeFieldConstraint()));
            c.setConstraintType(PurposeFieldConstraint.ConstraintType.MIN_VALUE);
            return c;

        } else if (purposeConstraint.hasOneOfConstraint()) {

            OneOfConstraint c = new OneOfConstraint();
            c.setAvailableValues(purposeConstraint.getOneOfConstraint().getAvailableValuesList().parallelStream().collect(Collectors.toList()));
            c.setAppliesTo(getOffChainPurposeFieldConstraint(purposeConstraint.getOneOfConstraint().getPurposeFieldConstraint()));
            c.setConstraintType(PurposeFieldConstraint.ConstraintType.ONE_OF);
            return c;

        } else if (purposeConstraint.hasPatternConstraint()) {

            PatternConstraint c = new PatternConstraint();
            c.setPattern(purposeConstraint.getPatternConstraint().getPattern());
            c.setAppliesTo(getOffChainPurposeFieldConstraint(purposeConstraint.getPatternConstraint().getPurposeFieldConstraint()));
            c.setConstraintType(PurposeFieldConstraint.ConstraintType.PATTERN);
            return c;

        }

        return null;
    }


    protected Common.PurposeFieldConstraint getOnChainPurposeFieldConstraint(PurposeFieldConstraint pfc) {

        Common.PurposeFieldConstraint.Builder appliesToBuilder = Common.PurposeFieldConstraint.newBuilder();
        if (pfc != null && pfc.getAppliesTo() != null && !pfc.getAppliesTo().isEmpty()) {

            for (PurposeField.Type type : pfc.getAppliesTo()) {
                appliesToBuilder.addAppliesTo(purposeFieldTypeAdapter.toOnChainModel(type));
            }
        }

        return appliesToBuilder.build();
    }

    protected List<PurposeField.Type> getOffChainPurposeFieldConstraint(Common.PurposeFieldConstraint origin) {

        List<PurposeField.Type> result = new ArrayList<>();

        if (origin != null && origin.getAppliesToList() != null && origin.getAppliesToCount() > 0) {
            for (Common.PurposeFieldType type : origin.getAppliesToList()) {
                result.add(purposeFieldTypeAdapter.toOffchainModel(type));
            }
        }

        return result;
    }
}
