package com.ibm.au.bgx.common.queue;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.pojo.notification.EmailNotification;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.queue.QueueConsumer.EmailQueueConsumer;
import com.ibm.au.bgx.model.queue.QueueHandler;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @author Peter Ilfrich
 */
@Component
public class RabbitEmailNotificationConsumer implements EmailQueueConsumer {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired(required = false)
    QueueHandler<EmailNotification> handler;

    @Override
    public void registerConsumer(String queueName, QueueClient client) throws IOException {
        RabbitQueueClient queueClient = (RabbitQueueClient) client;
        queueClient.getChannel()
                .basicConsume(queueName, false, this.getConsumer(queueClient.getChannel()));
    }

    public Consumer getConsumer(Channel channel) {
        RabbitEmailNotificationConsumer self = this;
        if (self.handler == null) {
            throw new RuntimeException("No QueueHandler<EmailNotification> available.");
        }
        return new DefaultConsumer(channel) {

            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                                       BasicProperties properties, byte[] body) throws IOException {

                // TODO: we need to catch missed de-serialising, since re-execution wouldn't do any good
                EmailNotification notification = MAPPER.readValue(body, EmailNotification.class);
                // send the notification, client may provide any required components (like the handler)
                self.handler.handle(notification);
                channel.basicAck(envelope.getDeliveryTag(), false);
            }
        };
    }
}
