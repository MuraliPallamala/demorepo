package com.ibm.au.bgx.common.rest;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */
import com.ibm.au.bgx.model.api.NewCoAdminReferrerClient;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.api.request.OnboardingRequest;
import com.ibm.au.bgx.model.pojo.api.response.OnboardingResponse;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

/**
 * Default implementation of Referral client interface This communicates with NewCo Admin API for
 * onboarding an organization
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class NewCoAdminReferrerClientImpl extends AbstractNewCoAdminClient implements
    NewCoAdminReferrerClient {

    private static Logger LOGGER = LoggerFactory.getLogger(NewCoAdminReferrerClientImpl.class);


    public String getOnboardingUrl() {
        String url = getBaseUrl() + "/profile/onboarding-requests";
        return url;
    }

    @Override
    public OnboardingResponse onboard(OnboardingRequest onboardingRequest)
        throws ServiceUnavailableException, HttpClientErrorException {


        if (onboardingRequest == null
            || onboardingRequest.getProfile() == null
            || onboardingRequest.getReferrer() == null
            || onboardingRequest.getReferrer().getId() == null
            || onboardingRequest.getReferrer().getReferrerToken() == null
            ) {
            throw new IllegalArgumentException("Onboarding request is malformed. Profile and referrer information are required");
        }

        String url = getOnboardingUrl();
        
        try {

            String referrerToken = UUID.randomUUID().toString();
            RestTemplate rest = this.getRestTemplate(url);
    
            HttpHeaders headers = getHeaders();
            headers.add(ApiConstants.ONBOARDING_HEADER_REFERRER_TOKEN, referrerToken);
            this.addRequestHash(headers, onboardingRequest, onboardingRequest.getReferrer().getId());
    
            HttpEntity<OnboardingRequest> request = new HttpEntity<>(onboardingRequest, headers);
    
            LOGGER.debug(BgxLogMarkers.DEV, String.format("> POST %s | Posting new onboarding request for '%s'", url, onboardingRequest.getProfile().getBusinessId(), url));
    
            ResponseEntity<OnboardingResponse> response = rest
                .exchange(url, HttpMethod.POST, request, OnboardingResponse.class);
    
            return response.getBody();
        
        } catch(IOException | URISyntaxException ioex) {
            
            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }
    }
}
