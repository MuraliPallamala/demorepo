package com.ibm.au.bgx.common.rest;

import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.api.NewCoAdminOnboardingClient;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest;
import com.ibm.au.bgx.model.pojo.api.response.OrgRequestActionResponse;
import com.ibm.au.bgx.model.pojo.onboarding.OnboardingNotification;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * Default implementation of Onboarding client interface
 *
 * This communicates with NewCo Admin API for self onboarding or initial signup operations
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class NewCoAdminOnboardingClientImpl extends AbstractNewCoAdminClient implements
    NewCoAdminOnboardingClient {

    private static final Logger LOGGER = LoggerFactory
        .getLogger(NewCoAdminOnboardingClientImpl.class);

    @Override
    public OrgProfileRequest getOnboardingDetails(String key, String token)
        throws ServiceUnavailableException {

        String url = getBaseUrl() + "/profile/onboarding-requests/new";


        try {
            
            RestTemplate rest = this.getRestTemplate(url);
            LOGGER.debug(BgxLogMarkers.DEV, "> GET {} (key: {}, token: {})", url, key, token);
    
            HttpHeaders headers = getHeaders();
            headers.add(ApiConstants.ONBOARDING_HEADER_DLT_REQUEST_KEY, key);
            headers.add(ApiConstants.ONBOARDING_HEADER_DLT_AUTH_TOKEN, token);
            HttpEntity<?> request = new HttpEntity<>(headers);
    
            ResponseEntity<OrgProfileRequest> response = rest
                .exchange(url, HttpMethod.GET, request, OrgProfileRequest.class);
    
            return response.getBody();
            
        } catch(IOException | URISyntaxException ioex) {
            
            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }
    }

    @Override
    public OrgRequestActionResponse sendConfirmAction(OrgProfileRequest orgProfileRequest,
                                                      String key, String token, OrgRequestActionRequest actionRequest)
        throws ServiceUnavailableException {

        String url = String.format("%s/profile/onboarding-requests/%s/actions", getBaseUrl(), orgProfileRequest.getId());
        LOGGER.debug(BgxLogMarkers.DEV, "> POST {} (key: {}, token: {})", url, key, token);
        
        try {
        
            RestTemplate rest = this.getRestTemplate(url);
    
            HttpHeaders headers = getHeaders();
            headers.add(ApiConstants.ONBOARDING_HEADER_DLT_REQUEST_KEY, key);
            headers.add(ApiConstants.ONBOARDING_HEADER_DLT_AUTH_TOKEN, token);
            this.addRequestHash(headers, actionRequest, identityConfig.getIdentity());
            HttpEntity<OrgRequestActionRequest> request = new HttpEntity<>(actionRequest, headers);
    
            ResponseEntity<OrgRequestActionResponse> response = rest
                .exchange(url, HttpMethod.POST, request, OrgRequestActionResponse.class);
    
            return response.getBody();
        
        } catch(IOException | URISyntaxException ioex) {
            
            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }
    }


    @Override
    public String getToken(String requestId) throws ServiceUnavailableException {

        String url = String
            .format("%s/profile/onboarding-requests/%s/token", getBaseUrl(), requestId);
        LOGGER.debug(BgxLogMarkers.DEV, "> GET {}", url);
        try {
            
            RestTemplate rest = this.getRestTemplate(url);

            HttpHeaders headers = this.getHeaders();
            HttpEntity<?> request = new HttpEntity<>(headers);
    
            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = rest.exchange(url, HttpMethod.GET, request, Map.class);
    
            return (String) response.getBody().get(ApiConstants.FIELD_ONBOARDING_TOKEN);
            
        } catch(IOException | URISyntaxException ioex) {
            
            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }
    }


    @Override
    public boolean removeOnboardingRequest(String requestId, String key, String token)
        throws ServiceUnavailableException {

        String url = String.format("%s/profile/onboarding-requests/%s", getBaseUrl(), requestId);
        LOGGER.debug(BgxLogMarkers.DEV, "> DELETE {}", url);

        HttpHeaders headers = getHeaders();
        headers.add(ApiConstants.ONBOARDING_HEADER_DLT_REQUEST_KEY, key);
        headers.add(ApiConstants.ONBOARDING_HEADER_DLT_AUTH_TOKEN, token);

        try {
            
            RestTemplate rest = this.getRestTemplate(url);
            HttpEntity<?> request = new HttpEntity<>(headers);
    
            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = rest.exchange(url, HttpMethod.DELETE, request, Map.class);
            if (response.getStatusCode().equals(HttpStatus.NO_CONTENT)) {
                return true;
            }
            LOGGER.error(BgxLogMarkers.DEV,
                "HTTP request was successful, but response code didn't match '204', but was '{}'",
                response.getStatusCodeValue());
    
            return false;
            
        } catch(IOException | URISyntaxException ioex) {
            
            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }

    }

    @Override
    public OrgRequestActionResponse sendCompleteSignupNotification(UserProfile userProfile,
                                                                   String key, String token) throws ServiceUnavailableException {

        if (userProfile == null) {
            throw new IllegalArgumentException("Contact info cannot be null");
        }

        String url = String
            .format("%s%s", this.getBaseUrl(), ApiConstants.ONBOARDING_NOTIFICATION_ENDPOINT);

        HttpHeaders headers = this.getHeaders();
        headers.add(ApiConstants.ONBOARDING_HEADER_DLT_REQUEST_KEY, key);
        headers.add(ApiConstants.ONBOARDING_HEADER_DLT_AUTH_TOKEN, token);

        OnboardingNotification notification = new OnboardingNotification();
        notification.setPayload(new HashMap<>());
        notification.getPayload().put(BgxConstants.NOTIFICATION_TYPE, BgxConstants.USER_COMPLETED_ONBOARDING);
        notification.getPayload().put(BgxConstants.KEY_USER_EMAIL, userProfile.getEmail());
        notification.getPayload().put(BgxConstants.KEY_ORG_ID, userProfile.getPrimaryOrgId());

        // Set referrer info
        notification.getPayload().put(BgxConstants.KEY_REFERRER_ID, identityConfig.getIdentity());

        // Add referrer header
        this.addRequestHash(headers, notification, identityConfig.getIdentity());

        LOGGER.debug(BgxLogMarkers.DEV, "> POST {}", url);

        try {
            
            RestTemplate rest = this.getRestTemplate(url);
 
            HttpEntity<?> httpRequest = new HttpEntity<>(notification, headers);
            ResponseEntity<String> response = rest.exchange(url, HttpMethod.POST, httpRequest, String.class);
            LOGGER.debug(BgxLogMarkers.DEV, "Notification response: {}", response);
    
            if (!response.getStatusCode().equals(HttpStatus.OK)) {
                // just log the error, no need to take action or throw an exception
                LOGGER.error(
                    "Sending notification returned an invalid status code: {}",
                    response.getStatusCode()
                );
            }
    
            return null;
        
       } catch(IOException | URISyntaxException ioex) {
            
            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
       }
    }

    @Override
    public void sendAdminUserRejection(String orgId, String rejectUserEmail) throws ServiceUnavailableException {

        String url = String.format("%s%s", this.getBaseUrl(), ApiConstants.ONBOARDING_NOTIFICATION_ENDPOINT);

        OnboardingNotification notification = new OnboardingNotification();
        notification.setPayload(new HashMap<>());
        notification.getPayload().put(BgxConstants.NOTIFICATION_TYPE, BgxConstants.USER_REJECTED_ONBOARDING);
        // set info about the user
        notification.getPayload().put(BgxConstants.KEY_USER_EMAIL, rejectUserEmail);
        notification.getPayload().put(BgxConstants.KEY_ORG_ID, orgId);
        // Set referrer info
        notification.getPayload().put(BgxConstants.KEY_REFERRER_ID, identityConfig.getIdentity());

        // Add referrer header
        HttpHeaders headers = this.getHeaders();
        this.addRequestHash(headers, notification, identityConfig.getIdentity());

        try {

            RestTemplate rest = this.getRestTemplate(url);

            HttpEntity<?> httpRequest = new HttpEntity<>(notification, headers);
            ResponseEntity<String> response = rest.exchange(url, HttpMethod.POST, httpRequest, String.class);
            LOGGER.debug(BgxLogMarkers.DEV, "Notification response: {}", response);

        } catch (IOException | URISyntaxException ioex) {
            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }
    }
}
