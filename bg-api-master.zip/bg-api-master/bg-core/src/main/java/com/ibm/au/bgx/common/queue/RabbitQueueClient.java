package com.ibm.au.bgx.common.queue;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.IdentityConfig;
import com.ibm.au.bgx.model.api.SystemStatusResource;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.notification.EmailTemplates;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.chain.BlockchainEvent;
import com.ibm.au.bgx.model.pojo.notification.EmailNotification;
import com.ibm.au.bgx.model.pojo.notification.NetworkSyncNotification;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.notification.WebNotification.Status;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.queue.QueueConsumer.BatchProcessTaskConsumer;
import com.ibm.au.bgx.model.queue.QueueConsumer.BlockchainEventConsumer;
import com.ibm.au.bgx.model.queue.QueueConsumer.EmailQueueConsumer;
import com.ibm.au.bgx.model.queue.QueueConsumer.NetworkSyncQueueConsumer;
import com.ibm.au.bgx.model.queue.QueueConsumer.WebQueueConsumer;
import com.ibm.au.bgx.model.repository.BatchProcessTaskRepository;
import com.ibm.au.bgx.model.repository.EmailNotificationRepository;
import com.ibm.au.bgx.model.repository.UserProfileRepository;
import com.ibm.au.bgx.model.repository.WebNotificationRepository;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.math.BigInteger;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeoutException;

import javax.annotation.PostConstruct;

/**
 * @author Peter Ilfrich
 */
@Component
@Primary
public class RabbitQueueClient implements QueueClient {

    public static final int QUEUE_DEFAULT_PORT = 15672;

    public static final String EXCHANGE_NAME = "bgxQueue";
    private static final String SYSTEM_STATUS_IDENTIFIER = "RabbitMQ";

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();
    private static final Logger LOGGER = LoggerFactory.getLogger(RabbitQueueClient.class);

    @Autowired
    SystemStatusResource systemStatus;
    @Value("${queue.url:localhost}")
    private String queueUrl;
    @Value("${queue.username:guest}")
    private String queueUsername;
    @Value("${queue.password:guest}")
    private String queuePassword;
    @Value("${queue.receiver:false}")
    private boolean queueReceiverFlag;
    // each attempt is 3 seconds delay
    @Value("${queue.maxReconnectAttempts:10}")
    private int maxReconnect;

    @Value("${mail.from:noreply@dlt.res.ibm.com}")
    private String defaultEmailFrom;

    @Value(("${mail.replyTo:noreply@dlt.res.ibm.com}"))
    private String emailReplyTo;

    @Value("${bgx.emails.subject.prefix:Lygon 1B - }")
    private String subjectPrefix;

    @Value("${mail.support.address:}")
    private String supportEmail;
    
    
    // consumer only available in service api
    @Autowired(required = false)
    private WebQueueConsumer webConsumer;

    @Autowired(required = false)
    private EmailQueueConsumer emailConsumer;

    @Autowired(required = false)
    private BatchProcessTaskConsumer batchProcessConsumer;

    @Autowired(required = false)
    private BlockchainEventConsumer blockchainEventconsumer;

    @Autowired(required = false)
    private NetworkSyncQueueConsumer networkSyncConsumer;

    // repositories for the queue elements
    @Autowired

    private WebNotificationRepository webRepository;

    @Autowired
    private EmailNotificationRepository emailRepository;

    @Autowired
    private BatchProcessTaskRepository batchProcessRepository;

    // other repositories used for lookup
    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private IdentityConfig identityConfig;

    /**
     * The channel opened by this queue client in the postConstruct
     */
    private Channel channel;

    @PostConstruct
    public void postConstruct() throws IOException, TimeoutException, InterruptedException {

        systemStatus.registerComponent(SYSTEM_STATUS_IDENTIFIER);
        this.connectChannels();
        systemStatus.setComponentReady(SYSTEM_STATUS_IDENTIFIER);
    }

    protected void connectChannels() throws IOException, TimeoutException, InterruptedException {

        ConnectionFactory factory = new ConnectionFactory();
        try {

            URI uri = new URI(this.queueUrl);

            String userInfo = uri.getUserInfo();
            if (userInfo == null && this.queueUsername != null && this.queuePassword != null) {
                uri = new URI(uri.getScheme(),
                        String.format("%s:%s", this.queueUsername, this.queuePassword),
                        uri.getHost(),
                        uri.getPort() != -1 ? uri.getPort() : RabbitQueueClient.QUEUE_DEFAULT_PORT,
                        uri.getPath(), uri.getQuery(), uri.getFragment());

            } else if (this.queueUsername != null && LOGGER.isWarnEnabled()) {

                LOGGER.warn(BgxLogMarkers.DEV,
                        "Username information is defined in both the queue URL and the queuse Username attributes, URI defined parameters take precedence.");
            }

            factory.setUri(uri);

            Connection connection = null;
            int attempts = 0;
            while (connection == null) {
                try {

                    LOGGER.debug(BgxLogMarkers.DEV,
                            "Attempting connect: (host: {}, port: {}, attempts: {}/{})...",
                            uri.getHost(), uri.getPort(), attempts + 1, maxReconnect);
                    connection = factory.newConnection();

                } catch (Exception e) {

                    // abort condition will throw exception, failing startup
                    if (attempts >= maxReconnect) {
                        LOGGER.error(String.format("Connected %s:%d", uri.getHost(), uri.getPort()),
                                e);
                        throw e;
                    }

                    // wait for 3 seconds and try again
                    Thread.sleep(3000);
                    attempts += 1;
                }
            }

            LOGGER.debug(BgxLogMarkers.DEV, "Connected to RabbitMQ. Creating channel and declare queues...");

            try {
                this.channel = connection.createChannel();
                this.channel.basicQos(1);
                this.channel.exchangeDeclare(EXCHANGE_NAME, "direct", true);
                for (String queueName : new String[]{QueueClient.CHANNEL_EMAIL,
                        QueueClient.CHANNEL_WEB,
                        QueueClient.CHANNEL_IMPEX,
                        QueueClient.CHANNEL_REPORT,
                        QueueClient.CHANNEL_BATCH,
                        QueueClient.CHANNEL_EVENT,
                        QueueClient.CHANNEL_NETWORK
                }) {

                    this.channel.queueDeclare(queueName, true, false, false, null);

                    // 3rd parameter = routingKey???
                    // TODO: check what that is (it's also used in basicPublish
                    //
                    this.channel.queueBind(queueName, EXCHANGE_NAME, queueName);
                }
                LOGGER.debug(BgxLogMarkers.DEV, "Connected to RabbitMQ channel");
                // register consumers
                if (this.queueReceiverFlag) {
                    LOGGER.debug(BgxLogMarkers.DEV, "Registering queue handler");
                    this.registerEmailNotificationHandler();
                    this.registerWebNotificationHandler();
                    this.registerBatchProcessTaskHandler();
                    this.registerImpexHandler();
                    this.registerReportHandler();
                    this.registerBlockchainEventHandler();
                    this.registerNetworkSyncHandler();
                }

            } catch (Exception e) {

                LOGGER.error("Error joining RabbitMQ channel. Closing connection", e);
                if (connection != null) {
                    connection.close();
                }
                throw e;
            }

        } catch (URISyntaxException | KeyManagementException | NoSuchAlgorithmException ex) {

            // TODO: improve the exception management, this should not be an I/O Exception
            //
            throw new IOException("An error occurred while creating the connection to the queue.",
                    ex);

        }

        // register shutdown listener
        RabbitQueueClient self = this;
        channel.addShutdownListener(e -> {
            try {
                LOGGER.debug(BgxLogMarkers.DEV, "Reconnecting channels after shutdown of channel", e);
                self.connectChannels();
            } catch (Exception rex) {
                LOGGER.error("Could not reconnect channel after it got closed.", rex);
            }
        });
    }

    @Override
    public void addEmailNotification(EmailNotification message) throws IOException {
        if (message.getFrom() == null) {
            message.setFrom(defaultEmailFrom);
        }

        if (message.getRevision() == null) {
            message = emailRepository.addItem(message);
        }

        if (!message.getSubject().startsWith(subjectPrefix)) {
            message.setSubject(String.format("%s%s", subjectPrefix, message.getSubject()));
        }

        LOGGER.debug(BgxLogMarkers.DEV, "Adding email notification for {}", message.getTo());
        this.publish(EXCHANGE_NAME, QueueClient.CHANNEL_EMAIL, MAPPER.writeValueAsBytes(message));
    }

    @Override
    public void addEmailNotification(EmailNotification message, String orgId) throws IOException {
        // process users of this org
        List<UserProfile> users = userProfileRepository.getByPrimaryOrgId(orgId);
        for (UserProfile profile : users) {

            // create copy of the notification object
            EmailNotification email = new EmailNotification();
            BeanUtils.copyProperties(message, email);

            // set recipient and add it to the queue
            email.setTo(profile.getEmail());
            this.addEmailNotification(email);
        }
    }

    @Override
    public void addWebNotification(WebNotification message) throws IOException {
        message.setStatus(Status.NEW);
        if (message.getRevision() == null) {
            message = webRepository.addItem(message);
        }
        LOGGER.debug(BgxLogMarkers.DEV, "Adding web notification {}", message.getMessageType());
        this.publish(EXCHANGE_NAME, QueueClient.CHANNEL_WEB, MAPPER.writeValueAsBytes(message));
    }

    @Override
    public void addWebNotification(WebNotification message, String orgId) throws IOException {

        if (orgId == null) {
            throw new IllegalArgumentException("Parameter 'orgId' is required");
        }

        List<UserProfile> users = userProfileRepository.getByPrimaryOrgId(orgId);
        processWebNotification(message, users);
    }

    @Override
    public void addWebNotification(WebNotification message, String orgId, String role)
            throws IOException {
        List<UserProfile> users = userProfileRepository.getByOrgRole(orgId, role);
        processWebNotification(message, users);
    }

    @Override
    public void addWebNotification(WebNotification message, List<UserProfile> receivers) throws IOException {
        this.processWebNotification(message, receivers);
    }

    @Override
    public void addBatchProcessTask(BatchProcessTask message) throws IOException {
        if (message.getRevision() == null) {
            message = batchProcessRepository.addItem(message);
        }

        LOGGER.debug(BgxLogMarkers.DEV, "Adding batch process (type: {})...",
                message.getType().toString());

        this.publish(EXCHANGE_NAME, QueueClient.CHANNEL_BATCH, MAPPER.writeValueAsBytes(message));
    }

    @Override
    public void addBlockchainEvent(BlockchainEvent event) throws IOException {

        // we're not storing the item in off-chain, because the payload contains all the gx data as well

        LOGGER.debug(BgxLogMarkers.DEV, "Adding blockchain event (name: {})..", event.getEventName());
        this.publish(EXCHANGE_NAME, QueueClient.CHANNEL_EVENT, MAPPER.writeValueAsBytes(event));
    }

    @Override
    public void addNetworkSyncNotification(NetworkSyncNotification notification)
            throws IOException {

        LOGGER.debug(BgxLogMarkers.DEV, "Adding network sync notification(target: {}, type: {})..",
                notification.getTargetId(), notification.getSyncType());

        // set the retry count to ZERO
        notification.setRetryCount(BigInteger.ZERO);

        this.publish(EXCHANGE_NAME, QueueClient.CHANNEL_NETWORK,
                MAPPER.writeValueAsBytes(notification));
    }

    @Override
    public void registerWebNotificationHandler() throws IOException {
        this.webConsumer.registerConsumer(QueueClient.CHANNEL_WEB, this);
    }

    @Override
    public void registerEmailNotificationHandler() throws IOException {
        LOGGER.debug(BgxLogMarkers.DEV, "Registering Email notification handler for channel {}",
                QueueClient.CHANNEL_EMAIL);
        this.emailConsumer.registerConsumer(QueueClient.CHANNEL_EMAIL, this);
    }

    @Override
    public void registerBatchProcessTaskHandler() throws IOException {
        LOGGER.debug(BgxLogMarkers.DEV, "Registering Batch process handler for channel {}",
                QueueClient.CHANNEL_BATCH);
        this.batchProcessConsumer.registerConsumer(QueueClient.CHANNEL_BATCH, this);
    }

    @Override
    public void registerBlockchainEventHandler() throws IOException {
        LOGGER.debug(BgxLogMarkers.DEV, "Registering Blockchain Event handler for channel {}",
                QueueClient.CHANNEL_EVENT);
        this.blockchainEventconsumer.registerConsumer(QueueClient.CHANNEL_EVENT, this);
    }

    @Override
    public void registerReportHandler() {

    }

    @Override
    public void registerImpexHandler() {

    }

    @Override
    public void registerNetworkSyncHandler() throws IOException {
        LOGGER.debug(BgxLogMarkers.DEV, "Registering Network Sync handler for channel {}",
                QueueClient.CHANNEL_NETWORK);
        this.networkSyncConsumer.registerConsumer(QueueClient.CHANNEL_NETWORK, this);
    }

    @Override
    public void sendSupportEmail(String message) {
        // determine received id
        String receiver = null;
        if (!"".equals(this.supportEmail)) {
            receiver = this.supportEmail;
        } else if (this.identityConfig.isIssuer() || this.identityConfig.isNewCoAdmin()) {
            receiver = this.getIdentityAdminEmail();
        } 

        if (receiver == null) {
            LOGGER.error("Couldn't send support email for message: {}", message);
            return;
        }

        
        // compile email
        EmailNotification email = new EmailNotification();
        email.setFrom(defaultEmailFrom);
        email.setTo(receiver);
        email.setSubject(String.format("Error on DLT Platform: %s", Instant.now().toString()));
        
        // [CV] NOTE: kept for rollback untile verified it works.
        //
        // email.setBody(message);

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("message", message);
        email.setPayload(model);
        email.setTemplateId(EmailTemplates.PLATFORM_ERROR_TEMPLATE_ID);

        // send email
        try {
            this.addEmailNotification(email);
        } catch (IOException ioe) {
            LOGGER.error("Failed to send email notification", ioe);
        }
    }

    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    protected void processWebNotification(WebNotification message, List<UserProfile> profiles)
            throws IOException {

        LOGGER.debug("Processing web notification {} for {} users", message.getMessageType(), profiles.size());
        // create event identifier
        message.setEventId(UUID.randomUUID().toString());
        message.setStatus(Status.NEW);

        // clean up message object
        if (message.getRevision() != null) {
            message.setRevision(null);
        }
        if (message.getId() != null) {
            message.setId(null);
        }
        // serialise the message (avoids references to the same message when iterating)
        String messageRaw = MAPPER.writeValueAsString(message);

        for (UserProfile user : profiles) {
            LOGGER.debug("Sending web notification for user (email: {}).", user.getEmail());

            // de-serialise the message fresh for each user
            message = MAPPER.readValue(messageRaw, WebNotification.class);
            // set the receiver
            message.setReceiverId(user.getId());
            // store the notification
            webRepository.addItem(message);

            // and publish it to the queue
            this.publish(EXCHANGE_NAME, QueueClient.CHANNEL_WEB, MAPPER.writeValueAsBytes(message));
        }
    }


    protected void publish(String exchangeName, String channelName, byte[] data)
            throws IOException {

        // make sure the channel is open
        if (!channel.isOpen()) {
            try {
                this.connectChannels();
            } catch (Exception e) {
                LOGGER.error("Could not reconnect to RabbitMQ", e);
                throw new IOException("Error reconnecting to RabbitMQ", e);
            }

        }
        channel.basicPublish(exchangeName, channelName, null, data);
    }

    protected String getIdentityAdminEmail() {
        List<UserProfile> orgUsers = this.userProfileRepository.getByPrimaryOrgId(identityConfig.getIdentity());
        for (UserProfile user : orgUsers) {
            if (user.getUserRoles().containsKey(identityConfig.getIdentity()) && user.getUserRoles().get(identityConfig.getIdentity()).contains(BgxConstants.ROLE_ADMIN)) {
                return user.getEmail();
            }
        }

        return null;
    }

}
