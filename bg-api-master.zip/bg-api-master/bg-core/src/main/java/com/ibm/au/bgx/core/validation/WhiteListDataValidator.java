/**
 * 
 */
package com.ibm.au.bgx.core.validation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.validation.WhiteListManager;

/**
 * Class <b>WhiteListDataValidator</b>. This class extends {@link BgxDataValidatorImpl} and
 * extends the profile validation capabilities of the validator by supporting the ability
 * to white list specific profiles to bypass the validation of business identifiers. The
 * white-listing capabilities are implemented by means of a configured implementation of
 * {@link WhiteListManager} which is auto-wired into the validator.
 * 
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
@Primary
@Component
public class WhiteListDataValidator extends BgxDataValidatorImpl {
	
	/**
	 * A {@link Logger} instance that collects all the log messages produced by the instances
	 * of this class.
	 */
    private static final Logger LOGGER = LoggerFactory.getLogger(WhiteListDataValidator.class);


	/**
	 * A {@link WhiteListManager} implementation that, if defined is
	 * used to bypass the validation of business identifiers during
	 * the validation of organisation profiles, for profiles that
	 * match those in the white list.
	 */
	@Autowired
	protected WhiteListManager whiteListManager;
	
	/**
	 * Validates the business identifier associated to the given organisation profile. This 
	 * method specialises the behaviour of the base method by testing whether the given 
	 * organisation profile is white-listed and if that is the case it skips the validation`q
 	 * of the business identifier.
	 * 
     * 
     * @param profile	a {@link OrgProfile} whose business identifier is validated. It is
     * 					expected to not to be {@literal null}.
     * 
     * @throws DataValidationException 	if <i>profile</i> is not white-listed and the associated
     * 									business identifier is not valid.
	 * 
	 */
	@Override
	protected void validateBusinessId(OrgProfile profile) {
		
		String candidate = profile.getBusinessId();
    	if (candidate == null) {
    		
    		throw new DataValidationException(String.format("Organization profile (id: %s) has a null business identifier.", profile.getId()));
    	}
    	
    	boolean isWhiteListed = false;
    	
    	if (this.whiteListManager != null) {
        	
        	// [CV] NOTE: this conditions checks whether the profile is white listed
        	//            if the check returns true, then business validation is set
        	//            to false (not required).
        	//
    		isWhiteListed = this.whiteListManager.isWhiteListed(profile);
        	
        	if (isWhiteListed) {
        	
        		LOGGER.info("Organization ({}, {}, {}) is WHITE LISTED validation of the business identifier is SKIPPED.", profile.getEntityName(), profile.getEntityType(), profile.getBusinessId());
        	}
        
        }
    	
    	if (!isWhiteListed) {
    		
    		this.validateBusinessId(candidate);
    	}
	}
}
