package com.ibm.au.bgx.core.chain.adapter;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.chain.Currency;
import com.ibm.au.bgx.model.shared.Common;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class CurrencyDataAdapter implements ChainDataAdapter<Common.Currency, Currency> {

    @Override
    public Common.Currency toOnChainModel(Currency input) {
        switch (input) {
            case AUD:
                return Common.Currency.AUD;
            case NZD:
                return Common.Currency.NZD;
            default:
            	throw new IllegalArgumentException("Unable to map Currency to on chain model");
        }
    }

    @Override
    public Currency toOffchainModel(Common.Currency input) {
        switch (input) {
            case AUD:
                return Currency.AUD;
            case NZD:
                return Currency.NZD;
            default:
            	throw new IllegalArgumentException("Unable to map Currency to off chain model");
        }
    }
}
