package com.ibm.au.bgx.core.chain.adapter.tc;


import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.tc.TcEmbeddedContent;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditionsEmbeddedData;
import java.util.Base64;
import org.springframework.stereotype.Component;

/**
 * A implementation of adapter interface {@link ChainDataAdapter} to perform on-chain and off-chain
 * data model conversion for terms and conditions embedded content record
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class TcEmbeddedContentAdapter implements
    ChainDataAdapter<TermsConditionsEmbeddedData, TcEmbeddedContent> {

    @Override
    public TermsConditionsEmbeddedData toOnChainModel(TcEmbeddedContent content) {
        if (content == null) {
            throw new IllegalArgumentException("Input off-chain TC content cannot be null");
        }

        TermsConditionsEmbeddedData.Builder b = TermsConditionsEmbeddedData.newBuilder();
        b.setText(TcEmbeddedContentAdapter.encode(content.getText()));
        return b.build();
    }

    @Override
    public TcEmbeddedContent toOffchainModel(TermsConditionsEmbeddedData content) {

        if (content == null) {
            throw new IllegalArgumentException("Input on-chain TC content cannot be null");
        }

        TcEmbeddedContent ec = new TcEmbeddedContent();
        ec.setText(TcEmbeddedContentAdapter.decode(content.getText()));

        return ec;
    }

    public static String encode(String text) {
        return Base64.getEncoder().encodeToString(text.getBytes());
    }

    public static String decode(String text) {
        return new String(Base64.getDecoder().decode(text));
    }
}
