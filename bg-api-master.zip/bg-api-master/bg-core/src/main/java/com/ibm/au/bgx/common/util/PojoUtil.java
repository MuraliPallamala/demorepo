/**
 *
 */
package com.ibm.au.bgx.common.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.util.JacksonUtil;

import java.util.Map;

/**
 * Class <b>PojoUtil</b>. This class is a wrapper around the capability of {@link ObjectMapper}
 * that is used to convert to and from a {@link Map} implementation and a given specified type.
 * Because {@link ObjectMapper} is thread safe, there is no need to create an instance of the
 * mapper in every class that requires JSON/POJO conversion. We can then use {@link PojoUtil}
 * to make the cleaner and reduce the underlying dependency to {@link ObjectMapper}.
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
public class PojoUtil {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();


    public static ObjectMapper getMapper() {

        return MAPPER;
    }

    public static <T> T toPojo(Map<String, Object> raw, Class<T> type) {

        if (raw == null) {

            throw new IllegalArgumentException("Parameter 'raw' cannot be null.");
        }

        if (type == null) {

            throw new IllegalArgumentException("Parameter 'type' cannot be null.");
        }

        return MAPPER.convertValue(raw, type);
    }

    public static <T> Map<String, Object> toMap(T pojo) {

        if (pojo == null) {

            throw new IllegalArgumentException("Parameter 'pojo' cannot be null.");
        }

        return MAPPER.convertValue(pojo, new TypeReference<Map<String, Object>>() {
        });

    }
}
