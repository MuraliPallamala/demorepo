package com.ibm.au.bgx.core.approvalmodel;

import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.approvalmodel.SharedApprovalModelActionType;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ApprovalModelUtil {
    public static List<SharedApprovalModelActionType> gxPrefillTypes = Arrays.asList(
            SharedApprovalModelActionType.PREFILL_ISSUE_GUARANTEE,
            SharedApprovalModelActionType.PREFILL_AMEND_GUARANTEE,
            SharedApprovalModelActionType.PREFILL_CANCEL_GUARANTEE);

    public static List<SharedApprovalModelActionType> gxRequestTypes = Arrays.asList(
            SharedApprovalModelActionType.START_ISSUE_GUARANTEE,
            SharedApprovalModelActionType.START_AMEND_GUARANTEE,
            SharedApprovalModelActionType.START_CANCEL_GUARANTEE,
            SharedApprovalModelActionType.START_DEMAND_GUARANTEE,
            SharedApprovalModelActionType.START_PAYWALK_GUARANTEE,
            SharedApprovalModelActionType.START_TRANSFER_GUARANTEE);

    public static List<SharedApprovalModelActionType> gxIssueActionTypes = Arrays.asList(
            SharedApprovalModelActionType.APPROVE_ISSUE_GUARANTEE,
            SharedApprovalModelActionType.CANCEL_ISSUE_GUARANTEE,
            SharedApprovalModelActionType.REJECT_ISSUE_GUARANTEE
    );

    public static List<SharedApprovalModelActionType> gxAmendActionTypes = Arrays.asList(
            SharedApprovalModelActionType.APPROVE_AMEND_GUARANTEE,
            SharedApprovalModelActionType.CANCEL_AMEND_GUARANTEE,
            SharedApprovalModelActionType.REJECT_AMEND_GUARANTEE
    );

    public static List<SharedApprovalModelActionType> gxCancelActionTypes = Arrays.asList(
            SharedApprovalModelActionType.APPROVE_CANCEL_GUARANTEE,
            SharedApprovalModelActionType.CANCEL_CANCEL_GUARANTEE,
            SharedApprovalModelActionType.REJECT_CANCEL_GUARANTEE
    );

    public static List<SharedApprovalModelActionType> gxDemandActionTypes = Arrays.asList(
            SharedApprovalModelActionType.APPROVE_DEMAND_GUARANTEE,
            SharedApprovalModelActionType.CANCEL_DEMAND_GUARANTEE,
            SharedApprovalModelActionType.REJECT_DEMAND_GUARANTEE,
            SharedApprovalModelActionType.DEFER_DEMAND_GUARANTEE
    );


    public static List<SharedApprovalModelActionType> gxTransferActionTypes = Arrays.asList(
            SharedApprovalModelActionType.APPROVE_TRANSFER_GUARANTEE,
            SharedApprovalModelActionType.CANCEL_TRANSFER_GUARANTEE,
            SharedApprovalModelActionType.REJECT_TRANSFER_GUARANTEE
    );

    public static List<SharedApprovalModelActionType> gxApproveActionTypes = Arrays.asList(
        SharedApprovalModelActionType.APPROVE_ISSUE_GUARANTEE,
        SharedApprovalModelActionType.APPROVE_AMEND_GUARANTEE,
        SharedApprovalModelActionType.APPROVE_CANCEL_GUARANTEE,
        SharedApprovalModelActionType.APPROVE_DEMAND_GUARANTEE,
        SharedApprovalModelActionType.APPROVE_TRANSFER_GUARANTEE
    );

    public static List<SharedApprovalModelActionType> gxActionTypes = concatenate(
            ApprovalModelUtil.gxIssueActionTypes,
            ApprovalModelUtil.gxAmendActionTypes,
            ApprovalModelUtil.gxCancelActionTypes,
            ApprovalModelUtil.gxDemandActionTypes,
            ApprovalModelUtil.gxTransferActionTypes
    );


    public static List<SharedApprovalModelActionType> approvalModelTypes = Arrays.asList(
            SharedApprovalModelActionType.APPROVAL_FLOW_APPROVE,
            SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL,
            SharedApprovalModelActionType.APPROVAL_FLOW_REJECT
    );

    public static List<SharedApprovalModelActionType> nonApproveApprovalModelTypes = Arrays.asList(
            SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL,
            SharedApprovalModelActionType.APPROVAL_FLOW_REJECT
    );

    // TODO move
    // Generic function to concatenate multiple lists in Java
    @SafeVarargs
	public static <T> List<T> concatenate(List<T>... lists) {
        return Stream.of(lists)
                .flatMap(x -> x.stream())
                .collect(Collectors.toList());
    }

    // removes gx request payload and action payloads from approval model request
    // Note at the moment this is sufficient as there are no other types of requests that contain sensitive information.
    // Note we cannot delete the payloads of GxAction types as they're used by GxActionConverter
    // If GxActions end up containing sensitive information, we should instead resort to encryption
    public static ApprovalModelFlowRequest deleteGxReqPayloads(ApprovalModelFlowRequest approvalModelFlowRequest) {
        SharedApprovalModelActionType type;
        try {
            type = SharedApprovalModelActionType.fromValue(approvalModelFlowRequest.getType());
        } catch (IllegalArgumentException e) {
            return approvalModelFlowRequest;
        }
        if (gxRequestTypes.contains(type)) {
            approvalModelFlowRequest.setPayload(null);
            for (ApprovalModelFlowRequest action: approvalModelFlowRequest.getActions()) {
                action.setPayload(null);
            }
        }
        return approvalModelFlowRequest;
    }
}
