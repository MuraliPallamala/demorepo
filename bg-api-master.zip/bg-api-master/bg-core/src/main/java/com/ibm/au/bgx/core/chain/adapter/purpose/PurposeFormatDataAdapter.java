package com.ibm.au.bgx.core.chain.adapter.purpose;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.purpose.PurposeField;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;
import com.ibm.au.bgx.model.shared.Common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Data adapter to convert a purpose format from off-chain format into on-chain format and
 * vice-versa.
 *
 * @author Peter Ilfrich
 */
@Component
public class PurposeFormatDataAdapter implements ChainDataAdapter<Common.PurposeFormat, PurposeFormat> {

    @Autowired
    PurposeFieldDataAdapter purposeFieldDataAdapter;

    @Override
    public Common.PurposeFormat toOnChainModel(PurposeFormat purposeFormat) {

        Common.PurposeFormat.Builder builder = Common.PurposeFormat.newBuilder();
        // add meta data
        builder.setActive(purposeFormat.getActive())
                .setName(purposeFormat.getName())
                .setLabel(purposeFormat.getLabel())
                .setPdfTemplateId(purposeFormat.getPdfTemplateId())
                .setStringTemplate(purposeFormat.getStringTemplate())
                .setVersion(purposeFormat.getVersion());
        if (purposeFormat.getId() != null) {
            builder.setId(purposeFormat.getId());
        }

        // add fields
        for (PurposeField field : purposeFormat.getFields()) {
            builder.addPurposeField(purposeFieldDataAdapter.toOnChainModel(field));
        }

        return builder.build();
    }

    @Override
    public PurposeFormat toOffchainModel(Common.PurposeFormat purposeFormat) {
        PurposeFormat format = new PurposeFormat();
        format.setActive(purposeFormat.getActive());
        format.setName(purposeFormat.getName());
        format.setLabel(purposeFormat.getLabel());

        if (purposeFormat.getId() != null && !purposeFormat.getId().isEmpty()) {
            format.setId(purposeFormat.getId());
        }

        if (purposeFormat.getVersion() != null && !purposeFormat.getVersion().isEmpty()) {
            format.setVersion(purposeFormat.getVersion());
        }
        if (purposeFormat.getPdfTemplateId() != null && !purposeFormat.getPdfTemplateId().isEmpty()) {
            format.setPdfTemplateId(purposeFormat.getPdfTemplateId());
        }
        if (purposeFormat.getStringTemplate() != null && !purposeFormat.getStringTemplate().isEmpty()) {
            format.setStringTemplate(purposeFormat.getStringTemplate());
        }

        if (purposeFormat.getPurposeFieldCount() > 0) {
            List<PurposeField> fields = new ArrayList<>();
            for (Common.PurposeField field : purposeFormat.getPurposeFieldList()) {
                fields.add(purposeFieldDataAdapter.toOffchainModel(field));
            }
            format.setFields(fields);
        }

        return format;
    }
}
