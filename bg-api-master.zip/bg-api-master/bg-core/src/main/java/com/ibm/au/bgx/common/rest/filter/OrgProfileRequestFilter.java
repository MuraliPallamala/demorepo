package com.ibm.au.bgx.common.rest.filter;

import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class OrgProfileRequestFilter extends AbstractApiEntityFilter<OrgProfileRequest> {

    @Autowired
    OrgProfileFilter orgProfileFilter;

    @Override
    public OrgProfileRequest filterOne(OrgProfileRequest item, BgxPrincipal principal) {
        if (item == null) {
            return null;
        }

        // we don't filter for newco and newco-admin users
        if (principal != null && principal.isConsortiumUser()) {
            return item;
        }

        // filter fields
        if (principal != null
            && !StringUtils.isEmpty(principal.getConfiguredForOrgId())
            && item.getId().equals(principal.getConfiguredForOrgId())
            && principal.isAdminForOrg(principal.getConfiguredForOrgId())) {

            // return item for the org belonging to the principal
            return item;
        }

        // filter fields
        item.setProfile(orgProfileFilter.filterOne(item.getProfile(), principal));
        item.setCredentials(null);

        return item;
    }
}
