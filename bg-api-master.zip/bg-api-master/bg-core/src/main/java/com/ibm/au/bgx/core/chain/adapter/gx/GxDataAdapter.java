package com.ibm.au.bgx.core.chain.adapter.gx;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.ChannelResolverNamePrefixImpl;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.util.GxUtil;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxDataAdapter implements ChainDataAdapter<Gxs.GX, Gx> {

    private static final Logger LOGGER = LoggerFactory.getLogger(GxDataAdapter.class);

    public static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    GxAmountDataAdapter gxAmountDataAdapter;

    @Autowired
    GxStatusTypeDataAdapter gxStatusTypeDataAdapter;

    @Autowired
    GxPurposeDataAdapter gxPurposeDataAdapter;

    @Autowired
    private ChannelResolverNamePrefixImpl gxChannelResolver; // For Gx IDs

    @Override
    public Gxs.GX toOnChainModel(Gx input) {

        try {
            LOGGER.debug("Converting Gx input to on-chain model: {}", MAPPER.writeValueAsString(input));
        } catch (JsonProcessingException e) {
            // ignore
            LOGGER.warn("Could not serialize Gx", e);
        }

        Gxs.GX.Builder builder = Gxs.GX.newBuilder()
        							   .addAllApplicants(input.getApplicants())
        							   .addAllBeneficiaries(input.getBeneficiaries())
        							   .setPurposeType(input.getPurposeType())
        							   .setAmount(gxAmountDataAdapter.toOnChainModel(input.getAmount()))
        							   .setBankReference(input.getBankReference());

        if (input.getId() != null) {
            builder.setId(input.getId());
        }

        if (input.getPurpose() != null) {
            builder.putAllPurpose(this.gxPurposeDataAdapter.toOnChainModel(input.getPurpose()));
        }

        if (input.getExpiresAt() != null) {
            builder.setExpiresAt(this.timestampDataAdapter.toOnChainModel(input.getExpiresAt()));
        }

        // Status not usually set
        if (input.getStatus() != null) {
            builder.setStatus(this.gxStatusTypeDataAdapter.toOnChainModel(input.getStatus()));
        }

        if (input.getPrevGxId() != null) {
            builder.setPrevGxId(input.getPrevGxId());
        }

        if (input.getTcId() != null) {
            builder.setTcId(input.getTcId());
        }

        return builder.build();
    }

    @Override
    public Gx toOffchainModel(Gxs.GX input) {
    	
        Gx output = new Gx();
        // ID can be null for issue request payloads
        if (input.getId() != null && !input.getId().equals("")) {
            output.setIssuer(GxUtil.getIssuerIdFromChannelName(this.gxChannelResolver.get(input.getId())));
        }
        output.setId(input.getId());
        output.setApplicants(input.getApplicantsList());
        output.setBeneficiaries(input.getBeneficiariesList());
        output.setStatus(this.gxStatusTypeDataAdapter.toOffchainModel(input.getStatus()));
        output.setPurposeType(input.getPurposeType());
        output.setPurpose(this.gxPurposeDataAdapter.toOffchainModel(input.getPurposeMap()));

        output.setExpiresAt(this.timestampDataAdapter.toOffchainModel(input.getExpiresAt()));
        output.setAmount(this.gxAmountDataAdapter.toOffchainModel(input.getAmount()));
        output.setBankReference(input.getBankReference());
        output.setIssuedAt(this.timestampDataAdapter.toOffchainModel(input.getIssuedAt()));
        output.setUpdatedAt(this.timestampDataAdapter.toOffchainModel(input.getUpdatedAt()));
        output.setPrevGxId(input.getPrevGxId());
        output.setOnchainActiveRequests(input.getActiveFlows());
        output.setTcId(input.getTcId());

        return output;
    }
}
