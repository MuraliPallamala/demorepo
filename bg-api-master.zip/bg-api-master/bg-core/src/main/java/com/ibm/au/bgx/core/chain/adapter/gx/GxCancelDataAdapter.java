package com.ibm.au.bgx.core.chain.adapter.gx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.flow.FlowStatusDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxCancelPayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxCancelDataAdapter implements ChainDataAdapter<Gxs.GXCancelRequest, GxRequest> {

    public static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    TimestampDataAdapter timestampDataAdapter;


    @Autowired
    FlowStatusDataAdapter flowStatusDataAdapter;

    @Override
    public Gxs.GXCancelRequest toOnChainModel(GxRequest input) {

        GxCancelPayload cancelPayload = MAPPER.convertValue(input.getPayload(), GxCancelPayload.class);

        Gxs.GXCancelRequest.Builder builder = Gxs.GXCancelRequest.newBuilder()
                												 .setGxId(input.getGuaranteeId());

        if (input.getId() != null) {
            builder.setId(input.getId());
        }

        if (cancelPayload.getReason() != null) {
            builder.setReason(cancelPayload.getReason());
        }

        return builder.build();
    }

    @Override
    public GxRequest toOffchainModel(Gxs.GXCancelRequest input) {
        GxRequest output = new GxRequest();
        GxCancelPayload payload = new GxCancelPayload();
        payload.setReason(input.getReason());
        output.setPayload(payload);
        output.setId(input.getId());
        output.setType(GxRequestType.CANCEL);
        output.setStatus(this.flowStatusDataAdapter.toOffchainModel(input.getStatus()));
        output.setGuaranteeId(input.getGxId());
        output.setCreatedBy(input.getCreatedBy());
        output.setCreatedAt(this.timestampDataAdapter.toOffchainModel(input.getCreatedAt()));
        output.setUpdatedBy(input.getUpdatedBy());
        output.setUpdatedAt(this.timestampDataAdapter.toOffchainModel(input.getUpdatedAt()));
        return output;
    }
}
