package com.ibm.au.bgx.core.chain.adapter.gx;

import com.ibm.au.bgx.core.chain.adapter.AddressDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxSearchRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigInteger;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxSearchRequestDataAdapter implements ChainDataAdapter<Gxs.GXSearchRequest, GxSearchRequest> {

    @Autowired
    AddressDataAdapter addressDataAdapter;

    @Autowired
    GxStatusTypeDataAdapter gxStatusTypeDataAdapter;

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    GxSearchOrderByTypeDataAdapter gxSearchOrderByTypeDataAdapter;

    @Autowired
    GxSearchOrderTypeDataAdapter gxSearchOrderTypeDataAdapter;

    @Autowired
    GxPurposeDataAdapter gxPurposeDataAdapter;

    @Override
    public Gxs.GXSearchRequest toOnChainModel(GxSearchRequest input) {
        Gxs.GXSearchRequest.Builder builder = Gxs.GXSearchRequest.newBuilder();
        if (input.getStatus() != null) {
            builder.setStatus(
                    Gxs.GXStatusValue.newBuilder().setValue(this.gxStatusTypeDataAdapter.toOnChainModel(input.getStatus()))
            );
        }
        if (input.getStart() != null) {
            builder.setStart(input.getStart());
        }
        if (input.getLimit() != null) {
            builder.setLimit(input.getLimit().intValue());
        }
        if (input.getOrgId() != null) {
            builder.setOrgId(input.getOrgId());
        }
        if (input.getApplicantId() != null) {
            builder.setApplicantId(input.getApplicantId());
        }
        if (input.getBeneficiaryId() != null) {
            builder.setBeneficiaryId(input.getBeneficiaryId());
        }
        if (input.getIssuedAfter() != null) {
            builder.setIssuedAfter(this.timestampDataAdapter.toOnChainModel(input.getIssuedAfter()));
        }
        if (input.getIssuedBefore() != null) {
            builder.setIssuedBefore(this.timestampDataAdapter.toOnChainModel(input.getIssuedBefore()));
        }
        if (input.getExpiredAfter() != null) {
            builder.setExpiredAfter(this.timestampDataAdapter.toOnChainModel(input.getExpiredAfter()));
        }
        if (input.getExpiredBefore() != null) {
            builder.setExpiredBefore(this.timestampDataAdapter.toOnChainModel(input.getExpiredBefore()));
        }
        if (input.getOrderBy() != null) {
            builder.setOrderBy(
                    Gxs.GXSearchOrderByValue.newBuilder()
                    						.setValue(this.gxSearchOrderByTypeDataAdapter.toOnChainModel(input.getOrderBy()))
            );
        }
        if (input.getOrder() != null) {
            builder.setOrder(this.gxSearchOrderTypeDataAdapter.toOnChainModel(input.getOrder()));
        }
        if (input.getAmountSmallerThan() != null) {
            builder.setAmountSmallerThan(input.getAmountSmallerThan().longValue());
        }
        if (input.getAmountGreaterThan() != null) {
            builder.setAmountGreaterThan(input.getAmountGreaterThan().longValue());
        }
        if (input.getPurpose() != null) {
            builder.putAllPurpose(this.gxPurposeDataAdapter.toOnChainModel(input.getPurpose()));
        }
        if (input.getPurposeType() != null) {
            builder.setPurposeType(input.getPurposeType());
        }

        return builder.build();
    }

    @Override
    public GxSearchRequest toOffchainModel(Gxs.GXSearchRequest input) {
    	
        GxSearchRequest output = new GxSearchRequest();
        output.setStatus(this.gxStatusTypeDataAdapter.toOffchainModel(input.getStatus().getValue()));
        output.setStart(input.getStart());
        output.setLimit(BigInteger.valueOf(input.getLimit()));
        output.setOrgId(input.getOrgId());
        output.setApplicantId(input.getApplicantId());
        output.setBeneficiaryId(input.getBeneficiaryId());
        output.setIssuedAfter(this.timestampDataAdapter.toOffchainModel(input.getIssuedAfter()));
        output.setIssuedBefore(this.timestampDataAdapter.toOffchainModel(input.getIssuedBefore()));
        output.setExpiredAfter(this.timestampDataAdapter.toOffchainModel(input.getExpiredAfter()));
        output.setExpiredBefore(this.timestampDataAdapter.toOffchainModel(input.getExpiredBefore()));
        output.setOrderBy(this.gxSearchOrderByTypeDataAdapter.toOffchainModel(input.getOrderBy().getValue()));
        output.setOrder(this.gxSearchOrderTypeDataAdapter.toOffchainModel(input.getOrder()));
        output.setAmountSmallerThan(BigInteger.valueOf(input.getAmountSmallerThan()));
        output.setAmountGreaterThan(BigInteger.valueOf(input.getAmountGreaterThan()));
        output.setPurpose(this.gxPurposeDataAdapter.toOffchainModel(input.getPurposeMap()));
        output.setPurposeType(input.getPurposeType());
        return output;
    }
}
