/**
 * 
 */
package com.ibm.au.bgx.core.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.pojo.AgreementInfo;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;
import com.ibm.au.bgx.model.validation.BgxDataValidator;

/**
 * Class <b>OnboardingDataValidator</b>. This class implements the {@link BgxDataValidator}
 * interface and provides additional capabilities that are specific to the onboarding of
 * organisations that further restricts the conditions on valid profiles. More specifically
 * this implementation of {@link BgxDataValidator} relies on a different instance of {@link 
 * BgxDataValidator} for which it acts as a proxy of for the majority of the methods exposed 
 * by the interface, while it adds additional controls on the methods:
 * <ul>
 * <li>{@link OnboardingDataValidator#isValidProfile(OrgProfile, Status)}</li>
 * <li>{@link OnboardingDataValidator#validateProfile(OrgProfile, Status)}</li>
 * </ul>
 * that are aimed at restricting the set of valid profiles to only those profiles that are
 * for organisations whose entity type is {@literal EntityType#APPLICANT_OR_BENEFICIARY}.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
@Component
public class OnboardingDataValidator implements BgxDataValidator {
	
	/**
	 * An instance of {@link BgxDataValidator} that is used as a primary source
	 * of validation of business identifiers, profiles, and agreements.
	 */
	protected BgxDataValidator validator;
	
	/**
	 * Initialises an instance of {@link OnboardingDataValidator} which proxies
	 * the given instance of {@link BgxDataValidator}.
	 * 
	 * @param validator	a {@link BgxDataValidator} implementation that is used 
	 * 					as a primary source of validation. It cannot be {@literal 
	 * 					null}.
	 * 
	 * @throws IllegalArgumentException	if <i>validator</i> is {@literal null}.
	 */
	@Autowired
	public OnboardingDataValidator(BgxDataValidator validator) {
		if (validator == null) {
			throw new IllegalArgumentException("Parameter 'validator' cannot be null.");
		}
		this.validator = validator;
 	}
	
	/**
	 * This method returns the configured data validator that it acts as a proxy for.
	 * 
	 * @return	an instance of {@link  BgxDataValidator}. It is guaranteed to not to
	 * 			be {@literal null}.
	 */
	public BgxDataValidator getSourceValidator() {
		
		return this.validator;
	}

	/**
	 * This method determines whether the given organisation profile is valid within 
	 * the context of the given request <i>status</i>. This method first invokes the 
	 * method {@link BgxDataValidator#isValidProfile(OrgProfile, Status)} of the instance 
	 * of {@link BgxDataValidator} it proxies and then further checks that provided value 
	 * for {@link OrgProfile#getEntityType()} matches {@link EntityType#APPLICANT_OR_BENEFICIARY}.
	 * 
	 * @param profile	an instance of {@link OrgProfile} that contains the information about
	 * 					the profile subject to validation. It cannot be {@literal null}.
	 * 
	 * @param status	a value from the {@link Status} enumeration, that determines the constraints
	 * 					that need to be applied during validation. It cannot be {@literal null}.
	 * 
	 * @return 	{@literal true} if the configured validator successfully validate the profile
	 * 			and the provided value of {@link OrgProfile#getEntityType()} matches {@link 
	 * 			EntityType#APPLICANT_OR_BENEFICIARY}, {@literal false} otherwise. 
	 * 
	 * @throws IllegalArgumentException	if <i>profile</i> or <i>status</i> is {@literal null}.
	 * 
	 */
	@Override
	public boolean isValidProfile(OrgProfile profile, Status status) {
		
		return this.validator.isValidProfile(profile, status) && profile.getEntityType().equals(EntityType.APPLICANT_OR_BENEFICIARY);
	}

	/**
	 * This method validates the given organisation profile within the context of the given
	 * request <i>status</i>. This method defers the validation of the profile to the method
	 * {@link BgxDataValidator#validateProfile(OrgProfile, Status)} of the instance of {@link 
	 * BgxDataValidator} that it proxies and if the validation is successful it further checks
	 * that the proposed entity type matches {@link EntityType#APPLICANT_OR_BENEFICIARY}.
	 * 
	 * @param profile	an instance of {@link OrgProfile} that contains the information about
	 * 					the profile subject to validation. It cannot be {@literal null}.
	 * 
	 * @param status	a value from the {@link Status} enumeration, that determines the constraints
	 * 					that need to be applied during validation. It cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException	if <i>profile</i> or <i>status</i> is {@literal null}.
	 * 
	 * @throws DataValidationException	if the configured validator fails validation or if the
	 * 									provided value of {@link OrgProfile#getEntityType()} is
	 * 									different from {@link EntityType#APPLICANT_OR_BENEFICIARY}.
	 */
	@Override
	public void validateProfile(OrgProfile profile, Status status) {
		
		this.validator.validateProfile(profile, status);
		
        if (profile.getEntityType() != EntityType.APPLICANT_OR_BENEFICIARY) {
        	
        	throw new DataValidationException(String.format("Organisation with type other than %2$s cannot be onboarded (found: %1$s, expected: %2$s)", 
        													profile.getEntityType(), 
        													EntityType.APPLICANT_OR_BENEFICIARY));
        }
		
	}

	/**
	 * This method validates the given <i>agreement</i> as acceptable for the given terms and 
	 * condition <i>scope</i>. This implementation defers the validation to the method {@link 
	 * BgxDataValidator#validateAgreement(AgreementInfo, Scope)} of the source <i>validator</i>.
	 * 
	 * @param agreement	an {@link AgreementInfo} instance that contains the details of the 
	 * 					agreement to validate. It cannot be {@literal null}.	
	 * @param scope		a {@link Scope} value that defines the context for the validation.
	 * 					It cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException	if <i>agreement</i> or <i>scope</i> is {@literal null}.
	 * @throws DataValidationException	if the configured validator fails validation.
	 */
	@Override
	public void validateAgreement(AgreementInfo agreement, Scope scope) {

		this.validator.validateAgreement(agreement, scope);
	}

	/**
	 * This method validates the given <i>businessId</i> as a valid business identifier. This 
	 * method defers the validation to the method {@link BgxDataValidator#validateBusinessId(String)}
	 * of the {@link BgxDataValidator} that it proxies.
	 * 
	 * @param businessId	an {@link String} representing the business identifier. It cannot 
	 * 						be {@literal null}.	
	 * 
	 * @throws IllegalArgumentException	if <i>businessId</i> is {@literal null}.
	 * @throws DataValidationException	if the configured validator fails validation.
	 */
	@Override
	public void validateBusinessId(String businessId) {

		this.validator.validateBusinessId(businessId);
	}



	/**
	 * This method determines whether the given argument is a valid business identifier. This method.
	 * defers the check to the method {@link BgxDataValidator#isValidAcn(String)} of the {@link 
	 * BgxDataValidator} that it proxies.
	 * 
	 * @param businessId	a {@link String} representing the business identifier to validate. It cannot 
	 * 						be {@literal null}.
	 * 
	 * @return 	{@literal true} if <i>businessId</i> is an accepted business identifier, {@literal 
	 * 			false} otherwise.
	 * 
	 * @throws IllegalArgumentException if <i>businessId</i> is {@literal null}.
	 */
	@Override
	public boolean isValidBusinessId(String businessId) {
		
		return this.validator.isValidBusinessId(businessId);
	}

	/**
	 * This method validates the given <i>businessId</i> as a valid Australian Business Number (ABN). 
	 * This method defers the validation to the method {@link BgxDataValidator#validateAbn(String)}
	 * of the {@link BgxDataValidator} that it proxies.
	 * 
	 * @param abn	an {@link String} representing the ACN to validate. It cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException	if <i>abn</i> is {@literal null}.
	 * @throws DataValidationException	if the configured validator fails validation.
	 */
	@Override
	public void validateAbn(String abn) {

		this.validator.validateAbn(abn);
	}

	/**
	 * This method determines whether the given argument is a valaid Australian Business Number (ABN).
	 * This method defers the check to the method {@link BgxDataValidator#isValidAbn(String)} of the
	 * {@link BgxDataValidator} that it proxies.
	 * 
	 * @param abn	a {@link String} representing the ABN to validate. It cannot be {@literal null}.
	 * 
	 * @return {@literal true} if <i>abn</i> is a valid ABN, {@literal false} otherwise.
	 * 
	 * @throws IllegalArgumentException if <i>abn</i> is {@literal null}.
	 */
	@Override
	public boolean isValidAbn(String abn) {
		
		return this.validator.isValidAbn(abn);
	}

	/**
	 * This method validates the given <i>acn</i> as a valid Australian Company Number (ACN). 
	 * This method defers the validation to the method {@link BgxDataValidator#validateAcn(String)}
	 * of the {@link BgxDataValidator} that it proxies.
	 * 
	 * @param acn	an {@link String} representing the ACN to validate. It cannot be {@literal null}.	
	 * 
	 * @throws IllegalArgumentException	if <i>acn</i> is {@literal null}.
	 * @throws DataValidationException	if the configured validator fails validation.
	 */
	@Override
	public void validateAcn(String acn) {

		this.validator.validateAcn(acn);

	}

	/**
	 * This method determines whether the given argument is a valaid Australian Company Number (ACN).
	 * This method defers the check to the method {@link BgxDataValidator#isValidAcn(String)} of the
	 * {@link BgxDataValidator} that it proxies.
	 * 
	 * @param acn	a {@link String} representing the ACN to validate. It cannot be {@literal null}.
	 * 
	 * @return {@literal true} if <i>acn</i> is a valid ACN, {@literal false} otherwise.
	 * 
	 * @throws IllegalArgumentException if <i>acn</i> is {@literal null}.
	 */
	@Override
	public boolean isValidAcn(String acn) {

		return this.validator.isValidAcn(acn);
	}

}
