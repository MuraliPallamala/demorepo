package com.ibm.au.bgx.core.chain.adapter.tc;


import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.tc.TcExternalContent;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditionsExternalData;
import org.springframework.stereotype.Component;

/**
 * A implementation of adapter interface {@link ChainDataAdapter} to perform on-chain and off-chain
 * data model conversion for terms and conditions external content record
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class TcExternalContentAdapter implements
    ChainDataAdapter<TermsConditionsExternalData, TcExternalContent> {

    @Override
    public TermsConditionsExternalData toOnChainModel(TcExternalContent content) {
        if (content == null) {
            throw new IllegalArgumentException("Input off-chain TC content cannot be null");
        }

        TermsConditionsExternalData.Builder b = TermsConditionsExternalData.newBuilder();
        b.setDocumentId(content.getDocumentId());
        b.setHash(content.getHash());
        return b.build();
    }

    @Override
    public TcExternalContent toOffchainModel(TermsConditionsExternalData content) {

        if (content == null) {
            throw new IllegalArgumentException("Input on-chain TC content cannot be null");
        }

        TcExternalContent ec = new TcExternalContent();

        ec.setDocumentId(content.getDocumentId());
        ec.setHash(content.getHash());

        return ec;
    }
}
