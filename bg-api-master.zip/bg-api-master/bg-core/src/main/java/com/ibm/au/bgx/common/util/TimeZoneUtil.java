package com.ibm.au.bgx.common.util;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/**
 * Utility class to offer helpers related to time zones.
 *
 * @author Peter Ilfrich
 */
public class TimeZoneUtil {

    /**
     * The Java timezone label for AEST
     */
    public static final String label = "Australia/Sydney";

    /**
     * Formatter for date time
     */
    public static final DateTimeFormatter dateTimeFormatter =  DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL)
                    															.withLocale(Locale.forLanguageTag("en_AU"));

    /**
     * Formatter for dates
     */
    public static final DateTimeFormatter dateFormatter =  DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)
                    														.withLocale(Locale.forLanguageTag("en_AU"));

    /**
     * Converts an instant to AEST and returnes it as a zoned date time.
     *
     * @param i - the instant (unix timestamp)
     * @return - the date/time the instant represents in the AEST timezone.
     */
    public static ZonedDateTime convertToAEST(Instant i) {
        if (i == null) {
            return null;
        }
        return i.atZone(ZoneId.of(label));
    }

    /**
     * Formats a date by converting it to AEST first and then using the pre-defined formatter for
     * the Australia locale to return the date of the instant.
     *
     * @param i - a point in time to render as date
     * @return a string representation of the provided instant
     */
    public static String formatDateDefault(Instant i) {
        return dateFormatter.format(convertToAEST(i));
    }

    /**
     * Formats a date by converting it to AEST first and then using the pre-defined formatter for
     * the Australia locale to return the date and time of the instant.
     *
     * @param i - a point in time to render as date and time
     * @return a string representation of the provided instant
     */
    public static String formatDateTimeDefault(Instant i) {
        return dateTimeFormatter.format(convertToAEST(i));
    }

    /**
     * Converts the provided date into AEST and subtracts the time (hours, min, secs, millis, nanos)
     * from the converted date (to get midnight AEST) and then returns it as an instant object
     * (timezone independent).
     *
     * @param i - the give date/time in a timezone unspecific format
     * @return - the date time that represents midnight in AEST for the given day provided by the
     * instant (input)
     */
    public static Instant setToMidnightAEST(Instant i) {
        if (i == null) {
            return null;
        }

        ZonedDateTime zdt = convertToAEST(i);

        int hours = zdt.getHour();
        int min = zdt.getMinute();
        int sec = zdt.getSecond();

        // reset time to midnight (AEST)
       return i.minus(hours, ChronoUnit.HOURS)
               .minus(min, ChronoUnit.MINUTES)
               .minus(sec, ChronoUnit.SECONDS)
               .minus(i.get(ChronoField.MILLI_OF_SECOND), ChronoUnit.MILLIS)
               .minus(i.get(ChronoField.NANO_OF_SECOND), ChronoUnit.NANOS);
    }
}
