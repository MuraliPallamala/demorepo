package com.ibm.au.bgx.core.chain.event;

import com.ibm.au.bgx.model.guarantee.GxsEventHandlerService;
import com.ibm.au.bgx.model.guarantee.GxsEventHandlerService.EventHandler;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.queue.QueueClient;

import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Event handler for guarantee chaincode.
 *
 * @author Peter Ilfrich
 */
@Component
public class GxsEventHandler extends AbstractEventHandler implements EventHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GxsEventHandler.class);

    /**
     * Registers the guarantee chain events for the provided channel.
     *
     * @param channel - the channel for which to register this instance as the event handler
     */
    @Override
    public void registerEvents(Channel channel) {
        // list all the events that we want to register to (each event has a separate registration method)
        try {
            LOGGER.debug(BgxLogMarkers.DEV, "Registering event handlers for channel {}",
                    channel.getName());

            Set<String> handles = this.getEventHandleSet(channel);

            // for some reason Jenkins complains about this not being captured??
            handles.add(GxsEventHandlerService.registerStartFlowEvent(channel, this));
            handles.add(GxsEventHandlerService.registerUpdateFlowEvent(channel, this));
            handles.add(GxsEventHandlerService.registerFinishFlowEvent(channel, this));

        } catch (InvalidArgumentException iae) {
            LOGGER.error("Error registering GXS events", iae);
            throw new IllegalArgumentException("Error registering GXS events", iae);
        }
    }
}
