package com.ibm.au.bgx.core.chain.adapter.purpose;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.purpose.PurposeField;
import com.ibm.au.bgx.model.shared.Common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

/**
 * Data adapter to convert a purpose field from onchain to POJO and back.
 *
 * @author Peter Ilfrich
 */
@Component
public class PurposeFieldDataAdapter implements ChainDataAdapter<Common.PurposeField, PurposeField> {

    @Autowired
    protected PurposeFieldAppearanceDataAdapter purposeFieldAppearanceDataAdapter;

    @Autowired
    protected PurposeConstraintDataAdapter purposeConstraintDataAdapter;

    @Autowired
    protected PurposeFieldTypeAdapter purposeFieldTypeAdapter;


    @Override
    public Common.PurposeField toOnChainModel(PurposeField field) {
        Common.PurposeField.Builder builder = Common.PurposeField.newBuilder();
        builder
                .setName(field.getName())
                .setType(purposeFieldTypeAdapter.toOnChainModel(field.getType()))
                .setOptional(field.getOptional());

        if (field.getAppearance() != null) {
            builder.setAppearance(purposeFieldAppearanceDataAdapter.toOnChainModel(field.getAppearance()));
        }
        // constraints
        if (field.getConstraints() != null && !field.getConstraints().isEmpty()) {
            for (Object constraint : field.getConstraints()) {
                builder.addPurposeConstraints(purposeConstraintDataAdapter.toOnChainModel(constraint));
            }
        }

        // sub fields
        if (field.getSubFields() != null && !field.getSubFields().isEmpty()) {
            for (PurposeField subField : field.getSubFields()) {
                builder.addSubFields(this.toOnChainModel(subField));
            }
        }

        return builder.build();
    }

    @Override
    public PurposeField toOffchainModel(Common.PurposeField purposeField) {
        PurposeField pf = new PurposeField();

        pf.setAppearance(purposeFieldAppearanceDataAdapter.toOffchainModel(purposeField.getAppearance()));
        pf.setName(purposeField.getName());
        pf.setType(purposeFieldTypeAdapter.toOffchainModel(purposeField.getType()));
        pf.setOptional(purposeField.getOptional());

        if (purposeField.getPurposeConstraintsCount() > 0) {
            pf.setConstraints(new ArrayList<>());
            for (Common.PurposeConstraint c : purposeField.getPurposeConstraintsList()) {
                pf.getConstraints().add(purposeConstraintDataAdapter.toOffchainModel(c));
            }
        }

        if (purposeField.getSubFieldsCount() > 0) {
            pf.setSubFields(new ArrayList<>());
            for (Common.PurposeField f : purposeField.getSubFieldsList()) {
                pf.getSubFields().add(this.toOffchainModel(f));
            }
        }

        return pf;
    }

}
