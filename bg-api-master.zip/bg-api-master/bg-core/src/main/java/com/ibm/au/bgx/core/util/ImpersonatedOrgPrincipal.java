package com.ibm.au.bgx.core.util;

import com.ibm.au.bgx.core.approvalmodel.FourEyeApprovalModel;
import com.ibm.au.bgx.core.approvalmodel.SoleApproverApprovalModel;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.GxPrefillRequestManager;
import com.ibm.au.bgx.model.RequestManager;
import com.ibm.au.bgx.model.approvalmodel.ApprovalModel;
import com.ibm.au.bgx.model.chain.gx.GxManager;
import com.ibm.au.bgx.model.chain.profile.OrgChangeRequestManager;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Permission;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.pojo.approvalmodel.OrgApprovalModelSettings;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
public class ImpersonatedOrgPrincipal implements BgxPrincipal {

	/**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    /**
     * 
     */
    private final Organization organization;
    /**
     * 
     */
    private transient final ApplicationContext applicationContext;
    /**
     * 
     */
    private transient final GxManager gxManager;
    /**
     * 
     */
    private transient final ApprovalModel approvalModel;
    /**
     * 
     */
    private transient final RequestManager requestManager;
    /**
     * 
     */
    private transient final GxPrefillRequestManager gxPrefillRequestManager;


    /**
     * 
     * @param organization
     * @param applicationContext
     */
    public ImpersonatedOrgPrincipal(Organization organization, ApplicationContext applicationContext) {
    	
        this.setAuthenticated(true);
        this.organization = organization;

        // HACKY should be autowired in
        this.applicationContext = applicationContext;

        this.requestManager = (RequestManager) this.applicationContext.getBean("requestManager", this);

        // NOTE organization does not exist during bootstrapping phase
        // TODO refactor
        if (this.organization != null) {
        	
            if (this.organization.getProfile().getEntityType().equals(OrgProfile.EntityType.APPLICANT_OR_BENEFICIARY)) {
            
            	this.gxManager = (GxManager) this.applicationContext.getBean("appBenGxManager", this);
            
            } else if (this.organization.getProfile().getEntityType().equals(OrgProfile.EntityType.ISSUER)) {
            
            	this.gxManager = (GxManager) this.applicationContext.getBean("issuerGxManager", this);
            
            } else {
            
            	this.gxManager = null;
            }

            OrgApprovalModelSettings orgApprovalModelSettings = this.organization.getSettings().getApprovalModel();
            // Approval models are optional, so organizations may not set one
            if (orgApprovalModelSettings != null) {
                ApprovalModelInfo.Name approvalModelName = organization.getSettings().getApprovalModel().getName();
                if (approvalModelName == ApprovalModelInfo.Name.SOLE_APPROVER) {
                    this.approvalModel = (SoleApproverApprovalModel) this.applicationContext.getBean("soleApproverApprovalModel", this);
                } else if (approvalModelName == ApprovalModelInfo.Name.FOUR_EYE) {
                    this.approvalModel = (FourEyeApprovalModel) this.applicationContext.getBean("fourEyeApprovalModel", this);
                } else {
                    this.approvalModel = null;
                }
            } else {
                this.approvalModel = null;
            }
            this.gxPrefillRequestManager = (GxPrefillRequestManager) this.applicationContext.getBean("gxPrefillRequestManager", this);
        } else {
            this.gxManager = null;
            this.approvalModel = null;
            this.gxPrefillRequestManager = null;
        }
    }

    /**
     * 
     */
    @Override
    public String getPassword() {
        return null;
    }

    /**
     * 
     */
    @Override
    public String getUsername() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public boolean isAccountNonExpired() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public boolean isAccountNonLocked() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public boolean isCredentialsNonExpired() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public boolean isEnabled() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public Collection<GrantedAuthority> getAuthorities() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public String getName() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public String getEmail() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public String getPrimaryOrgId() {
        return this.organization.getId();
    }

    /**
     * 
     */
    @Override
    public UserProfile getUserProfile() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public OrgChangeRequestManager getOrgChangeRequestManager() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public GxManager getGxManager() {
        return this.gxManager;
    }

    /**
     * 
     */
    @Override
    public ApprovalModel getApprovalModel() {
        return this.approvalModel;
    }

    /**
     * 
     */
    @Override
    public RequestManager getRequestManager() {
        return this.requestManager;
    }

    /**
     * 
     */
    @Override
    public GxPrefillRequestManager getGxPrefillRequestManager() {
        return this.gxPrefillRequestManager;
    }

    /**
     * 
     */
    @Override
    public Organization getOrganization() {
        return this.organization;
    }

    /**
     * 
     */
    @Override
    public Object getCredentials() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public Object getDetails() {
        // NOT POSSIBLE TO IMPLEMENT
        throw new UnsupportedOperationException();
    }

    /**
     * 
     */
    @Override
    public Object getPrincipal() {
        return this;
    }

    /**
     * 
     */
    @Override
    public boolean isAuthenticated() {
        return false;
    }
    
    /**
     * 
     */
    @Override
    public void setAuthenticated(boolean b) throws IllegalArgumentException {

    }

    /**
     * 
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof ImpersonatedOrgPrincipal)) {
            return false;
        }

        ImpersonatedOrgPrincipal test = (ImpersonatedOrgPrincipal) obj;

        if ((this.getPrimaryOrgId() != null) && !this.getPrimaryOrgId().equals(test.getPrimaryOrgId())) {
            return false;
        }

        return true;
    }

    /**
     * 
     */
    @Override
    public int hashCode() {
        int code = 31;

        if (this.getPrincipal() != null) {
            code ^= ((ImpersonatedOrgPrincipal) this.getPrincipal()).getPrimaryOrgId().hashCode();
        }

        return code;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Organization: ").append(((ImpersonatedOrgPrincipal) this.getPrincipal()).getPrimaryOrgId());
        return sb.toString();
    }

    @Override
    public boolean isSpawned() {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public String getConfiguredForOrgId() {
        return this.organization.getId();
    }

    @Override
    public BgxPrincipal forOrg(Relationship relationship, String targetOrgId, List<Permission> permissions) throws GuaranteeForbiddenException {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public BgxPrincipal forOrg(String targetOrgId, List<Permission> orgPermissions) throws GuaranteeForbiddenException {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public BgxPrincipal forOrg(Relationship relationship, String targetOrgId, Permission permission) throws GuaranteeForbiddenException {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public BgxPrincipal forOrg(String targetOrgId, Permission orgPermission) throws GuaranteeForbiddenException {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public boolean hasRole(String orgId, String role) {
        if (orgId == null) {
            throw new IllegalArgumentException("Org Id cannot be null");
        }

        if (role == null) {
            throw new IllegalArgumentException("Role cannot be null");
        }

        List<String> roles = new ArrayList<>();
        roles.add(role);

        return hasRoles(orgId, roles);
    }

    @Override
    public boolean hasRoles(String orgId, List<String> roles) {
        if (orgId == null) {
            throw new IllegalArgumentException("Org Id cannot be null");
        }

        if (roles == null) {
            throw new IllegalArgumentException("Role cannot be null");
        }

        if (this.getUserProfile().getUserRoles().containsKey(orgId)
            && this.getUserProfile().getUserRoles().get(orgId).containsAll(roles)) {

            return true;
        }

        return false;
    }

    @Override
    public boolean isAdmin() {
        return this.hasRole(getPrimaryOrgId(), BgxConstants.ROLE_ADMIN);
    }

    @Override
    public boolean isAdminForOrg(String orgId) {
        return this.hasRole(orgId, BgxConstants.ROLE_ADMIN);
    }

    @Override
    public boolean isUserOfOrgType(EntityType entityType) {
    	
    	return (this.getOrganization() != null &&
    			this.getOrganization().getProfile() != null &&
    			this.getOrganization().getProfile().getEntityType().equals(entityType));

    }

    @Override
    public boolean isConsortiumUser() {
        return this.isUserOfOrgType(EntityType.CONSORTIUM);
    }

    @Override
    public boolean isConsortiumAdminUser() {
        return this.isConsortiumUser() && this.isAdmin();
    }

    @Override
    public boolean isActingOnBehalf() {
        return true;
    }

    @Override
    public boolean isActingOnBehalf(String targetOrgId) {
        return !this.getPrimaryOrgId().equals(targetOrgId)
            && this.getConfiguredForOrgId().equals(targetOrgId);
    }

    @Override
    public RelationshipInfo getRelationshipFor(String targetOrgId) {
        for (RelationshipInfo relInfo : this.getOrganization().getSettings().getRelationships()) {
            if (relInfo.getId().equals(targetOrgId)) {
                return relInfo;
            }
        }

        return null;
    }

    @Override
    public String getChannelUserName() {

        if (!this.organization.getProfile().getEntityType().equals(EntityType.APPLICANT_OR_BENEFICIARY)) {

            throw new IllegalStateException("ImpersonatedOrgPrincipal is only used for a non applicant or beneficiary organisation.");
        }

        // This component (ImpersonatedOrgPrincipal) is only used
        // to submit on the channel issuance requests by the applicant
        // on behalf of the beneficiary. As a result, this method will
        // only be called in the context of an applicant organisation
        // which means, there will be a static fabric user assigned to
        // the org. Hence, we follow the convention and return the org
        // identifier, which is the fabric user associated to the
        // organisation.
        //
        return this.getConfiguredForOrgId();
    }

    @Override
    public BigInteger getGxLimit() {
        throw new UnsupportedOperationException();
    }

    @Override
    public BigInteger getGxLimit(String orgId) {
        throw new UnsupportedOperationException();
   }
}
