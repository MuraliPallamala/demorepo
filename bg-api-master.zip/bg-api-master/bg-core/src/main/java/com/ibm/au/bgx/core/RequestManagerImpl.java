package com.ibm.au.bgx.core;

import com.ibm.au.bgx.model.AbstractPrincipalProvider;
import com.ibm.au.bgx.model.RequestManager;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.Request;
import com.ibm.au.bgx.model.repository.RequestRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class RequestManagerImpl extends AbstractPrincipalProvider implements RequestManager {

    private final static Logger LOGGER = LoggerFactory.getLogger(RequestManagerImpl.class);

    @Autowired
    RequestRepository repository;

    public RequestManagerImpl(BgxPrincipal principal) {
        super(principal);
    }

    @Override
    public List<Request> find(String gxId, String status) {
        String orgId = null;
        
        BgxPrincipal p = this.getPrincipal();
        
        if (p.getOrganization()
        	 .getProfile()
        	 .getEntityType().equals(EntityType.APPLICANT_OR_BENEFICIARY)) {
        	
            orgId = p.getConfiguredForOrgId();

            LOGGER.debug(BgxLogMarkers.DEV, "Fetching requests for org {} by principal {} of org {}", orgId, p.getEmail(), p.getPrimaryOrgId());
        }
        return this.repository.find(orgId, gxId, status);
    }

    @Override
    public Request get(String id) {
        return this.repository.getItem(id);
    }
}
