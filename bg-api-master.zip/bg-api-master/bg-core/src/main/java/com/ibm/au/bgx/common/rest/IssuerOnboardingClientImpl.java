package com.ibm.au.bgx.common.rest;

import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.api.IssuerOnboardingClient;
import com.ibm.au.bgx.model.chain.profile.OrgProfileRequestManager;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest.Type;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.model.pojo.onboarding.OnboardingNotification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Peter Ilfrich
 */
@Component
public class IssuerOnboardingClientImpl extends AbstractIssuerClient implements
        IssuerOnboardingClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(IssuerOnboardingClientImpl.class);

    @Override
    public void sendDeleteRequestNotification(OrgProfileRequest request) throws ServiceUnavailableException {
        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }

        if (request.getReferrer() == null) {
            throw new IllegalArgumentException("Request doesn't contain referrer details");
        }

        Map<String, Object> notificationPayload = new HashMap<>();
        OrgRequestAction action = new OrgRequestAction();
        action.setActionType(Type.CANCEL);
        notificationPayload.put(OrgProfileRequestManager.KEY_ACTION, action);
        String url = request.getReferrer().getReferralUrl();

        HttpHeaders baseHeaders = this.getHeaders();
        baseHeaders.add(ApiConstants.ONBOARDING_HEADER_REFERRER_TOKEN, request.getReferrer().getReferrerToken());

        this.sendNotification(url, notificationPayload, baseHeaders);

    }

    @Override
    public void sendCompleteRequestNotification(OrgProfileRequest request, Type actionType) {
        if (request.getReferrer() == null) {
            // nothing to do
            return;
        }
        // url
        String url = request.getReferrer().getReferralUrl();
        // header
        HttpHeaders baseHeaders = new HttpHeaders();
        baseHeaders.add(ApiConstants.ONBOARDING_HEADER_REFERRER_TOKEN, request.getReferrer().getReferrerToken());
        // body
        OrgRequestAction action = new OrgRequestAction();
        action.setActionType(actionType);
        Map<String, Object> notificationPayload = new HashMap<>();
        notificationPayload.put(OrgProfileRequestManager.KEY_ACTION, action);

        // send
        try {
            this.sendNotification(url, notificationPayload, baseHeaders);
            
        } catch (ServiceUnavailableException sex) { // lol
            LOGGER.error("Could not retrieve auth token. Please check connectivity to FIP.", sex);
        } catch (RuntimeException re) {
            // technical issue sending the notification
            LOGGER.error("Failed to send approve notification to referrer", re);
        }
    }

    private void sendNotification(String url, Map<String, Object> notificationPayload, HttpHeaders additionalHeaders) throws ServiceUnavailableException {

        if (additionalHeaders == null) {
            additionalHeaders = new HttpHeaders();
        }


        additionalHeaders.addAll(getHeaders());

        OnboardingNotification notification = new OnboardingNotification();
        notification.setPayload(notificationPayload);

        // Any API-to-API request requires the referrer headers to be added which is basically a signature of the payload
        notification.getPayload().put(BgxConstants.KEY_REFERRER_ID, this.identityConfig.getIdentity());
        this.addRequestHash(additionalHeaders, notification, this.identityConfig.getIdentity());

        HttpEntity<?> httpRequest = new HttpEntity<>(notification, additionalHeaders);

        LOGGER.debug(BgxLogMarkers.DEV, "> POST {}", url);

        try {

            RestTemplate rest = this.getRestTemplate(url);
            @SuppressWarnings("rawtypes")
			ResponseEntity<Map> response = rest.exchange(url, HttpMethod.POST, httpRequest, Map.class);
            if (!response.getStatusCode().equals(HttpStatus.OK)) {

                // just log the error, no need to take action or throw an exception
                LOGGER.error(BgxLogMarkers.DEV,
                        "Sending delete request notification returned an invalid status code: {}",
                        response.getStatusCode());
            }

        } catch (IOException | URISyntaxException ioex) {

            throw new ServiceUnavailableException(String.format("Cannot access remote service: %s", url), ioex);
        }
    }
}
