/**
 * 
 */
package com.ibm.au.bgx.core.chain.channel.gx;

/**
 * Class <b>GxChannelMetadata</b>. This class wraps the information 
 * about a bank guarantee channel that is of use in the solution. 
 * At present time it only stores the information about the channel
 * name and the associated prefix used for bank guarantees.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class GxChannelMetadata {
	
	/**
	 * A {@link String} containing the name of the channel.
	 */
	private String name;
	
	/**
	 * A {@link String} containing the prefix used to assign
	 * identifiers to bank guarantees in the channel.
	 */
	private String prefix;
	
	/**
	 * Initializes an instance of {@link GxChannelMetadata} with the
	 * given <i>name</i> and <i>prefix</i>.
	 * 
	 * @param name		a {@link String} containing the name of the channel.
	 * 					It cannot be {@literal null} or an empty string.
	 * 
	 * @param prefix	a {@link String} containing the guarantee id prefix
	 * 					used for the channel. It cannot be {@literal null}
	 * 					or an empty string.
	 * 
	 * @throws IllegalArgumentException		if <i>name</i> or <i>prefix</i>
	 * 										is {@literal null} or an empty string.
	 */
	public GxChannelMetadata(String name, String prefix) {
		
		if (name == null || name.isEmpty()) {
			
			throw new IllegalArgumentException("Paramter 'name' cannot be null or an empty string.");
		}
		
		if (prefix == null || prefix.isEmpty()) {
			
			throw new IllegalArgumentException("Parameter 'prefix' cannot be null or an mpty string.")
;		}
		
		this.name = name;
		this.prefix = prefix;
	}
	
	/**
	 * Gets the name of the channel.
	 * 
	 * @return	a {@link String} representing the name of the channel. 
	 * 			It is guaranteed to not to be {@literal null} or an 
	 * 			empty string.
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Gets the value of the prefix assigned to the channel to.
	 * 
	 * @return	a {@link String} representing the prefix. It is 
	 * 			guaranteed to not to be {@literal null} or an 
	 * 			empty string.
	 */
	public String getPrefix() {
		return this.prefix;
	}

	
}
