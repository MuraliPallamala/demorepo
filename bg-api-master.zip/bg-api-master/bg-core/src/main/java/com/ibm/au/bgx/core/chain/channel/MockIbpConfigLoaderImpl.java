package com.ibm.au.bgx.core.chain.channel;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.fabric.model.IbpConfig;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * IBP config loader for mock IBP
 *
 * It loads the config from a URL
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class MockIbpConfigLoaderImpl extends AbstractIbpConfigLoader  {

    private final Logger LOGGER = LoggerFactory.getLogger(MockIbpConfigLoaderImpl.class);

    private static final ObjectMapper MAPPER = new ObjectMapper();

    /**
     * API endpoint to retrieve the IBP config
     */
    @Value("${fabric.config.api.url:http://localhost:9000/network/}")
    private String configApiBaseUrl;

    // We are making an effective max probe limit of an hour.
    @Value("${bgx.network.probe.maxRetry:1200}")
    private int probeMaxRetry;

    @Value("${bgx.network.probe.sleep:3000}")
    private int probeSleep;

    // This is used as a mutex to access the ibpConfigs map
    private Object cacheLock = new Object();

    private Map<String, IbpConfig> ibpConfigCache = new HashMap<>();

    /**
     * Prepare the URL for the config given the channel name
     *
     * If channel name is null, it loads the config based on the property:
     * fabric.config.api.identity Otherwise, it tries to load the config path from the mappings
     */
    private String getConfigUrl(String channelName) {

        if (this.configMappings == null) {
            this.loadMappings();
        }

        if (!this.configMappings.containsKey(channelName)) {
            throw new IllegalArgumentException(
                String.format("Could not find config for channel %s", channelName));
        }

        return String
            .format("%s%s", configApiBaseUrl, this.configMappings.getProperty(channelName));
    }

    @Override
    public IbpConfig load(String channelName) throws Exception {

        if (channelName == null || channelName.isEmpty()) {
            throw new IllegalArgumentException("Channel name cannot be null");
        }

        // we lock before we read from the IBP config cache
        synchronized (this.cacheLock) {

            if (!ibpConfigCache.containsKey(channelName)) {

                LOGGER.debug(BgxLogMarkers.DEV, "Loading IBP config for channel {}", channelName);

                final IbpConfig ibpConfig = this.loadFromUrl(this.getConfigUrl(channelName));
                if (ibpConfig == null) {
                    throw new IllegalArgumentException(
                        String.format("Could not load IBP config for channel %s", channelName));
                }

                LOGGER.debug(BgxLogMarkers.DEV, "Caching IBP config for channel {}", channelName);

                this.ibpConfigCache.put(channelName, ibpConfig);
            }

            LOGGER.debug(BgxLogMarkers.DEV, "Retrieving IBP config for channel {}", channelName);
            return this.ibpConfigCache.get(channelName);
        }
    }

    private IbpConfig loadFromUrl(String configUrl) throws IOException, InterruptedException {

        LOGGER.debug(BgxLogMarkers.DEV, "Loading IBP config from URL {}", configUrl);

        HttpClient client = new HttpClient();

        // availability check
        HttpMethod method = new GetMethod(configApiBaseUrl + "status");
        int attempts = 0;
        int status = 0;

        // try again until status is 200 (network ready) or max attempts is reached
        while (status != 200 && attempts <= probeMaxRetry) {
            try {
                status = client.executeMethod(method);

            } catch (Exception e) {
                LOGGER.warn("Error during communication with Mock IBP", e);
            }

            if (status != 200) {
                // wait 10 seconds to retry
                LOGGER.debug(BgxLogMarkers.DEV, "Fabric network not ready yet. Waiting for {}s.",
                    probeSleep / 1000);
                Thread.sleep(probeSleep);
            }
            attempts += 1;
        }

        // max attempts is reached, abort
        if (status != 200) {
            throw new RuntimeException(String
                .format("Mock IBP didn't start in time (timeout reached: %d seconds)",
                    probeMaxRetry * probeSleep / 1000));
        }

        // retrieve network config and continue
        method = new GetMethod(configUrl);
        try {
            status = client.executeMethod(method);
            if (status != 200) {
                throw new RuntimeException(
                    String.format("Invalid status code (%d) when retrieving configuration: %s",
                        status, configUrl));
            }
            byte[] responseBody = method.getResponseBody();
            IbpConfig config = MAPPER.readValue(responseBody, IbpConfig.class);
            return config;
        } finally {
            method.releaseConnection();
        }
    }
}
