package com.ibm.au.bgx.core.migration;

import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.migration.DataMigrator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.io.File;

/**
 * @author Peter Ilfrich
 */
public abstract class AbstractMigrator implements DataMigrator {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractMigrator.class);

    @Value("${bgx.migration.marker.path:../properties}")
    protected String migrationMarkerPath;


    protected boolean checkForMigrationMarker(String markerFilename) {
        File marker = new File(migrationMarkerPath, markerFilename);
        LOGGER.debug(BgxLogMarkers.DEV, "Checking for marker: {}", marker.getAbsolutePath());
        return marker.isFile();
    }

    protected void deleteMigrationMarker(String markerFilename) {
        File marker = new File(migrationMarkerPath, markerFilename);
        if (marker.isFile()) {
            try {
                marker.delete();
            } catch (Exception ioe) {
                LOGGER.error("Failed to delete migration marker", ioe);
            }
        } else {
            LOGGER.error("Tried to delete migration marker, but file doesn't exist: {}/{}", migrationMarkerPath, markerFilename);
        }
    }
}
