package com.ibm.au.bgx.common.queue;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.pojo.chain.BlockchainEvent;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.queue.QueueConsumer.BlockchainEventConsumer;
import com.ibm.au.bgx.model.queue.QueueHandler;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @author Peter Ilfrich
 */
@Component
public class RabbitBlockchainEventConsumer implements BlockchainEventConsumer {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();
    private static final Logger LOGGER = LoggerFactory
            .getLogger(RabbitWebNotificationConsumer.class);

    @Autowired(required = false)
    private QueueHandler<BlockchainEvent> handler;

    @Override
    public void registerConsumer(String queueName, QueueClient client) throws IOException {
        RabbitQueueClient queueClient = (RabbitQueueClient) client;
        queueClient.getChannel()
                .basicConsume(queueName, false, this.getConsumer(queueClient.getChannel()));
    }

    public Consumer getConsumer(Channel channel) {
        RabbitBlockchainEventConsumer self = this;
        if (self.handler == null) {
            throw new RuntimeException("No QueueHandler<BlockchainEvent> available.");
        }
        return new DefaultConsumer(channel) {

            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                                       BasicProperties properties, byte[] body) throws IOException {
                try {
                    LOGGER.debug("Handling delivery of message: Started: {}", body);

                    // TODO: we need to catch missed de-serialising, since re-execution wouldn't do any good
                    BlockchainEvent notification = MAPPER.readValue(body, BlockchainEvent.class);
                    // send the notification, client may provide any required components (like the handler)
                    self.handler.handle(notification);
                    // confirm receipt and processing
                    channel.basicAck(envelope.getDeliveryTag(), false);
                    LOGGER.debug("Handling delivery of message: Acknowledged");
                } catch (IOException e) {
                    LOGGER.error("IO during handling of WebNotification", e);
                    throw e;
                }

            }
        };
    }
}
