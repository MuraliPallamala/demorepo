package com.ibm.au.bgx.core.approvalmodel;

import com.ibm.au.bgx.model.chain.profile.ApprovalModelCatalog;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;

public class SoleApproverApprovalModel extends AbstractApprovalModel {

    @Autowired
    ApprovalModelCatalog catalog;

    public SoleApproverApprovalModel(BgxPrincipal principal) {
        super(principal);
    }

    @Override
    public ApprovalModelInfo getApprovalModelInfo() throws IOException {
        return this.catalog.getApprovalModel(ApprovalModelInfo.Name.SOLE_APPROVER);
    }
}
