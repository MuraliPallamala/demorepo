package com.ibm.au.bgx.core.chain.adapter.purpose;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.purpose.Appearance;
import com.ibm.au.bgx.model.shared.Common;

import org.springframework.stereotype.Component;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

/**
 * Data adapter to convert a purpose field's appearance element from the on-chain format to the Java
 * POJO format.
 *
 * @author Peter Ilfrich
 */
@Component
public class PurposeFieldAppearanceDataAdapter implements ChainDataAdapter<Common.PurposeFieldAppearance, Appearance> {

    private static Map<Common.PurposeFieldAppearanceRenderAs, Appearance.RenderAs> fromChainMap;
    private static Map<Appearance.RenderAs, Common.PurposeFieldAppearanceRenderAs> toChainMap;

    // special handling for DEFAULT rendering to null in the offchain model
    private static final Common.PurposeFieldAppearanceRenderAs DEFAULT_VALUE = Common.PurposeFieldAppearanceRenderAs.DEFAULT;

    static {
        fromChainMap = new HashMap<>();
        toChainMap = new HashMap<>();

        toChainMap.put(Appearance.RenderAs.ADDRESS, Common.PurposeFieldAppearanceRenderAs.ADDRESS);
        toChainMap.put(Appearance.RenderAs.CURRENCY, Common.PurposeFieldAppearanceRenderAs.CURRENCY);

        for (Appearance.RenderAs renderAs : toChainMap.keySet()) {
            fromChainMap.put(toChainMap.get(renderAs), renderAs);
        }
    }

    @Override
    public Common.PurposeFieldAppearance toOnChainModel(Appearance appearance) {

        Common.PurposeFieldAppearance.Builder builder = Common.PurposeFieldAppearance.newBuilder();
        builder.setLabel(appearance.getLabel())
                .setWidth(appearance.getWidth().intValue()).build();

        if (appearance.getTooltip() != null) {
            builder.setTooltip(appearance.getTooltip());
        }
        if (appearance.getRenderAs() != null) {
            builder.setRenderAs(toChainMap.get(appearance.getRenderAs()));
        } else {
            builder.setRenderAs(DEFAULT_VALUE);
        }

        return builder.build();
    }

    @Override
    public Appearance toOffchainModel(Common.PurposeFieldAppearance purposeFieldAppearance) {

        Appearance app = new Appearance();
        app.setLabel(purposeFieldAppearance.getLabel());
        app.setWidth(BigInteger.valueOf(purposeFieldAppearance.getWidth()));

        if (purposeFieldAppearance.getTooltip() != null && !purposeFieldAppearance.getTooltip().isEmpty()) {
            app.setTooltip(purposeFieldAppearance.getTooltip());
        }
        if (purposeFieldAppearance.getRenderAs().equals(Common.PurposeFieldAppearanceRenderAs.DEFAULT)) {
            app.setRenderAs(null);
        } else {
            app.setRenderAs(fromChainMap.get(purposeFieldAppearance.getRenderAs()));
        }

        return app;
    }
}
