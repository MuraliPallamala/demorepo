package com.ibm.au.bgx.core.chain.adapter.gx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.chain.adapter.BankAccountDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.flow.FlowStatusDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxDemandPayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigInteger;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxDemandDataAdapter implements ChainDataAdapter<Gxs.GXDemandRequest, GxRequest> {

    public static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    BankAccountDataAdapter bankAccountDataAdapter;

    @Autowired
    FlowStatusDataAdapter flowStatusDataAdapter;

    @Override
    public Gxs.GXDemandRequest toOnChainModel(GxRequest input) {
        GxDemandPayload demandPayload = MAPPER.convertValue(input.getPayload(), GxDemandPayload.class);

        if (demandPayload.getAmount().compareTo(BigInteger.ZERO) <= 0) {
            throw new IllegalArgumentException(String.format("Demand amount %s for Gx %s cannot be zero or negative", demandPayload.getAmount(), input.getGuaranteeId()));
        }

        Gxs.GXDemandRequest.Builder builder = Gxs.GXDemandRequest.newBuilder()
                .setGxId(input.getGuaranteeId())
                .setAmount(demandPayload.getAmount().longValue());

        if (input.getId() != null) {
            builder.setId(input.getId());
        }

        if (demandPayload.getReason() != null) {
            builder.setReason(demandPayload.getReason());
        }

        if (demandPayload.getAccount() != null) {
            builder.setAccount(this.bankAccountDataAdapter.toOnChainModel(demandPayload.getAccount()));
        }

        return builder.build();
    }

    @Override
    public GxRequest toOffchainModel(Gxs.GXDemandRequest input) {
        GxRequest output = new GxRequest();
        output.setType(GxRequestType.DEMAND);
        GxDemandPayload payload = new GxDemandPayload();
        payload.setReason(input.getReason());
        payload.setAmount(BigInteger.valueOf(input.getAmount()));
        payload.setAccount(this.bankAccountDataAdapter.toOffchainModel(input.getAccount()));
        output.setPayload(payload);
        output.setId(input.getId());
        output.setStatus(this.flowStatusDataAdapter.toOffchainModel(input.getStatus()));
        output.setGuaranteeId(input.getGxId());
        output.setCreatedBy(input.getCreatedBy());
        output.setCreatedAt(this.timestampDataAdapter.toOffchainModel(input.getCreatedAt()));
        output.setUpdatedBy(input.getUpdatedBy());
        output.setUpdatedAt(this.timestampDataAdapter.toOffchainModel(input.getUpdatedAt()));
        return output;
    }
}
