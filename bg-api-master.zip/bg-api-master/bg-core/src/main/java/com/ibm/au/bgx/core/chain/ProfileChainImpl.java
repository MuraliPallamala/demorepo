package com.ibm.au.bgx.core.chain;

import com.ibm.au.bgx.model.profile.Organizations;
import com.ibm.au.bgx.model.shared.Flow;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import com.ibm.au.bgx.core.chain.adapter.ProfileDataAdapter;
import com.ibm.au.bgx.model.chain.ProfileChain;
import com.ibm.au.bgx.model.exception.ChainInitializationException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.profile.OrganizationAPI;
import com.ibm.au.bgx.model.profile.Organizations.ActivateKeyRequest;
import com.ibm.au.bgx.model.profile.Organizations.DeactivateKeyRequest;
import com.ibm.au.bgx.model.profile.Organizations.Organization;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationCreateRequest;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationCreateRequest.Builder;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationPublicKey;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationPublicKeyMap;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationSearchRequest;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationStartRequest;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationsList;
import com.ibm.au.bgx.model.shared.Common.IDValue;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class ProfileChainImpl extends AbstractChain<OrganizationAPI> implements ProfileChain {


    @Autowired
    ProfileDataAdapter profileAdapter;

    @Override
    public String update(String orgId, Organizations.OrganizationStartRequest request) throws ProfileChainException {
        try {
            OrganizationAPI orgApi = this.getChain(this.channelUserName, false);
            Flow.FlowIDValue val = orgApi.StartFlow(request);
            return val.getValue();
        } catch (Exception e) {
            throw new ProfileChainException(e);
        }

    }

    @Override
    public OrgProfile deactivate(String orgId) throws ProfileNotFoundException, ProfileChainException {
        if (orgId == null || orgId.isEmpty()) {
            throw new IllegalArgumentException("ID cannot be empty");
        }
        IDValue req = IDValue.newBuilder().setValue(orgId).build();

        try {
            getChain(this.channelUserName).Deactivate(req);
        } catch (Exception e) {
            throw new ProfileChainException("Failed to deactivate organization", e);
        }

        return getById(orgId);
    }

    @Override
    public OrgProfile create(OrgProfile profile, String adminCert)  throws ProfileCreateException {
        return this.create(profile, adminCert, false);
    }

    @Override
    public OrgProfile create(OrgProfile profile, String adminCert, boolean forceReconnect)
        throws ProfileCreateException {

        if (profile == null) {
            throw new IllegalArgumentException("Profile cannot be null");
        }

        if (profile.getId() == null || profile.getId().isEmpty()) {
            throw new IllegalArgumentException("Profile ID cannot be empty");
        }

        Builder builder = OrganizationCreateRequest.newBuilder();
        if (adminCert == null) {
            builder.setSelfOnboarding(true);
        } else {
            builder.setAdminCertificate(adminCert);
        }

        OrganizationCreateRequest createRequest = builder
            .setOrganization(profileAdapter.toOnChainModel(profile))
            .build();

        OrganizationStartRequest req = OrganizationStartRequest.newBuilder()
            .setCreateRequest(createRequest)
            .build();

        try {
            this.getChain(this.channelUserName, forceReconnect).StartFlow(req, false, true);
        } catch (Exception e) {
            throw new ProfileCreateException("Could not create profile on-chain", e);
        }

        try {
            return this.getById(profile.getId());
        } catch (Exception e) {
            throw new ProfileCreateException(String
                .format("Could not retrieve the created profile from chain: %s", e.getMessage()),
                e);
        }
    }

    @Override
    public List<OrgProfile> getAll() throws ProfileChainException {
        OrganizationSearchRequest req = OrganizationSearchRequest.newBuilder()
            .build();

        OrganizationsList list = null;

        try {
            list = getChain(this.channelUserName).Search(req);
        } catch (Exception e) {
            throw new ProfileChainException(e.getMessage(), e);
        }

        List<OrgProfile> profiles = new ArrayList<>();
        for (Organization org : list.getOrganizationsList()) {
            profiles.add(profileAdapter.toOffchainModel(org));
        }

        return profiles;
    }

    @Override
    public OrgProfile getById(String id) throws ProfileNotFoundException {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("ID cannot be empty");
        }

        try {
            IDValue req = IDValue.newBuilder().setValue(id).build();
            Organization organization = getChain(this.channelUserName).Get(req);
            return profileAdapter.toOffchainModel(organization);
        } catch (Exception e) {
            throw new ProfileNotFoundException(String.format("Profile could not be retrieved with ID: %s", id), e);
        }
    }

    @Override
    public List<OrgProfile> getByBusinessId(String bid) throws ProfileChainException {

        if (bid == null || bid.isEmpty()) {
            throw new IllegalArgumentException("Business Id cannot be empty");
        }

        OrganizationSearchRequest req = OrganizationSearchRequest.newBuilder()
            .setBusinessId(bid)
            .build();

        OrganizationsList list = null;

        try {
            list = getChain(this.channelUserName).Search(req);
        } catch (Exception e) {
            throw new ProfileChainException(e.getMessage(), e);
        }

        List<OrgProfile> profiles = new ArrayList<>();
        for (Organization org : list.getOrganizationsList()) {
            profiles.add(profileAdapter.toOffchainModel(org));
        }

        return profiles;
    }

    @Override
    public List<OrgProfile> getByEntityName(String name)
        throws ProfileNotFoundException, ProfileChainException {

        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Business Id cannot be empty");
        }

        OrganizationSearchRequest req = OrganizationSearchRequest.newBuilder()
            .setEntityName(name).build();

        OrganizationsList list;
        try {
            list = getChain(this.channelUserName).Search(req);
        } catch (Exception e) {
            throw new ProfileChainException(e.getMessage(), e);
        }

        List<OrgProfile> profiles = new ArrayList<>();
        for (Organization org : list.getOrganizationsList()) {
            profiles.add(profileAdapter.toOffchainModel(org));
        }

        return profiles;
    }

    @Override
    public Map<String, OrganizationPublicKey> getPublicKeys(String id) throws ProfileNotFoundException {

        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Id cannot be empty");
        }

        try {
            IDValue req = IDValue.newBuilder().setValue(id).build();
            OrganizationPublicKeyMap keysMap = getChain(this.channelUserName).GetPublicKeys(req);
            return keysMap.getMapMap();
        } catch (Exception e) {
            throw new ProfileNotFoundException(String
                .format("Admin certificates could not be retrieved with for profile ID: %s", id),
                e);
        }
    }

    @Override
    public Map<String, OrganizationPublicKey> activateKey(String orgId, PublicKey publicKey)
        throws ProfileNotFoundException {

        if (orgId == null || orgId.isEmpty()) {
            throw new IllegalArgumentException("Org Id cannot be empty");
        }

        if (publicKey == null) {
            throw new IllegalArgumentException("Public key cannot be empty");
        }

        try {
            ActivateKeyRequest request = ActivateKeyRequest
                .newBuilder()
                .setKey(BgxEncryptionUtil.toPem(publicKey))
                .build();

            getChain(orgId).ActivateKey(request);
        } catch (Exception e) {
            throw new ProfileNotFoundException(String
                .format("Could not activate public key for org: %s", orgId),
                e);
        }

        return this.getPublicKeys(orgId);
    }

    @Override
    public Map<String, OrganizationPublicKey> deactivateKey(String orgId, PublicKey publicKey)
        throws ProfileNotFoundException {

        if (orgId == null || orgId.isEmpty()) {
            throw new IllegalArgumentException("Org Id cannot be empty");
        }

        if (publicKey == null) {
            throw new IllegalArgumentException("Public key cannot be empty");
        }

        try {
            DeactivateKeyRequest request = DeactivateKeyRequest
                .newBuilder()
                .setKey(BgxEncryptionUtil.toPem(publicKey))
                .build();

            getChain(orgId).DeactivateKey(request);
        } catch (Exception e) {
            throw new ProfileNotFoundException(String
                .format("Could not deactivate public key for org: %s", orgId),
                e);
        }

        return this.getPublicKeys(orgId);
    }

    @Override
    protected OrganizationAPI getChain(String channelUserName) throws ChainInitializationException {
        return this.getChain(channelUserName, false);
    }

    protected OrganizationAPI getChain(String channelUserName, boolean forceReconnect) throws ChainInitializationException {

        OrganizationAPI api;

        if (channelUserName == null || channelUserName.isEmpty()) {
            throw new IllegalArgumentException(
                "Channel user name cannot be empty.");
        }

        try {
            api = selector.getOrganisationApi(channelUserName, forceReconnect);
        } catch (Exception e) {
            throw new ChainInitializationException(
                "Could not initialize profile chain API", e);
        }

        return api;
    }

}
