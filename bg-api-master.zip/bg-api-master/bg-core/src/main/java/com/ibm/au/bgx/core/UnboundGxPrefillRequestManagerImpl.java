package com.ibm.au.bgx.core;

import com.ibm.au.bgx.model.GxPrefillRequestManager;
import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;
import com.ibm.au.bgx.model.repository.GxPrefillRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.List;


// TODO potentially remove, currently is required for notification callbacks
@Primary
@Component
public class UnboundGxPrefillRequestManagerImpl implements GxPrefillRequestManager {

    @Autowired
    GxPrefillRequestRepository repository;

    @Override
    public GxPrefillRequest add(GxPrefillRequest request) {
        return repository.addItem(request);
    }


    @Override
    public GxPrefillRequest get(String id) {
        // TODO
        return null;
    }

    @Override
    public List<GxPrefillRequest> find(String gxRequestId) {
        return null;
    }
}
