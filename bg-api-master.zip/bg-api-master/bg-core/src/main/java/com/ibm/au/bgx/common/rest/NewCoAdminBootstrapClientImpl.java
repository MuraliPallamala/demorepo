package com.ibm.au.bgx.common.rest;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.api.NewCoAdminBootstrapClient;
import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.api.request.BootstrapRequest;
import com.ibm.au.bgx.model.pojo.api.response.BootstrapResponse;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * Default implementation of Bootstrap client interface
 *
 * This communicates with NewCo Admin API for bootstraping the organization
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class NewCoAdminBootstrapClientImpl extends AbstractNewCoAdminClient implements
        NewCoAdminBootstrapClient {

    private static Logger LOGGER = LoggerFactory.getLogger(NewCoAdminBootstrapClient.class);

    private static ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Value("${bootstrap.accessTokenUri:PROPERTY_NOT_SET}")
    private String accessTokenUri;

    @Value("${bootstrap.clientId:SET_PROPERTY_NOT_SET}")
    private String clientId;

    @Value("${bootstrap.clientSecret:PROPERTY_NOT_SET}")
    private String clientSecret;

    @Override
    public BootstrapResponse bootstrap(BootstrapRequest bootstrapRequest)
            throws ProfileCreateException, ServiceUnavailableException {

        if (bootstrapRequest.getProfile() == null || bootstrapRequest.getConfig() == null) {
            throw new IllegalArgumentException(
                    "Profile and Config are required for bootstrap request");
        }

        try {
            if (!this.isApiReady(this.getBaseUrl(), -1)) {
                throw new ServiceUnavailableException(
                        String.format("API '%s' is not ready", this.getBaseUrl()));
            }

            String url = String.format("%s/bootstrap", this.getBaseUrl());

            HttpHeaders headers = null;
            try {
                headers = this.getHeaders();
            } catch (Exception e) {
                throw new IllegalArgumentException("Could not prepare headers", e);
            }

            HttpEntity<BootstrapRequest> request = new HttpEntity<>(bootstrapRequest, headers);

            RestTemplate rest = this.getRestTemplate(url);

            LOGGER
                    .debug("Sending bootstrap request: " + MAPPER.writeValueAsString(bootstrapRequest));
            LOGGER.debug(BgxLogMarkers.DEV,
                    String.format("Sending bootstrap request to NewCo Admin: POST %s", url));
            ResponseEntity<BootstrapResponse> response = rest
                    .exchange(url, HttpMethod.POST, request, BootstrapResponse.class);
            return response.getBody();

        } catch (ServiceUnavailableException e) {
            throw e;

        } catch (Exception e) {
            throw new ProfileCreateException(String
                    .format("Could not bootstrap organization %s",
                            (String) bootstrapRequest.getConfig().get(
                                    BgxConstants.BOOTSTRAP_ORG_ID)), e);
        }
    }

    @Override
    public HttpHeaders getHeaders() throws ServiceUnavailableException {

        String accessTokenHeader = this.getAccessTokenHeader(accessTokenUri, clientId, clientSecret);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", accessTokenHeader);
        headers.add(BgxConstants.HEADER_BOOTSTRAP_MARKER, "1");

        return headers;
    }
}
