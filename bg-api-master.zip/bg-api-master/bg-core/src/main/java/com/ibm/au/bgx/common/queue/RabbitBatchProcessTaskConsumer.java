package com.ibm.au.bgx.common.queue;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask.Status;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.queue.QueueConsumer.BatchProcessTaskConsumer;
import com.ibm.au.bgx.model.queue.QueueHandler;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @author Peter Ilfrich
 */
@Component
public class RabbitBatchProcessTaskConsumer implements BatchProcessTaskConsumer {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired(required = false)
    QueueHandler<BatchProcessTask> handler;

    @Override
    public void registerConsumer(String queueName, QueueClient client) throws IOException {
        RabbitQueueClient queueClient = (RabbitQueueClient) client;
        queueClient.getChannel().basicConsume(queueName, false, this.getConsumer(queueClient.getChannel()));
    }

    public Consumer getConsumer(Channel channel) {
        RabbitBatchProcessTaskConsumer self = this;
        if (self.handler == null) {
            throw new RuntimeException("No QueueHandler<BatchProcessTaskConsumer> available.");
        }
        return new DefaultConsumer(channel) {

            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties, byte[] body) throws IOException {

                BatchProcessTask task = MAPPER.readValue(body, BatchProcessTask.class);

                // process task
                self.handler.handle(task);

                // Remove from the queue
                channel.basicAck(envelope.getDeliveryTag(), false);

                // if not completed requeue at the back
                if (!task.getStatus().equals(Status.COMPLETED)) {
                    channel.basicPublish(RabbitQueueClient.EXCHANGE_NAME, QueueClient.CHANNEL_BATCH,
                        null, MAPPER.writeValueAsBytes(task));
                }
            }
        };
    }
}
