package com.ibm.au.bgx.core.task;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.pojo.task.UserBatchUpdateTaskDetail;
import com.ibm.au.bgx.model.util.JacksonUtil;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public class TaskUtil {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    public static UserBatchUpdateTaskDetail deserializeTaskDetail(BatchProcessTask task) {
    	
    	if (task == null) {
    		throw new IllegalArgumentException("Task cannot be null.");
    	}

        if (!task.getPayload().containsKey(BgxConstants.TASK)) {
            throw new IllegalArgumentException("Task detail does not exist in the payload.");
        }

        // deserialize
        return deserializeTaskDetail(task.getPayload().get(BgxConstants.TASK));
    }

    public static UserBatchUpdateTaskDetail deserializeTaskDetail(Object taskPayload) {

        if (taskPayload == null) {
            throw new IllegalArgumentException("Task payload cannot be empty.");
        }

        // deserialize
        UserBatchUpdateTaskDetail taskDetail = MAPPER
            .convertValue(taskPayload, UserBatchUpdateTaskDetail.class);

        if (taskDetail == null || taskDetail.getUsers() == null) {
            throw new IllegalArgumentException("Users list cannot be empty.");
        }

        return taskDetail;
    }
}
