package com.ibm.au.bgx.core.chain.adapter.gx;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxStatusType;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxStatusTypeDataAdapter implements ChainDataAdapter<Gxs.GXStatus, GxStatusType> {

    @Override
    public Gxs.GXStatus toOnChainModel(GxStatusType input) {
        switch (input) {
            case ACTIVE:
                return Gxs.GXStatus.GX_ACTIVE;
            case CANCELLED:
                return Gxs.GXStatus.GX_CANCELLED;
            case DEMANDED:
                return Gxs.GXStatus.GX_DEMANDED;
            case PAYWALKED:
                return Gxs.GXStatus.GX_PAYWALKED;
            case TRANSFERRED:
                return Gxs.GXStatus.GX_TRANSFERRED;
            case EXPIRED:
                return Gxs.GXStatus.GX_EXPIRED;
        }
        throw new IllegalArgumentException("Unable to map GxStatusType to on chain model");
    }

    @Override
    public GxStatusType toOffchainModel(Gxs.GXStatus input) {
        switch (input) {
            case GX_ACTIVE:
                return GxStatusType.ACTIVE;
            case GX_CANCELLED:
                return GxStatusType.CANCELLED;
            case GX_DEMANDED:
                return GxStatusType.DEMANDED;
            case GX_PAYWALKED:
                return GxStatusType.PAYWALKED;
            case GX_TRANSFERRED:
                return GxStatusType.TRANSFERRED;
            case GX_EXPIRED:
                return GxStatusType.EXPIRED;
            default:
            	throw new IllegalArgumentException("Unable to map GxStatusType to off chain model");
        }
    }
}
