package com.ibm.au.bgx.core.chain.adapter.gx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.flow.FlowStatusDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxIssueDataAdapter implements ChainDataAdapter<Gxs.GXIssueRequest, GxRequest> {

    public static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    GxDataAdapter gxDataAdapter;

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    FlowStatusDataAdapter flowStatusDataAdapter;

    @Override
    public Gxs.GXIssueRequest toOnChainModel(GxRequest input) {
        GxIssuePayload issuePayload = MAPPER.convertValue(input.getPayload(), GxIssuePayload.class);

        Gxs.GXIssueRequest.Builder builder = Gxs.GXIssueRequest.newBuilder()
                .setGx(this.gxDataAdapter.toOnChainModel(issuePayload));

        if (input.getId() != null) {
            builder.setId(input.getId());
        }

        if (issuePayload.getOffchainCreatedAt() != null) {
            builder.setOffchainCreatedAt(this.timestampDataAdapter.toOnChainModel(issuePayload.getOffchainCreatedAt()));
        }

        return builder.build();
    }

    @Override
    public GxRequest toOffchainModel(Gxs.GXIssueRequest input) {
        GxRequest output = new GxRequest();

        // HACK
        GxIssuePayload payload = MAPPER.convertValue(this.gxDataAdapter.toOffchainModel(input.getGx()), GxIssuePayload.class);

        // Clear leftover status from GX payload
        if (payload.getStatus() != null) {
            payload.setStatus(null);
        }

        payload.setOffchainCreatedAt(this.timestampDataAdapter.toOffchainModel(input.getOffchainCreatedAt()));
        output.setPayload(payload);
        output.setId(input.getId());
        output.setType(GxRequestType.ISSUE);
        output.setGuaranteeId(input.getGxId());
        output.setStatus(this.flowStatusDataAdapter.toOffchainModel(input.getStatus()));
        output.setCreatedBy(input.getCreatedBy());
        output.setCreatedAt(this.timestampDataAdapter.toOffchainModel(input.getCreatedAt()));
        output.setUpdatedBy(input.getUpdatedBy());
        output.setUpdatedAt(this.timestampDataAdapter.toOffchainModel(input.getUpdatedAt()));
        return output;
    }
}
