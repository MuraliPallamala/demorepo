package com.ibm.au.bgx.core.chain.adapter.purpose;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.purpose.PurposeField;
import com.ibm.au.bgx.model.shared.Common;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Peter Ilfrich
 */
@Component
public class PurposeFieldTypeAdapter implements ChainDataAdapter<Common.PurposeFieldType, PurposeField.Type> {

    private static Map<Common.PurposeFieldType, PurposeField.Type> fromChainTypeMap;
    private static Map<PurposeField.Type, Common.PurposeFieldType> toChainTypeMap;

    static {
        toChainTypeMap = new HashMap<>();
        fromChainTypeMap = new HashMap<>();

        toChainTypeMap.put(PurposeField.Type.BOOLEAN, Common.PurposeFieldType.PFT_BOOLEAN);
        toChainTypeMap.put(PurposeField.Type.STRING, Common.PurposeFieldType.PFT_STRING);
        toChainTypeMap.put(PurposeField.Type.NUMBER, Common.PurposeFieldType.PFT_NUMBER);
        toChainTypeMap.put(PurposeField.Type.TEXT, Common.PurposeFieldType.PFT_TEXT);
        toChainTypeMap.put(PurposeField.Type.DATE, Common.PurposeFieldType.PFT_DATE);
        toChainTypeMap.put(PurposeField.Type.OBJECT, Common.PurposeFieldType.PFT_OBJECT);

        // map the reverse
        for (PurposeField.Type type : toChainTypeMap.keySet()) {
            fromChainTypeMap.put(toChainTypeMap.get(type), type);
        }
    }

    @Override
    public Common.PurposeFieldType toOnChainModel(PurposeField.Type type) {
        return toChainTypeMap.get(type);
    }

    @Override
    public PurposeField.Type toOffchainModel(Common.PurposeFieldType purposeFieldType) {
        return fromChainTypeMap.get(purposeFieldType);
    }
}
