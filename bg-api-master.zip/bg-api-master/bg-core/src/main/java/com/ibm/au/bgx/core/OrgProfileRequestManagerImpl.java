package com.ibm.au.bgx.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.common.rest.ApiConstants;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.chain.profile.OrgProfileRequestManager;
import com.ibm.au.bgx.model.pojo.BaseRequest.RequestType;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.Credentials;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest.Type;
import com.ibm.au.bgx.model.pojo.api.request.OnboardingRequest;
import com.ibm.au.bgx.model.pojo.api.response.OnboardingResponse;
import com.ibm.au.bgx.model.repository.OrgProfileRequestRepository;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * Organization profile request manager
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class OrgProfileRequestManagerImpl implements OrgProfileRequestManager {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    protected OrgProfileRequestRepository repository;

    @Autowired
    protected KeyGenerator keyGenerator;

    @Override
    public OrgProfileRequest create(OrgProfileRequest req) {

        if (req == null) {
            throw new IllegalArgumentException("Argument 'req' is required");
        }

        if (req.getId() == null || req.getId().isEmpty()) {
            req.setId(UUID.randomUUID().toString());
        }

        req.setRequestType(RequestType.ON_BOARDING);
        req.setStatus(Status.DRAFTED);

        // generate signup credentials
        if (req.getCredentials() == null) {
            req.setCredentials(this.generateCredentials());
        }

        return repository.addItem(req);
    }

    @Override
    public OrgProfileRequest update(OrgProfileRequest req) {
        return repository.updateItem(req);
    }

    @Override
    public OrgProfileRequest complete(String id) {

        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Argument 'id' is required to complete the request, it cannot be null or an empty string.");
        }

        OrgProfileRequest req = this.repository.getItem(id);

        if (req == null) {
            throw new IllegalArgumentException(String.format("Organization profile request doesn't exist with ID '%s' to complete.",  id));
        }

        if (!this.checkApprovalPrecondition(req)) {
            throw new IllegalStateException("Cannot complete a request, which doesn't have its elements (company, contact, [admin]) approved.");
        }

        req.setStatus(Status.APPROVED);
        req.getCredentials().setKey(this.generateKey());

        // Generate key and token for business contacts
        for (ContactInfo contact : req.getProfile().getContacts()) {
            Credentials cred = new Credentials();
            cred.setKey(this.keyGenerator.newKey(BgxConstants.USER_KEY_LEN));
            cred.setToken(req.getCredentials().getToken());
            contact.setCredentials(cred);
        }

        return this.repository.updateItem(req);
    }

    @Override
    public OrgProfileRequest confirm(String id) {

        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Argument 'id' is required to confirm the request, it cannot be null or an empty string.");
        }

        OrgProfileRequest req = this.repository.getItem(id);

        if (req == null) {
            throw new IllegalArgumentException(String.format("Organization profile request doesn't exist with ID '%s' to confirm", id));
        }

        if (req.getStatus() != Status.DRAFTED) {
            throw new IllegalStateException(String.format("Cannot confirm profile request if status is '%s'", req.getStatus()));
        }

        if (req.getProfile().getAgreement() == null ||
            req.getProfile().getAgreement().getTcId() == null || 
            req.getProfile().getAgreement().getTcId().isEmpty()) {
        	
            throw new IllegalStateException("Request cannot be approved if terms and conditions has not been accepted");
        }

        req.setStatus(Status.CONFIRMED);
        return this.repository.updateItem(req);
    }

    @Override
    public OrgProfileRequest reject(String id) {
    	
    	if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Argument 'id' is required to reject request, it cannot be null or an empty string.");
        }

        OrgProfileRequest req = this.repository.getItem(id);

        if (req == null) {
            throw new IllegalArgumentException(String.format("Organization profile request doesn't exist with ID: %s", id));
        }

        if (req.getStatus() != Status.CONFIRMED) {
            throw new IllegalStateException(String.format("Cannot reject profile request if status is '%s'", req.getStatus()));
        }

        req.setStatus(Status.REJECTED);
        return this.repository.updateItem(req);
    }

    @Override
    public OrgProfileRequest getById(String id) {
        return this.repository.getItem(id);
    }

    @Override
    public List<OrgProfileRequest> getAll() {
        return this.repository.getAll();
    }

    @Override
    public List<OrgProfileRequest> getForReview(Status status) {
        return this.repository.getForReview(status);
    }

    @Override
    public List<OrgProfileRequest> getByBusinessId(String referrerId, String bid, Status status) {
        return this.repository.getByBusinessId(referrerId, bid, status);
    }

    @Override
    public List<OrgProfileRequest> getByBusinessId(String referrerId, String bid) {
        return this.repository.getByBusinessId(referrerId, bid);
    }

    @Override
    public OrgProfileRequest getByOnboardingKey(String key, String token) {

    	if (token == null || token.isEmpty()) {
    		
    		throw new IllegalArgumentException("Parameter token cannot be null or an empty string.");
    	}
    	
        OrgProfileRequest request = this.repository.getByOnboardingKey(key);

        if (request != null
            && request.getCredentials() != null
            && request.getCredentials().getToken() != null
            && request.getCredentials().getToken().equals(token)) {

            return request;
        }

        return null;
    }

    private String generateKey() {

        // Generate organization key
        boolean found = true;
        int maxAttempt = 100;
        int attempt = 0;
        String key = "";

        while (found && attempt < maxAttempt) {

            key = this.keyGenerator.newKey(BgxConstants.ORG_KEY_LEN);

            OrgProfileRequest request = this.repository.getByOnboardingKey(key);

            if (request == null) {
                found = false;
            }

            attempt++;
        }

        if (found) {
            throw new IllegalStateException(String.format("Could not generate key for organization after %d attempt", maxAttempt));
        }

        return key;
    }

    private Credentials generateCredentials() {

        Credentials credentials = new Credentials();
        credentials.setKey(this.generateKey());
        credentials.setToken(this.keyGenerator.newNumeric(BgxConstants.SIGNUP_TOKEN_LEN));

        Instant now = Instant.now();
        credentials.setCreatedAt(now);

        return credentials;
    }

    private Credentials regenerateToken(Credentials oldCredentials) {
        Instant now = Instant.now();
        Credentials newCredentials = new Credentials();
        newCredentials.setKey(oldCredentials.getKey());
        newCredentials.setToken(this.keyGenerator.newNumeric(BgxConstants.SIGNUP_TOKEN_LEN));
        newCredentials.setCreatedAt(now);
        return newCredentials;
    }

    @Override
    public OrgProfileRequest refreshCredentials(String id) {

        if (id == null) {
            throw new IllegalArgumentException("Argument 'id' is required");
        }

        OrgProfileRequest req = this.repository.getItem(id);

        if (req == null) {
            throw new IllegalArgumentException(String.format("Organization profile request doesn't exist with ID: %s", id));
        }

        req.setCredentials(this.regenerateToken(req.getCredentials()));
        return repository.updateItem(req);
    }

    private void checkForMatchingRecallAction(OrgProfileRequest req, OrgRequestAction action) {
        // check if there's any recall action available
        OrgRequestAction recallActionCandidate = null;
        for (int i = req.getActions().size() - 1; i >= 0; i -= 1) {
            OrgRequestAction currentAction = req.getActions().get(i);
            if (currentAction.getActionType().equals(Type.RECALL)) {
                recallActionCandidate = currentAction;
                break;
            }
        }

        if (recallActionCandidate != null && recallActionCandidate.getId().equals(action.getActionId())) {
            throw new IllegalStateException("Could not verify data, because the latest RECALL action is not referenced.");
        }
    }

    /**
     * Performs pre-flight checks for eligible actions that can be added to a given on-boarding
     * request. It will throw a RuntimeException in case the request is in the wrong state for the
     * given action type or if any of the inputs is not provided.
     *
     * @param req - the on-boarding request to check against
     * @param action - the action that is supposed to be added to the request
     * @throws RuntimeException in case of invalid inputs or an action that is not applicable to the
     * requests current state.
     */
    private void onboardingActionPreflightCheck(OrgProfileRequest req, OrgRequestAction action) {

        if (action == null) {
            throw new IllegalArgumentException("Argument 'action' is required");
        }

        // check that request is in correct state
        if (req == null) {
            throw new IllegalArgumentException("Requested organization profile request doesn't exist with ID");
        }

        Status reqStatus = req.getStatus();

        switch (action.getActionType()) {

            case CANCEL:

                if (reqStatus != Status.DRAFTED) {

                    throw new IllegalStateException(String.format("CANCEL actions can only be submitted when the target request is DRAFTED (reqId: %1$s, actionId: %2$s. reqStatus: %3$s).",
                    											  req.getId(), 
                    											  action.getId(), 
                    											  reqStatus)
                    								);
                }

                // Here we only need to check the status of the
                // request. We should also check that it comes from
                // the referrer and not the primary contact.

                // Yet to be implemented.

                break;

            case RECALL:

                if (reqStatus != Status.DRAFTED) {

                    throw new IllegalStateException(String.format("RECALL actions can only be submitted when the target request is DRAFTED (reqId: %1$s, actionId: %2$s. reqStatus: %3$s).",
                    											  req.getId(), 
                    											  action.getId(), 
                    											  reqStatus)
                    							   );
                }

                // Here we only need to check the status of the
                // request. We should also check that it comes from
                // the referrer and not the primary contact.

                // Yet to be implemented.
                break;

            case CONFIRM:

                // CONFIRM only can be submitted when the request
                // is in DRAFTED status. We need to check the status
                // of the request and that it comes from the primary
                // contact.

                // TODO: update control logic to cater for identity of the submitter

                if (reqStatus != Status.DRAFTED) {

                    throw new IllegalStateException(String.format("CONFIRM actions can only be submitted when the target request is DRAFTED (reqId: %1$s, actionId: %2$s. reqStatus: %3$s).",
                    											  req.getId(), 
                    											  action.getId(), 
                    											  reqStatus)
                    							   );
                }

                // check if there's any recall action available
                checkForMatchingRecallAction(req, action);

                break;

            case VERIFY:

                // VERIFY can only be submitted when the request is
                // CONFIRMED and by NewCo Admin. Moreover, the VERIFY
                // needs to map to an entity (org,primary,admin) that
                // is listed in the profile request.

                if (reqStatus != Status.CONFIRMED) {

                    throw new IllegalStateException(String.format("VERIFY actions can only be submitted when the target request is CONFIRMED (reqId: %1$s, actionId: %2$s. reqStatus: %3$s).",
                    											  req.getId(), 
                    											  action.getId(), 
                    											  reqStatus)
                    							   );
                }

                // check if there's any recall action available
                this.checkForMatchingRecallAction(req, action);
                break;

            case REVOKE:

                // REVOKE can only be submitted when the request is
                // CONFIRMED and by NewCo Admin. Moreover, the revoke
                // needs to match a previous VERIFY action by identifier
                // and this should be the last action in the list of
                // actions.

                if (reqStatus != Status.CONFIRMED) {

                    throw new IllegalStateException(String.format("REVOKE actions can only be submitted when the target request is CONFIRMED (reqId: %1$s, actionId: %2$s. reqStatus: %3$s).",
                    											  req.getId(), 
                    											  action.getId(), 
                    											  reqStatus)
                    							   );
                }

                // action ID is required and needs to point to verify action
                if (action.getActionId() == null) {
                    throw new IllegalArgumentException("REVOKE action requires an actionId to point to.");
                }

                // extract and check verify object
                String verifyObject = null;
                if (action.getPayload().containsKey(OrgProfileRequestManager.KEY_VERIFY_OBJECT)) {
                    verifyObject = (String) action.getPayload().get(OrgProfileRequestManager.KEY_VERIFY_OBJECT);
                }
                if (verifyObject == null) {
                    throw new IllegalArgumentException("Request action needs to contain a verification object to revoke.");
                }

                // find an existing verify action that this revoke points to
                OrgRequestAction actionCandiate = null;
                for (int i = req.getActions().size() - 1; i >= 0; i -= 1) {
                    OrgRequestAction currentAction = req.getActions().get(i);
                    if (currentAction.getActionType().equals(Type.VERIFY) && currentAction.getPayload().get(OrgProfileRequestManager.KEY_VERIFY_OBJECT).equals(verifyObject)) {
                        actionCandiate = currentAction;
                        break;
                    }
                }

                // no verify action found
                if (actionCandiate == null) {
                    throw new IllegalStateException("There's no action available to revoke.");
                }

                // revoke points to the wrong action
                if (!actionCandiate.getId().equals(action.getActionId())) {
                    throw new IllegalArgumentException("The revoke action points to an outdated verify action.");
                }

                break;

            case APPROVE:

                // APPROVE can only be submitted when the request is
                // CONFIRMED and by NewCo Admin. Moreover, the list
                // of actions should contain VERIFY actions (that have
                // not been revoked) for all the items that have been
                // declared in the profile.

                if (reqStatus != Status.CONFIRMED) {

                    throw new IllegalStateException(String.format("APPROVE actions can only be submitted when the target request is CONFIRMED (reqId: %1$s, actionId: %2$s. reqStatus: %3$s).",
                        req.getId(), action.getId(), reqStatus));
                }

                break;

            case REJECT:

                // REJECT can only be submitted when the request is
                // CONFIRMED and by NewCoAdmin.

                if (reqStatus != Status.CONFIRMED) {

                    throw new IllegalStateException(String.format("REJECT actions can only be submitted when the target request is CONFIRMED (reqId: %1$s, actionId: %2$s. reqStatus: %3$s).",
                    											  req.getId(), 
                    											  action.getId(), 
                    											  reqStatus)
                    							   );
                }

                // check if there's any recall action available
                checkForMatchingRecallAction(req, action);

                break;

        }

    }

    @Override
    public OrgProfileRequest addOnboardingAction(String id, OrgRequestAction action) {
        // check input
        if (id == null) {
            throw new IllegalArgumentException("Argument 'id' is required");
        }

        // retrieve request and perform pre-flight checks (inputs, valid)
        OrgProfileRequest req = repository.getItem(id);
        this.onboardingActionPreflightCheck(req, action);

        // add additional technical fields to the action
        action.setCreatedAt(Instant.now());
        action.setId(UUID.randomUUID().toString());

        // add action and save
        if (req.getActions() == null) {
            req.setActions(new ArrayList<>());
        }
        req.getActions().add(action);

        // handle action types
        if (action.getActionType().equals(Type.CONFIRM)) {

            // extract the profile
            try {
            	
                String jsonProfile = MAPPER.writeValueAsString(action.getPayload().get(ApiConstants.ACTION_PAYLOAD_PROFILE));
                OrgProfile profile = MAPPER.readValue(jsonProfile, OrgProfile.class);
                req.setProfile(profile);
                this.repository.updateItem(req);
                
            } catch (IOException e) {
            	
                throw new IllegalArgumentException("Invalid profile payload");
            }

            // primary contact confirms request, we refresh the pin and set status to confirm
            this.confirm(id);
            req = this.refreshCredentials(id);
            
        } else if (action.getActionType().equals(Type.APPROVE)) {
        	
            // newco admin gives final approval for request (after verifying)
            this.repository.updateItem(req);
            req = this.complete(id);
            
        } else if (action.getActionType().equals(Type.REJECT)) {
        	
            // newco admin rejects request
            this.repository.updateItem(req);
            req = this.reject(id);
            
        } else {
        	
            // simply update the record (applies to VERIFY, TODO: check others )
            req = this.repository.updateItem(req);
        }

        return req;
    }

    /**
     * Checks whether a request is in a condition where it can receive overall approval. This
     * requires actions to be available that confirm the company information, primary contact
     * information and admin contact information (if provided in the original Profile).
     *
     * @param request - the request to check (profile contacts, actions)
     * @return - true if the preconditions are met and the request CAN be approved.
     */
    protected boolean checkApprovalPrecondition(OrgProfileRequest request) {

        // check if the org request specifies an admin contact
        boolean hasAdmin = false;
        if (request == null || 
        	request.getProfile() == null || 
        	request.getActions() == null || 
        	request.getProfile().getContacts() == null) {
            return false;
        }

        for (ContactInfo contact : request.getProfile().getContacts()) {

            // only admin role, not primary  will require admin approval
            if (contact.getRoles().contains(BgxConstants.ROLE_ADMIN)
                && !contact.getRoles().contains(BgxConstants.ROLE_PRIMARY)) {

                hasAdmin = true;
            }
        }

        boolean companyApproved = false;
        boolean primaryContactApproved = false;
        boolean adminContactApproved = !hasAdmin;
        for (OrgRequestAction action : request.getActions()) {

            // check if this is a verify action
            if (action.getPayload() != null && action.getPayload().containsKey(KEY_VERIFY_OBJECT)
                && action.getActionType()
                .equals(Type.VERIFY)) {

                // extract verify object and status
                String verifyObject = (String) action.getPayload().get(KEY_VERIFY_OBJECT);

                if (VALUE_VERIFY_PRIMARY_CONTACT.equals(verifyObject)) {
                    primaryContactApproved = true;
                } else if (VALUE_VERIFY_COMPANY.equals(verifyObject)) {
                    companyApproved = true;
                } else if (VALUE_VERIFY_ADMIN_CONTACT.equals(verifyObject) && hasAdmin) {
                    adminContactApproved = true;
                }
            }
        }

        return companyApproved && primaryContactApproved && adminContactApproved;
    }


    @Override
    public boolean validateTokenForKey(String key, String token) {
        return null != this.getByOnboardingKey(key, token); // if token doesn't match the method returns null
    }

    @Override
    public boolean validateTokenForId(String id, String token) {

    	if (token == null || token.isEmpty()) {
    		throw new IllegalArgumentException("Parameter token cannot be null or an empty string.");
    	}
    	
    	
        OrgProfileRequest req = this.getById(id);

        boolean isValid = false;
        if (req != null
            && req.getCredentials() != null
            && token.equals(req.getCredentials().getToken())) {

            isValid = true;
        }

        return isValid;
    }

    @Override
    public void deleteProfileRequest(OrgProfileRequest req) {
        // delete profile request
        this.repository.removeItem(req.getId());
    }

    @Override
    public List<OrgProfileRequest> getByReferrerIdAndStatus(String referrerId, Status status) {
        return this.repository.getByReferrerIdAndStatus(referrerId, status);
    }

    @Override
    public List<OrgProfileRequest> getByReferrerId(String referrerId) {
        return this.repository.getByReferrerId(referrerId);
    }

    @Override
    public OrgProfileRequest getByReferralToken(String referralToken) {
        return this.repository.getByReferralToken(referralToken);
    }

    @Override
    public OrgProfileRequest voidProfileRequest(OrgProfileRequest req) {
        req.setStatus(Status.ABANDONED);
        return this.repository.updateItem(req);
    }

    /**
     * This is to create an org profile request, after the NewCo admin API has created it on their
     * end.
     *
     * @param onboardingRequest - the original onboarding request sent to NewCo Admin
     * @param adminResponse - the response sent back from NewCo Admin
     * @return the org profile request after it has been stored in the offchain DB
     */
    @Override
    public OrgProfileRequest create(OnboardingRequest onboardingRequest, OnboardingResponse adminResponse) {

    	if (onboardingRequest == null) {
    		throw new IllegalArgumentException("Onboarding request cannot be null.");
    	}
    	
    	if (adminResponse == null) {
    		
    		throw new IllegalArgumentException("Administrative response to the onboardig request cannot be null.");
    	}
    	
        // create plain request
        OrgProfileRequest request = new OrgProfileRequest();

        // set id, profile, referrer and status
        request.setId(adminResponse.getId());
        request.setProfile(onboardingRequest.getProfile());
        request.setReferrer(onboardingRequest.getReferrer());
        request.setStatus(adminResponse.getStatus());

        //create credential section on this end (referrer, newco)
        Credentials credentials = new Credentials();
        credentials.setToken(adminResponse.getToken());

        request.setCredentials(credentials);

        // finally store the request in the offchain db
        return this.create(request);
    }
}
