package com.ibm.au.bgx.core;

import com.ibm.au.bgx.model.AbstractPrincipalProvider;
import com.ibm.au.bgx.model.GxPrefillRequestManager;
import com.ibm.au.bgx.model.notification.WebNotificationManager;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;
import com.ibm.au.bgx.model.repository.GxPrefillRequestRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class GxPrefillRequestManagerImpl extends AbstractPrincipalProvider implements GxPrefillRequestManager {

    @Autowired
    GxPrefillRequestRepository repository;

    @Autowired
    WebNotificationManager notificationManager;

    public GxPrefillRequestManagerImpl(BgxPrincipal principal) {
        super(principal);
    }

    @Override
    public GxPrefillRequest add(GxPrefillRequest request) {
        return repository.addItem(request);
    }


    @Override
    public GxPrefillRequest get(String id) {
        GxPrefillRequest prefillRequest = repository.getItem(id);
        if (prefillRequest == null) {
            throw new IllegalArgumentException("Request not found");
        }
        if (getPrincipal().getOrganization().getProfile().getEntityType().equals(OrgProfile.EntityType.APPLICANT_OR_BENEFICIARY) && !prefillRequest.getVisibleToOrgIds().contains(getPrincipal().getConfiguredForOrgId())) {
            throw new IllegalArgumentException("Unauthorized");
        }
        return prefillRequest;
    }

    @Override
    public List<GxPrefillRequest> find(String gxRequestId) {
        if (getPrincipal().getOrganization().getProfile().getEntityType().equals(OrgProfile.EntityType.APPLICANT_OR_BENEFICIARY)) {
            return repository.find(getPrincipal().getConfiguredForOrgId(), gxRequestId);
        }
        return repository.find(null, gxRequestId);
    }
}
