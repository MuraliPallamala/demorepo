package com.ibm.au.bgx.common.notification;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.chain.profile.ApprovalModelCatalog;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.notification.WebNotificationManager;
import com.ibm.au.bgx.model.pojo.BaseRequest;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.pojo.chain.FlowAction;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.gx.GxTransferPayload;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.repository.OrganizationRepository;
import com.ibm.au.bgx.model.repository.UserProfileRepository;
import com.ibm.au.bgx.model.repository.WebNotificationRepository;
import com.ibm.au.bgx.model.shared.Flow;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Peter Ilfrich
 */
@Component
public class WebNotificationManagerImpl implements WebNotificationManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebNotificationManagerImpl.class);
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    private WebNotificationRepository notificationRepository;

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private OrganizationManager organizationManager;

    @Autowired
    private OrganizationRepository orgRepository;

    @Autowired
    private ApprovalModelCatalog approvalModelCatalog;

    @Autowired
    private QueueClient queueClient;

    private Map<String, ApprovalModelInfo> approvalModels;

    @Override
    public void sendParentNotification(WebNotification notification, String subOrgId) {
        Organization org = orgRepository.getItem(subOrgId);
        if (org == null || org.getSettings().getRelationships() == null || org.getSettings()
                .getRelationships().isEmpty()) {
            return;
        }
        String parentOrgId = null;
        for (RelationshipInfo rel : org.getSettings().getRelationships()) {
            if (rel.getRelationship().equals(RelationshipInfo.Relationship.SUBSIDIARY_OF)) {
                parentOrgId = rel.getId();
            }
        }

        if (parentOrgId == null) {
            return;
        }

        // add subsidiary org id to the notification payload
        if (notification.getPayload() == null) {
            notification.setPayload(new HashMap<>());
        }
        this.addSubsidiaryInformation(notification, org);

        List<String> roles = this.getApprovalModelRoles(org.getSettings().getApprovalModel().getName().toString());
        List<UserProfile> parentUsers = new ArrayList<>();
        for (String approvalRole : roles) {
            List<UserProfile> users = userProfileRepository.getByOrgRolePrimary(parentOrgId, subOrgId, approvalRole);
            for (UserProfile profile : users) {
                if (!parentUsers.contains(profile)) {
                    parentUsers.add(profile);
                }
            }
        }

        try {
            this.queueClient.addWebNotification(notification, parentUsers);
        } catch (IOException ioe) {
            LOGGER.error("Failed to send web notifications to users of parent organisation", ioe);
        }

        // after sending the notification, remove the subsidiary information
        this.removeSubsidiaryInformation(notification);
    }

    @Override
    public void markActionsDone(BgxPrincipal principal, String referenceId) {

        if (principal == null) {
            throw new IllegalArgumentException("Principal cannot be null");
        }

        if (principal.getUserProfile() == null || principal.getUserProfile().getId() == null) {
            throw new IllegalArgumentException("Principal's user profile cannot be null");
        }

        String userId = principal.getUserProfile().getId();

        LOGGER.debug(BgxLogMarkers.DEV, "Mark action done for user {} with reference {}", userId, referenceId);

        // fetch notifications for this reference ID that require action
        List<WebNotification> notifications = notificationRepository
            .findByReferenceIdAction(referenceId, true, false);

        // check notifications for ones that belong to the same org and mark the action as done
        for (WebNotification notification : notifications) {
            if (userId.equals(notification.getReceiverId())) {
                notification.setActionDone(true);
                notificationRepository.updateItem(notification);
            }
        }
    }

    @Override
    public void markActionsDone(String orgId, String referenceId) {
        LOGGER.debug(BgxLogMarkers.DEV, "Mark action done for org {} with reference {}", orgId, referenceId);
        // fetch notifications for this reference ID that require action
        List<WebNotification> notifications = notificationRepository
                .findByReferenceIdAction(referenceId, true, false);
        // fetch users of the same org as the current actor
        List<UserProfile> profiles = userProfileRepository
                .getByPrimaryOrgId(orgId);
        // extract user IDs from the list of users for matching against notification receivers
        List<String> userIds = profiles.stream().map(profile -> profile.getId())
                .collect(Collectors.toList());

        // check notifications for ones that belong to the same org and mark the action as done
        for (WebNotification notification : notifications) {
            if (userIds.contains(notification.getReceiverId())) {
                notification.setActionDone(true);
                notificationRepository.updateItem(notification);
            }
        }
    }

    @Override
    public void markActionsDone(String referenceId) {
        if (referenceId == null) {
            // gracefully handle this case
            LOGGER.warn("Attempted to clear notifications without providing a reference ID", new IllegalArgumentException("Missing referenceId"));
            return;
        }

        // fetch notifications for this reference ID that require action
        List<WebNotification> notifications = notificationRepository
                .findByReferenceIdAction(referenceId, true, false);

        // mark notifications as done
        for (WebNotification notification : notifications) {
            notification.setActionDone(true);
            notificationRepository.updateItem(notification);
        }
    }

    @Override
    public void markActionsDone(String orgId, WebNotification.MessageType messageType) {
        // fetch users for this organisation
        List<UserProfile> users = userProfileRepository.getByPrimaryOrgId(orgId);
        for (UserProfile user : users) {
            // fetch notifications of that user
            List<WebNotification> notifications = notificationRepository.findByReceiverAction(user.getId(), true, false);
            for (WebNotification notification : notifications) {
                // compare message type to the provided and marke the ones done that are done
                if (notification.getMessageType().equals(messageType)) {
                    notification.setActionDone(true);
                    notificationRepository.updateItem(notification);
                }
            }
        }
    }

    @Override
    public void copyNotifications(Organization orgWithNotifications, UserProfile newOrgUser) {
        // pick first user that is not the new user
        List<UserProfile> orgUsers = userProfileRepository.getByPrimaryOrgId(orgWithNotifications.getId());
        UserProfile sourceUser = null;
        for (UserProfile orgUser : orgUsers) {
            if (!orgUser.getId().equals(newOrgUser.getId())) {
                sourceUser = orgUser;
                break;
            }
        }

        if (sourceUser == null) {
            LOGGER.error("Didn't find a source user of organisation {} from which to copy notifications to newly created user {}", orgWithNotifications.getId(), newOrgUser.getId());
            return;
        }

        List<WebNotification> notifications = notificationRepository.findByReceiverAction(sourceUser.getId(), true, false);
        for (WebNotification message : notifications) {
            // create copy and adjust receiver and status
            WebNotification copy = new WebNotification();
            copy.setReceiverId(newOrgUser.getId());
            copy.setStatus(WebNotification.Status.NEW);
            copy.setActionRequired(message.getActionRequired());
            copy.setActionDone(message.getActionDone());
            copy.setReferenceId(message.getReferenceId());
            copy.setReferenceType(message.getReferenceType());
            copy.setMessageType(message.getMessageType());
            copy.setPayload(message.getPayload());
            copy.setEventId(message.getEventId());

            // store the copy
            notificationRepository.addItem(copy);
        }
    }

    /**
     * Adds entity information from a given org profile to a given web notification. This updates
     * the notification object passed in as parameter.
     *
     * @param notification - the web notification to update
     * @param orgProfile   - the organisation profile containing the required information.
     */
    @Override
    public void addEntityInformation(WebNotification notification, OrgProfile orgProfile) {

        if (notification == null || orgProfile == null) {
            throw new IllegalArgumentException("Both parameters (notification and orgProfile) are required");
        }

        this.ensurePayload(notification);
        this.addOrganizationInfo(notification, PAYLOAD_ORG, orgProfile);
    }

    @Override
    public void addSubsidiaryInformation(WebNotification notification, Organization organization) {
        this.ensurePayload(notification);
        notification.getPayload().put(PAYLOAD_SUBSIDIARY_ID, organization.getId());
        this.addOrganizationInfo(notification, PAYLOAD_SUBSIDIARY_ORG, organization.getProfile());
    }

    @Override
    public void removeSubsidiaryInformation(WebNotification notification) {
        this.ensurePayload(notification);
        notification.getPayload().remove(PAYLOAD_SUBSIDIARY_ID);
        notification.getPayload().remove(PAYLOAD_SUBSIDIARY_ORG);
    }

    @Override
    public void addLinkType(WebNotification notification, OrgChangeRequest linkRequest) {
        this.ensurePayload(notification);

        if (!linkRequest.getRequestType().equals(BaseRequest.RequestType.LINK_ORGANIZATION) && !linkRequest.getRequestType().equals(BaseRequest.RequestType.UNLINK_ORGANIZATION)) {
            // not the correct request passed in, gracefully handle this
            LOGGER.error("You've passed in a request of type {}, but only link requests are supported.", linkRequest.getRequestType());
            return;
        }

        RelationshipInfo relInfo = MAPPER.convertValue(linkRequest.getPayload(), RelationshipInfo.class);
        RelationshipInfo.Relationship rel;
        if (notification.getMessageType().equals(WebNotification.MessageType.LINK_CANCEL)
                || notification.getMessageType().equals(WebNotification.MessageType.LINK_CREATE)
                || notification.getMessageType().equals(WebNotification.MessageType.UNLINK_CANCEL)
                || notification.getMessageType().equals(WebNotification.MessageType.UNLINK_CREATE)) {
            // invert relationship as the creator's relationship is stored in the request
            rel = relInfo.getRelationship().equals(RelationshipInfo.Relationship.PARENT_OF) ? RelationshipInfo.Relationship.SUBSIDIARY_OF : RelationshipInfo.Relationship.PARENT_OF;
        } else {
            rel = relInfo.getRelationship();
        }

        // update link type
        notification.getPayload().put(PAYLOAD_LINK_TYPE, rel.toString());
    }

    @Override
    public void addUserInfo(WebNotification notification, UserProfile profile) {
        this.ensurePayload(notification);
        Map<String, String> userInfo = new HashMap<>();
        userInfo.put(PAYLOAD_USER_FIRSTNAME, profile.getFirstName());
        userInfo.put(PAYLOAD_USER_LASTNAME, profile.getLastName());
        userInfo.put(PAYLOAD_USER_PHONE, profile.getPhone());
        userInfo.put(PAYLOAD_USER_EMAIL, profile.getEmail());
        notification.getPayload().put(PAYLOAD_USER, userInfo);
    }

    @Override
    public void addUserInfo(WebNotification notification, ContactInfo contact) {
        this.ensurePayload(notification);
        Map<String, String> userInfo = new HashMap<>();
        userInfo.put(PAYLOAD_USER_FIRSTNAME, contact.getFirstName());
        userInfo.put(PAYLOAD_USER_LASTNAME, contact.getLastName());
        userInfo.put(PAYLOAD_USER_PHONE, contact.getPhone());
        userInfo.put(PAYLOAD_USER_EMAIL, contact.getEmail());
        notification.getPayload().put(PAYLOAD_USER, userInfo);
    }

    /**
     * Updates a web notification, setting the reference type, reference ID and onboarding entity
     * information. This updates the notification object passed in as parameter
     *
     * @param notification   - the web notification object to update
     * @param profileRequest - the onboarding request containing the required information
     */
    @Override
    public void addOnboardingInformation(WebNotification notification, OrgProfileRequest profileRequest) {

        if (notification == null || profileRequest == null) {
            throw new IllegalArgumentException("Both parameters (notification and profileRequest) are required.");
        }

        this.addEntityInformation(notification, profileRequest.getProfile());
        notification.setReferenceType(WebNotification.ReferenceType.ORG_ONBOARDING_REQUEST);
        notification.setReferenceId(profileRequest.getId());
    }


    @Override
    public void addParticipants(WebNotification notification, Organization initiator, Organization issuer, Organization applicant, Organization... beneficiaries) {
        this.ensurePayload(notification);
        if (initiator != null) {
            notification.getPayload().put(PAYLOAD_INITIATOR_ENTITY_NAME, initiator.getProfile().getEntityName());
        }

        if (issuer != null) {
            // issuer is optional (amend, cancel, demand, paywalk)
            notification.getPayload().put(PAYLOAD_ISSUER_ENTITY_NAME, issuer.getProfile().getEntityName());
        }

        // robustness check
        if (applicant != null) {
            notification.getPayload().put(PAYLOAD_APPLICANT_ENTITY_NAME, applicant.getProfile().getEntityName());
        }

        if (beneficiaries != null) {
            if (beneficiaries.length == 1) {
                // regular event
                notification.getPayload().put(PAYLOAD_BENEFICIARY_ENTITY_NAME, beneficiaries[0].getProfile().getEntityName());
            } else if (beneficiaries.length == 2) {
                // transfer
                Organization oldBene = beneficiaries[0];
                Organization newBene = beneficiaries[1];
                notification.getPayload().put(PAYLOAD_OLD_BENE_ID, oldBene.getId());
                notification.getPayload().put(PAYLOAD_OLD_BENE_ENTITY_NAME, oldBene.getProfile().getEntityName());
                notification.getPayload().put(PAYLOAD_NEW_BENE_ID, newBene.getId());
                notification.getPayload().put(PAYLOAD_NEW_BENE_ENTITY_NAME, newBene.getProfile().getEntityName());
            }
        }
    }

    @Override
    public void addRejectReason(WebNotification notification, Flow.FlowActionRequest rejectActionRequest) {
        this.ensurePayload(notification);
        if (rejectActionRequest != null && rejectActionRequest.getMessage() != null && !rejectActionRequest.getMessage().isEmpty()) {
            notification.getPayload().put(PAYLOAD_REJECT_REASON, rejectActionRequest.getMessage());
        }
    }

    @Override
    public void addRejectReason(WebNotification notification, FlowAction rejectAction) {
        this.ensurePayload(notification);
        if (rejectAction != null && rejectAction.getMessage() != null && !rejectAction.getMessage().isEmpty()) {
            notification.getPayload().put(PAYLOAD_REJECT_REASON, rejectAction.getMessage());
        }
    }

    @Override
    public void addNewGxData(WebNotification notification, Flow.FlowActionRequest actionRequest) {
        this.ensurePayload(notification);
        if (actionRequest != null && actionRequest.getNewGxId() != null && !actionRequest.getNewGxId().isEmpty()) {
            notification.getPayload().put(PAYLOAD_NEW_GX_ID, actionRequest.getNewGxId());
        }
    }

    @Override
    public void addGxData(WebNotification notification, Gx gx) {
        this.ensurePayload(notification);
        notification.getPayload().put(PAYLOAD_OUTSTANDING_AMOUNT, gx.getAmount().getOutstanding());
        if (gx.getId() != null && !gx.getId().isEmpty()) {
            notification.getPayload().put(PAYLOAD_GX_ID, gx.getId());
        }

        if (gx.getBankReference() != null && !gx.getBankReference().trim().isEmpty()) {
            notification.getPayload().put(PAYLOAD_BANK_REFERENCE, gx.getBankReference());
        }
    }

    @Override
    public void populateGxIssueData(WebNotification notification, GxRequest request, boolean includeIssuer) {
        if (!request.getType().equals(GxRequestType.ISSUE)) {
            LOGGER.error("Tried to populate GxIssue data with request {} of a different type {}", request.getId(), request.getType());
            return;
        }
        GxIssuePayload issue = getGxIssue(request);
        if (issue == null) {
            LOGGER.error("Could not parse GxRequest payload to GxIssue");
            return;
        }
        // retrieve orgs
        Organization applicant = resolveOrganisation(issue.getApplicants());
        Organization bene = resolveOrganisation(issue.getBeneficiaries());

        Organization issuer = null;
        if (includeIssuer && issue.getIssuer() != null && !issue.getIssuer().isEmpty()) {
            issuer = resolveOrganisation(issue.getIssuer());
        }

        // always triggered by applicant (initiator), issuer omitted
        addParticipants(notification, applicant, issuer, applicant, bene);

        // add gx id if it is available to be pushed into the notification
        if (request.getGuaranteeId() != null && !request.getGuaranteeId().isEmpty()) {
            issue.setId(request.getGuaranteeId());
        }

        addGxData(notification, issue);
    }

    @Override
    public void populateGxData(WebNotification notification, Gx gx, GxRequest request) {
        Organization applicant = resolveOrganisation(gx.getApplicants());
        Organization bene = resolveOrganisation(gx.getBeneficiaries());
        Organization issuer = resolveOrganisation(gx.getIssuer());

        Organization initiator = null;
        if (applicant.getId().equals(request.getCreatedBy())) {
            initiator = applicant;
        } else if (bene.getId().equals(request.getCreatedBy())) {
            initiator = bene;
        } else if (issuer.getId().equals(request.getCreatedBy())) {
            initiator = issuer;
        }

        addParticipants(notification, initiator, issuer, applicant, bene);
        addGxData(notification, gx);
    }

    @Override
    public void populateGxTransferData(WebNotification notification, GxRequest request) {
        if (!request.getType().equals(GxRequestType.TRANSFER)) {
            LOGGER.error("Tried to populate GxTransfer data with request {} of different type {}", request.getId(), request.getType());
            return;
        }

        GxTransferPayload transfer = getGxTransfer(request);
        if (transfer == null) {
            LOGGER.error("Could not parse GxRequest payload to GxTransfer");
            return;
        }

        // retrieve organisations
        Organization applicant = resolveOrganisation(transfer.getGx().getApplicants());
        Organization oldBene = resolveOrganisation(transfer.getGx().getBeneficiaries());
        Organization newBene = resolveOrganisation(transfer.getBeneficiaries());
        Organization issuer = resolveOrganisation(transfer.getGx().getIssuer());

        Organization initiator;
        if (request.getCreatedBy().equals(applicant.getId())) {
            initiator = applicant;
        } else {
            initiator = oldBene;
        }
        addParticipants(notification, initiator, issuer, applicant, oldBene, newBene);
        addGxData(notification, transfer.getGx());
    }

    @Override
    public WebNotification cleanCopyNoBankReference(WebNotification original) {
        WebNotification copy;
        try {
            copy = MAPPER.readValue(MAPPER.writeValueAsString(original), WebNotification.class);
        } catch (IOException jpe) {
            throw new IllegalArgumentException("Could not clone web notification", jpe);
        }

        if (copy.getPayload() != null && copy.getPayload().containsKey(PAYLOAD_BANK_REFERENCE)) {
            copy.getPayload().remove(PAYLOAD_BANK_REFERENCE);
        }
        return copy;
    }

    @Override
    public WebNotification cleanCopyNoRejectReason(WebNotification original) {
        WebNotification copy;
        try {
            copy = MAPPER.readValue(MAPPER.writeValueAsString(original), WebNotification.class);
        } catch (IOException jpe) {
            throw new IllegalArgumentException("Could not clone web notification", jpe);
        }

        if (copy.getPayload() != null && copy.getPayload().containsKey(PAYLOAD_REJECT_REASON)) {
            copy.getPayload().remove(PAYLOAD_REJECT_REASON);
        }

        return copy;
    }

    @Override
    public GxIssuePayload getGxIssue(GxRequest request) {
        if (request.getType().equals(GxRequestType.ISSUE)) {
            return MAPPER.convertValue(request.getPayload(), GxIssuePayload.class);
        }
        return null;
    }

    @Override
    public GxTransferPayload getGxTransfer(GxRequest request) {
        if (request.getType().equals(GxRequestType.TRANSFER)) {
            return MAPPER.convertValue(request.getPayload(), GxTransferPayload.class);
        }
        return null;
    }

    protected Organization resolveOrganisation(List<String> orgIds) {
        return this.resolveOrganisation(orgIds.get(0));
    }

    protected Organization resolveOrganisation(String orgId) {
        try {
            return organizationManager.getById(orgId);
        } catch (Exception e) {
            LOGGER.warn(String.format("Could not resolve organisation '%s'", orgId), e);
            return null;
        }
    }

    protected void ensurePayload(WebNotification notification) {
        if (notification.getPayload() == null) {
            notification.setPayload(new HashMap<>());
        }
    }

    protected void addOrganizationInfo(WebNotification notification, String payloadKey, OrgProfile orgProfile) {
        Map<String, String> orgInfo = new HashMap<>();
        orgInfo.put(PAYLOAD_BUSINESS_ID, orgProfile.getBusinessId());
        orgInfo.put(PAYLOAD_ENTITY_NAME, orgProfile.getEntityName());

        notification.getPayload().put(payloadKey, orgInfo);
    }

    protected synchronized List<String> getApprovalModelRoles(String modelName) {
        if (this.approvalModels == null) {
            this.approvalModels = new HashMap<>();
            try {
                for (ApprovalModelInfo model : approvalModelCatalog.getApprovalModels()) {
                    this.approvalModels.put(model.getName().toString(), model);
                }
            } catch (IOException e) {
                LOGGER.error(
                        "Could not load approval models. This is a general problem that prevents other parts of the platform from working.");
                throw new RuntimeException("Could not load approval models", e);
            }
        }

        ApprovalModelInfo info = this.approvalModels.get(modelName);
        if (info == null) {
            return new ArrayList<>();
        }
        List<String> roles = info.getRoles()
        						 .stream()
        						 .map(role -> role.getRoleName())
        						 .collect(Collectors.toList());
        return roles;
    }
}
