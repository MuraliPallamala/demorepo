package com.ibm.au.bgx.core.chain.channel;

import org.hyperledger.fabric.sdk.ChaincodeID;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.HFClient;

/**
 * This is a structure holding all the necessary information to create an API client instance (the
 * client classes provided by weave-client-java)
 *
 * @author Peter Ilfrich
 */
public class ChannelDescriptor {
  private HFClient client;
  private Channel channel;
  private ChaincodeID chaincodeId;
  private ChannelConnector connector;

  public HFClient getClient() {
    return client;
  }

  public void setClient(HFClient client) {
    this.client = client;
  }

  public Channel getChannel() {
    return channel;
  }

  public void setChannel(Channel channel) {
    this.channel = channel;
  }

  public ChaincodeID getChaincodeId() {
    return chaincodeId;
  }

  public void setChaincodeId(ChaincodeID chaincodeId) {
    this.chaincodeId = chaincodeId;
  }

  public ChannelConnector getConnector() {
    return connector;
  }

  public void setConnector(ChannelConnector connector) {
    this.connector = connector;
  }
}
