package com.ibm.au.bgx.core;

import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.IdentityConfig;
import com.ibm.au.bgx.model.api.NewCoNotificationClient;
import com.ibm.au.bgx.model.chain.ChannelSelector;
import com.ibm.au.bgx.model.chain.ProfileChain;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.notification.WebNotificationManager;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.repository.AuditEventRepository;
import com.ibm.au.bgx.model.repository.BatchProcessTaskRepository;
import com.ibm.au.bgx.model.repository.ChannelUserRepository;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.repository.OrgChangeRequestRepository;
import com.ibm.au.bgx.model.repository.OrgProfileRequestRepository;
import com.ibm.au.bgx.model.repository.OrganizationRepository;
import com.ibm.au.bgx.model.repository.UserProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Peter Ilfrich
 */
@Component
public class BgxComponentProviderImpl implements BgxComponentProvider {
    

	@Autowired
    NewCoNotificationClient newCoNotificationClient;

    @Autowired
    OrgChangeRequestRepository orgChangeRequestRepository;

    @Autowired
    OrganizationRepository organizationRepository;

    @Autowired
    AuditEventRepository auditEventRepository;

    @Autowired
    UserProfileRepository userProfileRepository;

    @Autowired
    OrgProfileRequestRepository orgProfileRequestRepository;

    @Autowired
    ChannelSelector channelSelector;

    @Autowired
    ProfileChain profileChain;

    @Autowired
    ChannelUserRepository channelUserRepository;

    @Autowired
    QueueClient queueClient;

    @Autowired
    BatchProcessTaskRepository taskRepository;

    @Autowired
    OrganizationManager organizationManager;

    @Autowired
    WebNotificationManager webNotificationManager;

    @Autowired
    IdentityConfig identityConfig;

    @Autowired
    GxRequestRepository gxRequestRepository;

    public NewCoNotificationClient getNewCoNotificationClient() {
        return newCoNotificationClient;
    }

    @Override
    public OrganizationManager getOrganizationManager() {
        return organizationManager;
    }

    public OrgChangeRequestRepository getOrgChangeRequestRepository() {
        return this.orgChangeRequestRepository;
    }

    public OrganizationRepository getOrganizationRepository() {
        return organizationRepository;
    }

    @Override
    public AuditEventRepository getAuditEventRepository() {
        return auditEventRepository;
    }

    @Override
    public UserProfileRepository getUserProfileRepository() {
        return userProfileRepository;
    }

    @Override
    public OrgProfileRequestRepository getOrgProfileRequestRepository() {
        return orgProfileRequestRepository;
    }

    @Override
    public ChannelSelector getChannelSelector() {
        return channelSelector;
    }

    @Override
    public ChannelUserRepository getChannelUserRepository() {
        return channelUserRepository;
    }

    @Override
    public QueueClient getQueueClient() {
        return queueClient;
    }

    @Override
    public BatchProcessTaskRepository getTaskRepository() {
        return taskRepository;
    }

    @Override
    public ProfileChain getProfileChain() {
        return profileChain;
    }

    @Override
    public WebNotificationManager getWebNotificationManager() {
        return webNotificationManager;
    }

    @Override
    public IdentityConfig getIdentityConfig() {
        return identityConfig;
    }

    @Override
    public GxRequestRepository getGxRequestRepository() {
        return gxRequestRepository;
    }
}
