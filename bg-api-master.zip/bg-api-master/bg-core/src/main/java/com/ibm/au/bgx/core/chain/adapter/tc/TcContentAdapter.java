package com.ibm.au.bgx.core.chain.adapter.tc;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.tc.TcEmbeddedContent;
import com.ibm.au.bgx.model.pojo.tc.TcExternalContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCondContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCondContent.Type;
import com.ibm.au.bgx.model.profile.Termsconditions.DataStorageType;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditionsContent;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * A implementation of adapter interface {@link ChainDataAdapter} to perform on-chain and off-chain
 * data model conversion for terms and conditions content record
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class TcContentAdapter implements ChainDataAdapter<TermsConditionsContent, TermsAndCondContent> {

    @Autowired
    TcExternalContentAdapter externalContentAdapter;

    @Autowired
    TcEmbeddedContentAdapter embeddedContentAdapter;

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Override
    public TermsConditionsContent toOnChainModel(TermsAndCondContent tcc) {

        if (tcc == null) {
            throw new IllegalArgumentException("Input off-chain TC content cannot be null");
        }

        TermsConditionsContent.Builder b = TermsConditionsContent.newBuilder();
        b.setType(DataStorageType.valueOf(tcc.getType().value()));
        b.setContentType(tcc.getContentType());

        if (isEmbeddedContent(tcc.getType().value())) {
            TcEmbeddedContent ec = MAPPER.convertValue(tcc.getData(), TcEmbeddedContent.class);
            b.setEmbeddedData(embeddedContentAdapter.toOnChainModel(ec));
        } else {
            TcExternalContent ec = MAPPER.convertValue(tcc.getData(), TcExternalContent.class);
            b.setExternalData(externalContentAdapter.toOnChainModel(ec));
        }

        return b.build();
    }

    @Override
    public TermsAndCondContent toOffchainModel(TermsConditionsContent tcc) {

        if (tcc == null) {
            throw new IllegalArgumentException("Input on-chain TC content cannot be null");
        }

        TermsAndCondContent tccOffchain = new TermsAndCondContent();
        tccOffchain.setType(TermsAndCondContent.Type.valueOf(tcc.getType().toString()));
        tccOffchain.setContentType(tcc.getContentType());

        if (isEmbeddedContent(tcc.getType().toString())) {
            tccOffchain.setData(embeddedContentAdapter.toOffchainModel(tcc.getEmbeddedData()));
        } else if(isExternalContent(tcc.getType().toString())) {
            tccOffchain.setData(externalContentAdapter.toOffchainModel(tcc.getExternalData()));
        }

        return tccOffchain;
    }

    private boolean isExternalContent(String type) {
        return Type.EXTERNAL.value().equals(type);
    }

    private boolean isEmbeddedContent(String type) {
        return Type.EMBEDDED.value().equals(type);
    }
}
