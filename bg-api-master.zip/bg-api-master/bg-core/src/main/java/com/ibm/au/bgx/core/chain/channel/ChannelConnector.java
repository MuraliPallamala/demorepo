package com.ibm.au.bgx.core.chain.channel;

import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.Enrollment;
import org.hyperledger.fabric.sdk.EventHub;
import org.hyperledger.fabric.sdk.HFClient;
import org.hyperledger.fabric.sdk.Orderer;
import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.User;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.helper.Utils;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric_ca.sdk.HFCAClient;
import org.hyperledger.fabric_ca.sdk.RegistrationRequest;
import org.hyperledger.fabric_ca.sdk.exception.BaseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.fabric.model.CaConfig;
import com.ibm.au.bgx.fabric.model.ChannelConfig;
import com.ibm.au.bgx.fabric.model.Configuration;
import com.ibm.au.bgx.fabric.model.DefaultConfiguration;
import com.ibm.au.bgx.fabric.model.IbpConfig;
import com.ibm.au.bgx.fabric.model.IbpConfiguration;
import com.ibm.au.bgx.fabric.model.OrdererConfig;
import com.ibm.au.bgx.fabric.model.PeerConfig;
import com.ibm.au.bgx.fabric.model.TlsConfig;
import com.ibm.au.bgx.fabric.util.IbpUtil;
import com.ibm.au.bgx.model.chain.BgxDefaultEnrollment;
import com.ibm.au.bgx.model.chain.ChannelUser;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;

/**
 * Utility class that allows to create connections to the fabric and specific channels using a
 * provided user.
 *
 * @author Peter Ilfrich
 */
public class ChannelConnector {

    // logger
    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelConnector.class);

    // fabric clients
    private HFClient client;
    private HFCAClient caClient;
    // fabric channel
    private Channel channel;

    // config variables
    private IbpConfig ibpConfig;
    private Configuration config;
    private SSLUtils sslUtils;


    /**
     * Initialises the connector, providing the config, which will be parsed for better
     * accessibility. After that the CA client and the HF client will be instantiated.
     *
     * @param ibpConfig - the network configuration provided to the connector
     */
    public void init(IbpConfig ibpConfig, SSLUtils sslUtils) {
        try {
            this.ibpConfig = ibpConfig;
            this.sslUtils = sslUtils;
            this.config = new IbpConfiguration(ibpConfig);
            this.initClients();


        } catch (Exception e) {
            throw new RuntimeException("Unable to connect to channel", e);
        }
    }

    /**
     * Logs in the provided user to the currently instantiated fabric clients.
     *
     * @param user - the user to enroll
     */
    public void enrollUser(ChannelUser user) throws BaseException, InvalidArgumentException {
        if (user.getEnrollment() == null) {
            LOGGER.debug(BgxLogMarkers.FABRIC_TECH,
                String.format("Enrolling user %s", user.getName()));
            Enrollment enrollment = caClient.enroll(user.getName(), user.getEnrollmentSecret());
            user.setEnrollment(new BgxDefaultEnrollment(enrollment));
        }
        client.setUserContext(user);
    }


    /**
     * Initialises the CA client and the fabric client and provides the default crypto suite to
     * them.
     */
    protected void initClients()
        throws CryptoException, InvalidArgumentException, IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, MalformedURLException {

        LOGGER.debug(BgxLogMarkers.FABRIC_TECH, "Initializing fabric clients");

        // init CA client
        caClient = HFCAClient
            .createNewInstance(config.getOrganizations().iterator().next().getCALocation(),
                this.prepareCaProperties());
        caClient.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());

        client = HFClient.createNewInstance();
        client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
    }

    private void prepareBaseTlsProps(TlsConfig tlsConfig, Properties props) {

        props.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_SSL_PROVIDER,
            DefaultConfiguration.ENDPOINT_SSL_PROVIDER_DEFAULT);
        props.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_SSL_PROVIDER,
            DefaultConfiguration.ENDPOINT_SSL_PROVIDER_DEFAULT);
        props.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_NEGOTIATION_TYPE,
            DefaultConfiguration.ENDPOINT_NEGOTIATION_TYPE_DEFAULT);
        props.setProperty(DefaultConfiguration.PROPERTY_ENDPOINT_TRUST_SERVER_CERTIFICATE,
            DefaultConfiguration.ENDPOINT_TRUST_SERVER_CERTIFICATE_DEFAULT);

    }

    /**
     * Prepare CA properties
     */
    private Properties prepareCaProperties() {
        Properties props = new Properties();

        // pick the first CaConfig
        Map.Entry<String, CaConfig> entry = this.ibpConfig.getCertificateAuthorities().entrySet()
            .iterator().next();
        CaConfig caConfig = entry.getValue();

        // convert the TLS cert into PEM Bytes if TLS is required
        try {
            if (this.sslUtils.isSSL(caConfig.getUrl())) {
                byte[] pemBytes = IbpUtil.extractFirstCertString(caConfig.getTlsCACerts().getPem()).getBytes();
                props.put(DefaultConfiguration.PROPERTY_ENDPOINT_PEM_BYTES, pemBytes);
                this.prepareBaseTlsProps(caConfig.getTlsCACerts(), props);
            }
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("Invalid CA URL", e);
        }

        return props;
    }

    /**
     * Prepare Peer properties
     */
    private Properties preparePeerProperties(PeerConfig peerConfig) {

        Properties props = new Properties();

        // convert the TLS cert into PEM Bytes if TLS is required
        try {
            if (this.sslUtils.isSSL(peerConfig.getUrl())) {
                this.prepareBaseTlsProps(peerConfig.getTlsCACerts(), props);

                props.put(DefaultConfiguration.PROPERTY_ENDPOINT_PEM_BYTES, peerConfig.getTlsCACerts().getPem().getBytes());
                Properties urlProp = Utils.parseGrpcUrl(peerConfig.getUrl());
                props.put(DefaultConfiguration.PROPERTY_ENDPOINT_HOSTNAME_OVERRIDE, urlProp.getProperty("host"));

                this.injectGrpcKeepAliveProperties(props);
            }
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("Invalid Peer URL", e);
        }

        return props;
    }

    /**
     * Prepare Orderer properties
     */
    private Properties prepareOrdererProperties(OrdererConfig ordererConfig) {

        Properties props = new Properties();

        // convert the TLS cert into PEM Bytes if TLS is required
        try {
            if (this.sslUtils.isSSL(ordererConfig.getUrl())) {
                this.prepareBaseTlsProps(ordererConfig.getTlsCACerts(), props);
                props.put(DefaultConfiguration.PROPERTY_ENDPOINT_PEM_BYTES, ordererConfig.getTlsCACerts().getPem().getBytes());
                Properties urlProp = Utils.parseGrpcUrl(ordererConfig.getUrl());
                props.put(DefaultConfiguration.PROPERTY_ENDPOINT_HOSTNAME_OVERRIDE, urlProp.getProperty("host"));

                this.injectGrpcKeepAliveProperties(props);
            }
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("Invalid Peer URL", e);
        }

        return props;
    }
    
    /**
     * Prepare EventHub properties
     */
    private Properties prepareEventHubProperties() {

        Properties props = new Properties();
        this.injectGrpcKeepAliveProperties(props);

        return props;
    }

    /**
     * Injects the grpc keepAlive properties in order to maintain a persistent connection to the
     * network components.
     * 
     * @param properties
     */
    private void injectGrpcKeepAliveProperties(Properties properties) {
        // this should keep the event hub connection alive on IBP
        properties.put("grpc.NettyChannelBuilderOption.keepAliveTime",
                        new Object[] {120000L, TimeUnit.MILLISECONDS});
        properties.put("grpc.NettyChannelBuilderOption.keepAliveTimeout",
                        new Object[] {20000L, TimeUnit.MILLISECONDS});
        properties.put("grpc.NettyChannelBuilderOption.keepAliveWithoutCalls", new Object[] {true});
    }
    
    /**
     * Connects the current client with the provided user to the provided channel using the channel
     * config.
     *
     * @param channelName - the name of the channel to connect to
     * @param channelConfig - the channel config providing peer, orderer and eventhub URLs
     */
    public void connect(String channelName, ChannelConfig channelConfig)
        throws org.hyperledger.fabric.sdk.exception.BaseException {

        LOGGER.debug(BgxLogMarkers.FABRIC_TECH,
            String.format("Connecting to channel %s", channelName));

        // Create channel
        channel = client.newChannel(channelName);

        // Add all the peers in the channel
        Iterator peerKeys = channelConfig.getPeers().keySet().iterator();
        while (peerKeys.hasNext()) {
            String peerKey = (String) peerKeys.next();
            PeerConfig peerConfig = this.ibpConfig.getPeers().get(peerKey);

            Peer peer = client
                .newPeer(peerKey, peerConfig.getUrl(), this.preparePeerProperties(peerConfig));

            channel.addPeer(peer);

            LOGGER.debug(BgxLogMarkers.FABRIC_TECH, "Added peer '{}' to channel '{}'",
                peerKey, channelName);

            // add only the first peer key as event hub - we only need one and all event hubs should receive all events
//            if (channel.getEventHubs().size() == 0) {
//                EventHub eventHub = client.newEventHub(peerKey, peerConfig.getEventUrl(), prepareEventHubProperties() );
//                eventHub.setEventHubDisconnectedHandler(hub -> {
//                    // log the disconnect
//                    LOGGER.debug(BgxLogMarkers.DEV, "Disconnected event hub {}", hub.getUrl());
//                });
//                channel.addEventHub(eventHub);
//
//                LOGGER.debug(BgxLogMarkers.FABRIC_TECH, "Added event hub '{}' to channel '{}'",
//                    peerConfig.getEventUrl(), channelName);
//            }
        }


        // Add all the orderers
        Iterator ordererKeys = channelConfig.getOrderers().iterator();
        while (ordererKeys.hasNext()) {
            String ordererKey = (String) ordererKeys.next();
            OrdererConfig ordererConfig = this.ibpConfig.getOrderers().get(ordererKey);
            Orderer orderer = client.newOrderer(ordererKey, ordererConfig.getUrl(),
                this.prepareOrdererProperties(ordererConfig));
            channel.addOrderer(orderer);

            LOGGER.debug(BgxLogMarkers.FABRIC_TECH, "Added orderer '{}' to channel '{}'",
                ordererKey, channelName);
        }

        // Initialize channel
        channel.initialize();

        while (peerKeys.hasNext()) {
            String peerKey = (String) peerKeys.next();
            PeerConfig peerConfig = this.ibpConfig.getPeers().get(peerKey);


            // add only the first peer key as event hub - we only need one and all event hubs should receive all events
            if (channel.getEventHubs().size() == 0) {
                EventHub eventHub = client.newEventHub(peerKey, peerConfig.getEventUrl(), prepareEventHubProperties() );
                eventHub.setEventHubDisconnectedHandler(hub -> {
                    // log the disconnect
                    LOGGER.debug(BgxLogMarkers.DEV, "Disconnected event hub {}", hub.getUrl());
                });
                channel.addEventHub(eventHub);

                LOGGER.debug(BgxLogMarkers.FABRIC_TECH, "Added event hub '{}' to channel '{}'",
                        peerConfig.getEventUrl(), channelName);
            }
        }
    }

    /**
     * Registers a new user with the currently connected client. This requires the admin user, which
     * needs to be enrolled already.
     *
     * @param userName - the user name to register
     * @param affiliation - the affiliation of that new user
     * @param adminUser - the admin user who performs the registration
     * @return the newly registered ChannelUser with the generated enrollmentSecret
     */
    public ChannelUser registerUser(String userName, String affiliation, User adminUser)
        throws Exception {

        LOGGER.debug(BgxLogMarkers.FABRIC_TECH, String.format("Register new user %s", userName));

        String mspId = this.ibpConfig.getCertificateAuthorities().values().iterator().next()
            .getXMspid();

        RegistrationRequest req = new RegistrationRequest(userName, affiliation);
        String secret = caClient.register(req, adminUser);

        ChannelUser user = new ChannelUser(userName, affiliation, mspId);
        user.setMspId(mspId);
        user.setEnrollmentSecret(secret);
        return user;
    }

    /**
     * Getter for the HFClient
     *
     * @return - the initialised fabric client
     */
    public HFClient getClient() {
        return client;
    }

    /**
     * Setter for the fabric client (probably won't be used)
     *
     * @param client - the fabric client to use for this connector
     */
    public void setClient(HFClient client) {
        this.client = client;
    }

    /**
     * Getter for the connected channel. If connect has not been called yet, this is null
     *
     * @return the connected channel instance
     */
    public Channel getChannel() {
        return channel;
    }

    /**
     * Setter for the channel (probably won't be used)
     *
     * @param channel - the channel provided by this connector
     */
    public void setChannel(Channel channel) {
        this.channel = channel;
    }
}
