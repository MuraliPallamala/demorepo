package com.ibm.au.bgx.core.approvalmodel;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.chain.gx.GxActionRequestConverter;
import com.ibm.au.bgx.model.pojo.ActionScopeType;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.approvalmodel.SharedApprovalModelActionType;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxActionApprovePayload;
import com.ibm.au.bgx.model.pojo.gx.GxActionType;
import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class GxActionConverterImpl implements GxActionRequestConverter {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Override
    public GxAction from(GxPrefillRequest gxPrefillRequest) {
        GxAction output = new GxAction();
        output.setId(gxPrefillRequest.getId());
        output.setScope(ActionScopeType.EXTERNAL);
        output.setType(GxActionType.PREFILL);
        output.setGxRequestId(gxPrefillRequest.getGxRequestId());
        output.setCreatedBy(gxPrefillRequest.getCreatedBy());
        output.setCreatedAt(gxPrefillRequest.getCreatedAt());
        return output;
    }

    @Override
    public GxAction from(ApprovalModelFlowRequest approvalModelFlowAction) {
        GxAction output = new GxAction();
        output.setId(approvalModelFlowAction.getId());
        output.setScope(ActionScopeType.INTERNAL);
        output.setType(this.getType(approvalModelFlowAction));
        output.setGxRequestId(approvalModelFlowAction.getGxRequestId());
        output.setCreatedBy(approvalModelFlowAction.getCreatedBy());
        output.setCreatedAt(approvalModelFlowAction.getCreatedAt());
        output.setAuthoredBy(approvalModelFlowAction.getAuthoredBy());

        // Pull out GxAction payload from ApprovalModelRequest
        try {
           SharedApprovalModelActionType approvalModelActionType = SharedApprovalModelActionType.fromValue(approvalModelFlowAction.getType());
            if (ApprovalModelUtil.gxActionTypes.contains(approvalModelActionType)) {
                GxAction gxAction = MAPPER.convertValue(approvalModelFlowAction.getPayload(), GxAction.class);
                output.setPayload(gxAction.getPayload());
            }
        } catch (IllegalArgumentException e) {
            // Do nothing
        }

        return output;
    }

    @Override
    public List<GxAction> fromChildren(ApprovalModelFlowRequest approvalModelFlowRequest) {
        List<GxAction> output = new ArrayList<>();
        for (ApprovalModelFlowRequest child : approvalModelFlowRequest.getActions()) {
            output.add(this.from(child));
        }
        return output;
    }

    private GxActionType getType(ApprovalModelFlowRequest approvalModelFlowRequest) {
        SharedApprovalModelActionType approvalModelRequestType = SharedApprovalModelActionType
            .valueOf(approvalModelFlowRequest.getType());
        switch (approvalModelRequestType) {
            case START_ISSUE_GUARANTEE:
                return GxActionType.SUBMIT;
            case START_AMEND_GUARANTEE:
                return GxActionType.SUBMIT;
            case START_DEMAND_GUARANTEE:
                return GxActionType.SUBMIT;
            case START_PAYWALK_GUARANTEE:
                return GxActionType.SUBMIT;
            case START_CANCEL_GUARANTEE:
                return GxActionType.SUBMIT;
            case START_TRANSFER_GUARANTEE:
                return GxActionType.SUBMIT;
            case PREFILL_ISSUE_GUARANTEE:
                return GxActionType.PREFILL;
            case PREFILL_AMEND_GUARANTEE:
                return GxActionType.PREFILL;
            case PREFILL_CANCEL_GUARANTEE:
                return GxActionType.PREFILL;
            case APPROVE_ISSUE_GUARANTEE:
                return GxActionType.APPROVE;
            case APPROVE_AMEND_GUARANTEE:
                return GxActionType.APPROVE;
            case APPROVE_DEMAND_GUARANTEE:
                return GxActionType.APPROVE;
            case APPROVE_CANCEL_GUARANTEE:
                return GxActionType.APPROVE;
            case APPROVE_TRANSFER_GUARANTEE:
                return GxActionType.APPROVE;
            case CANCEL_ISSUE_GUARANTEE:
                return GxActionType.CANCEL;
            case CANCEL_AMEND_GUARANTEE:
                return GxActionType.CANCEL;
            case CANCEL_DEMAND_GUARANTEE:
                return GxActionType.CANCEL;
            case CANCEL_CANCEL_GUARANTEE:
                return GxActionType.CANCEL;
            case CANCEL_TRANSFER_GUARANTEE:
                return GxActionType.CANCEL;
            case REJECT_ISSUE_GUARANTEE:
                return GxActionType.REJECT;
            case REJECT_AMEND_GUARANTEE:
                return GxActionType.REJECT;
            case REJECT_DEMAND_GUARANTEE:
                return GxActionType.REJECT;
            case REJECT_CANCEL_GUARANTEE:
                return GxActionType.REJECT;
            case REJECT_TRANSFER_GUARANTEE:
                return GxActionType.REJECT;
            case DEFER_DEMAND_GUARANTEE:
                return GxActionType.DEFER;
            case REVOKE_APPROVE_ISSUE:
                return GxActionType.REVOKE;
            case REVOKE_APPROVE_AMEND:
                return GxActionType.REVOKE;
            case REVOKE_APPROVE_CANCEL:
                return GxActionType.REVOKE;
            case REVOKE_APPROVE_TRANSFER:
                return GxActionType.REVOKE;
            case APPROVAL_FLOW_APPROVE:
                return GxActionType.APPROVE;
            case APPROVAL_FLOW_REJECT:
                return GxActionType.REJECT;
            case APPROVAL_FLOW_CANCEL:
                return GxActionType.CANCEL;
        }

        throw new IllegalArgumentException("Unknown type found");
    }
}
