package com.ibm.au.bgx.core.cache;

import com.ibm.au.bgx.model.pojo.UserProfile;

public interface UserProfileCache {

    UserProfile get(String userId);

    void refresh(String userId);
}
