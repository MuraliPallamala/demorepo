package com.ibm.au.bgx.core.validation;

import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.pojo.BaseRequest;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.validation.BgxDataValidator;

/**
 * Abstract class for data validation methods.
 *
 * Note that we keep the actual validator (i.e. validateX instead of isValidX) methods to be
 * implemented by the child class so that validator can throw exception with various details.
 * If we do the other way, the validator cannot throw exception with extra details for the client
 * to let it know why the data is not valid.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public abstract class AbstractBgxDataValidator implements BgxDataValidator {

	/**
	 * <p>
	 * Determines whether the given <i>profile</i> is a valid organisation profile according to the 
	 * given onboarding request <i>status</i>.
	 * </p>
	 * <p>
	 * This method invokes {@link BgxDataValidator#validateProfile(OrgProfile, Status)}
	 * and if the method throws {@link DataValidationException} it captures it and returns {@literal 
	 * false}. The implementation of the last method is left to concrete classes.
	 * </p>
	 * 
	 * @param profile	an instance of {@link OrgProfile} that contains the information about
	 * 					the organisation profile to validate. It cannot be {@literal null}.
	 * 
	 * @param status 	a {@link Status} value that determines the type of checks that are applied to the
	 * 					<i>profile</i>. Currently the only relevant values are {@link Status#DRAFTED} and
	 * 					{@link Status#CONFIRMED}. The values {@link Status#APPROVED} and {@link Status#REJECTED} 
	 * 					trigger the same type of checks of {@link Status#DRAFTED}, while the value {@link 
	 * 					Status#ABANDONED} triggers the same type of checks applied for {@link Status#DRAFTED}. 
	 * 					It cannot be {@literal null}.
	 * 
	 * @return	{@literal true} if the given <i>profile</i> is valid with respect to the provide 
	 * 			<i>status</i>, {@literal false} otherwise.
	 * 
	 * @throws IllegalArgumentException if <i>profile</i> or <i>status</i> is {@literal null}.
	 * 
	 * @see BgxDataValidator#validateProfile(OrgProfile, BaseRequest.Status)
	 */
	@Override
	public boolean isValidProfile(OrgProfile profile, BaseRequest.Status status) {

        try {
        	
            this.validateProfile(profile, status);
        
        } catch (DataValidationException e) {
        
        	return false;
        }

        return true;
		
	}
	
	
    /**
     * <p>
     * Determines whether the given business identifier is valid.
     * </p>
     * <p>
	 * This method invokes {@link BgxDataValidator#validateBusinessId(String)} and if the
	 *  method throws {@link DataValidationException} it captures it and returns  {@literal 
	 * false}. The implementation of the last method is left to concrete classes.
     * </p>
     * 
     * @param businessId	a {@link String} representing the business identifier to validate.
     * 						It cannot be {@literal null} or an empty string.
     * 
     * @return	{@literal true} if <i>businessId</i> is a valid business identifier, {@literal false}
     * 			otherwise.
     * 
     * @throws IllegalArgumentException	if <i>businessId</i> is {@literal null}.
	 * 
	 * @see BgxDataValidator#validateBusinessId(String)
     */
    @Override
    public boolean isValidBusinessId(String businessId) {

        try {
        
        	this.validateBusinessId(businessId);
        
        } catch (DataValidationException e) {
        
        	return false;
        }

        return true;
    }

    /**
     * <p>
     * Determines if the given identifier is a valid Australian Business Number (ABN).
     * </p>
     * <p>
	 * This method invokes {@link BgxDataValidator#validateAbn(String)} and if the
	 *  method throws {@link DataValidationException} it captures it and returns 
	 * {@literal false}. The implementation of the last method is left to concrete 
	 * classes.
     * </p>
     * 
     * 
     * @param abn	a {@link String} representing the business identifier to test. It
     * 				cannot be {@literal null}.
     * 
     * @return	{@literal true} if <i>abn</i> is a valid ABN, {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException	if <i>abn</i> is {@literal null}.
     * 
     * @see BgxDataValidator#validateAbn(String)
     */
    @Override
    public boolean isValidAbn(String abn) {

        try {
        
        	this.validateAbn(abn);
        
        } catch (DataValidationException e) {
        
        	return false;
        }

        return true;
    }
    /**
     * <p>
     * Determines if the given identifier is a valid Australian Company Number (ACN).
     * </p>
     * <p>
	 * This method invokes {@link BgxDataValidator#validateAcn(String)} and if the
	 *  method throws {@link DataValidationException} it captures it and returns 
	 * {@literal false}. The implementation of the last method is left to concrete 
	 * classes.
     * </p>
     * 
     * @param acn	a {@link String} representing the business identifier to test. It
     * 				cannot be {@literal null}.
     * 
     * @return	{@literal true} if <i>acn</i> is a valid ACN, {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException	if <i>acn</i> is {@literal null}.
     * 
     * @see BgxDataValidator#validateAcn(String)
     */
    @Override
    public boolean isValidAcn(String acn) {

        try {
        
        	this.validateAcn(acn);
        
        } catch (DataValidationException e) {
        
        	return false;
        }

        return true;
    }
}
