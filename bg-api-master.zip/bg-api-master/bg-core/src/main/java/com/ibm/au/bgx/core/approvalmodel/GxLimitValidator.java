package com.ibm.au.bgx.core.approvalmodel;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.exception.GuaranteeException;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.exception.GuaranteeNotFoundException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.approvalmodel.SharedApprovalModelActionType;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxAmendPayload;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.gx.GxTransferPayload;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.math.BigInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class GxLimitValidator {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractApprovalModel.class);

    public String getGxId(BgxPrincipal principal, ApprovalModelFlowRequest approvalModelFlowRequest) 
    		throws GuaranteeException, GuaranteeNotFoundException, GuaranteeForbiddenException {

        SharedApprovalModelActionType actionType;
        try {
            actionType = SharedApprovalModelActionType
                .fromValue(approvalModelFlowRequest.getType());
        } catch (IllegalArgumentException e) {
            // Unknown type
            return null;
        }

        String gxId = null;
        if (ApprovalModelUtil.gxRequestTypes.contains(actionType)) {
        	
            GxRequest gxRequest = MAPPER.convertValue(approvalModelFlowRequest.getPayload(), GxRequest.class);
            gxId = gxRequest.getGuaranteeId();
        
        } else if (ApprovalModelUtil.gxActionTypes.contains(actionType)) {
            
        	GxAction gxAction = MAPPER.convertValue(approvalModelFlowRequest.getPayload(), GxAction.class);
            String gxRequestId = gxAction.getGxRequestId();
            GxRequest flow = principal.getGxManager().getFlow(gxRequestId);
            gxId = flow.getGuaranteeId();
        }
        return gxId;
    }


    /**
     * Validate GxLimit based on the request payload
     */
    public boolean validateGxLimit(BgxPrincipal principal,
        ApprovalModelFlowRequest parentFlow)
        throws GuaranteeNotFoundException, GuaranteeForbiddenException, GuaranteeException {

        SharedApprovalModelActionType actionType;
        try {
            actionType = SharedApprovalModelActionType
                .fromValue(parentFlow.getType());
        } catch (IllegalArgumentException e) {
            // Unknown actions are assumed to not be gx related
            return true;
        }

        if (ApprovalModelUtil.gxRequestTypes.contains(actionType)) {
        	
            GxRequest gxRequest = MAPPER.convertValue(parentFlow.getPayload(), GxRequest.class);
            return this.validateGxLimit(principal, actionType, gxRequest);
            
        } else if (ApprovalModelUtil.gxActionTypes.contains(actionType)) {
        	
            GxAction gxAction = MAPPER.convertValue(parentFlow.getPayload(), GxAction.class);
            return this.validateGxLimit(principal, actionType, gxAction);
        }

        // other actions are assumed to be unrelated to guarantees
        return true;
    }

    /**
     * Validate GxLimit for the GxRequest
     */
    private boolean validateGxLimit(BgxPrincipal principal,
        SharedApprovalModelActionType actionType, GxRequest gxRequest)
        throws GuaranteeException, GuaranteeNotFoundException, GuaranteeForbiddenException {

        if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
        	
            LOGGER.debug(BgxLogMarkers.DEV, "Checking Gx Limit for {} action", actionType);
            GxIssuePayload gxIssuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
            return compareGxLimit(principal, gxIssuePayload.getAmount().getOutstanding());
        
        } else if (gxRequest.getType().equals(GxRequestType.TRANSFER)) {
        
        	GxTransferPayload gxTransferPayload = MAPPER.convertValue(gxRequest.getPayload(), GxTransferPayload.class);
            return compareGxLimit(principal, gxTransferPayload.getGx().getAmount().getOutstanding());
        
        } else if (gxRequest.getType().equals(GxRequestType.AMEND)) {
        	
            GxAmendPayload gxAmendPayload = MAPPER.convertValue(gxRequest.getPayload(), GxAmendPayload.class);
            if (gxAmendPayload.getAmount() != null && !compareGxLimit(principal, gxAmendPayload.getAmount())) {
                return false;
            }
        }

        Gx gx = principal.getGxManager().get(gxRequest.getGuaranteeId());
        return compareGxLimit(principal, gx.getAmount().getOutstanding());
    }


    /**
     * Validate GxLimit for the GxActionRequest
     */
    private boolean validateGxLimit(BgxPrincipal principal, SharedApprovalModelActionType actionType, GxAction gxAction)
        throws GuaranteeException, GuaranteeNotFoundException, GuaranteeForbiddenException {

        String gxRequestId = gxAction.getGxRequestId();
        GxRequest gxRequest = principal.getGxManager().getFlow(gxRequestId);

        // validate amount
        return this.validateGxLimit(principal, actionType, gxRequest);
    }


    private boolean compareGxLimit(BgxPrincipal principal, BigInteger amount) {
    	
        BigInteger userGxLimit = principal.getGxLimit();
        LOGGER.debug(BgxLogMarkers.DEV,
        			 "Checking GxLimit for user {}, for Gx amount: {} and Limit: {}", 
        			 principal.getEmail(),
        			 amount, 
        			 userGxLimit);

        if (amount == null) {
            throw new IllegalArgumentException("Amount cannot be null");
        }

        if (amount.compareTo(BigInteger.ZERO) < 0) {
            throw new IllegalArgumentException(String.format("Amount (%s) cannot be negative.", amount));
        }

        return (userGxLimit == null // this should not be since we set a default max
            || userGxLimit.compareTo(BgxConstants.UNLIMITED_GX_LIMIT) == 0 // we set it by default
            || (userGxLimit.compareTo(amount) >= 0));
    }


}
