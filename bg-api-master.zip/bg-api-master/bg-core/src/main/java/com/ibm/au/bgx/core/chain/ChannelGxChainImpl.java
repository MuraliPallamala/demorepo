package com.ibm.au.bgx.core.chain;

import com.ibm.au.bgx.model.chain.ChannelGxChain;
import com.ibm.au.bgx.model.chain.GxChain;
import com.ibm.au.bgx.model.exception.GuaranteeChainException;
import com.ibm.au.bgx.model.guarantee.GXAPI;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchResponse;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchResponse;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.text.ParseException;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.context.ApplicationContext;

public class ChannelGxChainImpl extends AbstractPrincipalChain<GXAPI> implements ChannelGxChain {


    // NOTE Assumes single channel
	//
	// [CV] NOTE: this is now resolved via the channel selector, which has a proper knowledge
	//            of which channels are configured with the execution context.
	//
    // @Value("${fabric.guarantee.channel.list:PROPERTY_NOT_SET}")
    protected String channelName;

    private GxChain gxChain;

    public ChannelGxChainImpl(ApplicationContext applicationContext, BgxPrincipal principal,
        String channelUserName) {
        super(principal, channelUserName);
        gxChain = (GxChain) applicationContext.getBean("gxChain", principal, channelUserName);
    }

    /**
     * This method resolves the bank guarantee channel that is configured with
     * the current vertical to manage bank guarantees. It uses the services 
     * offered by the {@link ChannelSelector} implementation to resolve the list
     * of bank guarantee channel available and checks whether exactly one channel
     * has been configured.
     * 
     * @throws IllegalStateException	if the channel selector retries a list of
     * 									more than on channel.
     */
    @PostConstruct
    public void init() {
    	
    	List<String> channelNames = this.selector.getChannelNameList();
    	if (channelNames.size() != 1) {
    		
    		throw new IllegalStateException(String.format("Expected one single channel to be configured with the chain (found: %1$d).", channelNames.size()));
    	}
    	
    	this.channelName = channelNames.get(0);
    }
    

    @Override
    public GxRequest startIssue(GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return gxChain.startIssue(channelName, gxRequest);
    }

    @Override
    public GxRequest startAmend(GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return gxChain.startAmend(channelName, gxRequest);
    }

    @Override
    public GxRequest startCancel(GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return gxChain.startCancel(channelName, gxRequest);
    }

    @Override
    public GxRequest startDemand(GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return gxChain.startDemand(channelName, gxRequest);
    }

    @Override
    public GxRequest startPayWalk(GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return gxChain.startPayWalk(channelName, gxRequest);
    }

    @Override
    public GxRequest startTransfer(GxRequest gxRequest)
        throws GuaranteeChainException, ParseException {
        return gxChain.startTransfer(channelName, gxRequest);
    }

    @Override
    public GxRequest expire(GxRequest gxRequest) throws GuaranteeChainException, ParseException {
        return gxChain.expire(channelName, gxRequest);
    }

    @Override
    public GxAction actionApprove(GxAction action) throws GuaranteeChainException, ParseException {
        return gxChain.actionApprove(channelName, action);
    }

    @Override
    public GxAction actionCancel(GxAction action) throws GuaranteeChainException, ParseException {
        return gxChain.actionCancel(channelName, action);
    }

    @Override
    public GxAction actionRevoke(GxAction action) throws GuaranteeChainException, ParseException {
        return gxChain.actionRevoke(channelName, action);
    }

    @Override
    public GxAction actionReject(GxAction action) throws GuaranteeChainException, ParseException {
        return gxChain.actionReject(channelName, action);
    }

    @Override
    public GxAction actionDefer(GxAction action) throws GuaranteeChainException, ParseException {
        return gxChain.actionDefer(channelName, action);
    }

    @Override
    public GxAction actionRecallIssue(String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return gxChain.actionRecallIssue(channelName, flowId, gxRequest);
    }

    @Override
    public GxAction actionRecallAmend(String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return gxChain.actionRecallAmend(channelName, flowId, gxRequest);
    }

    @Override
    public GxAction actionRecallCancel(String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return gxChain.actionRecallCancel(channelName, flowId, gxRequest);
    }

    @Override
    public GxAction actionRecallDemand(String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return gxChain.actionRecallDemand(channelName, flowId, gxRequest);
    }

    @Override
    public GxAction actionRecallTransfer(String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        return gxChain.actionRecallTransfer(channelName, flowId, gxRequest);
    }

    @Override
    public GxSearchResponse search(GxSearchRequest searchRequest)
        throws GuaranteeChainException, ParseException {
        return gxChain.search(channelName, searchRequest);
    }

    @Override
    public Gx get(String guaranteeId) throws GuaranteeChainException, ParseException {
        return gxChain.get(channelName, guaranteeId);
    }

    @Override
    public GxFlowsSearchResponse searchFlows(GxFlowsSearchRequest flowsSearchRequest)
        throws GuaranteeChainException, ParseException {
        return gxChain.searchFlows(channelName, flowsSearchRequest);
    }

    @Override
    public GxRequest getFlow(String flowId) throws GuaranteeChainException, ParseException {
        return gxChain.getFlow(channelName, flowId);
    }

    @Override
    public List<GxAction> getFlowActions(String flowId)
        throws GuaranteeChainException, ParseException {
        return gxChain.getFlowActions(channelName, flowId);
    }
}
