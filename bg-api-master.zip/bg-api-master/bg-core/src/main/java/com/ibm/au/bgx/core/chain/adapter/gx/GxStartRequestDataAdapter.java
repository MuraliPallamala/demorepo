package com.ibm.au.bgx.core.chain.adapter.gx;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxStartRequestDataAdapter implements ChainDataAdapter<Gxs.GXStartRequest, GxRequest> {

    @Autowired
    GxIssueDataAdapter gxIssueDataAdapter;

    @Autowired
    GxAmendDataAdapter gxAmendDataAdapter;

    @Autowired
    GxCancelDataAdapter gxCancelDataAdapter;

    @Autowired
    GxDemandDataAdapter gxDemandDataAdapter;

    @Autowired
    GxExpireDataAdapter gxExpireDataAdapter;

    @Autowired
    GxPayWalkDataAdapter gxPayWalkDataAdapter;

    @Autowired
    GxTransferDataAdapter gxTransferDataAdapter;


    @Override
    public Gxs.GXStartRequest toOnChainModel(GxRequest input) {
        Gxs.GXStartRequest.Builder builder = Gxs.GXStartRequest.newBuilder();
        switch (input.getType()) {
            case ISSUE:
                builder.setGxIssueRequest(this.gxIssueDataAdapter.toOnChainModel(input));
                break;
            case AMEND:
                builder.setGxAmendRequest(this.gxAmendDataAdapter.toOnChainModel(input));
                break;
            case DEMAND:
                builder.setGxDemandRequest(this.gxDemandDataAdapter.toOnChainModel(input));
                break;
            case CANCEL:
                builder.setGxCancelRequest(this.gxCancelDataAdapter.toOnChainModel(input));
                break;
            case PAYWALK:
                builder.setGxPayWalkRequest(this.gxPayWalkDataAdapter.toOnChainModel(input));
                break;
            case TRANSFER:
                builder.setGxTransferRequest(this.gxTransferDataAdapter.toOnChainModel(input));
                break;
            case EXPIRE:
                builder.setGxExpireRequest(this.gxExpireDataAdapter.toOnChainModel(input));
                break;
        }
        return builder.build();
    }

    @Override
    public GxRequest toOffchainModel(Gxs.GXStartRequest input) {
    	
        if (input.hasGxIssueRequest()) {
        	
            return this.gxIssueDataAdapter.toOffchainModel(input.getGxIssueRequest());
            
        } else if (input.hasGxAmendRequest()) {

            return this.gxAmendDataAdapter.toOffchainModel(input.getGxAmendRequest());
            
        } else if (input.hasGxCancelRequest()) {

            return this.gxCancelDataAdapter.toOffchainModel(input.getGxCancelRequest());
            
        } else if (input.hasGxDemandRequest()) {

            return this.gxDemandDataAdapter.toOffchainModel(input.getGxDemandRequest());
            
        } else if (input.hasGxExpireRequest()) {

            return this.gxExpireDataAdapter.toOffchainModel(input.getGxExpireRequest());
            
        } else if (input.hasGxPayWalkRequest()) {

            return this.gxPayWalkDataAdapter.toOffchainModel(input.getGxPayWalkRequest());
            
        } else if (input.hasGxTransferRequest()) {

            return this.gxTransferDataAdapter.toOffchainModel(input.getGxTransferRequest());
            
        } else {
            throw new IllegalArgumentException("Unable to extract request from protobuf GxStartRequest");
        }
    }

}
