package com.ibm.au.bgx.core.chain.adapter;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.BankAccount;
import com.ibm.au.bgx.model.shared.Common;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class BankAccountTypeDataAdapter implements ChainDataAdapter<Common.BankAccountType, BankAccount.Type> {

    @Override
    public Common.BankAccountType toOnChainModel(BankAccount.Type input) {
        switch (input) {
            case SWIFT:
                return Common.BankAccountType.BANK_ACCOUNT_TYPE_SWIFT;
            case BANK_ACCOUNT_AU_NZ:
                return Common.BankAccountType.BANK_ACCOUNT_TYPE_BANK_ACCOUNT_AU_NZ;
            case IBAN:
                return Common.BankAccountType.BANK_ACCOUNT_TYPE_IBAN;
        }
        throw new IllegalArgumentException("Unable to map BankAccountType to on chain model");
    }

    @Override
    public BankAccount.Type toOffchainModel(Common.BankAccountType input) {
        switch (input) {
            case BANK_ACCOUNT_TYPE_SWIFT:
                return BankAccount.Type.SWIFT;
            case BANK_ACCOUNT_TYPE_BANK_ACCOUNT_AU_NZ:
                return BankAccount.Type.BANK_ACCOUNT_AU_NZ;
            case BANK_ACCOUNT_TYPE_IBAN:
                return BankAccount.Type.IBAN;
            default:
            	throw new IllegalArgumentException("Unable to map BankAccountType to off chain model");
        }
    }
}
