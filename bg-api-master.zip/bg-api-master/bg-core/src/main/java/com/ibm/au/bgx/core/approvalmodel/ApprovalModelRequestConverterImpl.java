package com.ibm.au.bgx.core.approvalmodel;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.chain.gx.ApprovalModelRequestConverter;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxActionType;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

@Component
public class ApprovalModelRequestConverterImpl implements ApprovalModelRequestConverter {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();


    // Convert GxRequest
    @Override
    public ApprovalModelFlowRequest from(BgxPrincipal principal, GxRequest gxRequest) {
        ApprovalModelFlowRequest flowActionRequest = new ApprovalModelFlowRequest();
        flowActionRequest.setGxRequestId(gxRequest.getId());
        flowActionRequest.setPayload(MAPPER.convertValue(gxRequest, Map.class));
        flowActionRequest.setType(getApprovalModelRequestType(principal, gxRequest));
        if (!gxRequest.getType().equals(GxRequestType.ISSUE)) {

        }
        return flowActionRequest;
    }

    // Convert GxAction
    @Override
    public ApprovalModelFlowRequest from(BgxPrincipal principal, GxAction gxAction, GxRequest gxRequest, String workFlowId) {
        if (!gxRequest.getId().equals(gxAction.getGxRequestId())) {
            throw new IllegalArgumentException(String.format("gxActionRequest.gxRequestId %s != gxRequest.id %s", gxAction.getGxRequestId(), gxRequest.getId()));
        }

        ApprovalModelFlowRequest flowActionRequest = new ApprovalModelFlowRequest();
        if (workFlowId != null) {
            flowActionRequest.setFlowId(workFlowId);
        }
        flowActionRequest.setGxRequestId(gxAction.getGxRequestId());
        flowActionRequest.setPayload(MAPPER.convertValue(gxAction, Map.class));
        flowActionRequest.setType(getActionApprovalModelRequestType(gxRequest, gxAction, workFlowId));
        return flowActionRequest;
    }

    private String getApprovalModelRequestType(BgxPrincipal principal, GxRequest gxRequest) {
        ArrayList<GxRequestType> prefillTypes = new ArrayList<>(Arrays.asList(GxRequestType.ISSUE, GxRequestType.AMEND, GxRequestType.CANCEL));
        if (principal.getOrganization().getProfile().getEntityType().equals(OrgProfile.EntityType.APPLICANT_OR_BENEFICIARY) ||
                !prefillTypes.contains(gxRequest.getType())
        ) {
            return String.format("START_%s_GUARANTEE", gxRequest.getType());
        }
        return String.format("PREFILL_%s_GUARANTEE", gxRequest.getType());
    }

    private String getActionApprovalModelRequestType(GxRequest gxRequest, GxAction gxAction, String workFlowId) {
        if (workFlowId != null && (gxAction.getType().equals(GxActionType.APPROVE) || gxAction.getType().equals(GxActionType.CANCEL) || gxAction.getType().equals(GxActionType.REJECT))) {
            return String.format("APPROVAL_FLOW_%s", gxAction.getType());
        }
        if (gxAction.getType().equals(GxActionType.REVOKE)) {
            return String.format("REVOKE_APPROVE_%s", gxRequest.getType());
        }

        return String.format("%s_%s_GUARANTEE", gxAction.getType(), gxRequest.getType());
    }
}
