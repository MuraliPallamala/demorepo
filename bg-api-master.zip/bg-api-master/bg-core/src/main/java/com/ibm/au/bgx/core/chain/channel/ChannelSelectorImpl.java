package com.ibm.au.bgx.core.chain.channel;

import java.security.Security;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.annotation.PostConstruct;
import org.hyperledger.fabric.sdk.ChaincodeID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.ibm.au.bgx.common.rest.IdentityConfiguration;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.core.chain.channel.gx.GxChannelProvider;
import com.ibm.au.bgx.fabric.model.CaConfig;
import com.ibm.au.bgx.fabric.model.ChannelConfig;
import com.ibm.au.bgx.fabric.model.IbpConfig;
import com.ibm.au.bgx.fabric.model.Registrar;
import com.ibm.au.bgx.model.chain.ChannelSelector;
import com.ibm.au.bgx.model.chain.ChannelUser;
import com.ibm.au.bgx.model.exception.DataExistsException;
import com.ibm.au.bgx.model.guarantee.DefaultGXAPIImpl;
import com.ibm.au.bgx.model.guarantee.GXAPI;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.profile.DefaultOrganizationAPIImpl;
import com.ibm.au.bgx.model.profile.DefaultPurposeFormatsAPIImpl;
import com.ibm.au.bgx.model.profile.DefaultTermsConditionsAPIImpl;
import com.ibm.au.bgx.model.profile.OrganizationAPI;
import com.ibm.au.bgx.model.profile.PurposeFormatsAPI;
import com.ibm.au.bgx.model.profile.TermsConditionsAPI;
import com.ibm.au.bgx.model.repository.ChannelUserRepository;


/**
 * This component is responsible for providing chaincode access. It allows to read the configuration
 * (IbpConfig) from the mock-ibp and creates a connector to Fabric. It uses a connector to enroll,
 * register new users, enroll existing users and connect to channels providing chaincode.
 *
 * @author Peter Ilfrich
 */
@Component
public class ChannelSelectorImpl implements ChannelSelector {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelSelectorImpl.class);

    /**
     * This static constructor adds the selected security provider that is needed to
     * parse the content of the key-pair.
     */
    static {
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
    }

    @Autowired
    protected IdentityConfiguration identityConfiguration;
    @Autowired
    SSLUtils sslUtils;
    @Autowired
    private MockIbpConfigLoaderImpl mockIbpConfigLoader;
    @Autowired
    private IbpConfigLoaderImpl ibpConfigLoader;
    @Value("${fabric.organization.channel:platform-channel}")
    private String orgChannel;
    

    /**
     * An instance of {@link GxChannelProvider} that provides information
     * about the set of bank guarantee channels that are configured in the
     * current execution context for bank guarantee management.
     */
    @Autowired
    private GxChannelProvider channelProvider;
    
    /**
     * The chaincode ID for the profile chaincode.
     */
    @Value("${fabric.sdk.chaincode.profile:profile}")
    private String profileChaincodeName;
    /**
     * The chaincode ID for the guarantee chaincode.
     */
    @Value("${fabric.sdk.chaincode.guarantee:guarantee}")
    private String guaranteeChaincodeName;
    /**
     * The default affiliation used for new users (register + enroll)
     */
    @Value("${fabric.sdk.default.affiliation:org1.department1}")
    private String defaultAffiliation;
    /**
     * Whether or not it should load config from mock IBP.
     */
    @Value("${fabric.config.loader.mockIbp:true}")
    private boolean useMockIbp;
    /**
     * The repository storing fabric users
     */
    @Autowired
    private ChannelUserRepository repository;

    /**
     * A cache for the guarantee APIs. The first level is the user name, the second level is the
     * channel name.
     */
    private Map<String, Map<String, GXAPI>> guaranteeApis = new HashMap<>();

    /**
     * A cache for the organization APIs (profile APIs). The key is the user name.
     */
    private Map<String, OrganizationAPI> organizationApis = new HashMap<>();

    /**
     * A cache for the TermsConditions APIs. The key is the user name.
     */
    private Map<String, TermsConditionsAPI> termsAndCondApis = new HashMap<>();

    /**
     * A cache for the PurposeFormatsAPI APIs. The key is the user name.
     */
    private Map<String, PurposeFormatsAPI> purposeFormatApis = new HashMap<>();


    /**
     * The connector created on startup when the admin user connects to the platform-channel.
     */
    private ChannelConnector adminConnector;

    /**
     * The admin user for this API (first user, which is provided by the IbpConfig)
     */
    private ChannelUser adminUser;
    /**
     * The MSP ID used by this API for all fabric communication. It is set on initialisation, when
     * the admin user connects.
     */
    private String mspId;

    /**
     * This method dumps the properties
     */
    private static void dumpConfiguration(Properties properties) {

        LOGGER.info(BgxLogMarkers.FABRIC_TECH, "Current IBP Configuration");
        LOGGER.info(BgxLogMarkers.FABRIC_TECH, "====================================================");
        LOGGER.info(BgxLogMarkers.FABRIC_TECH, "");
        for (Object key : properties.keySet()) {

            LOGGER.info(BgxLogMarkers.FABRIC_TECH, String.format("%1$s: %2$s", key, properties.get(key)));
        }
        LOGGER.info(BgxLogMarkers.FABRIC_TECH, "");
        LOGGER.info(BgxLogMarkers.FABRIC_TECH, "====================================================");
    }

    public ChannelUser getAdminUser() {
        return adminUser;
    }

    /**
     * This initialization method will create an admin connector with the admin fabric-user for the
     * current API instance. It will also create an instance of the profile API (aka
     * OrganizationApi), to verify connectivity on startup.
     */
    @PostConstruct
    protected void init() throws Exception {
        LOGGER.debug(BgxLogMarkers.DEV, "Connecting to profile-chain as admin user.");
        // initialise admin connection (this also sets the adminUser)
        ChannelDescriptor adminProfileChainDescriptor = this.connect();

        // store the admin connector for later registration calls
        this.adminConnector = adminProfileChainDescriptor.getConnector();

        // store the API in the local cache
        organizationApis.put(adminUser.getName(),
                new DefaultOrganizationAPIImpl(adminProfileChainDescriptor.getClient(),
                        adminProfileChainDescriptor.getChannel(),
                        adminProfileChainDescriptor.getChaincodeId()));
    }

    /**
     * Retrieves a connected instance of an OrganizationApi (or Profile API) for a specific user.
     * The method will lookup the actual fabric-user in the offchain DB and register a new user, if
     * the provided user name doesn't exist. It'll then connect as that user and return an instance
     * of a connected OrganizationApi
     *
     * @param userName - the name of the user who will perform invokes/queries on the chaincode
     * @return a connected instance of OrganizationApi with the default user set
     */
    @Override
    public OrganizationAPI getOrganisationApi(String userName) throws Exception {
        return this.getOrganisationApi(userName, false);
    }
    

    @Override
    public OrganizationAPI getOrganisationApi(String userName, boolean forceReconnect) throws Exception {

        synchronized (this.organizationApis) {

            if (this.organizationApis.containsKey(userName) && forceReconnect == false) {
                // return existing connection
                return this.organizationApis.get(userName);
            }

            OrganizationAPI api = connectOrganizationApi(userName);
            // store API for this user in local cache
            this.organizationApis.put(userName, api);
            return api;
        }
    }

    @Override
    public GXAPI getGuaranteeApi(String userName, String channelName) throws Exception {
        return this.getGuaranteeApi(userName, channelName, false);
    }

    @Override
    public PurposeFormatsAPI getPurposeFormatApi(String userName) throws Exception {

        synchronized (purposeFormatApis) {
            if (purposeFormatApis.containsKey(userName)) {
                return this.purposeFormatApis.get(userName);
            }

            // fetch user and create channel descriptor by connecting to the channel
            ChannelUser user = this.getUser(userName, true);
            ChannelDescriptor desc = this.connect(user, this.orgChannel);

            // create new instance of purpose format API
            PurposeFormatsAPI api = new DefaultPurposeFormatsAPIImpl(desc.getClient(), desc.getChannel(), desc.getChaincodeId());
            api.setDefaultUser(user);

            // add it to the cache
            this.purposeFormatApis.put(userName, api);

            // and return
            return api;
        }
    }

    /**
     * Retrieves a connected instance of an GuaranteeApi for a specific user and channel. The method
     * will lookup the actual fabric-user in the offchain DB and register a new user, if the
     * provided user name doesn't exist. It'll then connect as that user and return an instance of a
     * connected GuaranteeApi, which is connected to the provided channel.
     *
     * @param userName    - the name of the user who will perform invokes/queries on the chaincode
     * @param channelName - the name of the channel to connect to (e.g. anz-channel)
     * @return a connected instance of GuaranteeApi with the default user set
     */
    @Override
    public GXAPI getGuaranteeApi(String userName, String channelName, boolean forceReconnect) throws Exception {
        synchronized (this.guaranteeApis) {
            if (this.guaranteeApis.containsKey(userName)) {
                if (this.guaranteeApis.get(userName).containsKey(channelName) && forceReconnect == false) {
                    return this.guaranteeApis.get(userName).get(channelName);
                }
            } else {
                this.guaranteeApis.put(userName, new HashMap<>());
            }

            // create API for this current user and channel
            GXAPI api = this.connectGuaranteeApi(userName, channelName);
            this.guaranteeApis.get(userName).put(channelName, api);
            return api;
        }
    }

    /**
     * Retrieves a connected instance of an GuaranteeApi for a specific user and channel. It'll then
     * connect as that user and return an instance of a connected GuaranteeApi, which is connected
     * to the provided channel.
     *
     * @param user        - the the user who will perform invokes/queries on the chaincode
     * @param channelName - the name of the channel to connect to (e.g. anz-channel)
     * @return a connected instance of GuaranteeApi with the default user set
     */
    @Override
    public GXAPI getGuaranteeApi(ChannelUser user, String channelName) throws Exception {
        return this.getGuaranteeApi(user.getName(), channelName, false);
    }

    /**
     * Retrieves a connected instance of an TermsConditionsAPI for a specific user. The method will
     * lookup the actual fabric-user in the offchain DB and register a new user, if the provided
     * user name doesn't exist. It'll then connect as that user and return an instance of a
     * connected OrganizationApi
     *
     * @param userName - the name of the user who will perform invokes/queries on the chaincode
     * @return a connected instance of OrganizationApi with the default user set
     */
    @Override
    public TermsConditionsAPI getTermsConditionsApi(String userName) throws Exception {
        if (termsAndCondApis.containsKey(userName)) {
            return this.termsAndCondApis.get(userName);
        }

        // fetch user and create channel descriptor by connecting to the channel
        ChannelUser user = this.getUser(userName, true);
        ChannelDescriptor desc = this.connect(user, this.orgChannel);

        // create new API instance for the current user
        TermsConditionsAPI api = new DefaultTermsConditionsAPIImpl(desc.getClient(),
                desc.getChannel(),
                desc.getChaincodeId());
        api.setDefaultUser(user);

        // add API to local cache for future lookup
        this.termsAndCondApis.put(userName, api);
        return api;
    }

    /**
     * Internal method to retrieve a user from the off-chain db. If the user doesn't exist, a new
     * user will be registered and added to the off-chain DB
     *
     * @param userName - the username to lookup
     * @return - an ChannelUser (not yet enrolled)
     */
    @Override
    public ChannelUser getUser(String userName, boolean createIfNotFound) throws Exception {
        return this.getUser(userName, null, createIfNotFound);
    }

    /**
     * Internal method to retrieve a user from the off-chain db. If the user doesn't exist, a new
     * user will be registered and added to the off-chain DB
     *
     * @param userName - the username to lookup
     * @return - an ChannelUser (not yet enrolled)
     */
    @Override
    public ChannelUser getUser(String userName, String orgId, boolean createIfNotFound)
            throws Exception {

        // check if the username is available in the repository
        LOGGER.debug(BgxLogMarkers.DEV, "Searching for channel user '{}' of MSP '{}'", userName, mspId);
        ChannelUser user = this.repository.find(userName, this.mspId);

        if (user != null) {
            LOGGER.debug(BgxLogMarkers.DEV, "Found channel user '{}' of org '{}' and MSP '{}'", userName, user.getOrgId(), user.getMspId());
        }

        // check that we don't have duplicate user for another org
        if (orgId != null && user != null && user.getOrgId() != null && !orgId.equals(user.getOrgId())) {
            throw new IllegalArgumentException(String.format("There exists a user %s for orgId %s and MSP %s,"
                + "cannot create it for org %s", userName, user.getOrgId(), mspId, orgId));
        }

        // no user available, but we need to create one
        if (user == null && createIfNotFound) {

            LOGGER.debug(BgxLogMarkers.DEV, "User '{}' not found, creating new.", userName);

            // register new user
            user = this.registerNewUser(userName);

            try {
                // store user
                user.setOrgId(orgId);
                this.repository.addItem(user);

            } catch (DataExistsException uce) {

                // user was added by a different container, just load that user from the db
                LOGGER.warn("New user was just added by another API.", uce);
                user = this.repository.find(userName, this.mspId);
            }
        } else if (user != null && user.getOrgId() == null
            && (userName.equals(identityConfiguration.getIdentity()) // if username is same as bgxIdentity
                || identityConfiguration.getIdentity().equals(orgId))) { // or if orgId is same as bgxIdentity

            // assign bgxIdentity if we have not set already
            LOGGER.debug(BgxLogMarkers.DEV, "Updating user {} orgId to {}", userName, identityConfiguration.getIdentity());
            user.setOrgId(identityConfiguration.getIdentity());
            user = this.repository.updateItem(user);
        }

        return user;
    }

    /**
     * Retrieves a list of available channels configured in this API. This is provided by a property
     * and injected into this component as channelList.
     *
     * @return a list of channel names
     */
    @Override
    public List<String> getChannelNameList() {
    	
    	String[] nameArray = this.channelProvider.getChannelNames();
    	
    	List<String> nameList = new ArrayList<String>(nameArray.length);
    	for(int i=0; i<nameArray.length; i++) {
    		
    		nameList.add(nameArray[i]);
    	}
    	
    	return nameList;
    }

    /**
     * Register and enroll a user.
     *
     * @param userName         - the name of the user
     * @param orgId            - the id of the organization
     * @param createIfNotFound - boolean flag to indicate whether to create a new fabric user if it
     *                         doesn't exist yet.
     * @return - the freshly created or retrieved ChannelUser
     */
    @Override
    public ChannelUser getEnrolledUser(String userName, String orgId, boolean createIfNotFound) throws Exception {

        // fetch user and create channel descriptor by connecting to the channel
        ChannelUser user = this.getUser(userName, orgId, createIfNotFound);

        if (user == null) {
            throw new IllegalArgumentException("Could not create channel user");
        }

        if (user.getOrgId() == null) {
            user.setOrgId(orgId);
        }

        // load config and initialise connector
        IbpConfig ibpConfig = this.getIbpConfig(this.orgChannel);
        ChannelConnector connector = createConnector(ibpConfig);

        // enroll the current user
        connector.enrollUser(user);

        LOGGER.debug(BgxLogMarkers.FABRIC_TECH, String.format("Found user enrollment cert: %s", user.getEnrollment().getCert()));

        // Save the user with enrolment certificates so that we do not reissue cert
        // This cert is used for bootstrapping the organization where organization will contain this cert
        try {
            if (this.repository.find(user.getName(), user.getMspId()) == null) {
                LOGGER.debug(BgxLogMarkers.FABRIC_TECH, String.format("Saving organization user %s", user.getName()));
                user = this.repository.addItem(user);

            } else {

                LOGGER.debug(BgxLogMarkers.FABRIC_TECH, String.format("Updating organization user %s", user.getName()));
                user = this.repository.updateItem(user);
            }

        } catch (DataExistsException uce) {
            LOGGER.warn("While attempting to update a fabric-user, an exception was thrown", uce);
            user = this.repository.find(user.getName(), user.getMspId());
        }

        return user;
    }

    /**
     * Registers a new user. This will use the admin connector to register a new user on the
     * blockchain.
     *
     * @param userName - the username to register
     * @return - the registered ChannelUser with the newly created enrollSecret (but not enrolled
     * yet)
     */
    protected ChannelUser registerNewUser(String userName) throws Exception {
    	
        return this.adminConnector.registerUser(userName, this.defaultAffiliation, this.adminUser);
    }

    /**
     * Loads the IBP config from the HTTP endpoint configured for this API.
     *
     * @return an IbpConfig instance which contains information about the CA, channels, peers and
     * orderers
     */
    protected IbpConfig getIbpConfig(String channelName) throws Exception {
    	
        if (this.useMockIbp) {
            return this.mockIbpConfigLoader.load(channelName);
        }

        return this.ibpConfigLoader.load(channelName);
    }

    /**
     * Creates a new connector and initialise it, which creates and initiates the clients (CA +
     * peer).
     *
     * @param ibpConfig - the IBP config that provides all the connection credentials. This is
     *                  stored in the connector.
     * @return a channel connector instance, which is not connected yet.
     */
    protected ChannelConnector createConnector(IbpConfig ibpConfig) {
        ChannelConnector connector = new ChannelConnector();
        connector.init(ibpConfig, sslUtils);
        return connector;
    }

    /**
     * Creates a new connection to the fabric using the admin credentials to enroll.
     *
     * @return - a channel descriptor holding HFClient, Channel, ChaincodeID and the connector
     * itself
     */
    protected synchronized ChannelDescriptor connect() throws Exception {
        // load config and extract registrar user
        IbpConfig ibpConfig = this.getIbpConfig(this.orgChannel);
        CaConfig caConfig = ibpConfig.getCertificateAuthorities()
                .get(ibpConfig.getCertificateAuthorities().keySet().iterator().next());
        Registrar admin = caConfig.getRegistrar().get(0);

        // store msp ID for future requests to retrieve user
        this.mspId = caConfig.getXMspid();

        // set the default affiliation
        if (admin.getXAffiliations() != null && 
        	!admin.getXAffiliations().isEmpty() &&
            !admin.getXAffiliations().contains(this.defaultAffiliation)) {
        	
            this.defaultAffiliation = admin.getXAffiliations().get(0);
        }
        LOGGER.debug(BgxLogMarkers.DEV, "Default affiliation {} and MSP {}", this.defaultAffiliation, this.mspId);

        // create new admin user and store it
        ChannelUser user = this.getUser(admin.getEnrollId(), identityConfiguration.getIdentity(), false);
        if (user == null) {
            user = new ChannelUser(admin.getEnrollId(), this.defaultAffiliation,
                    caConfig.getXMspid());
            user.setEnrollmentSecret(admin.getEnrollSecret());
            user.setMspId(caConfig.getXMspid());
            user.setOrgId(identityConfiguration.getIdentity());
        }

        this.adminUser = user;

        // connect to the org channel using the admin user
        return this.connect(this.adminUser, this.orgChannel);
    }

    /**
     * Creates a new connection to the fabric using the provided user and creating a new connection
     * to the channel with the provided name
     *
     * @param user        - the user used to enroll to the fabric
     * @param channelName - the channel to create a connection to
     * @return - a channel descriptor holding client, channel and chaincode information as well as
     * the connector itself.
     */
    protected synchronized ChannelDescriptor connect(ChannelUser user, String channelName)
            throws Exception {
        // load config and initialise connector
        IbpConfig ibpConfig = this.getIbpConfig(channelName);
        ChannelConnector connector = createConnector(ibpConfig);

        if (user.getActiveStatus() == false) {
            throw new IllegalArgumentException(String.format(
                    "Channel user '%s' is not active and cannot be used to connect to the channel.",
                    user.getName()));
        }

        // enroll the current user
        connector.enrollUser(user);

        LOGGER.debug(BgxLogMarkers.FABRIC_TECH,
                String.format("Found user enrolment cert: %s", user.getEnrollment().getCert()));

        // Save the user with enrolment certificates so that we do not reissue cert
        // This cert is used for bootstrapping the organization where organization will contain this cert
        try {
            if (this.repository.find(user.getName(), user.getMspId()) == null) {
                LOGGER.debug(BgxLogMarkers.FABRIC_TECH,
                        String.format("Saving organization user %s", user.getName()));
                this.repository.addItem(user);

            } else {

                LOGGER.debug(BgxLogMarkers.FABRIC_TECH,
                        String.format("Updating organization user %s", user.getName()));
                this.repository.updateItem(user);

            }

        } catch (DataExistsException uce) {
            LOGGER.warn("While attempting to update a fabric-user, an exception was thrown",
                    uce);
            user = this.repository.find(user.getName(), user.getMspId());
            return this.connect(user, channelName); // FIXME this may potentially cause an infinite recursive loop
        }

        // connect using the channel config
        if (!ibpConfig.getChannels().containsKey(channelName)) {
            throw new IllegalArgumentException(String.format("No channel exists with name %s", channelName));
        }

        ChannelConfig channelConfig = ibpConfig.getChannels().get(channelName);
        connector.connect(channelName, channelConfig);

        // create descriptor and extract client + channel
        ChannelDescriptor desc = new ChannelDescriptor();
        desc.setClient(connector.getClient());
        desc.setChannel(connector.getChannel());
        desc.setConnector(connector);

        if (channelName.equals(this.orgChannel)) {
            // if we access the organization channel, we use the profile chaincode
            desc.setChaincodeId(
                    ChaincodeID.newBuilder().setName(this.profileChaincodeName).build());
        } else {
            // any other channel is a guarantee channel
            desc.setChaincodeId(
                    ChaincodeID.newBuilder().setName(this.guaranteeChaincodeName).build());
        }

        return desc;
    }

    /**
     * Creates a new organisation api instance and sets the default user
     *
     * @param userName - the user name to connect with
     * @return - an instance of organisation API
     */
    @Override
    public OrganizationAPI connectOrganizationApi(String userName) throws Exception {
        // fetch user and create channel descriptor by connecting to the channel
        ChannelUser user = this.getUser(userName, true);
        ChannelDescriptor desc = this.connect(user, this.orgChannel);

        // create new API instance for the current user
        OrganizationAPI api = new DefaultOrganizationAPIImpl(desc.getClient(), desc.getChannel(),
                desc.getChaincodeId());
        api.setDefaultUser(user);

        return api;
    }

    @Override
    public GXAPI connectGuaranteeApi(String userName, String channelName) throws Exception {
        // fetch user and create channel descriptor
        ChannelUser user = this.getUser(userName, true);
        ChannelDescriptor desc = this.connect(user, channelName);

        // create API for this current channel
        GXAPI api = new DefaultGXAPIImpl(desc.getClient(), desc.getChannel(),
                desc.getChaincodeId());
        api.setDefaultUser(user);

        return api;
    }

    @Override
    public String getProfileChannelName() {
        return this.orgChannel;
    }
}
