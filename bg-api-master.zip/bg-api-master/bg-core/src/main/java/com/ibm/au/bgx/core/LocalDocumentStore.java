package com.ibm.au.bgx.core;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.DocumentStore;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Implementation of {@link DocumentStore} that stores and reads file from a local directory
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class LocalDocumentStore extends AbstractDocumentStore implements DocumentStore {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Value("${bgx.documentStore.path:_documents}")
    private String bucketPath;

    @Override
    public void createDocument(String id, byte[] bytes, Map<String, Object> meta) {

        if (StringUtils.isEmpty(id)) {
            throw new IllegalArgumentException("Document ID cannot be empty");
        }

        if (bytes == null) {
            throw new IllegalArgumentException("Data bytes cannot be null");
        }

        // clean any previously created document with the same id
        if (this.hasDocument(id)) {
            this.deleteDocument(id);
        }

        String documentPath = this.generateStoragePath(id);
        try (FileOutputStream docStream = new FileOutputStream(documentPath)) {
            // write the file
            docStream.write(bytes);

            // create meta if required
            if (meta != null) {
                this.createMeta(id, meta);
            }

        } catch (IOException e) {
            throw new IllegalArgumentException(String.format("Could not create document with id: %s", id), e);
        }
    }

    @Override
    public Map<String, Object> readDocumentMeta(String id) {

        if (StringUtils.isEmpty(id)) {
            throw new IllegalArgumentException("Document ID cannot be null");
        }

        if (!this.hasDocumentMeta(id)) {
            return null;
        }

        try {
            return MAPPER.readValue(new File(generateDocumentMetaPath(id)), new TypeReference<Map<String, Object>>(){});
        } catch (IOException e) {
            throw new IllegalStateException("Could not parse document meta", e);
        }
    }

    @Override
    public byte[] readDocument(String id) {

        if (StringUtils.isEmpty(id)) {
            throw new IllegalArgumentException("Document ID cannot be null");
        }

        if (!hasDocument(id)) {
            throw new IllegalArgumentException(String.format("Document does not exists with id: %s", id));
        }

        String documentPath = generateStoragePath(id);
        try (FileInputStream inputStream = new FileInputStream(documentPath)) {
            return IOUtils.toByteArray(inputStream);
        } catch (IOException e) {
            throw new IllegalArgumentException(String.format("Could not read document with id: %s", id), e);
        }
    }

    @Override
    public boolean hasDocument(String id) {
        if (StringUtils.isEmpty(id)) {
            return false;
        }

        return Files.exists(Paths.get(generateStoragePath(id)));
    }

    @Override
    public boolean hasDocumentMeta(String id) {
        if (StringUtils.isEmpty(id)) {
            return false;
        }

        return Files.exists(Paths.get(generateDocumentMetaPath(id)));
    }

    @Override
    public boolean deleteDocument(String id) {

        String documentPath = generateStoragePath(id);
        try {
            deleteDocumentMeta(id);

            return Files.deleteIfExists(Paths.get(documentPath));
        } catch (IOException e) {
            throw new IllegalArgumentException(String.format("Could not delete document: %s", id),e);
        }
    }

    private boolean deleteDocumentMeta(String id) {

        String documentPath = generateDocumentMetaPath(id);
        try {
            return Files.deleteIfExists(Paths.get(documentPath));
        } catch (IOException e) {
            throw new IllegalArgumentException(String.format("Could not delete document: %s", id),e);
        }
    }

    /**
     * Prepare the storage path
     * @param id A {@link String} containing the file id
     * @return
     */
    private String generateStoragePath(String id) {

        if (StringUtils.isEmpty(bucketPath)) {
            throw new IllegalArgumentException("Property bgx.documentStore.path is not set");
        }

        if (StringUtils.isEmpty(id)) {
            throw new IllegalArgumentException("File id cannot be empty");
        }

        try {
            if (!Files.exists(Paths.get(bucketPath))) {
                Files.createDirectories(Paths.get(bucketPath));
            }
        } catch (IOException e) {
            throw new IllegalArgumentException(String.format("Could not create directories for document store at: %s", bucketPath), e);
        }

        return String.format("%s/%s", bucketPath, id);
    }

    /**
     * Create document meta data file
     *
     * @param id A {@link String} containing document id
     * @param meta A {@link Map} containing meta data
     */
    private void createMeta(String id, Map<String, Object> meta) {

        if (StringUtils.isEmpty(id)) {
            throw new IllegalArgumentException("ID cannot be empty");
        }

        if (meta == null || meta.isEmpty()) {
            throw new IllegalArgumentException("Parameter 'meta' cannot be empty");
        }

        try (FileOutputStream outputStream = new FileOutputStream(generateDocumentMetaPath(id))) {
            String metaJson = MAPPER.writeValueAsString(meta);
            outputStream.write(metaJson.getBytes());
        } catch (IOException e) {
            throw new IllegalArgumentException(
                String.format("Could not create document meta for id: %s", id), e);
        }
    }

    private String generateDocumentMetaPath(String id) {

        if (StringUtils.isEmpty(id)) {
            throw new IllegalArgumentException("File id cannot be empty");
        }

        String metaPath = String.format("%s.meta", generateStoragePath(id));

        return metaPath;
    }
}
