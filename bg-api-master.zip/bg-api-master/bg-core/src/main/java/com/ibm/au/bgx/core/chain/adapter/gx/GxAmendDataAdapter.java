package com.ibm.au.bgx.core.chain.adapter.gx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.flow.FlowStatusDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxAmendPayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigInteger;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxAmendDataAdapter implements ChainDataAdapter<Gxs.GXAmendRequest, GxRequest> {

    public static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    GxPurposeDataAdapter gxPurposeDataAdapter;

    @Autowired
    FlowStatusDataAdapter flowStatusDataAdapter;

    @Override
    public Gxs.GXAmendRequest toOnChainModel(GxRequest input) {
        GxAmendPayload amendPayload = MAPPER.convertValue(input.getPayload(), GxAmendPayload.class);
        Gxs.GXAmendRequest.Builder builder = Gxs.GXAmendRequest.newBuilder()
                .setGxId(input.getGuaranteeId());

        if (input.getId() != null) {
            builder.setId(input.getId());
        }

        if (amendPayload.getPurpose() != null) {
            builder.putAllPurpose(gxPurposeDataAdapter.toOnChainModel(amendPayload.getPurpose()));
        }

        if (amendPayload.getAmount() != null) {
            if (amendPayload.getAmount().compareTo(BigInteger.ZERO) <= 0) {
                throw new IllegalArgumentException(String.format("Amend amount %s for Gx %s cannot be zero or negative", amendPayload.getAmount(), input.getGuaranteeId()));
            }
            builder.setAmount(amendPayload.getAmount().longValue());
        }

        if (amendPayload.getExpiresAt() != null) {
            builder.setExpiresAt(timestampDataAdapter.toOnChainModel(amendPayload.getExpiresAt()));
        }

        if (amendPayload.getExpiresAtOpenEnded() != null) {
            builder.setExpiresAtOpenEnded(amendPayload.getExpiresAtOpenEnded());
        }

        if (amendPayload.getPurposeType() != null) {
            builder.setPurposeType(amendPayload.getPurposeType());
        }

        return builder.build();
    }

    @Override
    public GxRequest toOffchainModel(Gxs.GXAmendRequest input) {
        GxRequest output = new GxRequest();
        GxAmendPayload payload = new GxAmendPayload();
        // NOTE Do not change this comparison to use .equals, we need to compare against the exact object
        payload.setPurpose(gxPurposeDataAdapter.toOffchainModel(input.getPurposeMap()));
        payload.setPurposeType(input.getPurposeType());

        if (input.getAmount() != 0) {
            payload.setAmount(BigInteger.valueOf(input.getAmount()));
        }
        payload.setExpiresAt(timestampDataAdapter.toOffchainModel(input.getExpiresAt()));
        if (input.getExpiresAtOpenEnded()) {
            payload.setExpiresAtOpenEnded(input.getExpiresAtOpenEnded());
        }
        output.setPayload(payload);
        output.setId(input.getId());
        output.setType(GxRequestType.AMEND);
        output.setStatus(flowStatusDataAdapter.toOffchainModel(input.getStatus()));
        output.setGuaranteeId(input.getGxId());
        output.setCreatedBy(input.getCreatedBy());
        output.setCreatedAt(timestampDataAdapter.toOffchainModel(input.getCreatedAt()));
        output.setUpdatedBy(input.getUpdatedBy());
        output.setUpdatedAt(timestampDataAdapter.toOffchainModel(input.getUpdatedAt()));

        return output;
    }
}
