package com.ibm.au.bgx.core;

import com.ibm.au.bgx.core.approvalmodel.FourEyeApprovalModel;
import com.ibm.au.bgx.core.approvalmodel.SoleApproverApprovalModel;
import com.ibm.au.bgx.core.chain.ChannelGxChainImpl;
import com.ibm.au.bgx.core.chain.GxChainImpl;
import com.ibm.au.bgx.model.GxPrefillRequestManager;
import com.ibm.au.bgx.model.RequestManager;
import com.ibm.au.bgx.model.chain.ChannelGxChain;
import com.ibm.au.bgx.model.chain.GxChain;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class RuntimeBeanConfig {

    @Autowired
    ApplicationContext applicationContext;

    @Bean
    @Scope("prototype")
    public AppBenGxManagerImpl appBenGxManager(BgxPrincipal principal) {
        return new AppBenGxManagerImpl(applicationContext, principal);
    }

    @Bean
    @Scope("prototype")
    public IssuerGxManagerImpl issuerGxManager(BgxPrincipal principal) {
        return new IssuerGxManagerImpl(applicationContext, principal);
    }

    @Bean
    @Scope("prototype")
    public GxChain gxChain(BgxPrincipal principal, String channelUserName) {
        return new GxChainImpl(principal, channelUserName);
    }

    @Bean
    @Scope("prototype")
    public ChannelGxChain channelGxChain(BgxPrincipal principal, String channelUserName) {
        return new ChannelGxChainImpl(applicationContext, principal, channelUserName);
    }

    @Bean
    @Scope("prototype")
    public SoleApproverApprovalModel soleApproverApprovalModel(BgxPrincipal principal) {
        return new SoleApproverApprovalModel(principal);
    }

    @Bean
    @Scope("prototype")
    public FourEyeApprovalModel fourEyeApprovalModel(BgxPrincipal principal) {
        return new FourEyeApprovalModel(principal);
    }

    @Bean
    @Scope("prototype")
    public RequestManager requestManager(BgxPrincipal principal) {
        return new RequestManagerImpl(principal);
    }

    @Bean
    @Scope("prototype")
    public GxPrefillRequestManager gxPrefillRequestManager(BgxPrincipal principal) {
        return new GxPrefillRequestManagerImpl(principal);
    }
}
