package com.ibm.au.bgx.core.chain.adapter.gx;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxSearchOrderType;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxSearchOrderTypeDataAdapter implements ChainDataAdapter<Gxs.GXSearchOrder, GxSearchOrderType> {

    @Override
    public Gxs.GXSearchOrder toOnChainModel(GxSearchOrderType input) {
        switch (input) {
            case ASC:
                return Gxs.GXSearchOrder.GX_SEARCH_ORDER_ASC;
            case DESC:
                return Gxs.GXSearchOrder.GX_SEARCH_ORDER_DESC;
            default:
                throw new IllegalArgumentException("Unable to map GxOrderType to on chain model");
        }
    }

    @Override
    public GxSearchOrderType toOffchainModel(Gxs.GXSearchOrder input) {
        switch (input) {
            case GX_SEARCH_ORDER_ASC:
                return GxSearchOrderType.ASC;
            case GX_SEARCH_ORDER_DESC:
                return GxSearchOrderType.DESC;
            default:
            	throw new IllegalArgumentException("Unable to map GxOrderType to off chain model");
        }
    }
}
