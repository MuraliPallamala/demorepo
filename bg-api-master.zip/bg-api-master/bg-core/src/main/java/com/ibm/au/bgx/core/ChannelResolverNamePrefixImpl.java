package com.ibm.au.bgx.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.ibm.au.bgx.core.chain.channel.gx.GxChannelMetadata;
import com.ibm.au.bgx.core.chain.channel.gx.GxChannelProvider;


/**
 * <p>
 * Class <b>ChannelResolverNamePrefixImpl</b>. This class implements {@link ChannelResolver}
 * and specialises its behaviour by resolving a channel given prefix that is used to create 
 * the bank guarantee unique identifiers in that channel. There is one prefix for each channel
 * and this is unique across all the bank guarantee channels allocated by the platform.
 * </p>
 * <p>
 * The class leverages the services of the {@link GxChannelProvider} component to resolve the
 * channel by prefix. The component is auto-wired into the instance.
 * </p>
 * 
 * @author Dain Yap Liffman <dainliff@au1.ibm.com>
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
@Primary
@Component
public class ChannelResolverNamePrefixImpl implements ChannelResolver {
	
	/**
	 * A {@literal int} constant containing the length of the length of
	 * the identifier used for bank guarantee requests.
	 */
	public static final int GX_REQUEST_ID_LENGTH 	= 	38;
	/**
	 * A {@literal int} constant containing the length of the prefix used
	 * in the bank guarantee channel to generate bank guarantee identifiers.
	 */
    public static final int GX_PREFIX_LENGTH 		= 	6;
	
    /**
     * A {@link GxChannelProvider} implementation that is used to provide
     * information about the bank guarantee channels that are available
     * in the current execution context.
     */
	@Autowired
	protected GxChannelProvider provider;
    

	/**
	 * <p>
	 * This method implements the channel resolution contract defined by
	 * {@link ChannelResolver#get(String)}. It retrieves the name of the
	 * channel given the identifier provided as argument.
	 * </p>
	 * <p>
	 * The method checks that the given <i>id</i> is at least the size of
	 * the bank guarantee request identifier, and if so it then extracts
	 * the prefix based on the first {@link ChannelResolverNamePrefixImpl#GX_PREFIX_LENGTH}
	 * characters to use for channel resolution.
	 * </p>
	 * 
	 * @param id 	a {@link String} representing the identifier of the bank
	 * 				guarantee request for which we need to retrieve the channel
	 * 				it belongs to {@literal null}.
	 * 
	 * @returns a {@link String} containing the name of the channel that
	 * 			is mapped by the given prefix identifier, or {@literal null}
	 * 			if it the identifier does not match the expected
	 * 
	 * 
	 * @throws IllegalArgumentException	if <i>id</i> is either {@literal null}
	 * 									or an empty string, or it does not map
	 * 									to an existing channel.
	 */
    @Override
    public String get(String id) {
    	
    	
    	if (id == null || id.isEmpty()) {
    		
    		throw new IllegalArgumentException("Channel prefix cannot be null or an empty string.");
    	}
    	
        // id does not belong to channel so return null
        if (id.length() < GX_REQUEST_ID_LENGTH) {
            return null;
        }
        
        return this.prefixToChannelName(id.substring(0, GX_PREFIX_LENGTH));
    }

    /**
     * This is an internal utility method that is used to asbtract away the use
     * of the channel resolver. It takes the prefix provided as argument and then
     * invokes the channel resolver to retrieve the corresponding instance of
     * {@link GxChannelMetadata}.
     * 
     * @param prefix	a {@link String} representing the bank guarantee identifier
     * 					prefix used in the channel. It is expected to not to be an
     * 					empty or {@literal null} string.
     * 
     * @return a {@link String} representing the channel name if there is a match.
     * 
     * @throws IllegalArgumentException	if the prefix is not valid or no channel is
     * 									found matching that prefix.
     */
    private String prefixToChannelName(String prefix) {
       
    	GxChannelMetadata metadata = this.provider.getChannelByPrefix(prefix);
    	
    	if (metadata == null) {

    		throw new IllegalArgumentException(String.format("Could not map prefix: %s", prefix));
    	}
    	
    	return metadata.getName();
    }
    
   
}
