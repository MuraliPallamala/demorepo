package com.ibm.au.bgx.core.chain;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.IdentityConfig;
import com.ibm.au.bgx.model.chain.ChannelSelector;
import com.ibm.au.bgx.model.chain.GxChain;
import com.ibm.au.bgx.model.exception.GuaranteeChainException;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.exception.GuaranteeNotFoundException;
import com.ibm.au.bgx.model.exception.GuaranteePreconditionFailsException;
import com.ibm.au.bgx.model.exception.ChainInitializationException;
import com.ibm.au.bgx.model.guarantee.GXAPI;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchResponse;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchResponse;

import java.text.ParseException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

/**
 * This implements methods to persist and retrieve records from chain
 *
 * @author Dain LIffman <dainliff@au1.ibm.com>
 */
@Component
@Primary
public class AdminGxChainImpl implements GxChain {


    @Autowired
    ChannelSelector selector;

    @Autowired
    BaseGxChain baseGxChain;


    @Autowired
    IdentityConfig identity;




    protected GXAPI getChain(String channelName) throws ChainInitializationException {
        GXAPI api;
        try {
            api = selector.getGuaranteeApi(identity.getFabricUser(), channelName);
        } catch (Exception e) {
            throw new ChainInitializationException("Could not initialize GX chain", e);
        }

        return api;
    }

    @Override
    public GxRequest startIssue(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeForbiddenException {
        try {
            return baseGxChain.startIssue(getChain(channelName), gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }

    }

    @Override
    public GxRequest startAmend(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeForbiddenException {
        try {
            return baseGxChain.startAmend(getChain(channelName), gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxRequest startCancel(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeForbiddenException {
        try {
            return baseGxChain.startCancel(getChain(channelName), gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxRequest startDemand(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeForbiddenException {
        try {
            return baseGxChain.startDemand(getChain(channelName), gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxRequest startPayWalk(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeForbiddenException {
        try {
            return baseGxChain.startPayWalk(getChain(channelName), gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxRequest startTransfer(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeForbiddenException {
        try {
            return baseGxChain.startTransfer(getChain(channelName), gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxRequest expire(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeForbiddenException, ParseException {
        try {
            return baseGxChain.expire(getChain(channelName), gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxAction actionApprove(String channelName, GxAction action)
        throws GuaranteeChainException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            return baseGxChain.actionApprove(getChain(channelName), action);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxAction actionCancel(String channelName, GxAction action)
        throws GuaranteeChainException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            return baseGxChain.actionCancel(getChain(channelName), action);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxAction actionRevoke(String channelName, GxAction action)
        throws GuaranteeChainException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            return baseGxChain.actionRevoke(getChain(channelName), action);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxAction actionReject(String channelName, GxAction action)
        throws GuaranteeChainException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            return baseGxChain.actionReject(getChain(channelName), action);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxAction actionDefer(String channelName, GxAction action)
        throws GuaranteeChainException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            return baseGxChain.actionDefer(getChain(channelName), action);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxAction actionRecallIssue(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallIssue(getChain(channelName), flowId, gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }

    }

    @Override
    public GxAction actionRecallAmend(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallAmend(getChain(channelName), flowId, gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }

    }

    @Override
    public GxAction actionRecallCancel(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallCancel(getChain(channelName), flowId, gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }

    }

    @Override
    public GxAction actionRecallDemand(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallDemand(getChain(channelName), flowId, gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }

    }

    @Override
    public GxAction actionRecallTransfer(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException {
        try {
            return baseGxChain.actionRecallTransfer(getChain(channelName), flowId, gxRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxSearchResponse search(String channelName, GxSearchRequest searchRequest)
        throws GuaranteeChainException, GuaranteeForbiddenException, ParseException {
        try {
            return baseGxChain.search(getChain(channelName), searchRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public Gx get(String channelName, String guaranteeId)
        throws GuaranteeChainException, GuaranteeForbiddenException, GuaranteeNotFoundException {
        try {
            return baseGxChain.get(getChain(channelName), guaranteeId);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxFlowsSearchResponse searchFlows(String channelName,
        GxFlowsSearchRequest flowsSearchRequest) throws GuaranteeChainException, GuaranteeForbiddenException {
        try {
            return baseGxChain.searchFlows(getChain(channelName), flowsSearchRequest);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public GxRequest getFlow(String channelName, String flowId)
        throws GuaranteeChainException, GuaranteeForbiddenException {
        try {
            return baseGxChain.getFlow(getChain(channelName), flowId);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

    @Override
    public List<GxAction> getFlowActions(String channelName, String flowId)
        throws GuaranteeChainException, GuaranteePreconditionFailsException, GuaranteeForbiddenException {
        try {
            return baseGxChain.getFlowActions(getChain(channelName), flowId);
        } catch (Exception e) {
            throw new GuaranteeChainException(e);
        }
    }

}
