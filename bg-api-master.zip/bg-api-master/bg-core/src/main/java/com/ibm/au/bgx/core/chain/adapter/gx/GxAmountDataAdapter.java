package com.ibm.au.bgx.core.chain.adapter.gx;

import com.ibm.au.bgx.core.chain.adapter.CurrencyDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxAmount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigInteger;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxAmountDataAdapter implements ChainDataAdapter<Gxs.GXAmount, GxAmount> {

    @Autowired
    CurrencyDataAdapter currencyDataAdapter;

    @Override
    public Gxs.GXAmount toOnChainModel(GxAmount input) {
        Gxs.GXAmount.Builder builder = Gxs.GXAmount.newBuilder();

        if (input.getCurrency() != null) {
            builder.setCurrency(currencyDataAdapter.toOnChainModel(input.getCurrency()));
        }

        if (input.getOutstanding() != null) {

            if (input.getOutstanding().compareTo(BigInteger.ZERO) <= 0) {
                throw new IllegalArgumentException(String.format("Gx outstanding amount %s cannot be zero or negative", input.getOutstanding()));
            }
            builder.setOutstanding(input.getOutstanding().longValue());
        }

        if (input.getDemanded() != null) {
            if (input.getDemanded().compareTo(BigInteger.ZERO) < 0) {
                throw new IllegalArgumentException(String.format("Gx demanded amount %s cannot be negative", input.getOutstanding()));
            }
            builder.setDemanded(input.getDemanded().longValue());
        }
        return builder.build();
    }

    @Override
    public GxAmount toOffchainModel(Gxs.GXAmount input) {
        GxAmount output = new GxAmount();
        output.setCurrency(currencyDataAdapter.toOffchainModel(input.getCurrency()));
        output.setOutstanding(BigInteger.valueOf(input.getOutstanding()));
        output.setDemanded(BigInteger.valueOf(input.getDemanded()));
        return output;
    }
}
