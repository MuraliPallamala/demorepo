package com.ibm.au.bgx.common.util;

import com.ibm.au.bgx.model.IdentityConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigInteger;

/**
 * This component provides specific 5 digit error codes depending on the type of API, error topic
 * and specific error code. The class provides an enumeration for topics as well as constants for
 * specific errors.
 *
 * @author Peter Ilfrich
 */
@Component
public class ErrorCodeUtil {

    // authentication errors
    public static final int AUTH_MISSING_TOKEN					= 0;
    public static final int AUTH_INVALID_TOKEN 					= 1;
    public static final int AUTH_DUPLICATE_SESSION 				= 2;

    // onboarding errors

    // org management errors

    // user management errors

    // bank guarantee errors
    public static final int NON_ACTIVE_APPROVED_REQUEST_ACTION 	= 0;
    public static final int NON_ACTIVE_CANCELLED_REQUEST_ACTION = 1;
    public static final int NON_ACTIVE_REJECTED_REQUEST_ACTION 	= 2;
    public static final int NON_ACTIVE_WITHDRAWN_REQUEST_ACTION = 3;
    public static final int NON_ACTIVE_EXPIRED_REQUEST_ACTION 	= 4;
    public static final int NON_ACTIVE_UNKNOWN_REQUEST_ACTION 	= 9;

    // prefixes for error codes
    private static final int ADMIN_PREFIX 						= 10000;
    private static final int NEWCO_PREFIX 						= 20000;
    private static final int ISSUER_PREFIX 						= 30000;
    private static final int ONBOARDING_PREFIX 					= 0;
    private static final int ORG_MANAGEMENT_PREFIX 				= 1000;
    private static final int USER_MANAGEMENT_PREFIX 			= 2000;
    private static final int BANK_GUARANTEE_PREFIX 				= 3000;
    private static final int LOGIN_PREFIX 						= 4000;
    
    private static IdentityConfig identityConfig;

    /**
     * Retrieves a computed 5 digit error code using the current API type (auto-wired), an error
     * topic and a (maximum) 3 digit error code for any specific error within a topic
     *
     * @param error     - the topic of the error (org management, user management, login, guarantee
     *                  management, onboarding, etc.)
     * @param errorCode - a specific error code (use constants provided in this class)
     * @return the full error code, which can be passed into the {@link com.ibm.au.bgx.model.api.exceptions.ApiException}.
     */
    public static BigInteger getPrefixedErrorCode(ErrorTopic error, int errorCode) {

        if (errorCode >= 1000) {
            throw new IllegalArgumentException("Cannot retrieve error code with base code greater than 3 digits.");
        }

        int topicPrefix = getTopicPrefix(error);

        if (identityConfig.isIssuer()) {
            return BigInteger.valueOf(ISSUER_PREFIX + topicPrefix + errorCode);
        }

        if (identityConfig.isNewCoAdmin()) {
            return BigInteger.valueOf(ADMIN_PREFIX + topicPrefix + errorCode);
        }

        return BigInteger.valueOf(NEWCO_PREFIX + topicPrefix + errorCode);
    }

    /**
     * Maps the error class to a number dividable by 1000, which is used to determine the 2nd digit
     * in the 5 digit error code.
     *
     * @param error - the error class provided in an exception
     * @return the topic prefix, which is a number dividable by 1000
     */
    protected static int getTopicPrefix(ErrorTopic error) {
        int topicPrefix;
        switch (error) {
            case ONBOARDING: {
                topicPrefix = ONBOARDING_PREFIX;
                break;
            }
            case ORG_MANAGEMENT: {
                topicPrefix = ORG_MANAGEMENT_PREFIX;
                break;
            }
            case USER_MANAGEMENT: {
                topicPrefix = USER_MANAGEMENT_PREFIX;
                break;
            }
            case BANK_GUARANTEE: {
                topicPrefix = BANK_GUARANTEE_PREFIX;
                break;
            }
            case LOGIN: {
                topicPrefix = LOGIN_PREFIX;
                break;
            }
            default: {
                throw new IllegalArgumentException("Invalid error state provided");
            }
        }

        return topicPrefix;
    }

    /**
     * Autowire method to connect the identity config to this component in order to figure out which
     * API type we're running. This will determine the first digit of the 5 digit error code.
     *
     * @param config - the initialised identity config of this API
     */
    @Autowired
    public void setIdentityConfig(IdentityConfig config) {
        ErrorCodeUtil.identityConfig = config;
    }

    /**
     * Enumeration providing error topics that can be mapped to their corresponding error code
     * prefix (the 2nd digit in the 5 digit error codes)
     */
    public enum ErrorTopic {
        ONBOARDING,
        ORG_MANAGEMENT,
        USER_MANAGEMENT,
        BANK_GUARANTEE,
        LOGIN,
    }
}
