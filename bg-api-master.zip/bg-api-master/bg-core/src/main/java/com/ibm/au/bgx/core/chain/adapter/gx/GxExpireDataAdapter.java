package com.ibm.au.bgx.core.chain.adapter.gx;

import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.flow.FlowStatusDataAdapter;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class GxExpireDataAdapter implements ChainDataAdapter<Gxs.GXExpireRequest, GxRequest> {

    @Autowired
    TimestampDataAdapter timestampDataAdapter;

    @Autowired
    FlowStatusDataAdapter flowStatusDataAdapter;

    @Override
    public Gxs.GXExpireRequest toOnChainModel(GxRequest input) {
        Gxs.GXExpireRequest.Builder builder = Gxs.GXExpireRequest.newBuilder()
                												 .setGxId(input.getGuaranteeId());

        if (input.getId() != null) {
            builder.setId(input.getId());
        }

        return builder.build();
    }

    @Override
    public GxRequest toOffchainModel(Gxs.GXExpireRequest input) {
    	
        GxRequest output = new GxRequest();
        output.setType(GxRequestType.EXPIRE);
        output.setId(input.getId());
        output.setStatus(this.flowStatusDataAdapter.toOffchainModel(input.getStatus()));
        output.setGuaranteeId(input.getGxId());
        output.setCreatedBy(input.getCreatedBy());
        output.setCreatedAt(this.timestampDataAdapter.toOffchainModel(input.getCreatedAt()));
        output.setUpdatedBy(input.getUpdatedBy());
        output.setUpdatedAt(this.timestampDataAdapter.toOffchainModel(input.getUpdatedAt()));
        return output;
    }
}
