package com.ibm.au.bgx.common.util.ssl;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.annotation.PostConstruct;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;

@Component
public class SSLUtils {

    /**
     * A {@link Logger} implementation that is used to record the messages that are produced by the
     * logic in this class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(SSLUtils.class);
    
    public static final String HTTPS_SCHEME = "https";

    public static final String GRPCS_SCHEME = "grpcs";

    @Value("${ssl.trusted.keystore.path:}")
    private String trustedCertsKeystorePath;

    @Value("${ssl.trusted.keystore.password:}")
    private String trustedCertsKeystorePassword;

    @Value("${ssl.client.keystore.path:}")
    private String clientCertsKeystorePath;

    @Value("${ssl.client.keystore.password:}")
    private String clientCertsKeystorePassword;


    private KeyStore cacerts = null;
    private KeyStore clientCerts = null;

    private TrustManagerFactory trustedManagerFactory;

    private KeyManagerFactory keyManagerFactory;
    
  
    protected String getTrustedCertsKeystorePath() {
        return trustedCertsKeystorePath;
    }

    protected void setTrustedCertsKeystorePath(String trustedCertsKeystorePath) {
        this.trustedCertsKeystorePath = trustedCertsKeystorePath;
    }

    protected String getTrustedCertsKeystorePassword() {
        return trustedCertsKeystorePassword;
    }

    protected void setTrustedCertsKeystorePassword(String trustedCertsKeystorePassword) {
        this.trustedCertsKeystorePassword = trustedCertsKeystorePassword;
    }

    protected String getClientCertsKeystorePath() {
        return clientCertsKeystorePath;
    }

    protected void setClientCertsKeystorePath(String clientCertsKeystorePath) {
        this.clientCertsKeystorePath = clientCertsKeystorePath;
    }

    protected String getClientCertsKeystorePassword() {
        return clientCertsKeystorePassword;
    }

    protected void setClientCertsKeystorePassword(String clientCertsKeystorePassword) {
        this.clientCertsKeystorePassword = clientCertsKeystorePassword;
    }
    
    
    public boolean isSSL(String uriString) throws URISyntaxException {
        
        return this.isSSL(new URI(uriString));
        
    }
    
    public boolean isSSL(URL url) throws URISyntaxException {
        
        return this.isSSL(url.toURI());
    }

    public boolean isSSL(URI uri) {

        return HTTPS_SCHEME.equals(uri.getScheme()) || GRPCS_SCHEME.equals(uri.getScheme());
    }

    
    public SSLConnectionSocketFactory getSSLConnectionSocketFactory() throws IOException {

        SSLConnectionSocketFactory sslConnectionSocketFactory = null;
        
        if (this.cacerts != null && this.clientCerts != null) {
            
        
            try {
            	
            	SSLContextBuilder builder = new SSLContextBuilder();
            	
            	
            	sslConnectionSocketFactory = new SSLConnectionSocketFactory(builder.loadTrustMaterial(this.cacerts, new TrustSelfSignedStrategy())
                                									  .loadKeyMaterial(this.clientCerts, this.clientCertsKeystorePassword.toCharArray())
                                									  .build());
               
            
            } catch (KeyManagementException | UnrecoverableKeyException | NoSuchAlgorithmException  | KeyStoreException e) {
                throw new IOException();
            }
            
        } else {
            
            try {
                
            
            SSLContextBuilder builder = new SSLContextBuilder();
            builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
            sslConnectionSocketFactory = new SSLConnectionSocketFactory(builder.build());
            
            } catch (KeyManagementException | NoSuchAlgorithmException  | KeyStoreException e) {
                throw new IOException();
            }

        }

        return sslConnectionSocketFactory;
    }

    public SSLSocketFactory getSSLSocketFactory() throws IOException {

       SSLSocketFactory sslSocketFactory = null;
                      
        if (this.trustedManagerFactory != null && this.keyManagerFactory != null) {
            try {
                SSLContext context = SSLContext.getInstance("TLS");
                
                context.init(this.keyManagerFactory.getKeyManagers(), this.trustedManagerFactory.getTrustManagers(), new SecureRandom());
                return context.getSocketFactory();
    
            } catch (NoSuchAlgorithmException | KeyManagementException e) {
                throw new IOException();
            }
        } else {
            sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
        }
        
        return sslSocketFactory;
    }


    private KeyStore getKeyStore(String keyStorePath, String keyStorePassword) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {

        KeyStore keystore = KeyStore.getInstance("JKS");
        keystore.load(new FileInputStream(keyStorePath), keyStorePassword.toCharArray());
        return keystore;
    }

    @PostConstruct
    protected void initializeFactories() {

        // Initialization of the truststore.
        //
        if (this.trustedCertsKeystorePath != null && !this.trustedCertsKeystorePath.isEmpty()) {
            try {
                this.cacerts = this.getKeyStore(this.trustedCertsKeystorePath, this.trustedCertsKeystorePassword);
                this.trustedManagerFactory = TrustManagerFactory.getInstance("SunX509", "SunJSSE");
                this.trustedManagerFactory.init(cacerts);
    
            } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException | NoSuchProviderException e) {
                
                if (LOGGER.isErrorEnabled()) {
                    
                    LOGGER.error(BgxLogMarkers.DEV, String.format("Could not initialize the trust manager (keystore path: %s).", this.trustedCertsKeystorePath), e);
                }
            }
        }
        
        if (this.clientCertsKeystorePath != null && !this.clientCertsKeystorePath.isEmpty()) {
            try {
                
                this.clientCerts = this.getKeyStore(this.clientCertsKeystorePath, this.clientCertsKeystorePassword);
                this.keyManagerFactory = KeyManagerFactory.getInstance("SunX509", "SunJSSE");
                this.keyManagerFactory.init(clientCerts, this.clientCertsKeystorePassword.toCharArray());
                
            } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException | NoSuchProviderException | UnrecoverableKeyException e) {
                
                if (LOGGER.isErrorEnabled()) {
                    
                    LOGGER.error(BgxLogMarkers.DEV, String.format("Could not initialize the client certificates manager (keystore path: %s).", this.clientCertsKeystorePath), e);
                }
            }
        }


    }

}
