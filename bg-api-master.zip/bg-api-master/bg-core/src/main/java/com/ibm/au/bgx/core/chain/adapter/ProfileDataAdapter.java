package com.ibm.au.bgx.core.chain.adapter;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.OrgProfile.Status;
import com.ibm.au.bgx.model.profile.Organizations.Organization;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationEntityType;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class ProfileDataAdapter implements ChainDataAdapter<Organization, OrgProfile> {

    @Autowired
    AddressDataAdapter addressAdapter;

    private static Map<Status, OrganizationStatus> toChainStatusMap;

    private static Map<OrganizationStatus, Status> fromChainStatusMap;

    private static Map<EntityType, OrganizationEntityType> toChainEntityTypeMap;

    private static Map<OrganizationEntityType, EntityType> fromChainEntityTypeMap;

    private static final Logger LOGGER = LoggerFactory.getLogger(ProfileDataAdapter.class);

    static {
        toChainStatusMap = new HashMap<>();
        toChainStatusMap.put(Status.ACTIVE, OrganizationStatus.ORGANIZATION_ACTIVE);
        toChainStatusMap.put(Status.INACTIVE, OrganizationStatus.ORGANIZATION_INACTIVE);

        // inverse the toChainStatusMap
        // this works because we have unique mapping
        fromChainStatusMap = toChainStatusMap
                .entrySet()
                .stream()
                .collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey));

        toChainEntityTypeMap = new HashMap<>();
        toChainEntityTypeMap.put(EntityType.APPLICANT_OR_BENEFICIARY,
                OrganizationEntityType.ORGANIZATION_APPLICANT_OR_BENEFICIARY);
        toChainEntityTypeMap.put(EntityType.ISSUER, OrganizationEntityType.ORGANIZATION_ISSUER);
        toChainEntityTypeMap
                .put(EntityType.CONSORTIUM, OrganizationEntityType.ORGANIZATION_CONSORTIUM);

        // inverse the toChainEntityTypeMap
        // this works because we have unique mapping
        fromChainEntityTypeMap = toChainEntityTypeMap
                .entrySet()
                .stream()
                .collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey));
    }

    @Override
    public Organization toOnChainModel(OrgProfile profile) {
        if (profile == null) {
            throw new IllegalArgumentException("Input organization profile cannot be null");
        }

        if (!toChainStatusMap.containsKey(profile.getStatus())) {
            throw new IllegalArgumentException(String
                    .format("Organization status '%s' cannot be mapped to on-chain status",
                            profile.getStatus().value()));
        }

        if (profile.getStatus() == null) {
            throw new IllegalArgumentException("Organization status '%s' cannot be null");
        }

        Organization organization = Organization.newBuilder()
                .setId(profile.getId())
                .setEntityName(profile.getEntityName())
                .setBusinessId(profile.getBusinessId())
                .setAddress(addressAdapter.toOnChainModel(profile.getEntityAddress()))
                .setStatus(toChainStatusMap.get(profile.getStatus()))
                // FIXME: check if this is the correct solution, or whether the portal should provide the entity type
                .setEntityType(profile.getEntityType() != null ? toChainEntityTypeMap.get(profile.getEntityType()) : OrganizationEntityType.ORGANIZATION_APPLICANT_OR_BENEFICIARY)
                .build();

        LOGGER.debug(BgxLogMarkers.DEV, String
                .format("Id: %s, Name: %s, BID: %s, Status: %s, Type: %s",
                        organization.getId(),
                        organization.getEntityName(),
                        organization.getBusinessId(),
                        organization.getStatus().getNumber(),
                        organization.getEntityType().getNumber()
                ));

        return organization;
    }

    @Override
    public OrgProfile toOffchainModel(Organization organization) {
        if (organization == null) {
            throw new IllegalArgumentException("Input on-chain organization record cannot be null");
        }

        if (!fromChainStatusMap.containsKey(organization.getStatus())) {
            throw new IllegalArgumentException(String
                    .format("On-chain organization status '%d' cannot be mapped to off-chain status",
                            organization.getStatus().getNumber()));
        }

        OrgProfile profile = new OrgProfile();
        profile.setId(organization.getId());
        profile.setEntityName(organization.getEntityName());
        profile.setBusinessId(organization.getBusinessId());
        profile.setEntityAddress(addressAdapter.toOffchainModel(organization.getAddress()));
        profile.setStatus(fromChainStatusMap.get(organization.getStatus()));
        profile.setEntityType(fromChainEntityTypeMap.get(organization.getEntityType()));

        return profile;
    }
}
