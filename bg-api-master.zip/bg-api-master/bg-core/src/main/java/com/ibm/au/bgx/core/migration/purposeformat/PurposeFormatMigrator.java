package com.ibm.au.bgx.core.migration.purposeformat;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.migration.AbstractMigrator;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.PostalAddress;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.approvalmodel.SharedApprovalModelActionType;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAmendPayload;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.gx.GxTransferPayload;
import com.ibm.au.bgx.model.pojo.legacy.gx.LegacyGx;
import com.ibm.au.bgx.model.pojo.legacy.gx.LegacyGxAmendPayload;
import com.ibm.au.bgx.model.pojo.legacy.gx.LegacyGxIssuePayload;
import com.ibm.au.bgx.model.pojo.legacy.gx.LegacyGxRentalPurpose;
import com.ibm.au.bgx.model.pojo.legacy.gx.LegacyGxTransferPayload;
import com.ibm.au.bgx.model.pojo.legacy.gx.LegacyGxType;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;
import com.ibm.au.bgx.model.purpose.PurposeFormatManager;
import com.ibm.au.bgx.model.repository.ApprovalModelFlowRequestRepository;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.util.JacksonUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class PurposeFormatMigrator extends AbstractMigrator {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();
    private static final Logger LOGGER = LoggerFactory.getLogger(PurposeFormatMigrator.class);

    private static final String MIGRATION_MARKER = ".purpose-migration";

    @Autowired
    protected GxRequestRepository gxRequestRepository;

    @Autowired
    protected ApprovalModelFlowRequestRepository approvalModelFlowRequestRepository;

    @Autowired
    protected PurposeFormatManager purposeFormatManager;

    @Value("${bgx.migration.purposeformat.legacyname:commercial-lease}")
    protected String newPurposeFormatName;


    protected Map<LegacyGxType, PurposeFormat> purposeFormatMapping;


    @Override
    public boolean check() {
        return this.checkForMigrationMarker(MIGRATION_MARKER);
    }

    @Override
    public void run() throws Exception {

        LOGGER.debug(BgxLogMarkers.DEV, "Running data migration for purpose format feature");
        this.populatePurposeFormatMapping();

        // handle GxRequests
        LOGGER.debug(BgxLogMarkers.DEV, " - Processing GxRequests");
        List<GxRequest> legacyGxRequests = gxRequestRepository.getAll();
        List<GxRequest> gxRequests = convertGxRequests(legacyGxRequests);


        // handle approval model requests
        LOGGER.debug(BgxLogMarkers.DEV, " - Processing ApprovalModelFlowRequests");
        List<ApprovalModelFlowRequest> legacyApprovalModelFlowRequests = approvalModelFlowRequestRepository
                .getAll();
        List<ApprovalModelFlowRequest> approvalModelFlowRequests = convertApprovalModelFlowRequests(
                legacyApprovalModelFlowRequests);

        // save updated requests in bulk
        updateGxRequests(gxRequests);
        updateApprovalModelFlowRequests(approvalModelFlowRequests);

        LOGGER.debug(BgxLogMarkers.DEV, " - Done migrating");
    }

    @Override
    public void cleanup() {
        this.deleteMigrationMarker(MIGRATION_MARKER);
    }

    protected void populatePurposeFormatMapping() {
        List<PurposeFormat> formats = purposeFormatManager.getAll(true);
        purposeFormatMapping = new HashMap<>();
        for (PurposeFormat format : formats) {
            if (format.getName().equals(newPurposeFormatName)) {
                purposeFormatMapping.put(LegacyGxType.COMMERCIAL_LEASE, format);
            }
        }

        if (purposeFormatMapping.size() == 0) {
            throw new IllegalStateException("Could not find purpose format for legacy commercial leases");
        }
    }


    private List<GxRequest> convertGxRequests(List<GxRequest> legacyGxRequests) {
        List<GxRequest> result = new ArrayList<>();
        for (GxRequest legacyReq : legacyGxRequests) {
            if (legacyReq.getModelVersion() == null && (legacyReq.getType().equals(GxRequestType.ISSUE)
                    || legacyReq.getType().equals(GxRequestType.AMEND)
                    || legacyReq.getType().equals(GxRequestType.TRANSFER))) {
                LOGGER.debug("Converting legacy GX request: {}", legacyReq.getId());
                result.add(convertGxRequest(legacyReq));
            }
        }

        return result;
    }

    private List<ApprovalModelFlowRequest> convertApprovalModelFlowRequests(
            List<ApprovalModelFlowRequest> legacyApprovalModelFlowRequests) {
        List<ApprovalModelFlowRequest> result = new ArrayList<>();
        for (ApprovalModelFlowRequest legacyReq : legacyApprovalModelFlowRequests) {
            if (legacyReq.getModelVersion() == null && (legacyReq.getType().equals(SharedApprovalModelActionType.START_ISSUE_GUARANTEE.toString())
                    || legacyReq.getType().equals(SharedApprovalModelActionType.START_AMEND_GUARANTEE.toString())
                    || legacyReq.getType().equals(SharedApprovalModelActionType.START_TRANSFER_GUARANTEE.toString()))) {

                LOGGER.debug("Converting legacy approval model request: {}", legacyReq.getId());
                result.add(convertApprovalModelFlowRequest(legacyReq));
            }
        }

        return result;
    }

    private void updateGxRequests(List<GxRequest> gxRequests) {
        LOGGER.debug(BgxLogMarkers.DEV, "Done migrating. Saving {} GxRequests", gxRequests.size());
        for (GxRequest gxRequest : gxRequests) {
            gxRequestRepository.updateItem(gxRequest);
        }
    }

    private void updateApprovalModelFlowRequests(List<ApprovalModelFlowRequest> approvalModelFlowRequests) {
        LOGGER.debug(BgxLogMarkers.DEV, "Done migrating. Saving {} ApprovalModelFlowRequest", approvalModelFlowRequests.size());
        for (ApprovalModelFlowRequest approvalModelFlowRequest : approvalModelFlowRequests) {
            approvalModelFlowRequestRepository.updateItem(approvalModelFlowRequest);
        }
    }

    private GxRequest convertGxRequest(GxRequest gxRequest) {
        if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
            // issue requests
            LegacyGxIssuePayload legacyPayload = MAPPER
                    .convertValue(gxRequest.getPayload(), LegacyGxIssuePayload.class);
            gxRequest.setPayload(this.convertGxIssuePayload(legacyPayload));

        } else if (gxRequest.getType().equals(GxRequestType.AMEND)) {
            // amend requests
            LegacyGxAmendPayload legacyPayload = MAPPER
                    .convertValue(gxRequest.getPayload(), LegacyGxAmendPayload.class);
            gxRequest.setPayload(this.convertGxAmendPayload(legacyPayload));

        } else if (gxRequest.getType().equals(GxRequestType.TRANSFER)) {
            // transfer requests
            LegacyGxTransferPayload legacyPayload = MAPPER
                    .convertValue(gxRequest.getPayload(), LegacyGxTransferPayload.class);
            gxRequest.setPayload(this.convertGxTransferPayload(legacyPayload));
        }
        gxRequest.setModelVersion("1.0.0");
        return gxRequest;
    }

    private ApprovalModelFlowRequest convertApprovalModelFlowRequest(
            ApprovalModelFlowRequest approvalModelFlowRequest) {

        // Update payload
        GxRequest legacyPayload = MAPPER
                .convertValue(approvalModelFlowRequest.getPayload(), GxRequest.class);
        if (legacyPayload != null && legacyPayload.getType() != null) {
            GxRequest payload = convertGxRequest(legacyPayload);
            Map<String, Object> payloadMap = MAPPER.convertValue(payload, Map.class);
            approvalModelFlowRequest.setPayload(payloadMap);

            // Update first action
            LOGGER.debug("Processing GxRequest for approval model: {}", approvalModelFlowRequest.getId());
            try {
                LOGGER.debug("Converting first action payload of {}: {}", approvalModelFlowRequest.getId(), approvalModelFlowRequest.getActions().get(0).getPayload());
                GxRequest legacyAction = MAPPER
                        .convertValue(approvalModelFlowRequest.getActions().get(0).getPayload(), GxRequest.class);
                GxRequest action = convertGxRequest(legacyAction);
                Map<String, Object> actionMap = MAPPER.convertValue(action, Map.class);
                approvalModelFlowRequest.getActions().get(0).setPayload(actionMap);
            } catch (IllegalArgumentException e) {
                try {
                    LOGGER.debug("Could not load action into payload: {}", MAPPER.writeValueAsString(approvalModelFlowRequest.getActions().get(0)));
                } catch (JsonProcessingException jpe) {
                    // shouldn't happen
                }
                throw new IllegalArgumentException(e);
            }

        }
        approvalModelFlowRequest.setModelVersion("1.0.0");
        return approvalModelFlowRequest;
    }

    private GxIssuePayload convertGxIssuePayload(LegacyGxIssuePayload legacyPayload) {
        if (!purposeFormatMapping.containsKey(legacyPayload.getType())) {
            throw new IllegalStateException("Found a legacy GX issue request with invalid purpose type");
        }

        GxIssuePayload payload = new GxIssuePayload();
        payload.setId(legacyPayload.getId());
        payload.setActiveRequests(legacyPayload.getActiveRequests());
        payload.setOffchainCreatedAt(legacyPayload.getOffchainCreatedAt());
        payload.setPurposeType(purposeFormatMapping.get(legacyPayload.getType()).getId());
        payload.setApplicants(legacyPayload.getApplicants());
        payload.setBeneficiaries(legacyPayload.getBeneficiaries());
        payload.setIssuer(legacyPayload.getIssuer());
        payload.setStatus(legacyPayload.getStatus());
        payload.setAmount(legacyPayload.getAmount());
        payload.setBankReference(legacyPayload.getBankReference());
        payload.setExpiresAt(legacyPayload.getExpiresAt());
        payload.setTcId(legacyPayload.getTcId());
        payload.setIssuedAt(legacyPayload.getIssuedAt());
        payload.setUpdatedAt(legacyPayload.getUpdatedAt());
        payload.setPrevGxId(legacyPayload.getPrevGxId());
        payload.setOnchainActiveRequests(legacyPayload.getOnchainActiveRequests());

        payload.setPurpose(this.migratePurpose(legacyPayload.getPurpose()));

        return payload;
    }

    private GxTransferPayload convertGxTransferPayload(LegacyGxTransferPayload legacyPayload) {
        GxTransferPayload payload = new GxTransferPayload();

        payload.setBeneficiaries(legacyPayload.getBeneficiaries());
        payload.setReason(legacyPayload.getReason());
        payload.setNewGuaranteeId(legacyPayload.getNewGuaranteeId());
        payload.setGx(this.convertGx(legacyPayload.getGx()));

        return payload;
    }

    private Gx convertGx(LegacyGx oldGx) {
        if (!purposeFormatMapping.containsKey(oldGx.getType())) {
            throw new IllegalStateException("Found a legacy Gx (transfer) request with invalid purpose type");
        }
        Gx gx = new Gx();

        gx.setId(oldGx.getId());
        gx.setActiveRequests(oldGx.getActiveRequests());
        gx.setPurposeType(purposeFormatMapping.get(oldGx.getType()).getId());
        gx.setApplicants(oldGx.getApplicants());
        gx.setBeneficiaries(oldGx.getBeneficiaries());
        gx.setIssuer(oldGx.getIssuer());
        gx.setStatus(oldGx.getStatus());
        gx.setAmount(oldGx.getAmount());
        gx.setBankReference(oldGx.getBankReference());
        gx.setExpiresAt(oldGx.getExpiresAt());
        gx.setTcId(oldGx.getTcId());
        gx.setIssuedAt(oldGx.getIssuedAt());
        gx.setUpdatedAt(oldGx.getUpdatedAt());
        gx.setPrevGxId(oldGx.getPrevGxId());
        gx.setOnchainActiveRequests(oldGx.getOnchainActiveRequests());

        gx.setPurpose(this.migratePurpose(oldGx.getPurpose()));

        return gx;
    }

    private GxAmendPayload convertGxAmendPayload(LegacyGxAmendPayload legacyPayload) {

        GxAmendPayload payload = new GxAmendPayload();

        payload.setPurpose(this.migratePurpose(MAPPER.convertValue(legacyPayload.getPurpose(), LegacyGxRentalPurpose.class)));
        payload.setAmount(legacyPayload.getAmount());
        payload.setExpiresAt(legacyPayload.getExpiresAt());
        payload.setExpiresAtOpenEnded(legacyPayload.getExpiresAtOpenEnded());

        return payload;
    }


    protected Map<String, Object> migratePurpose(LegacyGxRentalPurpose purpose) {
        Map<String, Object> result = new HashMap<>();

        if (purpose == null) {
            return null;
        }

        // handle prop details
        Map<String, Object> propDetails = new HashMap<>();
        if (purpose.getPropertyName() != null) {
            propDetails.put("propertyName", purpose.getPropertyName());
        }
        if (purpose.getShopNumber() != null) {
            propDetails.put("shopNumber", purpose.getShopNumber());
        }
        if (propDetails.size() > 0) {
            result.put("propertyDetails", propDetails);
        }

        // handle address
        PostalAddress address = purpose.getAddress();
        Map<String, Object> addressMap = new HashMap<>();
        if (address != null) {
            if (address.getStreetAddress() != null) {
                addressMap.put("addressStreet", address.getStreetAddress());
            }
            if (address.getAddressLocality() != null) {
                addressMap.put("addressSuburb", address.getAddressLocality());
            }
            if (address.getPostalCode() != null) {
                addressMap.put("addressPostcode", address.getPostalCode());
            }
            if (address.getAddressRegion() != null) {
                addressMap.put("addressState", address.getAddressRegion());
            }
            if (address.getAddressCountry() != null) {
                addressMap.put("addressCountry", address.getAddressCountry());
            }
            if (addressMap.size() > 0) {
                result.put("propertyAddress", addressMap);
            }
        }

        // handle optional comment
        if (purpose.getFreeFormText() != null) {
            Map<String, Object> purposeMap = new HashMap<>();
            purposeMap.put("comment", purpose.getFreeFormText());
            result.put("purpose", purposeMap);
        }

        return result;
    }

}
