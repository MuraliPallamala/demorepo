package com.ibm.au.bgx.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.slf4j.Logger;

/**
 * Class <b>TraceUtil</b>. A simple utility class that traces objects by
 * converting them into JSON documents and writing them into the log.
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
public class TraceUtil {

    /**
     * A {@link ObjectMapper} that is used convert user profile information and
     * other entities into JSON documents.
     */
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();
    
    /**
     * Private constructor declared to prevent instantiation of instances
     * of a class that has only static methods.
     */
    private TraceUtil() {
    	
    }

    /**
     * Traces an object with the given target logger by converting it into its
     * JSON representation.
     *
     * @param target   a {@link Logger} object that is used to log the instance. It
     *                 is expected to not to be {@literal null}.
     * @param message  a {@link String} containing the format message to use for the
     *                 trace log.
     * @param instance a {@link Object}. It is expectd to not to be {@literal null}.
     */
    public static void trace(Logger target, String message, Object instance) {

        if (target.isDebugEnabled()) {
            try {

                String json = MAPPER.writeValueAsString(instance);
                target.debug(message == null ? json : String.format(message, json));

            } catch (JsonProcessingException e) {
                target.error("Could not serialize instance", e);
            }
        }
    }

}
