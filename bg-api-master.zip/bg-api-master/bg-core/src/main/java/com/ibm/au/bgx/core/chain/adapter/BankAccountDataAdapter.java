package com.ibm.au.bgx.core.chain.adapter;

import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.pojo.BankAccount;
import com.ibm.au.bgx.model.shared.Common;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
@Component
public class BankAccountDataAdapter implements ChainDataAdapter<Common.BankAccount, BankAccount> {


    @Autowired
    BankAccountTypeDataAdapter bankAccountTypeDataAdapter;

    @Override
    public Common.BankAccount toOnChainModel(BankAccount input) {
        Common.BankAccount.Builder builder = Common.BankAccount.newBuilder();

        if (input.getType() != null) {
            builder.setType(bankAccountTypeDataAdapter.toOnChainModel(input.getType()));
        }

        if (input.getAccountNumber() != null) {
            builder.setAccountNumber(input.getAccountNumber());
        }

        if (input.getDescription() != null) {
            builder.setDescription(input.getDescription());
        }

        return builder.build();
    }

    @Override
    public BankAccount toOffchainModel(Common.BankAccount input) {
        BankAccount output = new BankAccount();
        output.setType(bankAccountTypeDataAdapter.toOffchainModel(input.getType()));
        output.setAccountNumber(input.getAccountNumber());
        output.setDescription(input.getDescription());
        return output;
    }
}
