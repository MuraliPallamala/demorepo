package com.ibm.au.bgx.core.chain.adapter.gx;

import com.google.protobuf.StringValue;
import com.ibm.au.bgx.model.chain.ChainDataAdapter;
import com.ibm.au.bgx.model.guarantee.Gxs.GXAmendAddress;
import com.ibm.au.bgx.model.pojo.PostalAddress;
import org.springframework.stereotype.Component;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@Component
public class GxAmendAddressDataAdapter implements ChainDataAdapter<GXAmendAddress, PostalAddress> {

    @Override
    public GXAmendAddress toOnChainModel(PostalAddress postalAddress) {
        GXAmendAddress.Builder builder = GXAmendAddress.newBuilder();

        if (postalAddress.getStreetAddress() != null) {
            builder.setStreetAddress(
                StringValue.newBuilder().setValue(postalAddress.getStreetAddress()).build());
        }

        if (postalAddress.getAddressLocality() != null) {
            builder.setAddressLocality(
                StringValue.newBuilder().setValue(postalAddress.getAddressLocality()).build());
        }

        if (postalAddress.getAddressRegion() != null) {
            builder.setAddressRegion(
                StringValue.newBuilder().setValue(postalAddress.getAddressRegion()).build());
        }

        if (postalAddress.getAddressCountry() != null) {
            builder.setAddressCountry(
                StringValue.newBuilder().setValue(postalAddress.getAddressCountry()).build());
        }

        if (postalAddress.getPostalCode() != null) {
            builder.setPostalCode(
                StringValue.newBuilder().setValue(postalAddress.getPostalCode()).build());
        }

        if (postalAddress.getPostOfficeBoxNumber() != null) {
            builder.setPostOfficeBoxNumber(
                StringValue.newBuilder().setValue(postalAddress.getPostOfficeBoxNumber()).build());
        }

        return builder.build();
    }

    @Override
    public PostalAddress toOffchainModel(GXAmendAddress address) {
        PostalAddress postalAddress = new PostalAddress();
        // NOTE Do not change any of these to .equals, we need to compare against the exact object
        if (address.getStreetAddress() != address.getStreetAddress().getDefaultInstanceForType()) {
            postalAddress.setStreetAddress(address.getStreetAddress().getValue());
        }
        if (address.getAddressLocality() != address.getAddressLocality()
            .getDefaultInstanceForType()) {
            postalAddress.setAddressLocality(address.getAddressLocality().getValue());
        }
        if (address.getAddressRegion() != address.getAddressRegion().getDefaultInstanceForType()) {
            postalAddress.setAddressRegion(address.getAddressRegion().getValue());
        }
        if (address.getAddressCountry() != address.getAddressCountry()
            .getDefaultInstanceForType()) {
            postalAddress.setAddressCountry(address.getAddressCountry().getValue());
        }
        if (address.getPostalCode() != address.getPostalCode().getDefaultInstanceForType()) {
            postalAddress.setPostalCode(address.getPostalCode().getValue());
        }
        if (address.getPostOfficeBoxNumber() != address.getPostOfficeBoxNumber()
            .getDefaultInstanceForType()) {
            postalAddress.setPostOfficeBoxNumber(address.getPostOfficeBoxNumber().getValue());
        }

        return postalAddress;
    }
}
