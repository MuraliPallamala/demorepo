package com.ibm.au.bgx.core.approvalmodel;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.core.ChannelResolverNamePrefixImpl;
import com.ibm.au.bgx.core.util.GxUtil;
import com.ibm.au.bgx.model.AbstractPrincipalProvider;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.SystemActionsManager;
import com.ibm.au.bgx.model.api.GxPrefillClient;
import com.ibm.au.bgx.model.approvalmodel.ApprovalModel;
import com.ibm.au.bgx.model.exception.ApprovalModelForbiddenException;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.exception.GuaranteeException;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelActionInfo;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowResponse;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.pojo.approvalmodel.SharedApprovalModelActionType;
import com.ibm.au.bgx.model.pojo.chain.FlowStatus;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxActionApprovePayload;
import com.ibm.au.bgx.model.pojo.gx.GxActionType;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequestType;
import com.ibm.au.bgx.model.pojo.system.SystemActionRequest;
import com.ibm.au.bgx.model.pojo.system.SystemActionResponse;
import com.ibm.au.bgx.model.pojo.system.SystemActionType;
import com.ibm.au.bgx.model.repository.ApprovalModelFlowRequestRepository;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 
 *
 */
// TODO refactor so that APPROVAL_FLOW_<CANCEL, RECALL, REJECT> are explicit actions
public abstract class AbstractApprovalModel extends AbstractPrincipalProvider implements ApprovalModel {

	/**
	 * A {@link Logger} implementation that is used to collect all the log messages produced by instances
	 * of this class.
	 */
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractApprovalModel.class);

    /**
     * 
     */
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    /**
     * 
     */
    private static final String ANY_ROLE = "*";

    /**
     * 
     */
    @Autowired
    private ApprovalModelFlowRequestRepository repository;

    /**
     * 
     */
    @Autowired
    private GxRequestRepository gxRequestRepository;

    /**
     * 
     */
    @Autowired
    private SystemActionsManager systemActionsManager;

    /**
     * 
     */
    @Autowired
    private GxLimitValidator gxLimitValidator;

    /**
     * 
     */
    @Autowired
    private ChannelResolverNamePrefixImpl gxChannelResolver;

    /**
     * 
     */
    @Autowired
    private GxPrefillClient gxPrefillClient;

    /**
     * 
     */
    @Autowired
    private GxUtil gxUtil;

    /**
     * 
     * @param principal
     */
    public AbstractApprovalModel(BgxPrincipal principal) {
        super(principal);
    }

    /**
     * 
     */
    @Override
    public ApprovalModelFlowResponse performAction(ApprovalModelFlowRequest request) throws IOException {
    	
        ApprovalModelActionInfo currentActionInfo;
        ApprovalModelFlowRequest flow;

        SharedApprovalModelActionType actionType = null;
        try {
            actionType = SharedApprovalModelActionType.fromValue(request.getType());
        } catch (IllegalArgumentException e) {
            // Unknown actions cannot be special approval model types
        }

        // Generate ID for request/action
        request.setId(UUID.randomUUID().toString());

        LOGGER.debug(BgxLogMarkers.DEV,
        			 "Processing new flow request: {} with principal (Acting on behalf: {}, Org: {})",
        			 request,
        			 getPrincipal().isActingOnBehalf(),
        			 getPrincipal().getConfiguredForOrgId());

        request.setAuthoredBy(this.getPrincipal().getUserProfile().getId());
        request.setCreatedBy(this.getPrincipal().getConfiguredForOrgId());
        request.setCreatedAt(Instant.now());

        if (!this.getPrincipal()
                 .getUserProfile()
                 .getUserRoles()
                 .containsKey(this.getPrincipal().getConfiguredForOrgId())) {

            throw new ApprovalModelForbiddenException(String.format("User does not have roles for org %s to perform the operation.", this.getPrincipal().getConfiguredForOrgId()), null);
        }

        boolean hasParent = request.getFlowId() != null && !request.getFlowId().equals("");

        if (!hasParent) {
            // Requests with no parent
            currentActionInfo = getApprovalModelActionInfo(request.getType());

            this.validateParentFlowActionRequest(request, currentActionInfo);

            LOGGER.debug("Creating new approval model flow request");
            flow = new ApprovalModelFlowRequest();
            // set masterFlowId for approval model request

            flow.setAuthoredBy(request.getAuthoredBy());
            flow.setGxRequestId(request.getGxRequestId());
            flow.setGuaranteeId(request.getGuaranteeId());
            flow.setPayload(request.getPayload());
            flow.setType(request.getType());
            if (currentActionInfo.getNextAction() == null) {
                flow.setStatus(FlowStatus.APPROVED);
            } else {
                flow.setStatus(FlowStatus.ACTIVE);
            }
            flow.setVisibleToOrgIds(Collections.singletonList(getPrincipal().getConfiguredForOrgId()));
            flow.setInvolvedOrgIds(Collections.singletonList(getPrincipal().getConfiguredForOrgId()));
            flow.setCreatedBy(request.getCreatedBy());
            flow.setCreatedAt(request.getCreatedAt());
            List<ApprovalModelFlowRequest> actions = new ArrayList<>();
            actions.add(request);
            flow.setActions(actions);
            
        } else {
        	
            // Requests with a parent
            LOGGER.debug("Action against existing flow {}", request.getFlowId());
            flow = repository.getItem(request.getFlowId());
            currentActionInfo = getApprovalModelActionInfo(flow);

            this.validateChildFlowActionRequest(request, currentActionInfo, flow);

            if (request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL.value())) {
            	
                flow.setStatus(FlowStatus.CANCELLED);
            
            } else if (request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_REJECT.value())) {
            
            	flow.setStatus(FlowStatus.REJECTED);
            
            } else if (currentActionInfo.getNextAction() == null) {
            
            	flow.setStatus(FlowStatus.APPROVED);
            
            } else {
                flow.setStatus(FlowStatus.ACTIVE);
            }

            List<ApprovalModelFlowRequest> actions = flow.getActions();
            actions.add(request);
            flow.setActions(actions);
        }

        ApprovalModelFlowResponse flowResponse = new ApprovalModelFlowResponse();
        flowResponse.setId(flow.getId());
        flowResponse.setStatus(flow.getStatus());
        flowResponse.setGxRequestId(flow.getGxRequestId());
        flowResponse.setActions(flow.getActions());
        flowResponse.setNextAction(currentActionInfo.getNextAction());
        flowResponse.setPayload(flow.getPayload());

        // Copy the meta from the request, particularly BgxConstants.META_TARGET_ORG_ID.
        // Should we only copy selectively? Currently we copy as it is to be able to propagate
        // system internal data to subsequent request handling
        flowResponse.setMeta(request.getMeta());

        String flowString = MAPPER.writeValueAsString(flow);
        LOGGER.debug("Perform flow action. Flow: {}", flowString);

        // Process offchain GX request
        this.processTemporaryOffchainGxRequest(currentActionInfo, request, flow, actionType, hasParent);

        // Execute system jobs
        List<SystemActionResponse> systemActionResponses = this.triggerSystemJobs(flowResponse, flow, request, currentActionInfo);
        flowResponse.setSystemActionResponses(systemActionResponses);

        // Delete payload for non-active requests
        if (!flow.getStatus().equals(FlowStatus.ACTIVE)) {
            ApprovalModelUtil.deleteGxReqPayloads(flow);
        }

        // Update Approval Model Requests, note this is done after triggerSystemJobs and updating offchain requests, to avoid adding/removing requests that fail
        if (!hasParent) {
            this.repository.addItem(flow);
        } else {
            this.repository.updateItem(flow);
        }

        return flowResponse;
    }

    /**
     * 
     */
    @Override
    public ApprovalModelFlowRequest getApprovalFlow(String flowId) {
        return this.repository.getItem(flowId);
    }


    /**
     * 
     */
    @Override
    public List<ApprovalModelFlowRequest> getApprovalFlows(String gxRequestId, String gxId, FlowStatus status) {
    	
        if (this.getPrincipal()
        		.getOrganization()
        		.getProfile()
        		.getEntityType()
        		.equals(OrgProfile.EntityType.APPLICANT_OR_BENEFICIARY)) {
        	
            return this.repository.find(getPrincipal().getConfiguredForOrgId(), gxRequestId, gxId, status);
        }
        return this.repository.find(null, gxRequestId, gxId, status);
    }

    /**
     * 
     * @param request
     * @param currentActionInfo
     */
    private void validateParentFlowActionRequest(ApprovalModelFlowRequest request, ApprovalModelActionInfo currentActionInfo) {

        this.validateCommonFlowActionRequest(request, currentActionInfo);

        // validate GxLimit
        if (!this.gxLimitValidator.validateGxLimit(this.getPrincipal(), request)) {
        	
            throw new GuaranteeForbiddenException(String.format("User has insufficient Gxlimit privileges to perform this request: %s", request.getType()));
        }
    }
    
    /**
     * 
     * @param action
     * @param currentActionInfo
     * @param parentFlow
     */
    private void validateChildFlowActionRequest(ApprovalModelFlowRequest action, ApprovalModelActionInfo currentActionInfo, ApprovalModelFlowRequest parentFlow) {
        
    	this.validateCommonFlowActionRequest(action, currentActionInfo);

        if (!parentFlow.getStatus().equals(FlowStatus.ACTIVE)) {
            throw new ApprovalModelForbiddenException("Flow is not active");
        }

        // Ensures initiator and approver can't be the same user for approving
        if (action.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_APPROVE.value()) &&
            action.getAuthoredBy().equals(parentFlow.getAuthoredBy())) {
        	
            throw new ApprovalModelForbiddenException(String.format("User created original request, and so cannot perform %s", action.getType()));
        }

        // validates action type is valid
        if (
            !action.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_REJECT.value()) &&
            !action.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL.value()) &&
            !action.getType().equals(currentActionInfo.getActionName())
        ) {
            throw new ApprovalModelForbiddenException(String.format("Unexpected action of type %s, expected an internal action or %s", 
            														action.getType(), 
            														currentActionInfo.getActionName())
            										 );
        }

        if (!this.gxLimitValidator.validateGxLimit(this.getPrincipal(), parentFlow)) {
        	
            throw new GuaranteeForbiddenException(String.format("User has insufficient Gxlimit privileges to perform this action: %s on parent : %s", 
            													action.getType(), 
            													parentFlow.getType())
            									 );
        }
    }

    /**
     * Validate {@link ApprovalModelFlowRequest}
     *
     * @throws IllegalArgumentException if there is any argument validation error
     * @throws GuaranteeForbiddenException if GxLimit is not allowed
     * @throws ApprovalModelForbiddenException if approval model request cannot be made due to
     * privilege/flow issues
     * @throws GuaranteeException for miscellaneous Guarantee errors
     */
    private void validateCommonFlowActionRequest(ApprovalModelFlowRequest actionRequest, ApprovalModelActionInfo currentActionInfo) {

        List<String> upRoles = this.getPrincipal()
        						   .getUserProfile()
        						   .getUserRoles()
        						   .get(this.getPrincipal().getConfiguredForOrgId());

        if (!actionRequest.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_REJECT.value()) &&
            !actionRequest.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL.value())) {
        	
            // Non-Approve internal actions are allowed by any role currently

            // Checks whether user is of allowed roles
            this.ensureHasRequiredRoles(currentActionInfo, upRoles);
        }

        // Checks whether user has role USER
        if (!upRoles.contains(BgxConstants.ROLE_USER)) {
            throw new ApprovalModelForbiddenException("Logged in user does not have role USER", null);
        }
    }

    /**
     * 
     * @param flowResponse
     * @param flow
     * @param request
     * @param currentActionInfo
     * @return
     */
    private List<SystemActionResponse> triggerSystemJobs(ApprovalModelFlowResponse flowResponse, ApprovalModelFlowRequest flow, ApprovalModelFlowRequest request, ApprovalModelActionInfo currentActionInfo) {

        SharedApprovalModelActionType actionType = null;
        try {
            actionType = SharedApprovalModelActionType.fromValue(request.getType());
        } catch (IllegalArgumentException e) {
            // do nothing
        }

        // trigger special system actions for approval model reject
        SharedApprovalModelActionType flowType = null;
        try {
            flowType = SharedApprovalModelActionType.fromValue(flow.getType());
        } catch (IllegalArgumentException e) {
            // do nothing
        }

        Object systemActionPayload = null;
        if (
        	actionType != null && 
            actionType.equals(SharedApprovalModelActionType.APPROVAL_FLOW_REJECT) && 
        	flowType != null && 
        	ApprovalModelUtil.nonApproveApprovalModelTypes.contains(actionType) && 
        	ApprovalModelUtil.gxApproveActionTypes.contains(flowType)
        ) {
            // Perform system action rejection upon rejecting an approval
            SystemActionType reject = SystemActionType.REJECT_ISSUE_GUARANTEE;
            switch (flowType) {
                case APPROVE_ISSUE_GUARANTEE:
                    reject = SystemActionType.REJECT_ISSUE_GUARANTEE;
                    break;
                case APPROVE_AMEND_GUARANTEE:
                    reject = SystemActionType.REJECT_AMEND_GUARANTEE;
                    break;
                case APPROVE_CANCEL_GUARANTEE:
                    reject = SystemActionType.REJECT_CANCEL_GUARANTEE;
                    break;
                case APPROVE_DEMAND_GUARANTEE:
                    reject = SystemActionType.REJECT_DEMAND_GUARANTEE;
                    break;
                case APPROVE_TRANSFER_GUARANTEE:
                    reject = SystemActionType.REJECT_TRANSFER_GUARANTEE;
                    break;
                default:
                    // do nothing
            }
            
            List<SystemActionType> systemActions = Collections.singletonList(reject);
            flowResponse.setSystemActions(systemActions);

            // Use reject payload
            systemActionPayload = request.getPayload();
            
        } else if (actionType != null && 
        		   !ApprovalModelUtil.nonApproveApprovalModelTypes.contains(actionType)) {
        	
            // ApprovalModelUtil.nonApproveApprovalModelTypes system actions are currently not handled correctly so they must be ignored
            flowResponse.setSystemActions(currentActionInfo.getSystemActions());
            systemActionPayload = flowResponse.getPayload();
        }

        List<SystemActionResponse> systemActionResponses = new ArrayList<>();

        for (SystemActionType systemActionType : flowResponse.getSystemActions()) {
            SystemActionRequest systemActionRequest = new SystemActionRequest();
            systemActionRequest.setType(systemActionType);
            systemActionRequest.setPrincipal(this.getPrincipal());
            systemActionRequest.setPayload(systemActionPayload);
            systemActionRequest.setMeta(flowResponse.getMeta());
            SystemActionResponse systemActionResponse = systemActionsManager.run(systemActionRequest);
            systemActionResponses.add(systemActionResponse);

            // Map<String, Object> auditData = new HashMap<>();

            // TODO: pass resp.getPayload() as payload into the audit data (we should parse it already to GxRequest or GxActionRequest)
            // TODO: should not log audit event here as it logs it inside the SystemActionsManagerImpl
            // auditManager.logAuditEvent(systemActionType, this.getPrincipal(), auditData);
        }

        return systemActionResponses;
    }


    /**
     * 
     * @param currentActionInfo
     * @param request
     * @param flow
     * @param actionType
     * @param hasParent
     */
    // TODO move out of this class, implementation should be cleaned up too
    @SuppressWarnings("unchecked")
	private void processTemporaryOffchainGxRequest(ApprovalModelActionInfo currentActionInfo, 
												   ApprovalModelFlowRequest request, 
												   ApprovalModelFlowRequest flow, 
												   SharedApprovalModelActionType actionType, 
												   boolean hasParent) {

        // If cancelling or rejecting approval model request Close temporary GxRequests created by approval model request
        if (request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_REJECT.value()) ||
            request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL.value())
        ) {
            SharedApprovalModelActionType flowType = null;
            try {
                flowType = SharedApprovalModelActionType.fromValue(flow.getType());
            } catch (IllegalArgumentException e) {
                // Unknown actions are assumed to not be gx related
            }
            if (flowType != null && ApprovalModelUtil.gxRequestTypes.contains(flowType)) {
            	
                GxRequest gxRequest = MAPPER.convertValue(flow.getPayload(), GxRequest.class);
                
                if (request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_REJECT.value())) {
                
                	gxRequest.setStatus(FlowStatus.REJECTED);
                
                } else if (request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL.value())) {
                    
                	gxRequest.setStatus(FlowStatus.CANCELLED);
                }

                this.gxRequestRepository.updateItem(gxRequest);

                // Alert issuer that Request has been rejected
                List<GxAction> gxActions = this.getPrincipal()
                							   .getGxManager()
                							   .getFlowActions(gxRequest.getId());
                
                if (!gxActions.isEmpty() && 
                	gxActions.get(0).getType().equals(GxActionType.PREFILL)) {
                	
                    LOGGER.debug(BgxLogMarkers.DEV, "Alerting issuer to prefill Rejection (request ID: {})", gxRequest.getId());
                    
                    GxAction prefill = gxActions.get(0);
                    GxAction reject = new GxAction();
                    reject.setType(GxActionType.REJECT);
                    reject.setId(UUID.randomUUID().toString());
                    reject.setGxRequestId(gxRequest.getId());
                    reject.setCreatedBy(getPrincipal().getConfiguredForOrgId());
                    reject.setCreatedAt(Instant.now());

                    try {
                    	
                        this.gxPrefillClient.sendOffchainGxActionNotification(prefill.getCreatedBy(), reject);
                    
                    } catch (Exception e) {
                        
                    	throw new GuaranteeException("Failed to alert issuer to prefill rejection", e);
                    }
                }

            }

        }

        // Insert "Fake" Guarantee Request for first step of multi-step flows
        if (
        	!hasParent && 
        	currentActionInfo.getNextAction() != null && 
        	actionType != null && 
        	ApprovalModelUtil.gxRequestTypes.contains(actionType)
        ) {
        	
            GxRequest gxRequest = MAPPER.convertValue(request.getPayload(), GxRequest.class);
            gxRequest.setVisibleToOrgIds(Arrays.asList(getPrincipal().getConfiguredForOrgId()));
            gxRequest.setVisibleToChannelUsernames(gxUtil.getVisibleToChannelUsernames(gxRequest));
            gxRequest.setStatus(FlowStatus.ACTIVE);
            gxRequest.setId(flow.getGxRequestId());
            gxRequest.setCreatedAt(flow.getCreatedAt());

            // Set Involved Orgs
            Gx gx = null;
            if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
            	
                gx = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
            
            } else {
            
            	gx = this.getPrincipal().getGxManager().get(gxRequest.getGuaranteeId());
            }
            flow.setInvolvedOrgIds(GxUtil.getInvolvedOrgIdsForGxRequest(gxRequest, gx));

            // Set createdBy of gxRequest
            if (ApprovalModelUtil.gxPrefillTypes.contains(actionType)) {
                // createdBy is applicant for prefill
                gxRequest.setCreatedBy(gx.getApplicants().get(0));
            } else {
                gxRequest.setCreatedBy(flow.getCreatedBy());
            }

            // Set Channel Name
            String channelName = null;
            if (gxRequest.getType().equals(GxRequestType.ISSUE)) {
            	
                GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);
                
                if (issuePayload.getIssuer() != null) {
                    channelName = this.gxUtil.getChannelNameFromIssuerId(issuePayload.getIssuer());
                }
            } else {
            	
                channelName = this.gxChannelResolver.get(gxRequest.getGuaranteeId());
            }
            gxRequest.setChannelName(channelName);
            gxRequest.setOffchainOnly(true);
            flow.setPayload(MAPPER.convertValue(gxRequest, Map.class));

            // Upsert to GxRequest repository (request can exist already due to prefills)
            // This serves the dual purpose of storing the guarantee request for searches, as well as linking it to a channel
            try {
            	
                this.gxRequestRepository.getItem(gxRequest.getId());
                this.gxRequestRepository.updateItem(gxRequest);
                
            } catch (DataNotFoundException exception) {
            	
                this.gxRequestRepository.addItem(gxRequest);
            }
        }

        // If approving offchain applicant approve of beneficiary initiated issue, add issuer to temporary request
        if (
        	!hasParent && 
        	currentActionInfo.getNextAction() != null && 
        	request.getType().equals(SharedApprovalModelActionType.APPROVE_ISSUE_GUARANTEE.value())
        ) {
        	
            GxRequest gxRequest = this.gxRequestRepository.getItem(flow.getGxRequestId());
            GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);

            // check is beneficiary initiated, and is applicant
            if (issuePayload.getBeneficiaries().get(0).equals(gxRequest.getCreatedBy()) && 
            	issuePayload.getApplicants().get(0).equals(request.getCreatedBy())) {
                // extract issuer
                GxAction approve = MAPPER.convertValue(request.getPayload(), GxAction.class);
                GxActionApprovePayload approvePayload = MAPPER.convertValue(approve.getPayload(), GxActionApprovePayload.class);

                // add issuer
                issuePayload.setIssuer(approvePayload.getIssuer());
                gxRequest.setPayload(issuePayload);
                this.gxRequestRepository.updateItem(gxRequest);
            }
            
        } else if (
        			request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL.value()) && 
        			flow.getType().equals(SharedApprovalModelActionType.APPROVE_ISSUE_GUARANTEE.value())
        ) {
        	
            // If cancelling offchain applicant approve of beneficiary initiated issue, delete issuer from temporary request
            GxRequest gxRequest = gxRequestRepository.getItem(flow.getGxRequestId());

            if (gxRequest.getOffchainOnly() != null && gxRequest.getOffchainOnly()) {
            	
                GxIssuePayload issuePayload = MAPPER.convertValue(gxRequest.getPayload(), GxIssuePayload.class);

                // check is beneficiary initiated, and is applicant cancelling
                //
                if (issuePayload.getBeneficiaries().get(0).equals(gxRequest.getCreatedBy()) && 
                	issuePayload.getApplicants().get(0).equals(request.getCreatedBy())) {
                	
                    // delete issuer
                    issuePayload.setIssuer(null);
                    gxRequest.setPayload(issuePayload);

                    this.gxRequestRepository.updateItem(gxRequest);
                }
            }
        }

        // If cancelling or rejecting approval model request for a new Start GxRequest. Close the temporary GxRequest created by approval model request
        if (request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_REJECT.value()) ||
            request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL.value())
        ) {
            SharedApprovalModelActionType flowType = null;
            try {
                
            	flowType = SharedApprovalModelActionType.fromValue(flow.getType());
                
            } catch (IllegalArgumentException e) {
                // Unknown actions are assumed to not be gx related
            }
            
            if (flowType != null && ApprovalModelUtil.gxRequestTypes.contains(flowType)) {
            	
                GxRequest gxRequest = MAPPER.convertValue(flow.getPayload(), GxRequest.class);
                
                if (request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_REJECT.value())) {
                	
                    gxRequest.setStatus(FlowStatus.REJECTED);
                
                } else if (request.getType().equals(SharedApprovalModelActionType.APPROVAL_FLOW_CANCEL.value())) {
                
                	gxRequest.setStatus(FlowStatus.CANCELLED);
                }

                this.gxRequestRepository.updateItem(gxRequest);

                // Alert issuer that Request has been rejected
                List<GxAction> gxActions = this.getPrincipal()
                							   .getGxManager()
                							   .getFlowActions(gxRequest.getId());
                
                if (
                	!gxActions.isEmpty() && 
                	gxActions.get(0).getType().equals(GxActionType.PREFILL)
                ) {
                	
                    LOGGER.debug(BgxLogMarkers.DEV,"Alerting issuer to prefill Rejection (request ID: {})", gxRequest.getId());
                    
                    GxAction prefill = gxActions.get(0);
                    GxAction reject = new GxAction();
                    reject.setType(GxActionType.REJECT);
                    reject.setId(UUID.randomUUID().toString());
                    reject.setGxRequestId(gxRequest.getId());
                    reject.setCreatedBy(getPrincipal().getConfiguredForOrgId());
                    reject.setCreatedAt(Instant.now());

                    try {
                    
                    	this.gxPrefillClient.sendOffchainGxActionNotification(prefill.getCreatedBy(), reject);
                    
                    } catch (Exception e) {
                    	
                        throw new GuaranteeException("Failed to alert issuer to prefill rejection", e);
                    }
                }
            }
        }
    }

    /**
     * 
     * @param currentActionInfo
     * @param userProfileRoles
     */
    private void ensureHasRequiredRoles(ApprovalModelActionInfo currentActionInfo, List<String> userProfileRoles) {
    	
        if (currentActionInfo.getRoles().isEmpty() || 
        	(
        		!currentActionInfo.getRoles().get(0).equals(ANY_ROLE) &&
                userProfileRoles.stream().noneMatch(currentActionInfo.getRoles()::contains)
            )
        ) {
            throw new ApprovalModelForbiddenException(String.format("User is not of a required role. User's roles: %s, Required Roles: %s", 
            														userProfileRoles, 
            														currentActionInfo.getRoles())
            										 );
        }
    }

    /**
     * 
     * @param flowRequest
     * @return
     * @throws IOException
     */
    private ApprovalModelActionInfo getInitialApprovalModelActionInfo(ApprovalModelFlowRequest flowRequest) throws IOException {
    	
        ApprovalModelInfo approvalModelInfo = getApprovalModelInfo();

        for (ApprovalModelActionInfo flow : approvalModelInfo.getFlows()) {
        	
            if (flow.getActionName().equals(flowRequest.getType())) {
                return flow;
            }
        }
        throw new IllegalArgumentException(String.format("Could not find flow with name %s", flowRequest.getType()));
    }

    /**
     * 
     * @param flowType
     * @return
     * @throws IOException
     */
    // For parent flows
    private ApprovalModelActionInfo getApprovalModelActionInfo(String flowType) throws IOException {
    	
        ApprovalModelInfo approvalModelInfo = getApprovalModelInfo();
        for (ApprovalModelActionInfo flow : approvalModelInfo.getFlows()) {
            
        	if (flow.getActionName().equals(flowType)) {
                return flow;
            }
        }

        throw new IllegalArgumentException(String.format("Could not find flow with name %s", flowType));
    }

    /**
     * 
     * @param flowRequest
     * @return
     * @throws IOException
     */
    // For actions
    private ApprovalModelActionInfo getApprovalModelActionInfo(ApprovalModelFlowRequest flowRequest) throws IOException {
    	
        ApprovalModelActionInfo targetAction = getInitialApprovalModelActionInfo(flowRequest);
        return getApprovalModelActionInfo(flowRequest, targetAction);
    }

    /**
     * 
     * @param flowRequest
     * @param initialAction
     * @return
     */
    // For actions
    private ApprovalModelActionInfo getApprovalModelActionInfo(ApprovalModelFlowRequest flowRequest, ApprovalModelActionInfo initialAction) {
    	
        ApprovalModelActionInfo targetAction = initialAction;

        for (int i = 0; i < flowRequest.getActions().size(); i++) {
            targetAction = targetAction.getNextAction();
        }

        if (targetAction == null) {
            throw new IllegalArgumentException(String.format("Could not find target action for flow %s", flowRequest.getType()));
        }

        return targetAction;
    }
}