package com.ibm.au.bgx.core.chain;

import com.ibm.au.bgx.model.AbstractPrincipalProvider;
import com.ibm.au.bgx.model.chain.ChannelSelector;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
public abstract class AbstractPrincipalChain<T> extends AbstractPrincipalProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractPrincipalChain.class);

    @Autowired
    ChannelSelector selector;

    protected String channelUserName;

    public AbstractPrincipalChain(BgxPrincipal principal, String channelUserName) {
        super(principal);

        if (channelUserName == null) {
            throw new IllegalArgumentException("Channel user name cannot be null.");
        }

        LOGGER.debug("Using channel user {}", channelUserName);
        this.channelUserName = channelUserName;
    }
}
