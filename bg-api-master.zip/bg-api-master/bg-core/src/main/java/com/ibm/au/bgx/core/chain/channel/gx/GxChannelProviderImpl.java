/**
 * 
 */
package com.ibm.au.bgx.core.chain.channel.gx;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

/**
 * Class <b>GxChannelProviderImpl</b>. This class is the default implementation of
 * the {@link GxChannelProvider} interface and completes the {@link AbstractGxChannelProvider}
 * by adding the logic for channel setup by reading the configuration of the channel from a 
 * string, which encodes the channel mapping in the following form:
 * 
 * <code>
 * mapping := pair { COMMA pair }
 * pair := name PIPE prefix
 * name := IDENTIFIER
 * prefix := IDENTIFIER
 * 
 * COMMA := ','
 * PIPE := '|'
 * <code>
 * 
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
@Primary
@Component
public class GxChannelProviderImpl extends AbstractGxChannelProvider {


	/**
	 * A {@link String} containing the value of the separator of pairs
	 * that containing the information about one channel.
	 */
    public static final String CHANNEL_SEPARATOR	=	",";
    /**
     * A {@link String} containing the value of the separator that is used
     * in each pair to separate the channel name from its associated prefix.
     */
    public static final char MAPPING_SEPARATOR		=	'|';
    
    

    /**
     * This method sets the list of channel mappings with the given <i>channelList</i>. 
     * Upon successful processing of the given string the list of channel mappings will
     * be configured with the information processed and {@link #getChannels()} will return 
     * the list of channel mappings that have been processed.
     * 
     * @param channelList	a {@link String} containing the encoded metadata
     * 						information for the bank guarantee channels. This
     * 						argument is expected to be a non {@literal null}
     * 						string, which contains a comma separated list of
     * 						mapping pairs, where each pair is represented by
     * 						the sequence channel name, pipe character, channel
     * 						prefix.
     */
    @Value("${fabric.guarantee.channel.list:anz-channel|000001,commbank-channel|000002,nab-channel|000003,westpac-channel|000004}")
    public void setChannelList(String channelList) {
    	
    	try {
    		
    		this.channels = this.parseMappings(channelList);
    		
    	} catch(ParseException pex) {
    		
    		throw new IllegalArgumentException("Could not parse the list of channels.", pex);
    	}
    }
    
    /**
     * This method parses the content of the given strings and separates into mapping pairs by
     * using the value of {@link GxChannelProviderImpl#CHANNEL_SEPARATOR}. It then processes 
     * each mapping pair to extract the channel name and prefix, which are separated by looking
     * for the occurrence of {@link GxChannelProviderImpl#MAPPING_SEPARATOR}. The information 
     * extracted from each pair is then used to create an instance of {@link GxChannelMetadata}.
     * 
     * @param channelMappings	a {@link String} containing the channel mapping pairs. It cannot
     * 							be {@literal null}.
     * 
     * @return	a {@link List} of {@link GxChannelMetadata} instances that contains the information
     * 			about the extracted channel mappings.
     * 
     * @throws ParseException	if there is any error while parsing the content of <i>channelMappings</i>
     * 
     * @throws IllegalArgumentException if <i>channelMappings</i> is {@literal null}.
     */
    protected List<GxChannelMetadata> parseMappings(String channelMappings) throws ParseException {
    	
    	if (channelMappings == null) {
    		throw new IllegalArgumentException("Parameter channelMappings cannot be null, if you want to reset the mappings provide an empty string.");
    	}
    	
    	int counter = 0;
    	
    	List<GxChannelMetadata> newMappings = new ArrayList<>();
    	
    	if (channelMappings.trim().isEmpty()) {
    		return newMappings;
    	}
    	
    	String[] pairs = channelMappings.split(CHANNEL_SEPARATOR);
    	for(String pair : pairs) {
    		
    		int pivot = pair.indexOf(MAPPING_SEPARATOR);
    		if (pivot > 0) {
    			
    			String channelName = pair.substring(0, pivot).trim();
    			String prefix = pair.substring(pivot+1).trim();
    			
    			try {
    			
    				newMappings.add(new GxChannelMetadata(channelName, prefix));
    			
    			} catch(IllegalArgumentException iex) {
    				
    				throw new ParseException(String.format("Unexpected pair data: %1$s", pair), counter);	
    			}
    			
    		} else {
    		
    			throw new ParseException(String.format("Expected mapping separator %1$s for pair (pair: %2$s)", MAPPING_SEPARATOR, pair), counter);
    			
    		}
    		counter += pair.length() + 1;
    	}
    		
    	return newMappings;
    }
}
