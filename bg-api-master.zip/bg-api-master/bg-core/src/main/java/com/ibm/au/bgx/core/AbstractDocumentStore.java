package com.ibm.au.bgx.core;

import com.ibm.au.bgx.model.DocumentStore;
import java.util.Base64;
import java.util.Map;
import org.apache.commons.lang.StringUtils;

/**
 * Abstract class with helper methods
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public abstract class AbstractDocumentStore implements DocumentStore {

    @Override
    public void createDocumentWithBase64(String id, String payload, Map<String, Object> meta) {

        if (StringUtils.isEmpty(id)) {
            throw new IllegalArgumentException("Payload cannot be empty");
        }

        if (StringUtils.isEmpty(payload)) {
            throw new IllegalArgumentException("Payload cannot be empty");
        }

        createDocument(id, Base64.getDecoder().decode(payload), meta);
    }

    @Override
    public String readDocumentAsBase64(String id) {
        if (StringUtils.isEmpty(id)) {
            throw new IllegalArgumentException("Payload cannot be empty");
        }

        if (!hasDocument(id)) {
            throw new IllegalArgumentException(
                String.format("Document does not exists with id: %s", id));
        }

        byte[] bytes = readDocument(id);
        if (bytes == null) {
            throw new IllegalArgumentException(
                String.format("Could not read document with id: %s", id));
        }

        return Base64.getEncoder().encodeToString(bytes);
    }
}
