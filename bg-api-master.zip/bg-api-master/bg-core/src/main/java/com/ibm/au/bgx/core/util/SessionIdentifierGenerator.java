package com.ibm.au.bgx.core.util;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.springframework.stereotype.Component;

/**
 * Class <b>SessionIdentifierGenerator</b>. This class is used to generate unique identifiers
 * for client sessions. This session identifiers are used within the context of communication
 * with web sockets primarily for the delivery of push notifications to application clients.
 *
 * @author Peter Ilfrich
 */
@Component
public class SessionIdentifierGenerator {

	/**
	 * A {@literal int} value that defines the length of the session identifiers.
	 */
    private static final int MAX_NUMERIC_LEN = 32;

    /**
     * A {@link SecureRandom} instance that is used to produce a sequence of pseudo
     * random numbers that are used to generate identifiers.
     */
    private SecureRandom random = new SecureRandom();

    /**
     * Creates the next session identifier number randomly with the default length set by 
     * {@link SessionIdentifierGenerator#MAX_NUMERIC_LEN}. The generation of the number is 
     * implemented by using {@link BigInteger#BigInteger(int, java.util.Random)}.
     *
     * @return	a {@link String} representing the random number generated. This is guaranteed
     * 			to not to be {@literal null} and of length {@link SessionIdentifierGenerator#MAX_NUMERIC_LEN}.
     */
    public synchronized String next() {
    	
        return new BigInteger(130, this.random).toString(32);
    }

    /**
     * Generates a random numeric string of the desired length. This method has allows for
     * defining a random number whose number of digit is up to maximum allowed value {@link 
     * SessionIdentifierGenerator#MAX_NUMERIC_LEN}. The generation of the random number is
     * implemented by using {@link BigInteger#BigInteger(int, java.util.Random)}.
     *
     * @param len	a {@literal int} that defines the number of characters that the random
     * 				number needs to be composed of. It cannot be smaller than 1 and bigger 
     * 				than {@link SessionIdentifierGenerator#MAX_NUMERIC_LEN}.
     * 
     * @return a {@link String} representing the random number generated. This is guaranteed
     * 			to not to be {@literal null} and of length <i>len</i>.
     * 
     * @throws IllegalArgumentException if <i>len</i> is smaller than 1 or bigger than  {@link 
     * 									SessionIdentifierGenerator#MAX_NUMERIC_LEN}
     * 									
     */
    public synchronized String nextNumeric(int len) {

        if (len < 1 || len > SessionIdentifierGenerator.MAX_NUMERIC_LEN) {
          throw new IllegalArgumentException(String.format("Length must be between 1 and %d", SessionIdentifierGenerator.MAX_NUMERIC_LEN));
        }

        return new BigInteger(130, this.random).toString().substring(0, len);
    }
}
