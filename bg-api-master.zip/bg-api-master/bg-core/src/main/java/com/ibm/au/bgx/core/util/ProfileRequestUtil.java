package com.ibm.au.bgx.core.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.util.JacksonUtil;
import java.io.IOException;
import java.util.List;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public class ProfileRequestUtil {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    /**
     * Clone contacts without credentials
     *
     * @param profileRequest
     * @return
     */
    public static List<ContactInfo> cloneContacts(OrgProfileRequest profileRequest) {

        List<ContactInfo> contacts;
        try {
            contacts = MAPPER
                .readValue(MAPPER.writeValueAsString(profileRequest.getProfile().getContacts()),
                    new TypeReference<List<ContactInfo>>(){});

            // clean up contact's credentials if required
            for (ContactInfo contactInfo : contacts) {
                if (contactInfo.getCredentials() != null) {
                    contactInfo.setCredentials(null);
                }
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("Could not serialize/deserialize contacts list", e);
        }

        return contacts;
    }

    /**
     * Clone contacts with token or PIN
     *
     * This is used when primary user tries to on-board and requires the token/pin of the ADMIN contacts
     *
     * @param profileRequest
     * @return
     */
    public static List<ContactInfo> cloneContactsWithToken(OrgProfileRequest profileRequest) {

        List<ContactInfo> contacts;
        try {
            contacts = MAPPER
                .readValue(MAPPER.writeValueAsString(profileRequest.getProfile().getContacts()),
                    new TypeReference<List<ContactInfo>>(){});

            // cleanup keys
            for (ContactInfo contactInfo : contacts) {
                if (contactInfo.getCredentials() != null) {
                    contactInfo.getCredentials().setKey(null);
                }
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("Could not serialize/deserialize contacts list", e);
        }

        return contacts;
    }
}
