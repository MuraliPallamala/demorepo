package com.ibm.au.bgx.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.chain.profile.ApprovalModelCatalog;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * Class <b>ApprovalModelCatalogImpl</b>. Default implementation of the approval model catalog,
 * which sources the information about available approval models from resource files. These are
 * stored as JSON documents and map the two existing and supported implementation of approval
 * model: <i>SOLE_APPROVER</i> and <i>FOUR_EYE</i>.
 * 
 * @author Dain Liffman
 * @author Christian Vecchiola
 *
 */
@Component
public class ApprovalModelCatalogImpl implements ApprovalModelCatalog {
	
	/**
	 * A {@link String} constant pointing to the resource file that contains the definition of the
	 * {@link Name#SOLE_APPROVER} approval model.
	 */
	private static final String SOLE_APPROVER_RESOURCE_PATH = "/approval-models/sole-approver.json";

	/**
	 * A {@link String} constant pointing to the resource file that contains the definition of the
	 * {@link Name#FOUR_EYE} approval model.
	 */
	private static final String FOUR_EYE_RESOURCE_PATH = "/approval-models/four-eye.json";

	/**
	 * A {@link ObjectMapper} implementation that is used to deserialise from the {@link ApprovalModelInfo}
	 * instance from the corresponding JSON representation.
	 */
    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    /**
     * {@inheritDoc}
     */
    public List<ApprovalModelInfo> getApprovalModels() throws IOException {
    	
        // TODO retrieve from repository
        ApprovalModelInfo fourEyeApprover = this.loadApprovalModel(ApprovalModelCatalogImpl.FOUR_EYE_RESOURCE_PATH);
        ApprovalModelInfo soleApprover = this.loadApprovalModel(ApprovalModelCatalogImpl.SOLE_APPROVER_RESOURCE_PATH);

        return Arrays.asList(soleApprover, fourEyeApprover);
    }
	    
	/**
	 * {@inheritDoc}
	 */
    @Override
    public ApprovalModelInfo getApprovalModel(ApprovalModelInfo.Name name) throws IOException {
    	
    	if (name == null) {
    		throw new IllegalArgumentException("Name cannot be null.");
    	}
    	
    	switch(name) {
	    	case SOLE_APPROVER	:	return this.loadApprovalModel(ApprovalModelCatalogImpl.SOLE_APPROVER_RESOURCE_PATH);
	    	case FOUR_EYE		:	return this.loadApprovalModel(ApprovalModelCatalogImpl.FOUR_EYE_RESOURCE_PATH);
	        default				:	return null;
    	}
    }
    
    /**
     * Loads the approval model definition from the given class resource path.
     * 
     * @param resourcePath	a {@link String} representing the resource path relative to the current class, from where
     * 						to load the information about the approval model. This is expected to be a valid resource
     * 						path and it is not checked. 
     * 
     * @return	a {@link ApprovalModelInfo} instance representing the definition of the approval model deserialised
     * 			from the JSON document pointed by <i>resourcePath</i>.
     * 
     * @throws IOException	if there is any error while deserialising the content of <i>resourcePath</i>
     */
    protected ApprovalModelInfo loadApprovalModel(String resourcePath) throws IOException {
    
    	return MAPPER.readValue(ApprovalModelCatalogImpl.class.getResourceAsStream(resourcePath), ApprovalModelInfo.class);
    }
}
