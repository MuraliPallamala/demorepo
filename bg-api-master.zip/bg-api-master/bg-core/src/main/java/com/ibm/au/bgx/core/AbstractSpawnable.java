package com.ibm.au.bgx.core;

import com.ibm.au.bgx.model.AbstractPrincipalProvider;
import com.ibm.au.bgx.model.user.BgxPrincipal;

/**
 * This abstract class contains various common variables and methods for classes that implements the
 * Spawnable interface to create an instance configured for principal and a given orgId
 *
 * @param <T> 
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public abstract class AbstractSpawnable<T> extends AbstractPrincipalProvider {

    /**
     * A {@link String} containing the organization for which this class has been spawend
     */
    private String orgId;

    /**
     * A {@link Boolean} field denoting whether it is spawned by another instance or not.
     *
     * If this flag is set it is not allowed to spawn another instance of its own type.
     */
    private boolean hasBeenSpawned = false;

    protected AbstractSpawnable(BgxPrincipal principal, String orgId) {
        super(principal);

        if (orgId == null) {
            throw new IllegalArgumentException("OrgId parameter cannot be null.");
        }

        this.orgId = orgId;
    }

    /**
     * Each child class should call this after it spawn another instance of its own type
     */
    protected void flagSpawned() {
        this.hasBeenSpawned = true;
    }

    /**
     * A helper method to check if it is a spawned instance or not
     * @return
     */
    public boolean isSpawned() {
        return this.hasBeenSpawned;
    }

    /**
     * Default implementation of one of the methods in Spawnable interface
     * @return
     */
    public String getConfiguredForOrgId() {
        return this.orgId;
    }

}
