package com.ibm.au.bgx.core.util;

import com.ibm.au.bgx.core.approvalmodel.FourEyeApprovalModel;
import com.ibm.au.bgx.core.approvalmodel.SoleApproverApprovalModel;
import com.ibm.au.bgx.core.auth.AbstractBgxPrincipal;
import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.GxPrefillRequestManager;
import com.ibm.au.bgx.model.RequestManager;
import com.ibm.au.bgx.model.chain.gx.GxManager;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.logging.BgxLogMarkers;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Permission;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.pojo.approvalmodel.OrgApprovalModelSettings;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.util.Collection;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.GrantedAuthority;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public class BgxPrincipalMock extends AbstractBgxPrincipal {

    private static final Logger LOGGER = LoggerFactory.getLogger(BgxPrincipalMock.class);

    private ApplicationContext applicationContext;

    public BgxPrincipalMock(UserProfile userProfile, Organization organization,
        Collection<GrantedAuthority> authorities,
        boolean enabled, boolean accountExpired, boolean accountLocked,
        boolean credentialsExpired, BgxComponentProvider componentProvider,
        ApplicationContext applicationContext) {

        super(userProfile, organization, authorities, enabled, accountExpired, accountLocked,
            credentialsExpired, componentProvider);

        this.applicationContext = applicationContext;

        if (this.applicationContext != null) {
            requestManager = (RequestManager) applicationContext.getBean("requestManager", this);
        }

        // NOTE organization does not exist during bootstrapping phase
        // TODO refactor
        if (organization != null && applicationContext != null) {
            if (organization.getProfile().getEntityType()
                .equals(OrgProfile.EntityType.APPLICANT_OR_BENEFICIARY)) {

                LOGGER.debug(BgxLogMarkers.AUTH,
                    "Initializing principal {} with GxManager for org type {}",
                    this.getEmail(), organization.getProfile().getEntityType());

                gxManager = (GxManager) applicationContext.getBean("appBenGxManager", this);
            } else if (organization.getProfile().getEntityType()
                .equals(OrgProfile.EntityType.ISSUER)) {

                LOGGER.debug(BgxLogMarkers.AUTH,
                    "Initializing principal {} with GxManager for org type {}",
                    this.getEmail(), organization.getProfile().getEntityType());

                gxManager = (GxManager) applicationContext.getBean("issuerGxManager", this);
            } else {

                LOGGER.debug(BgxLogMarkers.AUTH,
                    "Skipping initialization of principal {} with GxManager for org type {}",
                    this.getEmail(), organization.getProfile().getEntityType());

                gxManager = null;
            }

            // Approval models are optional, so organizations may not set one
            if (organization.getSettings()!= null && organization.getSettings().getApprovalModel() != null) {
                OrgApprovalModelSettings orgApprovalModelSettings = organization.getSettings()
                    .getApprovalModel();
                ApprovalModelInfo.Name approvalModelName = organization.getSettings()
                    .getApprovalModel().getName();
                if (approvalModelName == ApprovalModelInfo.Name.SOLE_APPROVER) {
                    approvalModel = (SoleApproverApprovalModel) applicationContext
                        .getBean("soleApproverApprovalModel", this);
                } else if (approvalModelName == ApprovalModelInfo.Name.FOUR_EYE) {
                    approvalModel = (FourEyeApprovalModel) applicationContext
                        .getBean("fourEyeApprovalModel", this);
                } else {
                    approvalModel = null;
                }
            } else {
                approvalModel = null;
            }
            gxPrefillRequestManager = (GxPrefillRequestManager) applicationContext
                .getBean("gxPrefillRequestManager", this);
        } else {
            gxManager = null;
            approvalModel = null;
            gxPrefillRequestManager = null;

        }
    }

    @Override
    public BgxPrincipal forOrg(Relationship relationship, String targetOrgId,
        List<Permission> permissions) throws GuaranteeForbiddenException {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public String getChannelUserName() {
        return getConfiguredForOrgId();
    }
}
