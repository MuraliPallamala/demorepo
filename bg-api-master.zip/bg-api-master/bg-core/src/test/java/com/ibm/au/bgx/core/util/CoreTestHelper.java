package com.ibm.au.bgx.core.util;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.user.BgxPrincipal;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

/**
 * @author Peter Ilfrich
 * @author Lenin Mehedy
 */
@Component
public class CoreTestHelper extends DefaultTestHelper {
	
	
	
	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	BgxComponentProvider componentProvider;


	public BgxPrincipal getPrincipal(Organization org, UserProfile userProfile) {
		return getPrincipal(org, userProfile, componentProvider, applicationContext);
	}

	@Override
	public BgxPrincipal getPrincipal(Organization org, UserProfile profile, BgxComponentProvider componentProvider,
			ApplicationContext applicationContext) {

		SimpleGrantedAuthority authority = new SimpleGrantedAuthority("ROLE_ANOTHER");
		Collection<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(authority);

		BgxPrincipalMock principal = new BgxPrincipalMock(profile, org, authorities, true, false, false, false,
				componentProvider, applicationContext);

		return principal;
	}

	@Autowired
	public void setTermsAndConditions(TermsAndCondManager tcManager) {

		this.tcManager = tcManager;
	}
	
	public void setupTermsAndConds() {
		this.setupTermsAndConds(this.tcManager);
	}


}
