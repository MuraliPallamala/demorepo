package com.ibm.au.bgx.core;

import static org.junit.Assert.*;

import com.ibm.au.bgx.common.KeyGeneratorImpl;
import com.ibm.au.bgx.model.BgxConstants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    KeyGeneratorImpl.class
})
public class KeyGeneratorImplTest {

    @Autowired
    KeyGeneratorImpl generator;

    @Test
    public void checkCompositeKey() throws Exception {
        String orgKey = generator.newKey(BgxConstants.ORG_KEY_LEN) ;
        String userKey = generator.newKey(BgxConstants.USER_KEY_LEN) ;

        String compositeKey = generator.getCompositeKey(orgKey, userKey);

        assertEquals(orgKey, generator.getOrgKey(compositeKey));
        assertEquals(userKey, generator.getUserKey(compositeKey));
    }

}