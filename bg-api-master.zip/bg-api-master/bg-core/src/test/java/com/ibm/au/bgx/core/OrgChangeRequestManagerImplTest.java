package com.ibm.au.bgx.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.chain.ChannelSelectorMock;
import com.ibm.au.bgx.chain.ProfileChainMock;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.common.KeyGeneratorImpl;
import com.ibm.au.bgx.common.notification.WebNotificationManagerImpl;
import com.ibm.au.bgx.common.rest.AccessTokenProvider;
import com.ibm.au.bgx.common.rest.IdentityConfiguration;
import com.ibm.au.bgx.common.rest.NewCoNotificationClientImpl;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.core.util.CoreTestHelper;
import com.ibm.au.bgx.core.validation.BgxDataValidatorImpl;
import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.chain.profile.OrgChangeRequestManager;
import com.ibm.au.bgx.model.chain.profile.OrgProfileRequestManager;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.pojo.*;
import com.ibm.au.bgx.model.pojo.BaseRequest.RequestType;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest.Type;
import com.ibm.au.bgx.model.pojo.api.request.OrgChangePayloadEntity;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo.Name;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationPublicKey;
import com.ibm.au.bgx.model.repository.OrgChangeRequestRepository;
import com.ibm.au.bgx.model.repository.OrganizationRepository;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.queue.TransientQueueClient;
import com.ibm.au.bgx.repository.AuditEventRepositoryMock;
import com.ibm.au.bgx.repository.BatchProcessTaskRepositoryMock;
import com.ibm.au.bgx.repository.ChannelUserRepositoryMock;
import com.ibm.au.bgx.repository.EncryptionKeyRepositoryMock;
import com.ibm.au.bgx.repository.GxRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrgChangeRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrgProfileRepositoryMock;
import com.ibm.au.bgx.repository.OrgProfileRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrganizationRepositoryMock;
import com.ibm.au.bgx.repository.UserProfileRepositoryMock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.ibm.au.bgx.repository.WebNotificationRepositoryMock;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.Assert.*;

/**
 * @author Peter Ilfrich
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    BgxComponentProviderImpl.class,
    AuditEventRepositoryMock.class,
    OrganizationRepositoryMock.class,
    ChannelUserRepositoryMock.class,
    UserProfileRepositoryMock.class,
    NewCoNotificationClientImpl.class,
    OrganizationManagerImpl.class,
    ApprovalModelCatalogImpl.class,
    OrgProfileRepositoryMock.class,
    ProfileChainMock.class,
    IdentityConfiguration.class,
    BgxEncryptionUtil.class,
    EncryptionKeyRepositoryMock.class,
    OrgChangeRequestRepositoryMock.class,
    CoreTestHelper.class,
    KeyGeneratorImpl.class,
    OrgChangeRequestRepositoryMock.class,
    OrgProfileRequestRepositoryMock.class,
    BatchProcessTaskRepositoryMock.class,
    SSLUtils.class,
    ChannelSelectorMock.class,
    TransientQueueClient.class,
    WebNotificationManagerImpl.class,
    WebNotificationRepositoryMock.class,
    AccessTokenProvider.class,
    BgxDataValidatorImpl.class,
    GxRequestRepositoryMock.class,
    TermsAndCondManagerMock.class
})
@TestPropertySource(locations = "classpath:application-test.properties")
public class OrgChangeRequestManagerImplTest {

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Autowired
    BgxComponentProvider provider;

    @Autowired
    OrganizationManager orgManager;

    @Autowired
    OrganizationRepository organizationRepository;

    @Autowired
    OrgChangeRequestRepository changeRequestRepository;

    @Autowired
    KeyGenerator generator;

    @Autowired
    CoreTestHelper testHelper;
    
    List<String> sampleAdminCerts;
    

    @Before
    public void setUp() throws Exception {

        this.sampleAdminCerts = testHelper.getAdminCerts();
        
        this.testHelper.setupTermsAndConds();

        // we need to check that one organization has already been bootstrapped without adminCert input
        // This is required for local java-integration-test where chaincode throws error if the admin org hasn't been bootstrapped
        List<Organization> orgs = orgManager.getAll();
        if (orgs.size() == 0) {
            this.initializeOrganization(null, null); // create the first org that does not require cert
        }
    }

    @Test
    public void testGetAll() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization org = mocks.get(0);

        OrgChangeRequestManager manager = getManager(org);

        try {
            List<OrgChangeRequest> list = manager.getAll();
            assertEquals(0, list.size());
        } catch (Exception e) {
            e.printStackTrace();
        }

        OrgChangeRequest r1 = new OrgChangeRequest();
        r1.setOrgId("bla");

        OrgChangeRequest r2 = new OrgChangeRequest();
        r2.setOrgId(org.getId());

        r1 = changeRequestRepository.addItem(r1);
        r2 = changeRequestRepository.addItem(r2);

        List<OrgChangeRequest> list = manager.getAll();

        assertEquals(1, list.size());
        assertEquals(r2, list.get(0));
        assertNotEquals(r1, list.get(0));
    }

    @Test
    public void addBusinessAccount() throws Exception {
        List<Organization> mocks = this.createMocks(1);
        Organization org = mocks.get(0);
        OrgChangeRequestManager manager = getManager(org);

        try {
            manager.addBusinessAccount(null);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }

        BankAccount bankingDetail = testHelper.createBankAccount();
        Organization actual = manager.addBusinessAccount(bankingDetail);

        assertNotNull(actual);
        assertNotNull(actual.getId());
        assertNotNull(actual.getSettings());
        assertNotNull(actual.getSettings().getBankAccounts());
        assertEquals(bankingDetail,
                ((OrgChangeRequestManagerImpl) manager).getAccount(actual, bankingDetail.getId()));

        try {
            // try adding it again
            bankingDetail = testHelper.createBankAccount();
            manager.addBusinessAccount(bankingDetail);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }
    }

    @Test
    public void removeBankingDetails() throws Exception {

        List<Organization> mocks = this.createMocks(1);
        Organization org = mocks.get(0);

        OrgChangeRequestManager manager = getManager(org);

        BankAccount bankingDetail = testHelper.createBankAccount();
        Organization actual = manager.addBusinessAccount(bankingDetail);

        assertNotNull(actual);
        assertNotNull(actual.getId());
        assertNotNull(actual.getSettings());
        assertNotNull(actual.getSettings().getBankAccounts());
        assertEquals(bankingDetail,
                ((OrgChangeRequestManagerImpl) manager).getAccount(actual, bankingDetail.getId()));
        assertEquals(1, actual.getSettings().getBankAccounts().size());

        actual = manager.removeBusinessAccount(bankingDetail.getId());

        assertNotNull(actual);
        assertNotNull(actual.getId());
        assertNotNull(actual.getSettings());
        assertNotNull(actual.getSettings().getBankAccounts());
        assertEquals(0, actual.getSettings().getBankAccounts().size());

        try {
            // try again
            manager.removeBusinessAccount(bankingDetail.getId());
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }
    }

    @Test
    public void testAddOrgLinkInformation() throws Exception {
        List<Organization> mocks = this.createMocks(2);

        Organization sourceOrg = mocks.get(0);
        Organization targetOrg = mocks.get(1);

        sourceOrg.getSettings().setRelationships(null);
        targetOrg.getSettings().setRelationships(null);

        OrgChangeRequestManagerImpl manager = getManager(sourceOrg);

        RelationshipInfo sourceRel = new RelationshipInfo();
        List<Permission> permissions = new ArrayList<>();
        permissions.add(Permission.READ);
        sourceRel.setPermission(permissions);
        sourceRel.setId(targetOrg.getId());
        sourceRel.setRelationship(Relationship.PARENT_OF);

        OrgChangeRequest orgChangeRequest = new OrgChangeRequest();
        orgChangeRequest.setRequestType(RequestType.LINK_ORGANIZATION);
        orgChangeRequest.setPayload(MAPPER.convertValue(sourceRel, Map.class));
        orgChangeRequest.setOrgId(sourceOrg.getId());
        orgChangeRequest.setStatus(Status.CONFIRMED);
        orgChangeRequest.setId(UUID.randomUUID().toString());
        String oldRequestId = orgChangeRequest.getOrgId();

        // add link request information
        manager.addOrgLinkInformation(orgChangeRequest, sourceOrg, targetOrg, sourceRel);

        // perform assertions
        sourceOrg = this.orgManager.getById(sourceOrg.getId());
        targetOrg = this.orgManager.getById(targetOrg.getId());
        assertEquals(1, sourceOrg.getSettings().getRelationships().size());
        assertEquals(1, targetOrg.getSettings().getRelationships().size());

        sourceRel = sourceOrg.getSettings().getRelationships().get(0);
        RelationshipInfo targetRel = targetOrg.getSettings().getRelationships().get(0);
        assertEquals(1, sourceRel.getPermission().size());
        assertEquals(1, targetRel.getPermission().size());

        assertEquals(sourceRel.getRequestId(), orgChangeRequest.getId());
        assertEquals(targetRel.getRequestId(), orgChangeRequest.getId());
        assertEquals(Relationship.SUBSIDIARY_OF, targetRel.getRelationship());
        assertEquals(Relationship.PARENT_OF, sourceRel.getRelationship());
        assertEquals(RelationshipInfo.Status.LINK_PENDING, sourceRel.getStatus());
        assertEquals(RelationshipInfo.Status.LINK_PENDING, targetRel.getStatus());
        assertTrue(sourceRel.getInitiatorFlag());
        assertFalse(targetRel.getInitiatorFlag());

        // finalise the links in preparation of the next test
        sourceOrg.getSettings().getRelationships().get(0).setStatus(RelationshipInfo.Status.LINKED);
        targetOrg.getSettings().getRelationships().get(0).setStatus(RelationshipInfo.Status.LINKED);
        organizationRepository.updateItem(sourceOrg);
        organizationRepository.updateItem(targetOrg);
        // prepare 2nd scenario (unlink)
        orgChangeRequest.setRequestType(RequestType.UNLINK_ORGANIZATION);
        orgChangeRequest.setId(UUID.randomUUID().toString());

        // add unlink request information
        manager.addOrgLinkInformation(orgChangeRequest, sourceOrg, targetOrg, sourceRel);

        // perform assertions
        sourceOrg = this.orgManager.getById(sourceOrg.getId());
        targetOrg = this.orgManager.getById(targetOrg.getId());
        assertEquals(1, sourceOrg.getSettings().getRelationships().size());
        assertEquals(1, targetOrg.getSettings().getRelationships().size());

        sourceRel = sourceOrg.getSettings().getRelationships().get(0);
        targetRel = targetOrg.getSettings().getRelationships().get(0);
        assertEquals(1, sourceRel.getPermission().size());
        assertEquals(1, targetRel.getPermission().size());
        assertEquals(Relationship.SUBSIDIARY_OF, targetRel.getRelationship());
        assertEquals(Relationship.PARENT_OF, sourceRel.getRelationship());
        assertEquals(RelationshipInfo.Status.UNLINK_PENDING, sourceRel.getStatus());
        assertEquals(RelationshipInfo.Status.UNLINK_PENDING, targetRel.getStatus());
        assertTrue(sourceRel.getInitiatorFlag());
        assertFalse(targetRel.getInitiatorFlag());
    }

    @Test
    public void testCreateOrgChangeRequestChangeDetails() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization sourceOrg = mocks.get(0);

        OrgChangeRequestManagerImpl manager = getManager(sourceOrg);

        String newName = "New Org Change";

        OrgChangeRequest request = new OrgChangeRequest();
        request.setOrgId(sourceOrg.getId());
        request.setRequestType(RequestType.CHANGE_DETAILS);
        OrgChangePayloadEntity payload = new OrgChangePayloadEntity();
        payload.setEntityName(newName);
        PostalAddress pa = new PostalAddress();
        pa.setAddressCountry("A");
        pa.setAddressLocality("A");
        pa.setAddressRegion("A");
        pa.setPostalCode("A");
        pa.setPostOfficeBoxNumber("A");
        pa.setStreetAddress("A");
        payload.setAddress(pa);
        request.setPayload(convertToMap(payload));

        OrgChangeRequest req = manager.createOrgChangeRequest(request);
        OrgChangeRequest dbReq = changeRequestRepository.getItem(req.getId());

        assertEquals(req, dbReq);
        assertEquals(Status.CONFIRMED, req.getStatus());
        assertEquals(MAPPER.writeValueAsString(payload),
                MAPPER.writeValueAsString(req.getPayload()));
        assertEquals(RequestType.CHANGE_DETAILS, req.getRequestType());

        OrgChangeRequest copy = MAPPER
                .readValue(MAPPER.writeValueAsString(request), OrgChangeRequest.class);
        copy.setId(null);
        copy.setRevision(null);
        copy.setCreatedAt(null);
        copy.setCreatedBy(null);

        req = manager.createOrgChangeRequest(copy);
        dbReq = changeRequestRepository.getItem(req.getId());

        assertEquals(req, dbReq);
        assertEquals(Status.CONFIRMED, req.getStatus());
        assertEquals(MAPPER.writeValueAsString(payload),
                MAPPER.writeValueAsString(req.getPayload()));
        assertEquals(RequestType.CHANGE_DETAILS, req.getRequestType());
    }

    @Test
    public void testCreateOrgChangeRequestLink() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization sourceOrg = mocks.get(0);
        Organization targetOrg = mocks.get(1);

        // update database
        sourceOrg = organizationRepository.updateItem(sourceOrg);
        targetOrg = organizationRepository.updateItem(targetOrg);

        OrgChangeRequestManagerImpl manager = getManager(sourceOrg);

        OrgChangeRequest request = new OrgChangeRequest();
        request.setOrgId(sourceOrg.getId());
        request.setRequestType(RequestType.LINK_ORGANIZATION);

        RelationshipInfo payload = new RelationshipInfo();
        payload.setRelationship(Relationship.PARENT_OF);
        payload.setId(targetOrg.getId());

        request.setPayload(convertToMap(payload));

        OrgChangeRequest result = manager.createOrgChangeRequest(request);
        OrgChangeRequest dbReq = changeRequestRepository.getItem(result.getId());
        assertEquals(result, dbReq);
        assertEquals(Status.CONFIRMED, result.getStatus());

        // refresh from database
        sourceOrg = orgManager.getById(sourceOrg.getId());
        targetOrg = orgManager.getById(targetOrg.getId());

        assertEquals(1, sourceOrg.getSettings().getRelationships().size());
        assertEquals(1, targetOrg.getSettings().getRelationships().size());

        assertEquals(RelationshipInfo.Status.LINK_PENDING,
                sourceOrg.getSettings().getRelationships().get(0).getStatus());
        assertEquals(RelationshipInfo.Status.LINK_PENDING,
                targetOrg.getSettings().getRelationships().get(0).getStatus());
    }

    @Test
    public void testCreateOrgChangeRequestUnLink() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization sourceOrg = mocks.get(0);
        Organization targetOrg = mocks.get(1);

        this.linkOrganizations(sourceOrg, targetOrg);

        // update database
        sourceOrg = organizationRepository.updateItem(sourceOrg);
        targetOrg = organizationRepository.updateItem(targetOrg);

        OrgChangeRequestManagerImpl manager = getManager(sourceOrg);

        OrgChangeRequest request2 = new OrgChangeRequest();
        request2.setOrgId(sourceOrg.getId());
        request2.setRequestType(RequestType.UNLINK_ORGANIZATION);

        RelationshipInfo payload2 = new RelationshipInfo();
        payload2.setRelationship(Relationship.SUBSIDIARY_OF);
        payload2.setId(targetOrg.getId());

        request2.setPayload(convertToMap(payload2));
        OrgChangeRequest result2 = manager.createOrgChangeRequest(request2);
        OrgChangeRequest dbReq2 = changeRequestRepository.getItem(result2.getId());
        assertEquals(result2, dbReq2);
        assertEquals(Status.CONFIRMED, result2.getStatus());

        // refresh from database
        sourceOrg = orgManager.getById(sourceOrg.getId());
        targetOrg = orgManager.getById(targetOrg.getId());

        assertEquals(1, sourceOrg.getSettings().getRelationships().size());
        assertEquals(1, targetOrg.getSettings().getRelationships().size());

        assertEquals(RelationshipInfo.Status.UNLINK_PENDING,
                sourceOrg.getSettings().getRelationships().get(0).getStatus());
        assertEquals(RelationshipInfo.Status.UNLINK_PENDING,
                targetOrg.getSettings().getRelationships().get(0).getStatus());
    }

    @Test
    public void testDeleteOrganizationLink() throws Exception {
        List<Organization> mocks = this.createMocks(4);
        Organization sourceOrg = mocks.get(0);
        Organization targetOrg = mocks.get(1);

        Organization thirdOrg = mocks.get(2);
        Organization fourthOrg = mocks.get(3);

        this.linkOrganizations(sourceOrg, thirdOrg);
        this.linkOrganizations(fourthOrg, targetOrg);

        OrgChangeRequest request = new OrgChangeRequest();
        request.setRequestType(RequestType.UNLINK_ORGANIZATION);
        request.setOrgId(sourceOrg.getId());

        RelationshipInfo info = new RelationshipInfo();
        info.setRelationship(Relationship.SUBSIDIARY_OF);
        info.setId(targetOrg.getId());
        request.setPayload(MAPPER.convertValue(info, Map.class));
        request = changeRequestRepository.addItem(request);

        // prep of relationships
        RelationshipInfo sourceRel = new RelationshipInfo();
        sourceRel.setRelationship(Relationship.SUBSIDIARY_OF);
        sourceRel.setStatus(RelationshipInfo.Status.UNLINK_PENDING);
        sourceRel.setId(targetOrg.getId());
        sourceRel.setRequestId(request.getId());

        RelationshipInfo targetRel = new RelationshipInfo();
        targetRel.setRelationship(Relationship.PARENT_OF);
        targetRel.setStatus(RelationshipInfo.Status.UNLINK_PENDING);
        targetRel.setId(sourceOrg.getId());
        targetRel.setRequestId(request.getId());

        sourceOrg.getSettings().getRelationships().add(sourceRel);
        targetOrg.getSettings().getRelationships().add(targetRel);

        // refresh from database
        sourceOrg = organizationRepository.updateItem(sourceOrg);
        targetOrg = organizationRepository.updateItem(targetOrg);

        OrgRequestAction approveAction = new OrgRequestAction();
        approveAction.setActionType(Type.APPROVE);

        // attempt to approve as source
        OrgChangeRequestManagerImpl manager = getManager(sourceOrg);
        try {
            manager.deleteOrganizationLink(request, approveAction);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }

        manager = getManager(targetOrg);
        manager.deleteOrganizationLink(request, approveAction);

        // refresh from database
        sourceOrg = organizationRepository.getItem(sourceOrg.getId());
        targetOrg = organizationRepository.getItem(targetOrg.getId());

        assertEquals(1, sourceOrg.getSettings().getRelationships().size());
        assertEquals(1, targetOrg.getSettings().getRelationships().size());

        assertEquals(Status.APPROVED, request.getStatus());
    }

    @Test
    public void testCreateOrganizationLink() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization sourceOrg = mocks.get(0);
        Organization targetOrg = mocks.get(1);

        // setup pending link
        this.linkOrganizations(sourceOrg, targetOrg);
        sourceOrg.getSettings().getRelationships().get(0)
                .setStatus(RelationshipInfo.Status.LINK_PENDING);
        targetOrg.getSettings().getRelationships().get(0)
                .setStatus(RelationshipInfo.Status.LINK_PENDING);

        OrgChangeRequest request = new OrgChangeRequest();
        request.setOrgId(sourceOrg.getId());
        request.setRequestType(RequestType.LINK_ORGANIZATION);

        RelationshipInfo payload = new RelationshipInfo();
        payload.setRelationship(Relationship.PARENT_OF);
        payload.setId(targetOrg.getId());

        request.setPayload(MAPPER.convertValue(payload, Map.class));
        request.setStatus(Status.CONFIRMED);

        request = changeRequestRepository.addItem(request);

        // update rel with request id
        sourceOrg.getSettings().getRelationships().get(0).setRequestId(request.getId());
        targetOrg.getSettings().getRelationships().get(0).setRequestId(request.getId());

        sourceOrg = organizationRepository.updateItem(sourceOrg);
        targetOrg = organizationRepository.updateItem(targetOrg);

        OrgRequestAction approveAction = new OrgRequestAction();
        approveAction.setActionType(Type.APPROVE);

        OrgChangeRequestManager manager = getManager(sourceOrg);
        try {
            manager.createOrganizationLink(request, approveAction);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }

        Map<String, OrganizationPublicKey> publicKeyMap1 = orgManager.getPublicKeys(targetOrg.getId());
        assertEquals(1, publicKeyMap1.size());

        manager = getManager(targetOrg);
        manager.createOrganizationLink(request, approveAction);

        // refresh from database
        sourceOrg = organizationRepository.getItem(sourceOrg.getId());
        targetOrg = organizationRepository.getItem(targetOrg.getId());

        assertEquals(1, request.getActions().size());
        assertEquals(Status.APPROVED, request.getStatus());

        assertEquals(RelationshipInfo.Status.LINKED,
                sourceOrg.getSettings().getRelationships().get(0).getStatus());
        assertEquals(RelationshipInfo.Status.LINKED,
                targetOrg.getSettings().getRelationships().get(0).getStatus());

        Map<String, OrganizationPublicKey> publicKeyMap2 = orgManager.getPublicKeys(targetOrg.getId());
        assertEquals(publicKeyMap1.size() + 1, publicKeyMap2.size());
    }

    @Test
    public void testRejectLinkRequest() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization sourceOrg = mocks.get(0);
        Organization targetOrg = mocks.get(1);

        // setup pending link
        this.linkOrganizations(sourceOrg, targetOrg);
        sourceOrg.getSettings().getRelationships().get(0)
                .setStatus(RelationshipInfo.Status.LINK_PENDING);
        targetOrg.getSettings().getRelationships().get(0)
                .setStatus(RelationshipInfo.Status.LINK_PENDING);

        OrgChangeRequest request = new OrgChangeRequest();
        request.setOrgId(sourceOrg.getId());
        request.setRequestType(RequestType.LINK_ORGANIZATION);
        request.setStatus(Status.CONFIRMED);
        RelationshipInfo rel = new RelationshipInfo();
        rel.setId(targetOrg.getId());
        rel.setRelationship(Relationship.PARENT_OF);
        request.setPayload(MAPPER.convertValue(rel, Map.class));

        request = changeRequestRepository.addItem(request);
        // update request id
        sourceOrg.getSettings().getRelationships().get(0).setRequestId(request.getId());
        targetOrg.getSettings().getRelationships().get(0).setRequestId(request.getId());

        sourceOrg = organizationRepository.updateItem(sourceOrg);
        targetOrg = organizationRepository.updateItem(targetOrg);

        OrgRequestAction rejectAction = new OrgRequestAction();
        rejectAction.setActionType(Type.REJECT);
        rejectAction.setPayload(new HashMap<>());
        rejectAction.getPayload().put(OrgProfileRequestManager.KEY_REJECT_REASON, "just cause");

        OrgChangeRequestManager manager = getManager(sourceOrg);
        try {
            manager.rejectLinkRequest(request, rejectAction);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }

        manager = getManager(targetOrg);
        request = manager.rejectLinkRequest(request, rejectAction);

        // refresh from database

        assertEquals(Status.CONFIRMED, request.getStatus());
        assertEquals(0, request.getActions().size());

        sourceOrg = organizationRepository.getItem(sourceOrg.getId());
        targetOrg = organizationRepository.getItem(targetOrg.getId());

        assertEquals(0, sourceOrg.getSettings().getRelationships().size());
        assertEquals(0, targetOrg.getSettings().getRelationships().size());

        // add final request action and see the update
        request = manager.addFinalRequestAction(request, rejectAction);
        assertEquals(Status.REJECTED, request.getStatus());
        assertEquals(1, request.getActions().size());
    }

    @Test
    public void testUpdateBusinessAccount() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization sourceOrg = mocks.get(0);

        sourceOrg.getSettings().setBankAccounts(new ArrayList<>());

        OrgChangeRequestManager manager = getManager(sourceOrg);
        // checking null input
        try {
            manager.updateBusinessAccount(null, null);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }
        try {
            manager.updateBusinessAccount("bla", null);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }

        BankAccount accountInfo = new BankAccount();
        accountInfo.setId(UUID.randomUUID().toString());
        accountInfo.setAccountNumber("A");
        accountInfo.setDescription("B");
        accountInfo.setType(BankAccount.Type.SWIFT);

        try {
            manager.updateBusinessAccount(null, accountInfo);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }

        try {
            // should fail, since account doesn't exist yet
            manager.updateBusinessAccount(accountInfo.getId(), accountInfo);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }

        sourceOrg.getSettings().getBankAccounts().add(accountInfo);

        BankAccount newAccountInfo = new BankAccount();
        newAccountInfo.setId(accountInfo.getId());
        newAccountInfo.setType(BankAccount.Type.BANK_ACCOUNT_AU_NZ);
        newAccountInfo.setAccountNumber("Z");
        newAccountInfo.setDescription("Y");

        manager.updateBusinessAccount(newAccountInfo.getId(), newAccountInfo);

        BankAccount updated = ((OrgChangeRequestManagerImpl) manager)
                .getAccount(sourceOrg, accountInfo.getId());

        assertEquals(BankAccount.Type.BANK_ACCOUNT_AU_NZ, updated.getType());
        assertEquals("Z", updated.getAccountNumber());
        assertEquals("Y", updated.getDescription());
    }


    @Test
    public void testCancelOrganizationLink() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization sourceOrg = mocks.get(0);
        Organization targetOrg = mocks.get(1);

        // setup pending link
        this.linkOrganizations(sourceOrg, targetOrg);
        sourceOrg.getSettings().getRelationships().get(0)
            .setStatus(RelationshipInfo.Status.LINK_PENDING);
        targetOrg.getSettings().getRelationships().get(0)
            .setStatus(RelationshipInfo.Status.LINK_PENDING);

        // setup relationship payload
        RelationshipInfo payload = new RelationshipInfo();
        payload.setRelationship(Relationship.PARENT_OF);
        payload.setId(targetOrg.getId());
        // setup change request
        OrgChangeRequest request = new OrgChangeRequest();
        request.setOrgId(sourceOrg.getId());
        request.setRequestType(RequestType.LINK_ORGANIZATION);
        request.setPayload(MAPPER.convertValue(payload, Map.class));
        request.setStatus(Status.CONFIRMED);
        // save request
        request = changeRequestRepository.addItem(request);

        // update org rel with request id
        sourceOrg.getSettings().getRelationships().get(0).setRequestId(request.getId());
        targetOrg.getSettings().getRelationships().get(0).setRequestId(request.getId());
        sourceOrg = organizationRepository.updateItem(sourceOrg);
        targetOrg = organizationRepository.updateItem(targetOrg);

        OrgChangeRequestManager manager = getManager(targetOrg);
        // cancel link
        manager.cancelOrganizationLink(request);

        // refresh from database
        sourceOrg = organizationRepository.getItem(sourceOrg.getId());
        targetOrg = organizationRepository.getItem(targetOrg.getId());

        assertEquals(0, sourceOrg.getSettings().getRelationships().size());
        assertEquals(0, targetOrg.getSettings().getRelationships().size());
    }

    @Test
    public void testAddFinalRequestAction() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization org = mocks.get(0);

        OrgChangeRequestManager manager = getManager(org);
        OrgRequestAction action = new OrgRequestAction();

        // approve
        OrgChangeRequest r1 = new OrgChangeRequest();
        r1.setStatus(Status.CONFIRMED);
        r1 = changeRequestRepository.addItem(r1);

        action.setActionType(Type.APPROVE);
        r1 = manager.addFinalRequestAction(r1, action);
        assertEquals(Status.APPROVED, r1.getStatus());
        assertEquals(1, r1.getActions().size());
        assertEquals(action, r1.getActions().get(0));

        // reject
        OrgChangeRequest r2 = new OrgChangeRequest();
        r2.setStatus(Status.CONFIRMED);
        r2 = changeRequestRepository.addItem(r2);
        r2.setActions(null);

        action.setActionType(Type.REJECT);
        r2 = manager.addFinalRequestAction(r2, action);
        assertEquals(Status.REJECTED, r2.getStatus());
        assertEquals(1, r2.getActions().size());
        assertEquals(action, r2.getActions().get(0));

        // cancel
        OrgChangeRequest r3 = new OrgChangeRequest();
        r3.setStatus(Status.CONFIRMED);
        r3 = changeRequestRepository.addItem(r3);

        action.setActionType(Type.CANCEL);
        r3 = manager.addFinalRequestAction(r3, action);
        assertEquals(Status.ABANDONED, r3.getStatus());
        assertEquals(1, r3.getActions().size());
        assertEquals(action, r3.getActions().get(0));

        // cancel
        OrgChangeRequest r4 = new OrgChangeRequest();
        r4.setStatus(Status.CONFIRMED);
        r4 = changeRequestRepository.addItem(r4);

        action.setActionType(Type.RECALL);
        r4 = manager.addFinalRequestAction(r4, action);
        assertEquals(Status.CONFIRMED, r4.getStatus());
        assertEquals(1, r4.getActions().size());
        assertEquals(action, r4.getActions().get(0));

        // invalid (revoke)
        OrgChangeRequest r5 = new OrgChangeRequest();
        r5.setStatus(Status.CONFIRMED);
        r5 = changeRequestRepository.addItem(r5);

        action.setActionType(Type.REVOKE);
        try {
            r5 = manager.addFinalRequestAction(r5, action);
            assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }

        assertEquals(Status.CONFIRMED, r5.getStatus());
        assertEquals(0, r5.getActions().size());
    }

    @Test
    public void testAddNewcoAdminOrgChangeRequestAction() throws Exception {
        List<Organization> mocks = this.createMocks(2);
        Organization org = mocks.get(0);

        OrgChangeRequestManager manager = getManager(org);
        OrgRequestActionRequest action1 = new OrgRequestActionRequest();
        action1.setType(Type.RECALL);

        OrgChangeRequest request = new OrgChangeRequest();
        request.setOrgId(org.getId());
        request.setRequestType(RequestType.CHANGE_DETAILS);
        request.setStatus(Status.CONFIRMED);
        request.setActions(null);

        request = changeRequestRepository.addItem(request);

        request = manager.addNewcoAdminOrgChangeRequestAction(request.getId(), action1);
        assertEquals(Status.CONFIRMED, request.getStatus());
        assertEquals(1, request.getActions().size());

        OrgRequestActionRequest action2 = new OrgRequestActionRequest();
        action2.setType(Type.CANCEL);
        request = manager.addNewcoAdminOrgChangeRequestAction(request.getId(), action2);
        assertEquals(Status.ABANDONED, request.getStatus());
        assertEquals(2, request.getActions().size());

        OrgRequestActionRequest action3 = new OrgRequestActionRequest();
        action3.setType(Type.REJECT);
        request = manager.addNewcoAdminOrgChangeRequestAction(request.getId(), action3);
        assertEquals(Status.REJECTED, request.getStatus());
        assertEquals(3, request.getActions().size());

        OrgRequestActionRequest action4 = new OrgRequestActionRequest();
        action4.setType(Type.APPROVE);
        request = manager.addNewcoAdminOrgChangeRequestAction(request.getId(), action4);
        assertEquals(Status.APPROVED, request.getStatus());
        assertEquals(4, request.getActions().size());

        // invalid action
        OrgRequestActionRequest action5 = new OrgRequestActionRequest();
        action5.setType(Type.REVOKE);
        request = manager.addNewcoAdminOrgChangeRequestAction(request.getId(), action5);
        assertEquals(Status.APPROVED, request.getStatus());
        assertEquals(5, request.getActions().size());
    }

    protected void linkOrganizations(Organization sourceOrg, Organization targetOrg) {

        String relId = UUID.randomUUID().toString();

        // prep of relationships
        RelationshipInfo sourceRel = new RelationshipInfo();
        sourceRel.setRelationship(Relationship.PARENT_OF);
        sourceRel.setStatus(RelationshipInfo.Status.LINKED);
        sourceRel.setId(targetOrg.getId());
        sourceRel.setRequestId(relId);

        RelationshipInfo targetRel = new RelationshipInfo();
        targetRel.setRelationship(Relationship.SUBSIDIARY_OF);
        targetRel.setStatus(RelationshipInfo.Status.LINKED);
        targetRel.setId(sourceOrg.getId());
        targetRel.setRequestId(relId);

        sourceOrg.getSettings().setRelationships(new ArrayList<>());
        targetOrg.getSettings().setRelationships(new ArrayList<>());
        sourceOrg.getSettings().getRelationships().add(sourceRel);
        targetOrg.getSettings().getRelationships().add(targetRel);
    }

    protected Map<String, Object> convertToMap(Object o) throws Exception {
        return MAPPER.readValue(MAPPER.writeValueAsString(o), Map.class);
    }

    protected OrgChangeRequestManagerImpl getManager(Organization org) {
        BgxPrincipal principal = testHelper.createPrincipalMock(generator, provider, org);
        return (OrgChangeRequestManagerImpl) principal.getOrgChangeRequestManager();
    }

    protected Organization initializeOrganization(OrgProfileRequest profileRequest, String adminCert) {
        try {
        	
            if (profileRequest == null) {
                profileRequest = testHelper.createOrgProfileRequestMock();
            }

            Organization org = orgManager.create(profileRequest, adminCert);
            orgManager.updateApprovalModel(org.getId(), Name.SOLE_APPROVER);
            return org;
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialise organisation", e);
        }
    }

    protected List<Organization> createMocks(int count)
        throws Exception {
        List<Organization> mocks = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            Organization org = this.initializeOrganization(null, sampleAdminCerts.get(i % sampleAdminCerts.size()));
            mocks.add(org);
        }

        return mocks;
    }

}
