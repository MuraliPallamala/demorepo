package com.ibm.au.bgx.core.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


/**
 * Utility class to generate unique random strings
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    SessionIdentifierGenerator.class
})
public class SessionIdentifierGeneratorTest {

    @Autowired
    SessionIdentifierGenerator generator;

    @Test
    public void next() throws Exception {
        String first = generator.next();
        assertNotNull(first);
        assertNotEquals(first, generator.next());
    }

    @Test
    public void nextNumeric() throws Exception {
        String first = generator.nextNumeric(32);
        assertNotNull(first);
        assertEquals(32, first.length());
        assertNotEquals(first, generator.next());

        try {
            generator.nextNumeric(100);
        } catch (Exception e) {
            // expected exception
        }

        try {
            generator.nextNumeric(0);
        } catch (Exception e) {
            // expected exception
        }

        try {
            generator.nextNumeric(-1);
        } catch (Exception e) {
            // expected exception
        }
    }

}