package com.ibm.au.bgx.common.notification;

import com.ibm.au.bgx.model.notification.WebNotificationManager;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;

import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;

/**
 * @author Peter Ilfrich
 */
public class WebNotificationManagerImplTest {


    @Test
    public void testCopyWithoutReason() throws Exception {
        WebNotificationManagerImpl manager = new WebNotificationManagerImpl();

        WebNotification notification = new WebNotification();
        notification.setPayload(new HashMap<>());
        notification.getPayload().put(WebNotificationManager.PAYLOAD_REJECT_REASON, "Because");

        WebNotification copy = manager.cleanCopyNoRejectReason(notification);

        Assert.assertNull(copy.getPayload().get(WebNotificationManager.PAYLOAD_REJECT_REASON));
        Assert.assertNotNull(notification.getPayload().get(WebNotificationManager.PAYLOAD_REJECT_REASON));
    }
}
