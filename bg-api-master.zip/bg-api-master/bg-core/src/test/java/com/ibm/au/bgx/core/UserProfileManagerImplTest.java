package com.ibm.au.bgx.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.chain.ProfileChainMock;
import com.ibm.au.bgx.chain.TermsAndCondChainMock;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.common.KeyGeneratorImpl;
import com.ibm.au.bgx.common.audit.AuditManagerImpl;
import com.ibm.au.bgx.common.notification.WebNotificationManagerImpl;
import com.ibm.au.bgx.common.rest.filter.OrgProfileFilter;
import com.ibm.au.bgx.common.rest.filter.OrgProfileRequestFilter;
import com.ibm.au.bgx.common.rest.filter.OrgSettingsFilter;
import com.ibm.au.bgx.common.rest.filter.OrganizationFilter;
import com.ibm.au.bgx.common.rest.filter.UserProfileFilter;
import com.ibm.au.bgx.common.user.UserProfileManagerImpl;
import com.ibm.au.bgx.core.processor.UserTaskProcessorImpl;
import com.ibm.au.bgx.core.processor.item.UserRoleUpdateProcessor;
import com.ibm.au.bgx.core.processor.item.UserStatusUpdateProcessor;
import com.ibm.au.bgx.core.validation.BgxDataValidatorImpl;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.chain.profile.UserProfileManager;
import com.ibm.au.bgx.model.pojo.ApiKey;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.api.request.ApiKeyRequest;
import com.ibm.au.bgx.model.pojo.api.request.UserTaskRequest;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask.Status;
import com.ibm.au.bgx.model.repository.BatchProcessTaskRepository;
import com.ibm.au.bgx.queue.TransientQueueClient;
import com.ibm.au.bgx.repository.AuditEventRepositoryMock;
import com.ibm.au.bgx.repository.BatchProcessTaskRepositoryMock;
import com.ibm.au.bgx.repository.GxRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrgChangeRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrgProfileRepositoryMock;
import com.ibm.au.bgx.repository.OrgProfileRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrganizationRepositoryMock;
import com.ibm.au.bgx.repository.TermsAndCondRepositoryMock;
import com.ibm.au.bgx.repository.UserProfileRepositoryMock;
import com.ibm.au.bgx.repository.WebNotificationRepositoryMock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Unit tests for user profile manager
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    UserProfileManagerImpl.class,
    UserProfile.class,
    DefaultTestHelper.class,
    KeyGeneratorImpl.class,
    BatchProcessTaskRepositoryMock.class,
    UserTaskProcessorImpl.class,
    UserRoleUpdateProcessor.class,
    UserStatusUpdateProcessor.class,
    OrganizationManagerImpl.class,
    OrganizationRepositoryMock.class,
    UserProfileRepositoryMock.class,
    ApprovalModelCatalogImpl.class,
    OrgProfileRepositoryMock.class,
    BatchProcessTaskRepositoryMock.class,
    ProfileChainMock.class,
    WebNotificationManagerImpl.class,
    WebNotificationRepositoryMock.class,
    TransientQueueClient.class,
    AuditManagerImpl.class,
    AuditEventRepositoryMock.class,
    OrgChangeRequestRepositoryMock.class,
    OrgProfileRequestRepositoryMock.class,
    GxRequestRepositoryMock.class,
    OrganizationFilter.class,
    OrgProfileRequestFilter.class,
    UserProfileFilter.class,
    OrgProfileFilter.class,
    OrgSettingsFilter.class,
    BgxDataValidatorImpl.class,
    TermsAndCondManagerMock.class
})
public class UserProfileManagerImplTest {

    @Autowired
    private UserProfileManager manager;

    @Autowired
    DefaultTestHelper testHelper;

    @Autowired
    KeyGenerator generator;

    @Autowired
    UserTaskProcessorImpl userTaskProcessor;

    @Autowired
    BatchProcessTaskRepository taskRepository;

    @Test
    public void create() throws Exception {
        this.initUserProfile(null);
    }
    
    /**
     * <p>
     * This method test the implemented behaviour of {@link UserProfileManagerImpl#create(UserProfile)}
     * and {@link UserProfileManagerImpl#getByEmail(String, String)} with respect to the case sensitivity
     * of the email attribute.
     * </p>
     * <p>
     * The expected outcome is that searching by email should be treated as a case insensitive operation.
     * </p>
     */
    @Test
    public void testEmailCaseSensitivity() {
    	
    	// Test 1. We create a profile and with an upper
    	//         case email and we ensure that the email
    	//         is saved lower case.
    	//
    	UserProfile expected = this.getUserProfile();
    	
    	String email = expected.getEmail();
    	// we change the capitalization of the
    	// email.
    	//
    	expected.setEmail(email.toUpperCase());
    	
    	UserProfile actual = manager.create(expected);
    	
    	assertEquals("Email should be set lower case", email.toLowerCase(), actual.getEmail());
    	
    	
    	// Test 2. We retrieve the same entity and we
    	//         use the upper case email. We should
    	//         be able to retrieve the right profile.
    	//
    	actual = manager.getByEmail(expected.getPrimaryOrgId(), email);
    	
    	assertNotNull("Should be able to retrieve item with different capitalisation of email.", actual);
    	assertEquals("Should be able to retrieve item with differnt capitalisation of email", expected.getId(), actual.getId());
    	assertEquals("Email should be stored lower case", email.toLowerCase(), actual.getEmail());
    	
    }

    @Test
    public void delete() throws Exception {
        UserProfile up = this.initUserProfile(null);
        assertNotNull(up);

        manager.delete(up.getId());

        UserProfile deleted = manager.getById(up.getId());
        assertEquals(deleted.getStatus(), UserProfile.Status.DELETED);
    }


    @Test
    public void getById() throws Exception {

        List<UserProfile> mocks = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            UserProfile up = this.initUserProfile(null);
            assertNotNull(up);
            mocks.add(up);
        }

        UserProfile saved = manager.getById(mocks.get(2).getId());
        assertNotNull(saved);
        assertEquals(mocks.get(2), saved);
    }

    @Test
    public void getByEmail() throws Exception {

        List<UserProfile> mocks = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            UserProfile up = this.initUserProfile(null);
            assertNotNull(up);
            mocks.add(up);
        }

        UserProfile saved = manager
            .getByEmail(mocks.get(2).getPrimaryOrgId(), mocks.get(2).getEmail());
        assertNotNull(saved);
        assertEquals(mocks.get(2), saved);
    }

    @Test
    public void hasKey() throws Exception {

        List<UserProfile> mocks = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            UserProfile up = this.initUserProfile(null);
            assertNotNull(up);
            mocks.add(up);
        }

        boolean found = manager.hasKey(mocks.get(2).getCredentials().getKey());
        assertTrue(found);
    }

    @Test
    public void getByPrimaryOrgId() throws Exception {
        List<UserProfile> mocks = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            UserProfile up = testHelper.createUserProfileMock(generator, null);
            up.setPrimaryOrgId(UUID.randomUUID().toString());
            UserProfile saved = this.initUserProfile(up);
            assertNotNull(saved);
            mocks.add(saved);
        }

        List<UserProfile> records = manager.getByPrimaryOrgId(mocks.get(2).getPrimaryOrgId());
        assertNotNull(records);
        assertEquals(mocks.get(2), records.get(0));
    }

    @Test
    public void getByOrgRole() throws Exception {
        Map<String, UserProfile> mocks = new HashMap<>();
        for (int i = 0; i < 5; i++) {
            UserProfile up = testHelper.createUserProfileMock(generator, null);
            up.setPrimaryOrgId(UUID.randomUUID().toString());

            ArrayList<String> roleIds = new ArrayList<>();
            roleIds.add(UUID.randomUUID().toString());

            Map<String, List<String>> userRole = new HashMap<>();
            userRole.put(up.getPrimaryOrgId(), roleIds);
            up.setUserRoles(userRole);

            UserProfile saved = this.initUserProfile(up);
            assertNotNull(saved);
            mocks.put(saved.getPrimaryOrgId(), saved);
        }

        for (Entry<String, UserProfile> entry : mocks.entrySet()) {
            String orgId = entry.getKey();
            String role = entry.getValue().getUserRoles().get(orgId).get(0);

            List<UserProfile> records = manager.getByOrgRole(orgId, role);
            assertNotNull(records);
            assertEquals(entry.getValue(),records.get(0));
            assertTrue(records.get(0).getUserRoles().get(orgId).contains(role));
            break;
        }

    }


    @Test
    public void isAdminUser() {

        UserProfile userProfile = this.initUserProfile(null);
        userProfile.getUserRoles().get(userProfile.getPrimaryOrgId()).add(BgxConstants.ROLE_ADMIN);
        assertTrue(manager.isAdminUser(userProfile));
    }

    @Test
    public void isPrimaryUser() {

        UserProfile userProfile = this.initUserProfile(null);
        assertTrue(manager.isPrimaryUser(userProfile));
    }

    @Test
    public void addTask() throws Exception {
        UserProfile userProfile = this.initUserProfile(null);

        UserTaskRequest taskRequest = DefaultTestHelper.createUserRoleUpdateTaskRequest(null, null);

        BatchProcessTask batchTask = manager.addTask(userProfile, taskRequest);
        assertNotNull(batchTask);
        assertNotNull(batchTask.getId());
        assertNotNull(batchTask.getPayload().get(BgxConstants.TASK));
        assertEquals(Status.PENDING, batchTask.getStatus());

        assertTrue(manager.retrieveTasks(userProfile).size() > 0);
    }

    @Test
    public void deleteTask() throws Exception {
        UserProfile userProfile = this.initUserProfile(null);

        UserTaskRequest taskRequest = DefaultTestHelper.createUserRoleUpdateTaskRequest(null, null);

        BatchProcessTask batchTask = manager.addTask(userProfile, taskRequest);
        assertNotNull(batchTask);
        assertNotNull(batchTask.getId());
        assertNotNull(batchTask.getPayload().get(BgxConstants.TASK));
        assertEquals(Status.PENDING, batchTask.getStatus());

        try {
            manager.deleteTask(userProfile, batchTask.getId());
        } catch (IllegalStateException e) {
            // expected
        }

        BatchProcessTask processed = userTaskProcessor.process(batchTask);
        processed = taskRepository.updateItem(processed);
        assertEquals(Status.COMPLETED, processed.getStatus());


        manager.deleteTask(userProfile, batchTask.getId());

        assertNull(manager.getTask(userProfile, batchTask.getId()));
    }

    @Test
    public void generateApiKey() {

        ApiKeyRequest apiKeyRequest = new ApiKeyRequest();
        apiKeyRequest.setDescription(RandomStringUtils.randomAlphabetic(6));

        UserProfile userProfile = this.initUserProfile(null);
        ApiKey apiKey = manager.generateApiKey(userProfile.getId(), apiKeyRequest);
        assertNotNull(apiKey);

        UserProfile updated = manager.getById(userProfile.getId());
        assertNotNull(updated);
        assertNotNull(updated.getApiKeys());
        assertEquals(1, updated.getApiKeys().size());
        assertTrue(updated.getApiKeys().containsKey(apiKey.getId()));
    }

    @Test
    public void deleteApiKey() {

        ApiKeyRequest apiKeyRequest = new ApiKeyRequest();
        apiKeyRequest.setDescription(RandomStringUtils.randomAlphabetic(6));

        UserProfile userProfile = this.initUserProfile(null);
        ApiKey apiKey1 = manager.generateApiKey(userProfile.getId(), apiKeyRequest);

        UserProfile updated = manager.getById(userProfile.getId());
        assertTrue(updated.getApiKeys().containsKey(apiKey1.getId()) == true);

        // generate two more api keys
        for (int i = 0; i < 2; i++) {
            apiKeyRequest.setDescription(RandomStringUtils.randomAlphabetic(6));
            manager.generateApiKey(userProfile.getId(), apiKeyRequest);
        }

        updated = manager.getById(userProfile.getId());
        assertNotNull(updated);
        assertNotNull(updated.getApiKeys());
        assertEquals(3, updated.getApiKeys().size());

        UserProfile updated2 = manager.deleteApiKey(userProfile.getId(), apiKey1.getId());
        assertTrue(updated2.getApiKeys().containsKey(apiKey1.getId()) == false);
    }

    @Test
    public void getByApiKey() {

        List<UserProfile> mocks = new ArrayList<>();
        for (int i = 0; i < 3; i++) {

            ApiKeyRequest apiKeyRequest = new ApiKeyRequest();
            apiKeyRequest.setDescription(RandomStringUtils.randomAlphabetic(4));

            UserProfile userProfile = this.initUserProfile(null);
            manager.generateApiKey(userProfile.getId(), apiKeyRequest);

            UserProfile updated = manager.getById(userProfile.getId());
            mocks.add(updated);
        }

        ApiKey apiKey1 = mocks.get(0).getApiKeys().entrySet().iterator().next().getValue();
        assertNotNull(apiKey1);
        UserProfile matched = manager.getByApiKey(apiKey1.getKey());
        assertNotNull(matched);
        assertEquals(mocks.get(0).getId(), matched.getId());
    }

    @Test
    public void validatePassword() {
        assertFalse("aA9".matches(BgxConstants.PASSWORD_REGEX)); // not long
        assertFalse("aAsdfsdfsf!".matches(BgxConstants.PASSWORD_REGEX)); // no number
        assertFalse("aasdfsdfsf9!".matches(BgxConstants.PASSWORD_REGEX)); // no uppercase
        assertFalse("AAAAADDDDDD9!".matches(BgxConstants.PASSWORD_REGEX)); // no lowercase
        assertFalse("aAAAAADDDDDD9".matches(BgxConstants.PASSWORD_REGEX)); // no special character
        assertTrue("a A9aaaadddddd".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd!".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd\"".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd#".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd$".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd%".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd&".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd'".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd(".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd)".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd*".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd+".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd,".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd-".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd.".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd/".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd:".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd;".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd<".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd=".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd>".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd?".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd@".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd[".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd]".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd\\".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd^".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd_".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd`".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd{".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd|".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd}".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9aaaadddddd~".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("aA9  aaaadddddd~".matches(BgxConstants.PASSWORD_REGEX));
        assertTrue("a A9!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~".matches(BgxConstants.PASSWORD_REGEX));
    }


    private UserProfile initUserProfile(UserProfile userProfile) {
        if (userProfile == null) {

            userProfile = this.getUserProfile();
        }

        UserProfile saved = manager.create(userProfile);

        assertNotNull(saved);
        assertNotNull(saved.getId());
        assertEquals(userProfile.getPrimaryOrgId(), saved.getPrimaryOrgId());
        assertEquals(userProfile.getFirstName(), saved.getFirstName());
        assertEquals(userProfile.getLastName(), saved.getLastName());
        assertEquals(userProfile.getEmail(), saved.getEmail());

        return saved;
    }
    
    
    private UserProfile getUserProfile() {
    	
    	UserProfile userProfile = testHelper.createUserProfileMock(generator, null);

        userProfile.setPrimaryOrgId(UUID.randomUUID().toString());

        ArrayList<String> roleIds = new ArrayList<>();
        roleIds.add(BgxConstants.ROLE_PRIMARY);

        Map<String, List<String>> userRole = new HashMap<>();
        userRole.put(userProfile.getPrimaryOrgId(), roleIds);
        userProfile.setUserRoles(userRole);
        
        return userProfile;
    }
}