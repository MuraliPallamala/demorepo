package com.ibm.au.bgx.core.adapter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.tc.TcContentAdapter;
import com.ibm.au.bgx.core.chain.adapter.tc.TcEmbeddedContentAdapter;
import com.ibm.au.bgx.core.chain.adapter.tc.TcExternalContentAdapter;
import com.ibm.au.bgx.core.chain.adapter.tc.TermsAndCondAdapter;
import com.ibm.au.bgx.model.pojo.tc.TcEmbeddedContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.profile.Termsconditions.TermsConditions;
import com.ibm.au.bgx.model.util.JacksonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


/**
 * Unit tests for {@link TermsAndCondAdapter} class
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    TermsAndCondAdapter.class,
    TcContentAdapter.class,
    TcEmbeddedContentAdapter.class,
    TcExternalContentAdapter.class,
    TermsConditions.class,
    TimestampDataAdapter.class,
    DefaultTestHelper.class
})
public class TermsAndCondAdapterTest {

    @Autowired
    private TermsAndCondAdapter adapter;

    @Autowired
    private DefaultTestHelper testHelper;

    private static final ObjectMapper MAPPER = JacksonUtil.createObjectMapper();

    @Test
    public void toOnChainModel() throws Exception {

        TermsAndCond tc = testHelper.createTermsAndCondEmbeddedMock();
        TcEmbeddedContent inputTec = MAPPER
            .convertValue(tc.getContent().getData(), TcEmbeddedContent.class);

        TermsConditions converted = adapter.toOnChainModel(tc);
        assertEquals(tc.getId(), converted.getId());
        assertEquals(TcEmbeddedContentAdapter.encode(inputTec.getText()),
            converted.getContent().getEmbeddedData().getText());
        assertEquals(tc.getTitle(), converted.getTitle());

        try {
            adapter.toOnChainModel(null);
        } catch (Exception e) {
            assertTrue(e instanceof IllegalArgumentException);
        }
    }

    @Test
    public void toOffchainModel() throws Exception {
        TermsAndCond tc = testHelper.createTermsAndCondEmbeddedMock();
        TcEmbeddedContent inputTec = MAPPER
            .convertValue(tc.getContent().getData(), TcEmbeddedContent.class);
        TermsConditions tcChain = adapter.toOnChainModel(tc);

        TermsAndCond converted = adapter.toOffchainModel(tcChain);
        TcEmbeddedContent convertedTec = MAPPER
            .convertValue(converted.getContent().getData(), TcEmbeddedContent.class);

        assertEquals(tcChain.getId(), converted.getId());
        assertEquals(inputTec.getText(), convertedTec.getText());
        assertEquals(tcChain.getTitle(), converted.getTitle());

        try {
            adapter.toOffchainModel(null);
        } catch (Exception e) {
            assertTrue(e instanceof IllegalArgumentException);
        }

    }

}