package com.ibm.au.bgx.core.chain.adapter.gx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.guarantee.Gxs;
import com.ibm.au.bgx.model.util.JacksonUtil;

import org.junit.Assert;
import org.junit.Test;

import java.util.LinkedHashMap;
import java.util.Map;


public class GxPurposeDataAdapterTest {

    @Test
    public void testBackAndForthConversion() throws Exception {
        Map<String, Object> input = new LinkedHashMap<>();

        Map<String, Object> addressMap = new LinkedHashMap<>();
        addressMap.put("streetName", "15 Street Name");
        addressMap.put("postalCode", 3000);
        addressMap.put("isMainAddress", true);

        input.put("address", addressMap);
        input.put("propertyName", "Some Shop");
        input.put("shopNo", 15);
        input.put("value", 12.0);

        GxPurposeDataAdapter adapter = new GxPurposeDataAdapter();
        Map<String, Gxs.GxPurposeElement> onChain = adapter.toOnChainModel(input);

        Map<String, Object> output = adapter.toOffchainModel(onChain);

        ObjectMapper mapper = JacksonUtil.createObjectMapper();
        Assert.assertEquals(mapper.writeValueAsString(output), mapper.writeValueAsString(input));
    }
}
