package com.ibm.au.bgx;

import com.ibm.au.bgx.chain.ChannelGxChainMock;
import com.ibm.au.bgx.chain.GxChainMock;
import com.ibm.au.bgx.core.RuntimeBeanConfig;
import com.ibm.au.bgx.core.util.BgxPrincipalMock;
import com.ibm.au.bgx.core.util.CoreTestHelper;
import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.chain.ChannelGxChain;
import com.ibm.au.bgx.model.chain.GxChain;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.util.ArrayList;
import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@Configuration
public class TestBeanConfiguration extends RuntimeBeanConfig {

    @Autowired
    protected ApplicationContext applicationContext;

    @Autowired
    protected CoreTestHelper testHelper;

    @Autowired
    protected KeyGenerator keyGenerator;

    @Autowired
    protected BgxComponentProvider componentProvider;

    @Bean
    public Organization getOrganization() {
    	
    	testHelper.setupTermsAndConds();
        OrgProfile orgProfile = testHelper.createOrgProfileMock();
        Organization organization = new Organization();
        organization.setProfile(orgProfile);
        organization.setId(orgProfile.getId());

        return organization;
    }

    @Bean
    public UserProfile getUserProfile() {
        UserProfile userProfile = testHelper.createUserProfileMock(keyGenerator, getOrganization());
        return userProfile;
    }

    @Bean
    public BgxPrincipal getPrincipal() {
        Organization organization = getOrganization();
        UserProfile userProfile = testHelper.createUserProfileMock(keyGenerator, organization);

        SimpleGrantedAuthority authority = new SimpleGrantedAuthority("ROLE_ANOTHER");
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(authority);

        BgxPrincipalMock principal = new BgxPrincipalMock(userProfile, organization, authorities, true,
            false, false, false,
            componentProvider, applicationContext);

        return principal;
    }

    @Bean
    @Scope("prototype")
    @Override
    public GxChain gxChain(BgxPrincipal principal, String channelUserName) {
        GxChainMock gxChain = new GxChainMock();
        gxChain.init(principal, channelUserName);
        return gxChain;
    }

    @Bean
    @Scope("prototype")
    @Override
    public ChannelGxChain channelGxChain(BgxPrincipal principal, String channelUserName) {
        ChannelGxChainMock gxChain = new ChannelGxChainMock();
        gxChain.init(principal, channelUserName);
        return gxChain;
    }
}
