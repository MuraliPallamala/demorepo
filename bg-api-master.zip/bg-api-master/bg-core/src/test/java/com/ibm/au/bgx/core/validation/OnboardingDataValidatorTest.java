/**
 * 
 */
package com.ibm.au.bgx.core.validation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.AgreementInfo;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;
import com.ibm.au.bgx.model.validation.BgxDataValidator;

/**
 * Class <b>OnboardingDataValidatorTest</b>. This class extends {@link BgxDataValidatorTest} and
 * implements the tests for the additional behaviours implemented in the {@link OnboardingDataValidator}
 * class, which are related to the validation of organisation profile with specific entity types.
 * 
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    BgxDataValidatorImpl.class,
    DefaultTestHelper.class,
    TermsAndCondManagerMock.class
})
@TestPropertySource(locations="classpath:application-test.properties")
public class OnboardingDataValidatorTest extends BgxDataValidatorTest {

	@Autowired 
	protected DefaultTestHelper helper;
	
	@Autowired
	protected TermsAndCondManager tcManager;
	
	/**
	 * This is the auto-wired {@link BgxDataValidator} that we will be using
	 * as a source validator for the tested instance of {@link OnboardingDataValidator}.
	 */
	@Autowired
	protected BgxDataValidator dataValidator;
	
	/**
	 * This method tests the implemented behaviour of {@link OnboardingDataValidator#OnboardingDataValidator(BgxDataValidator)}.
	 * The expectation is that the method throws an {@link IllegalArgumentException} if the given argument is {@literal null}.
	 */
	@Test(expected=IllegalArgumentException.class)
	public void testConstructorWithNullArgument() {
	
		new OnboardingDataValidator(null);
	}
	
	/**
	 * This method tests the implemented behaviour of {@link OnboardingDataValidator#OnboardingDataValidator(BgxDataValidator)}
	 * when invoked with a non-{@literal null} validator implementation. The expectation is that the this instance is configured
	 * as source validator for the tested instance, and retrieved by {@literal OnboardingDataValidator#getSourceValidator()}.
	 */
	@Test
	public void testConstructorWithValidArgument() {
		
		OnboardingDataValidator proxy = new OnboardingDataValidator(this.dataValidator);
		BgxDataValidator actual = proxy.getSourceValidator();
		Assert.assertNotNull("OnboardingDataValidator.getSourceValidator() should NOT return null.", actual);
		Assert.assertEquals("OnboardingDataValidator.getSourceValidator() should return the instance passed to the constructor.", this.dataValidator, actual);
		
	}
	
	/**
	 * This method tests the implemented behaviour of the various methods of {@link OnboardingDataValidator}. The expectation is
	 * that these methods are proxy to the corresponding methods of the given instance of {@link BgxDataValidator} that has been
	 * configured as a source validator. The method creates a mock and ensures that the method of the mock validator when this is
	 * configured as a source validator to the tested instance are called, and that the tested proxy really acts as a proxy.
	 * 
	 * @throws ProfileChainException 	required by method invoked by the test.
	 */
	@Test
	public void testProxyBehaviour() throws ProfileChainException {
		
		
		// [CV] NOTE: we should also check, that we are actually using source validator as validator?
		//            but calling the validateXXX(...) methods and comparing the result, will only
		//            prove that they're both conformant to the interface contract. In order to do
		// 			  that we will be using a mock, where we can check whether the methods are actually
		//			  invoked.
		//

		BgxDataValidator source = Mockito.mock(BgxDataValidator.class);
		
		// this is a map where we store the value we expect to receive when invoking the source. The value
		// of null, for void methods is used to tell the test to not to throw any exception.
		//
		Map<String, Object> traps = new HashMap<>();
		traps.put("isValidProfile", new Boolean(true));
		traps.put("isValidBusinessId", new Boolean(true));
		traps.put("isValidAbn", new Boolean(true));
		traps.put("isValidAcn", new Boolean(true));
		traps.put("validateProfile", null);
		traps.put("validateAgreement", null);
		traps.put("validateBusinessId", null);
		traps.put("validateAbn", null);
		traps.put("validateAcn", null);
		
		// we now mock the isValidXXXX methods to return the value stored in the map.
		//
		Mockito.doAnswer((Answer<Boolean>) invocation -> { return (Boolean) traps.get("isValidAbn"); })
			   .when(source)
			   .isValidAbn(Mockito.anyString());
		
		Mockito.doAnswer((Answer<Boolean>) invocation -> { return (Boolean) traps.get("isValidAcn"); })
			   .when(source)
			   .isValidAcn(Mockito.anyString());
		
		Mockito.doAnswer((Answer<Boolean>) invocation -> { return (Boolean) traps.get("isValidBusinessId"); })
		       .when(source)
		       .isValidBusinessId(Mockito.anyString());
		
		Mockito.doAnswer((Answer<Boolean>) invocation -> { return (Boolean) traps.get("isValidProfile"); })
	       	   .when(source)
	       	   .isValidProfile(Mockito.any(), Mockito.any());
		
		// we now mock the methods validateXXX to conditionally throw an exception based
		// on what is in the trap map for the corresponding method...
		//
		Mockito.doAnswer((Answer<?>) invocation -> {
			
			Object zombie = traps.get("validateAbn");
			if (zombie != null && zombie instanceof DataValidationException) {
				
				throw (DataValidationException) zombie;
			}
			return null;
			
		}).when(source).validateAbn(Mockito.any());
		
		Mockito.doAnswer((Answer<?>) invocation -> {
			
			Object zombie = traps.get("validateAcn");
			if (zombie != null && zombie instanceof DataValidationException) {
				
				throw (DataValidationException) zombie;
			}
			return null;
			
		}).when(source).validateAcn(Mockito.anyString());
		Mockito.doAnswer((Answer<?>) invocation -> {
			
			Object zombie = traps.get("validateBusinessId");
			if (zombie != null && zombie instanceof DataValidationException) {
				
				throw (DataValidationException) zombie;
			}
			return null;
			
		}).when(source).validateBusinessId(Mockito.anyString());
		Mockito.doAnswer((Answer<?>) invocation -> {
			
			Object zombie = traps.get("validateProfile");
			if (zombie != null && zombie instanceof DataValidationException) {
				
				throw (DataValidationException) zombie;
			}
			return null;
			
		}).when(source).validateProfile(Mockito.any(), Mockito.any());
		Mockito.doAnswer((Answer<?>) invocation -> {
			
			Object zombie = traps.get("validateAgreement");
			if (zombie != null && zombie instanceof DataValidationException) {
				
				throw (DataValidationException) zombie;
			}
			return null;
			
		}).when(source).validateAgreement(Mockito.any(), Mockito.any());
		
		
		// we now build the instance subject to test
		//
		OnboardingDataValidator proxy = new OnboardingDataValidator(source);
		
		// Testing. We purposely create conditions that make sure that the values returned and exceptions we get are those we tell
		//          tell the proxy. This implies getting valid response for invalid business identifiers, profiles, and agreements.
		// 
		
		// Testing isValidAcn - ACN is empty.
		//
		String businessId = "";
		boolean expected = (boolean) traps.get("isValidAcn");
		boolean actual = proxy.isValidAcn(businessId);
		Assert.assertEquals("OnboardingDataValidator.isValidAcn(String) should return the value of <source>.isValidAcn(String). (=true)", expected, actual);
		
		businessId = this.helper.generateMockAcn();
		traps.put("isValidAcn", new Boolean(false));	
		expected = (boolean) traps.get("isValidAcn");
		actual = proxy.isValidAcn(businessId);
		Assert.assertEquals("OnboardingDataValidator.isValidAcn(String) should return the value of <source>.isValidAcn(String). (=false)", expected, actual);

		// Testing isValidAbn
		//
		businessId = "";
		expected = (boolean) traps.get("isValidAbn");
		actual = proxy.isValidAbn(businessId);
		Assert.assertEquals("OnboardingDataValidator.isValidAbn(String) should return the value of <source>.isValidAbn(String). (=true)", expected, actual);
		
		businessId = this.helper.generateMockAbn();
		traps.put("isValidAbn", new Boolean(false));
		expected = (boolean) traps.get("isValidAbn");
		actual = proxy.isValidAbn(businessId);		
		Assert.assertEquals("OnboardingDataValidator.isValidAbn(String) should return the value of <source>.isValidAbn(String). (=false)", expected, actual);

		// Testing isValidBusinessId
		//
		businessId = "";
		Assert.assertEquals("OnboardingDataValidator.isValidBusinessId(String) should return the value of <source>.isValidBusinessId(String). (=true)", expected, actual);
		expected = (boolean) traps.get("isValidBusinessId");
		actual = proxy.isValidBusinessId(businessId);
		
		businessId = this.helper.generateMockAcn();
		traps.put("isValidBusinessId", new Boolean(false));	
		expected = (boolean) traps.get("isValidBusinessId");
		actual = proxy.isValidBusinessId(businessId);
		Assert.assertEquals("OnboardingDataValidator.isValidBusinessId(String) should return the value of <source>.isValidBusinessId(String). (=false)", expected, actual);

		// Testing isValidProfile
		//
		OrgProfile dummy = new OrgProfile();
		dummy.setEntityType(EntityType.APPLICANT_OR_BENEFICIARY);
		expected = (boolean) traps.get("isValidProfile");
		actual = proxy.isValidProfile(dummy, Status.CONFIRMED);
		Assert.assertEquals("OnboardingDataValidator.isValidProfile(OrgProfile,Status) should return the value of <source>.isValidProfile(OrgProfile,Status). (=true)", expected, actual);
		
		dummy = this.helper.createOrgProfileMock();
		traps.put("isValidProfile", new Boolean(false));	
		expected = (boolean) traps.get("isValidProfile");
		actual = proxy.isValidProfile(dummy, Status.CONFIRMED);
		Assert.assertEquals("OnboardingDataValidator.isValidProfile(OrgProfile,Status) should return the value of <source>.isValidProfile(OrgProfile,Status). (=false)", expected, actual);

		
		// Testing validateProfile
		//
		dummy = new OrgProfile();
		dummy.setEntityType(EntityType.APPLICANT_OR_BENEFICIARY);
		try {
			
			proxy.validateProfile(dummy, Status.CONFIRMED);
		
		} catch(DataValidationException dvex) {
			
			Assert.fail("OnboardingDataValidator.validateProfile(OrgProfile,Status) should call <source>.validateProfile(OrgProfile,Status) (invalid).");
		}
		// we should have now an exception, and we check is the one
		// we put in the map. Regardless of valid data.
		//
		dummy = this.helper.createOrgProfileMock(); 
		traps.put("validateProfile", new DataValidationException("Invalid org profile."));
		try {
			
			proxy.validateProfile(dummy, Status.CONFIRMED);
			Assert.fail("OnboardingDataValidator.validateProfile(OrgProfile,Status) should call <source>.validateProfile(OrgProfile,Status) (valid).");
			
		} catch(DataValidationException dvex) {
			
			Assert.assertEquals("OnboardingDataValidator.validateProfile(OrgProfile,Status) should rethrow DataValidationException from <source>.validateProfile(OrgProfile,Status) (valid)", 
								(DataValidationException) traps.get("validateProfile"), 
								dvex);
		}
		
		
		// Testing validateAgreement
		//
		AgreementInfo ag = new AgreementInfo();
		try {
			
			proxy.validateAgreement(ag, Scope.PLATFORM);
		
		} catch(DataValidationException dvex) {
			
			Assert.fail("OnboardingDataValidator.validateAgreement(AgreementInfo,Scope) should call <source>.validateAgreement(AgreementInfo,Scope) (invalid).");
		}
		// we should have now an exception, and we check is the one
		// we put in the map. Regardless of valid data.
		//
		List<TermsAndCond> tcs = this.tcManager.getByScope(Scope.PLATFORM.toString());
		Assert.assertFalse("Precondition failed: there are no platform T&Cs.", tcs.isEmpty());
		ag.setTcId(tcs.get(0).getId());
		traps.put("validateAgreement", new DataValidationException("Invalid T&Cs."));
		try {
			
			proxy.validateAgreement(ag, Scope.PLATFORM);
			Assert.fail("OnboardingDataValidator.validateAgreement(AgreementInfo,Scope) should call <source>.validateAgreement(AgreementInfo,Scope) (valid).");
			
		} catch(DataValidationException dvex) {
			
			Assert.assertEquals("OnboardingDataValidator.validateAgreement(AgreementInfo,Scope) should rethrow DataValidationException from <source>.validateAgreement(AgreementInfo,Scope) (valid)", 
								(DataValidationException) traps.get("validateAgreement"), 
								dvex);
		}
		
		// Testing validateBusinessId
		//
		businessId = "";
		try {
			
			proxy.validateBusinessId(businessId);
		
		} catch(DataValidationException dvex) {
			
			Assert.fail("OnboardingDataValidator.validateBusinessId(String) should call <source>.validateBusinessId(String) (invalid).");
		}
		// we should have now an exception, and we check is the one
		// we put in the map. Regardless of valid data.
		//
		traps.put("validateBusinessId", new DataValidationException("Invalid Business Identifier."));
		try {
			
			proxy.validateBusinessId(businessId);
			Assert.fail("OnboardingDataValidator.validateBusinessId(String) should call <source>.validateBusinessId(String) (valid).");
			
		} catch(DataValidationException dvex) {
			
			Assert.assertEquals("OnboardingDataValidator.validateBusinessId(String) should rethrow DataValidationException from <source>.validateBusinessId(String) (valid)", 
								(DataValidationException) traps.get("validateBusinessId"), 
								dvex);
		}
		
		// Testing validateAbn
		//
		businessId = "";
		try {
			
			proxy.validateAbn(businessId);
		
		} catch(DataValidationException dvex) {
			
			Assert.fail("OnboardingDataValidator.validateAbn(String) should call <source>.validateAbn(String) (invalid).");
		}
		// we should have now an exception, and we check is the one
		// we put in the map. Regardless of valid data.
		//
		traps.put("validateAbn", new DataValidationException("Invalid ABN."));
		try {
			
			proxy.validateAbn(businessId);
			Assert.fail("OnboardingDataValidator.validateAbn(String) should call <source>.validateAbn(String) (valid).");
			
		} catch(DataValidationException dvex) {
			
			Assert.assertEquals("OnboardingDataValidator.validateAbn(String) should rethrow DataValidationException from <source>.validateAbn(String) (valid)", 
								(DataValidationException) traps.get("validateAbn"), 
								dvex);
		}
		
		// Testing validateAcn
		//
		businessId = "";
		try {
			
			proxy.validateAcn(businessId);
		
		} catch(DataValidationException dvex) {
			
			Assert.fail("OnboardingDataValidator.validateAcn(String) should call <source>.validateAcn(String) (invalid).");
		}
		// we should have now an exception, and we check is the one
		// we put in the map. Regardless of valid data.
		//
		traps.put("validateAcn", new DataValidationException("Invalid ACN."));
		try {
			
			proxy.validateAcn(businessId);
			Assert.fail("OnboardingDataValidator.validateAcn(String) should call <source>.validateAcn(String) (valid).");
			
		} catch(DataValidationException dvex) {
			
			Assert.assertEquals("OnboardingDataValidator.validateAcn(String) should rethrow DataValidationException from <source>.validateAcn(String) (valid)", 
								(DataValidationException) traps.get("validateAcn"), 
								dvex);
		}
		
	}
	
	/**
	 * This method tests the implemented behaviour of {@link OnboardingDataValidator#validateProfile(OrgProfile, Status)} when 
	 * invoked with valid {@link OrgProfile} instance and explores the behaviour of the method as the value set for the entity
	 * type changes. The expectation is that a {@link DataValidationException} is thrown when the entity type is set to {@link 
	 * EntityType#CONSORTIUM} and {@link EntityType#ISSUER} but not when the entity type is {@link EntityType#APPLICANT_OR_BENEFICIARY}.
	 */
	@Test
	public void testValidateProfileForEntityType() {
		
		// we get a CONFIRMED profile.
		//
		OrgProfile profile = this.helper.createOrgProfileMock();
		profile.setEntityType(EntityType.APPLICANT_OR_BENEFICIARY);
		
		BgxDataValidator validator = this.getValidator();
		
		try {
			
			validator.validateProfile(profile, Status.CONFIRMED);
			
		} catch(DataValidationException dvex) {
			
			Assert.fail("OnboardingDataValidator.validate(OrgProfile[entityType=APPLICANT_OR_BENEFICIARY], Status) should not throw DataValidationException.");
		}
		
		
		for(EntityType type : new EntityType[] { EntityType.CONSORTIUM, EntityType.ISSUER }) {
			
			profile.setEntityType(type);
			
			try {
				validator.validateProfile(profile, Status.CONFIRMED);
				Assert.fail(String.format("OnboardingDataValidator.validate(OrgProfile[entityType=%1$s], Status) should not throw DataValidationException.", type));
				
			} catch(DataValidationException dvex) {
				
				// ok good to go.
			}
		}
	}

	
	/**
	 * This method tests the implemented behaviour of {@link OnboardingDataValidator#isValidProfile(OrgProfile, Status)} when 
	 * invoked with valid {@link OrgProfile} instance and explores the behaviour of the method as the value set for the entity
	 * type changes. The expectation is the method returns {@literal false} when the entity type is set to {@link EntityType#CONSORTIUM} 
	 * and {@link EntityType#ISSUER}, while it returns {@literal true} when the entity type is {@link EntityType#APPLICANT_OR_BENEFICIARY}.
	 */
	@Test
	public void testIsValidProfileForEntityType() {
		
		// we get a CONFIRMED profile.
		//
		OrgProfile profile = this.helper.createOrgProfileMock();
		profile.setEntityType(EntityType.APPLICANT_OR_BENEFICIARY);
		
		BgxDataValidator validator = this.getValidator();
	
			
		boolean isValid = validator.isValidProfile(profile, Status.CONFIRMED);
		Assert.assertTrue("OnboardingDataValidator.isValidProfile(OrgProfile[entityType=APPLICANT_OR_BENEFICIARY], Status) should be valid.", isValid);
		
		
		
		for(EntityType type : new EntityType[] { EntityType.CONSORTIUM, EntityType.ISSUER }) {
			
			profile.setEntityType(type);
			isValid = validator.isValidProfile(profile, Status.CONFIRMED);
			Assert.assertFalse(String.format("OnboardingDataValidator.validate(OrgProfile[entityType=%1$s], Status) should NOT be valid.", type), isValid);
			
		}
	}
	
	
	
	/**
	 * This method returns the current instance of {@link BgxDataValidator} used for
	 * the purpose of testing. This method is callback declared by the base test class
	 * used to perform the generic test suite that every implementation of the interface
	 * {@link BgxDataValidator} needs to implement.
	 * 
	 * @return 	an instance of {@link OnboardingDataValidator} configured with the injected
	 * 			{@link BgxDataValidator} implementation.
	 */
	@Override
	protected BgxDataValidator getValidator() {
		
		return new OnboardingDataValidator(this.dataValidator);
	}

	/**
	 * This method returns the injected instance of {@link DefaultTestHelper} which is used
	 * to setup conditions for the tests. This method is a callback declared by the base test
	 * class to implement the test suite that every implementation of {@link BgxDataValidator}
	 * should pass.
	 * 
	 * @return an instance of {@link DefaultTestHelper} as injected into the test class.
	 */
	@Override
	protected DefaultTestHelper getTestHelper() {
		
		return this.helper;
	}


	/**
	 * This method returns the injected instance of {@link TermsAndCondManager} which is used
	 * to setup conditions for the tests. This method is a callback declared by the base test
	 * class to implement the test suite that every implementation of {@link BgxDataValidator}
	 * should pass.
	 * 
	 * @return an instance of {@link TermsAndCondManager} as injected into the test class.
	 */
	@Override
	protected TermsAndCondManager getTermsAndCondManager() {
		
		return this.tcManager;
	}

}
