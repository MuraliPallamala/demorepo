/**
 * 
 */
package com.ibm.au.bgx.core.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.core.validation.BgxDataValidatorImpl.TermsAndCondResolveMode;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.AgreementInfo;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;
import com.ibm.au.bgx.model.repository.TermsAndCondRepository;
import com.ibm.au.bgx.model.validation.BgxDataValidator;

/**
 * Class <b>BgxDataValidatorImplTest</b>. Specialises the {@link BgxDataValidatorTest} 
 * to provide a concrete instance of {@link BgxDataValidator} which is of type {@link 
 * BgxDataValidatorImpl}.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    BgxDataValidatorImpl.class,
    DefaultTestHelper.class,
    TermsAndCondManagerMock.class
})
@TestPropertySource(locations="classpath:application-test.properties")
public class BgxDataValidatorImplTest extends BgxDataValidatorTest {
	
	/**
	 * A {@link BgxDataValidatorImpl} instance that is autowired by the test runtime.
	 */
	@Autowired
	protected BgxDataValidatorImpl bgxDataValidator;
	
	/**
	 * A {@link TermsAndCondRepository} implementation that is used to store the 
	 * terms and conditions that are available for validation.
	 */
	@Autowired
	protected TermsAndCondManager tcManager;
	
	/**
	 * A {@link CoreTestHelper} that is used to facilitate the setup of mocks and
	 * conditions for the tests.
	 */
	@Autowired
	protected DefaultTestHelper helper;
	
	/**
	 * This method tests the implementation of {@link BgxDataValidatorImpl#init()} when
	 * the validation is configured in lazy mode. The expectation is that the component
	 * will not resolve the terms and conditions.
	 */
	@Test
	public void testInitWithLazyMode() {
		
		String expectedPlatformTcKey = this.platformTCs.getTitle();
		String expectedUserTcKey = this.userTCs.getTitle();
		
		// [CV] NOTE: we don't use the instance returned by getValidator() because such
		//            instance is injected and configured with the application-test.properties
		//            and more importantly it has already triggered the invocation of init().
		//
		BgxDataValidatorImpl validator = this.getValidatorWith(TermsAndCondResolveMode.BY_TITLE, true, expectedPlatformTcKey, expectedUserTcKey, this.getTermsAndCondManager());
				
		validator.init();
		
		Assert.assertEquals("BgxValidatorImpl.init() should not resolve PLATFORM terms and conditions identifiers, when configured in LAZY mode.", expectedPlatformTcKey, validator.platformTcKey);
		Assert.assertEquals("BgxValidatorImpl.init() should not resolve USER terms and conditions identifiers, when configured in LAZY mode.", expectedUserTcKey, validator.userTcKey);
		
		
		// Test 2. We now set the terms and conditions to valid titles
		//         and invoke the validateAgreement(....) method and 
		//         we should get the two references resolved.
		//
		AgreementInfo agreement = new AgreementInfo();
		agreement.setTcId(this.platformTCs.getId());
		validator.validateAgreement(agreement, Scope.PLATFORM);
		
		Assert.assertEquals("BgxValidatorImpl.validateAgreement(...) should resolve PLATFORM terms and conditions identifiers, when configured in LAZY mode.", this.platformTCs.getId(), validator.platformTcKey);
		Assert.assertEquals("BgxValidatorImpl.validateAgreement(...) should resolve USER terms and conditions identifiers, when configured in LAZY mode.", this.userTCs.getId(), validator.userTcKey);
		
	}
	
	/**
	 * <p>
	 * This method tests the implemented behaviour of {@link  BgxDataValidatorImpl#init()} when
	 * the validation is configured without lazy mode. The expectation is that the invocation 
	 * of the method causes the values of {@link BgxDataValidatorImpl#platformTcKey} and {@link 
	 * BgxDataValidatorImpl#userTcKey} to be resolved, according to the resolution mode. If the
	 * resolution mode is {@link TermsAndCondResolveMode#BY_ID} the identifier are cross-checked
	 * with the terms and conditions manager, if the mode is {@link TermsAndCondResolveMode#BY_TITLE}
	 * these are mapped to the corresponding identifiers.
	 * </p>
	 * <p>
	 * The method tests the following scenarios:
	 * <ul>
	 * <li>resolution mode is {@link TermsAndCondResolveMode#BY_TITLE}: we expect to have the correct
	 * identifiers after the invocation of the method.</li>
	 * <li>resolution mode is {@link TermsAndCondResolveMode#BY_ID}: we expect the provision of 
	 * invalid identifiers to cause a {@link DataValidationException}.</li>
	 * </ul>
	 */
	@Test
	public void testInitWithoutLazyMode() {
		
		String expectedPlatformTcKey = this.platformTCs.getTitle();
		String expectedUserTcKey = this.userTCs.getTitle();
		
		
		// Test 1 - we test with resolution mode by title, we should have valid identifiers after
		//          the invocation of the method.
		//
		
		// [CV] NOTE: we don't use the instance returned by getValidator() because such
		//            instance is injected and configured with the application-test.properties
		//            and more importantly it has already triggered the invocation of init().
		//
		BgxDataValidatorImpl validator = this.getValidatorWith(TermsAndCondResolveMode.BY_TITLE, false, expectedPlatformTcKey, expectedUserTcKey, this.getTermsAndCondManager());
		
		validator.init();
		
		Assert.assertEquals("BgxValidatorImpl.init() should resolve PLATFORM terms and conditions titles, when NOT configured in LAZY mode.", this.platformTCs.getId(), validator.platformTcKey);
		Assert.assertEquals("BgxValidatorImpl.init() should resolve USER terms and conditions titles, when NOT configured in LAZY mode.", this.userTCs.getId(), validator.userTcKey);
		
		
		// Test 2 - we now test the behaviour of init when the resolution is by identifier. 
		//          We simply change the resolution mode to BY_ID, and the existing titles
		//          become invalid identifiers... :-)
		//
		validator.platformTcKey = expectedPlatformTcKey;
		validator.userTcKey = expectedUserTcKey;
		validator.resolveMode = TermsAndCondResolveMode.BY_ID;
		
		try {
			
			validator.init();
			Assert.fail("BgxValidatorImpl.init() should cross-validate identifiers for terms and conditions, when NOT configured in LAZY mode.");
			
		} catch(DataValidationException dvex) {
			
			// ok good, we now check that the values
			// are still the originals. 
			
			Assert.assertEquals("BgxValidatorImpl.init(): post-condition failed, expected unresolved platform terms and conditions.", expectedPlatformTcKey, validator.platformTcKey);
			Assert.assertEquals("BgxValidatorImpl.init(): post-condition failed, expected unresolved user terms and conditions.", expectedUserTcKey, validator.userTcKey);
		}
	}
	
	/**
	 * This method tests the implemented behaviour of the terms and conditions resolution logic, 
	 * via the invocation of the {@link BgxDataValidatorImpl#init()} method when the validator
	 * is configured in lazy mode. The method is invoked in a combination of configurations that
	 * are invalid, and the expectation is that a {@link DataValidationException} is thrown. More
	 * specifically the explored test conditions are the following:
	 * <ul>
	 * <li>submission of correct identifiers but with wrong scope.</li>
	 * <li>submission of terms and conditions titles that multiple terms and conditions documents</li>
	 * <li>submission of wrong titles, when resolution mode is configured by title.</li>
	 * </ul>
	 * 
	 * @throws ProfileChainException 	this exception is only declared because some of the methods
	 * 									of the {@link TermsAndCondManager} interface used in the test
	 * 									declared such exception.
	 */
	@Test
	public void testInitWithoutLazyModeAndInvalidConditions() throws ProfileChainException {
		
		String expectedPlatformTcKey = this.platformTCs.getId();
		String expectedUserTcKey = this.userTCs.getId();
		TermsAndCondManager manager = this.getTermsAndCondManager();
		
		// Test 1.a Resolution by ID, platform TC reference points to a user terms and conditions.
		//
		BgxDataValidatorImpl validator = this.getValidatorWith(TermsAndCondResolveMode.BY_ID, false, expectedUserTcKey, expectedUserTcKey, manager);
		try {
			
			validator.init();
			Assert.fail("BgxDataValidatorImpl.init() should throw DataValidationException if the configured platform TCs reference points to a user terms and condition.");
			
		} catch(DataValidationException dvex) {
			
			// ok good to go.
		}
		
		// Test 1.b Resolution by ID, user TC reference points to a platform terms and conditions.
		//
		validator = this.getValidatorWith(TermsAndCondResolveMode.BY_ID, false, expectedPlatformTcKey, expectedPlatformTcKey, manager);
		try {
			
			validator.init();
			Assert.fail("BgxDataValidatorImpl.init() should throw DataValidationException if the configured user TCs reference points to a platform terms and condition.");
			
		} catch(DataValidationException dvex) {
			
			// ok good to go.
		}
		
		expectedPlatformTcKey = this.platformTCs.getTitle();
		expectedUserTcKey = this.userTCs.getTitle();
		
		manager = Mockito.mock(TermsAndCondManager.class);
		
		
		// Test 2.a Multiple terms and conditions that match the given title.
		//          for platform terms and condition.
		//
		List<TermsAndCond> pTcs = new ArrayList<TermsAndCond>();
		pTcs.add(this.platformTCs);
		pTcs.add(this.platformTCs);
		
		List<TermsAndCond> uTcs = new ArrayList<TermsAndCond>();
		uTcs.add(this.userTCs);
		
		Mockito.when(manager.getByTitle(this.userTCs.getTitle()))
		       .thenReturn(uTcs);
		Mockito.when(manager.getByTitle(this.platformTCs.getTitle()))
		       .thenReturn(pTcs);
		
		validator = this.getValidatorWith(TermsAndCondResolveMode.BY_TITLE, false, expectedPlatformTcKey, expectedUserTcKey, manager);
		
		try {
			
			validator.init();
			Assert.fail(String.format("BgxDataValidatorImpl.init() should throw DataValidationException if there are multiple instances mapping the same platform terms and conditions title (value: %1$s).",
									  this.platformTCs.getTitle()));
			
		} catch(DataValidationException dvex) {
			
			// ok good to go.
		}
		
		// Test 2.b Multiple terms and conditions that match the given title.
		//          for user terms and condition.
		//
		
		pTcs.remove(0);
		uTcs.add(this.userTCs);
		
		validator = this.getValidatorWith(TermsAndCondResolveMode.BY_TITLE, false, expectedPlatformTcKey, expectedUserTcKey, manager);
		
		try {
			
			validator.init();
			Assert.fail(String.format("BgxDataValidatorImpl.init() should throw DataValidationException if there are multiple instances mapping the same user terms and conditions title (value: %1$s).",
									  this.userTCs.getTitle()));
			
		} catch(DataValidationException dvex) {
			
			// ok good to go...
		}
		
		// Test 3.a No matching terms and condition for the platform terms and conditions.
		//
		manager = this.getTermsAndCondManager();
		validator = this.getValidatorWith(TermsAndCondResolveMode.BY_TITLE, false, "mozumbo", this.userTCs.getTitle(), manager);
		
		try {
			
			validator.init();
			Assert.fail("BgxDataValidatorImpl.init() should throw DataValidationExceptino if there is no matching platform terms and condition title.");
			
		} catch(DataValidationException dvex) {
			
			// ok good to go...
		}
		
		// Test 3.b No matching terms and condition for the platform terms and conditions.
		//
		manager = this.getTermsAndCondManager();
		validator = this.getValidatorWith(TermsAndCondResolveMode.BY_TITLE, false, this.platformTCs.getTitle(), "mozumbo", manager);
		
		try {
			
			validator.init();
			Assert.fail("BgxDataValidatorImpl.init() should throw DataValidationExceptino if there is no matching user terms and condition title.");
			
		} catch(DataValidationException dvex) {
			
			// ok good to go...
		}
		
		
	}
	
	/**
	 * This method tests the implemented behaviour of the terms and condition resolution logic via
	 * the invocation of the {@link BgxDataValidatorImpl#init()} in presence of an underlying profile
	 * chain error. The expectation is that a {@link DataValidationException} is thrown.
	 * 
	 * @throws ProfileChainException 	this exception is only declared because some of the methods
	 * 									of the {@link TermsAndCondManager} interface used in the test
	 * 									declared such exception.
	 */
	@Test
	public void testInitWithoutLazyModeAndChainError() throws ProfileChainException {
		
		ProfileChainException pcex = new ProfileChainException("Unexpected ledger error.");
		
		TermsAndCondManager manager = Mockito.mock(TermsAndCondManager.class);
		Mockito.when(manager.getById(Mockito.anyString()))
		       .thenThrow(pcex);

		// [CV] NOTE: we don't use the instance returned by getValidator() because such
		//            instance is injected and configured with the application-test.properties
		//            and more importantly it has already triggered the invocation of init().
		//
		BgxDataValidatorImpl validator = this.getValidatorWith(TermsAndCondResolveMode.BY_ID, false, this.platformTCs.getId(), this.userTCs.getId(), manager);
		
		try {
			
			validator.init();
			Assert.fail("BgxDataValidatorImpl.init() should throw a DataValidationException in case of an underlying ProfileChainException.");
			
		} catch(DataValidationException dvex) {
			
			Assert.assertNotNull("BgxDataValidatorImpl.init() should throw a DataValidationException that wraps the underlying ProfileChainException in case of ledger error.", dvex.getCause());
			Assert.assertEquals("BgxDataValidatorImpl.init() should throw a DataValidationException that returns the ProfileChainException thrown by the terms and conditions manager.", pcex, dvex.getCause());
			
		}
		
		
		// [CV] NOTE: we have two possible blocks that cause ProfileChainException. We 
		//            now force the chain error during cache refresh, thus covering the
		//  		  other catch block for ProfileChainException. This is mainly to
		//            ensure highest test coverage.
		
		Mockito.doThrow(pcex)
			   .when(manager)
			   .refreshCacheFromChain();
		
		// force cache refresh of the
		// manager.
		//
		validator.tcRefreshed=false;
		
		try {
			
			validator.init();
			Assert.fail("BgxDataValidatorImpl.init() should throw a DataValidationException in case of an underlying ProfileChainException.");
			
		} catch(DataValidationException dvex) {
			
			Assert.assertNotNull("BgxDataValidatorImpl.init() should throw a DataValidationException that wraps the underlying ProfileChainException in case of ledger error.", dvex.getCause());
			Assert.assertEquals("BgxDataValidatorImpl.init() should throw a DataValidationException that returns the ProfileChainException thrown by the terms and conditions manager.", pcex, dvex.getCause());
			
		}
	}
	
	/**
	 * This method tests the implemented behaviour of {@link BgxDataValidatorImpl#init()} when the validator
	 * instance is configured with {@literal null} or empty references to the terms and conditions. The expected
	 * behaviour is that after initialisation, the references are set to {@literal null}.
	 */
	@Test
	public void testInitWithMissingReferences() {
		
		TermsAndCondManager manager = this.getTermsAndCondManager();
		BgxDataValidatorImpl validator = this.getValidatorWith(TermsAndCondResolveMode.BY_ID, false, null, null, manager);
		
		validator.init();
		Assert.assertNull("BgxDataValidatorImpl.init() leave the platform terms and conditions reference to NULL, when NOT configured in LAZY mode.", validator.platformTcKey);
		Assert.assertNull("BgxDataValidatorImpl.init() leave the user terms and conditions reference to NULL, when NOT configured in LAZY mode.", validator.userTcKey);
		
		validator = this.getValidatorWith(TermsAndCondResolveMode.BY_ID, false, "", "", manager);
		
		validator.init();
		Assert.assertNull("BgxDataValidatorImpl.init() normalise the platform terms and conditions reference to NULL, when NOT configured in LAZY mode.", validator.platformTcKey);
		Assert.assertNull("BgxDataValidatorImpl.init() normalise the user terms and conditions reference to NULL, when NOT configured in LAZY mode.", validator.userTcKey);
		
	}
	
	/**
	 * This method tests the implemented behaviour of {@link BgxDataValidatorImpl#validateAgreement(AgreementInfo, Scope)} 
	 * when the validator is configured with {@literal null} references to the expected terms and conditions. The expected
	 * behaviour is that the validation will only limit itself to verifying the scope, but it won't be verify whether the
	 * given terms and condition identifier within an agreement, is the desired one. The tested scenarios are:
	 * <ul>
	 * <li>an {@link AgreementInfo} containing a non empty terms and condition, with the wrong scope will still cause {@link DataValidationException}</li>
	 * <li>an {@link AgreementInfo} containing a non empty terms and condition, with the right scope will not cause {@link DataValidationException}</li>
	 * </ul>
	 * 
	 * @throws ProfileChainException 	this exception is only declared because some of the methods of the {@link 
	 * 									TermsAndCondManager} interface used in the test declared such exception.
	 */
	@Test
	public void testValidateAgreementWithMissingReferences() throws ProfileChainException {
		
		TermsAndCondManager manager = this.getTermsAndCondManager();
		BgxDataValidatorImpl validator = this.getValidatorWith(TermsAndCondResolveMode.BY_ID, false, null, null, manager);
		validator.init();
		
		
		// Test 1. Invalid Terms and condition (not existing) should still cause DataValidationException.
		//
		AgreementInfo agreement = new AgreementInfo();
		agreement.setTcId("mozumbo");
		
		
		for (Scope scope : new Scope[] { Scope.PLATFORM, Scope.USER }) {
			
			try {
				
				validator.validateAgreement(agreement, scope);
				Assert.fail(String.format("BgxDataValidatorImpl.validateAgreement(AgreementInfo[tcId=<wrong>], %1$s) should throw DataValidationException.", scope));
				
			} catch(DataValidationException dvex) {
				
				// good to go...
			}
		}
		
		// Test 2. Terms and condition of the right scope but not the expected one should not cause validation error.
		//
		TermsAndCond fakePlatformTCs = new TermsAndCond();
		fakePlatformTCs.setScope(Scope.PLATFORM);
		fakePlatformTCs.setId("01000");
		fakePlatformTCs.setTitle("The Fake Platform Terms and Conditions");
		
		TermsAndCond fakeUserTCs = new TermsAndCond();
		fakeUserTCs.setScope(Scope.USER);
		fakeUserTCs.setId("02000");
		fakeUserTCs.setTitle("The Fake User Terms and Conditions");

		
		List<TermsAndCond> tcList = new ArrayList<>();
		tcList.add(this.platformTCs);
		tcList.add(this.userTCs);
		tcList.add(fakePlatformTCs);
		tcList.add(fakeUserTCs);
		
		
		manager = Mockito.mock(TermsAndCondManager.class);
		
		Mockito.when(manager.getByScope(Scope.PLATFORM.toString()))
			   .thenReturn(tcList.stream()
					   			 .filter(tc -> tc.getScope().equals(Scope.PLATFORM))
					   			 .collect(Collectors.toList()));
		
		Mockito.when(manager.getByScope(Scope.USER.toString()))
		   	   .thenReturn(tcList.stream()
		   			   			 .filter(tc -> tc.getScope().equals(Scope.USER))
		   			   			 .collect(Collectors.toList()));
		
		
		Mockito.when(manager.getById(this.platformTCs.getId())).thenReturn(tcList.get(0));
		Mockito.when(manager.getById(this.userTCs.getId())).thenReturn(tcList.get(1));
		Mockito.when(manager.getById(fakePlatformTCs.getId())).thenReturn(tcList.get(2));
		Mockito.when(manager.getById(fakeUserTCs.getId())).thenReturn(tcList.get(3));
		
		validator = this.getValidatorWith(TermsAndCondResolveMode.BY_ID, true, null, null, manager);
		
		agreement.setTcId(this.platformTCs.getId());
		validator.validateAgreement(agreement, Scope.PLATFORM);
		agreement.setTcId(fakePlatformTCs.getId());
		validator.validateAgreement(agreement, Scope.PLATFORM);
		

		agreement.setTcId(this.userTCs.getId());
		validator.validateAgreement(agreement, Scope.USER);
		agreement.setTcId(fakeUserTCs.getId());
		validator.validateAgreement(agreement, Scope.USER);
	}
	

	/**
	 * Gets a concrete implementation of {@link BgxDataValidator}.
	 * 
	 * @return a {@link BgxDataValidatorImpl} instance.
	 */
	@Override
	protected BgxDataValidator getValidator() {

		return this.bgxDataValidator;
	}
	
	/**
	 * This method provides an implementation to the base abstract
	 * version and returns the injected manager implementation for
	 * the terms and conditions.
	 * 
	 * @return 	a {@link TermsAndCondManager} implementation that
	 * 			has been injected into the current instance.
	 */
	@Override
	protected TermsAndCondManager getTermsAndCondManager() {
		
		return this.tcManager;
	}
	
	/**
	 * This method provides an implementation of the base abstract
	 * version and returns the injected implementation of {@link 
	 * DefaultTestHelper}.
	 * 
	 * @return  the {@link DefaultTestHelper} implementation that has
	 *			been injected into the current instance.
	 */
	@Override
	protected DefaultTestHelper getTestHelper() {
		
		return this.helper;
	}
	
	/**
	 * <p>
	 * This is a utility factory method that creates an instance of {@link BgxDataValidatorImpl} and
	 * configures it with the given attributes. This method is specifically used to explore those
	 * test scenarios that would be otherwise difficult to test with the injected {@link BgxDataValidatorImpl}
	 * instance that is already configured with the setup defines in <i>application-test.properties</i>.
	 * </p>
	 * <p>
	 * The method defers the creation of the instance to {@link BgxDataValidatorImplTest#getValidatorInstance()}
	 * so that inherited test classes, can provide the more specialised instance.
	 * </p>
	 * 
	 * @param mode			a {@link TermsAndCondResolveMode} value that determines the resolution mode
	 * 						of the validator.
	 * @param resolveLazy	a {@literal boolean} that indicates whether the validator should be configured
	 * 						to lazily resolve the terms and conditions references ({@literal true}) or not
	 * 						({@literal false}).
	 * @param platformTcKey a {@link String} containing the configured platform terms and conditions reference.
	 * @param userTcKey		a {@link String} containing the configured user terms and conditions reference.
	 * @param manager		a {@link TermsAndCondManager} implementation.
	 * 
	 * 
	 * @return	a {@link BgxDataValidatorImpl} configured according to the given parameters.
	 */
	protected BgxDataValidatorImpl getValidatorWith(TermsAndCondResolveMode mode, boolean resolveLazy, String platformTcKey, String userTcKey, TermsAndCondManager manager) {
		
		BgxDataValidatorImpl bgxv = this.getValidatorInstance();
		bgxv.resolveLazy = resolveLazy;
		bgxv.resolveMode = mode;
		bgxv.platformTcKey = platformTcKey;
		bgxv.userTcKey = userTcKey;
		bgxv.tcManager = manager;
		
		return bgxv;
	}
	
	/**
	 * This method returns an instance of {@link BgxDataValidatorImpl}. This method is defined for
	 * inherited test classes so that it is possible to provide an instance inheriting from {@link 
	 * BgxDataValidatorImpl} which is the specific type being tested by the inherited classes.
	 *  
	 * @return	this implementation returns an instance of {@link BgxDataValidatorImpl}.
	 */
	protected BgxDataValidatorImpl getValidatorInstance() {
		
		return new BgxDataValidatorImpl();
	}

}
