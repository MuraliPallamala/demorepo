package com.ibm.au.bgx.core.purpose;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.au.bgx.model.chain.PurposeFormatChain;
import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.purpose.MaxValueConstraint;
import com.ibm.au.bgx.model.pojo.purpose.MinValueConstraint;
import com.ibm.au.bgx.model.pojo.purpose.NewPurposeField;
import com.ibm.au.bgx.model.pojo.purpose.NewPurposeFormat;
import com.ibm.au.bgx.model.pojo.purpose.OneOfConstraint;
import com.ibm.au.bgx.model.pojo.purpose.PatternConstraint;
import com.ibm.au.bgx.model.pojo.purpose.PurposeField;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFieldConstraint;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;
import com.ibm.au.bgx.model.purpose.PurposeFormatManager;
import com.ibm.au.bgx.model.util.JacksonUtil;
import com.ibm.au.bgx.purpose.PurposeFormatChainMock;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Peter Ilfrich
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
        PurposeFormatChainMock.class,
        PurposeFormatManagerImpl.class,
})
public class PurposeFormatManagerImplTest {

    @Autowired
    PurposeFormatManager purposeFormatManager;

    @Autowired
    PurposeFormatChain chain;

    @Test
    public void testRegExpValidation() {
        PurposeFormatManagerImpl impl = new PurposeFormatManagerImpl();

        PatternConstraint pc = new PatternConstraint();
        pc.setPattern("/^[0-9]{4,4}$/");
        impl.validatePatternConstraint("3000", pc);

        pc.setPattern("/^[0-9]{4,4}$");
        impl.validatePatternConstraint("3000", pc);

        pc.setPattern("^[0-9]{4,4}$/");
        impl.validatePatternConstraint("3000", pc);

        pc.setPattern("^[0-9]{4,4}$");
        impl.validatePatternConstraint("3000", pc);

        try {
            pc.setPattern("^[0-9]{4,4}$");
            impl.validatePatternConstraint("30000", pc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }

        try {
            impl.validatePatternConstraint("300", pc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }

        try {
            impl.validatePatternConstraint(5000, pc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }
    }

    @Test
    public void testMinValueConstraint() {
        PurposeFormatManagerImpl impl = new PurposeFormatManagerImpl();

        MinValueConstraint mc = new MinValueConstraint();
        mc.setMinValue(5);
        mc.setIncludeMin(false);

        impl.validateMinValueConstraint(6, mc);

        try {
            impl.validateMinValueConstraint(5, mc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }

        mc.setIncludeMin(true);
        impl.validateMinValueConstraint(5, mc);

        try {
            mc.setMinValue(6);
            impl.validateMinValueConstraint(5, mc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }

        impl.validateMinValueConstraint(6.0, mc);
        mc.setIncludeMin(false);

        try {
            impl.validateMinValueConstraint(6.0, mc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }

        try {
            impl.validateMinValueConstraint("abc", mc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }
    }

    @Test
    public void testMaxValueConstraint() {
        PurposeFormatManagerImpl impl = new PurposeFormatManagerImpl();

        MaxValueConstraint mc = new MaxValueConstraint();
        mc.setMaxValue(5);
        mc.setIncludeMax(false);

        impl.validateMaxValueConstraint(4, mc);

        try {
            impl.validateMaxValueConstraint(5, mc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }

        mc.setIncludeMax(true);
        impl.validateMaxValueConstraint(5, mc);

        try {
            mc.setMaxValue(6);
            impl.validateMaxValueConstraint(7, mc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }

        impl.validateMaxValueConstraint(6.0, mc);
        mc.setIncludeMax(false);

        try {
            impl.validateMaxValueConstraint(6.0, mc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }

        try {
            impl.validateMaxValueConstraint("abc", mc);
            Assert.assertFalse(true);
        } catch (DataValidationException iae) {
            // expected
        }
    }

    @Test
    public void testOneOfConstraint() {
        PurposeFormatManagerImpl manager = new PurposeFormatManagerImpl();
        OneOfConstraint constraint = new OneOfConstraint();
        constraint.setAvailableValues(Arrays.asList(new String[]{"foo", "bar"}));

        manager.validateOneOfConstraint("foo", constraint);
        manager.validateOneOfConstraint("bar", constraint);

        try {
            manager.validateOneOfConstraint("fail", constraint);
            Assert.assertTrue(false);
        } catch (DataValidationException iae) {
            // expected
        }

        try {
            manager.validateOneOfConstraint(5, constraint);
            Assert.assertTrue(false);
        } catch (DataValidationException iae) {
            // expected
        }
    }

    @Test
    public void testStringifier() throws IOException {
        ObjectMapper mapper = JacksonUtil.createObjectMapper();
        PurposeFormat format = mapper.readValue(this.getClass().getResourceAsStream("/purpose-format-stringifier.json"), PurposeFormat.class);
        format.setStringTemplate("${details.name}, ${details.number}, ${details.owner}, ${comment}, ${value}");

        Map<String, Object> purpose = new HashMap<>();
        purpose.put("value", 2.0);
        purpose.put("comment", "bar");
        Map<String, Object> detailsMap = new HashMap<>();
        detailsMap.put("name", "foo");
        detailsMap.put("number", 5);
        detailsMap.put("owner", true);
        purpose.put("details", detailsMap);

        PurposeFormatManagerImpl manager = new PurposeFormatManagerImpl();
        String result = manager.stringifyPurpose(format, purpose);
        Assert.assertEquals("foo, 5, Yes, bar, 2.0", result);
    }

    @Test
    public void testCreateWithResolveReferences() throws Exception {
        // prepare old format to reference
        PurposeFormat oldFormat = new PurposeFormat();
        oldFormat.setId(UUID.randomUUID().toString());
        oldFormat.setName("test");
        oldFormat.setLabel("foo");
        oldFormat.setActive(true);
        oldFormat.setFields(new ArrayList<>());
        PurposeField oldSubField = this.createPurposeField(PurposeField.Type.STRING, "sub");
        OneOfConstraint subFieldConstraint = new OneOfConstraint();
        subFieldConstraint.setAvailableValues(Arrays.asList(new String[]{"x", "y"}));
        oldSubField.setConstraints(Arrays.asList(new PurposeFieldConstraint[]{subFieldConstraint}));
        PurposeField oldF1 = this.createPurposeField(PurposeField.Type.OBJECT, "complex");
        oldF1.setSubFields(Arrays.asList(new PurposeField[]{oldSubField}));
        PurposeField oldF2 = this.createPurposeField(PurposeField.Type.NUMBER, "number");
        oldFormat.getFields().addAll(Arrays.asList(new PurposeField[]{oldF1, oldF2}));

        // create old format
        chain.create(oldFormat);

        // create request with field refs
        NewPurposeFormat req = new NewPurposeFormat();
        req.setName("test2");
        req.setLabel("bar");
        req.setStringTemplate("string");
        req.setActive(true);
        req.setFields(new ArrayList<>());
        NewPurposeField f1 = this.createPurposeRequestField(PurposeField.Type.REFERENCE, "oldF1Sub", "test.complex.sub");
        NewPurposeField f2 = this.createPurposeRequestField(PurposeField.Type.REFERENCE, "oldF2", "test.number");
        NewPurposeField standardField = this.createPurposeRequestField(PurposeField.Type.STRING, "bla", null);
        req.getFields().addAll(Arrays.asList(new NewPurposeField[]{f1, f2, standardField}));

        purposeFormatManager.validate(req);
        PurposeFormat format = purposeFormatManager.create(req);

        Assert.assertEquals(req.getStringTemplate(), format.getStringTemplate());
        Assert.assertEquals(3, format.getFields().size());
        Assert.assertNotEquals(oldFormat.getId(), format.getId());
        boolean foundConstraintCopy = false;
        for (PurposeField field : format.getFields()) {
            if (field.getName().equals("sub")) {
                foundConstraintCopy = true;
                Assert.assertEquals(oldSubField.getConstraints(), field.getConstraints());
            }
        }
        Assert.assertTrue(foundConstraintCopy);

        req.getFields().get(1).setFieldReference("test3.number");
        List<DataValidationException> exceptions = purposeFormatManager.validate(req);
        Assert.assertEquals(1, exceptions.size());

        format = purposeFormatManager.create(req);
        // 2nd field should be null
        Assert.assertNull(format.getFields().get(1));

        // missing reference to purpose format
        f2.setFieldReference("number");
        f1.setFieldReference("test.not.existing");
        exceptions = purposeFormatManager.validate(req);
        Assert.assertEquals(2, exceptions.size());
    }

    @Test
    public void testCacheHandling() throws Exception {
        PurposeFormat format = new PurposeFormat();
        format.setId("foo");
        format.setName("bar");

        chain.create(format);
        PurposeFormat res1 = purposeFormatManager.get("foo");
        Assert.assertEquals(format, res1);

        ((PurposeFormatChainMock) chain).currentException = new ProfileChainException("Chain no longer operational");

        PurposeFormat res2 = purposeFormatManager.get("foo");
        Assert.assertEquals(res1, res2);

        Assert.assertTrue(((PurposeFormatManagerImpl) purposeFormatManager).cache.containsKey("foo"));

        // should not work due to exception
        purposeFormatManager.refreshCache("foo");
        // no longer there
        Assert.assertFalse(((PurposeFormatManagerImpl) purposeFormatManager).cache.containsKey("foo"));

        ((PurposeFormatChainMock) chain).currentException = null;
        purposeFormatManager.refreshCache("foo");
        Assert.assertTrue(((PurposeFormatManagerImpl) purposeFormatManager).cache.containsKey("foo"));
        PurposeFormat res3 = purposeFormatManager.get("foo");
        Assert.assertEquals(res1, res3);
    }

    @Test
    public void testParseConstraintRaw() throws Exception {
        PurposeFormatManagerImpl manager = new PurposeFormatManagerImpl();
        ObjectMapper mapper = JacksonUtil.createObjectMapper();

        MinValueConstraint mvc1 = new MinValueConstraint();
        mvc1.setMinValue(5);
        mvc1.setIncludeMin(true);

        try {
            PurposeFieldConstraint parsedMvc1 = manager.parseConstraint(mapper.readValue(mapper.writeValueAsString(mvc1), LinkedHashMap.class));
            Assert.assertTrue(false);
        } catch (DataValidationException ia) {
            // expected due to missing type=
        }

        // now fix it and parse again
        mvc1.setConstraintType(PurposeFieldConstraint.ConstraintType.MIN_VALUE);
        PurposeFieldConstraint parsedMvc1 = manager.parseConstraint(mapper.readValue(mapper.writeValueAsString(mvc1), LinkedHashMap.class));
        Assert.assertEquals(mvc1, parsedMvc1);

        MaxValueConstraint mvc2 = new MaxValueConstraint();
        mvc2.setConstraintType(PurposeFieldConstraint.ConstraintType.MAX_VALUE);
        mvc2.setMaxValue(15);
        mvc2.setIncludeMax(false);

        PurposeFieldConstraint parsedMvc2 = manager.parseConstraint(mapper.readValue(mapper.writeValueAsString(mvc2), LinkedHashMap.class));
        Assert.assertEquals(mvc2, parsedMvc2);

        OneOfConstraint ooc = new OneOfConstraint();
        ooc.setConstraintType(PurposeFieldConstraint.ConstraintType.ONE_OF);
        ooc.setAvailableValues(Arrays.asList(new String[]{"a", "b"}));

        PurposeFieldConstraint parsedOoc = manager.parseConstraint(mapper.readValue(mapper.writeValueAsString(ooc), LinkedHashMap.class));
        Assert.assertEquals(ooc, parsedOoc);

        PatternConstraint pc = new PatternConstraint();
        pc.setConstraintType(PurposeFieldConstraint.ConstraintType.PATTERN);
        pc.setPattern("foobar");

        PurposeFieldConstraint parsedPc = manager.parseConstraint(mapper.readValue(mapper.writeValueAsString(pc), LinkedHashMap.class));
        Assert.assertEquals(pc, parsedPc);
    }


    private PurposeField createPurposeField(PurposeField.Type type, String name) {
        PurposeField field = new PurposeField();
        field.setName(name);
        field.setType(type);
        return field;
    }

    private NewPurposeField createPurposeRequestField(PurposeField.Type type, String name, String optionalReference) {
        NewPurposeField field = new NewPurposeField();
        field.setName(name);
        field.setType(type);
        if (optionalReference != null) {
            field.setFieldReference(optionalReference);
        }
        return field;
    }
}
