package com.ibm.au.bgx.core.chain.adapter.purpose;

import com.ibm.au.bgx.model.pojo.purpose.Appearance;
import com.ibm.au.bgx.model.shared.Common;

import org.junit.Assert;
import org.junit.Test;

import java.math.BigInteger;

/**
 * @author Peter Ilfrich
 */
public class PurposeFieldAppearanceDataAdapterTest {

    @Test
    public void testBackAndForthConversion() {
        PurposeFieldAppearanceDataAdapter adapter = new PurposeFieldAppearanceDataAdapter();

        Appearance offchain = new Appearance();
        offchain.setTooltip("foo");
        offchain.setLabel("bar");
        offchain.setWidth(BigInteger.valueOf(6));

        Common.PurposeFieldAppearance onchain = adapter.toOnChainModel(offchain);

        Appearance back = adapter.toOffchainModel(onchain);
        Assert.assertNull(back.getRenderAs());

        offchain.setRenderAs(Appearance.RenderAs.ADDRESS);
        onchain = adapter.toOnChainModel(offchain);
        Assert.assertEquals(onchain.getRenderAs(), Common.PurposeFieldAppearanceRenderAs.ADDRESS);
        back = adapter.toOffchainModel(onchain);
        Assert.assertEquals(back.getRenderAs(), Appearance.RenderAs.ADDRESS);
        Assert.assertEquals("bar", back.getLabel());
        Assert.assertEquals("foo", back.getTooltip());
        Assert.assertEquals(BigInteger.valueOf(6), back.getWidth());
    }
}
