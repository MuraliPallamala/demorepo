package com.ibm.au.bgx.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.common.KeyGeneratorImpl;
import com.ibm.au.bgx.common.rest.ApiConstants;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.chain.profile.OrgProfileRequestManager;
import com.ibm.au.bgx.model.exception.DataNotFoundException;
import com.ibm.au.bgx.model.pojo.AgreementInfo;
import com.ibm.au.bgx.model.pojo.BaseRequest.RequestType;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.Credentials;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.ReferrerInfo;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest.Type;
import com.ibm.au.bgx.model.pojo.api.request.OnboardingRequest;
import com.ibm.au.bgx.model.pojo.api.response.OnboardingResponse;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.repository.OrgProfileRequestRepositoryMock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Unit tests for OrgProfileManagerImpl
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    OrgProfileRequestManagerImpl.class,
    OrgProfileRequest.class,
    OrgProfileRequestRepositoryMock.class,
    KeyGeneratorImpl.class,
    DefaultTestHelper.class
})
public class OrgProfileRequestManagerImplTest {

    @Autowired
    OrgProfileRequestManagerImpl manager;

    @Autowired
    KeyGenerator generator;

    @Autowired
    DefaultTestHelper testHelper;

    @Test
    public void create() throws Exception {
        this.initiateMockProfileRequest(null);
    }

    @Test
    public void approve() throws Exception {

        OrgProfileRequest req = this.createConfirmedRequest(this.initiateMockProfileRequest(null));

        // add complete actions for company and contact
        OrgRequestAction companyApproval = new OrgRequestAction();
        companyApproval.setActionType(Type.VERIFY);
        Map<String, Object> companyPayload = new HashMap<>();
        companyPayload.put(OrgProfileRequestManager.KEY_VERIFY_OBJECT,
            OrgProfileRequestManager.VALUE_VERIFY_COMPANY);
        companyApproval.setPayload(companyPayload);

        OrgRequestAction contactApproval = new OrgRequestAction();
        contactApproval.setActionType(Type.VERIFY);
        Map<String, Object> contactPayload = new HashMap<>();
        contactPayload.put(OrgProfileRequestManager.KEY_VERIFY_OBJECT,
            OrgProfileRequestManager.VALUE_VERIFY_PRIMARY_CONTACT);
        contactApproval.setPayload(contactPayload);

        OrgRequestAction adminApproval = new OrgRequestAction();
        adminApproval.setActionType(Type.VERIFY);
        Map<String, Object> adminPayload = new HashMap<>();
        adminPayload.put(OrgProfileRequestManager.KEY_VERIFY_OBJECT,
            OrgProfileRequestManager.VALUE_VERIFY_ADMIN_CONTACT);
        adminApproval.setPayload(adminPayload);

        try {
            manager.complete(req.getId());
            throw new Exception("Should not be able to complete at this point");
        } catch (RuntimeException re) {
            assertTrue(true);
        }

        OrgProfileRequest saved = manager.addOnboardingAction(req.getId(), companyApproval);
        assertNotNull(saved);

        try {
            manager.complete(req.getId());
            throw new Exception("Should not be able to complete at this point");
        } catch (RuntimeException re) {
            assertTrue(true);
        }

        saved = manager.addOnboardingAction(req.getId(), contactApproval);
        assertNotNull(saved);

        try {
            manager.complete(req.getId());
            throw new Exception("Should not be able to complete at this point");
        } catch (RuntimeException re) {
            assertTrue(true);
        }

        saved = manager.addOnboardingAction(req.getId(), adminApproval);
        assertNotNull(saved);

        saved = manager.complete(req.getId());
        assertEquals(Status.APPROVED, saved.getStatus());
    }

    @Test
    public void checkApprovalPrecondition() throws Exception {
        OrgProfileRequest req = new OrgProfileRequest();
        OrgProfile profile = new OrgProfile();
        profile.setContacts(new ArrayList<>());
        req.setProfile(profile);
        req.setActions(new ArrayList<>());
        assertFalse(manager.checkApprovalPrecondition(req));

        // add primary contact
        ContactInfo primaryContact = new ContactInfo();
        primaryContact.setRoles(new ArrayList<>());
        primaryContact.getRoles().add(BgxConstants.ROLE_PRIMARY);
        profile.getContacts().add(primaryContact);
        assertFalse(manager.checkApprovalPrecondition(req));

        // add complete actions for company and contact
        OrgRequestAction companyApproval = new OrgRequestAction();
        companyApproval.setActionType(Type.VERIFY);
        Map<String, Object> companyPayload = new HashMap<>();
        companyPayload.put(OrgProfileRequestManager.KEY_VERIFY_OBJECT,
            OrgProfileRequestManager.VALUE_VERIFY_COMPANY);
        companyApproval.setPayload(companyPayload);
        req.getActions().add(companyApproval);
        assertFalse(manager.checkApprovalPrecondition(req));

        OrgRequestAction contactApproval = new OrgRequestAction();
        contactApproval.setActionType(Type.VERIFY);
        Map<String, Object> contactPayload = new HashMap<>();
        contactPayload.put(OrgProfileRequestManager.KEY_VERIFY_OBJECT,
            OrgProfileRequestManager.VALUE_VERIFY_PRIMARY_CONTACT);
        contactApproval.setPayload(contactPayload);
        req.getActions().add(contactApproval);
        assertTrue(manager.checkApprovalPrecondition(req));
    }

    @Test
    public void getById() throws Exception {
        OrgProfileRequest req = testHelper.createOrgProfileRequestMock();

        OrgProfileRequest saved = manager.create(req);

        OrgProfileRequest saved2 = manager.getById(saved.getId());

        assertNotNull(saved2);
        assertEquals(saved, saved2);
    }

    @Test
    public void getByOnboardingKey() throws Exception {
        OrgProfileRequest req = this.initiateMockProfileRequest(null);
        OrgProfileRequest saved = manager
            .getByOnboardingKey(req.getCredentials().getKey(), req.getCredentials().getToken());

        assertNotNull(saved);
        assertEquals(req, saved);

        assertNull(manager.getByOnboardingKey(saved.getCredentials().getKey(), "INVALID"));
    }

    @Test
    public void refreshSignupCredentials() throws Exception {
        OrgProfileRequest req = this.initiateMockProfileRequest(null);
        Credentials credentials = req.getCredentials();

        Thread.sleep(10);
        OrgProfileRequest saved = manager.refreshCredentials(req.getId());
        assertNotNull(saved.getCredentials());

        Instant createdAt = saved.getCredentials().getCreatedAt();

        assertTrue(createdAt.isAfter(credentials.getCreatedAt()));

        assertNotEquals(credentials.getToken(), saved.getCredentials().getToken());
        assertEquals(credentials.getKey(), saved.getCredentials().getKey());

    }

    @Test
    public void getForReview() throws Exception {
        OrgProfileRequest newReq = this.initiateMockProfileRequest(null);
        List<OrgProfileRequest> records = manager.getForReview(Status.CONFIRMED);
        for (OrgProfileRequest req : records) {
            assertNotEquals(Status.DRAFTED, req.getStatus());
        }

        this.createConfirmedRequest(newReq);
        records = manager.getForReview(Status.CONFIRMED);
        assertNotEquals(0, records.size());
        for (OrgProfileRequest req : records) {
            assertNotEquals(Status.DRAFTED, req.getStatus());
        }
    }

    @Test
    public void update() throws Exception {

        OrgProfileRequest req = this.initiateMockProfileRequest(null);

        req.getProfile().setEntityName(UUID.randomUUID().toString());
        OrgProfileRequest saved = manager.update(req);

        assertNotNull(saved);
        assertNotNull(saved.getProfile());
        assertEquals(req.getProfile().getEntityName(), saved.getProfile().getEntityName());
    }

    @Test
    public void reject() throws Exception {
        OrgProfileRequest confirmedRequest = this
            .createConfirmedRequest(this.initiateMockProfileRequest(null));
        OrgProfileRequest req = this.createRejectedRequest(confirmedRequest);

        assertNotNull(req);
        assertNotNull(req.getStatus());
        assertEquals(Status.REJECTED, req.getStatus());
    }

    @Test
    public void getAll() throws Exception {

        List<OrgProfileRequest> mocks = this.createMocks(3);
        List<OrgProfileRequest> records = manager.getAll();
        assertNotNull(records);
        assertTrue(!records.isEmpty());
        assertTrue(records.size() >= mocks.size());
    }

    @Test
    public void getByBusinessId() throws Exception {
        List<OrgProfileRequest> mocks = this.createMocksWithReferrerInfo(3, null);

        OrgProfileRequest req = mocks.get(1);
        List<OrgProfileRequest> records = manager
            .getByBusinessId(req.getReferrer().getId(), req.getProfile().getBusinessId());

        assertNotNull(records);
        assertTrue(!records.isEmpty());
        assertEquals(req, records.get(0));

        records = manager
            .getByBusinessId(req.getReferrer().getId(), req.getProfile().getBusinessId(),
                req.getStatus());

        assertNotNull(records);
        assertTrue(!records.isEmpty());
        assertEquals(req, records.get(0));
    }

    @Test
    public void refreshCredentials() throws Exception {
        OrgProfileRequest req = this.initiateMockProfileRequest(null);

        // clone
        Credentials credentials = new Credentials();
        credentials.setToken(req.getCredentials().getToken());
        credentials.setKey(req.getCredentials().getKey());
        credentials.setCreatedAt(req.getCredentials().getCreatedAt());

        OrgProfileRequest saved = manager.refreshCredentials(req.getId());
        assertNotNull(saved);
        assertNotEquals(credentials.getToken(), saved.getCredentials().getToken());
    }

    @Test
    public void validateTokenForKey() throws Exception {
        OrgProfileRequest req = this.initiateMockProfileRequest(null);

        assertFalse(manager.validateTokenForKey(req.getCredentials().getKey(), "INVALID"));
        assertTrue(manager
            .validateTokenForKey(req.getCredentials().getKey(), req.getCredentials().getToken()));
    }

    @Test
    public void validateTokenForId() throws Exception {
        OrgProfileRequest req = this.initiateMockProfileRequest(null);

        assertFalse(manager.validateTokenForId(req.getId(), "INVALID"));
        assertTrue(manager.validateTokenForId(req.getId(), req.getCredentials().getToken()));
    }

    @Test
    public void deleteProfileRequest() throws Exception {
        OrgProfileRequest req = this.initiateMockProfileRequest(null);
        manager.deleteProfileRequest(req);

        OrgProfileRequest deletedReq = null;
        try {
            deletedReq = manager.getById(req.getId());
        } catch (DataNotFoundException e) { // this is thrown by CouchDb implementation

        }

        assertNull(deletedReq);
    }

    @Test
    public void getByReferrerIdAndStatus() throws Exception {

        List<OrgProfileRequest> mocks = this.createMocksWithReferrerInfo(3, null);

        OrgProfileRequest req = mocks.get(1);
        List<OrgProfileRequest> records = manager
            .getByReferrerIdAndStatus(req.getReferrer().getId(), req.getStatus());

        assertNotNull(records);
        assertTrue(!records.isEmpty());
        assertEquals(1, records.size());
        assertEquals(req, records.get(0));

        records = manager.getByReferrerIdAndStatus(req.getReferrer().getId(), Status.CONFIRMED);
        assertNotNull(records);
        assertTrue(records.isEmpty());
    }

    @Test
    public void getByReferrerId() throws Exception {
        List<OrgProfileRequest> mocks = this.createMocksWithReferrerInfo(3, null);

        OrgProfileRequest req = mocks.get(1);
        List<OrgProfileRequest> records = manager.getByReferrerId(req.getReferrer().getId());

        assertNotNull(records);
        assertTrue(!records.isEmpty());
        assertEquals(1, records.size());
        assertEquals(req, records.get(0));

        records = manager.getByReferrerId("INVALID");
        assertNotNull(records);
        assertTrue(records.isEmpty());
    }

    @Test
    public void getByReferralToken() throws Exception {
        List<OrgProfileRequest> mocks = this.createMocksWithReferrerInfo(3, null);

        OrgProfileRequest req = mocks.get(1);
        OrgProfileRequest record = manager.getByReferralToken(req.getReferrer().getReferrerToken());

        assertNotNull(record);
        assertEquals(req, record);

        record = manager.getByReferralToken("INVALID");
        assertNull(record);
    }

    @Test
    public void voidProfileRequest() throws Exception {
        List<OrgProfileRequest> mocks = this.createMocksWithReferrerInfo(3, null);

        final OrgProfileRequest req = mocks.get(0);
        manager.voidProfileRequest(req);

        OrgProfileRequest voidReq = manager.getById(req.getId());
        assertNotNull(voidReq);
        assertEquals(Status.ABANDONED, voidReq.getStatus());
    }

    @Test
    public void createWithOnboardingResponse() throws Exception {

        OrgProfileRequest req = testHelper.createOrgProfileRequestMock();

        ReferrerInfo referrerInfo = new ReferrerInfo();
        referrerInfo.setId(UUID.randomUUID().toString());
        referrerInfo.setReferrerToken(UUID.randomUUID().toString());
        referrerInfo.setReferralUrl("http://localhost:8080");
        req.setReferrer(referrerInfo);

        AgreementInfo agreementInfo = new AgreementInfo();
        agreementInfo.setTcId("TC01");

        OnboardingRequest onboardingRequest = new OnboardingRequest();
        onboardingRequest.setProfile(req.getProfile());
        onboardingRequest.setReferrer(referrerInfo);
        onboardingRequest.setAgreement(agreementInfo);

        OnboardingResponse adminResponse = new OnboardingResponse();
        adminResponse.setCreatedAt(Instant.now());
        adminResponse.setToken("2345");
        adminResponse.setId(UUID.randomUUID().toString());
        adminResponse.setStatus(Status.DRAFTED);

        OrgProfileRequest saved = manager.create(onboardingRequest, adminResponse);

        assertNotNull(saved);
        assertEquals(adminResponse.getId(), saved.getId());
        assertEquals(adminResponse.getToken(), saved.getCredentials().getToken());

    }

    private OrgProfileRequest initiateMockProfileRequest(OrgProfileRequest req) {

        if (req == null) {
            req = testHelper.createOrgProfileRequestMock();
        }

        OrgProfileRequest saved = manager.create(req);

        assertNotNull(saved);
        assertNotNull(saved.getId());
        assertEquals(RequestType.ON_BOARDING, saved.getRequestType());
        assertNotNull(saved.getProfile());
        assertNotNull(saved.getCreatedAt());

        assertNotNull(saved.getCredentials());
        assertNotNull(saved.getCredentials().getKey());
        assertNotNull(saved.getCredentials().getToken());
        assertEquals(BgxConstants.SIGNUP_TOKEN_LEN,
            saved.getCredentials().getToken().length());

        return req;
    }

    private OrgProfileRequest createConfirmedRequest(final OrgProfileRequest req) {

        // set T&C
        OrgProfile profile = req.getProfile();
        AgreementInfo platformAgreement = new AgreementInfo();
        platformAgreement.setTcId("TC01");

        AgreementInfo userAgreement = new AgreementInfo();
        platformAgreement.setTcId("TC02");

        profile.setAgreement(platformAgreement);
        for (ContactInfo contactInfo : profile.getContacts()) {
            contactInfo.setAgreement(userAgreement);
        }

        OrgRequestAction action = new OrgRequestAction();
        action.setActionType(Type.CONFIRM);
        Map<String, Object> payload = new HashMap<>();
        payload.put(ApiConstants.ACTION_PAYLOAD_PROFILE, profile);
        action.setPayload(payload);

        return manager.addOnboardingAction(req.getId(), action);
    }

    private OrgProfileRequest createRejectedRequest(final OrgProfileRequest req) {

        OrgRequestAction action = new OrgRequestAction();
        action.setActionType(Type.REJECT);
        Map<String, Object> payload = new HashMap<>();
        action.setPayload(payload);

        return manager.addOnboardingAction(req.getId(), action);
    }

    private List<OrgProfileRequest> createMocks(int count) {

        List<OrgProfileRequest> mocks = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            OrgProfileRequest req = this.initiateMockProfileRequest(null);
            assertNotNull(req);
            mocks.add(req);
        }

        return mocks;
    }

    private List<OrgProfileRequest> createMocksWithReferrerInfo(int count,
        ReferrerInfo referrerInfo) {

        List<OrgProfileRequest> mocks = new ArrayList<>();

        boolean createReferrerInfo = false;
        if (referrerInfo == null) {
            createReferrerInfo = true;
        }

        for (int i = 0; i < count; i++) {
            OrgProfileRequest req = testHelper.createOrgProfileRequestMock();

            if (createReferrerInfo) {
                referrerInfo = new ReferrerInfo();
                referrerInfo.setId(UUID.randomUUID().toString());
                referrerInfo.setReferrerToken(UUID.randomUUID().toString());
                referrerInfo.setReferralUrl("http://localhost:8080");
            }

            req.setReferrer(referrerInfo);
            req = this.initiateMockProfileRequest(req);
            assertNotNull(req);
            mocks.add(req);
        }

        return mocks;
    }
}
