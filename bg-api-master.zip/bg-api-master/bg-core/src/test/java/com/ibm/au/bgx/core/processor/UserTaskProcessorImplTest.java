package com.ibm.au.bgx.core.processor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.chain.ProfileChainMock;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.common.audit.AuditManagerImpl;
import com.ibm.au.bgx.common.notification.WebNotificationManagerImpl;
import com.ibm.au.bgx.common.rest.filter.OrgProfileFilter;
import com.ibm.au.bgx.common.rest.filter.OrgProfileRequestFilter;
import com.ibm.au.bgx.common.rest.filter.OrgSettingsFilter;
import com.ibm.au.bgx.common.rest.filter.OrganizationFilter;
import com.ibm.au.bgx.common.rest.filter.UserProfileFilter;
import com.ibm.au.bgx.common.user.UserProfileManagerImpl;
import com.ibm.au.bgx.core.ApprovalModelCatalogImpl;
import com.ibm.au.bgx.common.KeyGeneratorImpl;
import com.ibm.au.bgx.core.OrganizationManagerImpl;
import com.ibm.au.bgx.core.task.TaskUtil;
import com.ibm.au.bgx.core.validation.BgxDataValidatorImpl;
import com.ibm.au.bgx.core.processor.item.UserRoleUpdateProcessor;
import com.ibm.au.bgx.core.processor.item.UserStatusUpdateProcessor;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.chain.profile.UserProfileManager;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.OrgSettings;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Role;
import com.ibm.au.bgx.model.pojo.Role.Source;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.api.request.UserTaskRequest;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask.Status;
import com.ibm.au.bgx.model.pojo.task.UserBatchUpdateTaskDetail;
import com.ibm.au.bgx.model.pojo.task.UserBatchUpdateTaskDetail.Method;
import com.ibm.au.bgx.model.repository.BatchProcessTaskRepository;
import com.ibm.au.bgx.model.task.processor.UserTaskProcessor;
import com.ibm.au.bgx.queue.TransientQueueClient;
import com.ibm.au.bgx.repository.AuditEventRepositoryMock;
import com.ibm.au.bgx.repository.BatchProcessTaskRepositoryMock;
import com.ibm.au.bgx.repository.GxRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrgChangeRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrgProfileRepositoryMock;
import com.ibm.au.bgx.repository.OrgProfileRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrganizationRepositoryMock;
import com.ibm.au.bgx.repository.UserProfileRepositoryMock;
import com.ibm.au.bgx.repository.WebNotificationRepositoryMock;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    UserProfileManagerImpl.class,
    DefaultTestHelper.class,
    KeyGeneratorImpl.class,
    BatchProcessTaskRepositoryMock.class,
    UserTaskProcessorImpl.class,
    UserRoleUpdateProcessor.class,
    UserStatusUpdateProcessor.class,
    OrganizationManagerImpl.class,
    OrganizationRepositoryMock.class,
    UserProfileRepositoryMock.class,
    ApprovalModelCatalogImpl.class,
    OrgProfileRepositoryMock.class,
    ProfileChainMock.class,
    WebNotificationManagerImpl.class,
    WebNotificationRepositoryMock.class,
    TransientQueueClient.class,
    AuditManagerImpl.class,
    AuditEventRepositoryMock.class,
    OrgChangeRequestRepositoryMock.class,
    OrgProfileRequestRepositoryMock.class,
    GxRequestRepositoryMock.class,
    OrganizationFilter.class,
    OrgProfileRequestFilter.class,
    UserProfileFilter.class,
    OrgProfileFilter.class,
    OrgSettingsFilter.class,
    BgxDataValidatorImpl.class,
    TermsAndCondManagerMock.class
})
public class UserTaskProcessorImplTest {

    @Autowired
    DefaultTestHelper testHelper;
    
    @Autowired 
    TermsAndCondManager tcManager;

    @Autowired
    UserProfileManager userProfileManager;

    @Autowired
    KeyGenerator keyGenerator;

    @Autowired
    BatchProcessTaskRepository taskRepository;

    @Autowired
    UserTaskProcessor userTaskProcessor;

    @Autowired
    private OrganizationManagerImpl organizationManager;

    List<String> sampleAdminCerts;

    private Organization defaultOrg;

    private final static String ROLE_APPROVER = "APPROVER";

    private final static String ROLE_INITIATOR = "INITIATOR";

    @Before
    public void setUp() throws Exception {

        this.sampleAdminCerts = testHelper.getAdminCerts();
        this.testHelper.setupTermsAndConds(this.tcManager);

        // we need to check that one organization has already been bootstrapped without adminCert input
        // This is required for local java-integration-test where chaincode throws error if the admin org hasn't been bootstrapped
        List<Organization> orgs = organizationManager.getAll();
        if (orgs.size() == 0) {
            this.defaultOrg = this.initailizeOrganization(null, null); // create the first org that does not require cert

        } else {
            this.defaultOrg = orgs.get(0);
        }

        // check if approval role exists or not, if not create those
        boolean approvalRoleExists = false;
        for (Role role : defaultOrg.getSettings().getRoles()) {

            if (role.getSource().equals(Source.APPROVAL_MODEL)) {
                approvalRoleExists = true;
                break;
            }

        }


        // add some mock approval roles
        if (approvalRoleExists == false) {

            Role testRole= new Role();
            testRole.setSource(Source.APPROVAL_MODEL);
            testRole.setIsDefault(false);
            testRole.setRoleName(ROLE_INITIATOR);
            defaultOrg.getSettings().getRoles().add(testRole);

            Role approver = new Role();
            approver.setSource(Source.APPROVAL_MODEL);
            approver.setIsDefault(false);
            approver.setRoleName(ROLE_APPROVER);
            defaultOrg.getSettings().getRoles().add(approver);

            defaultOrg = organizationManager.updateCache(defaultOrg);
        }
    }

    @Test
    public void updateUserRoles() throws Exception {

        List<UserProfile> mocks = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            UserProfile profile = testHelper.createUserProfileMock(keyGenerator, defaultOrg);
            mocks.add(userProfileManager.create(profile));
        }

        UserProfile userProfile = mocks.get(0);
        BatchProcessTask batchTask = this.initializeRoleUpdateTask(userProfile, mocks.subList(1, mocks.size()));
        BatchProcessTask processTask = userTaskProcessor.process(batchTask);
        assertNotNull(processTask);
        assertEquals(batchTask.getId(), processTask.getId());
        assertEquals(Status.COMPLETED, processTask.getStatus());

        UserProfile saved = userProfileManager.getById(mocks.get(1).getId());
        assertEquals(Arrays.asList(new String[]{BgxConstants.ROLE_USER, ROLE_INITIATOR}), saved.getUserRoles().get(userProfile.getPrimaryOrgId()));

        // [USER, INITIATOR] + [USER, APPROVER] => [USER, APPROVER]
        // [USER, INITIATOR] + [APPROVER] => [USER, APPROVER]
        batchTask = this.initializeRoleUpdateTask(userProfile, mocks.subList(1, mocks.size()));
        UserBatchUpdateTaskDetail taskDetail = TaskUtil.deserializeTaskDetail(batchTask);
        taskDetail.setMethod(Method.REPLACE);
        taskDetail.setUsers(new HashMap<>());
        taskDetail.getUsers().put(mocks.get(1).getId(), Arrays.asList(new String[]{BgxConstants.ROLE_USER, ROLE_APPROVER}));
        batchTask.getPayload().put(BgxConstants.TASK, taskDetail);
        batchTask = taskRepository.updateItem(batchTask);
        processTask = userTaskProcessor.process(batchTask);
        assertNotNull(processTask);
        assertEquals(batchTask.getId(), processTask.getId());
        assertEquals(Status.COMPLETED, processTask.getStatus());

        saved = userProfileManager.getById(mocks.get(1).getId());
        assertEquals(Arrays.asList(new String[]{BgxConstants.ROLE_USER, ROLE_APPROVER}), saved.getUserRoles().get(userProfile.getPrimaryOrgId()));

        // [USER, INITIATOR] + [] => [USER]
        // [USER, INITIATOR] + [USER] => [USER]
        batchTask = this.initializeRoleUpdateTask(userProfile, mocks.subList(1, mocks.size()));
        taskDetail = TaskUtil.deserializeTaskDetail(batchTask);
        taskDetail.setMethod(Method.REPLACE);
        taskDetail.setUsers(new HashMap<>());
        taskDetail.getUsers().put(mocks.get(1).getId(), Arrays.asList(new String[]{}));
        batchTask.getPayload().put(BgxConstants.TASK, taskDetail);
        batchTask = taskRepository.updateItem(batchTask);
        processTask = userTaskProcessor.process(batchTask);
        assertNotNull(processTask);
        assertEquals(batchTask.getId(), processTask.getId());
        assertEquals(Status.COMPLETED, processTask.getStatus());

        saved = userProfileManager.getById(mocks.get(1).getId());
        assertEquals(Arrays.asList(new String[]{BgxConstants.ROLE_USER}), saved.getUserRoles().get(userProfile.getPrimaryOrgId()));

        // batching
        batchTask = this.initializeRoleUpdateTask(userProfile, mocks.subList(1, mocks.size()));
        batchTask.setBatchSize(BigInteger.ONE);
        batchTask = taskRepository.updateItem(batchTask);

        processTask = userTaskProcessor.process(batchTask);
        assertNotNull(processTask);
        assertEquals(batchTask.getId(), processTask.getId());
        assertEquals(Status.PROCESSING, processTask.getStatus());

        // process with error
        batchTask = this.initializeRoleUpdateTask(userProfile, mocks.subList(1, mocks.size()));
        taskDetail = TaskUtil.deserializeTaskDetail(batchTask);
        taskDetail.getUsers().put("INVALID", Arrays.asList(new String[]{"INVALID"}));
        batchTask.getPayload().put(BgxConstants.TASK, taskDetail);
        batchTask = taskRepository.updateItem(batchTask);

        processTask = userTaskProcessor.process(batchTask);
        assertNotNull(processTask);
        assertEquals(batchTask.getId(), processTask.getId());
        assertEquals(Status.COMPLETED, processTask.getStatus());
        assertTrue(processTask.getHasError());
    }

    @Test
    public void updateUserRolesInBulk() throws Exception {


        List<UserProfile> mocks = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            UserProfile profile = testHelper.createUserProfileMock(keyGenerator, defaultOrg);
            mocks.add(userProfileManager.create(profile));
        }



        UserProfile userProfile = mocks.get(0);
        BatchProcessTask batchTask = this
            .initializeRoleUpdateTask(userProfile, mocks.subList(1, mocks.size()));

        // overwrite with the userId as "_"
        UserBatchUpdateTaskDetail taskDetail = TaskUtil.deserializeTaskDetail(batchTask);
        taskDetail.setUsers(new HashMap<>());
        taskDetail.getUsers().put(BgxConstants.TASK_FOR_ALL, Arrays.asList(new String[]{ROLE_APPROVER}));
        batchTask.getPayload().put(BgxConstants.TASK, taskDetail);
        taskRepository.updateItem(batchTask);

        BatchProcessTask processTask = userTaskProcessor.process(batchTask);
        assertNotNull(processTask);
        assertEquals(batchTask.getId(), processTask.getId());
        assertEquals(Status.COMPLETED, processTask.getStatus());

        UserProfile saved = userProfileManager.getById(userProfile.getId());
        assertTrue(saved.getUserRoles().get(userProfile.getPrimaryOrgId()).contains(ROLE_APPROVER));
    }

    @Test
    public void updateUserStatus() throws Exception {

        List<UserProfile> mocks = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            UserProfile profile = testHelper.createUserProfileMock(keyGenerator, defaultOrg);
            mocks.add(userProfileManager.create(profile));
        }

        UserProfile userProfile = mocks.get(0);
        BatchProcessTask batchTask = this.initializeStatusUpdateTask(userProfile, mocks.subList(1, mocks.size()), UserProfile.Status.INACTIVE);
        BatchProcessTask processTask = userTaskProcessor.process(batchTask);
        assertNotNull(processTask);
        assertEquals(batchTask.getId(), processTask.getId());
        assertEquals(Status.COMPLETED, processTask.getStatus());

    }

    @Test
    public void updateUserStatusInBulk() throws Exception {

        List<UserProfile> mocks = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            UserProfile profile = testHelper.createUserProfileMock(keyGenerator, defaultOrg);
            mocks.add(userProfileManager.create(profile));
        }

        UserProfile userProfile = mocks.get(0);
        BatchProcessTask batchTask = this.initializeStatusUpdateTask(userProfile, mocks.subList(1, mocks.size()), UserProfile.Status.INACTIVE);

        // overwrite with the userId as "_"
        UserBatchUpdateTaskDetail taskDetail = TaskUtil.deserializeTaskDetail(batchTask);
        taskDetail.setUsers(new HashMap<>());
        taskDetail.getUsers().put(BgxConstants.TASK_FOR_ALL, UserProfile.Status.INACTIVE.value());
        batchTask.getPayload().put(BgxConstants.TASK, taskDetail);
        taskRepository.updateItem(batchTask);

        BatchProcessTask processTask = userTaskProcessor.process(batchTask);
        assertNotNull(processTask);
        assertEquals(batchTask.getId(), processTask.getId());
        assertEquals(Status.COMPLETED, processTask.getStatus());

        UserProfile saved = userProfileManager.getById(userProfile.getId());
        assertEquals(UserProfile.Status.INACTIVE, saved.getStatus());
    }

    private BatchProcessTask initializeRoleUpdateTask(UserProfile userProfile,
        List<UserProfile> mocks) {
        UserTaskRequest taskRequest = DefaultTestHelper.createUserRoleUpdateTaskRequest(mocks, ROLE_INITIATOR);
        return userProfileManager.addTask(userProfile, taskRequest);
    }

    private BatchProcessTask initializeStatusUpdateTask(UserProfile userProfile,
        List<UserProfile> mocks, UserProfile.Status status) {
        UserTaskRequest taskRequest = DefaultTestHelper.createUserStatusUpdateTaskRequest(mocks, status);
        return userProfileManager.addTask(userProfile, taskRequest);
    }

    protected Organization initailizeOrganization(OrgProfileRequest profileRequest,
        String adminCert) throws Exception {

        if (profileRequest == null) {
            profileRequest = testHelper.createOrgProfileRequestMock();
        }

        profileRequest.getProfile().setId(profileRequest.getId());

        Organization expected = new Organization();
        expected.setProfile(profileRequest.getProfile());
        OrgSettings settings = new OrgSettings();
        expected.setSettings(settings);

        Organization actual = organizationManager.create(profileRequest, adminCert);
        actual = organizationManager.setDefaultRoles(actual);

        assertNotNull(actual);
        assertNotNull(actual.getId());
        assertNotNull(actual.getProfile());
        assertNotNull(actual.getSettings());
        assertEquals(expected.getProfile().getId(), actual.getProfile().getId());
        assertEquals(expected.getProfile().getEntityName(), actual.getProfile().getEntityName());
        assertEquals(expected.getProfile().getEntityType(), actual.getProfile().getEntityType());
        assertEquals(expected.getProfile().getBusinessId(), actual.getProfile().getBusinessId());
        assertEquals(expected.getProfile().getEntityAddress(),
            actual.getProfile().getEntityAddress());

        return actual;
    }

}