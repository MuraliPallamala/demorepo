package com.ibm.au.bgx.core.channel;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.ibm.au.bgx.core.chain.channel.IbpConfigLoaderImpl;
import com.ibm.au.bgx.fabric.model.IbpConfig;
import com.ibm.au.bgx.model.chain.IbpConfigLoader;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    IbpConfigLoaderImpl.class
})
@TestPropertySource(locations = "classpath:application-test.properties")
public class IbpConfigLoaderImplTest {

    @Autowired
    protected IbpConfigLoader loader;

    @Test
    public void load() throws Exception {

        boolean invalid = false;
        try {
            loader.load("INVALID");
        } catch (Exception e) {
            invalid = true;
        }
        assertTrue(invalid);

        String channelName = "platform-channel";
        IbpConfig config = loader.load(channelName);
        assertNotNull(config);
        assertTrue(config.getChannels().containsKey(channelName));
    }

}