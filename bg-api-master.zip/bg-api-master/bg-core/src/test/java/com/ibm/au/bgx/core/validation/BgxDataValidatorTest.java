package com.ibm.au.bgx.core.validation;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.AgreementInfo;
import com.ibm.au.bgx.model.pojo.BaseRequest;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.validation.BgxDataValidator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Stream;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Class <b>BgxDataValidatorTest</b>. This class defines a suite of tests to
 * verify the correct implementation of {@link BgxDataValidator}. The class
 * is abstract and leave to concrete classes the implementation of the {@link 
 * BgxDataValidatorTest#getValidator()} which returns the instance of the
 * specific type to be tested.
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
public abstract class BgxDataValidatorTest {

	/**
	 * A {@link String} constant that points to a text file containing a collection
	 * of sample ABNs, that are used for validating the implementation of the logic
	 * that validates business identifiers that are ABNs.
	 */
    private static final String ABN_SAMPLES_PATH = "src/test/resources/abn-samples.txt";

	/**
	 * A {@link String} constant that points to a text file containing a collection
	 * of sample ACNs, that are used for validating the implementation of the logic
	 * that validates business identifiers that are ACNs.
	 */
    private static final String ACN_SAMPLES_PATH = "src/test/resources/acn-samples.txt";
    
    /**
     * A {@link TermsAndCond} instance referencing the selected platform terms and
     * conditions that are expected to be found in a completed organisation profile
     * and that are configured with the {@link TermsAndCondManager} in use.
     */
    protected TermsAndCond platformTCs;
    
    /**
     * A {@link TermsAndCond} instance referencing the selected user terms and
     * conditions that are expected to be found in a completed organisation profile
     * and that are configured with the {@link TermsAndCondManager} in use.
     */
    protected TermsAndCond userTCs;
    
    /**
     * This method is executed before each test to ensure that the terms and condition
     * manager is properly setup.
     * 
     * 
     * @throws ProfileChainException	the exception is declared to comply to the signature 
     * 									requirements of the method being called but not thrown 
     * 									in the context of this test.
     */
    @Before
    public void setup() throws ProfileChainException {
    	
    	// We need this to be sure that when we get the helper support services,
    	// this is connected to the appropriate terms and conditions manager.
    	//
    	DefaultTestHelper helper = this.getTestHelper();
    	TermsAndCondManager tcManager = this.getTermsAndCondManager();
    	helper.setupTermsAndConds(tcManager);
    	
    	List<TermsAndCond> tcs = tcManager.getByTitle("Platform User Terms");
    	Assert.assertEquals("Precondition failed: cannot find 'Platform User Terms' TCs", 1, tcs.size());
    	this.platformTCs = tcs.get(0);
    	Assert.assertEquals("Precondition failed: 'Platform User Terms' TCs is not of PLATFORM scope.", Scope.PLATFORM, this.platformTCs.getScope());
    	
    	tcs = tcManager.getByTitle("Consent Form");
    	Assert.assertEquals("Precondition failed: cannot find 'Consent Form' TCs", 1, tcs.size());
    	this.userTCs = tcs.get(0);
    	Assert.assertEquals("Precondition failed: 'Consent Form' TCs is not of USER scope.", Scope.USER, this.userTCs.getScope());
    	
    	
    			
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateProfile(OrgProfile, Status)}
     * when invoked with a various combination of {@literal null} argument. The expectation is that the method
     * throw an {@link IllegalArgumentException}.
     */
    @Test
    public void testValidateProfileWithNullArguments() {
    	
    	BgxDataValidator validator = this.getValidator();
    	
    	for(BaseRequest.Status status : new BaseRequest.Status[] { Status.DRAFTED, Status.CONFIRMED, Status.REJECTED, Status.APPROVED, Status.ABANDONED }) {
    	
	    	try {
	    		
	    		validator.validateProfile(null, status);
	    		Assert.fail("BgxDataValidator.validateProfile(null, Status) should throw IllegalArgumentException.");
	    	
	    	} catch(IllegalArgumentException ilex) {
	    		
	    		// ok good to go.
	    	}
	    }

    	DefaultTestHelper helper = this.getTestHelper();
    	OrgProfile profile = helper.createOrgProfileMock();

    	try {
    	
    		validator.validateProfile(profile, null);
    		Assert.fail("BgxDataValidator.validateProfile(OrgProfile, null) should throw IllegalArgumentException.");
    	
    	} catch(IllegalArgumentException ilex) {
    		
    		// ok good to go.
    	}
    }
    
    /**
     * This method tests the implemented behaviour of {#link {@link BgxDataValidator#isValidProfile(OrgProfile, Status)}
     * when invoked with various {@literal null} arguments. The expected behaviour is that the method throws an {@link 
     * IllegalArgumentException} because of {@literal null} parameters.
     */
    @Test
    public void testIsValidProfileWithNullArguments() {
    
    	BgxDataValidator validator = this.getValidator();
    	
    	for(BaseRequest.Status status : new BaseRequest.Status[] { Status.DRAFTED, Status.CONFIRMED, Status.REJECTED, Status.APPROVED, Status.ABANDONED }) {
    	
	    	try {
	    		
	    		validator.isValidProfile(null, status);
	    		Assert.fail("BgxDataValidator.validateProfile(null, Status) should throw IllegalArgumentException.");
	    	
	    	} catch(IllegalArgumentException ilex) {
	    		
	    		// ok good to go.
	    	}
	    }

    	DefaultTestHelper helper = this.getTestHelper();
    	OrgProfile profile = helper.createOrgProfileMock();

    	try {
    	
    		validator.isValidProfile(profile, null);
    		Assert.fail("BgxDataValidator.validateProfile(OrgProfile, null) should throw IllegalArgumentException.");
    	
    	} catch(IllegalArgumentException ilex) {
    		
    		// ok good to go.
    	}
    }
    
    /**
     * <p>
     * This method tests the implemented behaviour of {@link BgxDataValidator#isValidProfile(OrgProfile,Status)} when
     * invoked with a valid profile. The expectation is that the method returns {@literal true}. This method is not
     * exhaustive in the testing all the possible scenarios of a valid profile as there is a variety of scenarios
     * covered of the {@link BgxDataValidator#validateProfile(OrgProfile, Status)} method. 
     * </p>
     * <p>
     * <b>NOTE:</b> The assumption here is that the two methods share the same validation logic, if this does not hold 
     * true, code coverage report may direct developers of tests for concrete classes of {@link BgxDataValidator} which
     * other test cases to develop.
     * </p>
     */
    @Test
    public void testIsValidProfileWithValidProfile() {
    	
    	DefaultTestHelper helper = this.getTestHelper();
    	BgxDataValidator validator = this.getValidator();
    	
    	OrgProfile completeProfile =  helper.createOrgProfileMock();
    	
    	Assert.assertTrue("BgxDataValidator.isValidProfile(OrgProfile, CONFIRMED) should return TRUE for a valid complete profile.", 
    					  validator.isValidProfile(completeProfile, Status.CONFIRMED));
    	
    	
    	OrgProfile draftedProfile = helper.createOrgProfileMock();
    	draftedProfile.setAgreement(null);
    	for(ContactInfo contact : draftedProfile.getContacts()) {
    		contact.setAgreement(null);
    	}

    	Assert.assertTrue("BgxDataValidator.isValidProfile(OrgProfile, DRAFTED) should return TRUE for a valid complete profile.", 
    					  validator.isValidProfile(draftedProfile, Status.DRAFTED));
    	
    }
    
    /**
     * <p>
     * This method tests the implemented behaviour of {@link BgxDataValidator#isValidProfile(OrgProfile,Status)} when
     * invoked with a invalid profile. The expectation is that the method returns {@literal true}. This method is not
     * exhaustive in the testing all the possible scenarios of an invalid profile as there is a variety of scenarios
     * covered of the {@link BgxDataValidator#validateProfile(OrgProfile, Status)} method. 
     * </p>
     * <p>
     * <b>NOTE:</b> The assumption here is that the two methods share the same validation logic, if this does not hold 
     * true, code coverage report may direct developers of tests for concrete classes of {@link BgxDataValidator} which
     * other test cases to develop.
     * </p>
     */
    @Test
    public void testIsValidProfileWithInvalidProfile() {
    	
    	BgxDataValidator validator = this.getValidator();
    	
    	OrgProfile orgProfile = new OrgProfile();
    	Assert.assertFalse("BgxDataValidator.isValidProfile(OrgProfile, DRAFTED) should return TRUE for a valid complete profile.", 
				  		   validator.isValidProfile(orgProfile, Status.DRAFTED));
    }
    
    /**
     * This method tests the implementation of {@link BgxDataValidator#validateProfile(OrgProfile, Status)} when the
     * the base attributes of the profile (entity name, address, type, businessId) are invalid. The expected behaviour
     * is that the method throws a {@link DataValidationException}. The test cases implemented in this method are:
     * <ul>
     * <li>{@literal null} or empty entity name</li>
     * <li>{@literal null} entity address</li>
     * <li>{@literal null} entity type</li>
     * <li>{@literal null} or empty businessId</li>
     * <li>invalid businessId</li>
     * </ul>
     */
    @Test
    public void testValidateProfileWithInvalidBaseProfile() {
    	
    	BgxDataValidator validator = this.getValidator();
    	
    	DefaultTestHelper helper = this.getTestHelper();
    	
    	Status[] values = Status.values();
    	
    	
    	// 1.a Testing with NULL entity name, should return DataValidationException.
    	// 
    	OrgProfile profile = helper.createOrgProfileMock();
    	profile.setEntityName(null);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[entityName=null], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	// 1.b Testing with NULL entity name, should return DataValidationException.
    	// 
    	profile.setEntityName("");
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[entityName=''], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 2. Testing with NULL address, should return DataValidationException.
    	//
    	profile = helper.createOrgProfileMock();
    	profile.setEntityAddress(null);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[entityAddress=null], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 3. Testing with NULL type, should return DataValidationException.
    	//
    	profile = helper.createOrgProfileMock();
    	profile.setEntityType(null);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[entityType=null], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 4.a Testing with NULL business identifier, should return DataValidationException
    	//
    	profile = helper.createOrgProfileMock();
    	profile.setBusinessId(null);

    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[businessId=null], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 4.b Testing with NULL business identifier, should return DataValidationException
    	//
    	profile = helper.createOrgProfileMock();
    	profile.setBusinessId("");

    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[businessId=''], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 4.c Testing with NULL business identifier, should return DataValidationException
    	//
    	profile = helper.createOrgProfileMock();
    	profile.setBusinessId("2030404013");

    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[businessId=(invalid)], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateProfile(OrgProfile, Status)} when invoked
     * with a profile that contains and invalid list of contacts. The expectation is that a {@link DataValidationException} is
     * thrown. The scenarios explored are the following:
     * <ul>
     * <li>{@literal null} and empty list of contacts.</li>
     * <li>list of contacts that does not contain a primary contact.</li>
     * <li>list of contacts that does not contain an administrator.</li>
     * <li>list of contacts with contacts with invalid attributes (first name, last name, phone)</li>
     * </ul>
     */
    @Test
    public void testValidateProfileWithInvalidContacts() {
    	
    	BgxDataValidator validator = this.getValidator();
    	DefaultTestHelper helper = this.getTestHelper();
    	Status[] values = Status.values();
    	
    	// 1.a Testing with NULL contacts, should return DataValidationException.
    	// 
    	OrgProfile profile = helper.createOrgProfileMock();
    	profile.setContacts(null);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts=NULL], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 1.b Testing with EMPTY contacts, should return DataValidationException.
    	// 
    	profile = helper.createOrgProfileMock();
    	profile.setContacts(new ArrayList<>());
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts=<EMPTY>], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 2. Testing with a list of contact that is missing the primary.
    	//
    	profile = helper.createOrgProfileMock();
    	ContactInfo primary = this.createContact("Poppy", "Primary", "primary@primary.test.au", "+61449110899", BgxConstants.ROLE_PRIMARY);
    	List<ContactInfo> contacts = new ArrayList<>();
    	contacts.add(primary);
    	profile.setContacts(contacts);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts=<MISSING primary>], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 3. Testing with a list of contact that is missing the admin.
    	//
    	profile = helper.createOrgProfileMock();
    	ContactInfo admin = this.createContact("Andy", "Admin", "admin@admin.test.au", "+61449110829", BgxConstants.ROLE_ADMIN);
    	contacts = new ArrayList<>();
    	contacts.add(admin);
    	profile.setContacts(contacts);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts=<MISSING admin>], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 4.a Testing with a list of contacts that has a NULL first name.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setFirstName(null);
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].lastName=NULL], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 4.b Testing with a list of contacts that has an EMPTY first name.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setFirstName("");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].firstName=''], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 5.a Testing with a list of contacts that has a NULL last name.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setFirstName("Paul");
    	primary.setLastName(null);
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].lastName=NULL], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 5.b Testing with a list of contacts that has an EMPTY last name.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setLastName("");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].lastName=''], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	
    	// 6.a Testing with a list of contacts that has a NULL email.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setLastName("Primary");
    	primary.setEmail(null);
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].email=NULL], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 6.b Testing with a list of contacts that has an EMPTY email.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setEmail("");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].email=''], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}

    	
    	// 6.c Testing with a list of contacts that has an email without @.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setEmail("primary.primary.com");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].email=<MISSING @>], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 6.d Testing with a list of contacts that has an email without domain name.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setEmail("primary@");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].emai=<MISSING domain name>], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 6.e Testing with a list of contacts that has an email without user name.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setEmail("@primary.com");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].email=<MISSING account name>], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	
    	// 7.a Testing with a list of contacts that has a NULL phone.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setEmail("primary@primary.com.au");
    	primary.setPhone(null);
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].phone=NULL], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 7.b Testing with a list of contacts that has an EMPTY phone.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setPhone("");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].phone=''], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}  
    	
    	// 7.c Testing with a list of contacts that has alphabetic characters in the phone.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setPhone("+61449nn192922");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].phone=<%2$:regex('fail \\+61[0-9]+')>], %1$s) should throw a DataValidationException.", status, primary.getPhone()));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}  
    	
    	// 7.b Testing with a list of contacts that has a phone not starting with +61....
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setPhone("+39449119756");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].phone=<%2$s:regex('fail \\+61[0-9]+')>], %1$s) should throw a DataValidationException.", status, primary.getPhone()));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}  
    	
    	// 8.a Testing with a list of contacts with a contact that has a NULL role.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.setPhone("+61453636212");
    	primary.getRoles().add(null);
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].roles=<includes NULL)>], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// 8.b Testing with a list of contacts with a contact that has an EMPTY role.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.getRoles().clear();
    	primary.getRoles().add("");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].roles=<includes ''>], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	

    	// 8.b Testing with a list of contacts with a contact that has an UNKNOWN role.
    	//
    	profile = helper.createOrgProfileMock();
    	primary.getRoles().clear();
    	primary.getRoles().add("NINJA");
    	profile.getContacts().add(primary);
    	
    	for(Status status : values) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any].roles=<includes UNKNOWN>], %1$s) should throw a DataValidationException.", status));
	    		
	    	} catch(DataValidationException dvex) {
	    		
	    		// ok good to go.
	    	}
    	}
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateProfile(OrgProfile, Status)} for
     * those profiles that are in DRAFTED mode. These profiles MUST not have any agreement block in the profile. The
     * expectation is that a {@link DataValidationException} is thrown. The scenarios explored are the following:
     * <ul>
     * <li>existence of an {@link AgreementInfo} block with a non-blank terms and condition identifier.</li>
     * <li>existence of an {@link AgreementInfo} block for the {@link ContactInfo} associated to the profile, with a
     * non-blank terms and condition identifier.</li>
     * </ul>
     */
    @Test
    public void testValidateProfileWithInvalidDraftedProfile() {
    	
    	BgxDataValidator validator = this.getValidator();
    	DefaultTestHelper helper = this.getTestHelper();
    	
    	OrgProfile profile = helper.createOrgProfileMock();
    	
    	// 1. The main agreement block should not be present.
    	//
    	AgreementInfo agreement = new AgreementInfo();
    	agreement.setTcId(this.platformTCs.getId());
    	profile.setAgreement(agreement);
    	
    	for(Status status : new Status[] { Status.DRAFTED, Status.ABANDONED }) {
    		
    		try {
    			
    			validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[agreement.tcId<PRESENT>], %1$s) should throw a DataValidationException.", status));
    			
    			
    		} catch(DataValidationException dvex) {
    			
    			// ok good to go...
    		}
    	}
    	
    	
    	// 2. The contacts should not have an agreement block. 
    	//
    	profile.setAgreement(null);
    	
    	agreement.setTcId(this.userTCs.getId());
    	for(ContactInfo contact : profile.getContacts()) {
    		
    		contact.setAgreement(agreement);
    	}
    	
    	for(Status status : new Status[] { Status.DRAFTED, Status.ABANDONED }) {
    		
    		try {
    			
    			validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contact.agreement.tcId<PRESENT>], %1$s) should throw a DataValidationException.", status));
    			
    			
    		} catch(DataValidationException dvex) {
    			
    			// ok good to go...
    		}
    	}
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateProfile(OrgProfile, Status)} 
     * for those profiles that are CONFIRMED (completed, from a submission standpoint) and miss some of the required 
     * agreement blocks. The expectation is that a {@link DataValidationException} is thrown. The scenarios explored 
     * in this test are:
     * <ul>
     * <li>a profile with an {@link AgreementInfo} block set to {@literal null}</li>
     * <li>a profile with an {@link AgreementInfo} block not {@literal null} but with terms and conditions identifier
     * set to {@literal null}</li>
     * <li>a profile with an {@link AgreementInfo} block not {@literal null} but with terms and conditions identifier
     * set to an empty string</li>
     * <li>a profile with an {@link AgreementInfo} block that has a terms and condition identifier not correct</li>
     * </ul>
     */
    @Test
    public void testValidateProfileWithInvalidCompletedProfile() {
    	
    	BgxDataValidator validator = this.getValidator();
    	DefaultTestHelper helper = this.getTestHelper();

    	OrgProfile profile = helper.createOrgProfileMock();
    	
    	Status[] completed = new Status[] { Status.CONFIRMED, Status.APPROVED, Status.REJECTED };
    	
    	
    	
    	// Test 1.a Main profile agreement with NULL tcId.
    	//
    	
    	profile.getAgreement().setTcId(null);
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[agreement.tcId=NULL], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	// Test 1.b Main profile agreement with EMPTY tcId.
    	//
    	profile.getAgreement().setTcId("");
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[agreement.tcId=''], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}

    	// Test 1.c Main profile agreement with wrong tcId.
    	//
    	profile.getAgreement().setTcId("mozumbo");
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[agreement.tcId=<INVALID id>], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	// Test 1.d Main profile agreement is set to User TCs.
    	//
    	profile.getAgreement().setTcId(this.userTCs.getId());
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[agreement.tcId=<USER TC id>], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	// Test 1.e Main profile agreement is NULL
    	//
    	profile.setAgreement(null);
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[agreement=NULL], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	
    	// Test 2.a Profile with a primary contact agreement with tcId NULL.
    	//
    	profile = helper.createOrgProfileMock();
    	ContactInfo primary = profile.getContacts()
    								 .stream()
    								 .filter(contact -> contact.getRoles().contains(BgxConstants.ROLE_PRIMARY))
    								 .findAny()
    								 .get();
    	
    	primary.getAgreement().setTcId(null);
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[primary.agreement.tcId=NULL], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	// Test 2.b Profile with a primary contact agreemnt with tcId EMPTY.
    	//
    	primary.getAgreement().setTcId("");
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[primary.agreement.tcId=''], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	// Test 2.c Profile with a primary contact agreemnt with tcId that is not correct.
    	//
    	primary.getAgreement().setTcId("mozumbo");
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[primary.agreement.tcId=<INVALID id>], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	// Test 2.d Profile with a primary contact agreement with tcId that is set to 
    	//          the Platform terms and conditions.
    	//
    	primary.getAgreement().setTcId(this.platformTCs.getId());
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[primary.agreement.tcId=<PLATFORM TC id>], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	// Test 2.e Profile with a primary contact agreement with tcId that is set to 
    	//          the Platform terms and conditions.
    	//
    	primary.setAgreement(null);
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[primary.agreement=<NULL>], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	// Test 3.a Admin with an assigned tcId (invalid).
    	//
    	profile = helper.createOrgProfileMock();
    	ContactInfo any = profile.getContacts()
				 				   .stream()
				 				   // we need to be sure that we pick a contact that is not primary.
				 				   .filter(contact -> !contact.getRoles().contains(BgxConstants.ROLE_PRIMARY))
				 				   .findAny()
				 				   .get();
    	
    	AgreementInfo agreement = new AgreementInfo();
    	agreement.setTcId("mozumbo");
    	
    	any.setAgreement(agreement);
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[!primary].agreement.tcId=<INVALID>], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    	
    	// Test 3.b Admin with an assigned tcId (valid).
    	//
    	agreement.setTcId(this.userTCs.getId());
    	any.setAgreement(agreement);
    	for(Status status : completed) {
    		
	    	try {
	    		
	    		validator.validateProfile(profile, status);
	    		Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[!primary].agreement.tcId=<USER TC Id>], %1$s) should throw DataValidationException.", status));
	    	
	    	} catch(DataValidationException dvex) {
	    		
	    		// good to go.
	    	}
    	}
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateProfile(OrgProfile, Status)} with
     * a valid profile. The expectation is that no {@link Exception} is thrown, especially no exception of type {@link 
     * DataValidationException}. The scenarios that are explored are:
     * <ul>
     * <li>a valid DRAFTED profile (various combinations of {@literal null} references and empty strings).</li>
     * <li>a valid CONFIRMED profile (various combinations of {@literal null} references and empty strings).</li>
     * </ul>
     */
    @Test
    public void testValidateProfileWithValidProfile() {
    	
    	BgxDataValidator validator = this.getValidator(); 
    	DefaultTestHelper helper = this.getTestHelper();
    	
    	Status[] drafted = new Status[] { Status.DRAFTED, Status.ABANDONED };
    	Status[] completed = new Status[] { Status.CONFIRMED, Status.APPROVED, Status.REJECTED };
    	
    	// Test 1.a A valid DRAFTED profile that does not contain any agreement block (all blocks are NULL).
    	//
    	OrgProfile profile = helper.createOrgProfileMock();
    	profile.setAgreement(null);
    	for(ContactInfo contact : profile.getContacts()) {
    		contact.setAgreement(null);
    	}
    	
    	for(Status status : drafted) {
    		
    		try {
    			
    			validator.validateProfile(profile, status);
    			
    		} catch(DataValidationException dvex) {
    			
    			Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[agreement=NULL, contacts.[any].agreement=NULL], %1$s) should NOT throw DataValidationException (error: %2$s).", 
    									  status, dvex.getMessage()));
    		}
     	}
    	
    	// Test 1.b A valid DRAFTED profile that does contain agreement blocks with TC id set to NULL.
    	//
    	AgreementInfo agreement = new AgreementInfo();
    	agreement.setTcId(null);
    	profile.setAgreement(agreement);
    	for(ContactInfo contact : profile.getContacts()) {
    		contact.setAgreement(agreement);
    	}
    	
    	for(Status status : drafted) {
    		
    		try {
    			
    			validator.validateProfile(profile, status);
    			
    		} catch(DataValidationException dvex) {
    			
    			Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[agreement.tcId=NULL, contacts.[any].agreement.tcId=NULL], %1$s) should NOT throw DataValidationException (error: %2$s).", 
    									  status, dvex.getMessage()));
    		}
     	}
    	
    	// Test 1.c A valid DRAFTED profile that does contain agreement blocks with TC id set to an empty string.
    	//
    	agreement = new AgreementInfo();
    	agreement.setTcId("");
    	profile.setAgreement(agreement);
    	for(ContactInfo contact : profile.getContacts()) {
    		contact.setAgreement(agreement);
    	}
    	
    	for(Status status : drafted) {
    		
    		try {
    			
    			validator.validateProfile(profile, status);
    			
    		} catch(DataValidationException dvex) {
    			
    			Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[agreement.tcId='', contacts.[any].agreement.tcId=''], %1$s) should NOT throw DataValidationException (error: %2$s).", 
    									  status, dvex.getMessage()));
    		}
     	}
    	
    	// Test 2.a A valid CONFIRMED profile with the non primary contact information, having a NULL agreement block.
    	//
    	profile = helper.createOrgProfileMock();
    	agreement = new AgreementInfo();
    	agreement.setTcId(this.platformTCs.getId());
    	profile.setAgreement(agreement);
    	
    	agreement = new AgreementInfo();
    	agreement.setTcId(this.userTCs.getId());
    	
    	for(ContactInfo contact : profile.getContacts()) {
    		
    		if (contact.getRoles().contains(BgxConstants.ROLE_PRIMARY)) {
    			
    			contact.setAgreement(agreement);
    			
    		} else {
    			
    			contact.setAgreement(null);
    		}
    	}
    	
    	for(Status status : completed) {
    		
    		try {
    			
    			validator.validateProfile(profile, status);
    			
    		} catch(DataValidationException dvex) {
    			
    			Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any!primary].agreement=NULL], %1$s) should NOT throw DataValidationException (error: %2$s).", 
    									  status, dvex.getMessage()));
    		}
     	}
    	
    	// Test 2.b A valid CONFIRMED profile with the non primary contact information, having an agreement 
    	//          with NULL terms and conditions identifier.
    	//
    	agreement = new AgreementInfo();
    	agreement.setTcId(null);
    	for(ContactInfo contact : profile.getContacts()) {
    		
    		if (!contact.getRoles().contains(BgxConstants.ROLE_PRIMARY)) {
    			
    			contact.setAgreement(agreement);
    		}
    	}
    	
    	for(Status status : completed) {
    		
    		try {
    			
    			validator.validateProfile(profile, status);
    			
    		} catch(DataValidationException dvex) {
    			
    			Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any!primary].agreement.tcId=NULL], %1$s) should NOT throw DataValidationException (error: %2$s).", 
    									  status, dvex.getMessage()));
    		}
     	}
    	
    	
    	// Test 2.c A valid CONFIRMED profile with the non primary contact information, having an agreement 
    	//          with EMPTY terms and conditions identifier.
    	//
    	agreement = new AgreementInfo();
    	agreement.setTcId("");
    	for(ContactInfo contact : profile.getContacts()) {
    		
    		if (!contact.getRoles().contains(BgxConstants.ROLE_PRIMARY)) {
    			
    			contact.setAgreement(agreement);
    		}
    	}
    	
    	for(Status status : completed) {
    		
    		try {
    			
    			validator.validateProfile(profile, status);
    			
    		} catch(DataValidationException dvex) {
    			
    			Assert.fail(String.format("BgxDataValidator.validateProfile(OrgProfile[contacts.[any!primary].agreement.tcId=''], %1$s) should NOT throw DataValidationException (error: %2$s).", 
    									  status, dvex.getMessage()));
    		}
     	}
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateAgreement(AgreementInfo, Scope)}
     * when invoked with {@literal null} arguments. The expectation is that a {@link IllegalArgumentException} is thrown
     * for any of the {@literal null} arguments.
     */
    @Test
    public void testValidateAgreemntWithNullArguments() {
    	
    	BgxDataValidator validator = this.getValidator();
    	
    	// Test 1. NULL AgreementInfo, should throw IllegalArgumentException.
    	//
    	for (Scope scope : Scope.values()) {
    		
	    	try {
	    		
	    		validator.validateAgreement(null, scope);
	    		Assert.fail(String.format("BgxDataValidator.validateAgreement(null,%1$s) should throw IllegalArgumentException.", scope));
	    		
	    	} catch(IllegalArgumentException ilex) {
	    		
	    		// ok good to go.
	    	}
    	}
    	
    	// Test 2. NULL Scope, should throw IllegalArgumentException.
    	//
    	try {
    		
    		validator.validateAgreement(new AgreementInfo(), null);
    		Assert.fail("BgxDataValidator.validateAgreement(AgreementInfo, null) should throw IllegalArgumentException.");
    		
    	} catch(IllegalArgumentException ilex) {
    		
    		// ok good to go.
    	}
    	
    	
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateAgreement(AgreementInfo, Scope)} when
     * invoked with an unsupported value for the {@link Scope} argument. The expectation is that a {@link DataValidationException}
     * is thrown.
     */
    @Test(expected=DataValidationException.class)
    public void testValidateAgreementWithInvalidScope() {
    	
    	BgxDataValidator validator = this.getValidator();
    	
    	AgreementInfo agreement = new AgreementInfo();
    	agreement.setTcId(this.platformTCs.getId());
    	validator.validateAgreement(agreement, Scope.BANK_GUARANTEE);
    	
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateAgreement(AgreementInfo, Scope)} when
     * invoked with valid arguments and invalid combination of argumnents. The expectation is that in the first case the
     * validation is successful, while in the second case a {@link DataValidationException} is thrown. More specifically,
     * the following scenarios are covered:
     * <ul>
     * <li>invocation with valid user TCs and scope set to {@link Scope#USER}: validation should pass.</li>
     * <li>invocation with valid platform TCs and scope set to {@link Scope#PLATFORM}: validation should pass.</li>
     * <li>invocation with valid user TCs and scope set to {@link Scope#PLATFORM}: {@link DataValidationException} expected.</li>
     * <li>invocation with valid platform TCs and scope set to {@link Scope#USER}: {@link DataValidationException} expected.</li>
     * <li>invocation with missing TC identifier ({@literal null} or empty string: {@link DataValidationException} expected.</li>
     * <li>invocation with a non existing TC identifier: {@link DataValidationException} expected.</li> 
     * </ul>
     * 
     */
    @Test
    public void testValidateAgreement() {
    	
    	BgxDataValidator validator = this.getValidator();
    	AgreementInfo agreement = new AgreementInfo();
    	
    	
    	// Test 1. Valid user terms and conditions, scope is USER.
    	//
    	agreement.setTcId(this.userTCs.getId());
    	validator.validateAgreement(agreement, Scope.USER);
    	
    	// Test 2. Valid platform terms and conditions, scope is PLATFORM.
    	//
    	agreement.setTcId(this.platformTCs.getId());
    	validator.validateAgreement(agreement, Scope.PLATFORM);
    	
    	// Test 3. Valid user terms and conditions, scope is PLATFORM.
    	//
    	agreement.setTcId(this.userTCs.getId());
    	try {
    		validator.validateAgreement(agreement, Scope.PLATFORM);
    		Assert.fail("BgxDataValidator.validateAgreement(AgreementInfo,Scope) should throw DataValidationException for the pair [userTCs, PLATFORM].");
    	
    	} catch(DataValidationException dvex) {
    		
    		// ok good to go.
    	}
    	
    	// Test 4. Valid platform terms and conditions, scope is USER.
    	//
    	agreement.setTcId(this.platformTCs.getId());
    	try {
    		validator.validateAgreement(agreement, Scope.USER);
    		Assert.fail("BgxDataValidator.validateAgreement(AgreementInfo,Scope) should throw DataValidationException for the pair [platformTCs, USER].");
    	
    	} catch(DataValidationException dvex) {
    		
    		// ok good to go.
    	}
    	
    	// Test 5.a Missing terms and conditions identifier (set to NULL).
    	//
    	agreement.setTcId(null);
    	for(Scope scope : new Scope[] { Scope.PLATFORM, Scope.USER }) {
    		try {

        		validator.validateAgreement(agreement, scope);
        		Assert.fail(String.format("BgxDataValidator.validateAgreement(AgreementInfo[tcId=NULL],%1$s) should throw DataValidationException.", scope));
    			
    		} catch(DataValidationException dvex) {
    			
    			// ok good to go
    		}
    	}
    	
    	// Test 5.b Missing terms and conditions identifier (set to EMTPY).
    	//
    	agreement.setTcId(null);
    	for(Scope scope : new Scope[] { Scope.PLATFORM, Scope.USER }) {
    		try {

        		validator.validateAgreement(agreement, scope);
        		Assert.fail(String.format("BgxDataValidator.validateAgreement(AgreementInfo[tcId=''],%1$s) should throw DataValidationException.", scope));
    			
    		} catch(DataValidationException dvex) {
    			
    			// ok good to go
    		}
    	}
    	
    	// Test 6. Wrong terms and conditions identifier (not existing).
    	//
    	agreement.setTcId("mozumbo");
    	for(Scope scope : new Scope[] { Scope.PLATFORM, Scope.USER }) {
    		try {

        		validator.validateAgreement(agreement, scope);
        		Assert.fail(String.format("BgxDataValidator.validateAgreement(AgreementInfo[tcId=<INVALID>],%1$s) should throw DataValidationException.", scope));
    			
    		} catch(DataValidationException dvex) {
    			
    			// ok good to go
    		}
    	}
    	
    }
    

    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateAcn(String)}. The
     * method is expected to throw a {@link DataValidationException} if the provided test string is not
     * a valid ABN. The method first tries some obvious invalid ABNs for which it expects the tested
     * method to throw {@link DataValidationException}, it then iterates over a collection of various
     * valid ABNs to test whether any of those fails the validation test.
     * 
     * @throws IOException 	if there is an error accessing the file with the test ABN numbers.
     */
    @Test
    public void testValidateAbn() throws IOException {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	// 1. Valid ACN
    	//
    	String abn = "51824753556";
    	try {
    	
    		validator.validateAbn(abn);   // valid
    	
    	} catch(DataValidationException dvex) {
    	
    		Assert.fail(String.format("Valid ABN (%1$s) should not throw DataValidationException.", abn));
    	}
    	
    	// 2. Too short.
    	//
    	abn = "123456";
    	try {
    		
    		validator.validateAbn(abn);
    		Assert.fail(String.format("Invalid ABN (%1$s, length mismatch) should throw DataValidationException.", abn));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}

    	// 3. Right length, but invalid.
    	//
    	abn = "12345678911";
    	try {
    		
    		validator.validateAbn(abn);
    		Assert.fail(String.format("Invalid ABN (%1$s, right length, but invalid) should throw DataValidationException.", abn));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}
    	
    	// 4. Contains other characters than 
    	//    numbers.
    	abn = "a2c4e6h8j11";
    	try {
    		
    		validator.validateAbn(abn);
    		Assert.fail(String.format("Invalid ABN (%1$s, right length, but not numeric) should throw DataValidationException.", abn));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}
    	
    	// 4. Empty string..
    	abn = "";
    	try {
    		
    		validator.validateAbn(abn);
    		Assert.fail(String.format("Invalid ABN (%1$s, empty string) should throw DataValidationException.", abn));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}

        // try the ACNs from the file.
    	Path source = this.getResourceFile(BgxDataValidatorTest.ABN_SAMPLES_PATH);
        try (Stream<String> lines = Files.lines(source)) {
        	
            lines.forEach(line -> {
            	
            	String abnFile = line.replaceAll("\\s", "");
            	validator.validateAbn(abnFile);
            });
            
        } catch(DataValidationException dvex) {
        	
        	Assert.fail(String.format("Valid ABN should not trigger DataValidationException [Exception: %s].", dvex.getMessage()));
        }
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateAbn(String)}
     * when invoked with a {@literal null} argument. The expectation is that the method throws an
     * {@link IllegalArgumentException}.
     * 
     * @throws IllegalArgumentException	expected for a successful test.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testValidateAbnWithNull() {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	validator.validateAbn(null);
    }
    
    /**
     * <p>
     * This method tests the implemented behaviour of {@link BgxDataValidator#isValidAbn(String)}.
     * The expectation is that for a given valid ABN the method returns {@literal true} while the
     * method returns {@literal false} otherwise.
     * </p>
     * <p>
     * The method first tries out some obvious invalid ABNs and then it loads a collection of valid
     * ABNs from the {@link BgxDataValidatorTest#ABN_SAMPLES_PATH} and iterates over each of these
     * number to verify their validity.
     * </p>
     * 
     * @throws IOException	if there is any error while accessing the sample file.
     */
    @Test
    public void testIsValidAbn() throws IOException {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	Assert.assertTrue(validator.isValidAbn("51824753556"));     // valid
    	Assert.assertFalse(validator.isValidAbn("123456"));         // too short
    	Assert.assertFalse(validator.isValidAbn("12345678911"));    // right length, but invalid
    	Assert.assertFalse(validator.isValidAbn("a2c4e6h8j11"));    // contains non-numeric
    	Assert.assertFalse(validator.isValidAbn(""));               // empty string

        // try the ABNs
    	Path source = this.getResourceFile(BgxDataValidatorTest.ABN_SAMPLES_PATH);
        try (Stream<String> lines = Files.lines(source)) {
            lines.forEach(line -> Assert.assertTrue(validator.isValidAbn(line.replaceAll("\\s", ""))));
        }
    }

    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#isValidAbn(String)}
     * when invoked with a {@literal null} argument. The expectation is that the method throws an
     * {@link IllegalArgumentException}.
     * 
     * @throws IllegalArgumentException	expected for a successful test.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testIsValidAbnWithNull() throws IllegalArgumentException {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	validator.isValidAbn(null);
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateAcn(String)}. The
     * method is expected to throw a {@link DataValidationException} if the provided test string is not
     * a valid ABN. The method first tries some obvious invalid ABNs for which it expects the tested
     * method to throw {@link DataValidationException}, it then iterates over a collection of various
     * valid ABNs to test whether any of those fails the validation test.
     * 
     * @throws IOException 	if there is an error accessing the file with the test ABN numbers.
     */
    @Test
    public void testValidateAcn() throws IOException {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	// 1. Valid ACN
    	//
    	String acn = "004085616";
    	try {
    	
    		validator.validateAcn(acn);   // valid
    	
    	} catch(DataValidationException dvex) {
    	
    		Assert.fail(String.format("Valid ACN (%1$s) should not throw DataValidationException.", acn));
    	}
    	
    	// 2. Too short.
    	//
    	acn = "123456";
    	try {
    		
    		validator.validateAcn(acn);
    		Assert.fail(String.format("Invalid ACN (%1$s, length mismatch) should throw DataValidationException.", acn));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}

    	// 3. Right length, but invalid.
    	//
    	acn = "123456789";
    	try {
    		
    		validator.validateAcn(acn);
    		Assert.fail(String.format("Invalid ACN (%1$s, right length, but invalid) should throw DataValidationException.", acn));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}
    	
    	// 4. Contains other characters than 
    	//    numbers.
    	acn = "a2c4e6h8j";
    	try {
    		
    		validator.validateAcn(acn);
    		Assert.fail(String.format("Invalid ACN (%1$s, right length, but not numeric) should throw DataValidationException.", acn));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}
    	
    	// 4. Empty string..
    	acn = "";
    	try {
    		
    		validator.validateAcn(acn);
    		Assert.fail(String.format("Invalid ACN (%1$s, empty string) should throw DataValidationException.", acn));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}

        // try the ACNs from the file.
    	Path source = this.getResourceFile(BgxDataValidatorTest.ACN_SAMPLES_PATH);
        try (Stream<String> lines = Files.lines(source)) {
        	
            lines.forEach(line -> {
            	
            	String acnFile = line.replaceAll("\\s", "");
            	validator.validateAcn(acnFile);
            });
            
        } catch(DataValidationException dvex) {
        	
        	Assert.fail(String.format("Valid ACN should not trigger DataValidationException [Exception: %s].", dvex.getMessage()));
        }
    }

    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateAcn(String)}
     * when invoked with a {@literal null} argument. The expectation is that the method throws an
     * {@link IllegalArgumentException}.
     * 
     * @throws IllegalArgumentException	expected for a successful test.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testValidateAcnWithNull() {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	validator.validateAcn(null);
    }

    /**
     * <p>
     * This method tests the implemented behaviour of {@link BgxDataValidator#isValidAbn(String)}.
     * The expectation is that for a given valid ACN the method returns {@literal true} while the
     * method returns {@literal false} otherwise.
     * </p>
     * <p>
     * The method first tries out some obvious invalid ACNs and then it loads a collection of valid
     * ACNs from the {@link BgxDataValidatorTest#ACN_SAMPLES_PATH} and iterates over each of these
     * number to verify their validity.
     * </p>
     * 
     * @throws IOException	if there is any error while accessing the sample file.
     */
    @Test
    public void testIsValidAcn() throws IOException {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	
    	Assert.assertTrue(validator.isValidAcn("004085616"));   // valid
    	Assert.assertFalse(validator.isValidAcn("123456"));     // too short
    	Assert.assertFalse(validator.isValidAcn("123456789"));  // right length, but invalid
    	Assert.assertFalse(validator.isValidAcn("a2c4e6h8j"));  // contains non-numeric
    	Assert.assertFalse(validator.isValidAcn(""));           // empty string

        // try the ACNs
    	Path source = this.getResourceFile(BgxDataValidatorTest.ACN_SAMPLES_PATH);
        try (Stream<String> lines = Files.lines(source)) {
            lines.forEach(line -> Assert.assertTrue(validator.isValidAcn(line.replaceAll("\\s", ""))));
        }
    }
    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#isValidAcn(String)}
     * when invoked with a {@literal null} argument. The expectation is that the method throws an
     * {@link IllegalArgumentException}.
     * 
     * @throws IllegalArgumentException	expected for a successful test.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testIsValidAcnWithNull() throws IllegalArgumentException {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	validator.isValidAcn(null);
    }
    

    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateBusinessId(String)}. The
     * method is expected to throw a {@link DataValidationException} if the provided test string is neither a
     *valid ABN nor a valid ACN. The method first tries some obvious invalid ABNs for which it expects the tested
     * method to throw {@link DataValidationException}, it then iterates over a collection of various valid ABNs 
     * and ACNs to test whether any of those fails the validation test.
     * 
     * @throws IOException 	if there is an error accessing the file with the test ABN numbers.
     */
    @Test
    public void testValidateBusinessId() throws IOException {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	// 1. Empty string..
    	//
    	String businessId = "";
    	try {
    		
    		validator.validateBusinessId(businessId);
    		Assert.fail(String.format("Invalid business identifier (%1$s, empty stringc) should throw DataValidationException.", businessId));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}
    	
    	// 2. Valid ABN
    	//
    	businessId = "53004085616";
    	try {
    		
    		validator.validateBusinessId(businessId);
    		
    	} catch(DataValidationException dvex) {

    		Assert.fail(String.format("Valid business identifier (%1$s, ABN) should not throw DataValidationException.", businessId));
    	
    		// good to go...
    	}
    	
    	// 3. Valid ACN
    	//
    	businessId = "010749961";
    	try {
    		
    		validator.validateBusinessId(businessId);
    		
    	} catch(DataValidationException dvex) {

    		Assert.fail(String.format("Valid business identifier (%1$s, ACN) should not throw DataValidationException.", businessId));
    	
    		// good to go...
    	}
    	
    	
    	// 4. Invalid ABN
    	//
    	businessId = "12345678911";
    	try {
    		
    		validator.validateBusinessId(businessId);
    		Assert.fail(String.format("Invalid business identifier (%1$s, invalid ABN) should throw DataValidationException.", businessId));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}
    	
    	// 5. Invalid ACN
    	//
    	businessId = "123456789";
    	try {
    		
    		validator.validateBusinessId(businessId);
    		Assert.fail(String.format("Invalid business identifier (%1$s, invalid ACN) should throw DataValidationException.", businessId));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}
    	
    	// 6. Invalid Business Id (characters...)
    	//
    	businessId = "12345mm89";
    	try {
    		
    		validator.validateBusinessId(businessId);
    		Assert.fail(String.format("Invalid business identifier (%1$s, invalid ACN (characters)) should throw DataValidationException.", businessId));
    		
    	} catch(DataValidationException dvex) {
    	
    		// good to go...
    	}

        // try the ABNs from the file.
    	Path source = this.getResourceFile(BgxDataValidatorTest.ABN_SAMPLES_PATH);
        try (Stream<String> lines = Files.lines(source)) {
        	
            lines.forEach(line -> {
            	
            	String abnFile = line.replaceAll("\\s", "");
            	validator.validateBusinessId(abnFile);
            });
            
        } catch(DataValidationException dvex) {
        	
        	Assert.fail(String.format("Valid businessId (ABN) should not trigger DataValidationException [Exception: %s].", dvex.getMessage()));
        }
        
        // try the ABNs from the file.
    	source = this.getResourceFile(BgxDataValidatorTest.ACN_SAMPLES_PATH);
        try (Stream<String> lines = Files.lines(source)) {
        	
            lines.forEach(line -> {
            	
            	String acnFile = line.replaceAll("\\s", "");
            	validator.validateBusinessId(acnFile);
            });
            
        } catch(DataValidationException dvex) {
        	
        	Assert.fail(String.format("Valid businessId (ACN) should not trigger DataValidationException [Exception: %s].", dvex.getMessage()));
        }
    	
    }

    
    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#validateBusinessId(String)}
     * when invoked with a {@literal null} argument. The expectation is that the method throws an {@link 
     * IllegalArgumentException}.
     * 
     * @throws IllegalArgumentException	expected for a successful test.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testValidateBusinessIdWithNull() {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	validator.validateBusinessId(null);
    	
    }
    
    /**
     * <p>
     * This method tests the implemented behaviour of {@link BgxDataValidator#isValidBusinessId(String)}. The
     * expectation is that the method returns {@literal true} if the provided argument is a valid ABN or a 
     * valid ACN, and {@literal false} otherwise.
     * </p>
     * <p>
     * Besides testing the method with some invalid business identifiers (empty string, invalid ABN, invalid ACN)
     * for which it expects a {@link DataValidationException}, the method iterates over a collection of valid ABNs 
     * and valid ACNs to ensure that the tested method does not throw any {@link DataValidationException}.
     * </p>
     * 
     * @throws IOException	the exception is declared to comply to the signature requirements of the method being
     * 						called but not thrown in the context of this test.
     */
    @Test
    public void testIsValidBusinessId() throws IOException {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
        Assert.assertFalse(validator.isValidBusinessId(""));    // empty string
        Assert.assertTrue(validator.isValidBusinessId("53004085616")); // valid ABN
        Assert.assertTrue(validator.isValidBusinessId("010749961"));   // valid ACN
        Assert.assertFalse(validator.isValidBusinessId("12345678911")); // Invalid ABN
        Assert.assertFalse(validator.isValidBusinessId("123456789"));   // Invalid ACN
        Assert.assertFalse(validator.isValidBusinessId("34234inn2"));   // Invalid ACN

        // try the ABNs
        Path source = this.getResourceFile(BgxDataValidatorTest.ABN_SAMPLES_PATH);
        try (Stream<String> lines = Files.lines(source)) {
            lines.forEach(line -> Assert.assertTrue(validator.isValidBusinessId(line.replaceAll("\\s", ""))));
        }


        // try the ACNs
        source = this.getResourceFile(BgxDataValidatorTest.ACN_SAMPLES_PATH);
        try (Stream<String> lines = Files.lines(source)) {
            lines.forEach(line -> Assert.assertTrue(validator.isValidBusinessId(line.replaceAll("\\s", ""))));
        }

    }


    /**
     * This method tests the implemented behaviour of {@link BgxDataValidator#isValidBusinessId(String)}.
     * The expectation is that for a valid ABN/ACN the method does not throw any exception, while for an
     * invalid business identifier that is neither an ABN nor an ACN it throws a {@link DataValidationException}.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testIsValidBusinessIdWithNull() {
    	
    	BgxDataValidator validator = this.getValidator();
    	Assert.assertNotNull("Precondition failed, validator is null.", validator);
    	
    	validator.isValidBusinessId(null);
    }
    
    /**
     * This method is left to the concrete classes that inherit from this test suite
     * and it is used to retrieve the instance of {@link BgxDataValidator} that is 
     * subject to the test.
     * 
     * @return	a {@link BgxDataValidator} instance. It is expected to not to be 
     * 			{@literal null}.
     */
    protected abstract BgxDataValidator getValidator();
    
    /**
     * This method is left to the concrete classes that inherit from this test suite
     * and it is used to retrieve the instance of {@link DefaultTestHelper} that can be
     * used to create mocks and setup test conditions.
     * 
     * @return	a {@link DefaultTestHelper} instance. It is expected to not to be {@literal 
     * 			null}.
     */
    protected abstract DefaultTestHelper getTestHelper();
    
    /**
     * This method is left to the concrete classes that inherit from this test suite and
     * it is used to retrieve the configured instance of {@link TermsAndCondManager} that
     * is used for the validation of the terms and conditions during tests.
     * 
     * @return	a {@link TermsAndCondManager} instance. It is expected to not to be
     * 			{@literal null}.
     */
    protected abstract TermsAndCondManager getTermsAndCondManager();
    
    /**
     * This is a utility method that provides access to the resource file identified
     * by <i>resourcePath</i>.
     * 
     * @param resourcePath	a {@link String} containing the path to the resource file.
     * 
     * @return 	a {@link Path} implementation that points to the resource file.
     */
    protected Path getResourceFile(String resourcePath) {
    	
    	return Paths.get(resourcePath);
    }
    
    /**
     * This is a utility function that is used to create a {@link ContactInfo} instance with the given parameters.
     * 
     * @param firstName		a {@link String} containing the first name for the contact.
     * @param lastName		a {@link String} containing the last name for the contact.
     * @param email			a {@link String} containing the email for the contact.
     * @param phone			a {@link String} containing the phone for the contact.
     * @param roles			a {@link String} array containing the list of roles to assign to the contact.
     * 
     * @return	a {@link ContactInfo} instance containing the contact create out of the given parameters.
     */
    protected ContactInfo createContact(String firstName, String lastName, String email, String phone, String... roles) {
    	
    	ContactInfo contact = new ContactInfo();
    	contact.setFirstName(firstName);
    	contact.setLastName(lastName);
    	contact.setEmail(email);
    	contact.setPhone(phone);
    	
    	List<String> r = new ArrayList<>();
    	for(String role : roles) {
    		r.add(role);
    	}
    	contact.setRoles(r);
    	
    	return contact;
    	
    }
    
}