package com.ibm.au.bgx.queue;

/**
 * @author Peter Ilfrich
 */

import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.repository.UserProfileRepositoryMock;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    TransientQueueClient.class,
    UserProfileRepositoryMock.class
})
public class TransientQueueClientTest {

    @Autowired
    private QueueClient client;

    @Test
    public void testAddWebNotification() throws Exception {
        // reset client before doing anything
        ((TransientQueueClient) client).reset();

        // add notification
        WebNotification m = new WebNotification();
        m.setId("foo");
        m.setReceiverId("bar");
        client.addWebNotification(m);

        // poll and assert
        TransientQueueClient queue = this.castClient();
        WebNotification notification = queue.getQueueWeb().poll();
        Assert.assertEquals(m, notification);
    }

    private TransientQueueClient castClient() {
        return (TransientQueueClient) this.client;
    }
}
