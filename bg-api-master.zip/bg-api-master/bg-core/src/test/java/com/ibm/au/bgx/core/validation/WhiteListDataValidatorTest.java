/**
 * 
 */
package com.ibm.au.bgx.core.validation;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.core.validation.BgxDataValidatorImpl.TermsAndCondResolveMode;
import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.validation.FileWhiteListManager;
import com.ibm.au.bgx.model.validation.WhiteListManager;

/**
 * Class <b>WhiteListDataValidatorTest</b>. This class extends {@link BgxDataValidatorImplTest}
 * and extends the test suite to include all those tests where there is a configured list of
 * organisation profile to white list.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    WhiteListDataValidator.class,
    FileWhiteListManager.class,
    DefaultTestHelper.class,
    TermsAndCondManagerMock.class
})
@TestPropertySource(locations="classpath:application-test.properties")
public class WhiteListDataValidatorTest extends BgxDataValidatorImplTest {
	
	/**
	 * This method tests the implemented behaviour of {@link WhiteListDataValidator#validateProfile(OrgProfile, Status)}
	 * when the profile passed as argument is an organisation profile configured as white listed with the validator. The
	 * expected behaviour is that the validation of the business identifier is skipped. To verify the behaviour the method
	 * sets the business identifier of the white listed profile to an invalid business identifier, which in normal conditions
	 * should throw a {@link DataValidationException}. The absence of such exception, validates the test.
	 */
	@Test
	public void testValidateProfileWithWhiteListedProfile() {
		
		WhiteListDataValidator validator = (WhiteListDataValidator) this.getValidatorWith(TermsAndCondResolveMode.BY_ID, 
																						  false, 
																						  this.platformTCs.getId(), 
																						  this.userTCs.getId(), 
																						  this.getTermsAndCondManager());
		
		// The profile we get from the mock, is a complete profile
		// hence either we remove the agreement blocks or we validate
		// as CONFIRMED.
		//
		DefaultTestHelper helper = this.getTestHelper();
		OrgProfile profile = helper.createOrgProfileMock();
		
		profile.setBusinessId("This is not valid.");
		
		// [CV] NOTE: we mock the white list manager, and we configure the
		//            mock to white list the test profile.
		//
		WhiteListManager manager = Mockito.mock(WhiteListManager.class);
		Mockito.when(manager.isWhiteListed(profile))
		       .thenReturn(true);
		
		validator.whiteListManager = manager;
		
		try {
		
			validator.validateProfile(profile, Status.CONFIRMED);
	
		} catch(DataValidationException dvex) {
			
			Assert.fail("WhiteListDataValidator.validateProfile(OrgProfile,Scope) should not throw DataValidationException for a white listed profile with invalid business identifier.");
		}
	}
	
	
	
	
	/**
	 * This method overrides the base definition to return the specific instance
	 * of {@link WhiteListDataValidator}, which is the type tested by this class.
	 * 
	 * @return a {@link WhiteListDataValidator} instance.
	 */
	@Override
	protected BgxDataValidatorImpl getValidatorInstance() {
		
		return new WhiteListDataValidator();
	}

}
