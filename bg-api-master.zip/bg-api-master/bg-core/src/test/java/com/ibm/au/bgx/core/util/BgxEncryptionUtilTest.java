package com.ibm.au.bgx.core.util;


import java.security.InvalidKeyException;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.chain.ChannelSelectorMock;
import com.ibm.au.bgx.chain.ProfileChainMock;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.common.BgxStatusResource;
import com.ibm.au.bgx.common.rest.IdentityConfiguration;
import com.ibm.au.bgx.core.ApprovalModelCatalogImpl;
import com.ibm.au.bgx.core.OrganizationManagerImpl;
import com.ibm.au.bgx.core.chain.adapter.AddressDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.ProfileDataAdapter;
import com.ibm.au.bgx.core.chain.channel.IbpConfigLoaderImpl;
import com.ibm.au.bgx.core.chain.channel.MockIbpConfigLoaderImpl;
import com.ibm.au.bgx.core.validation.BgxDataValidatorImpl;
import com.ibm.au.bgx.model.pojo.OrgSettings;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.crypto.CryptoKeyInfo;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import com.ibm.au.bgx.queue.TransientQueueClient;
import com.ibm.au.bgx.repository.ChannelUserRepositoryMock;
import com.ibm.au.bgx.repository.EncryptionKeyRepositoryMock;
import com.ibm.au.bgx.repository.OrgProfileRepositoryMock;
import com.ibm.au.bgx.repository.OrganizationRepositoryMock;
import com.ibm.au.bgx.repository.UserProfileRepositoryMock;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.keygen.KeyGenerators;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    OrganizationManagerImpl.class,
    Organization.class,
    OrgSettings.class,
    OrganizationRepositoryMock.class,
    OrgProfileRepositoryMock.class,
    ChannelUserRepositoryMock.class,
    CryptoKeyInfo.class,
    BgxEncryptionUtil.class,
    BgxStatusResource.class,
    ProfileChainMock.class,
    ChannelSelectorMock.class,
    IbpConfigLoaderImpl.class,
    MockIbpConfigLoaderImpl.class,
    ProfileDataAdapter.class,
    AddressDataAdapter.class,
    EncryptionKeyRepositoryMock.class,
    UserProfileRepositoryMock.class,
    ApprovalModelCatalogImpl.class,
    TransientQueueClient.class,
    DefaultTestHelper.class,
    IdentityConfiguration.class,
    BgxDataValidatorImpl.class,
    TermsAndCondManagerMock.class
})
@TestPropertySource(locations = "classpath:application-test.properties")
public class BgxEncryptionUtilTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(BgxEncryptionUtilTest.class);
	
    @Autowired
    protected BgxEncryptionUtil bgxEncryptionUtil;

    // [CV] NOTE: we have an illegal argument exception due to invalid key size.
    //            This is due to the lack of JCE installed on the machine, which
    //            is required to support encryption with AES-256bit.
    //
    @Test
    public void encryptPayload() {
    	
    	
    	try {
	
	        // actual test
	        String text = "Testing $%%^";
	        String encrypted = bgxEncryptionUtil.encrypt(text);
	        Assert.assertEquals(text, bgxEncryptionUtil.decrypt(encrypted));
	
	        // just for debugging
	        String salt = KeyGenerators.string().generateKey();
	        System.out.println("Sample encryption salt: " + salt);
        
    	} catch(IllegalArgumentException iaex) {
    		
    		// This is to cater for those enviroments that do not have JCE installed. We 
    		// still want the build to pass, but we just leave a message.
    		//
    		
    		String errorMessage = String.format("BgxEncryptionUtil.encrypt(String) COULD NOT BE TESTED, because of exception (type: %1$s, message: %2$s).", iaex.getClass().getName(), iaex.getMessage());
    		Throwable cause = iaex.getCause();
    		
    		Assert.assertNotNull(errorMessage, cause);
    		Assert.assertTrue(errorMessage, cause instanceof InvalidKeyException);
    	
    		LOGGER.error("BgxEncryptionUtil.encrypt(String) COULD NOT BE TESTED because of restrictions on the KEY SIZE. Please install JCE to support AES 256 bit encryption (type: {}, message: {}).",
    				     cause.getClass().getName(), cause.getMessage());
    	}

    }

}