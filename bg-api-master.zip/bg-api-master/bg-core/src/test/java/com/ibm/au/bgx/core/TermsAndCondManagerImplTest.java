package com.ibm.au.bgx.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.ibm.au.bgx.DefaultTestHelper;
import com.ibm.au.bgx.chain.TermsAndCondChainMock;
import com.ibm.au.bgx.common.KeyGeneratorImpl;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.core.chain.adapter.TimestampDataAdapter;
import com.ibm.au.bgx.core.chain.adapter.tc.TcContentAdapter;
import com.ibm.au.bgx.core.chain.adapter.tc.TcEmbeddedContentAdapter;
import com.ibm.au.bgx.core.chain.adapter.tc.TcExternalContentAdapter;
import com.ibm.au.bgx.core.chain.adapter.tc.TermsAndCondAdapter;
import com.ibm.au.bgx.model.DocumentStore;
import com.ibm.au.bgx.model.chain.profile.TermsAndCondManager;
import com.ibm.au.bgx.model.pojo.tc.TcExternalContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCondContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCondContent.Type;
import com.ibm.au.bgx.repository.TermsAndCondRepositoryMock;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Unit tests for History manager
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    TermsAndCondManagerImpl.class,
    TermsAndCondAdapter.class,
    TcContentAdapter.class,
    TcEmbeddedContentAdapter.class,
    TcExternalContentAdapter.class,
    TimestampDataAdapter.class,
    TermsAndCondRepositoryMock.class,
    TermsAndCondChainMock.class,
    KeyGeneratorImpl.class,
    DefaultTestHelper.class,
    SSLUtils.class,
    LocalDocumentStore.class
})
@TestPropertySource(locations = "classpath:application-test.properties")
public class TermsAndCondManagerImplTest {

    @Autowired
    TermsAndCondManager manager;

    @Autowired
    DocumentStore documentStore;

    @Autowired
    DefaultTestHelper testHelper;

    @Test
    public void getById() throws Exception {

        List<TermsAndCond> mocks = createMocks(3, Type.EMBEDDED);
        manager.refreshCacheFromChain();

        TermsAndCond tc = manager.getById(mocks.get(1).getId());
        assertNotNull(tc);
        assertEquals(mocks.get(1).getId(), tc.getId());
    }

    @Test
    public void getAll() throws Exception {

        List<TermsAndCond> mocksEmbedded = createMocks(2, Type.EMBEDDED);
        List<TermsAndCond> mocksExternal = createMocks(1, Type.EXTERNAL);

        manager.refreshCacheFromChain();
        List<TermsAndCond> tcs = manager
            .getByTitle(mocksEmbedded.get(1).getTitle());
        assertNotNull(tcs);
        assertNotNull(tcs.get(0));

        tcs = manager.getByScope(Scope.PLATFORM.value());
        assertNotNull(tcs);
        assertNotNull(tcs.get(0));

        tcs = manager.getByTitle("INVALID");
        assertNotNull(tcs);
        assertEquals(0, tcs.size());

        tcs = manager
            .getByTitle(mocksExternal.get(0).getTitle());
        assertNotNull(tcs);
        assertNotNull(tcs.get(0));
        assertEquals(mocksExternal.get(0).getContent().getContentType(),
            tcs.get(0).getContent().getContentType());

        TcExternalContent tec = manager.loadExternalContent(tcs.get(0).getId());
        assertNotNull(tec.getHash());
        assertNotNull(tec.getDocumentId());

    	// [CV] TODO: Remove reference to TermsAndCondManagerImpl and move method
    	//
        assertEquals(tec.getHash(), TermsAndCondManagerImpl.computeHash(tec.getPayload()));

        this.cleanTCDocuments(mocksExternal);
    }

    @Test
    public void updateExternal() throws Exception {

        List<TermsAndCond> mocksExternal = createMocks(1, Type.EXTERNAL);
        manager.refreshCacheFromChain();

        TcExternalContent tec = manager.loadExternalContent(mocksExternal.get(0).getId());
        manager.updateExternalData(mocksExternal.get(0).getId(), tec);
    }

    private List<TermsAndCond> createMocks(int total, TermsAndCondContent.Type tcType)
        throws Exception {

        List<TermsAndCond> mocks = new ArrayList<>();

        if (tcType.equals(Type.EMBEDDED)) {
            for (int i = 0; i < total; i++) {
                TermsAndCond tc = testHelper.createTermsAndCondEmbeddedMock();
                TermsAndCond saved = manager.create(tc);
                mocks.add(saved);
                assertNotNull(saved);
                assertEquals(tc.getId(), saved.getId());
                assertEquals(tc.getTitle(), saved.getTitle());
                assertNotNull(saved.getCreatedAt());
            }
        } else {

            for (int i = 0; i < total; i++) {
                TermsAndCond tc = testHelper.createTermsAndCondExternalMock();
                TermsAndCond saved = manager.create(tc);
                mocks.add(saved);
                assertNotNull(saved);
                assertEquals(tc.getId(), saved.getId());
                assertEquals(tc.getTitle(), saved.getTitle());
                assertNotNull(saved.getCreatedAt());
            }
        }

        return mocks;
    }

    private void cleanTCDocuments(List<TermsAndCond> tcs) {
        for(TermsAndCond tc : tcs) {
            documentStore.deleteDocument(tc.getId());
        }
    }
}