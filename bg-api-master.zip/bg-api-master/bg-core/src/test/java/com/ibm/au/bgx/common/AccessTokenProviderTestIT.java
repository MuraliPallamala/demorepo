package com.ibm.au.bgx.common;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import com.ibm.au.bgx.common.rest.AccessTokenProvider;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;
import com.nimbusds.oauth2.sdk.token.AccessToken;
import com.nimbusds.openid.connect.sdk.token.OIDCTokens;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    AccessTokenProvider.class,
    SSLUtils.class
})
@TestPropertySource(locations = "classpath:application-test.properties")
public class AccessTokenProviderTestIT {

    @Autowired
    AccessTokenProvider accessTokenProvider;

    @Value("${bootstrap.accessTokenUri:PROPERTY_NOT_SET}")
    private String accessTokenUri;

    @Value("${bootstrap.clientId:SET_PROPERTY_NOT_SET}")
    private String clientId;

    @Value("${bootstrap.clientSecret:PROPERTY_NOT_SET}")
    private String clientSecret;

    private OpenIdConfig authConfig;

    @Test
    public void getAccessToken() throws Exception {

        // invalid config should throw exception
        try {
            OpenIdConfig invalid = new OpenIdConfig();
            invalid.setAccessTokenUri(accessTokenUri);
            invalid.setClientId("INVALID");
            invalid.setClientSecret("INVALID");
            accessTokenProvider.getAccessToken(invalid);
        } catch (Exception e) {

        }

        // valid credential should return token
        AccessToken accessToken = accessTokenProvider.getAccessToken(authConfig);
        assertNotNull(accessToken);

        // if we request again, it should provide same token from the cache
        assertEquals(accessToken, accessTokenProvider.getAccessToken(authConfig));
    }

    @Test
    public void removeToken() throws Exception {

        // valid credential should return token
        AccessToken accessToken = accessTokenProvider.getAccessToken(authConfig);
        assertNotNull(accessToken);

        // remove token should succeed
        accessTokenProvider.removeToken(authConfig);

        // it should return a new token
        assertNotEquals(accessToken, accessTokenProvider.getAccessToken(authConfig));
    }

    @Test
    public void storeToken() throws Exception {

        // valid credential should return token
        OIDCTokens tokens = accessTokenProvider.getOIDCToken(authConfig, null);
        assertNotNull(tokens);

        // remove token should succeed
        accessTokenProvider.removeToken(authConfig);

        accessTokenProvider.storeToken(tokens, authConfig);

        // it should return a stored token
        assertEquals(tokens.getAccessToken(), accessTokenProvider.getAccessToken(authConfig));
    }

    @Test
    public void clearAll() throws Exception {

        // valid credential should return token
        AccessToken accessToken = accessTokenProvider.getAccessToken(authConfig);
        assertNotNull(accessToken);

        // remove token should succeed
        accessTokenProvider.removeToken(authConfig);

        // it should return a new token
        assertNotEquals(accessToken, accessTokenProvider.getAccessToken(authConfig));
    }


    @Before
    public void prepareAuthConfig() {

        if (this.authConfig == null) {
            authConfig = new OpenIdConfig();
            authConfig.setAccessTokenUri(accessTokenUri);
            authConfig.setClientId(clientId);
            authConfig.setClientSecret(clientSecret);
        }
    }
}