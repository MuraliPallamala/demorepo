package com.ibm.au.bgx.core;

import static org.junit.Assert.*;

import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.DocumentStore;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Map;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    LocalDocumentStore.class
})
@TestPropertySource(locations = "classpath:application-test.properties")
public class LocalDocumentStoreTest {

    @Autowired
    DocumentStore documentStore;

    @Test
    public void createAndRead() throws Exception {
        String fileId = "test1";

        // delete if it exists
        documentStore.deleteDocument(fileId);

        Map<String, Object> meta = new HashedMap();
        meta.put(BgxConstants.META_CONTENT_TYPE, "application/pdf");

        Path path = Paths.get("src/test/resources/guarantee.pdf");
        try (InputStream inputStream = Files.newInputStream(path)) {
            byte[] bytes = IOUtils.toByteArray(inputStream);
            documentStore.createDocument(fileId, bytes, meta);

            byte[] downloaded = documentStore.readDocument(fileId);
            assertNotNull(downloaded);

            assertEquals(bytes.length, downloaded.length);
            assertArrayEquals(bytes, downloaded);


            Map<String, Object> downloadedMeta = documentStore.readDocumentMeta(fileId);
            assertNotNull(downloadedMeta);
            assertTrue(downloadedMeta.containsKey(BgxConstants.META_CONTENT_TYPE));
            assertEquals(meta, downloadedMeta);

            // cleanup
            documentStore.deleteDocument(fileId);

            // create again without meta
            documentStore.createDocument(fileId, bytes, null);
            assertNull(documentStore.readDocumentMeta(fileId));
        }

        // cleanup
        documentStore.deleteDocument(fileId);
    }

    @Test
    public void createAndReadBase64() throws Exception {
        String fileId = "test2";

        // delete if it exists
        documentStore.deleteDocument(fileId);

        Path path = Paths.get("src/test/resources/guarantee.pdf");
        try (InputStream inputStream = Files.newInputStream(path)) {
            byte[] bytes = IOUtils.toByteArray(inputStream);
            String payload = Base64.getEncoder().encodeToString(bytes);
            documentStore.createDocumentWithBase64(fileId, payload, null);

            String downloaded = documentStore.readDocumentAsBase64(fileId);
            assertNotNull(downloaded);
            assertEquals(payload, downloaded);
        }

        // cleanup
        documentStore.deleteDocument(fileId);
    }

}