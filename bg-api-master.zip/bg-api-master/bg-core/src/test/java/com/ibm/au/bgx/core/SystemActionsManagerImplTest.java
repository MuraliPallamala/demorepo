package com.ibm.au.bgx.core;


import com.ibm.au.bgx.TestBeanConfiguration;
import com.ibm.au.bgx.chain.ChannelSelectorMock;
import com.ibm.au.bgx.chain.GxChainMock;
import com.ibm.au.bgx.chain.ProfileChainMock;
import com.ibm.au.bgx.chain.TermsAndCondChainMock;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.common.KeyGeneratorImpl;
import com.ibm.au.bgx.common.SystemActionsManagerImpl;
import com.ibm.au.bgx.common.audit.AuditManagerImpl;
import com.ibm.au.bgx.common.notification.WebNotificationManagerImpl;
import com.ibm.au.bgx.common.rest.AccessTokenProvider;
import com.ibm.au.bgx.common.rest.GxPrefillClientImpl;
import com.ibm.au.bgx.common.rest.IdentityConfiguration;
import com.ibm.au.bgx.common.rest.NewCoNotificationClientImpl;
import com.ibm.au.bgx.common.rest.filter.OrgProfileFilter;
import com.ibm.au.bgx.common.rest.filter.OrgProfileRequestFilter;
import com.ibm.au.bgx.common.rest.filter.OrgSettingsFilter;
import com.ibm.au.bgx.common.rest.filter.OrganizationFilter;
import com.ibm.au.bgx.common.rest.filter.UserProfileFilter;
import com.ibm.au.bgx.core.approvalmodel.GxLimitValidator;
import com.ibm.au.bgx.core.cache.OrgCacheImpl;
import com.ibm.au.bgx.core.chain.channel.gx.GxChannelProviderImpl;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.core.approvalmodel.GxActionConverterImpl;
import com.ibm.au.bgx.core.util.CoreTestHelper;
import com.ibm.au.bgx.core.util.GxUtil;
import com.ibm.au.bgx.core.validation.BgxDataValidatorImpl;
import com.ibm.au.bgx.model.BgxComponentProvider;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.OrgSettings;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo.Name;
import com.ibm.au.bgx.model.user.BgxPrincipal;
import com.ibm.au.bgx.queue.TransientQueueClient;
import com.ibm.au.bgx.repository.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    SystemActionsManagerImpl.class,
    GxChainMock.class,
    GxRequestRepositoryMock.class,
    WebNotificationManagerImpl.class,
    AuditManagerImpl.class,
    AuditEventRepositoryMock.class,
    OrganizationRepositoryMock.class,
    UserProfileRepositoryMock.class,
    OrgChangeRequestRepositoryMock.class,
    OrgProfileRequestRepositoryMock.class,
    WebNotificationRepositoryMock.class,
    CoreTestHelper.class,
    KeyGeneratorImpl.class,
    BgxComponentProviderImpl.class,
    NewCoNotificationClientImpl.class,
    IdentityConfiguration.class,
    OrganizationManagerImpl.class,
    ApprovalModelCatalogImpl.class,
    ProfileChainMock.class,
    OrgProfileRepositoryMock.class,
    TransientQueueClient.class,
    BgxEncryptionUtil.class,
    ChannelUserRepositoryMock.class,
    EncryptionKeyRepositoryMock.class,
    SSLUtils.class,
    ChannelSelectorMock.class,
    BatchProcessTaskRepositoryMock.class,
    RequestRepositoryMock.class,
    AppBenGxManagerImpl.class,
    ChannelResolverNamePrefixImpl.class,
    ChannelResolverRequestCacheImpl.class,
    GxUtil.class,
    OrgCacheImpl.class,
    GxPrefillRequestRepositoryMock.class,
    GxPrefillClientImpl.class,
    ApprovalModelFlowRequestRepositoryMock.class,
    GxActionConverterImpl.class,
    AccessTokenProvider.class,
    GxLimitValidator.class,
    GxChannelProviderImpl.class,
    OrganizationFilter.class,
    OrgProfileRequestFilter.class,
    UserProfileFilter.class,
    OrgProfileFilter.class,
    OrgSettingsFilter.class,
    BgxDataValidatorImpl.class,
    TermsAndCondManagerMock.class
})
@ContextConfiguration(classes = TestBeanConfiguration.class, loader = AnnotationConfigContextLoader.class)
public class SystemActionsManagerImplTest {

    @Autowired
    SystemActionsManagerImpl actionsManager;

    @Autowired
    CoreTestHelper testHelper;

    @Autowired
    KeyGenerator keyGenerator;

    @Autowired
    BgxComponentProvider bgxComponentProvider;

    @Autowired
    ApplicationContext context;

    @Autowired
    private OrganizationManager organizationManager;

    @Autowired
    BgxPrincipal defaultPrincipal;

    List<String> sampleAdminCerts;


    private Organization org1;

    private BgxPrincipal org1User;

    private Organization org2;
    private BgxPrincipal org2User;

    private Organization org3;
    private BgxPrincipal org3User;

    private Organization issuer;
    private BgxPrincipal issuerUser;

    @Before
    public void createOrgs() throws Exception {
    	
    	this.testHelper.setupTermsAndConds();

        this.sampleAdminCerts = testHelper.getAdminCerts();

        if (org1 == null) {
            org1 = this.createMockOrganizations(1).get(0);
            organizationManager.updateApprovalModel(org1.getId(), Name.SOLE_APPROVER);

            UserProfile userProfile = testHelper.createUserProfileMock(keyGenerator, org1);
            org1User = testHelper.getPrincipal(org1, userProfile);
        }

        if (org2 == null) {

            org2 = this.createMockOrganizations(1).get(0);
            organizationManager.updateApprovalModel(org2.getId(), Name.SOLE_APPROVER);

            UserProfile userProfile = testHelper.createUserProfileMock(keyGenerator, org2);
            org2User = testHelper.getPrincipal(org2, userProfile);
        }

        if (issuer == null) {
            issuer = this.createMockOrganizations(1).get(0);
            organizationManager.updateApprovalModel(issuer.getId(), Name.SOLE_APPROVER);

            UserProfile userProfile = testHelper.createUserProfileMock(keyGenerator, issuer);
            issuerUser = testHelper.getPrincipal(issuer, userProfile);
        }
    }

    // A_SI, B_AF, I_AF
    @Test
    public void createGx() throws Exception {

//        // A_I: Applicant initiates
//        GxIssue gxIssue = GxTestUtil
//            .createGxIssue(org1.getId(), org2.getId(), issuer.getId(), BigInteger.valueOf(5000));
//        SystemActionRequest req1 = new SystemActionRequest();
//        req1.setType(SystemActionType.START_ISSUE_GUARANTEE);
//        req1.setPrincipal(org1User);
//        req1.setPayload(GxTestUtil.createGxIssueRequest(gxIssue));
//
//        IdResponse resp1 = actionsManager.run(req1);
//        assertNotNull(resp1);

        // B_A: Beneficiary approves
//        FlowAction flowAction = new FlowAction();
//        flowAction.setId(UUID.randomUUID().toString());
//        flowAction.setActionType(FlowActionRequestType.APPROVE);
//        flowAction.setFlowId(resp1.getId());
//
//        GxActionRequest gxActionRequest = new GxActionRequest();
//        gxActionRequest.setActionType(GxActionType.APPROVE);
//        gxActionRequest.setPayload(flowAction);
//
//        SystemActionRequest req2 = new SystemActionRequest();
//        req2.setType(SystemActionType.APPROVE_ISSUE_GUARANTEE);
//        req2.setPrincipal(org2User);
//        req2.setPayload(gxActionRequest);
//
//        IdResponse resp2 = actionsManager.run(req2);
//        assertNotNull(resp2);

        // I_A: Issuer approves
    }

    protected List<Organization> createMockOrganizations(int count)
            throws Exception {
        List<Organization> mocks = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            Organization org = this.initailizeOrganization(null, sampleAdminCerts.get(i % sampleAdminCerts.size()));
            mocks.add(org);
        }

        return mocks;
    }

    protected Organization initailizeOrganization(OrgProfileRequest profileRequest,
                                                  String adminCert) throws ProfileCreateException, ProfileChainException {

        if (profileRequest == null) {
            profileRequest = testHelper.createOrgProfileRequestMock();
        }

        profileRequest.getProfile().setId(profileRequest.getId());

        Organization expected = new Organization();
        expected.setProfile(profileRequest.getProfile());
        OrgSettings settings = new OrgSettings();
        expected.setSettings(settings);

        Organization actual = organizationManager.create(profileRequest, adminCert);

        assertNotNull(actual);
        assertNotNull(actual.getId());
        assertNotNull(actual.getProfile());
        assertNotNull(actual.getSettings());
        assertEquals(expected.getProfile().getId(), actual.getProfile().getId());
        assertEquals(expected.getProfile().getEntityName(), actual.getProfile().getEntityName());
        assertEquals(expected.getProfile().getEntityType(), actual.getProfile().getEntityType());
        assertEquals(expected.getProfile().getBusinessId(), actual.getProfile().getBusinessId());
        assertEquals(expected.getProfile().getEntityAddress(), actual.getProfile().getEntityAddress());

        return actual;
    }
}