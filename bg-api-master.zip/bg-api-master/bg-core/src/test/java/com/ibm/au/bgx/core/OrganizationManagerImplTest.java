package com.ibm.au.bgx.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.ibm.au.bgx.chain.ChannelSelectorMock;
import com.ibm.au.bgx.chain.ProfileChainMock;
import com.ibm.au.bgx.chain.TermsAndCondManagerMock;
import com.ibm.au.bgx.common.KeyGeneratorImpl;
import com.ibm.au.bgx.common.notification.WebNotificationManagerImpl;
import com.ibm.au.bgx.common.rest.AccessTokenProvider;
import com.ibm.au.bgx.common.rest.ApiConstants;
import com.ibm.au.bgx.common.rest.IdentityConfiguration;
import com.ibm.au.bgx.common.rest.NewCoNotificationClientImpl;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import com.ibm.au.bgx.common.util.ssl.SSLUtils;
import com.ibm.au.bgx.core.chain.channel.IbpConfigLoaderImpl;
import com.ibm.au.bgx.core.chain.channel.MockIbpConfigLoaderImpl;
import com.ibm.au.bgx.core.util.CoreTestHelper;
import com.ibm.au.bgx.core.validation.BgxDataValidatorImpl;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.KeyGenerator;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.OrgSettings;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Role.Source;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationPublicKey;
import com.ibm.au.bgx.queue.TransientQueueClient;
import com.ibm.au.bgx.repository.AuditEventRepositoryMock;
import com.ibm.au.bgx.repository.BatchProcessTaskRepositoryMock;
import com.ibm.au.bgx.repository.ChannelUserRepositoryMock;
import com.ibm.au.bgx.repository.EncryptionKeyRepositoryMock;
import com.ibm.au.bgx.repository.GxRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrgChangeRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrgProfileRepositoryMock;
import com.ibm.au.bgx.repository.OrgProfileRequestRepositoryMock;
import com.ibm.au.bgx.repository.OrganizationRepositoryMock;
import com.ibm.au.bgx.repository.UserProfileRepositoryMock;
import com.ibm.au.bgx.repository.WebNotificationRepositoryMock;

import java.io.ByteArrayInputStream;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Unit tests for default organization manager
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
    OrganizationManagerImpl.class,
    OrganizationRepositoryMock.class,
    UserProfileRepositoryMock.class,
    ApprovalModelCatalogImpl.class,
    OrgProfileRepositoryMock.class,
    ProfileChainMock.class,
    KeyGeneratorImpl.class,
    CoreTestHelper.class,
    BgxComponentProviderImpl.class,
    NewCoNotificationClientImpl.class,
    IdentityConfiguration.class,
    BgxEncryptionUtil.class,
    ChannelUserRepositoryMock.class,
    EncryptionKeyRepositoryMock.class,
    SSLUtils.class,
    OrgChangeRequestRepositoryMock.class,
    AuditEventRepositoryMock.class,
    OrgProfileRequestRepositoryMock.class,
    BatchProcessTaskRepositoryMock.class,
    ChannelSelectorMock.class,
    MockIbpConfigLoaderImpl.class,
    IbpConfigLoaderImpl.class,
    TransientQueueClient.class,
    WebNotificationManagerImpl.class,
    WebNotificationRepositoryMock.class,
    AccessTokenProvider.class,
    BgxDataValidatorImpl.class,
    TermsAndCondManagerMock.class,
    GxRequestRepositoryMock.class
})
public class OrganizationManagerImplTest {

    @Autowired
    KeyGenerator generator;

    @Autowired
    CoreTestHelper testHelper;

    @Autowired
    private OrganizationManagerImpl manager;

    List<String> sampleAdminCerts;

    @Before
    public void setUp() throws Exception {

        this.sampleAdminCerts = testHelper.getAdminCerts();
        
        this.testHelper.setupTermsAndConds();

        // we need to check that one organization has already been bootstrapped without adminCert input
        // This is required for local java-integration-test where chaincode throws error if the admin org hasn't been bootstrapped
        List<Organization> orgs = manager.getAll();
        if (orgs.size() == 0) {
            this.initializeOrganization(null, null); // create the first org that does not require cert
        }
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void create() throws Exception {
        this.createMocks(1);
    }

    @Test
    public void createWithouthAdminCert() throws Exception {

        OrgProfileRequest profileRequest = testHelper.createOrgProfileRequestMock();
        Organization expected = new Organization();
        expected.setProfile(profileRequest.getProfile());

        Organization actual = manager.create(profileRequest, null);

        assertNotNull(actual);
        assertNotNull(actual.getId());
        assertNotNull(actual.getProfile());
        assertNotNull(actual.getSettings());
        assertEquals(expected.getProfile().getId(), actual.getProfile().getId());
        assertEquals(expected.getProfile().getEntityName(), actual.getProfile().getEntityName());
        assertEquals(expected.getProfile().getEntityType(), actual.getProfile().getEntityType());
        assertEquals(expected.getProfile().getBusinessId(), actual.getProfile().getBusinessId());
        assertEquals(expected.getProfile().getEntityAddress(),
            actual.getProfile().getEntityAddress());
    }

    protected Organization initializeOrganization(OrgProfileRequest profileRequest, String adminCert) throws ProfileCreateException, ProfileChainException {

        if (profileRequest == null) {
            profileRequest = testHelper.createOrgProfileRequestMock();
        }

        profileRequest.getProfile().setId(profileRequest.getId());

        Organization expected = new Organization();
        expected.setProfile(profileRequest.getProfile());
        OrgSettings settings = new OrgSettings();
        expected.setSettings(settings);

        Organization actual = manager.create(profileRequest, adminCert);

        assertNotNull(actual);
        assertNotNull(actual.getId());
        assertNotNull(actual.getProfile());
        assertNotNull(actual.getSettings());
        assertEquals(expected.getProfile().getId(), actual.getProfile().getId());
        assertEquals(expected.getProfile().getEntityName(), actual.getProfile().getEntityName());
        assertEquals(expected.getProfile().getEntityType(), actual.getProfile().getEntityType());
        assertEquals(expected.getProfile().getBusinessId(), actual.getProfile().getBusinessId());
        assertEquals(expected.getProfile().getEntityAddress(), actual.getProfile().getEntityAddress());

        return actual;
    }

    @Test
    public void getByBusinessId() throws Exception {

        List<Organization> mocks = this.createMocks(3);
        List<Organization> records = manager
            .getByBusinessId(mocks.get(1).getProfile().getBusinessId());
        assertNotNull(records);
        assertEquals(mocks.get(1).getProfile().getBusinessId(),
            records.get(0).getProfile().getBusinessId());

        // delete from cache and fetch from chain
        manager.deleteCache(mocks.get(1).getId());
        List<Organization> orgs = manager
            .getByBusinessId(mocks.get(1).getProfile().getBusinessId());
        assertEquals(1, orgs.size());
        assertEquals(mocks.get(1).getProfile().getId(), orgs.get(0).getProfile().getId());
        assertEquals(mocks.get(1).getProfile().getBusinessId(), orgs.get(0).getProfile().getBusinessId());
    }

    @Test
    public void getByEntityName() throws Exception {
        List<Organization> mocks = this.createMocks(3);
        List<Organization> records = manager
            .getByEntityName(mocks.get(1).getProfile().getEntityName());
        assertNotNull(records);
        assertEquals(1, records.size());

        boolean found = false;
        for (Organization saved : records) {
            if (mocks.get(1).getProfile().getBusinessId()
                .equals(saved.getProfile().getBusinessId())) {
                found = true;
            }
        }

        assertTrue(found);

        // delete from cache and fetch from profile chain
        manager.deleteCache(mocks.get(1).getId());
        List<Organization> org = manager.getByEntityName(mocks.get(1).getProfile().getEntityName());
        assertNotNull(org);
        assertEquals(1, org.size());
        assertEquals(mocks.get(1).getProfile().getEntityName(),  org.get(0).getProfile().getEntityName());
        assertEquals(mocks.get(1).getProfile().getId(), org.get(0).getProfile().getId());
    }

    @Test
    public void getAll() throws Exception {
        List<Organization> mocks = this.createMocks(3);

        List<Organization> records = manager.getAll();
        assertTrue(records.size() >= 3);

        for (Organization org : mocks) {
            manager.deleteCache(org.getId());
        }

        manager.refreshCache();
        records = manager.getAll();
        assertTrue(mocks.size() >= 3);

        for (Organization mock : mocks) {
            boolean found = false;
            for (Organization org : records) {
                if (mock.getId().equals(org.getId())) {
                    found = true;
                    break;
                }
            }

            assertTrue(found);
        }
    }

    @Test
    public void getPublicKeys() throws Exception {

        List<Organization> mocks = new ArrayList<>();

        mocks = this.createMocks(3);

        Map<String, OrganizationPublicKey> records = manager.getPublicKeys(mocks.get(1).getProfile().getId());
        assertNotNull(records);
        assertTrue(records.containsKey(ApiConstants.KEY_DEFAULT));

        // parse the cert
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        Certificate cert = cf.generateCertificate(new ByteArrayInputStream(sampleAdminCerts.get(1).getBytes()));

        assertEquals(cert.getPublicKey(), BgxEncryptionUtil.parsePemPublicKey(records.get(ApiConstants.KEY_DEFAULT).getKey(), BgxEncryptionUtil.ECDSA));
    }

    protected List<Organization> createMocks(int count)
        throws Exception {
        List<Organization> mocks = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            Organization org = this.initializeOrganization(null, sampleAdminCerts.get(i % sampleAdminCerts.size()));
            mocks.add(org);
        }

        return mocks;
    }

    @Test
    public void getByKey() throws Exception {

        List<Organization> mocks = this.createMocks(3);

        for (Organization org : mocks) {
            org.getSettings().setKey(generator.newKey(BgxConstants.ORG_KEY_LEN));
            manager.updateCache(org);
        }

        Organization record = manager
            .getByKey(mocks.get(1).getSettings().getKey());
        assertNotNull(record);
        assertEquals(mocks.get(1), record);
    }

    @Test
    public void getDefaultPublicKey() throws Exception {

        List<Organization> mocks = this.createMocks(3);

        int index = 1;

        // parse the cert
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        Certificate cert = cf.generateCertificate(new ByteArrayInputStream(sampleAdminCerts.get(index).getBytes()));

        PublicKey publicKey = manager.getDefaultPublicKey(mocks.get(index).getProfile().getId());
        assertNotNull(publicKey);
        assertEquals(cert.getPublicKey(), publicKey);
    }

    @Test
    public void getPrimaryContact() throws Exception {

        List<Organization> mocks = this.createMocks(1);

        int index = 0;

        ContactInfo expected = null;
        for (ContactInfo contactInfo : mocks.get(index).getProfile().getContacts()) {
            if (contactInfo.getRoles().contains(BgxConstants.ROLE_ADMIN)) {
                expected = contactInfo;
                break;
            }
        }

        ContactInfo primaryContact = manager.getPrimaryContact(mocks.get(index));
        assertNotNull(primaryContact);
        assertEquals(expected, primaryContact);
    }

    @Test
    public void getAdminContacts() throws Exception {
        List<Organization> mocks = this.createMocks(1);

        int index = 0;

        List<ContactInfo> expected = new ArrayList<>();
        for (ContactInfo contactInfo : mocks.get(index).getProfile().getContacts()) {
            if (contactInfo.getRoles().contains(BgxConstants.ROLE_ADMIN)) {
                expected.add(contactInfo);
            }
        }

        List<ContactInfo> adminContacts = manager.getAdminContacts(mocks.get(index));
        assertNotNull(adminContacts);
        assertEquals(expected, adminContacts);
    }

    @Test
    public void getAdminContact() throws Exception {
        List<Organization> mocks = this.createMocks(1);

        int index = 0;

        ContactInfo expected = null;
        for (ContactInfo contactInfo : mocks.get(index).getProfile().getContacts()) {
            if (contactInfo.getRoles().contains(BgxConstants.ROLE_ADMIN)) {
                expected = contactInfo;
                break;
            }
        }

        ContactInfo adminContact = manager.getAdminContact(mocks.get(index), expected.getEmail());
        assertNotNull(adminContact);
        assertEquals(expected, adminContact);
    }

    @Test
    public void getContact() throws Exception {
        List<Organization> mocks = this.createMocks(1);

        int index = 0;

        ContactInfo expected = null;
        for (ContactInfo contactInfo : mocks.get(index).getProfile().getContacts()) {
            if (contactInfo.getRoles().contains(BgxConstants.ROLE_ADMIN)) {
                expected = contactInfo;
                break;
            }
        }

        ContactInfo adminContact = manager.getContact(mocks.get(index), expected.getEmail());
        assertNotNull(adminContact);
        assertEquals(expected, adminContact);
    }

    @Test
    public void getByApiAuthJwtIssuer() throws Exception {

        List<Organization> mocks = this.createMocks(1);
        int index = 0;

        // set issuer config
        String issuer = "http://issuer.com/api/" + UUID.randomUUID().toString();
        OrgSettings settings = new OrgSettings();
        settings.setApiAuth(new OpenIdConfig());
        settings.getApiAuth().setIssuer(issuer);
        mocks.get(index).setSettings(settings);
        manager.updateCache(mocks.get(index));

        List<Organization> orgs = manager.getByApiAuthJwtIssuer(issuer);
        assertNotNull(orgs);
        assertEquals(mocks.get(index), orgs.get(0));
    }

    @Test
    public void getByUserAuthJwtIssuer() throws Exception {
        List<Organization> mocks = this.createMocks(1);
        int index = 0;

        // set issuer config
        String issuer = "http://issuer.com/user/" + UUID.randomUUID().toString();
        OrgSettings settings = new OrgSettings();
        settings.setUserAuth(new OpenIdConfig());
        settings.getUserAuth().setIssuer(issuer);
        mocks.get(index).setSettings(settings);
        manager.updateCache(mocks.get(index));

        List<Organization> orgs = manager.getByUserAuthJwtIssuer(issuer);
        assertNotNull(orgs);
        assertEquals(mocks.get(index), orgs.get(0));
    }

    @Test
    public void prepareRealmName() throws Exception {
        List<Organization> mocks = this.createMocks(1);
        int index = 0;

        mocks.get(index).setSettings(new OrgSettings());
        mocks.get(index).getSettings().setKey(generator.newKey(BgxConstants.ORG_KEY_LEN));
        manager.updateCache(mocks.get(index));

        assertTrue(manager.prepareRealmName(mocks.get(index).getId())
            .equals(manager.prepareRealmName(mocks.get(index))));
    }

    @Test
    public void getSystemRole() throws Exception {

        List<Organization> mocks = this.createMocks(1);
        int index = 0;

        Organization org = manager.setDefaultRoles(mocks.get(index));

        assertTrue(manager.getSystemRole(org, BgxConstants.ROLE_ADMIN).getRoleName()
            .equals(BgxConstants.ROLE_ADMIN));
        assertTrue(manager.getSystemRole(org, BgxConstants.ROLE_PRIMARY).getRoleName()
            .equals(BgxConstants.ROLE_PRIMARY));
        assertTrue(manager.getSystemRole(org, BgxConstants.ROLE_USER).getRoleName()
            .equals(BgxConstants.ROLE_USER));
    }

    @Test
    public void getOrgRole() throws Exception {

        List<Organization> mocks = this.createMocks(1);
        int index = 0;

        Organization org = manager.setDefaultRoles(mocks.get(index));

        assertTrue(manager.getOrgRole(org, BgxConstants.ROLE_ADMIN).getRoleName()
            .equals(BgxConstants.ROLE_ADMIN));
    }

    @Test
    public void isValidRole() throws Exception {
        List<Organization> mocks = this.createMocks(1);
        int index = 0;

        Organization org = manager.setDefaultRoles(mocks.get(index));
        assertTrue(manager.isValidRole(org, BgxConstants.ROLE_USER));
        assertTrue(manager.isValidRole(org, BgxConstants.ROLE_USER, Source.SYSTEM));
    }

    @Test
    public void testUpdateAdminContactsRejectUser() throws Exception {
        OrgProfileRequest profileRequest = testHelper.createOrgProfileRequestMock();

        String email = "abc@abc.com";
        ContactInfo admin = new ContactInfo();
        admin.setFirstName("Anthony");
        admin.setLastName("Admin");
        admin.setPhone("+6192929292");
        admin.setEmail(email);
        admin.setRoles(new ArrayList<>(Arrays.asList(new String[] { BgxConstants.ROLE_ADMIN })));
        ContactInfo primary = new ContactInfo();
        primary.setEmail("bla@bla.com");
        primary.setFirstName("John");
        primary.setLastName("Blah");
        primary.setPhone("+6192929292");
        primary.setAgreement(profileRequest.getProfile().getContacts().get(0).getAgreement());
        primary.setRoles(new ArrayList<>(Arrays.asList(new String[] { BgxConstants.ROLE_PRIMARY })));

        List<ContactInfo> contacts = new ArrayList<>(Arrays.asList(primary, admin));

        profileRequest.getProfile().setContacts(contacts);

        Organization org = this.initializeOrganization(profileRequest, sampleAdminCerts.get(0));

        org = manager.updateAdminContactsRejectUser(org, email, false);
        assertEquals(1, org.getProfile().getContacts().size());
        assertTrue(org.getProfile().getContacts().get(0).getRoles().contains(BgxConstants.ROLE_ADMIN));
        assertTrue(org.getProfile().getContacts().get(0).getRoles().contains(BgxConstants.ROLE_PRIMARY));
        assertNotEquals(email, org.getProfile().getContacts().get(0).getEmail());
    }
}