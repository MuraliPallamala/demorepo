package com.ibm.au.bgx.common.util;

import com.ibm.au.bgx.common.rest.IdentityConfiguration;
import com.ibm.au.bgx.model.IdentityConfig;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.repository.OrganizationRepository;
import com.ibm.au.bgx.repository.OrganizationRepositoryMock;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigInteger;

/**
 * @author Peter Ilfrich
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {
        OrganizationRepositoryMock.class,
        IdentityConfiguration.class,
        ErrorCodeUtil.class,
})
public class ErrorCodeUtilTest {

    @Autowired
    IdentityConfig config;

    @Autowired
    OrganizationRepository orgRepo;

    @Test
    public void testTopicPrefix() {
        int onboardingPrefix = ErrorCodeUtil.getTopicPrefix(ErrorCodeUtil.ErrorTopic.ONBOARDING);
        int orgPrefix = ErrorCodeUtil.getTopicPrefix(ErrorCodeUtil.ErrorTopic.ORG_MANAGEMENT);
        int userPrefix = ErrorCodeUtil.getTopicPrefix(ErrorCodeUtil.ErrorTopic.USER_MANAGEMENT);
        int loginPrefix = ErrorCodeUtil.getTopicPrefix(ErrorCodeUtil.ErrorTopic.LOGIN);

        Assert.assertEquals(0, onboardingPrefix % 1000);
        Assert.assertEquals(0, orgPrefix % 1000);
        Assert.assertEquals(0, userPrefix % 1000);
        Assert.assertEquals(0, loginPrefix % 1000);

        Assert.assertFalse(onboardingPrefix == orgPrefix);
        Assert.assertFalse(onboardingPrefix == userPrefix);
        Assert.assertFalse(onboardingPrefix == loginPrefix);
        Assert.assertFalse(userPrefix == loginPrefix);
        Assert.assertFalse(userPrefix == orgPrefix);
        Assert.assertFalse(orgPrefix == loginPrefix);
    }

    @Test
    public void testGetPrefixedErrorCode() {
        Organization admin = new Organization();
        admin.setId("newco-admin");
        OrgProfile adminOrgProfile = new OrgProfile();
        adminOrgProfile.setEntityType(OrgProfile.EntityType.CONSORTIUM);
        admin.setProfile(adminOrgProfile);
        orgRepo.addItem(admin);

        Organization issuer = new Organization();
        issuer.setId("anz");
        OrgProfile issuerProfile = new OrgProfile();
        issuerProfile.setEntityType(OrgProfile.EntityType.ISSUER);
        issuer.setProfile(issuerProfile);
        orgRepo.addItem(issuer);

        Organization newco = new Organization();
        newco.setId("newco");
        OrgProfile newcoProfile = new OrgProfile();
        newcoProfile.setEntityType(OrgProfile.EntityType.CONSORTIUM);
        newco.setProfile(newcoProfile);
        orgRepo.addItem(newco);

        this.config.setIdentity("newco-admin");
        BigInteger adminCode = ErrorCodeUtil.getPrefixedErrorCode(ErrorCodeUtil.ErrorTopic.USER_MANAGEMENT, 137);

        this.config.setIdentity("anz");
        BigInteger issuerCode = ErrorCodeUtil.getPrefixedErrorCode(ErrorCodeUtil.ErrorTopic.USER_MANAGEMENT, 137);

        this.config.setIdentity("newco");
        BigInteger newcoCode = ErrorCodeUtil.getPrefixedErrorCode(ErrorCodeUtil.ErrorTopic.BANK_GUARANTEE, 137);

        Assert.assertNotEquals(adminCode, issuerCode);
        Assert.assertNotEquals(adminCode, newcoCode);
        Assert.assertNotEquals(issuerCode, newcoCode);

        Assert.assertEquals(adminCode.mod(BigInteger.valueOf(10000)), issuerCode.mod(BigInteger.valueOf(10000)));
        Assert.assertNotEquals(adminCode.mod(BigInteger.valueOf(10000)), newcoCode.mod(BigInteger.valueOf(10000)));

        try {
            ErrorCodeUtil.getPrefixedErrorCode(ErrorCodeUtil.ErrorTopic.BANK_GUARANTEE, 1337);
            Assert.assertTrue(false);
        } catch (IllegalArgumentException ia) {
            // this is expected
        }
    }

}
