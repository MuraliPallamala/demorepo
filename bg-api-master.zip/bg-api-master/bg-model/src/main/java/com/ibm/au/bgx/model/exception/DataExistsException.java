package com.ibm.au.bgx.model.exception;

/**
 * Class <b>DataExistsException</b>. This class extends {@link DataException} and
 * provides a specific type for all those data error conditions in which a specific
 * data entity that is already existing is being created again. This condition may
 * arise for instance in cases where concurrent executions attempt to create the
 * same entity.
 *
 * @author Christian Vecchiola
 * @email christian.vecchiola@au.ibm.com
 * @date 05/05/2014
 */
public class DataExistsException extends DataException {


    /**
     * This is for versioning and serialisation.
     */
    private static final long serialVersionUID = 5350798792729967562L;


    /**
     * Initialises a new instance of {@link DataExistsException}.
     */
    public DataExistsException() {

    }

    /**
     * Initialises a new instance of {@link DataExistsException} with
     * the given <i>message</i>.
     *
     * @param message a {@link String} that provides a human intelligible
     *                information about the error that occurred and created
     *                this instance of {@link DataExistsException} to occur.
     */
    public DataExistsException(String message) {
        super(message);
    }

    /**
     * Initialises a new instance of the {@link DataExistsException} with
     * the given inner exception.
     *
     * @param innerException a {@link Throwable} instance that represents
     *                       the cause of this instance of {@link DataExistsException}
     *                       to be created.
     */
    public DataExistsException(Throwable innerException) {
        super(innerException);
    }


    /**
     * Initialises a new instance of the {@link DataExistsException} with the given
     * <i>message</i> and <i>innerException</i>.
     *
     * @param message        a {@link String} containing a human intelligible
     *                       message providing information about the cause
     *                       of the exception.
     * @param innerException a {@link Throwable} instance that represents
     *                       the cause of this instance of {@link DataExistsException}
     *                       to be created.
     */
    public DataExistsException(String message, Throwable innerException) {
        super(message, innerException);
    }
}
