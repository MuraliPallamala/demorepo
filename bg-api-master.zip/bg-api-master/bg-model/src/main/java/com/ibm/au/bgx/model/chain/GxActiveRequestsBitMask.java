package com.ibm.au.bgx.model.chain;

/**
 * 
 *
 */
public class GxActiveRequestsBitMask {
	/**
	 * 
	 */
    public static int AMEND = 0b00000001;
    /**
     * 
     */
    public static int CANCEL = 0b00000010;
    /**
     * 
     */
    public static int DEMAND = 0b00000100;
    /**
     * 
     */
    public static int PAYWALK = 0b00001000;
    /**
     * 
     */
    public static int TRANSFER = 0b00010000;
}
