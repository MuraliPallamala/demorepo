/**
 * 
 */
package com.ibm.au.bgx.model.text;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Class <b>FileTemplateReference</b>. This class extends {@link UrlTemplateReference} and 
 * model a reference to a template that is located in the file system accessible to the local
 * context. 
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
public class FileTemplateReference extends UrlTemplateReference {
	
	/**
	 * This constant stores the value of the file protocol scheme.
	 * This is needed to have an appropriate representation of the
	 * URL that points to a file.
	 */
	public static final String FILE_PROTOCOL_PREFIX = "file://";
	
	/**
	 * A {@link File} instance that provides access to the location
	 * of the template, referenced by instance.
	 */
	protected File file;
	
	/**
	 * Initialises an instance of {@link FileTemplateReference} with the
	 * given <i>path</i>. 
	 * 
	 * @param path	a {@link String} containing the path to the file that
	 * 				stores the template's content. It can either be in the
	 * 				fully qualified form: 'file://<absolute-path-to-file>'
	 * 				or without the protocol scheme. It cannot be {@literal 
	 * 				null}.
	 * 
	 * @throws IllegalArgumentException	if <i>path</i> is {@literal null}.
	 */
	public FileTemplateReference(String path) {
		super(path != null ? (path.startsWith(FileTemplateReference.FILE_PROTOCOL_PREFIX) ? path : FileTemplateReference.FILE_PROTOCOL_PREFIX + path) : path);

		if (path.startsWith(FileTemplateReference.FILE_PROTOCOL_PREFIX)) {
			
			path = path.substring(FileTemplateReference.FILE_PROTOCOL_PREFIX.length());
		}
		
		this.file = new File(path);
	}
	
	/**
	 * Gets the template's file.
	 * 
	 * @return	a {@link File} instance that provides access to the
	 * 			template in the local file system.
	 */
	public File getFile() {
		
		return this.file;
	}
	
	/**
	 * Gets the path to the template's file.
	 * 
	 * @return	a {@link String} containing the path to the file of the template. 
	 * 			This value is the same as the one returned by {@link File#getPath()}
	 * 		    when invoked on the instance returned by {@link #getFile()}.
	 */
	public String getPath() {
		
		return this.file.getPath();
	}
	
	/**
	 * Returns the stream that can be used to read the template's content.
	 * 
	 * @return 	a {@link InputStream} implementation that provides access
	 * 			to the template's content.
	 */
	@Override
	public InputStream getStream() throws IOException {
	
		return new FileInputStream(this.file);
	}

}
