package com.ibm.au.bgx.model.exception;

/**
 * Class <b>DataNotFoundException</b>. This class extends {@link DataException} and
 * provides a specific type for all those data error conditions in which a specific
 * element of data is expected to be found but it is not present.
 *
 * @author Christian Vecchiola
 * @email christian.vecchiola@au.ibm.com
 * @date 05/05/2014
 */
public class DataNotFoundException extends DataException {


    /**
     * This is for versioning and serialisation.
     */
    private static final long serialVersionUID = 5820798792729967562L;


    /**
     * Initialises a new instance of {@link DataNotFoundException}.
     */
    public DataNotFoundException() {

    }

    /**
     * Initialises a new instance of {@link DataNotFoundException} with
     * the given <i>message</i>.
     *
     * @param message a {@link String} that provides a human intelligible
     *                information about the error that occurred and created
     *                this instance of {@link DataNotFoundException} to occur.
     */
    public DataNotFoundException(String message) {
        super(message);
    }

    /**
     * Initialises a new instance of the {@link DataNotFoundException} with
     * the given inner exception.
     *
     * @param innerException a {@link Throwable} instance that represents
     *                       the cause of this instance of {@link DataNotFoundException}
     *                       to be created.
     */
    public DataNotFoundException(Throwable innerException) {
        super(innerException);
    }


    /**
     * Initialises a new instance of the {@link DataNotFoundException} with the given
     * <i>message</i> and <i>innerException</i>.
     *
     * @param message        a {@link String} containing a human intelligible
     *                       message providing information about the cause
     *                       of the exception.
     * @param innerException a {@link Throwable} instance that represents
     *                       the cause of this instance of {@link DataNotFoundException}
     *                       to be created.
     */
    public DataNotFoundException(String message, Throwable innerException) {
        super(message, innerException);
    }
}
