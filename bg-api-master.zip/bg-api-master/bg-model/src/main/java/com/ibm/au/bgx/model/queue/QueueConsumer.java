package com.ibm.au.bgx.model.queue;

import java.io.IOException;

/**
 * @author Peter Ilfrich
 */
public interface QueueConsumer {

	/**
	 * 
	 * @param queueName
	 * @param client
	 * @throws IOException
	 */
    void registerConsumer(String queueName, QueueClient client) throws IOException;

    /**
     *
     */
    interface EmailQueueConsumer extends QueueConsumer {

    }
    
    /**
     *
     */
    interface WebQueueConsumer extends QueueConsumer {

    }

    /**
     *
     */
    interface ImpexQueueConsumer extends QueueConsumer {

    }

    /**
     *
     */
    interface ReportQueueConsumer extends QueueConsumer {

    }

    /**
     *
     */
    interface BatchProcessTaskConsumer extends QueueConsumer {

    }

    /**
     *
     */
    interface BlockchainEventConsumer extends QueueConsumer {

    }

    // This is to sync network participants about various configurations
    /**
     *
     */
    interface NetworkSyncQueueConsumer extends QueueConsumer {

    }
}
