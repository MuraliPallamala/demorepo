package com.ibm.au.bgx.model.exception;

/**
 * Class <b>DataException</b>. This class extends {@link RuntimeException} and
 * provides a root type exception for various data related exception
 *
 * @author Christian Vecchiola
 * @email christian.vecchiola@au.ibm.com
 * @date 05/05/2014
 */
public class DataException extends RuntimeException {


    /**
     * This is for versioning and serialisation.
     */
    private static final long serialVersionUID = 7620798792729967562L;


    /**
     * Initialises a new instance of {@link DataException}.
     */
    public DataException() {

    }

    /**
     * Initialises a new instance of {@link DataException} with
     * the given <i>message</i>.
     *
     * @param message a {@link String} that provides a human intelligible
     *                information about the error that occurred and created
     *                this instance of {@link DataException} to occur.
     */
    public DataException(String message) {
        super(message);
    }

    /**
     * Initialises a new instance of the {@link DataException} with
     * the given inner exception.
     *
     * @param innerException a {@link Throwable} instance that represents
     *                       the cause of this instance of {@link DataException}
     *                       to be created.
     */
    public DataException(Throwable innerException) {
        super(innerException);
    }


    /**
     * Initialises a new instance of the {@link DataException} with the given
     * <i>message</i> and <i>innerException</i>.
     *
     * @param message        a {@link String} containing a human intelligible
     *                       message providing information about the cause
     *                       of the exception.
     * @param innerException a {@link Throwable} instance that represents
     *                       the cause of this instance of {@link DataException}
     *                       to be created.
     */
    public DataException(String message, Throwable innerException) {
        super(message, innerException);
    }
}
