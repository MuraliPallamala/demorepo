package com.ibm.au.bgx.model;

import com.ibm.au.bgx.model.user.BgxPrincipal;

/**
 * Interface <b>PrincipalProvider</b>. This interface defines the contract for
 * components that can supply a {@link BgxPrincipal} implementation which 
 * represents the identity that is currently bound to the execution context. The
 * security principal is essential to perform the majority of the operations in
 * the platform, which are influenced by the user that is currently logged in.
 * 
 * @author Peter Ilfrich
 */
public interface PrincipalProvider {

	/**
	 * Gets the security principal that is bound to the current execution
	 * context.
	 * 
	 * @return	a {@link BgxPrincipal} implementation representing the security
	 * 			identity associated to the current execution context. It can
	 * 			be {@literal null} if no principal has been resolved.
	 */
    BgxPrincipal getPrincipal();
}
