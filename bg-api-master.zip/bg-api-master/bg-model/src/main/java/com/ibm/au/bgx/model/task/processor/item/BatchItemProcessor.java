package com.ibm.au.bgx.model.task.processor.item;

import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import java.util.Map.Entry;

/**
 * Interface <b>BatchItemProcessor</b>. Defines the contract of a generic batch
 * task processor. The interface exposes only one method that provides the main
 * entry point for the execution of the task.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public interface BatchItemProcessor {

	/**
	 * <p>
	 * Executes the given <i>task</i>. Implementations must contain the execution errors generated 
	 * by the task within the <i>task</i> instance by adding the information to the task itself by 
	 * leveraging the methods:
	 * <ul>
	 * <li>{@link BatchProcessTask#setHasError(Boolean)}</li>
	 * <li>{@link BatchProcessTask#setErrorLogs(java.util.List)}</li>
	 * <ul>
	 * Runtime exceptions can still be thrown for exceptional conditions, that would not allow for
	 * the execution of the task in any condition.
	 * </p>
	 * <p>
	 * Upon the invocation of the method the status of the task provides information about the
	 * outcome of the execution.
	 * </p>
	 * 
	 * @param task	a {@link BatchProcessTask} instance that represents the task to be processed. 
	 * 				It cannot be {@literal null}.
	 * 
	 * @param entry	a {@link Entry} instance representing key-value pair that provides additional
	 * 				runtime information to specialise the execution of the task. It can be {@literal 
	 * 				null} if no additional information is needed.
	 * 
	 * @throws IllegalArgumentException if <i>task</i> is {@literal null}.
	 */
    void process(BatchProcessTask task, Entry<String, Object> entry);
}
