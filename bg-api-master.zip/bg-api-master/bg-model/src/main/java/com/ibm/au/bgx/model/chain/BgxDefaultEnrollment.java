package com.ibm.au.bgx.model.chain;

/**
 * Class <i>DefaultEnrollment</i>. This class is the default implementation of the {@link org.hyperledger.fabric.sdk.Enrollment}
 * interface. It provides a default behaviour to store the user enrollment certificate.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com> 
 */

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ibm.au.bgx.fabric.model.DefaultEnrollment;
import java.io.Serializable;
import java.security.PrivateKey;
import org.hyperledger.fabric.sdk.Enrollment;

/**
 * 
 *
 */
@JsonSerialize(using = BgxDefaultEnrollmentSerializer.class)
@JsonDeserialize(using = BgxDefaultEnrollmentDeserializer.class)
public class BgxDefaultEnrollment extends DefaultEnrollment implements Enrollment, Serializable {

	/**
	 * 
	 */
    private static final long serialVersionUID = 760416991376968096L;

    /**
     * 
     * @param privateKey
     * @param signedPem
     */
    public BgxDefaultEnrollment(PrivateKey privateKey, String signedPem) {
        super(privateKey, signedPem);
    }

    /**
     * 
     * @param enrollment
     */
    public BgxDefaultEnrollment(Enrollment enrollment) {
        super(enrollment.getKey(), enrollment.getCert());
    }
}
