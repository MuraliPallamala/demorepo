package com.ibm.au.bgx.model;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface  KeyGenerator {

	/**
	 * @param len 
	 * @return 
	 */
    String newKey(int len);

    /**
     * 
     * @param len
     * @return
     */
    String newNumeric(int len);

    /**
     * 
     * @param orgKey
     * @param userKey
     * @return
     */
    String getCompositeKey(String orgKey, String userKey);

    /**
     * 
     * @param compositeKey
     * @return
     */
    String getOrgKey(String compositeKey);

    /**
     * 
     * @param compositeKey
     * @return
     */
    String getUserKey(String compositeKey);

    /**
     * 
     * @param compositeKey
     * @return
     */
    boolean isValidCompositeKey(String compositeKey);
}
