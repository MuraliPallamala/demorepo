/**
 * 
 */
package com.ibm.au.bgx.model.api;

import java.math.BigInteger;

/**
 * Class <b>ApiErrorCodes</b>. This class defines all the error codes that
 * are used by the API to communicate to the client the nature of the error
 * that has occurred. The error codes maintain a structure that facilitate
 * the identification of the error just by looking at the value of the code.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class ApiErrorCodes {
	
	/**
	 * This is a multiplier that can be used to compose a detailed error with
	 * a category constant, which is one of the numbers defined in this class.
	 */
	public static final int API_ERROR_GROUP				= 0xFFFF;	 
	
	/**
	 * This error code indicates invalid input. This is very generic error 
	 * code that is produced by the API when the content of the request could
	 * not be properly interpreted.
	 */
	public static final int ERROR_INVALID_INPUT 		= 0x00010;
	
	/**
	 * This error code indicates that there is a problem in relation to the
	 * data validation.
	 */
	public static final int ERROR_DATA_VALIDATION 		= 0x00020;
	
	/**
	 * Gets the specific error code that is obtained by composing the category
	 * and the specific error code passed as argument. 
	 * 
	 * @param errorCodeGroup	a {@literal int} value that represents the
	 * 							category of the error. It is expected to be
	 * 							a positive number.
	 * 
	 * @param errorCode			a {@literal int} value that represents the 
	 * 							specific error code. It is expected to be a
	 * 							positive number.
	 * 
	 * @return	a {@link BigInteger} value that indicates the resulting error
	 * 			code as a composition of the following: <i>errorCodeGroup</i> 
	 * 	        <i>{@link ApiErrorCodes#API_ERROR_GROUP}</i> + <i>errorCode</i>.
	 */
	public static BigInteger getErrorCode(int errorCodeGroup, int errorCode) {
		
		return BigInteger.valueOf(errorCodeGroup)
				         .multiply(BigInteger.valueOf(ApiErrorCodes.API_ERROR_GROUP))
				         .add(BigInteger.valueOf(errorCode));
		
	}

}
