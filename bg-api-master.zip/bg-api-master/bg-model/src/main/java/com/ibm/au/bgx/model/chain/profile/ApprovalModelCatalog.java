package com.ibm.au.bgx.model.chain.profile;

import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo.Name;

import java.io.IOException;
import java.util.List;

/**
 * Interface <b>ApprovalModelCatalog</b>. Provide access to the collection of approval model
 * implementations that are available in the platform. Approval models are used to determine
 * the internal workflows that organisation users are subject while performing business processes
 * primarily associated to the management of bank guarantees.
 * 
 * @author Dain Liffman
 */
public interface ApprovalModelCatalog {

    /**
     * Retrieves the list of approval models that are active in the platform.
     * 
     * @return 	a {@link List} of {@link ApprovalModelInfo} instances containing metadata
     * 			about the approval models registered in the system.
     * 	
     * @throws IOException	if there is any error while loading the information about the
     * 						registered approval models.
     */
    List<ApprovalModelInfo> getApprovalModels() throws IOException;

    /**
     * Retrieves the information associated to a specific approval model identified by the
     * give <i>name</i>.
     * 
     * @param name 	a {@link Name} value that specifies the name of the approval model to
     * 				look up. It cannot be {@literal null}.
     * 
     * @return 	an instance of {@link ApprovalModelInfo} that contains the information 
     * 			about the queried approval model, or {@literal null} if the approval model
     * 			is not found.
     * 
     * @throws IOException	if there is any error while loading the approval model
     * 						information.
     */
    ApprovalModelInfo getApprovalModel(ApprovalModelInfo.Name name) throws IOException;

}
