package com.ibm.au.bgx.model.chain;

import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;

import java.util.List;

/**
 * Interface for interaction with the purpose format part of the profile chain.
 *
 * @author Peter Ilfrich
 */
public interface PurposeFormatChain {

    /**
     * Creates a new purpose format on the chain.
     *
     * @param format - the new purpose format definition to add
     * @return - the new added purpose format
     * @throws ProfileChainException in case of errors during creation or retrieval of the purpose
     *                               format to/from the chain.
     */
    PurposeFormat create(PurposeFormat format) throws ProfileChainException;

    /**
     * Retrieves a specific purpose format from the chain.
     *
     * @param id - the id of the purpose format to request
     * @return the requested purpose format or null
     * @throws ProfileChainException in case of issues during retrieval or communication with the
     *                               chain.
     */
    PurposeFormat getById(String id) throws ProfileChainException;

    /**
     * Retrieves a list of all purpose formats stored in the system.
     *
     * @return a list of all purpose formats
     * @throws ProfileChainException in case of any communication error during retrieval of the
     *                               purpose formats.
     */
    List<PurposeFormat> getAll() throws ProfileChainException;

    /**
     * Updates an existing purpose format's active status to either activate or deactivate it.
     *
     * @param id           - the id of the purpose format to update
     * @param activeStatus - the new status of this purpose format to update to
     * @throws ProfileChainException in case of communication issues during the update
     */
    void updateActiveStatus(String id, boolean activeStatus) throws ProfileChainException;
}
