package com.ibm.au.bgx.model.auth;

import com.ibm.au.bgx.model.api.exceptions.ApiException;
import java.time.Instant;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;


/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface BgxUserDetailService extends UserDetailsService {

	/**
	 * 
	 * @param orgId
	 * @param username
	 * @param jwt
	 * @param jwtIssuedAt
	 * @param jwtExpiry
	 * @return
	 * @throws ApiException
	 */
    UserDetails loadUserByUsername(String orgId, String username, String jwt, Instant jwtIssuedAt, Instant jwtExpiry) throws ApiException;

    /**
     * 
     * @param apiKey
     * @return
     */
    UserDetails loadUserByApiKey(String apiKey);
}
