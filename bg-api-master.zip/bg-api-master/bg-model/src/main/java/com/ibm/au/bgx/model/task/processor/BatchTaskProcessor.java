package com.ibm.au.bgx.model.task.processor;

import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;

/**
 * Interface <b>BatchTaskProcessor</b>. Specialises the {@link TaskProcessor}
 * interface for {@link BatchProcessTask} instances.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface BatchTaskProcessor extends TaskProcessor<BatchProcessTask> {

}
