package com.ibm.au.bgx.model.repository;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;

import java.util.List;

/**
 * <p>
 * Interface <b>TermsAndCondRepository</b>. Defines the contract for a repository
 * managing {@link TermsAndCond} instance. This interface specialises and extends
 * {@link DefaultRepository} and adds additional methods to implement the search
 * for terms and conditions by different attributes.
 * </p>
 * <p>
 * The repository for terms and conditions acts as an off-chain cache for the terms
 * and conditions that are stored in the ledger, which is looked up to speed up the 
 * searches and the retrieval of terms and conditions. As a result of it is responsibility 
 * of the entity that manages such interface to keep it synchronised with the content 
 * that is stored in the ledger.
 * </p>
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface TermsAndCondRepository extends DefaultRepository<TermsAndCond> {

	/**
	 * Retrieves all the terms and conditions entries that match the given <i>title</i>.
	 * The title is a short description of the terms and conditions, often used as a 
	 * headline to introduce the terms and conditions in a browser page. It is not
	 * considered to be unique, hence this method may return multiple instances of
	 * {@link TermsAndCond}.
	 * 
	 * @param title		a {@link String} containing the title for the terms and
	 * 					conditions to retrieve. It cannot be {@literal null}.
	 * 
	 * @return	a {@link List} containing the {@link TermsAndCond} instances that have
	 * 			a matching title with <i>title</i>. It is guaranteed to not to be
	 * 			{@literal null}, and for each term and conditions entity returned
	 * 			the value of {@link TermsAndCond#getTitle()} is equal to the given
	 * 			<i>title</i>.
	 * 
	 * @throws IllegalArgumentException	if <i>title</i> is {@literal null}.
	 */
    List<TermsAndCond> getByTitle(String title);

    /**
     * Retrieves all the terms and conditions entries that have the specified <i>scope</i>.
     * The scope of a terms and conditions document identifies the set of entities for
     * which the terms and condition may be relevant. Currently the platform support three
     * type of scopes for terms and conditions: {@link Scope#PLATFORM}, {@link Scope#USER},
     * and {@link Scope#BANK_GUARANTEE}.
     * 
     * @param scope		a {@link String} representing one of the three scopes identified
     * 					above. It is expected to not to be {@literal null}.
	 * 
	 * @return	a {@link List} containing the {@link TermsAndCond} instances that have
	 * 			a matching scope with <i>scope</i>. It is guaranteed to be not {@literal 
	 * 			null}, and for each term and conditions entity returned the value of 
	 * 			{@link TermsAndCond#getScope()} is equal to the given <i>scope</i>.
     * 
     * @throws IllegalArgumentException	if <i>scope</i> is {@literal null}.
     */
    List<TermsAndCond> getByScope(String scope);
}
