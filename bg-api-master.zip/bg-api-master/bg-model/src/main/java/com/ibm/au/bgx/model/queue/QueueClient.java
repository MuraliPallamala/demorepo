package com.ibm.au.bgx.model.queue;

import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.chain.BlockchainEvent;
import com.ibm.au.bgx.model.pojo.notification.EmailNotification;
import com.ibm.au.bgx.model.pojo.notification.NetworkSyncNotification;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;

import java.io.IOException;
import java.util.List;

/**
 * @author Peter Ilfrich
 */
public interface QueueClient {

	/**
	 * 
	 */
    String CHANNEL_WEB = "web";
    /**
     * 
     */
    String CHANNEL_EMAIL = "email";
    /**
     * 
     */
    String CHANNEL_REPORT = "report";
    /**
     * 
     */
    String CHANNEL_IMPEX = "impex";
    /**
     * 
     */
    String CHANNEL_BATCH = "batch";
    /**
     * 
     */
    String CHANNEL_EVENT = "event";
    /**
     * 
     */
    String CHANNEL_NETWORK = "network";

    /**
     * 
     * @param message
     * @throws IOException
     */
    void addEmailNotification(EmailNotification message) throws IOException;

    /**
     * 
     * @param message
     * @param orgId
     * @throws IOException
     */
    void addEmailNotification(EmailNotification message, String orgId) throws IOException;

    /**
     * This sends a single web notification to a single user as specified in the message. The
     * message needs to provide a receiverId, otherwise, the request will be rejected.
     *
     * @param message - the web notification containing a receiverId
     * 
     * @throws IOException 
     */
    void addWebNotification(WebNotification message) throws IOException;

    /**
     * This sends multiple web notifications to all users of a given organisation. The receiverId of
     * the message will be overwritten, so doesn't need to be set before sending.
     *
     * @param message - the web notification without a receiverId
     * @param orgId   - the organisation for which to retrieve all users and send the notification
     * @throws IOException 
     */
    void addWebNotification(WebNotification message, String orgId) throws IOException;

    /**
     * This sends potentially multiple web notifications to users with the given role inside the
     * given organisation.
     *
     * @param message - the web notification without a receiverId
     * @param orgId   - the id of the organisation for which to find users matching the role
     * @param role    - the role to filter by (see BgxConstants.ROLE_<...>)
     * @throws IOException 
     */
    void addWebNotification(WebNotification message, String orgId, String role) throws IOException;

    /**
     * 
     * @param message
     * @param receivers
     * @throws IOException
     */
    void addWebNotification(WebNotification message, List<UserProfile> receivers) throws IOException;

    /**
     * 
     * @param batchTask
     * @throws IOException
     */
    void addBatchProcessTask(BatchProcessTask batchTask) throws IOException;

    /**
     * 
     * @param event
     * @throws IOException
     */
    void addBlockchainEvent(BlockchainEvent event) throws IOException;

    /**
     * This sends network configuration to different parties for syncing
     * @param notification 
     * @throws IOException 
     */
    void addNetworkSyncNotification(NetworkSyncNotification notification) throws IOException;

    /**
     * 
     * @throws IOException
     */
    void registerWebNotificationHandler() throws IOException;

    /**
     * 
     * @throws IOException
     */
    void registerEmailNotificationHandler() throws IOException;

    /**
     * 
     * @throws IOException
     */
    void registerBatchProcessTaskHandler() throws IOException;

    /**
     * 
     * @throws IOException
     */
    void registerBlockchainEventHandler() throws IOException;

    /**
     * 
     * @throws IOException
     */
    void registerReportHandler() throws IOException;

    /**
     * 
     * @throws IOException
     */
    void registerImpexHandler() throws IOException;

    /**
     * 
     * @throws IOException
     */
    void registerNetworkSyncHandler() throws IOException;

    /**
     * Sends a message to the support email address. For issuer and newco admin, this is the ADMIN
     * user of the organisation represented by the APIs identity. For Newco, it will use a
     * system-configured email address.
     *
     * @param message - the email message body to send
     */
    void sendSupportEmail(String message);
}
