package com.ibm.au.bgx.model.task.processor;

/**
 * Interface <b>UserTaskProcessor</b>. This interfaces specialises {@link 
 * BatchTaskProcessor} to defines those types of batch task processors that
 * are designed to process tasks specific to organisation users (e.g. role
 * update, or similar).
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface UserTaskProcessor extends BatchTaskProcessor {

}
