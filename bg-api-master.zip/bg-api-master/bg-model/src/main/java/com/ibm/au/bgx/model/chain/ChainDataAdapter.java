package com.ibm.au.bgx.model.chain;

/**
 * Interface <b>ChainDataAdapter</b>. This interface provides the generic contract to
 * convert among different represenations of the same entity. In particular it is used
 * to transform between "on-chain" and "off-chain" representations of a given entity.
 *
 * @param <X>	The type that represents the "on-chain" representation of the entity.
 * @param <Y>	The type that represents the "off-chain" representation of the entity.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public interface ChainDataAdapter<X, Y> {

    /**
     * Converts between the "off-chain" representation of an entity to the corresponding
     * "on-chain" representation.
     * 
     * @param y 	the "off-chain" representation of the entity. It is expected
     * 				to not to be {@literal null}.
     * 
     * @return 	the "on-chain" representation of the entity.
     */
    X toOnChainModel(Y y);

    /**
     * Converts between the "on-chain" representation of an entity to the corresponding
     * "off-chain" representation.
     * 
     * @param x 	the "on-chain" representation of the entity. It is expected
     * 				to not to be {@literal null}.
     * 
     * @return 	the "off-chain" representation of the entity.
     */
    Y toOffchainModel(X x);
}
