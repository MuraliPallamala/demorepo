package com.ibm.au.bgx.model.api.exceptions;

import com.ibm.au.bgx.model.pojo.api.response.ExceptionResponse;
import java.math.BigInteger;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public class ApiException extends Exception {

	/**
	 * A {@link Long} value used to discriminate among different instances that
	 * have the same class name (but may not be the same) during serialization.
	 */
	private static final long serialVersionUID = 9126093200061208022L;

	/**
	 * 
	 */
    private ExceptionResponse response;

    /**
     * 
     * @param message
     */
    public ApiException(String message) {
        this(null, message, null, null);
    }

    /**
     * 
     * @param path
     * @param message
     * @param t
     */
    public ApiException(String path, String message, Throwable t) {
        this(path, message, null, null, null, t);
    }

    /**
     * 
     * @param path
     * @param message
     */
    public ApiException(String path, String message) {
        this(path, message, null, null, null);
    }

    /**
     * 
     * @param path
     * @param message
     * @param description
     * @param t
     */
    public ApiException(String path, String message, String description, Throwable t) {
        this(path, message, description, null, null, t);
    }

    /**
     * 
     * @param path
     * @param message
     * @param description
     */
    public ApiException(String path, String message, String description) {
        this(path, message, description, null, null);
    }

    /**
     * 
     * @param path
     * @param message
     * @param description
     * @param code
     * @param context
     * @param innerException
     */
    public ApiException(String path, String message, String description, BigInteger code, Map<String, Object> context, Throwable innerException) {

        super(message, innerException);

        this.response = new ExceptionResponse();
        this.response.setPath(path);
        this.response.setMessage(message);
        this.response.setDescription(description);
        this.response.setCode(code);
        this.response.setContext(context);
        this.response.setTimestamp(Instant.now().toString());

        // We generate UUID for each exception as reference
        // This will enable us to find the exception in the log quickly rather than searching based on timestamp
        this.response.setReference(UUID.randomUUID().toString());
    }

    /**
     * 
     * @param path
     * @param message
     * @param description
     * @param code
     * @param context
     */
    public ApiException(String path, String message, String description, BigInteger code, Map<String, Object> context) {
        this(path, message, description, code, context, null);
    }

    /**
     * 
     * @return
     */
    public ExceptionResponse getResponse() {
        return response;
    }
}
