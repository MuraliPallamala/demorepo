package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.api.PaginatedResponse;
import com.ibm.au.bgx.model.pojo.gx.GxActiveRequestsBitmaskWrapper;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;

import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.io.IOException;
import java.util.List;

/**
 * 
 * @author fl0yd
 *
 */
public interface GxRequestRepository extends DefaultRepository<GxRequest> {

	/**
	 * 
	 * @param orgId
	 * @param channelUsername
	 * @param guaranteeId
	 * @param status
	 * @param type
	 * @param start
	 * @param limit
	 * @return
	 */
    PaginatedResponse<GxRequest> find(String orgId, String channelUsername, String guaranteeId, String status, String type, String start, Integer limit);

    /**
     * 
     * @param orgId
     * @param channelUsername
     * @param searchRequest
     * @return
     */
    PaginatedResponse<GxRequest> find(String orgId, String channelUsername, GxFlowsSearchRequest searchRequest);

    /**
     * 
     * @param principal
     * @param guaranteeId
     * @param status
     * @param type
     * @param start
     * @param limit
     * @return
     */
    PaginatedResponse<GxRequest> find(BgxPrincipal principal, String guaranteeId, String status, String type, String start, Integer limit);

    /**
     * 
     * @param principal
     * @param searchRequest
     * @return
     */
    PaginatedResponse<GxRequest> find(BgxPrincipal principal, GxFlowsSearchRequest searchRequest);

    /**
     * 
     * @param orgId
     * @param guaranteeIds
     * @return
     * @throws IOException
     */
    List<GxActiveRequestsBitmaskWrapper> findActiveRequestsMask(String orgId, List<String> guaranteeIds) throws IOException;

    /**
     * 
     * @param orgId
     * @param guaranteeId
     * @return
     */
    GxActiveRequestsBitmaskWrapper findActiveRequestsMask(String orgId, String guaranteeId);

    /**
     * 
     * @param gxRequest
     * @param visibleChannelUserNames
     * @param retries
     * @return
     */
    GxRequest forceUpdateFields(GxRequest gxRequest, List<String> visibleChannelUserNames, int retries);
}
