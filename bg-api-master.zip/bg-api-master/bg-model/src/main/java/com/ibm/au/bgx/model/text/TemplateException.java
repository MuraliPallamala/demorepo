/**
 * 
 */
package com.ibm.au.bgx.model.text;

/**
 * Class <b>TemplateException</b>. This class provides a typed exception
 * to represent errors occurred while rendering a template.
 * 
 *  @see TemplateEngine
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class TemplateException extends Exception {

	/**
	 * A {@literal long} value that is used to discriminate the specific
	 * class implementation version during deserialisation.
	 */
	private static final long serialVersionUID = 8050028535174057466L;



	/**
	 * Initialises an instance of the {@link TemplateException} class, with
	 * the given message. 
	 * 
	 * @param message 	a {@link String} representing the message associated to
	 * 					the error. It cannot be {@literal null} or an empty string.
	 * 
	 * @throws IllegalArgumentException	if <i>message</i> is {@literal null} or
	 * 									an empty string.
	 */
	public TemplateException(String message) {
		super(message);
		if (message == null || message.isEmpty()) {
			throw new IllegalArgumentException("Parameter 'message' cannot be null.");
		}
	}


	/**
	 * Initialises an instance of the {@link TemplateException} class, with the
	 * given message and inner error.
	 * 
	 * 
	 * @param message 	a {@link String} representing the message associated to
	 * 					the error. It cannot be {@literal null} or an empty string.
	 * @param cause		a {@link Throwable} implementation that represents the
	 * 					original cause of the exception. It cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException	if <i>message</i> is {@literal null} or
	 * 									an empty string, or <i>cause</i>is {@literal 
	 * null}.
	 */
	public TemplateException(String message, Throwable cause) {
		super(message, cause);
		
		if (message == null || message.isEmpty()) {
			throw new IllegalArgumentException("Parameter 'message' cannot be null.");
		}
		
		if (cause == null) {
			
			throw new IllegalArgumentException("Parameter 'cause' cannot be null.");
		}
	}

}
