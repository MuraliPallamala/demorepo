package com.ibm.au.bgx.model.identityprovider;

import java.util.List;
import java.util.Map;
import com.ibm.au.bgx.model.exception.IdentityProviderException;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;

/**
 * @author Bruno Marques <brunomar@au1.ibm.com>
 *
 */
public interface ManagedIdentityProviderClient extends OtpClient {

    /**
     * Creates a realm.
     * 
     * @param realmName realm name
     * @param displayName string in representing the name of the realm that will be displayed during
     *        user authentication in HTML format.
     * @throws IdentityProviderException
     */
    public Map<String, Object> createRealm(String realmName, String displayNameHtml)
                    throws IdentityProviderException;

    /**
     * Creates a user client under a realm. This client enables support of 'Resource Owner Password
     * Credentials Grant'.
     * 
     * @param realmName
     * @param clientId
     * @param redirectUrls
     * @return
     * @throws IdentityProviderException
     */
    public OpenIdConfig createUserClient(String realmName, String clientId, List<String> redirectUrls)
                    throws IdentityProviderException;

    /**
     * Creates a api client under a realm. This client enables support of 'Client Credentials
     * Grant'.
     * 
     * @param realmName
     * @param clientId
     * @return
     * @throws IdentityProviderException
     */
    public OpenIdConfig createApiClient(String realmName, String clientId)
                    throws IdentityProviderException;

    /**
     * Retrieves the configuration of a client under a realm.
     * 
     * @param realmName
     * @param clientId
     * @return
     * @throws IdentityProviderException
     */
    public OpenIdConfig getClient(String realmName, String clientId)
                    throws IdentityProviderException;

    /**
     * Retrieves the realm information.
     * 
     * @return
     * @throws IdentityProviderException
     */
    public Map<String, Object> getRealm(String realmName) throws IdentityProviderException;

    /**
     * Creates a user in a realm.
     * 
     * @param realmName
     * @param email
     * @param firstName
     * @param lastName
     * @return a map which includes a String field called userId.
     * @throws IdentityProviderException
     */
    public Map<String, Object> createUser(String realmName, String email, String firstName,
                    String lastName) throws IdentityProviderException;

    /**
     * Update user details in a realm.
     *
     * It only allows updating firstName and lastName
     *
     * @param realmName
     * @param email
     * @param firstName
     * @param lastName
     * @return a map which includes a String field called userId.
     * @throws IdentityProviderException
     */
    public Map<String, Object> updateUser(String realmName, String email, String firstName,
        String lastName) throws IdentityProviderException;

    /**
     * Retrieves a user.
     * 
     * @param realmName
     * @param email
     * @return
     * @throws IdentityProviderException
     */
    public boolean userExists(String realmName, String email) throws IdentityProviderException;

    /**
     * Sets the user password.
     * 
     * @param realmName
     * @param email
     * @param password
     * @throws IdentityProviderException
     */
    public void setPassword(String realmName, String email, String password)
                    throws IdentityProviderException;

    /**
     * Removes a realm.
     * 
     * @param realmName
     * @throws IdentityProviderException
     */
    public void removeRealm(String realmName) throws IdentityProviderException;

    /**
     * Removes a client.
     * 
     * @param realmName
     * @param clientId
     * @throws IdentityProviderException
     */
    public void removeClient(String realmName, String clientId) throws IdentityProviderException;

    /**
     * Removes a user.
     *
     * @param realmName
     * @param email
     * @throws IdentityProviderException
     */
    public void removeUser(String realmName, String email) throws IdentityProviderException;
}
