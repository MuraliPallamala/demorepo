package com.ibm.au.bgx.model.repository;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.pojo.UserProfile;
import java.util.List;

/**
 * Interface <b>UserProfileRepository</b>. This interface specialises the {@link DefaultRepository}
 * interface for storing the profiles of the users of the platform. Even though the solution
 * is designed to delegate the authentication process to an external Federated Identity Provider
 * the solution still requires to store information about the users for those matters that are
 * related to the platform specifically (i.e. user roles primarily). Hence the need of a 
 * repository and this interface. 
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */

public interface UserProfileRepository  extends DefaultRepository<UserProfile>{

	/**
	 * Retrieves the user profile by email and primary organisation identifier.
	 * If the result is not null the following conditions are satisfied:
	 * <ul>
	 * <li>{@link UserProfile#getPrimaryOrgId()} is equal to <i>primaryOrgId</i></li>
	 * <li>{@link UserProfile#getEmail()} is equal to <i>email</i></li>
	 * </ul>
	 * 
	 * @param primaryOrgId		a {@link String} representing the unique identifier of
	 * 							the organisation the user belongs to.It cannot be an
	 * 							empty string or {@literal null}.
	 * @param email				a {@link String} representing the email of the user.
	 * 							It cannot be {@literal null} or an empty string.
	 * 
	 * @return	a {@link UserProfile} instance that matches the search criteria, or
	 * 			{@literal null} if there is no match.
	 * 
	 * @throws 	IllegalArgumentxception if <i>primaryOrgId</i> or <i>email</i> are
	 * 									{@literal null} or an empty string.
	 */
    UserProfile getByEmail(String primaryOrgId, String email);

    /**
     * Retrieves the user profiles that belong to a specific organisation identified
     * by the given identifier. For any {@link UserProfile} instance returned in the
     * result set the following condition will be satisfied: {@link UserProfile#getPrimaryOrgId()}
     * is equal to <i>id</i>.
     * 
     * @param id	a {@link String} representing the unique identifier of the organisation 
     * 				the user belong to. It cannot be an empty string or {@literal null}.
     * 
     * @return	a {@link List} containing {@link UserProfile} instances mapping the
     * 			users belong to the organisation identified by <i>id</i>.
	 * 
	 * @throws 	IllegalArgumentxception if <i>id</i> is {@literal null} or an empty string.
     */
    List<UserProfile> getByPrimaryOrgId(String id);
    
    /**
     * Retrieves the user profiles that belong to a given organisation and a have specific
     * role. For any {@link UserProfile} instance returned in the result set the following 
     * conditions will be satisfied: {@link UserProfile#getPrimaryOrgId()} is equal to <i>
     * orgId</i> and the roles associated to the profile in that organisation contain the
     * <i>role</i>.
     * 
     * @param orgId	a {@link String} representing the unique identifier of the organisation 
     * 				the user belong to. It cannot be an empty string or {@literal null}.
     * @param role	a {@link String} represnting the unique name of the role within the
     * 				organisation. It cannot be {@literal null} or an empty string.
	 * 
	 * @return	a {@link UserProfile} instance that matches the search criteria, or
	 * 			{@literal null} if there is no match.
	 * 
	 * @throws 	IllegalArgumentException if <i>orgId</i> or <i>email</i> are {@literal null} 
	 * 									or an empty string.
     */
    List<UserProfile> getByOrgRole(String orgId, String role);

	/**
	 * Retrieves a list of users that belong to a specific primary org, but also have a specific
	 * role in another org (roleOrgId).
	 * @param primaryOrgId - the primary organisation the users belong to
	 * @param roleOrgId - the org id that has an entry in the users roles map
	 * @param role - the role to match against
	 * @return - a list of matching user profiles.
	 */
    List<UserProfile> getByOrgRolePrimary(String primaryOrgId, String roleOrgId, String role);

    /**
     * Retrieves a user by its login key. A login key is used by a prospective platform
     * user to access his/her profile during onboarding. Once onboarding is completed
     * the normal login process will be used.
     * 
     * @param key	a {@link String} representing the unique login key. It cannot be 
     * 				{@literal null} or an empty string.
     * 
     * @return	a {@link UserProfile} instance whose login key matches <i>key</i> or
     * 			{@literal null} if there is no matching user to the given key.
     */
    UserProfile getByKey(String key);

	/**
	 * Retrieves a user by one of its API key
	 *
	 * @param apiKey	a {@link String} representing the unique API key. It cannot be
	 * 				{@literal null} or an empty string.
	 *
	 * @return	a {@link UserProfile} instance whose login key matches <i>key</i> or
	 * 			{@literal null} if there is no matching user to the given key.
	 */
	UserProfile getByApiKey(String apiKey);

	/**
	 * Retrieves users of a specific org in a given status.
	 * @param orgId - the id of the primary org id of a user
	 * @param status - the status the user is in (active, pending, inactive, deleted)
	 * @return - the list of
	 */
	List<UserProfile> getByPrimaryOrgIdAndStatus(String orgId, String status);
}
