package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.notification.EmailNotification;

/**
 * @author Peter Ilfrich
 */
public interface EmailNotificationRepository extends DefaultRepository<EmailNotification> {

}
