
package com.ibm.au.bgx.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.InputStream;
import java.io.Serializable;

/**
 * <p>
 * Class <b>Attachment</b>. This class models an attachment (in the form of a binary
 * content) that can be appended to an {@link Entity}. An attachment is defined by
 * its <i>name</i>, its <i>size</i>, and its <i>content type</i>.
 * </p>
 * <p>
 * Attachment may be used to add additional information to entitities that are not
 * directly processed or used by the platform but that are more for user consumption.
 * </p>
 * 
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
// [CV] TODO: Remove, this is not currently used and it is an heritage of the couchdb model
//            We are not managing attachments at the moment in the platform, and this feature
//            should only be implemented in the CouchDb package.
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "name",
    "contentLength",
    "contentType",
    "stream"
})
public class Attachment implements Serializable {
	
	/**
	 * A {@literal long} value representing the unique serial number that
	 * refers to this implementation of the {@link Attachment} class. This
	 * number is looked up when deserialising instances of this class from
	 * another JVM to ensure that the class definition coincides.
	 */
    private static final long serialVersionUID = -4834198232831588552L;

	/**
	 * A {@link String} representing the name of the attachment.
	 */
    @JsonProperty("name")
    private String name;
    /**
     * A {@literal long} value representing the content size in
     * bytes of the attachment.
     */
    @JsonProperty("contentLength")
    private long contentLength;
    /**
     * A {@link String} defining the type of the content. This
     * attribute should be set in accordance with the specification
     * of media types (see {@link <a href="https://www.iana.org/assignments/media-types/media-types.xhtml">IETF Media Types</a>}).
     */
    @JsonProperty("contentType")
    private String contentType;
    /**
     * A {@link InputStream} implementation that provides access to the
     * stream of bytes represeting the content of the attachment.
     */
    @JsonProperty("stream")
    private transient InputStream stream;

    /**
     * Gets the name of the attachment.
     * 
     * @return	a {@link String} representing the name of the attachment.
     */
    @JsonProperty("name")
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name of the attachment.
     * 
     * @param name	a {@link String} representing the name of the attachment.
     */
    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the size of the attachment in bytes.
     * 
     * @return	a {@literal long} value indicating the size in bytes of the
     * 			attachment.
     */
    @JsonProperty("contentLength")
    public long getContentLength() {
        return this.contentLength;
    }

    /**
     * Sets the size of the attachment in bytes.
     * 
     * @param contentLength	a {@literal long} value representing the size of
     * 						the attachment in bytes.
     */
    @JsonProperty("contentLength")
    public void setContentLength(long contentLength) {
        this.contentLength = contentLength;
    }

    /**
     * <p>
     * Gets the content type for the attachment. The content type is expected
     * to reference one of the media types defined by the IETF. Custom content
     * types can be also defined but they are discouraged.
     * </p>
     * <p>
     * Reference: {@link <a href="https://www.iana.org/assignments/media-types/media-types.xhtml">IETF Media Types</a>}
     * </p>
     * 
     * @return	a {@link String} representing the content type of the attachment.
     */
    @JsonProperty("contentType")
    public String getContentType() {
        return this.contentType;
    }

    /**
     * Sets the content type for the attachment. The content type is expected
     * to reference one of the media types defined by the IETF. Custom content
     * types can be also defined but they are discouraged.
     * 
     * Reference: {@link <a href="https://www.iana.org/assignments/media-types/media-types.xhtml">IETF Media Types</a>}
     * 
     * @param contentType	a {@link String} representing the content type of 
     * 						the attachment.
     */
    @JsonProperty("contentType")
    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    /**
     * Gets access to the stream that can be used to read the content of
     * the attachment.
     * 
     * @return	a {@link InputStream} implementation that provides access
     * 			to the stream of bytes that represent the attachment content.
     */
    @JsonProperty("stream")
    public InputStream getStream() {
        return this.stream;
    }

    /**
     * Sets the stream that can be used to read the content of the attachment.
     * 
     * @param stream	a {@link InputStream} implementation that can be used 
     * 					to access the stream of bytes representing the content
     * 					of the attachment.
     */
    @JsonProperty("stream")
    public void setStream(InputStream stream) {
        this.stream = stream;
    }

    /**
     * Returns the string representation of the attachment. This method
     * uses {@link ToStringBuilder#reflectionToString(Object)} to
     * generate the {@link String} representing the current instance.
     * 
     * @return 	a {@link String} representing the instance as constructed
     * 			by {@link ToStringBuilder#reflectionToString(Object)} when
     * 			applied to this object. It cannot be {@literal null}.
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    /**
     * Generates the hash code of the instance. This method uses the
     * capabilities of {@link HashCodeBuilder} to produce the hash by
     * adding all the attributes of the type to the builder in the
     * following order:
     * <ul>
     * <li><i>name</i></li>
     * <li><i>contentLength</i></li>
     * <li><i>contentType</i></li>
     * <li><i>stream</i></li>
     * </ul>
     * 
     * @return  a {@literal int} value representing the value returned
     * 			by {@link HashCodeBuilder#toHashCode()}.
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(this.name)
        							.append(this.contentLength)
        							.append(this.contentType)
        							.append(this.stream)
        							.toHashCode();
    }

    /**
     * Determines whether <i>other</i> equals to the current instance.
     * The following criteria needs to be met by <i>other</i> to satisfy
     * the equality test:
     * <ul>
     * <li><i>other</i> is not {@literal null}</li>
     * <li><i>other</i> is of type {@link Attachment}</li>
     * <li><i>other</i> has the same values for all the attributes of 
     * the class of the current instance</li>
     * </ul>
     * 
     * @param other	a {@link Object} reference that is the candidate of
     * 				the equality test.
     * 
     * @return 	{@literal true} if <i>other</i> is equal to the current
     * 			instance, {@literal false} otherwise.
     */
    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof Attachment)) {
            return false;
        }
        Attachment rhs = ((Attachment) other);
        return new EqualsBuilder().append(this.name, rhs.name)
        						  .append(this.contentLength, rhs.contentLength)
        						  .append(this.contentType, rhs.contentType)
        						  .append(this.stream, rhs.stream)
        						  .isEquals();
    }

}
