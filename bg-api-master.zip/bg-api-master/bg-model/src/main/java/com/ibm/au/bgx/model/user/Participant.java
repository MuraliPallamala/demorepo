package com.ibm.au.bgx.model.user;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.HashMap;
import java.util.Map;

/**
 * Enumeration <i>Participant</i>. Defines the different participant
 * roles that exist in a bank guarantee transaction.
 * 
 * @author Peter Ilfrich
 */
public enum Participant {

	/**
	 * Represents the issuer of the bank guarantee, the entity that is
	 * expected to pay out the guarantee in case of a demand and the one
	 * that provides assurance on the amount defined in the instrument.
	 */
	ISSUER("ISSUER"), 
	/**
	 * Represents the entity that is entitled to demand the bank guarantee.
	 * The beneficiary is the entity that can exercise a demand for the 
	 * total or partial amount of the guarantee, in case of applicant's
	 * default.
	 */
	BENEFICIARY("BENEFICIARY"), 
	/**
	 * Represents the entity the bank guarantee provides assurance for. The
	 * applicant is the entity that may default to adhere the contract rules
	 * that are backed with the provision of a bank guarantee, thus triggering
	 * the beneficiary partial or full demand.
	 */
	APPLICANT("APPLICANT"), 
	/**
	 * Represents the prospective beneficiary within a bank guarantee transfer
	 * transaction. This is the entity that will eventually be entitled to
	 * make a demand on the bank guarantee if the beneficiary transfer is 
	 * successful.
	 */
	NEW_BENEFICIARY("NEW_BENEFICIARY");

	/**
	 * A {@link Map} implementation that is used to store all the values of the
	 * enumeration mapped by their string representation.
	 */
	private static final Map<String, Participant> CONSTANTS = new HashMap<>();

	/**
	 * Initialises the {@link Map} implementation with all the values of the
	 * enumeration.
	 */
	static {
		for (Participant o : values()) {
			CONSTANTS.put(o.value, o);
		}
	}

	/**
	 * String representation of the enumeration value.
	 */
	private final String value;

	/**
	 * Initialises an instance of the {@link Participant} enumeration with
	 * the given value. This constructor is private as it is not meant to
	 * be used if not internally.
	 * 
	 * @param value	a {@link String} containing the string representation that
	 * 				is associated to the specific enumeration value being
	 * 				initialised.
	 */
	Participant(String value) {
		this.value = value;
	}

	/**
	 * Parses an instance of {@link Participant} from its string representation.
	 * 
	 * @param value	a {@link String} representing the value to parse. This is 
	 * 				must to be one of the names of the enumeration values and
	 * 				cannot be {@literal null}.
	 * 				
	 * @return	a {@link Participant} value, which is parsed from <i>value</i>.
	 * 			It is guaranteed to not to be {@literal null}.
	 * 
	 * @throws IllegalArgumentException	if <i>value</i> is {@literal null} or
	 * 									does not map any of the enumeration
	 * 									values.
	 */
	@JsonCreator
	public static Participant fromValue(String value) {
		Participant constant = CONSTANTS.get(value.toUpperCase());
		if (constant == null) {
			throw new IllegalArgumentException(value);
		} else {
			return constant;
		}
	}

	/**
	 * Gets the {@link String} representation of the enumeration value.
	 * 
	 * @return 	a {@link String} containing the name of the enumeration
	 * 			constant.
	 * 
	 * @see Participant#value()
	 */
	@Override
	public String toString() {
		return this.value;
	}


	/**
	 * Gets the {@link String} representation of the enumeration value.
	 * 
	 * @return 	a {@link String} containing the name of the enumeration
	 * 			constant.
	 * 
	 * @see Participant#value()
	 */
	@JsonValue
	public String value() {
		return this.value;
	}

}
