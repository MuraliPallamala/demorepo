/**
 * 
 */
package com.ibm.au.bgx.model.text;


import java.io.IOException;
import java.io.InputStream;

/**
 * Class <b>ResourceTemplateReference</b>. Extends {@link UrlTemplateReference} and
 * specialises its behaviour to support references to templates that stored in
 * the resource folders embedded with the JARs.
 * 
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class ResourceTemplateReference extends UrlTemplateReference {

	
	/**
	 * This constant stores the value of the file protocol scheme.
	 * This is needed to have an appropriate representation of the
	 * URL that points to a resource.
	 */
	public static final String RESOURCE_PROTOCOL_PREFIX = "resource://";
	
	/**
	 * A {@link ClassLoader} instance that is used to load the resource
	 * specified with the path.
	 */
	protected ClassLoader loader;
	

	/**
	 * Initialises an instance of {@link ResourceTemplateReference} with the
	 * given <i>path</i> and specified class loader.
	 * 
	 * @param path	a {@link String} containing the resource path to the file that
	 * 				stores the template's content. It can either be in the
	 * 				fully qualified form: 'resource://<absolute-path-to-file>'
	 * 				or without the protocol scheme. It cannot be {@literal 
	 * 				null}.
	 * 
	 * @param loader	a {@link ClassLoader} instance that is used to load the
	 * 					resource specified by <i>path</i>. It cannot be {@literal 
	 * 					null}.
	 * 
	 * @throws IllegalArgumentException if <i>path</i> or <i>loader</i> is {@literal 
	 * 									null}.
	 */
	public ResourceTemplateReference(String path, ClassLoader loader) {
		super(path != null ? (path.startsWith(ResourceTemplateReference.RESOURCE_PROTOCOL_PREFIX) ? path : ResourceTemplateReference.RESOURCE_PROTOCOL_PREFIX + path) : path);
		
		if (loader == null) {
			throw new IllegalArgumentException("Parameter 'loader' cannot be null.");
		}
		
		this.loader = loader;
	}
	
	/**
	 * Initialises an instance of {@link ResourceTemplateReference} with the
	 * given <i>path</i>. This method calls {@link #ResourceTemplateReference(String,ClassLoader)}
	 * with the default class loader.
	 * 
	 * @param path	a {@link String} containing the resource path to the file that
	 * 				stores the template's content. It can either be in the
	 * 				fully qualified form: 'resource://<absolute-path-to-file>'
	 * 				or without the protocol scheme. It cannot be {@literal 
	 * 				null}.
	 * 
	 * @throws IllegalArgumentException	if <i>path</i> is {@literal null}.
	 */
	public ResourceTemplateReference(String path) {
		this(path, ClassLoader.getSystemClassLoader());
	}
	
	/**
	 * Gets the path to the template's file.
	 * 
	 * @return	a {@link String} containing the path to the resource that
	 *          stores the tamplate content. This value is equivalent to
	 *          {@link #getUrl()} without the specification of the protocol
	 *          scheme {@link #RESOURCE_PROTOCOL_PREFIX}.
 	 */
	public String getPath() {
		
		return this.getUrl().substring(ResourceTemplateReference.RESOURCE_PROTOCOL_PREFIX.length());
	}
	
	/**
	 * Gets the {@link ClassLoader} instance that is used to load the resource
	 * referenced by this instance.
	 * 
	 * @return	a {@link ClassLoader} instance, by default the instance is
	 * 			initialised with {@link ClassLoader#getSystemClassLoader()}.
	 */
	public ClassLoader getClassLoader() {
		
		return this.loader;
	}
	
	/**
	 * Returns the stream that can be used to read the template's content.
	 * 
	 * @return 	a {@link InputStream} implementation that provides access
	 * 			to the template's content.
	 */
	@Override
	public InputStream getStream() throws IOException {

		return this.loader.getResourceAsStream(this.getPath());
		
	}
}
