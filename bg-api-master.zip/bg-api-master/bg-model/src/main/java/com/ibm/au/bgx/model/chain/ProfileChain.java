package com.ibm.au.bgx.model.chain;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.profile.Organizations;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationPublicKey;
import java.security.PublicKey;
import java.util.List;
import java.util.Map;

/**
 * Interface for profile chain
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com> 
 */

public interface ProfileChain {

    OrgProfile create(OrgProfile profile, String adminCert) throws ProfileCreateException;

    OrgProfile create(OrgProfile profile, String adminCert, boolean forceReconnect) throws ProfileCreateException;

    List<OrgProfile> getAll() throws ProfileChainException;

    OrgProfile getById(String id) throws ProfileNotFoundException;

    List<OrgProfile> getByBusinessId(String bid) throws ProfileNotFoundException, ProfileChainException;

    List<OrgProfile> getByEntityName(String name)
        throws ProfileNotFoundException, ProfileChainException;

    Map<String, OrganizationPublicKey> getPublicKeys(String id) throws ProfileNotFoundException;

    Map<String, OrganizationPublicKey> activateKey(String orgId, PublicKey publicKey) throws ProfileNotFoundException, ProfileChainException;

    Map<String, OrganizationPublicKey> deactivateKey(String orgId, PublicKey publicKey) throws ProfileNotFoundException, ProfileChainException;

    String update(String orgId, Organizations.OrganizationStartRequest request) throws ProfileChainException;

    OrgProfile deactivate(String orgId) throws ProfileNotFoundException, ProfileChainException;
}
