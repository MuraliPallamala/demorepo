package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.crypto.CryptoKeyInfo;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public interface EncryptionKeyRepository extends DefaultRepository<CryptoKeyInfo> {

	/**
	 * 
	 * @param ownerId
	 * @return
	 */
    CryptoKeyInfo getByOwnerId(String ownerId);
}
