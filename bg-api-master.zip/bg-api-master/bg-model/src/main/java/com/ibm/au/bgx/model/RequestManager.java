package com.ibm.au.bgx.model;

import com.ibm.au.bgx.model.pojo.Request;

import java.util.List;

/**
 * 
 * @author fl0yd
 *
 */
// [CV] TODO: Move this interface close to the GxManager?
public interface RequestManager {

	/**
	 * 
	 * @param gxId
	 * @param status
	 * @return
	 */
    List<Request> find(String gxId, String status);

    /**
     * 
     * @param id
     * @return
     */
    Request get(String id);
}
