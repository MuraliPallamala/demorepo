package com.ibm.au.bgx.model.migration;

/**
 * Interface <b>DataMigrator</b>. It is used for any data migration tool that will be developed. 
 * It provides a standardised API to support pre-flight checks, running the actual migration and 
 * cleaning up after the migration.
 *
 * @author Dain Liffman, Peter Ilfrich
 */
public interface DataMigrator {

    /**
     * Checks whether data migration is required.
     *
     * @return true if requires migration, false if not
     */
    boolean check();

    /**
     * Performs the data migration.
     *
     * @throws Exception in case of any issues during migration of the data. This will usually not
     *                   roll back changes and may leave the system in an unstable state.
     */
    void run() throws Exception;

    /**
     * Cleans up any temporary data or the marker that triggered the migration
     *
     * @throws Exception in case of any issues during cleanup
     */
    void cleanup() throws Exception;
}
