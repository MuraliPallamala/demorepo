package com.ibm.au.bgx.model.chain.profile;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import java.util.List;

/**
 * Interface <b>ProfileRequestManager</b>. This interface defines the basic operations
 * that each manager implementation should expose. The interface specifies a generic
 * type <i>T</i> which inherited interfaces and classes specialise for a give type of
 * request.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com> 
 * 
 * @param <T> 	the type of request that the manager interacts with.
 * 
 * @see OrgProfileRequestManager
 * @see UserProfileRequestManager
 */

public interface ProfileRequestManager<T> {

	/**
	 * Creates the request. This method processes and validates the given request <i>req</i>
	 * and stores it with updated details (e.g. a unique identifier if not provided already)
	 * into the storage system backing the activities of the request manager.
	 * 
	 * @param req	an instance containing the request details to be entered into the system.
	 * 				It cannot be {@literal null}.
	 * 
	 * @return	the updated request. It is guaranteed to not to be {@literal null} and have a
	 * 			valid unique identifier. 
	 * 
	 * @throws IllegalArgumentException	if <i>req</i> is {@literal null}.
	 */
    T create(T req);

    /**
     * Updates the request identified by <i>req</i> with the details it contains. The matching
     * strategy with an existing request in the system is performed by looking up the corresponding
     * request that has the same unique identifier.
     * 
     * @param req	an instance containing the updated details of the request, the value of its unique
     * 				identifier attribute is used to match an existing request in the system. It cannot
     * 				be {@literal null}.
     *  
     * @return	the updated request. It is guaranteed to not to be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>req</i> is {@literal null}.
     * @throws DataNotFoundException 	if <i>req</i> does not match an existing request.
     * 			
     */
    T update(T req);

    /**
     * Updates the request identified by <i>id</i> and sets its status to {@link Status#APPROVED}. This
     * operation is only successful if the request is in a status that allows the approved status to be
     * set and meets all the requirements for approval. These requirements depends on the specific type
     * of request, but it is expected that in order to set the status to {@link Status#APPROVED} the 
     * existing request must at least be in {@link Status#CONFIRMED}. Other requirements may exist.
     * 
     * @param id	a {@link String} representing the unique identifier of the request to approve. It 
     * 				cannot be {@literal null} or an empty string, and it must match an existing request.
     * 
     * @return	the updated request according to the new approved status. The details of the updates made
     * 			depend on the specific type of request, but at minimum its status is set to {@link Status#APPROVED}.
     * 
     * @throws IllegalArgumentException	if <i>id</i> is {@literal null} or an empty string.
     * @throws IllegalStateException 	if the operation is invalid according to the current status of the request.
     * @throws DataNotFoundException	if <i>id</i> does not match an existing request.
     */
    T complete(String id);

    /**
     * Updates the request identified by <i>id</i> and sets its status to {@link Status#CONFIRMED}. This
     * operation it only successful if the request is in a {@link Status#DRAFTED} status and it meets the
     * requirements for setting the status to confirmed, which vary according to the specific type <i>T</i>
     * of the request.
     * 
     * @param id	a {@link String} representing the unique identifier of the request to confirm. It cannot
     * 				be {@literal null} or an empty string, and it must match an existing request.
     * 
     * @return 	the updated request according to the new confirmed status. The details of the updates made
     * 			depend on the specific type of request, but at minimum its status is set to {@link Status#CONFIRMED}.
     * 
     * @throws IllegalArgumentException	if <i>id</i> is {@literal null} or an empty string.
     * @throws IllegalStateException 	if the operation is invalid according to the current status of the request.
     * @throws DataNotFoundException	if <i>id</i> does not match an existing request.
     */
    T confirm(String id);

    /**
     * Updates the request identified by <i>id</i> and sets its status to {@link Status#REJECTED}. This
     * operation it only successful if the request is in a {@link Status#CONFIRMED} status and it meets the
     * requirements for setting the status to rejected, which vary according to the specific type <i>T</i>
     * of the request.
     * 
     * @param id	a {@link String} representing the unique identifier of the request to reject. It cannot
     * 				be {@literal null} or an empty string, and it must match an existing request.
     * 
     * @return 	the updated request according to the new confirmed status. The details of the updates made
     * 			depend on the specific type of request, but at minimum its status is set to {@link Status#REJECTED}.
     * 
     * @throws IllegalArgumentException	if <i>id</i> is {@literal null} or an empty string.
     * @throws IllegalStateException 	if the operation is invalid according to the current status of the request.
     * @throws DataNotFoundException	if <i>id</i> does not match an existing request.
     */
    T reject(String id);
    

    /**
     * Updates the request identified by <i>id</i> and sets its status to {@link Status#ABANDONED}. This status
     * may indicate multiple things. One reason could be that the request has expired prior to receive confirmation
     * or it has been abandoned by the entity that it has initiated the process or is required to confirm it. Abandoned
     * request may eventually be deleted over time. Their deletion is subject to the specific requirements in terms of
     * data collection that are associated to the type <i>T</i> of the request.
     * 
     * @param id	a {@link String} representing the unique identifier of the request to make void. It cannot
     * 				be {@literal null} or an empty string, and it must match an existing request.
     * 
     * @return 	the updated request according to the new confirmed status. The details of the updates made
     * 			depend on the specific type of request, but at minimum its status is set to {@link Status#ABANDONED}.
     * 
     * @throws IllegalArgumentException	if <i>id</i> is {@literal null} or an empty string.
     * @throws IllegalStateException 	if the operation is invalid according to the current status of the request.
     * @throws DataNotFoundException	if <i>id</i> does not match an existing request.
     */
    T voidProfileRequest(T req);

    /**
     * Removes the request identified by <i>req</i>. This operation deletes all the information associated to the corresponding
     * request matched by using the unique identifier of the given request.
     * 
     * @param req	an instance containing the details of the request to remove, the value of its unique identifier attribute is 
     * 				used to match an existing request in the system. It cannot be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>req</i> is {@literal null}.
     * @throws DataNotFoundException	if <i>req</i> does not match an existing request.
     */
    void deleteProfileRequest(T req);

    /**
     * Retrieves the request that matches the given unique identifier.
     * 
     * @param id	a {@link String} representing the unique identifier of the request. It cannot be {@literal null} or
     * 				an empty string, and it must match an existing request.
     * @return
     */
    T getById(String id);

    /**
     * Retrieves all the requests that are managed by this instance.
     * 
     * @return	a {@link List} implementation containing all the request managed by this instance of the manager.
     * 			It is guaranteed to not to be {@literal null} but it may be empty if there are no requests entered
     * 			into the system.
     */
    List<T> getAll();

    /**
     * Retrieves the requests that require review. These are requests that are either in the status {@link Status#DRAFTED}
     * or the status {@link Status#CONFIRMED}. The former indicates requests just created that have not received a confirmation
     * yet, while the latter indicate requests that have been confirmed and that are ready for approval or rejection.
     * 
     * @param status	a {@link Status} value that can be used to further filter the requests to retrieve. This can be omitted,
     * 					thus instructing the manager to retrieve both requests in status {@link Status#DRAFTED} and status {@link 
     * 					Status#CONFIRMED} or set to one of these values to only retrieve the requests in that specific status.
     * 
     * @return	a {@link List} implementation containing the request that match the search criteria. It is guaranteed to not to
     * 			be {@literal null} but it may be empty, if there are not matching requests. 
     */
    List<T> getForReview(Status status);

    /**
     * Updates the credentials that are associated to the request identified by <i>id</i>. This operation essentially regenerates
     * the credentials that are stored with the request. This operation is performed when new credentials are required as a result
     * of the request moving from one stage of its life-cycle to another, but such credentials are not explicitly provided because
     * are system generated.
     * 
     * @param id	a {@link String} representing the unique identifier of the request. It cannot be {@literal null} or
     * 				an empty string, and it must match an existing request.
     * 
     * @return	the update request identified by <i>id</i> with the newly generated credentials.
     * 
     * @throws IllegalArgumentException	if <i>id</i> is {@literal null} or an empty string.
     * @throws DataNotFoundException	if <i>id</i> does not match an existing request.
     */
    T refreshCredentials(String id);

}
