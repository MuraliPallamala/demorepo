/**
 * 
 */
package com.ibm.au.bgx.model.text;

import java.io.IOException;
import java.io.InputStream;

/**
 * Class <b>UrlTemplateReference</b>. Extends {@link TemplateReference}
 * and provides means for accessing a template that is represented by a
 * URL. This class does not provide any concrete capability for access
 * to the template, but it functions as a base class for more specific
 * {@link TemplateReference} implementation.
 * 
 * @see FileTemplateReference
 * @see ResourceTemplateReference
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public abstract class UrlTemplateReference extends TemplateReference {

	/**
	 * A {@link String} containing the full URL to the template.
	 */
	private String url;
	
	/**
	 * Initialises an instance of {@link UrlTemplateReference} with the
	 * given URL.
	 * 
	 * @param url	a {@link String} representing the URL to the resource.
	 * 				It cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException if <i>url</i> is {@litral null}.
	 */
	public UrlTemplateReference(String url) {
		
		if (url == null) {
			
			throw new IllegalArgumentException("Parameter 'url' cannot be null.");
		}
		
		this.url = url;
	}
	/**
	 * Gets the URL to the template.
	 * 
	 * @return	a {@link String} representing the URL to the template. It cannot 
	 * 			be {@literal null}.
	 */
	public String getUrl() {
		
		return this.url;
	}
	
	/**
	 * Gets access to the stream that can be used to read the template's content.
	 * 
	 * @return	an implementation of {@link InputStream} that provides access to
	 * 			the content of the template.
	 * 
	 * @throws IOException	if there is an error in opening the stream.
	 */
	public abstract InputStream getStream() throws IOException;
}
