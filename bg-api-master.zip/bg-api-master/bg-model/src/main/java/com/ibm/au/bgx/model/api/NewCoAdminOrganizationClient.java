package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest;
import com.ibm.au.bgx.model.pojo.api.request.OrgChangePayloadEntity;
import com.ibm.au.bgx.model.pojo.api.response.OrgRequestActionResponse;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;

/**
 * This client interface provides interfaces for methods used for organisation management of an
 * onboarded organisation.
 *
 * @author Peter Ilfrich
 */
public interface NewCoAdminOrganizationClient {

    /**
     * This method sends an update org detail request from NewCo to NewCo admin. The payload
     * contains the updated attributes.
     *
     * @param orgId - the ID of the organization to change
     * @param payloadEntity - the new updated data
     * @return - the org change request created on NewCo admin side.
     * 
     * @throws ServiceUnavailableException 
     */
    OrgChangeRequest sendOrganizationChangeRequest(String orgId, OrgChangePayloadEntity payloadEntity) throws ServiceUnavailableException;

    /**
     * Sends an action to Newco-Admin to inform them about the updates on ongoing org change
     * requests. Newco Admin will run some validation on the payload and then perform the action on
     * their end.
     *
     * @param orgId - the ID of the organisation
     * @param requestId - the ID of the org change request
     * @param actionRequest - the action request for RECALL or CANCEL
     * @return - a response of the request from newco-admin containing information whether it was
     * successful or not
     * 
     * @throws ServiceUnavailableException 
     */
    OrgRequestActionResponse sendOrganiationChangeRequestAction(String orgId, String requestId, OrgRequestActionRequest actionRequest) throws ServiceUnavailableException;

}
