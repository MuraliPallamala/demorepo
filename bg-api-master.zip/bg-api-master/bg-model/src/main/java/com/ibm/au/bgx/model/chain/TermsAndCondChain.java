package com.ibm.au.bgx.model.chain;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;
import java.util.List;

/**
 * Interface for terms and condition chain
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com> 
 * 
 */

public interface TermsAndCondChain {

    TermsAndCond create(TermsAndCond tc) throws ProfileChainException;

    TermsAndCond getById(String id) throws ProfileChainException;

    List<TermsAndCond> getAll(String title, String type) throws ProfileChainException;

    List<TermsAndCond> getActive(String title, String type) throws ProfileChainException;

    void updateActiveStatus(String id, boolean activeStatus) throws ProfileChainException;
}
