package com.ibm.au.bgx.model.audit;

import com.ibm.au.bgx.model.pojo.audit.AuditEvent;
import com.ibm.au.bgx.model.pojo.audit.UserPermission;
import com.ibm.au.bgx.model.pojo.system.SystemActionType;
import com.ibm.au.bgx.model.user.BgxPrincipal;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

/**
 * Interface for operations related to auditing. An implementation will provide methods to log audit
 * events, retrieve them, compress and decompress the audit event payload and write them to CSV.
 *
 * @author Peter Ilfrich
 */
public interface AuditManager {

    /**
     * The topic for user related operations (permissions, onboarding, deletion)
     */
    String TOPIC_USER = "user";

    /**
     * The topic for organisation related operations (linking, change details, onboarding, approval
     * model)
     */
    String TOPIC_ORGANIZATION = "org";

    /**
     * The topic for guarantee related operations
     */
    String TOPIC_GX = "gx";

    /**
     * Logs an empty audit event with a specific type.
     *
     * @param eventType - the type of the audit event to create
     */
    void logAuditEvent(String eventType);

    /**
     * Logs an audit event of a given type with a specified payload.
     *
     * @param eventType - the type of the audit event to create
     * @param data      - the payload to attach to the audit event
     */
    void logAuditEvent(String eventType, Map<String, Object> data);

    /**
     * Logs an audit event of a given type for a specific org
     *
     * @param eventType - the type of the audit event to create
     * @param orgId     - the organisation for which to log the event
     */
    void logAuditEvent(String eventType, String orgId);

    /**
     * Logs an audit event with the provided parameters
     *
     * @param eventType - the type of the audit event to create
     * @param orgId     - the organisation for which to log the event
     * @param data      - the payload to attach to the audit event
     */
    void logAuditEvent(String eventType, String orgId, Map<String, Object> data);

    /**
     * Logs an audit event with the provided parameters
     *
     * @param eventType - the type of the audit event to create
     * @param orgId     - the organisation for which to log the event
     * @param userId    - the user that caused the audit event
     */
    void logAuditEvent(String eventType, String orgId, String userId);

    /**
     * Logs an audit event with the provided parameters
     *
     * @param eventType - the type of the audit event to create
     * @param orgId     - the organisation for which to log the event
     * @param userId    - the user that caused the audit event
     * @param data      - the payload to attach to the audit event
     */
    void logAuditEvent(String eventType, String orgId, String userId, Map<String, Object> data);

    /**
     * Logs an audit event with the provided parameters
     *
     * @param eventType - the type of the audit event to create
     * @param orgId     - the organisation for which to log the event
     * @param userId    - the user that caused the audit event
     * @param gxId      - the id of the guarantee this audit event relates to
     */
    void logAuditEvent(String eventType, String orgId, String userId, String gxId);

    /**
     * Logs an audit event with the provided parameters
     *
     * @param eventType - the type of the audit event to create
     * @param orgId     - the organisation for which to log the event
     * @param userId    - the user that caused the audit event
     * @param gxId      - the id of the guarantee this audit event relates to
     * @param data      - the payload to attach to the audit event
     */
    void logAuditEvent(String eventType, String orgId, String userId, String gxId, Map<String, Object> data);


    /**
     * Logs an audit event with the provided parameters
     *
     * @param eventType - the system action representing the type of the audit event to create
     * @param principal - the user that triggered this audit event
     * @param data      - the payload to be attached to the audit event
     */
    void logAuditEvent(SystemActionType eventType, BgxPrincipal principal, Map<String, Object> data);

    /**
     * Logs the provided audit event.
     *
     * @param event - the event to log
     */
    void logAuditEvent(AuditEvent event);

    /**
     * Packs the payload attached to an audit event by reducing Entities to their ID and an
     * identifier instead of the full object.
     *
     * @param event - the audit event containing some payload.
     */
    void packData(AuditEvent event);

    /**
     * Unpacks the payload attached to an audit event. This will resolve the IDs stored in the
     * payload of the event with the actual database object that this method will retrieve and
     * replace the IDs in the payload with the actual object that it resolves to.
     *
     * @param event     	the audit event to unpack
     * @param lookupMap 	an optional lookup map that contains ID to object mappings for items to
     *                  	resolve.
     * @param principal		the {@link BgxPrincipal} implementation that provides information about
     * 						the identity associated to the current execution context.
     */
    void unpackData(AuditEvent event, Map<String, Object> lookupMap, BgxPrincipal principal);

    /**
     * Unpacks a list of audit events by calling the unpackData(AuditEvent, Map) method for each of
     * the provided events in the list.
     *
     * @param events 		a list of audit events to unpack.
     * @param principal		the {@link BgxPrincipal} implementation that provides information about
     * 						the identity associated to the current execution context.
     * 
     * 
     * @return a {@link List} implementation containing the unpacked/expanded events.
     */
    List<AuditEvent> unpackData(List<AuditEvent> events, BgxPrincipal principal);

    /**
     * Retrieves a list of audit events belonging to a specific organisation.
     *
     * @param orgId      	the id of the org to filter audit events for
     * @param type       	the type of the audit events to filter for
     * @param beforeDate 	optional before date, which is the upper bound for the date where an
     *                   	audit event was logged
     * @param afterDate  	optional after date, which is the lower bound for the data where an audit
     *                   	event was logged.
     * @return a list of audit events matching the provided criteria
     */
    List<AuditEvent> getByOrg(String orgId, String type, String beforeDate, String afterDate);

    /**
     * Retrieves a list of audit events related to a specific user.
     *
     * @param orgId     	the id of the org to filter audit events for
     * @param userId    	the id of the user to filter audit events for
     * @param beforeDate 	optional before date, which is the upper bound for the date where an
     *                   	audit event was logged
     * @param afterDate  	optional after date, which is the lower bound for the data where an audit
     *                   	event was logged.
     * @return a list of audit events matching the provided criteria
     */
    List<AuditEvent> getByUser(String orgId, String userId, String beforeDate, String afterDate);

    /**
     * Retrieves a list of audit events related to a specific guarantee
     *
     * @param gxId       - the id of the guarantee to filter for
     * @param beforeDate - optional before date, which is the upper bound for the date where an
     *                   audit event was logged
     * @param afterDate  - optional after date, which is the lower bound for the data where an audit
     *                   event was logged.
     * @return a list of audit events matching the provided criteria
     */
    List<AuditEvent> getByGuarantee(String gxId, String beforeDate, String afterDate);

    /**
     * Retrieves a list of audit events filtered by type and target org id.
     *
     * @param targetOrgId - the id of the organisation stored in the payload of the audit events
     * @param type        - the optional type of the audit event to further filter by
     * @param beforeDate  - optional before date, which is the upper bound for the date where an
     *                    audit event was logged
     * @param afterDate   - optional after date, which is the lower bound for the data where an
     *                    audit event was logged.
     * @return a {@link List} implementation representing the list of retrieved events.
     */
    List<AuditEvent> getByTargetOrgId(String targetOrgId, String type, String beforeDate, String afterDate);

    /**
     * Writes a list of audit events to the provided output stream in CSV format.
     *
     * @param events      - the list of audit events to write down
     * @param writeStream - the output stream that will be written to
     * @param principal -  the principal requesting it (optional)
     * @throws IOException in case of errors while writing to the output stream
     */
    void writeCsv(List<AuditEvent> events, OutputStream writeStream, BgxPrincipal principal) throws IOException;

    /**
     * Writes the user permission CSV report to a given output stream.
     *
     * @param orgId       - the id of the organisation to which the list of permissions belongs to
     * @param permissions - the list of user permission entries (this is user information and
     *                    roles)
     * @param writeStream - the output stream that will be written to
     * @throws IOException in case of errors while writing to the output stream
     */
    void writePermCsv(String orgId, List<UserPermission> permissions, OutputStream writeStream) throws IOException;

    /**
     * Computes the list of users with their permissions at a given date. This will read audit
     * events and reconstruct the permissions and users at a given date.
     *
     * @param orgId           	the id for which to compute the user permissions for.
     * @param atDate          	the date, which represents the beforeDate to search audit events
     *                        	for.
     * @param subisidiaryFlag 	flag indicating whether we're retrieving user permissions of a
     *                        	subsidiary organisation of their parent users.
     * @param principal			the {@link BgxPrincipal} implementation that provides information about
     * 							the identity associated to the current execution context.
     *                        
     * @return	a {@link List} implementation containing the audit events that represents update to the
     * 			user permissions within the given date range.
     */
    List<UserPermission> getOrgUserPermissions(String orgId, String atDate, boolean subisidiaryFlag, BgxPrincipal principal);

    /**
     * Retrieves a list of org user permission audit events. This includes onboarding, updating
     * roles and deleting users.
     *
     * @param orgId      	the id of the organisation for which to retrieve user permission events.
     * @param beforeDate 	optional before date, which is the upper bound for the date where an
     *                   	audit event was logged
     * @param afterDate  	optional after date, which is the lower bound for the data where an audit
     *                   	event was logged.
     *                   
     * @return  a {@link List} implementation containing the audit events that represents update to the
     * 			user permissions within the given date range.
     */
    List<AuditEvent> getOrgUserPermissionEvents(String orgId, String beforeDate, String afterDate);

    /**
     * Filters a list of audit events by topic.
     *
     * @param events      	the list of audit events
     * @param topicFilter 	the provided filter of the reference type of an audit event
     * 
     * @return a filtered list containing only those audit events from the input that match the
     * topic filter.
     */
    List<AuditEvent> filterByTopic(List<AuditEvent> events, String topicFilter);
}
