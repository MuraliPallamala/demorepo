package com.ibm.au.bgx.model.repository;

import java.util.List;

/**
 * Interface <b>Repository</b>. This interface is a base abstraction for all the repository
 * implementations in the solution. It provides type agnostic functionality for CRUD operations
 * against a given data store of items of type <i>T</i> with unique identifier of type <i>Z</i>.
 * Inherited interfaces that specialise this interface to a specific type of entities may add 
 * more functionalities by exposing additional methods that are meaningful to a given entity 
 * type.
 * 
 * @param <T>	the type defining the entities stored in the repository.
 * @param <Z>	the type defining the unique identifier of the entities stored in the repository.
 * 
 * @author Peter Ilfrich
 * @author Christian Vecchiola
 */
public interface Repository<T,Z> {

    /**
     * Returns the collection of items that are in the repository.
     *
     * @return a {@link List} implementation that contains the collection of instances
     * 			store in the repository.
     */
    List<T> getAll();

    /**
     * Returns the item that corresponds to the given <i>id</i>.
     *
     * @param id  a {@link Z} representing the unique identifier of the item.
     * 			  It cannot be {@literal null} or generally invalid (i.e. an empty 
     * 			  string).
     *
     * @return the instance that corresponds to <i>id</i> if found, {@literal null}
     * 			otherwise.
     *
     * @throws IllegalArgumentException if <i>id</i> is {@literal null} or more generally
     * 									invalid (for instance, in the case <i>Z</> is a
     * 									{@link String}, an empty string).
     */
    T getItem(Z id);

    /**
     * Adds the given item to the repository. The item is expected to have a unique
     * identifier field that can either be provided or not. If not provided the
     * repository will set the unique identifier upon greation.
     *
     * @param item  the item to add. It cannot be {@literal null}.
     *
     * @throws IllegalArgumentException if <i>item</i> is {@literal null}.
     */
    T addItem(T item);


    /**
     * Updates the given item to the repository. This method expects the given item to
     * have an identifier that can be used to retrieve the correspoinding item in the
     * repository to update. The identifier it is expected to be a valid identifier that
     * matches and existing record.
     *
     * @param item  the item to update. It cannot be {@literal null}.
     *
     * @throws IllegalArgumentException if <i>item</i> is {@literal null} or the item 
     * 									identifier is  {@literal null} or more generally
     * 									invalid (for instance, in the case <i>Z</> is a
     * 									{@link String}, an empty string).
     * 
     * @throws IllegalStateException	if <i>item</i> is not matched to a corresponding
     * 									entity in the repository.
     */
    T updateItem(T item);

    /**
     * Removes all the documents from the repository.
     */
    void removeAll();

    /**
     * Removes the given document from the repository. If the item is not found the method
     * will throw no exception. The rationale here is that the intended outcome of the 
     * method is achieved regardless of whether the repository contains or does not contain
     * the item. Hence there is no reason to throw an exception if the item is not found.
     *
     * @param id  the id of the item to remove. It cannot be {@literal null}.
     *
     * @throws IllegalArgumentException if <i>id</i> is {@literal null} or more generally
     * 									invalid (for instance, in the case <i>Z</> is a
     * 									{@link String}, an empty string).
     * 
     * @throws DataNotFoundException if <i>id</i> does not match any existing entity.
     */
    void removeItem(Z id);

}
