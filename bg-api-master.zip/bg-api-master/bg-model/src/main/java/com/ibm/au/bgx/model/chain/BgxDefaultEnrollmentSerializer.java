package com.ibm.au.bgx.model.chain;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.util.BasicBgxEncryptionUtil;
import java.io.IOException;

/**
 * Class <b>DefaultEnrollmentSerializer</b>. This class serialize an instance of
 * {@link BgxDefaultEnrollment}
 *
 * This PrivateKey field cannot be automatically serialized, we are using custom
 * serializer and deserializer This serializer converts the whole object to byte
 * array for storage.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public class BgxDefaultEnrollmentSerializer extends StdSerializer<BgxDefaultEnrollment> {

    /**
     *
     */
    private static final long serialVersionUID = -3933888985582096710L;

    /**
     * 
     */
    public BgxDefaultEnrollmentSerializer() {
        this(null);
    }

    /**
     * 
     * @param t
     */
    public BgxDefaultEnrollmentSerializer(Class<BgxDefaultEnrollment> t) {
        super(t);
    }

    /**
     * 
     */
    @Override
    public void serialize(BgxDefaultEnrollment bgxDefaultEnrollment, JsonGenerator jsonGenerator,
        SerializerProvider serializerProvider) throws IOException {

        try {

            String encodedKey = BasicBgxEncryptionUtil.toPem(bgxDefaultEnrollment.getKey());

            jsonGenerator.writeStartObject();
            jsonGenerator
                .writeStringField(BgxConstants.META_CERT, bgxDefaultEnrollment.getCert());
            jsonGenerator.writeStringField(BgxConstants.META_PRIVATE_KEY, encodedKey);
            jsonGenerator.writeEndObject();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
