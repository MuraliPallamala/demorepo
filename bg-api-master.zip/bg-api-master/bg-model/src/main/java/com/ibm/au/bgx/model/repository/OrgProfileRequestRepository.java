package com.ibm.au.bgx.model.repository;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;

import java.util.List;

/**
 * Organizaiton profile request repository
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface OrgProfileRequestRepository extends DefaultRepository<OrgProfileRequest> {

    /**
     * Return a list of available profile requests
     * @param referrerId 
     *
     * @param bid A {@link String} containing businessId
     * @return 
     */
    List<OrgProfileRequest> getByBusinessId(String referrerId, String bid);

    /**
     * Return a list of available profile requests
     *
     * If status is passed as null, it will return all available profile requests Otherwise it will
     * return the matching profiles with the given businessId and status
     * @param referrerId 
     *
     * @param bid A {@link String} containing businessId
     * @param status A {@link String} containing satus. It can be NULL to force ignoring status
     * during checks
     * @return 
     */
    List<OrgProfileRequest> getByBusinessId(String referrerId, String bid, Status status);

    /**
     * Return profile by the on-boarding key
     *
     * @param key A {@link String} containing on-boarding key
     * @return 
     */
    OrgProfileRequest getByOnboardingKey(String key);

    /**
     * Returns profile by referrer I
     *
     * @param referrerId - the referrer id
     * @return - the org profile request matching the referrer id
     */
    List<OrgProfileRequest> getByReferrerId(String referrerId);

    /**
     * Returns profile by referrer I
     *
     * @param referralToken - the referrer token
     * @return - the org profile request matching the referrer id
     */
    OrgProfileRequest getByReferralToken(String referralToken);

    /**
     * Returns profile for review by Newco Admin
     *
     * @param status - status
     * @return - the org profile request matching the referrer id
     */
    List<OrgProfileRequest> getForReview(Status status);

    /**
     * Query database by status without any further restrictions.
     * @param status 
     * @return 
     */
    List<OrgProfileRequest> getByStatus(Status status);

    /**
     * 
     * @param referrerId
     * @param status
     * @return
     */
    List<OrgProfileRequest> getByReferrerIdAndStatus(String referrerId, Status status);
}
