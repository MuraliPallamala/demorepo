package com.ibm.au.bgx.model.logging;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

/**
 * Class <b>BgxLogMarkers</b>. This class wraps the set of link {@link Marker} implementations
 * that are used across the application to filter, route, and partition log messages to the
 * appropriate output.
 *
 * @author Peter Ilfrich
 */
public class BgxLogMarkers {
	

    /**
     * Any technical information relating the fabric connection (peers, orderer, proposals,
     * connection, events, ...)
     */
    public static final Marker FABRIC_TECH = MarkerFactory.getMarker("FABRIC_TECH");

    /**
     * Domain specific marker to capture any business logic logging. The domain log should read like
     * a journal of what business actions have been performed in the system.
     */
    public static final Marker DOMAIN = MarkerFactory.getMarker("DOMAIN");

    /**
     * Development marker, used for debugging messages during development. Usages of this filter to
     * be cleaned up before committing code.
     */
    public static final Marker DEV = MarkerFactory.getMarker("DEV");

    /**
     * Marker to log performance figures for various performance-sensitive actions.
     */
    public static final Marker PERFORMANCE = MarkerFactory.getMarker("PERFORMANCE");

    /**
     * Marker to log authentication events to debug authentication issues
     */
    public static final Marker AUTH = MarkerFactory.getMarker("AUTH");
    
    /**
     * Marker to log information that is useful for building statistics and reporting.
     * This is for instance used to keep track of how many organisations are created,
     * guarantee request processed, etc...
     */
    public static final Marker STATS = MarkerFactory.getMarker("STATS");
}
