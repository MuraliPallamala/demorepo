package com.ibm.au.bgx.model.api.exceptions;

import java.math.BigInteger;
import java.util.Map;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public class ApiServiceUnavailableException extends ApiException {

	/**
	 * A {@link Long} value used to discriminate among different instances that
	 * have the same class name (but may not be the same) during serialization.
	 */
	private static final long serialVersionUID = -4820664544854939365L;

	/**
	 * 
	 * @param path
	 * @param message
	 * @param description
	 * @param zero
	 * @param context
	 * @param innerException
	 */
	public ApiServiceUnavailableException(String path, String message, String description, BigInteger zero, Map<String, Object> context, Throwable innerException) {
        super(path, message, description, zero, context, innerException);
    }

	/**
	 * 
	 * @param path
	 * @param message
	 * @param description
	 * @param zero
	 * @param context
	 */
    public ApiServiceUnavailableException(String path, String message, String description, BigInteger zero, Map<String, Object> context) {
        super(path, message, description, zero, context);
    }

    /**
     * 
     * @param path
     * @param message
     * @param innerException
     */
    public ApiServiceUnavailableException(String path, String message, Throwable innerException) {
        super(path, message, innerException);
    }
}
