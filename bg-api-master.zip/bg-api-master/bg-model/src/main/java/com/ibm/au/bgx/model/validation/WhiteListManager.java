package com.ibm.au.bgx.model.validation;

import com.ibm.au.bgx.model.pojo.OrgProfile;

/**
 * Interface <b>WhiteListManager</b>. This interface defines the basic contract
 * for any implementation of components used to white-list organisation profiles.
 * The white-listing of organisation profiles is used within the context of onboarding
 * to bypass the business id check of organisations.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public interface WhiteListManager {
	
	/**
	 * This method checks whether the given organisation profile is white listed. 
	 * 
	 * @param profile	a {@link OrgProfile} representing the organisation profile
	 * 					to check for white listing. It is expected to not to be
	 * 					{@literal null}.
	 * 
	 * @return 	{@literal true} if there is a configured white list and an entry that
	 * 			matches the given profile, {@literal false} otherwise.
	 * 
	 * @throws IllegalArgumentException		if <i>profile</i> is {@literal null}.
	 */
	boolean isWhiteListed(OrgProfile profile);

}
