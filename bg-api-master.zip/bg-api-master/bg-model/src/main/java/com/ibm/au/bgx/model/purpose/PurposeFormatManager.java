package com.ibm.au.bgx.model.purpose;

import com.ibm.au.bgx.model.api.exceptions.ApiException;
import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.pojo.purpose.NewPurposeFormat;
import com.ibm.au.bgx.model.pojo.purpose.PurposeField;
import com.ibm.au.bgx.model.pojo.purpose.PurposeFormat;

import java.util.List;
import java.util.Map;

/**
 * Interface used to access (get) and handle (add) purpose formats for guarantee documents. It
 * offers an API to validate a purpose format request used to add a new one (and perform the add)
 * and also allows to retrieve, search and filter purpose formats. It also offers an off-chain cache
 * for performance purposes.
 *
 * @author Peter Ilfrich
 */
public interface PurposeFormatManager {

    /**
     * Initialises the purpose format manager.
     *
     * @throws ProfileChainException in case of communication issues with the blockchain
     */
    void init() throws ProfileChainException;

    /**
     * Validates an incoming purpose format request and returns a list of exceptions found during
     * the validation.
     *
     * @param newPurposeFormat an incoming purpose format, potentially containing field
     *                             references
     * @return a list of exceptions thrown during the validation (or empty list, if all is ok)
     */
    List<DataValidationException> validate(NewPurposeFormat newPurposeFormat);

    /**
     * Creates a new purpose format on the blockchain. This will resolve references and create a new
     * record on the blockchain.
     *
     * @param newPurposeFormat the incoming purpose format, potentially containing field
     *                             references.
     * @return the newly created purpose format
     * @throws ApiException in case communication issues with the blockchain or validation / resolve
     *                      issues.
     */
    PurposeFormat create(NewPurposeFormat newPurposeFormat) throws ApiException;

    /**
     * Updates the active status of an existing purpose format to the provided one.
     *
     * @param formatId        - the id of the purpose format to update
     * @param newActiveStatus - the new active status of that provided purpose format
     * @return the updated purpose format
     * @throws ApiException in case of any errors during communication with the blockchain or data
     *                      errors.
     */
    PurposeFormat updateActiveStatus(String formatId, boolean newActiveStatus) throws ApiException;

    /**
     * Retrieves a given purpose format from the blockchain or the local cache.
     *
     * @param formatId - the id of the purpose format to retrieve
     * @return a purpose format as it is returned from the blockchain
     */
    PurposeFormat get(String formatId);

    /**
     * Retrieves a list of all purpose formats available in the system.
     *
     * @return a list of available purpose formats
     */
    List<PurposeFormat> getAll();

    /**
     * Retrieves a list of all purpose formats filtered by their active status.
     *
     * @param activeFlag - the active status to filter for
     * @return a list of matching purpose formats (active flag match)
     */
    List<PurposeFormat> getAll(boolean activeFlag);

    /**
     * Refreshes and reloads a specific purpose format from the blockchain. This can be called for
     * new purpose formats to add them to the cache or updated ones (e.g. active status changed).
     *
     * @param formatId - the id of the purpose format to refresh
     */
    void refreshCache(String formatId);

    /**
     * Parses the raw constraint object into one of the available constraint types and checks the
     * field provided of the purpose provided against that constraint.
     *
     * @param constraintRaw - constraints are stored as a list of Objects, this raw object
     *                      represents a {@link java.util.LinkedHashMap}, which should be able to
     *                      get parsed into one of the available constraint types.
     * @param field         - the purpose field definition the constraint belongs to. It is used to
     *                      lookup the field value in the purpose map.
     * @param purpose       - the purpose of a GX issue or GX amend request payload, or a sub
     *                      section of it, if the field is a sub field.
     * @throws IllegalArgumentException in case of validation errors or in case of an invalid object
     *                                  provided as the constraintRaw
     */
    void validatePurposeFieldConstraint(Object constraintRaw, PurposeField field, Map<String, Object> purpose) throws DataValidationException;

    /**
     * Creates a string representation of the purpose using the serialisation string provided in the
     * purpose format. It uses template literals - e.g. ${value} - to replace placeholders with the
     * corresponding value in the purpose payload.
     *
     * @param purposeFormat - the purpose format specifying how to render the purpose as a string
     * @param purpose       - the full purpose payload
     * @return a string representation of the purpose
     */
    String stringifyPurpose(PurposeFormat purposeFormat, Map<String, Object> purpose);
}
