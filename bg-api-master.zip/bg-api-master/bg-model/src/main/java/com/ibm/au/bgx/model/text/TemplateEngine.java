/**
 * 
 */
package com.ibm.au.bgx.model.text;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

/**
 * <p>
 * Interface <i>TemplateEngine</i>. This interface defines the basic capabilities 
 * for implementing a minimal template engine that allow customising the output 
 * with a set of key-value pairs, where keys are used to match placeholder in the 
 * template text, and value are the corresponding actuals that will replace the
 * place holders.
 * </p>
 * <p> 
 * In designing the interface, we do not want to assume any templating technology
 * but just provide those capabilities that are common to all templating engines,
 * which essentially are the ability to replace value in a template that can be
 * passed as a string, or read via a file.
 * </p>
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public interface TemplateEngine {

	/**
	 * Renders the content of the given <i>template</i>, by applying the substitutions
	 * that are defined in <i>model</i>.
	 * 
	 * @param template	a {@link String} representing the template text to render. It
	 * 					cannot be {@literal null} but it can be an empty string.
	 * 
	 * @param model		a {@link Map} implementation that represents the collection
	 * 					of key-value pairs used to specialise the template. The keys
	 * 					of the map represent the placeholders in the template, while
	 * 					the values the corresponding replacements for such placeholders.
	 * 					It cannot be {@literal null} but it can be empty.
	 * 
	 * @return	a {@link String} representing the original <i>template</i> specialised with
	 * 			the pairings defined in <i>model</i>. It can be an empty string, but it cannot
	 * 			be {@literal null}.
	 * 
	 * @throws TemplateException	if there is any error while performing the rendering.
	 * @throws IllegalArgumentException		if  <i>template</i> or <i>model</i> is {@literal null}.
	 */
	public String render(String template, Map<String, Object> model) throws TemplateException;
	
	/**
	 * Renders the content accessible via <i>template</i>, by applying the substitutions
	 * that are defined in <i>model</i>.
	 * 
	 * @param template	an {@link File} instance providing access to the template text to render. It 
	 * 					cannot be {@literal null} but it point to empty content.
	 * 
	 * @param model		a {@link Map} implementation that represents the collection of key-value 
	 * 					pairs used to specialise the template. The keys of the map represent the 
	 * 					placeholders in the template, while the values the corresponding replacements 
	 * 					for such placeholders. It cannot be {@literal null} but it can be empty.
	 * 
	 * @return	a {@link String} representing the original content fetched from <i>template</i> 
	 * 			and specialised with the pairings defined in <i>model</i>. It can be an empty string,
	 * 			but it cannot be {@literal null}.
	 * 
	 * @throws TemplateException	if there is any error while performing the rendering.
	 * @throws IllegalArgumentException		if  <i>template</i> or <i>model</i> is {@literal null}.
	 */
	public String render(File template, Map<String, Object> model) throws TemplateException;
	

	/**
	 * Renders the content accessible via <i>template</i>, by applying the substitutions
	 * that are defined in <i>model</i>.
	 * 
	 * @param template	an {@link InputStream} instance providing access to the template text to render. It 
	 * 					cannot be {@literal null} but it point to empty content.
	 * 
	 * @param model		a {@link Map} implementation that represents the collection of key-value 
	 * 					pairs used to specialise the template. The keys of the map represent the 
	 * 					placeholders in the template, while the values the corresponding replacements 
	 * 					for such placeholders. It cannot be {@literal null} but it can be empty.
	 * 
	 * @return	a {@link String} representing the original content fetched from <i>template</i> 
	 * 			and specialised with the pairings defined in <i>model</i>. It can be an empty string,
	 * 			but it cannot be {@literal null}.
	 * 
	 * @throws TemplateException	if there is any error while performing the rendering.
	 * @throws IllegalArgumentException		if  <i>template</i> or <i>model</i> is {@literal null}.
	 */
	public String render(InputStream template, Map<String, Object> model) throws TemplateException;
	
	/**
	 * Renders the content of the given <i>template</i>, by applying the substitutions
	 * that are defined in <i>model</i>. This is an overloaded version of {@link #render(String, Map)}
	 * that can be used to render large amounts of text.
	 * 
	 * @param template	a {@link String} representing the template text to render. It
	 * 					cannot be {@literal null} but it can be an empty string.
	 * 
	 * @param model		a {@link Map} implementation that represents the collection
	 * 					of key-value pairs used to specialise the template. The keys
	 * 					of the map represent the placeholders in the template, while
	 * 					the values the corresponding replacements for such placeholders.
	 * 					It cannot be {@literal null} but it can be empty.
	 * 
	 * @param output	an {@link OutputStream} implementation where the rendered content 
	 * 					will be written to. It cannot be {@literal null}.
	 * 
	 * @throws TemplateException	if there is any error while performing the rendering.
	 * @throws IllegalArgumentException		if  <i>template</i>, <i>model</i>, or <i>output</i>
	 * 										is {@literal null}.
	 */
	public void render(String template, Map<String, Object> model, OutputStream output) throws TemplateException;
	
	/**
	 * Renders the content accessible via <i>template</i>, by applying the substitutions
	 * that are defined in <i>model</i>. This is an overloaded version of {@link #render(String, Map)}
	 * that can be used to render large amounts of text.
	 * 
	 * @param template	an {@link File} instance providing access to the template  text to render. 
	 * 					It cannot be {@literal null} but it point to empty content.
	 * 
	 * @param model		a {@link Map} implementation that represents the collection of key-value 
	 * 					pairs used to specialise the template. The keys of the map represent the 
	 * 					placeholders in the template, while the values the corresponding replacements 
	 * 					for such placeholders. It cannot be {@literal null} but it can be empty.
	 * 
	 * @param output	an {@link OutputStream} implementation where the rendered content 
	 * 					will be written to. It cannot be {@literal null}.
	 * 
	 * @throws TemplateException	if there is any error while performing the rendering.
	 * @throws IllegalArgumentException		if  <i>template</i>, <i>model</i>, or <i>output</i>
	 * 										is {@literal null}.
	 */
	public void render(File template, Map<String, Object> model, OutputStream output) throws TemplateException;
	
	/**
	 * Renders the content accessible via <i>template</i>, by applying the substitutions
	 * that are defined in <i>model</i>. This is an overloaded version of {@link #render(String, Map)}
	 * that can be used to render large amounts of text.
	 * 
	 * @param template	an {@link InputStream} instance providing access to the template  text to render. 
	 * 					It cannot be {@literal null} but it point to empty content.
	 * 
	 * @param model		a {@link Map} implementation that represents the collection of key-value 
	 * 					pairs used to specialise the template. The keys of the map represent the 
	 * 					placeholders in the template, while the values the corresponding replacements 
	 * 					for such placeholders. It cannot be {@literal null} but it can be empty.
	 * 
	 * @param output	an {@link OutputStream} implementation where the rendered content 
	 * 					will be written to. It cannot be {@literal null}.
	 * 
	 * @throws TemplateException	if there is any error while performing the rendering.
	 * @throws IllegalArgumentException		if  <i>template</i>, <i>model</i>, or <i>output</i>
	 * 										is {@literal null}.
	 */
	public void render(InputStream template, Map<String, Object> model, OutputStream output) throws TemplateException;
	
	/**
	 * Renders the content referenced by <i>reference</i>, by applying the substitutions that are
	 * defined in <i>model</i>. This is an overloaded version of {@link #render(String, Map)} that
	 * can be used to abstract away the specific representation of the template.
	 * 
	 * @param reference		a {@link TemplateReference} instance that points to the template to 
	 * 						render. It cannot be {@literal null}.
	 * 
	 * @param model		a {@link Map} implementation that represents the collection of key-value 
	 * 					pairs used to specialise the template. The keys of the map represent the 
	 * 					placeholders in the template, while the values the corresponding replacements 
	 * 					for such placeholders. It cannot be {@literal null} but it can be empty.
	 * 
	 * @return a {@link String} representing the original content fetched from <i>template</i> 
	 * 			and specialised with the pairings defined in <i>model</i>. It can be an empty string,
	 * 			but it cannot be {@literal null}.
	 * 
	 * @throws TemplateException	if there is any error while performing the rendering.
	 * @throws IllegalArgumentException		if  <i>reference</i>, <i>model</i> is {@literal null}.
	 */
	public String render(TemplateReference reference, Map<String, Object> model) throws TemplateException;
	
	
	/**
	 * Renders the content referenced by <i>reference</i>, by applying the substitutions that are
	 * defined in <i>model</i>. This is an overloaded version of {@link #render(TemplateReference, 
	 * Map)} that can be used to render large amounts of text.
	 * 
	 * 
	 * @param reference		a {@link TemplateReference} instance that points to the template to 
	 * 						render. It cannot be {@literal null}.
	 * 
	 * @param model		a {@link Map} implementation that represents the collection of key-value 
	 * 					pairs used to specialise the template. The keys of the map represent the 
	 * 					placeholders in the template, while the values the corresponding replacements 
	 * 					for such placeholders. It cannot be {@literal null} but it can be empty.
	 * 
	 * @param output	an {@link OutputStream} implementation where the rendered content 
	 * 					will be written to. It cannot be {@literal null}.
	 * 
	 * 
	 * 
	 * @throws TemplateException	if there is any error while performing the rendering.
	 * @throws IllegalArgumentException		if  <i>reference</i>, <i>model</i>, or <i>output</i>
	 * 										is {@literal null}.
	 */
	public void render(TemplateReference reference, Map<String, Object> model, OutputStream output) throws TemplateException;
}
