package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import java.util.Map;
import org.springframework.web.client.HttpClientErrorException;

/**
 * Client used by the issuers and NewCo admin to send notifications to NewCo informing organisations
 * about approval or rejection of requests they created.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public interface NewCoNotificationClient {

    /**
     * Sends a notification to NewCo informing the referrer about the approval to an on-boarding
     * request given by the NewCo admin.
     *
     * @param request - the onboarding request this notification refers to
     * @param payload - contains the approve action meta information
     * 
     * @throws ServiceUnavailableException
     * @throws HttpClientErrorException
     */
    void sendOrganizationApprovedNotification(OrgProfileRequest request, Map<String, Object> payload) throws ServiceUnavailableException, HttpClientErrorException;

    /**
     * Sends a notification to NewCo in case the admin decides to reject the changes requested by
     * the organisation in NewCo that created the original request.
     *
     * @param request - the original org change request
     * @param rejectAction - the reject action containing the reason
     * 
     * @throws ServiceUnavailableException
     * @throws HttpClientErrorException
     */
    void sendOrgChangeAdminNotification(OrgChangeRequest request, OrgRequestAction rejectAction) throws ServiceUnavailableException, HttpClientErrorException;

}
