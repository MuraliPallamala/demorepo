package com.ibm.au.bgx.model.exception;

/**
 * Class <b>IdentityProviderException</b>. This class extends {@link Exception} and it is used to
 * identify all the errors that occur as a result of the interaction with the identity provider.
 * 
 * @author Bruno Marques <brunomar@au1.ibm.com>
 *
 */
public class IdentityProviderException extends Exception {

    /**
     * This is for versioning and serialisation.
     */
    private static final long serialVersionUID = -3267150361538204314L;

    /**
     * Initialises a new instance of {@link IdentityProviderException}.
     */
    public IdentityProviderException() {
        super();
    }

    /**
     * Initialises a new instance of the {@link IdentityProviderException} with the given
     * <i>message</i>.
     *
     * @param message a {@link String} containing a human intelligible message providing information
     *        about the cause of the exception.
     */
    public IdentityProviderException(String message) {
        super(message);
    }

    /**
     * Initialises a new instance of the {@link IdentityProviderException} with the given
     * <i>message</i> and <i>innerException</i>.
     *
     * @param message 	a {@link String} containing a human intelligible message providing 
     * 					information about the cause of the exception.
     * 
     * @param inner 	a {@link Throwable} instance that represents the cause of this instance
     *        			of {@link DataNotFoundException} to be created.
     */
    public IdentityProviderException(String message, Throwable inner) {
        super(message, inner);
    }

    /**
     * Initialises a new instance of the {@link IdentityProviderException} with the given inner
     * exception.
     *
     * @param inner 	a {@link Throwable} instance that represents the cause of this instance
     *        			of {@link IdentityProviderException} to be created.
     */
    public IdentityProviderException(Throwable inner) {
        super(inner);
    }
}
