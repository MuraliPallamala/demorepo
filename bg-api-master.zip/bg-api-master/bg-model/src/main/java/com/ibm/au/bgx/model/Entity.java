package com.ibm.au.bgx.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

/**
 * 
 * @author fl0yd
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "id",
        "createdAt",
        "createdBy",
        "updatedAt",
        "updatedBy",
        "revision",
        "attachments"
})
public class Entity implements Serializable {

    /**
     * This is a {@literal long} value that uniquely identifies the instances of this
     * particular implementation of this class. This is to prevent that instances that
     * are serialized across JVMs that point to different definitions of the same type
     * are mixed together.
     */
    private static final long serialVersionUID = -1157831674542161050L;
    
    /**
     * 
     */
    @JsonProperty("id")
    private String id;
    /**
     * 
     */
    @JsonProperty("createdAt")
    private Instant createdAt;
    /**
     * 
     */
    @JsonProperty("createdBy")
    private String createdBy;
    /**
     * 
     */
    @JsonProperty("updatedAt")
    private Instant updatedAt;
    /**
     * 
     */
    @JsonProperty("updatedBy")
    private String updatedBy;
    /**
     * 
     */
    @JsonProperty("revision")
    private String revision;
    /**
     * 
     */
    @JsonProperty("attachments")
    @Valid
    private List<Attachment> attachments = new ArrayList<>();

    /**
     * 
     * @return
     */
    @JsonProperty("id")
    public String getId() {
        return id;
    }

    /**
     * 
     * @param id
     */
    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 
     * @return
     */
    @JsonProperty("createdAt")
    public Instant getCreatedAt() {
        return this.createdAt;
    }

    /**
     * 
     * @param createdAt
     */
    @JsonProperty("createdAt")
    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * 
     * @return
     */
    @JsonProperty("createdBy")
    public String getCreatedBy() {
        return this.createdBy;
    }

    /**
     * 
     * @param createdBy
     */
    @JsonProperty("createdBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * 
     * @return
     */
    @JsonProperty("updatedAt")
    public Instant getUpdatedAt() {
        return this.updatedAt;
    }

    /**
     * 
     * @param updatedAt
     */
    @JsonProperty("updatedAt")
    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * 
     * @return
     */
    @JsonProperty("updatedBy")
    public String getUpdatedBy() {
        return this.updatedBy;
    }

    /**
     * 
     * @param updatedBy
     */
    @JsonProperty("updatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * 
     * @return
     */
    @JsonProperty("revision")
    public String getRevision() {
        return this.revision;
    }

    /**
     * 
     * @param revision
     */
    @JsonProperty("revision")
    public void setRevision(String revision) {
        this.revision = revision;
    }

    /**
     * 
     * @return
     */
    @JsonProperty("attachments")
    public List<Attachment> getAttachments() {
        return this.attachments;
    }

    /**
     * 
     * @param attachments
     */
    @JsonProperty("attachments")
    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }

    /**
     * 
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    /**
     * 
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(id).append(createdAt).append(createdBy).append(updatedAt).append(updatedBy).append(revision).append(attachments).toHashCode();
    }

    /**
     * 
     */
    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Entity) == false) {
            return false;
        }
        Entity rhs = ((Entity) other);
        return new EqualsBuilder().append(id, rhs.id).append(createdAt, rhs.createdAt).append(createdBy, rhs.createdBy).append(updatedAt, rhs.updatedAt).append(updatedBy, rhs.updatedBy).append(revision, rhs.revision).append(attachments, rhs.attachments).isEquals();
    }

}
