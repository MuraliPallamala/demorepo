package com.ibm.au.bgx.model.exception;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */

import java.math.BigInteger;

/**
 * Class <b>GuaranteeChainException</b>. This class extends {@link RuntimeException} and it is
 * used to identify all the errors that occur while operating with bank guarantees functions.
 * 
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
public class GuaranteeException extends RuntimeException {

    /**
     * A {@link Long} value used to discriminate among different instances that
     * have the same class name (but may not be the same) during serialization.
     */
    private static final long serialVersionUID = -8687036006473795312L;
    

    /**
     * A {@link BigInteger} instance containing the unique identifier of the
     * cause of the error represented by this exception.
     */
    private BigInteger code;

    /**
     * Constructs a new exception with the specified detail message. The cause
     * is not initialized, and may subsequently be initialized by a call to
     * {@link #initCause}.
     *
     * @param message    the detail message. The detail message is saved for later
     *            		retrieval by the {@link #getMessage()} method.
     */
    public GuaranteeException(String message) {
        this(message, BigInteger.ZERO, null);
    }

    /**
     * Constructs a new exception with the specified cause and a detail message
     * of <tt>(cause==null ? null : cause.toString())</tt> (which typically
     * contains the class and detail message of <tt>cause</tt>).
     *
     * @param cause     the cause (which is saved for later retrieval by the
     *            		{@link #getCause()} method). (A <tt>null</tt> value is
     *            		permitted, and indicates that the cause is nonexistent or
     *            		unknown.)
     */
    public GuaranteeException(Throwable cause) {
        this(null, BigInteger.ZERO, cause);
    }

    /**
     * Constructs a new {@link GuaranteeException} with the specified detail message 
     * and cause.
     *
     * @param message   the detail message (which is saved for later retrieval by the
     *            		{@link #getMessage()} method).
     *
     * @param cause     the cause (which is saved for later retrieval by the
     *            		{@link #getCause()} method). (A <tt>null</tt> value is
     *            		permitted, and indicates that the cause is nonexistent or
     *            		unknown.)
     */
    public GuaranteeException(String message, Throwable cause) {
        this(message, BigInteger.ZERO, cause);
    }
    

    /**
     * Constructs a new {@link GuaranteeException} with the given <i>message</i>, 
     * <i>cause</i> and error <i>code</i>.
     * 
     * @param message   the detail message (which is saved for later retrieval by the
     *            		{@link #getMessage()} method).
     *            
     * @param code		a {@link BigInteger} value that indicates the specific error
     * 					code associated to the cause of this exception. It cannot be
     * 					{@literal null}.
     *
     * @param cause     the cause (which is saved for later retrieval by the
     *            		{@link #getCause()} method). (A <tt>null</tt> value is
     *            		permitted, and indicates that the cause is nonexistent or
     *            		unknown.)
     *            
     *  @throws IllegalArgumentException	if <i>code</i> is {@literal null}.
     */
    public GuaranteeException(String message, BigInteger code, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    /**
     * Gets the error code that provides a reference for the cause of this
     * exception. 
     * 
     * @return	a {@link BigInteger} instance representing the error code.
     */
    public BigInteger getCode() {
        return this.code;
    }
}
