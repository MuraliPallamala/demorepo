package com.ibm.au.bgx.model.approvalmodel;

import com.ibm.au.bgx.model.api.exceptions.ApiForbiddenException;
import com.ibm.au.bgx.model.api.exceptions.ApiRecordNotFoundException;
import com.ibm.au.bgx.model.exception.GuaranteeException;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.exception.GuaranteeNotFoundException;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowResponse;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.pojo.chain.FlowStatus;

import java.io.IOException;
import java.util.List;

/**
 * 
 * @author Dain Liffman
 *
 */
public interface ApprovalModel {
	/**
	 * 
	 * @return
	 * @throws IOException
	 */
    ApprovalModelInfo getApprovalModelInfo() throws IOException;

    /**
     * 
     * @param actionRequest
     * @return
     * @throws ApiForbiddenException
     * @throws GuaranteeException
     * @throws GuaranteeForbiddenException
     * @throws GuaranteeNotFoundException
     * @throws IOException
     */
    ApprovalModelFlowResponse performAction(ApprovalModelFlowRequest actionRequest) throws ApiForbiddenException, GuaranteeException, GuaranteeForbiddenException, GuaranteeNotFoundException, IOException;

    /**
     * 
     * @param flowId
     * @return
     * @throws ApiRecordNotFoundException
     */
    ApprovalModelFlowRequest getApprovalFlow(String flowId) throws ApiRecordNotFoundException;

    /**
     * 
     * @param gxRequestId
     * @param gxId
     * @param status
     * @return
     */
    List<ApprovalModelFlowRequest> getApprovalFlows(String gxRequestId, String gxId, FlowStatus status);
}
