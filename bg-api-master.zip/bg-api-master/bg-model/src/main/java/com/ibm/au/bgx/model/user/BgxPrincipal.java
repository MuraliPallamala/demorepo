package com.ibm.au.bgx.model.user;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.GxPrefillRequestManager;
import com.ibm.au.bgx.model.RequestManager;
import com.ibm.au.bgx.model.Spawnable;
import com.ibm.au.bgx.model.approvalmodel.ApprovalModel;
import com.ibm.au.bgx.model.chain.gx.GxManager;
import com.ibm.au.bgx.model.chain.profile.OrgChangeRequestManager;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.UserProfile;
import java.math.BigInteger;
import java.util.List;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Interface <b>BgxPrincipal</b>. This interface represents the identity that is associated
 * to a client request to the Bank Guarantee APIs. The interface extends {@link UserDetails},
 * {@link Authentication} and {@link Spawnable}, thus concentrating capabilities for:
 * <ul>
 * <li>providing information about the current logged in user</li>
 * <li>providing the security details associated to the identifier</li>
 * <li>impersonating another organisation within the context of a parent-sub relationship</li>
 * </ul>
 * This implementation of the principal exposes several utility methods aimed at extracting
 * the characteristics of the user and its role within the organisation, as well as the type
 * of the organisation he/she belongs to, thus facilitating the implementation of the downstream
 * business logic.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface BgxPrincipal extends UserDetails, Authentication, Spawnable<BgxPrincipal> {

	/**
	 * Gets the email of the user. This is unique within the context of the organisation the
	 * user belongs to. The same email can be re-used across organisations, thus representing
	 * two distinct user records.
	 * 
	 * @return 	a {@link String} representing the email of the user. It is guaranteed to be not 
	 * 			{@literal null} as the email is a required attribute for the user.
	 *      
	 */
    String getEmail();

    /**
     * Gets the unique identifier of the primary organisation of the user. The primary organisation
     * of a user is the organisation in which the user has been originally onboarded in. For most
     * of the cases this coincides with the organisations the user acts within. It only differ from
     * it in the case of a parent-subsidiary relationship where a user can be acting on behalf of a
     * subsidiary organisation and be bound to an organisation that differs from its primary organisation.
     * 
     * @return	a {@link String} represeting the unique identifier of the organisation the user was
     * 			originally onboarded into. This is guaranteed to not to be {@literal null} as every
     * 			user exist within the context of an organisation.
     */
    String getPrimaryOrgId();

    /**
     * Gets the details of the user, in particular its profile information.
     * 
     * @return	a {@link UserProfile} instance containing the details and configuration settings for
     * 			the user. It is guaranteed to not to be {@literal null} as every user has an associated
     * 			profile.
     */
    UserProfile getUserProfile();

    /**
     * <p>
     * Gets the details of the organisation that the principal is currently bound to.
     * </p>
     * <p>
     * Implementations must take into account the parent-subsidiary relationships among organisations
     * and the context in which the principal identity is acting. In the scenario where the principal
     * identity is impersonating a user of a subsidiary organisation, the details of such organisation
     * must be returned.
     * </p>
     * 
     * @return	a {@link Organization} instance containing the profile and configuration settings of the
     * 			organisation the user has been onboarded into. If the principal is not {@literal null}
     * 			and it has an associated identity, this reference is guaranteed to not to be {@literal 
     * 			null}.
     */
    Organization getOrganization();

    /**
     * <p>
     * Provides access to the organisation change request management capabilities for organisations, such
     * as update of organisation's public details and management of parent-subsidiary link requests.
     * </p>
     * <p>
     * This implementation is used differently according to the vertical bound to the execution context.
     * In the administrative vertical it is primarily used for its administrative functions to approve
     * requests, while in the other verticals it is primarily used to manage the organisation updates
     * of the primary organisation of the identity of the principal.
     * </p>
     * 
     * @return	an implementation of {@link OrgChangeRequestManager}, it cannot be {@literal null}.
     */
    OrgChangeRequestManager getOrgChangeRequestManager();

    /**
     * <p>
     * Provides access to the request management capabilities for the organisation bound to the identity
     * of the principal in the current execution context. The request manager provides aggregated view
     * of both approval model and external guarantee requests and acts as single access point for bank
     * guarantee request management.
     * </p>
     * <p>
     * Implementation must take into account the context in which the principal identity is operating,
     * and if such identity operates in an organisation that it is not its primary organisation the
     * instance of the {@link RequestManager} that is returned, needs to be properly configured to
     * retrieve the appropriate requests.
     * </p>
     * 
     * @return	a {@link RequestManager} implementation.
     */
    RequestManager getRequestManager();

    /**
     * <p>
     * Returns the approval model that is set for the organisation that the current principal is acting
     * within the context of.
     * </p>
     * <p>
     * The approval model governs the internal workflows that exist within the boundary of an organisation
     * to execute the business processes associated to bank guarantees an bank guarantes requests.
     * </p>
     * <p>
     * Implementations must take into account that in case the principal identity is impersonating another
     * organisation than its primary organisation, the approval model of the impersonated organisation must
     * be returned.
     * </p>
     * 
     * @return	a {@link ApprovalModel} instance that describes the workflows of the organisation. If the
     * 			principal identity is acting within the context of another organisation, the approval model
     * 			of that organisation must be returned, otherwise the approval model of the primary organisation
     * 			bound to the identity is returned. It can be {@literal null} if the approval model in the
     * 			organisation has not been set.
     */
    ApprovalModel getApprovalModel();

    /**
     * <p>
     * Returns an instance of the guarantee manager that can be used to manage the guarantees accessible
     * to the current identity.
     * </p>
     * <p>
     * The guarantee manager is the main access point for managing bank guarantees, this component is
     * sensitive to the execution context in which is invoked. Implementations must take into account
     * both the vertical bound to the execution context, and whether the current identity is acting on
     * behalf of another organisation. In particular:
     * <ul>
     * <li>a principal associated to the <i>admin</i> vertical should not provide access to guarantee data</li>
     * <li>a principal associated to the <i>issuer</i> vertical should be configured with a guarantee manager
     * that provides access only to the guarantees in the specific issuer channel</li>
     * <li>a principal associated to the <i>user</i> vertical should be configured with a guarantee manager
     * able to access all the guarantee channels and those guarantees that are associated to the organisation
     * that the identity is acting in the context of.
     * </ul>
     * </p>
     * 
     * @return	a {@link GxManager} implementation that provides access to the guarantees accessible to
     * 			the principal identity in the current execution context, or {@literal null} if the current
     * 			execution context does not have access to guarantee data.
     */
    GxManager getGxManager();

    /**
     * <p>
     * Provides access to the pre-filling capabilities of bank-guarantee request. Pre-filling is an operation that
     * is performed by issuer organisations to facilitate the submission of requests eventually made by applicants
     * that are their customers. As a result the pre-filling capability is primarily needed in the issuer vertical,
     * where in the user vertical it is only used by applicants to retrieve such requests and submit a real bank
     * guarantee request. No use of this interface is made by the administrative vertical.
     * </p>
     * 
     * @return	an instance of {@link GxPrefillRequestManager}, it can be {@literal null} if it is not required.
     */
    GxPrefillRequestManager getGxPrefillRequestManager();

    /**
     * <p>
     * Determines whether the user associated to the identity of the principal
     * is has the given role in the specified organisation.
     * </p>
     * <p>
     * While users are naturally segregated within a single organisation, parent-
     * subsidiary relationship allow users to have a different set of roles for 
     * different organisations, more precisely a user of a parent organisation, 
     * may have roles defined in each of subsidiary organisation, thus generating 
     * the need to query for roles in a specific organisation.
     * </p>
     * <p>
     * This method can be considered the basic building block for implementing the
     * following methods:
     * <ul>
     * <li>{@link BgxPrincipal#hasRoles(String, List)}</li>
     * <li>{@link BgxPrincipal#isAdmin()}</li>
     * <li>{@link BgxPrincipal#isAdminForOrg(String)}</li>
     * </ul>
     * </p>
     * 
     * @param orgId	a {@link String} representing the unique identifier of the
     * 				organisation where the principal has may have roles assigned.
     * 				It cannot be {@literal null} or an empty string.
     * 
     * @param role	a {@link String} representing the name of the role to verify.
     * 				It cannot be {@literal null} or an empty string.
     * 
     * @return	{@literal true} if the current principal has the specified role
     * 			in the organisation identified by <i>orgId</i> or {@literal false}
     * 			otherwise.
     * 
     * @throws IllegalArgumentException if one of the following occurs:
     * 									<ul>
     * 									<li><i>orgId</i> is {@literal null} or an empty string</li>
     * 									<li><i>orgId</i> does not map any existing organisation</li>
     * 									<li><i>role</i> is {@literal null} or an empty string</li>
     * 									</ul>
     */
    // [CV] TODO: enforce constraints on arguments in implementations (!= null, not-empty) -> IllegalArgumentException
    boolean hasRole(String orgId, String role);

    /**
     * <p>
     * Determines whether the identity associated to the principal has all the
     * specified roles in the organisation specified by <i>orgId</i>.
     * </p>
     * <p>
     * This method is the overloaded version of {@link BgxPrincipal#hasRole(String, 
     * String)} that can be used to check for a list of roles to be present rather
     * than a single role.
     * </p>
     * 
     * 
     * @param orgId	a {@link String} representing the unique identifier of the
     * 				organisation where the principal has may have roles assigned.
     * 				It cannot be {@literal null} or an empty string.
     * 
     * @param roles	a {@link List} implementation that contains the list of roles
     * 				that need to be checked. It cannot be {@literal null} or
     * 				contain {@literal null} or empty values.
     * 
     * 
     * @return	{@literal true} if the identity associated the principal has
     * 			all the specified roles in the organisation identified by 
     * 			<i>orgId</i>, {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException if one of the following occurs:
     * 									<ul>
     * 									<li><i>orgId</i> is {@literal null} or an empty string</li>
     * 									<li><i>orgId</i> does not map any existing organisation</li>
     * 									<li><i>roles</i> is {@literal null}</li>
     * 									<li><i>roles</i> contains {@literal null} or empty values</li>
     * 									</ul>
     * 
     * @see BgxPrincipal#hasRole(String, String)
     */
    // [CV] TODO: enforce constraints on argument in implementations (!= null, not-empty) -> IllegalArgumentException
    boolean hasRoles(String orgId, List<String> roles);

    /**
     * <p>
     * Determines whether the user associated to the identity of the principal
     * is an administrator in its primary organisation. If this method returns
     * {@literal true}, this means that the list of roles attached the user
     * profile of the user includes {@link BgxConstants#ROLE_ADMIN} for the
     * primary organisation of the user.
     * </p>
     * <p>
     * This method is semantically equivalent to:
     * <ul>
     * <li>{@link #hasRole(String, String)} invoked with arguments equal to
     * {@link #getPrimaryOrgId()} and {@link  BgxConstants#ROLE_ADMIN}</li>
     * <li>{@link #isAdminForOrg(String)} invoked with argument equal to
     * {@link  #getPrimaryOrgId()}</li>
     * </ul>
     * 
     * @return	{@literal true} if the principal maps an administrator of the
     * 			organisation it was originally onboarded into, {@literal false}
     * 			otherwise.
     * 
     * @see BgxPrincipal#hasRole(String, String)
     * @see BgxPrincipal#isAdminForOrg(String)
     */
    boolean isAdmin();

    /**
     * <p>
     * Determines whether the user has an administrative role in the organisation
     * identified by <i>orgId</i>. 
     * </p>
     * <p>
     * Implementations must respect the equivalence of semantics between this method
     * and an invocation to {@link #hasRole(String, String)} where the first argument
     * passed is <i>orgId</i> and the second argument is {@link BgxConstants#ROLE_ADMIN}.
     * </p>
     * 
     * @param orgId	a {@link String} representing the unique identifier of the
     * 				organisation where the principal has may have roles assigned.
     * 				It cannot be {@literal null} or an empty string.
     * 
     * @return	{@literal true} whether the identity associated to the current principal
     * 			is administrator for the organisation identified by <i>orgId</i>, {@literal 
     * 			false} if not.
     * 
     * @throws IllegalArgumentException if one of the following occurs:
     * 									<ul>
     * 									<li><i>orgId</i> is {@literal null} or an empty string</li>
     * 									<li><i>orgId</i> does not map any existing organisation</li>
     * 									</ul>
     * 
     * @see BgxPrincipal#hasRole(String, String)
     * @see BgxPrincipal#isAdmin()
     * 
     */
    // [CV] TODO: enforce constraints on argument in implementations (!= null, not-empty) -> IllegalArgumentException
    boolean isAdminForOrg(String orgId);

    /**
     * <p>
     * Determines whether the identity associated to the principal is a user of the
     * consortium organisation. The consortium organisation is the one representing 
     * the administrative vertical of the platform.
     * </p>
     * <p>
     * Implementation must respect the semantic equivalence between this method and
     * {@link BgxPrincipal#isUserOfOrgType(EntityType)} when invoked with the value
     * {@link EntityType#CONSORTIUM}.
     * </p>
     * 
     * @return	{@literal true} if the user belongs to the consortium organisation,
     * 			{@literal false} otherwise.
     * 
     * @see BgxPrincipal#isUserOfOrgType(EntityType)
     * @see BgxPrincipal#isConsortiumAdminUser()
     */
    boolean isConsortiumUser();

    /**
     * <p>
     * Determines whether the identity associated to the principal is an administrative
     * user of the consortium organisation. The consortium organisation is the one representing 
     * the administrative vertical of the platform.
     * </p>
     * <p>
     * Implementation must respect the semantic equivalence between this method and the
     * joint invocation (i.e. in logical AND) of the following methods:
     * <ul>
     * <li>{@link #isAdmin()}</li>
     * <li>{@link #isConsortiumUser()}</li>
     * </ul>
     * Moreover, if {@link #isConsortiumAdminUser()} returns {@literal true}, then {@link 
     * #isConsortiumUser()} must return {@literal true}.
     * </p>
     * 
     * @return	{@literal true} if the user is an administrator of the consortium organisation,
     * 			{@literal false} otherwise.
     * 
     * @see BgxPrincipal#isAdmin()
     * @see BgxPrincipal#isConsortiumUser()
     */
    boolean isConsortiumAdminUser();

    /**
     * <p>
     * Determines whether the identity associated to the principal is a user of a specific
     * type of organisation (i.e. issuer, applicant/beneficiary, consortium).
     * </p>
     * <p>
     * Verification is carried against the primary organisation of the user, which is the
     * organisation in which the user was originally onboarded into.
     * </p>
     * 
     * @param entityType	a {@link EntityType} value specifying the type of organisation
     * 						that need to be checked for the primary organisation of the user.
     * 						It cannot be {@literal null}.
     * 
     * @return	{@literal true} if the primary organisation of the user is of the type specified
     * 			by <i>entityType</i>, {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException		if <i>entityType</i> is {@literal null}.
     */
    // [CV] TODO: enforce the constraints on argument (!= null) --> IllegalArgumentException
    boolean isUserOfOrgType(EntityType entityType);

    /**
     * <p>
     * Determines whether the current principal is configured to act on behalf of any organisation.
     * In other words, determines whether the principal is impersonating the identity of a user in
     * an organisation different from its primary organisation.
     * </p>
     * <p>
     * Acting on behalf or organisation impersonation is the technique that allows the users of a
     * parent organisation, to operate (with the defined roles) in the context of a subsidiary organisation.
     * This is done by retaining the profile of the original user, but switching the organisation that is
     * connected to the subsidiary organisation. The set of roles that the user has defined in the subsidiary
     * organisation will determine the actions that can be done during the impersonation.
     * </p>
     * 
     * @return	{@literal true} if the principal is acting on behalf of another organisation, {@literal 
     * 			false} otherwise.
     * 
     * @see BgxPrincipal#isActingOnBehalf(String)
     */
    boolean isActingOnBehalf();

    /**
     * <p>
     * Determines whether the current principal is configured to act on behalf of the specified
     * organisation. In other words, determines whether the principal is impersonating the identity 
     * of a user in the organisation identified by <i>targetOrgId</i>.
     * </p>
     * <p>
     * Implementations must respect the following semantic relationship: if this method returns
     * {@literal true} for a given <i>targetOrgId</i>, within the same execution context then the
     * value returned by {@link #isActingOnBehalf()} must return {@literal true}.
     * </p>
     * 
     * @param targetOrgId 	a {@link String} representing the unique identifier of the organisation
     * 						that the user is verified to act on behalf of. It cannot be {@literal 
     * 						null} or an empty string.
     * 
     * @return	{@literal true} if the principal is acting on behalf of the organisation identified
     * 			by <i>targetOrgId</i>, {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException if one of the following occurs:
     * 									<ul>
     * 									<li><i>orgId</i> is {@literal null} or an empty string</li>
     * 									<li><i>orgId</i> does not map any existing organisation</li>
     * 									</ul>
     * 
     */
    // [CV] TODO: enforce constraints on argument on implementations (!= null, not-empty, not existing) --> IllegalArgumentException
    boolean isActingOnBehalf(String targetOrgId);

    /**
     * <p>
     * Retrieves the relationship information between the organisation of identity associated to the
     * current principal, and the organisation that is identified by <i>targetOrgId</i>.
     * </p>
     * <p>
     * The value returned by this method is not {@literal null} if the organisation associated to the
     * identity of the principal is in a parent-subsidiary relationship with the specified organisation.
     * </p>
     * 
     * @param targetOrgId	a {@link String} representing the unique identifier of the organisation
     * 						that is checked for relationships. It cannot be {@literal null} or an
     * 						empty string.
     * 
     * @return	a {@link RelationshipInfo} instance if the organisation associated to the identity of
     * 			the principal is in a relationship with the specified organisation, {@literal null}
     * 			otherwise.
     * 
     * @throws IllegalArgumentException	if <i>targetOrgId</i> is {@literal null} or an empty string.
     * 
     */
    // [CV] TODO: enforce constraints on argument on implementations (!= null, not-empty) --> IllegalArgumentException
    RelationshipInfo getRelationshipFor(String targetOrgId);

    /**
     * <p>
     * Get the user id of the Blockchain identity associated to the organisation the identity is 
     * currently acting for.
     * </p>
     * <p>
     * This method is context sensitive and implementations must taken into account of the context
     * in which the identity is operating. In the case of an existing parent-subsidiary relationship
     * where the current identity is acting on behalf of one of the subsidiary organisations, this
     * method should return the Blockchain identity created to transact on behalf of that subsidiary
     * rather than the original Blockchain identity associated to the primary organisation.
     * </p>
     * <p>
     * Implementations must respect the semantic relationship between this method and the methods
     * {@link #isActingOnBehalf()} and {@link #isActingOnBehalf(String)}:
     * <ul>
     * <li>if the value returned by {@link #isActingOnBehalf()} is {@literal false}, within the same 
     * execution context then the value returned by this method is the user id of the Blockchain 
     * identity associated to the primary organisation of the user.</li>
     * <li>if the value returned by {@link #isActingOnBehalf(String)} is {@literal true} for a given
     * organisation identifier, within the same session, this method must return the user id of the
     * Blockchain identity allocated in the principal organisation, to impersonate a user of that
     * organisation.</li>
     * </ul>
     * </p>
     * 
     * @return	the user identifier of the Blockchain identity associated to the primary organisation
     * 			of the principal if the principal is operating the context of its own organisation, or
     * 			the user identifier of the Blockchain identity allocated for a subsidiary if the
     * 			principal is acting on behalf of that subsidiary. It is guaranteed to not to be {@literal 
     * 			null}.
     */
    String getChannelUserName();

    /**
     * <p>
     * Returns the bank guarantee limit that the identity of the current principal has while operating within
     * the context of its primary organisation.
     * </p>
     * <p>
     * Bank guarantee limits are constraints on the operating capability of a user with regards to the bank
     * guarantees such user has access to. Essentially, if a value for the limit is set, the user can only
     * operate on bank guarantees that have amounts smaller than the limit.
     * </p>
     * <p>
     * Implementations must respect the semantic equivalence between this method and {@link #getGxLimit(String)}
     * when invoked with the unique identifier of the primary organisation of the principal.
     * </p>
     * 
     * @return	a {@link BigInteger} instance representing the value of the bank guarantee limit that the user
     * 			has when operating within the context of its primary organisation, or {@link BigInteger#ZERO} 
     * 			if there is no limit.
     */
    BigInteger getGxLimit();

    /**
     * <p>
     * Returns the bank guarantee limit that the identity of the current principal has while operating within
     * the context of the organisation identified by <i>orgId</i>.  
     * </p>
     * <p>
     * Bank guarantee limits are constraints on the operating capability of a user with regards to the bank
     * guarantees such user has access to. Essentially, if a value for the limit is set, the user can only
     * operate on bank guarantees that have amounts smaller than the limit.
     * </p>
     * 
     * @param orgId		a {@link String} representing the identifier of the organisation for which the bank
     * 					guarantee limits is requested. It cannot be {@literal null} or an empty string.
     * 
     * @return	a {@link BigInteger} instance representing the value of the bank guarantee limit that the user
     * 			has when operating on behalf of the organisation represented by <i>orgId</i>, or {@link 
     * 			BigInteger#ZERO} if there is no limit.
     * 
     * 
     * @throw IllegalArgumentException	if <i>orgId</i> is {@literal null} or an empty string.
     */
    // CV] TODO: enforce constraints on argument on implementations (!= null, not-empty, not existing) --> IllegalArgumentException
    BigInteger getGxLimit(String orgId);
}
