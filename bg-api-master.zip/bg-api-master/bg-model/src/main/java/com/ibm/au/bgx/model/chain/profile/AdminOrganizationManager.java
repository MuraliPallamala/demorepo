package com.ibm.au.bgx.model.chain.profile;

import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.exception.IdentityProviderException;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.Organization;
import java.util.Map;

/**
 * Interface <b>AdminOrganizationManager</b>. This interface extends {@link OrganizationManager} and provides
 * additional capabilities that are specifically required by the administrative vertical such as supporting the
 * ability of bootstrapping organisation in the platform, or configure their identity provider settings.
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public interface AdminOrganizationManager extends OrganizationManager {

	/**
	 * This method creates an organization in the ledger as part of the bootstrap process. This 
	 * method is used internally to automatically bootstrap organisations such as NewCo Admin,
	 * NewCo and the registered issuers.
     * 
     * @param profileRequest	a {@link OrgProfileRequest} instance that contains information about the 
     * 							organization to bootstrap. It cannot be {@literal null}.
     * @param adminCert			a {@link String} containing the certificate of the administrator that is
     * 							used to create the organization profile in the ledger. It is expected to
     * 							not to be {@literal null} or an empty string.
     * @param forceReconnect	a {@literal boolean} indicating whether the method should reconnect in case
     * 							of network disconnection.
     * 
     * @return an {@link Organization} instance that represents the organization that has been bootstrapped.
     * 
     * 
     * @throws IllegalArgumentException	if there already exist an organization profile with the same identifier 
     * 									or the same business identifier.
     * 
     * @throws ProfileChainException	if there is any error with the interaction with the ledger to lookup 
     * 									profiles
     * 							
     * @throws ProfileCreateException	if there is any error during the creation of organisation profile in 
     * 									the ledger. 
	 */
	Organization bootstrap(OrgProfileRequest profileRequest, String adminCert, boolean forceReconnect) throws ProfileCreateException, ProfileChainException;
	
    

    /**
     * This method configures the organisation with the default identity provider. As part of the organisation creation process in the
     * platform a security realm needs to be configured in order for the organisation users to be able to authenticate and login within
     * the platform and operates as recognised users of a specific organisation. This method sets up such security realm.
     * 
     * @param organization				an {@link Organization} instance that needs to be configured with the identity provider. It cannot
     * 									be {@literal null}.
     * 
     * @param config					a {@link Map} implementation that contains the configuration settings for the identity provider.
     * 									While the set of keys in this map may depend on the specific implementation of the identity provider
     * 									being used, this map should at least contain {@link BgxConstants#BOOTSTRAP_USER_REDIRECT_URI_LIST}
     * 									which needs to be set to the redirect url that needs to be contacted once authentication of a user
     * 									for this specific organisation is completed. It cannot be {@literal null}.
     * 
     * @param bootstrapPortalClient		a {@literal boolean} value indicating whether the initialisation process also needs to configure
     * 									an OpenID client for the portal (i.e. {@literal true}) or not (i.e. {@literal false}).
     * 
     * @param bootstrapApiClient		a {@literal boolean} value indicating whether the initialisation process also needs to configure the
     * 									OpenID client for API-to-API communication (i.e. {@literal true}) or not (i.e. {@literal false}).
     * 
     * @param bootstrapUsers			a {@literal boolean} value indicating whether the initialisation process also needs to initialise
     * 									the users that are defined in the contact list of the organisation profile associated to the 
     * 									organization.
     * 
     * @return	an {@link Organization} instance that is updated with the identity provider configuration as specified by the method arguments. 
     * 			It is guaranteed to not to be {@literal null}.	
     * 
     * @throws IdentityProviderException	if there is any error occurring while interacting the default identity provider, while creating
     * 										the security realm, configuring the client, or creating the users.
     * 
     * @throws IllegalArgumentException		if one of the following occurs:
     * 										<ul>
     * 										<li><i>organization</i> is {@literal null}</li>
     * 										<li><i>config</i> is {@literal null}</li>
     * 										</ul>
     */
    Organization prepareIdentityProvider(Organization organization, Map<String, Object> config, boolean bootstrapPortalClient, boolean bootstrapApiClient, boolean bootstrapUsers) throws IdentityProviderException;

}
