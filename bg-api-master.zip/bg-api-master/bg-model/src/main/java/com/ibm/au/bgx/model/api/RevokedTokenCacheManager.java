package com.ibm.au.bgx.model.api;

/**
 * Manager for the cache of revoked tokens.
 * 
 * @author brunomar
 *
 */
public interface RevokedTokenCacheManager {

	/**
	 * 
	 * @param item
	 * @return
	 */
    boolean tokenExists(String item);

    /**
     * 
     * @param authToken
     * @param expirationInMilliseconds
     */
    void addToken(String authToken, Long expirationInMilliseconds);

    /**
     * 
     * @param authToken
     */
    void removeToken(String authToken);

    /**
     * 
     */
    void cleanUpExpired();

}
