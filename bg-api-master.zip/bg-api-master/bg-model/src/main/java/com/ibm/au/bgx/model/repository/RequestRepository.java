package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.Request;
import java.util.List;

/**
 *
 */
public interface RequestRepository extends DefaultRepository<Request> {

	/**
	 * 
	 * @param orgId
	 * @param guaranteeId
	 * @param status
	 * @return
	 */
    List<Request> find(String orgId, String guaranteeId, String status);
}
