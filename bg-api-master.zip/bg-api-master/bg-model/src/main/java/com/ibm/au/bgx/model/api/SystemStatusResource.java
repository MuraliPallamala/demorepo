package com.ibm.au.bgx.model.api;

/**
 * @author Peter Ilfrich <peter.ilfrich@au1.ibm.com>
 */
public interface SystemStatusResource {

    void setLive(boolean liveState);

    /**
     * This flag will turn true, once all Spring components were started.
     * 
     * @return
     */
    boolean isLive();

    /**
     * This flag will turn true, once all bank-guarantees bootstrap procedures are completed.
     * 
     * @return
     */
    boolean isReady();

    /**
     * 
     * @param componentIdentifier
     */
    void registerComponent(String componentIdentifier);

    /**
     * 
     * @param componentIdentifier
     */
    void setComponentReady(String componentIdentifier);

    /**
     * 
     * @return
     */
    int getTotalReady();
}
