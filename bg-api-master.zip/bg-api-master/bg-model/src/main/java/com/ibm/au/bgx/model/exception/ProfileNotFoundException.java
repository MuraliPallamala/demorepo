package com.ibm.au.bgx.model.exception;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


/**
 * Class <b>ProfileNotFoundException</b>. 
 * 
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public class ProfileNotFoundException extends Exception {


	/**
	 * A {@link Long} value used to discriminate among different instances that
	 * have the same class name (but may not be the same) during serialization.
	 */
	private static final long serialVersionUID = -1626309290620681438L;

	/**
	 * Constructs a new exception with the specified detail message. The cause
	 * is not initialized, and may subsequently be initialized by a call to
	 * {@link #initCause}.
	 *
	 * @param message	the detail message. The detail message is saved for later
	 *            		retrieval by the {@link #getMessage()} method.
	 */
	public ProfileNotFoundException(String message) {
		super(message, null);
	}

	/**
	 * Constructs a new exception with the specified cause and a detail message
	 * of <tt>(cause==null ? null : cause.toString())</tt> (which typically
	 * contains the class and detail message of <tt>cause</tt>). 
	 *
	 * @param cause 	the cause (which is saved for later retrieval by the
	 *            		{@link #getCause()} method). (A <tt>null</tt> value is
	 *            		permitted, and indicates that the cause is nonexistent or
	 *            		unknown.)
	 */
	public ProfileNotFoundException(Throwable cause) {
		this(null, cause);
	}

	/**
	 * Constructs a new exception with the specified detail message and cause.
	 * <p>
	 * Note that the detail message associated with {@code cause} is <i>not</i>
	 * automatically incorporated in this exception's detail message.
	 *
	 * @param message 	the detail message (which is saved for later retrieval by the
	 *            		{@link #getMessage()} method).
	 *
	 * @param cause		the cause (which is saved for later retrieval by the
	 *            		{@link #getCause()} method). (A <tt>null</tt> value is
	 *            		permitted, and indicates that the cause is nonexistent or
	 *            		unknown.)
	 */
	public ProfileNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}


}
