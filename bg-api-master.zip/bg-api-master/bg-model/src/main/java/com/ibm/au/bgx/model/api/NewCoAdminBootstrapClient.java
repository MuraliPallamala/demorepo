package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.pojo.api.request.BootstrapRequest;
import com.ibm.au.bgx.model.pojo.api.response.BootstrapResponse;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface NewCoAdminBootstrapClient {

	/**
	 * 
	 * @param request
	 * @return
	 * @throws ProfileCreateException
	 * @throws ServiceUnavailableException
	 */
    BootstrapResponse bootstrap(BootstrapRequest request) throws ProfileCreateException, ServiceUnavailableException;
}
