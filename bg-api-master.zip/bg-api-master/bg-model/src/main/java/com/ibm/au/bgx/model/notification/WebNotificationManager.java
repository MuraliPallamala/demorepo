package com.ibm.au.bgx.model.notification;

import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.chain.FlowAction;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxIssuePayload;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxTransferPayload;
import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import com.ibm.au.bgx.model.shared.Flow;
import com.ibm.au.bgx.model.user.BgxPrincipal;


/**
 * Manager interface for web notification. This interface provides method signatures related to
 * creating notifications, populating notification payload, updating notifications and retrieving
 * notifications.
 *
 * @author Peter Ilfrich
 */
public interface WebNotificationManager {

    /**
     * Payload parameter which stores the entity name of an organisation
     */
    String PAYLOAD_ENTITY_NAME = "entityName";
    /**
     * Payload parameter which stores the ABN/ACN of an organisation
     */
    String PAYLOAD_BUSINESS_ID = "businessId";
    /**
     * Payload parameter which stores a bank reference of a guarantee
     */
    String PAYLOAD_BANK_REFERENCE = "bankReference";
    /**
     * Payload parameter which stores the id of a guarantee
     */
    String PAYLOAD_GX_ID = "gxId";
    /**
     * Payload parameter which stores a new GX id when the normal GX ID is already used.
     */
    String PAYLOAD_NEW_GX_ID = "newGxId";
    /**
     * Payload parameter identifying outstanding amount of a GX
     */
    String PAYLOAD_OUTSTANDING_AMOUNT = "outstandingAmount";
    /**
     * Payload parameter providing the issuer organisation name for a gx
     */
    String PAYLOAD_ISSUER_ENTITY_NAME = "issuerEntityName";
    /**
     * Payload parameter providing the applicants organisation name for a gx
     */
    String PAYLOAD_APPLICANT_ENTITY_NAME = "applicantEntityName";
    /**
     * Payload parameter providing the beneficiaries organisation name for a gx
     */
    String PAYLOAD_BENEFICIARY_ENTITY_NAME = "beneficiaryEntityName";
    /**
     * Payload parameter providing the id of a new beneficiary in case of transfer GX
     */
    String PAYLOAD_OLD_BENE_ID = "oldBeneficiaryId";
    /**
     * Payload parameter providing the id of the old beneficiary in case of transfer GX
     */
    String PAYLOAD_NEW_BENE_ID = "newBeneficiaryId";
    /**
     * Payload parameter providing the name of the old beneficiary in case of transfer GX
     */
    String PAYLOAD_OLD_BENE_ENTITY_NAME = "oldBeneficiaryEntityName";
    /**
     * Payload parameter providing the name of the new beneficiary in case of transfer GX
     */
    String PAYLOAD_NEW_BENE_ENTITY_NAME = "newBeneficiaryEntityName";
    /**
     * Payload parameter providing a reason for a rejection (gx or onboarding or org change)
     */
    String PAYLOAD_REJECT_REASON = "reason";
    /**
     * Payload parameter providing the name of the organisation that initiated something
     */
    String PAYLOAD_INITIATOR_ENTITY_NAME = "initiatorEntityName";
    /**
     * Payload parameter providing the id of a subsidiary organisation
     */
    String PAYLOAD_SUBSIDIARY_ID = "subsidiaryId";
    /**
     * Payload parameter providing the first name of a person
     */
    String PAYLOAD_USER_FIRSTNAME = "firstName";
    /**
     * Payload parameter providing the last name of a person
     */
    String PAYLOAD_USER_LASTNAME = "lastName";
    /**
     * Payload parameter providing the phone number of a person
     */
    String PAYLOAD_USER_PHONE = "phone";
    /**
     * Payload parameter providing the email address of a person
     */
    String PAYLOAD_USER_EMAIL = "email";
    /**
     * Payload parameter providing the type of link (PARENT/SUB)
     */
    String PAYLOAD_LINK_TYPE = "linkType";
    /**
     * Payload parameter to store a user profile under
     */
    String PAYLOAD_USER = "user";
    /**
     * Payload parameter to store an organisation profile under
     */
    String PAYLOAD_ORG = "org";
    /**
     * Payload parameter to store a subisdiary organisation profile under
     */
    String PAYLOAD_SUBSIDIARY_ORG = "subsidiaryOrg";
    /**
     * Payload parameter storing a list of roles that have been added
     */
    String PAYLOAD_ROLES_ADD = "rolesAdded";
    /**
     * Payload parameter storing a list of roles that have been removed
     */
    String PAYLOAD_ROLES_REMOVE = "rolesRemoved";

    /**
     * Marks notifications as done for a specific principal and a specific reference (object ID)
     *
     * @param principal - the principal for to clear notifications
     * @param referenceId - the id of the object for which to clear notifications
     */
    void markActionsDone(BgxPrincipal principal, String referenceId);

    /**
     * Marks notifications as done for a specific organisation and a specific reference (object ID)
     *
     * @param orgId       - the id of the organisation for which to clear notifications
     * @param referenceId - the id of the object for which to clear notifications
     */
    void markActionsDone(String orgId, String referenceId);

    /**
     * Marks notifications as done for a specific reference (object ID)
     *
     * @param referenceId - the id of the object for which to clear notifications
     */
    void markActionsDone(String referenceId);

    /**
     * Marks notifications as done for a specific organisation and a specific type of notification.
     *
     * @param orgId       - the id of the organisation for which to clear notifications
     * @param messageType - the type of notifications to clear
     */
    void markActionsDone(String orgId, WebNotification.MessageType messageType);

    /**
     * This will fetch the first user it can find for a specific organisation and duplicate any of
     * the notifications for that found user and store them for the provided user, which is a newly
     * onboarded user.
     *
     * @param orgWithNotifications - the organisation the user joined and from which to retrieve a
     *                             template user
     * @param newOrgUser           - the new user that we will create copies of notifications for
     */
    void copyNotifications(Organization orgWithNotifications, UserProfile newOrgUser);

    /**
     * Adds organisation information to the payload of a given web notification
     *
     * @param notification - the web notifications for which to add payload information
     * @param orgProfile   - the organisation profile to add
     */
    void addEntityInformation(WebNotification notification, OrgProfile orgProfile);

    /**
     * Adds subsidiary information to the payload of a given web notification
     *
     * @param notification - the web notifications for which to add payload information
     * @param organization - the subsidiary organisation to add
     */
    void addSubsidiaryInformation(WebNotification notification, Organization organization);

    /**
     * Removes subsidiary information from a given notification
     *
     * @param notification - the notification containing subsidiary information
     */
    void removeSubsidiaryInformation(WebNotification notification);

    /**
     * Adds the link type of a link request to the payload of a given notification
     *
     * @param notification - the web notifications for which to add payload information
     * @param linkRequest  - the org change request representing the link operation
     */
    void addLinkType(WebNotification notification, OrgChangeRequest linkRequest);

    /**
     * Adds user information to a given web notification
     *
     * @param notification - the web notifications for which to add payload information
     * @param profile      - the user profile to add to the notification
     */
    void addUserInfo(WebNotification notification, UserProfile profile);

    /**
     * Adds user information to a given web notification
     *
     * @param notification - the web notifications for which to add payload information
     * @param contact      - the contact info from an organisation request which contains user
     *                     information
     */
    void addUserInfo(WebNotification notification, ContactInfo contact);

    /**
     * Adds organisation onboarding information to a given web notification
     *
     * @param notification   - the web notifications for which to add payload information
     * @param profileRequest - the onboarding request containing the information to add
     */
    void addOnboardingInformation(WebNotification notification, OrgProfileRequest profileRequest);

    /**
     * Adds guarantee participants to the payload of a web notification
     *
     * @param notification  - the web notifications for which to add payload information
     * @param initiator     - the initiator of a guarantee request
     * @param issuer        - the issuer that is provided in a GX or gx request
     * @param applicant     - the applicant organisation in a GX
     * @param beneficiaries - the beneficiary organisation in a GX
     */
    void addParticipants(WebNotification notification, Organization initiator, Organization issuer,
                         Organization applicant, Organization... beneficiaries);

    /**
     * Adds a reject reason for a GX request to a web notification's payload
     *
     * @param notification        - the web notifications for which to add payload information
     * @param rejectActionRequest - the GX reject action
     */
    void addRejectReason(WebNotification notification, Flow.FlowActionRequest rejectActionRequest);

    /**
     * Adds a reject reason for a GX request to a web notification's payload
     *
     * @param notification - the web notifications for which to add payload information
     * @param rejectAction - the GX reject action
     */
    void addRejectReason(WebNotification notification, FlowAction rejectAction);

    /**
     * Adds new gx data to the payload of a web notification. The payload will be stored under a
     * specific key identifying it as a new GX
     *
     * @param notification  - the web notifications for which to add payload information
     * @param actionRequest - the action request containing GX data
     */
    void addNewGxData(WebNotification notification, Flow.FlowActionRequest actionRequest);

    /**
     * Adds GX data to the payload of a web notification.
     *
     * @param notification - the web notifications for which to add payload information
     * @param gx           - the GX from which to extract data from
     */
    void addGxData(WebNotification notification, Gx gx);

    /**
     * Populates a web notification with data from a GX issuer request
     *
     * @param notification  - the web notifications for which to add payload information
     * @param request       - the GX request that triggered this call
     * @param includeIssuer - a flag indicating whether to include issuer information or not
     *                      (beneficiaries don't need to know the issuer before the GX is issued)
     */
    void populateGxIssueData(WebNotification notification, GxRequest request,
                             boolean includeIssuer);

    /**
     * Populates the payload of a web notification with GX data.
     *
     * @param notification - the web notifications for which to add payload information
     * @param gx           - a guarantee containing information to add to the notification
     * @param request      - a GX request changing the provided gx and containing additional data to
     *                     add to the web notification
     */
    void populateGxData(WebNotification notification, Gx gx, GxRequest request);

    /**
     * Populates the payload of a web notification during a GX transfer request
     *
     * @param notification - the web notifications for which to add payload information
     * @param request      - the GX transfer request
     */
    void populateGxTransferData(WebNotification notification, GxRequest request);

    /**
     * This will duplicate notifications and send them to approval users of the parent organisation,
     * in case there is one. The provided subsidiary organisation ID is used to retrieve a parent
     * organisation if available. The method then reads the users of that parent organisation and
     * creates notifications for users having approval permissions for the subsidiary organisation.
     *
     * @param notification - the notification to send to parent users
     * @param subOrgId     - the id of the subsidiary organisations
     */
    void sendParentNotification(WebNotification notification, String subOrgId);

    /**
     * Creates a copy of a notification and removing any trace of bank references for this
     * notification.
     *
     * @param original - the original notification containing a bank reference
     * @return a copy of the original notification without any bank reference.
     */
    WebNotification cleanCopyNoBankReference(WebNotification original);

    /**
     * Creates a copy of a notification and removes any reject reason from the payload of that
     * notification.
     *
     * @param original - the original web notification containing a reject reason
     * @return a copy of the original notification without any reject reason
     */
    WebNotification cleanCopyNoRejectReason(WebNotification original);

    /**
     * Helper to retrieve Gx issuer payload from a Gx issue request
     *
     * @param request - the request from which to extract issue data
     * @return the gx issue payload of the provided request
     */
    GxIssuePayload getGxIssue(GxRequest request);

    /**
     * Helper to retrive Gx transfer payload from a Gx transfer request
     *
     * @param request - the transfer request from which to extract the payload
     * @return the gx transfer payload of the provided request
     */
    GxTransferPayload getGxTransfer(GxRequest request);
}
