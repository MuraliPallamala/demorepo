package com.ibm.au.bgx.model.api.exceptions;

import java.math.BigInteger;
import java.util.Map;

/**
 * @author Allison Irvin <allirvin@au1.ibm.com>
 */

public class ApiForbiddenException extends ApiException {

    /**
     * A {@link Long} value used to discriminate among different instances that have the same class
     * name (but may not be the same) during serialization.
     */
    private static final long serialVersionUID = -8478942940221007287L;

    /**
     * 
     * @param message
     */
    public ApiForbiddenException(String message) {
        super(message);
    }

    /**
     * 
     * @param path
     * @param message
     * @param description
     * @param code
     * @param context
     * @param innerException
     */
    public ApiForbiddenException(String path, String message, String description, BigInteger code, Map<String, Object> context, Throwable innerException) {
        super(path, message, description, code, context, innerException);
    }

    /**
     * 
     * @param path
     * @param message
     * @param description
     * @param code
     * @param context
     */
    public ApiForbiddenException(String path, String message, String description, BigInteger code, Map<String, Object> context) {
        super(path, message, description, code, context);
    }

    /**
     * 
     * @param path
     * @param message
     * @param innerException
     */
    public ApiForbiddenException(String path, String message, Throwable innerException) {
        super(path, message, innerException);
    }
}
