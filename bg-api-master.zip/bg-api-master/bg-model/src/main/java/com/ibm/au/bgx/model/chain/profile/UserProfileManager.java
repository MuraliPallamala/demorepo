package com.ibm.au.bgx.model.chain.profile;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.exception.IdentityProviderException;
import com.ibm.au.bgx.model.identityprovider.ManagedIdentityProviderClient;
import com.ibm.au.bgx.model.pojo.AgreementInfo;
import com.ibm.au.bgx.model.pojo.ApiKey;
import com.ibm.au.bgx.model.pojo.AuthTokenInfo;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Role;
import com.ibm.au.bgx.model.pojo.Role.Source;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.UserProfile.Status;
import com.ibm.au.bgx.model.pojo.api.request.ApiKeyRequest;
import com.ibm.au.bgx.model.pojo.api.request.SetOtpRequest;
import com.ibm.au.bgx.model.pojo.api.request.UserProfileRequest;
import com.ibm.au.bgx.model.pojo.api.request.UserProfileUpdateRequest;
import com.ibm.au.bgx.model.pojo.api.request.UserTaskRequest;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;

import java.math.BigInteger;
import java.time.Instant;
import java.util.List;

/**
 * <p>
 * Interface <b>UserProfileManager</b>. This class provides access to the management of 
 * the user profiles. Despite the solution design utilises a federated identity provider
 * for the management of the users, the solution still requires to maintain its own user
 * store to manage those functions that are associated to the applicaiton logic such as
 * the solution roles and other aspects. 
 * </p>
 * <p>
 * This interface performs these functions and also integrates with the federated identity
 * provider to perform user related functions such as profile creation and password setup
 * in scenarios where the organisation the user belongs to is configured to use the default
 * federated identity provider.
 * </p> 
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */

public interface UserProfileManager {


    /******************************************************************************************
     **   CREATE METHODS                                                                     **
     ******************************************************************************************/

    /**
     * This method creates a user in the solution based upon the profile that is being
     * passed as argument.
     *
     * @param profile    a {@link UserProfile} instance that is expected to not to be
     * 					{@literal null}.
     *
     * @return an instance of {@link UserProfile} with the updated details.
     *
     * @throws IllegalArgumentException
     *
     *			an exception is throw if any of the following conditions is met:
     *			<ul>
     *			<li><i>userProfile</i> is {@literal null}</li>
     *			<li><i>userProfile</i> does not have a valid organisation identifier.</li>
     *          <li><i>userProfile</i> does not have valid first name or last name.</i>
     *          <li><i>userProfile</i> does not have a valid email.</li>
     *          <li><i>userProfile</i> does not have valid credentials.</li>
     *          <li><i>userProfile</i> does not have any role ({@link UserProfile#getUserRoles()}
     *          is {@literal null} or an empty array).</li>
     *          <li><i>
     *          <li>there is already a user with the same email within the system.</li>
     *          <li><i>userProfile</i> has an invalid user key.</li>
     *          <li><i>userProfile</i> has no roles set.</li>
     *          <li><i>userProfile</i> has no credentials set, or no ket defined.</li>
     *          </ul>
     *
     *          First name, last name, organisation identifier are considered invalid if they
     *          are {@literal null} or empty strings. The credentials are considered not valid
     *          if {@link UserProfile#getCredentials()} returns{@literal null}.
     */
    UserProfile create(UserProfile profile);

    /**
     * <p>
     * Creates the corresponding {@link UserProfile} instances for the contacts that are 
     * listed within the given <i>organization</i> and assigns them the given <i>status</i>.
     * </p>
     * <p>
     * The method only creates those user profile that do not already exist, if there is an
     * existing profile, the method will skip the creation.
     * </p>
     *
     * @param orgId a {@link String} containing the organization Id of a newly created organization
     *
     * @param contacts a {@link List} containing contacts for the organization
     *
     * @param orgRoles a {@link List} containing default roles {@link Role} of the organization
     *
     * @param status        a {@link Status} value that represents the value of the status that
     * 						will be assigned to the newly created {@link UserProfile} instances.
     *
     * @return a {@link List} of {@link UserProfile} instances that represent the corresponding
     * 			{@link UserProfile} that match the contact list passed through the <i>organization</i>
     * 			argument.
     *
     * @throws IllegalArgumentException
     *
     * 			an exception of this type is called in any of the following cases:
     * 			<ul>
     * 			<li><i>orgId</i> is {@literal null}</li>
     * 			<li><i>contacts</i> is {@literal null}</li>
     * 			<li><i>orgRoles</i> is {@literal null}</li>
     * 			<li>the list of default roles is not included in <i>organization</i> or is empty</li>
     * 			<li><i>status</i> is {@literal null}</li>	
     * 			</ul>
     */
    List<UserProfile> createOrganizationUsers(String orgId, List<ContactInfo> contacts, List<Role> orgRoles, Status status);

    /******************************************************************************************
     **   QUERY METHODS                                                                      **
     ******************************************************************************************/

    /**
     * Checks whether the given user is a primary user. 
     *
     * @param userProfile    an instance of {@link UserProfile} representing the user. It is expected
     * 						to not to be {@literal null}.
     *
     * @return  {@literal true} if the given user profile includes the role 'PRIMARY' as one of the
     * 			roles associated to the user within its primary organisation. {@literal false}
     * 			otherwise. 
     *
     * @throws IllegalArgumentException if <i>userProfile</i> is {@literal null}.
     */
    boolean isPrimaryUser(UserProfile userProfile);

    /**
     * Checks whether the given user is a primary user. 
     *
     * @param userProfile    an instance of {@link UserProfile} representing the user. It is expected
     * 						to not to be {@literal null}.
     *
     * @return  {@literal true} if the given user profile includes the role 'PRIMARY' as one of the
     * 			roles associated to the user within its primary organisation. {@literal false}
     * 			otherwise. 
     */
    boolean isAdminUser(UserProfile userProfile);

    // TODO update to throw ProfileNotFoundException? That's how OrganizationManager works

    /**
     * Retrieves a user profile given the unique identifier. If the user is successfully retrieved
     * {@link UserProfile#getId()} is equal to <i>id</i>.
     *
     * @param id    a {@link String} representing the unique identifier of the user to retrieve.
     * 				It is expected to not to be {@literal null}.
     *
     * @return a {@link UserProfile} instance matching the given identifier, or {@literal null}
     * 			if it is not found. 
     *
     * @throws IllegalArgumentException        if <i>id</i> is {@literal null} or an empty string.
     */
    UserProfile getById(String id);

    /**
     * Retrieves a user profile given the organisation identifier and the email. If the user is 
     * successfully retrieved {@link UserProfile#getEmail()} is equal to <i>email</i> and {@link
     * UserProfile#getPrimaryOrgId()} is equal to <i>primaryOrgId</i>.
     *
     * @param primaryOrgId    a {@link String} representing the organisation identifier of the
     * 						organisation the user to retrieve belongs to. It is expected to not
     * 						to be {@literal null} or an empty string.
     *
     * @param email            a {@link String} representing the email of the user. It is expected
     * 						to not be {@literal null} or an empty string.
     *
     * @return a {@link UserProfile} instance matching the given organisation identifier and email,
     * 			or {@literal null} if there is no corresponding user record that with the given
     * 			primary organisation identifier and email.
     */
    UserProfile getByEmail(String primaryOrgId, String email);

    /**
     * Gets all the users that belong to the organisation whose unique identifier matches <i>id</i>.
     * For all the users that are retrieved the following condition should hold true: {@link
     * UserProfile#getPrimaryOrgId()} is equal to <i>id</id>.
     *
     * @param id    a {@link String} representing the unique identifier of the organization. It is
     * 				expected to not to be {@literal null} or an empty string.
     *
     * @return the list of {@link UserProfile} representing the users that belong to the organizaiton
     * 			represented by the given unique identifier.
     *
     * @throws IllegalArgumentException    if <i>id</i> is {@literal null} or an empty string.
     */
    List<UserProfile> getByPrimaryOrgId(String id);

    /**
     * Retrieves the user profiles that belong to a given organisation and a have specific
     * role. For any {@link UserProfile} instance returned in the result set the following 
     * conditions will be satisfied: {@link UserProfile#getPrimaryOrgId()} is equal to <i>
     * orgId</i> and the roles associated to the profile in that organisation contain the
     * <i>role</i>.
     *
     * @param orgId    	a {@link String} representing the unique identifier of the organisation
     * 					the user belong to. It cannot be an empty string or {@literal null}.
     * @param roleName  a {@link String} represnting the unique name of the role within the
     * 					organisation. It cannot be {@literal null} or an empty string.
     *
     * @return 	a {@link UserProfile} instance that matches the search criteria, or
     * 			{@literal null} if there is no match.
     *
     * @throws IllegalArgumentException if <i>orgId</i> or <i>email</i> are {@literal null}
     * 									or an empty string.
     */
    List<UserProfile> getByOrgRole(String orgId, String roleName);

    /**
     * Retrieves a list of users belonging to a specific organisation and being in a specified status.
     * @param orgId - the primary org id of the users to match against
     * @param status - the status of the users to match against
     * @return - a list of matching users from the given org in the provided status
     */
    List<UserProfile> getByStatusAndOrgId(String orgId, String status);

    /**
     * Checks whether the repository has a user that is already associated to the given <i>key</i>.
     *
     * @param key    a {@link String} representing the user login key. It is expected to not to
     * 				be {@literal null} or an empty string.
     *
     * @return    {@literal true} whether there is a user record whose key is set to <i>key</i>.
     * 			{@literal false} otherwise.
     */
    boolean hasKey(String key);

    /**
     * Gets the user that matches the given login and token. The login key is an attribute that
     * is associated to the end user and it is used to allow the prospective platform user to
     * login into the platform during the on-boarding phase. Once the usr has completed the setup
     * the key will be removed.
     *
     * @param key    a {@link String} representing the user login key. It is expected to not to
     * 				be {@literal null} or an empty string.
     *
     * @param token    a {@link String} representing the user authentication token. This token is
     * 				the additional information element required by the user to complete the setup
     * 				process and authenticate while its profile is not fully active. It is expected
     * 				to not to be {@literal null} or an empty string.
     *
     * @return a {@link UserProfile} instance that matches the given login key. If the result
     * 			is not {@literal null} then credentials object associated to the user have a
     * 			value for the key property that is equal to <i>key</i> and a value for the token
     * 			property that is equal to <i>token</i>.
     */
    UserProfile getByKeyAndToken(String key, String token);


    /******************************************************************************************
     **   UPDATE METHODS                                                                     **
     ******************************************************************************************/

    /**
     * Updates the roles of the users that are associated to its profile within the primary 
     * organisation. The primary organisation of a user is the one where the user account is
     * created in. This method is both used to update and remove roles or remove the linking
     * of a user to an organisation.
     *
     * @param id        a {@link String} representing the unique identifier of the user. It is
     * 					expected to not to be {@literal null} or an empty string. 
     * @param roles        a {@link String} representing the list of roles to associate to the
     * 					user. It cannot be {@literal null} or empty.
     *
     *
     * @return a {@link UserProfile} instance that matches the given <i>id</i> and contains the
     * 			updated roles mapping for the primary organisation it belongs to.
     *
     * @throws IllegalArgumentException
     *
     * 			this exception is thrown in the following cases:
     * 			<ul>
     * 			<li>the <i>id</i> is {@literal null} or an empty string.</li>
     * 			<li>the <i>roles</i> list does have empty strings, {@literal null} values or
     * 			duplicate values</li>
     * 			</ul>
     *
     * @throws IllegalStateException
     *
     * 			this exception is thrown in the following cases:
     * 			<ul>
     * 			<li>the <i>id</i> does not match any existing user.</i>
     * 			<li>the <i>roles</i> list is {@literal null} or an empty string.</li>
     * 			</ul>
     */
    UserProfile updateRoles(String id, List<String> roles);

    /**
     * <p>
     * Updates the roles of the user that are associated to the given <i>orgId</i>. This is more
     * generic version that allows the caller to set/update roles of user operating within the
     * context of a parent-subsidiary relationship.
     * </p>
     * <p>
     * As {@link UserProfileManager#updateRoles(String, List)} this method can either be used to
     * update/add/remove roles or remove completely the linking of a user to an organisation that 
     * is not its primary organisation. 
     * </p>
     *
     *
     * @param id        a {@link String} representing the unique identifier of the user. It is
     * 					expected to not to be {@literal null} or an empty string. 
     *
     * @param orgId        a {@link String} represnting the unique identifier of the organisation where
     * 					to assign the roles for the user. This organisation is expected to be in a
     * 					parent-subsidiary organisation with the primary organisation of the user. If
     * 					{@literal null} or empty string, the organisation is defaulted to the primary
     * 					organisation of the user.
     *
     * @param roles        a {@link String} representing the list of roles to associate to the user.
     *
     *
     * @return a {@link UserProfile} instance that matches the given <i>id</i> and contains the
     * 			updated roles mapping.
     *
     * @throws IllegalArgumentException
     *
     * 			this exception is thrown in the following cases:
     * 			<ul>
     * 			<li>the <i>id</i> is {@literal null} or an empty string.</li>
     * 			<li>the <i>roles</i> list does have empty strings, {@literal null} values or
     * 			duplicate values</li>
     * 			</ul>
     *
     * @throws IllegalStateException
     *
     * 			this exception is thrown in the following cases:
     * 			<ul>
     * 			<li>the <i>id</i> does not match any existing user.</i>
     * 			<li>the <i>roles</i> list is {@literal null} or an empty string and the organisation
     * 			identifier either matches the primary organisation of the user or it has been defaulted
     * 			to it.</li>
     * 			</ul> 
     */
    UserProfile updateRoles(String id, String orgId, List<String> roles);

    /**
     * Updates the status of the user mapped by <i>id</i> with the given <i>status</i>. If the
     * operation is successful, the returned {@link UserProfile} instance will have a value for
     * {@link UserProfile#getStatus()} that is equal to <i>status</i>.
     *
     * @param id        a {@link String} representing the unique identifier of the user to update.
     * 					It is expected to not to be {@literal null} or an empty string.
     * @param status    a {@link Status} value representing the user status. It is expected to not
     * 					to be {@literal null}.
     *
     * @return a {@link UserProfile} that matches <i>id</i> whose status is set to <i>status</i>.
     *
     * @throws IllegalArgumentException    if <i>id</i> is {@literal null} or an empty string, or
     * 									<i>status</i> is {@literal null}.
     *
     *  @throws IllegalStateException    if <i>id</i> does not map to any existing user.
     */
    UserProfile updateUserStatus(String id, UserProfile.Status status);

    /**
     * Updates the agreement information associated to the user identified by the given 
     * identifier.
     *
     * @param id            a {@link String} representing the unique identifier of the user. It
     * 						is expected to not to be {@literal null} or an empty string.
     * @param agreement        a {@link AgreementInfo} instance that contains the information
     * 						about the user agreement.
     *
     * @return a {@link UserProfile} instance that matches the user identifier ({@link
     * 			UserProfile#getId()} equals to <i>id</i>) and whose agreement is equal to 
     * 			to <i>agreement</i>. If the submitted agreement was {@literal null} then it
     * 			will b set to {@literal null}.
     */
    UserProfile updateAgreement(String id, AgreementInfo agreement);

    /**
     * Updates the user details (first name, last name, and phone) based on the content of 
     * the userProfile request.
     *
     * @param id                    a {@link String} representing the unique identifier of the
     * 								user to update. It cannot be {@literal null} or an empty
     * 								string.
     * @param userProfileRequest    a {@link UserProfileRequest} containing the updates to the
     * 								user details to apply. It cannot be {@literal null}.
     * @param realmName             a {@link String} containing the name of the realm of the
     * 								federated identity provider associated to the organisation
     * 								the user belongs to.
     * @param identityUserClient    a {@link ManagedIdentityProviderClient} that provides access
     * 								to the federated identity provider that stores the additional
     * 								details of the user. It cannot be {@literal null}.
     * @param targetOrgId 
     *
     * @return a {@link UserProfile} instance whose unique identifier matches <i>id</i> and
     * 			personal details are updated according to the allowed fields defined in the 
     * 			given request.
     *
     * @throws IllegalArgumentException
     *
     * 			if any of the following conditions is met:
     * 			<ul>
     * 			<li><i>id</i> is {@literal null} or an empty string</li>
     * 			<li><i>userProfileRequest</i> is {@literal null}.</li>
     * 			<li><i>realmName</i> is {@literal null} or an empty string.</li>
     * 			<li><i>identityUserClient</i> is {@literal null}.</li>
     * 			<li><i>targetOrgId</i> is {@literal null}.</li>
     * 			</ul>
     *
     * @throws IllegalStateException    if <i>id</i> does not map to any existing user.
     *
     * @throws IdentityProviderException    if there any exception in contacting the federated identity
     * 										provider to update the personal details.
     */
    UserProfile updateUserDetails(String id,
                                  final UserProfileUpdateRequest userProfileRequest,
                                  final String realmName,
                                  final ManagedIdentityProviderClient identityUserClient,
                                  final String targetOrgId
        ) throws IdentityProviderException;

    /**
     * Sets the user password, by interacting with the federated identity provider.
     *
     * @param id                    a {@link String} representing the unique identifier of the
     * 								user to update. It cannot be {@literal null} or an empty
     * 								string.
     * @param password                a {@link String} representing the password to set for the
     * 								user. It cannot be {@literal null} or an empty string and
     * 								must match the requirements imposed by the regulat expression
     * 								{@link BgxConstants#PASSWORD_REGEX}.
     * @param realmName                a {@link String} containing the name of the realm of the
     * 								federated identity provider associated to the organisation
     * 								the user belongs to.
     * @param identityUserClient    a {@link ManagedIdentityProviderClient} that provides access
     * 								to the federated identity provider that stores the password for
     * 							 	the user. It cannot be {@literal null}.
     *
     * @throws IllegalArgumentException
     *
     * 			if any of the following conditions is met:
     * 			<ul>
     * 			<li><i>id</i> is {@literal null} or an empty string</li>
     * 			<li><i>password</i> is {@literal null}, empty or does not satisfy the requirement
     * 			set by the {@link BgxConstants#PASSWORD_REGEX}.</li>
     * 			<li><i>realmName</i> is {@literal null} or an empty string.</li>
     * 			<li><i>identityUserClient</i> is {@literal null}.</li>
     * 			</ul>
     *
     * @throws IllegalStateException    if <i>id</i> does not map to any existing user.
     *
     * @throws IdentityProviderException    if there any exception in contacting the federated identity
     * 										provider to update the personal details.
     */
    void setPassword(String id,
                     final String password,
                     final String realmName,
                     final ManagedIdentityProviderClient identityUserClient) throws IdentityProviderException;

    /**
     * Removes the user that is mapped by the given unique identifier.
     *
     * @param id        a {@link String} representing the unique identifier of the user. It is expected
     * 					to not to be {@literal null} or an empty string.
     *
     * @throw {@link IllegalArgumentException} if <i>id</i> is {@literal null} or an empty string.
     */
    void delete(String id);

    /**
     * Update GxLimit for the org
     * @param id 
     * @param orgId A {@link String} representing the org
     * @param gxLimit A {@link BigInteger} representing the gx limit in cents
     * @return 
     */
    UserProfile updateGxLimit(String id, String orgId, BigInteger gxLimit);

    /**
     * 
     * @param profile
     * @param orgId
     * @param gxLimit
     * @return
     */
    UserProfile updateGxLimit(UserProfile profile, String orgId, BigInteger gxLimit);

    /**
     * 
     * @param id
     * @param orgId
     * @return
     */
    BigInteger getGxLimit(String id, String orgId);

    /**
     * 
     * @param profile
     * @param orgId
     * @return
     */
    BigInteger getGxLimit(UserProfile profile, String orgId);

    /******************************************************************************************
     **   TASK MANAGEMENT                                                                    **
     ******************************************************************************************/

    /**
     * Add a user task
     * @param userProfile 
     * @param task 
     * @return 
     */
    BatchProcessTask addTask(UserProfile userProfile, UserTaskRequest task);

    /**
     * Add a user task for a targetOrg
     * @param userProfile 
     * @param task 
     * @param sourceOrgId 
     * @param targetOrgId 
     * @return 
     */
    BatchProcessTask addTask(UserProfile userProfile, UserTaskRequest task, String sourceOrgId, String targetOrgId);

    /**
     * Delete a user task
     * @param userProfile 
     * @param taskId 
     */
    void deleteTask(UserProfile userProfile, String taskId);

    /**
     * Retrieve the list of tasks created by the user
     * @param userProfile 
     * @return 
     */
    List<BatchProcessTask> retrieveTasks(UserProfile userProfile);

    /**
     * Retrieve a task created by the user
     * @param userProfile 
     * @param taskId 
     * @return 
     */
    BatchProcessTask getTask(UserProfile userProfile, String taskId);

    /**
     * 
     * @param org
     * @param userProfile
     * @param organizationManager
     * @param roleSource
     * @return
     */
    UserProfile removeOrgRolesByRoleSource(Organization org, UserProfile userProfile, OrganizationManager organizationManager, Source roleSource);

    /**
     * Generate a new API key for the user
     * @param userId 
     * @param apiKeyRequest 
     * @return
     */
    ApiKey generateApiKey(String userId, ApiKeyRequest apiKeyRequest);

    /**
     * Delete an existing API key
     * @param userId 
     *
     * @param userProfile
     * @param keyId
     * @return
     */
    UserProfile deleteApiKey(String userId, String keyId);

    /**
     * Retrieve a user based on the API key
     * @param apiKey
     * @return
     */
    UserProfile getByApiKey(String apiKey);

    /**
     * Enable 2F authentication
     * @param userId 
     * @param realmName 
     * @param identityClient 
     * @param otpRequest 
     * @return 
     * @throws IdentityProviderException 
     */
    UserProfile enable2FAuth(String userId, String realmName, ManagedIdentityProviderClient identityClient, SetOtpRequest otpRequest) throws IdentityProviderException;

    /**
     * Disable 2F authentication
     * @param userId 
     * @param realmName 
     * @param identityClient 
     * @return 
     * @throws IdentityProviderException 
     */
    UserProfile disable2FAuth(String userId, String realmName, ManagedIdentityProviderClient identityClient) throws IdentityProviderException;

    /**
     * Store the auth token hash and expiry so that we can disable parallel login
     *
     * It also prunes expired tokens from the allowed auth
     * @param userId 
     *
     * @param authToken A {@link String} containing auth token
     * @param authTokenExpiry {@link java.time.Instant} representing the timestamp when auth token expires
     * @return
     */
    UserProfile updateLastLogin(String userId, String authToken, Instant authTokenExpiry);


    /**
     * Add the token in the allowed auth token list and prune expired tokens
     *
     * If param authToken is null, it will only prune the list if applicable
     * @param userId 
     * @param authToken 
     * @param authTokenExpiry 
     * @return 
     */
    UserProfile updateAllowedAuthTokens(String userId, String authToken, Instant authTokenExpiry);

    /**
     * Clear last login
     *
     * Note this is not a clear logout, rather we clear the last auth token details that are used
     * to block parallel login
     *
     * It also resets the list of allowed auth tokens
     *
     * @param userId
     * @return
     */
    UserProfile resetLastLogin(String userId);

    /**
     * Check if the user has different active login session or not
     * @param userProfile 
     * @param authToken A {@link String} containing auth token
     * @param authTokenIssuedAt A {@link java.time.Instant} representing the timestamp when auth token was issued
     * @return
     */
    boolean hasAnotherActiveLoginSession(UserProfile userProfile, String authToken, Instant authTokenIssuedAt);

    /**
     * Retrieve the matched auth token info
     * @param userProfile 
     * @param authToken 
     * @return 
     */
    AuthTokenInfo getAllowedAuthTokenInfo(UserProfile userProfile, String authToken);

    /**
     * Check that the token is not in use but can be used to login
     * @param userProfile 
     * @param authToken 
     * @return 
     */
    boolean isUnusedAuthToken(UserProfile userProfile, String authToken);

    /**
     * Compute auth token hash
     * @param authToken 
     * @return 
     */
    String computeAuthTokenHash(String authToken);
}
