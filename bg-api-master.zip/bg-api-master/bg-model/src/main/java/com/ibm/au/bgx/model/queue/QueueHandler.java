package com.ibm.au.bgx.model.queue;

import java.io.IOException;

/**
 * <p>
 * Interface <b>QueueHandler</b>. This interface defines a generic contract for
 * any component that desires to implement capabilities for processing asynchronous
 * messages submitted to the internal message queue of the vertical. The interface
 * is parameterised with a type <i>Z</i>, which allows to specialise the handlers
 * for a specific type of messages.
 * </p>
 * <p>
 * While this interface defines a specific type there exist two other entities that
 * work in coordination with {@link QueueHandler} implementations that are:
 * <ul>
 * <li>{@link QueueClient} this is used by other application components to push
 * messages to the asynchronous queue, which are dispatched according to the type
 * of message being sent.</li>
 * <li>{@link QueueConsumer} are the components that are actually registered with
 * the asynchronous queue, and usually hold a reference to a specific {@link QueueHandler}
 * implementation, to which they dispatch the processing of the asynchronous messages</li>
 * </ul>
 * </p>
 * 
 * 
 * @param <Z>  	the type of the messages that are stored in the queue that this handler
 * 				is interested in. 
 * 
 * 
 * @see QueueClient
 * @see QueueConsumer
 * 
 * @author Peter Ilfrich
 */
public interface QueueHandler<Z> {

	/**
	 * <p>
	 * Handles a message. This method is the main entry point for processing messages that
	 * are retrieved from the asynchronous queue.
	 * </p>
	 * <p>
	 * Implementations can throw an {@link IOException} if there is an error due to the
	 * message processing.
	 * </p>
	 * 
	 * 
	 * @param message	an instance of type <i>Z</i> representing the asynchronous 
	 * 					message passed to the handler. It cannot be {@literal null}.
	 * 
	 * @throws IOException	if there is any error while processing <i>message</i>.
	 * 
	 * @throws IllegalArgumentException	if <i>message</i> is {@literal null}.
	 * 
	 */
	// [CV] TODO: enforce constraints on argument in implementations (!= null) --> IllegalArgumentException
    void handle(Z message) throws IOException;
}
