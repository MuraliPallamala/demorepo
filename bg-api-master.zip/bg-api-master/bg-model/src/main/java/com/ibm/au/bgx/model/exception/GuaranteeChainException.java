package com.ibm.au.bgx.model.exception;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.ibm.au.bgx.fabric.model.FabricMessage;

/**
 * Class <b>GuaranteeChainException</b>. This class extends {@link RuntimeException} 
 * and it is used to identify all the errors that occur as a result of the interaction
 * with the {@link com.ibm.au.bgx.model.chain.GxChain}.
 * 
 * @author Dain Liffman <dainliff@au1.ibm.com>
 */
// [CV] TODO: make it inherit from GuaranteeException
//
public class GuaranteeChainException extends RuntimeException {

	/**
	 * A {@link Long} value used to discriminate among different instances that
	 * have the same class name (but may not be the same) during serialization.
	 */
	private static final long serialVersionUID = -8687036006473795312L;
	
	/**
	 * A {@link FabricMessage} instance that contains information about the underlying
	 * error occurred while interacting with the ledger.
	 */
	private FabricMessage fabricMessage;

	/**
	 * Constructs a new exception with the specified detail message. The cause
	 * is not initialized, and may subsequently be initialized by a call to
	 * {@link #initCause}.
	 *
	 * @param message	the detail message. The detail message is saved for later
	 *            		retrieval by the {@link #getMessage()} method.
	 */
	public GuaranteeChainException(FabricMessage message) {
		super(message.getRawMessage(), null);
		this.fabricMessage = message;
	}

	/**
	 * Constructs a new exception with the specified cause and a detail message
	 * of <tt>(cause==null ? null : cause.toString())</tt> (which typically
	 * contains the class and detail message of <tt>cause</tt>). 
	 *
	 * @param cause 	the cause (which is saved for later retrieval by the
	 *            		{@link #getCause()} method). (A <tt>null</tt> value is
	 *            		permitted, and indicates that the cause is nonexistent or
	 *            		unknown.)
	 */
	public GuaranteeChainException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructs a new exception with the specified detail message and cause.
	 * <p>
	 * Note that the detail message associated with {@code cause} is <i>not</i>
	 * automatically incorporated in this exception's detail message.
	 *
	 * @param message 	the detail message (which is saved for later retrieval by the
	 *            		{@link #getMessage()} method).
	 *
	 * @param cause		the cause (which is saved for later retrieval by the
	 *            		{@link #getCause()} method). (A <tt>null</tt> value is
	 *            		permitted, and indicates that the cause is nonexistent or
	 *            		unknown.)
	 */
	public GuaranteeChainException(FabricMessage message, Throwable cause) {
		super(message.getRawMessage(), cause);
		this.fabricMessage = message;
	}

	/**
	 * Gets information about the underlying ledger error occurred while transacting
	 * on the chain.
	 * 
	 * @return	a {@link FabricMessage} instance containing the error message parsed
	 * 			from the response of the transaction proposal. It can be {@literal null}.
	 */
	public FabricMessage getFabricMessage() {
		return this.fabricMessage;
	}
}
