/**
 * 
 */
package com.ibm.au.bgx.model.validation;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;

/**
 * <p>
 * Class <b>WhiteListRecord</b>. This class stores the information about the details
 * of an organisation that are white-listed during the onboarding process. Instances
 * of this class act like <i>match filters</i> against a specific {@link OrgProfile} 
 * which, if successful trigger the white-listing process, for that organisation.
 * </p>
 * <p>
 * The current implementation of this class is designed to perform a strict match, 
 * which requires that all the properties that are set in an instance of {@link 
 * WhiteListRecord} must be matched against the organisation profile in order to
 * trigger the white-listing, inherited classes or future implementations of this
 * class may relax this constraint by applying the filter only those properties that
 * are not set as {@literal null} (currently it is not possible to set any of these
 * properties as {@literal null}.
 * </p>
 * <p>
 * White-listing entails bypassing the normal checks (e.g. validation of business 
 * identifier against ASIC) prior to onboarding the organisation into the platform. 
 * This can be particularly useful in scenarios where there is a need for demo data 
 * or some of the services that the platform is dependent upon are temporarily not 
 * available.
 * </p>
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class WhiteListRecord {
	
	/**
	 * A {@link String} representing the name of the entity to be white-listed.
	 */
	private String entityName;
	/**
	 * A {@link String} representing the name of the business identifier.
	 */
	private String businessId;
	/**
	 * A {@link EntityType} value specifying the 
	 */
	private EntityType entityType;
	
	/**
	 * Initialises an instance of {@link WhiteListRecord} with the given properties.
	 * 
	 * @param entityName	a {@link String} representing the name of the organisation to match 
	 * 						for white listing (this is case sensitive). It cannot be {@literal 
	 * 						null} or an empty string.
	 * @param entityType	a {@link EntityType} value representing the type of the organisation 
	 * 						to match for white listing. It cannot be {@literal  null}.
	 * 
	 * @param businessId	a {@link String} representing the business identifier of the 
	 * 						organisation to match for white listing (this is case sensitive,
	 * 						but it does not really matter as the business identifier should
	 * 						only be composed by numbers). 
	 * 						It cannot be {@literal null} or an empty string.
	 * 
	 * @throws IllegalArgumentException	if one of the following applies:
	 * 									<ul>
	 * 									<li><i>entityName</i> is {@literal null} or an empty string</li>
	 * 									<li><i>businessId</i> is {@literal null} or an empty string</li>
	 * 									<li><i>entityType</i> is {@literal null}</li>
	 * 									</ul>
	 */
	@JsonCreator
	public WhiteListRecord(@JsonProperty("entityName") String entityName, 
						   @JsonProperty("entityType") EntityType entityType, 
						   @JsonProperty("businessId") String businessId) {
		
		this.setEntityName(entityName);
		this.setEntityType(entityType);
		this.setBusinessId(businessId);
	}

	/**
	 * Gets the configured name of the organisation for white-listing. This string is considered in a 
	 * case-sensitive manner when performing the matching and it is matched against the value of {@link 
	 * OrgProfile#getEntityName()}.
	 * 
	 * @return	a {@link String} representing the name of the organisation to match. It is guaranteed to 
	 * 			not to be {@literal null} or an empty string.
	 * 
	 * @see WhiteListRecord#matches(OrgProfile)
	 */
	public String getEntityName() {
		return this.entityName;
	}
	
	/**
	 * Sets the name of the organisation to match for white-listing. The value <i>entityName</i>
	 * is matched against {@link OrgProfile#getEntityName()} when performing the check for white-listing.
	 * 
	 * @param entityName	a {@link String} representing the name of the organisation. This value is
	 * 						interpreted in a case-sensitive manner and it cannot be {@literal null} or an 
	 * 						empty string.
	 * 
	 * @throws IllegalArgumentException		if <i>entityName</i> is {@literal null} or an empty string.
	 * 
	 * @see WhiteListRecord#matches(OrgProfile)
	 */
	public void setEntityName(String entityName) {
		
		if (entityName == null || entityName.isEmpty()) {
			throw new IllegalArgumentException("Parameter 'entityName' cannot be null or an empty string.");
		}
		
		this.entityName = entityName;
	}
	
	/**
	 * Gets the configured business identifier of the organisation for white-listing. This string is considered 
	 * in a case-sensitive manner when performing the matching and it is matched against the value of {@link 
	 * OrgProfile#getBusinessId()}.
	 * 
	 * @return	a {@link String} representing the business identifier of the organisation to match. It is guaranteed 
	 * 			to not to be {@literal null} or an empty string.
	 * 
	 * @see WhiteListRecord#matches(OrgProfile)
	 */
	public String getBusinessId() {
		
		return this.businessId;
	}
	
	/**
	 * Sets the name of the organisation to match for white-listing. The value <i>businessId</i>
	 * is matched against {@link OrgProfile#getBusinessId()} when performing the check for white-listing.
	 * 
	 * @param businessId	a {@link String} representing the business identifier of the organisation. This 
	 * 						value is interpreted in a case-sensitive manner and it cannot be {@literal null}
	 *  					or an empty string.
	 * 
	 * @throws IllegalArgumentException		if <i>businessId</i> is {@literal null} or an empty string.
	 * 
	 * @see WhiteListRecord#matches(OrgProfile)
	 */
	public void setBusinessId(String businessId) {
		
		if (businessId == null || businessId.isEmpty()) {
			throw new IllegalArgumentException("Parameter 'businessId' cannot be null or an empty string.");
		}
		
		this.businessId = businessId;
	}

	/**
	 * Gets the configured entity type of the organisation for white-listing. This string is matched against the value 
	 * of {@link OrgProfile#getEntityType()}.
	 * 
	 * @return	a {@link EntityType} value representing the type of the organisation to match. It is guaranteed to not
	 * 			to be {@literal null}.
	 * 
	 * @see WhiteListRecord#matches(OrgProfile)
	 */
	public EntityType getEntityType() {
		return entityType;
	}

	
	/**
	 * Sets the type of the organisation to match for white-listing. The value <i>entityType</i> is
	 * matched against {@link OrgProfile#getEntityType()} when performing the check for white-listing.
	 * 
	 * @param entityType	a {@link EntityType} value representing the business type of the organisation. 
	 * 						This cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException		if <i>entityType</i> is {@literal null}.
	 * 
	 * @see WhiteListRecord#matches(OrgProfile)
	 */
	public void setEntityType(EntityType entityType) {
		
		if (entityType == null) {
			throw new IllegalArgumentException("Parameter 'entityType' cannot be null.");
		}
		this.entityType = entityType;
	}
	
	/**
	 * Determines whether the current instance is match to the given <i>profile</i>. The matching
	 * is performed by checking whether <i>ALL</i> the following conditions are met:
	 * <ul>
	 * <li>{@link #getEntityName()} is equal to {@link OrgProfile#getEntityName()}</li>
	 * <li>{@link #getBusinessId()} is equal to {@link OrgProfile#getBusinessId()}</li>
	 * <li>{@link #getEntityType()} is equal to {@link OrgProfile#getEntityType()}</li>
	 * </ul>
	 * The comparison among strings is performed in a <i>case-sensitive</i> manner.
	 * 
	 * @param profile	a {@link OrgProfile} instance that represents the candidate organisation
	 * 					profile to match. It cannot be {@literal null} and must be a valid organisation
	 * 					profile.
	 * 
	 * @return	{@literal true} if the current instance matches the given <i>profile</i>, {@literal 
	 * 			false} otherwise.
	 * 
	 * @throws IllegalArgumentException	if <i>profile</i> is {@literal null}.
	 */
	public boolean matches(OrgProfile profile) {
		
		if (profile == null) {
			
			throw new IllegalArgumentException("Paramter 'profile' cannot be null.");
		}
		
		return this.getEntityName().equals(profile.getEntityName()) &&
			   this.getEntityType().equals(profile.getEntityType()) &&
			   this.getBusinessId().equals(profile.getBusinessId());
		
	}	
	
	/**
	 * Determines whether the current instance is equal to <i>other</i>. Equality test is
	 * performed according the following rules:
	 * <ul>
	 * <li>a {@literal null} <i>other</i> is not equal to any instance</li>
	 * <li><i>other</i> must be of type {@link WhiteListRecord} or a sub-type of it</li>
	 * <li><i>other</i> must have the same values for the properties defined in this class 
	 * (entityName, businessId, entityType).<li>
	 * </ul>
	 * 
	 * @param other 	a {@link Object} reference that is evaluated for comparison.
	 * 
	 * @return 	{@literal true} if <i>other</i> is not {@literal null}, of type {@link WhiteListRecord}
	 * 			and all the properties defined in this class are equal to those of <i>other</i>, {@literal 
	 * 			false} otherwise.
	 */
	@Override
	public boolean equals(Object other) {
		
		if (!(other instanceof WhiteListRecord)) {
			
			return false;
		}
		
		WhiteListRecord otherRecord = (WhiteListRecord) other;
		
		return this.getEntityName().equals(otherRecord.getEntityName()) &&
			   this.getEntityType().equals(otherRecord.getEntityType()) &&
			   this.getBusinessId().equals(otherRecord.getBusinessId());
	}
	

}
