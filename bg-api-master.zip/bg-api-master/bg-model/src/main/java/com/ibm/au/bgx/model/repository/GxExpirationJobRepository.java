package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.task.GxExpirationJob;

/**
 * @author Peter Ilfrich
 */
public interface GxExpirationJobRepository extends DefaultRepository<GxExpirationJob> {

	/**
	 * 
	 * @return
	 */
    GxExpirationJob findLatest();
}
