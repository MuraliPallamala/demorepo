package com.ibm.au.bgx.model;

import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.pojo.notification.NetworkSyncNotification;

/**
 * An interface to send {@link NetworkSyncNotification} to a remote network node
 * This is used to syn network participants about various configuration and notifications
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface NetworkSyncNotificationClient {

	/**
	 * 
	 * @param baseUrl
	 * @param notificationUrl
	 * @param notification
	 * @throws ServiceUnavailableException
	 */
    void notify(String baseUrl, String notificationUrl, NetworkSyncNotification notification) throws ServiceUnavailableException;
}
