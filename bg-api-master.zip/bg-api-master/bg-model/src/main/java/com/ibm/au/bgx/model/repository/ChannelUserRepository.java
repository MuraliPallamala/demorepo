package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.chain.ChannelUser;
import java.util.List;

/**
 * @author Peter Ilfrich
 */
public interface ChannelUserRepository extends DefaultRepository<ChannelUser> {

    // this is currently just an example to point out where the repo and service interfaces go
	/**
	 * 
	 * @param username
	 * @param mspId
	 * @return
	 */
    ChannelUser find(String username, String mspId);

    /**
     * 
     * @param username
     * @param orgId
     * @param mspId
     * @return
     */
    ChannelUser findUserByOrgId(String username, String orgId, String mspId);

    /**
     * 
     * @param mspId
     * @return
     */
    List<ChannelUser> findAllByMspId(String mspId);

    /**
     * 
     * @param affiliation
     * @return
     */
    List<ChannelUser> findAllByAffiliation(String affiliation);

}
