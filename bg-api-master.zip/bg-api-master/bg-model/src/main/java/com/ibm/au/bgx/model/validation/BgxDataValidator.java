package com.ibm.au.bgx.model.validation;

import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.exception.DataValidationException;
import com.ibm.au.bgx.model.pojo.AgreementInfo;
import com.ibm.au.bgx.model.pojo.BaseRequest;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond.Scope;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;

/**
 * Interface <b>BgxDataValidator</b>. This interface defines a set of validation methods
 * that are used by the solution for the purpose of ensuring that the information that is
 * entered into the system matches the expectations that are imposed by the business 
 * processes that have driven the implementation.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */

public interface BgxDataValidator {
	
	/**
	 * Determines whether the given organisation profile is valid with respect to the status of the associated
	 * onboarding request. 
	 * 
	 * @param profile	an instance of {@link OrgProfile} that contains the information about the organisation 
	 * 					profile to validate. It cannot be {@literal null}.
	 * 
	 * @param status 	a {@link Status} value that determines the type of checks that are applied  to the 
	 * 					<i>profile</i>. Currently the only relevant values are {@link Status#DRAFTED} and 
	 * 					{@link Status#CONFIRMED}. The values {@link Status#APPROVED} and {@link Status#REJECTED} 
	 * 					trigger the same type of checks of {@link Status#DRAFTED}, while the value {@link 
	 * 					Status#ABANDONED} triggers the same type of checks applied for  {@link Status#DRAFTED}. 
	 * 					It cannot be {@literal null}.
	 * 
	 * @return	{@literal true} if the given <i>profile</i> is valid with respect to the provide <i>status</i>, 
	 * 			{@literal false} otherwise.
	 * 
	 * @throws IllegalArgumentException if <i>profile</i> or <i>status</i> is {@literal null}.
	 * 
	 * @see BgxDataValidator#validateProfile(OrgProfile, Status)
	 */
	boolean isValidProfile(OrgProfile profile, BaseRequest.Status status);
	
	/**
	 * This method validates the given organisation profile according to the stage of the  associated onboarding 
	 * request. At different stages the organisation profile is expected to match different conditions:
	 * <ul>
	 * <li>when the status of the onboarding request is {@link Status#DRAFTED} the organisation profile is in the 
	 * initial stage of the referred onboarding process. In this scenario, any of the terms and conditions references 
	 * are not expected to be present</li>
	 * <li>when the status of the onboarding request is {@link Status#CONFIRMED} the organisation profile is in the 
	 * initial stage of the self-onboarding process or in the confirmation stage of the referred onboarding process. 
	 * In this scenarios, the terms and conditions entities must be accepted both for the overall organisation profile
	 * and the primary contact listed in the profile.<li>
	 * </ul>
	 * At any stage the following conditions should be verified:
	 * <ul>
	 * <li>entity name must be non {@literal null} or empty</li>
	 * <li>entity address must be non {@literal null} or empty</li>
	 * <li>business identifier must be valid</li>
	 * <li>contacts list must contain an entity with the role of {@link BgxConstants#ROLE_PRIMARY}</li>
	 * </ul>
	 * 
	 * @param profile	an instance of {@link OrgProfile} that contains the information about the organisation profile 
	 * 					to validate. It cannot be {@literal null}.
	 * 
	 * @param status 	a {@link Status} value that determines the type of checks that are applied to the <i>profile</i>. 
	 * 					Currently the only relevant values are {@link Status#DRAFTED} and {@link Status#CONFIRMED}. The 
	 * 					values {@link Status#APPROVED} and {@link Status#REJECTED} trigger the same type of checks of 
	 * 					{@link Status#DRAFTED}, while the value {@link Status#ABANDONED} triggers the same type of checks
	 * 					applied for {@link Status#DRAFTED}. It cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException if <i>profile</i> or <i>status</i> is {@literal null}.
	 * 
	 * @throws DataValidationException	if there is any condition on <i>profile</i> that is not met.
	 */
	void validateProfile(OrgProfile profile, BaseRequest.Status status);
	
	
	/**
	 * This method validates that the given agreement. The method checks the properties of the agreement and in particular 
	 * the specification the terms and conditions against the expected terms and conditions document stored in the platform 
	 * for that specific scope. If the validation is not successful it does throw a {@link DataValidationException}.
	 * 
	 * @param agreement	an instance of {@link AgreementInfo} that contains the details of the agreement. It cannot be {@literal 
	 * 					null}.
	 * 
	 * @param scope		a {@link Scope} value that defines the type of checks that need to be performed on the <i>agreement</i> 
	 * 					it cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException if <i>agreement</i> or <i>scope</i> is {@literal null}.
	 * 
	 * @throws DataValidationException	if the agreement is not valid (i.e. it does not contain the specification of the expected 
	 * 									terms and conditions document based on the defined scope.
	 */
	void validateAgreement(AgreementInfo agreement, Scope scope);

    /**
     * Validates the given business identifier. This could be either an Australian Business Number (ABN) or an Australian Company 
     * Number (ACN).
     * 
     * @param businessId	a {@link String} representing the business identifier to validate. It cannot be {@literal null} or an 
     * 						empty string.
     * 
     * @throws IllegalArgumentException	if <i>businessId</i> is {@literal null}.
     * 
     * @throws DataValidationException	if <i>businessId</i> is not valid.
     */
    void validateBusinessId(String businessId);

    /**
     * Determines whether the given business identifier is valid.
     * 
     * @param businessId	a {@link String} representing the business identifier to validate. It cannot be {@literal null} or an 
     * 						empty string.
     * 
     * @return	{@literal true} if <i>businessId</i> is a valid business identifier, {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException	if <i>businessId</i> is {@literal null}.
	 * 
	 * @see BgxDataValidator#validateBusinessId(String)
     */
    boolean isValidBusinessId(String businessId);

    /**
     * Validates the given business identifier as an Australian Business Number (ABN).
     * 
     * @param abn	a {@link String} representing the business identifier to test. It cannot be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>abn</i> is {@literal null}.
     * @throws DataValidationException	if <i>abn</i> is not a valid ABN.
     */
    void validateAbn(String abn);

    /**
     * Determines if the given identifier is a valid Australian Business Number (ABN).
     * 
     * @param abn	a {@link String} representing the business identifier to test. It cannot be {@literal null}.
     * 
     * @return	{@literal true} if <i>abn</i> is a valid ABN, {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException	if <i>abn</i> is {@literal null}.
     * 
     * @see BgxDataValidator#validateAbn(String)
     */
    boolean isValidAbn(String abn);

    /**
     * Validates the given business identifier as an Australian Company Number (ABN).
     * 
     * @param acn	a {@link String} representing the business identifier to test. It cannot be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>acn</i> is {@literal null}.
     * @throws DataValidationException	if <i>acn</i> is not a valid ACN.
     */
    void validateAcn(String acn);


    /**
     * Determines if the given identifier is a valid Australian Company Number (ACN).
     * 
     * @param acn	a {@link String} representing the business identifier to test. It cannot be {@literal null}.
     * 
     * @return	{@literal true} if <i>acn</i> is a valid ACN, {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException	if <i>acn</i> is {@literal null}.
     * 
     * @see BgxDataValidator#validateAcn(String)
     */
    boolean isValidAcn(String acn);
}
