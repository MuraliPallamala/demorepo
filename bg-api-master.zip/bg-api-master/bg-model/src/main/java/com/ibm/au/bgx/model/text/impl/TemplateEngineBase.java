/**
 * 
 */
package com.ibm.au.bgx.model.text.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;


import com.ibm.au.bgx.model.text.FileTemplateReference;
import com.ibm.au.bgx.model.text.InlineTemplateReference;
import com.ibm.au.bgx.model.text.ResourceTemplateReference;
import com.ibm.au.bgx.model.text.TemplateEngine;
import com.ibm.au.bgx.model.text.TemplateException;
import com.ibm.au.bgx.model.text.TemplateReference;

/**
 * Class <b>TemplateEngineBase</b>. Implements {@link TemplateEngine} and provides the
 * basic capability of dispatching the execution of the rendering when the an instance
 * of {@link TemplateReference} is supplied to the rendering method. This implementaiton
 * supports the rendering of the following types of reference:
 * <ul>
 * <li>{@link InlineTemplateReference}</li>
 * <li>{@link ResourceTemplateReference}</li>
 * <li>{@link FileTemplateReference}</li>
 * </ul>
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public abstract class TemplateEngineBase implements TemplateEngine {



	/**
	 * Renders the template that is pointed by <i>reference</i> and returns the rendered output. The method 
	 * uses reflection to determine the specific type of <i>reference</i> and based on the actual type 
	 * dispatches the execution of the rendering method as follows:
	 * <ul>
	 * <li>{@link InlineTemplateReference} instances will trigger the execution of the {@link TemplateEngineBase#render(String,Map)}.</li>
	 * <li>{@link FileTemplateReference} instances will trigger the execution of the @link TemplateEngineBase#render(File,Map)}.</li>
	 * <li>{@link ResourceTemplateReference} instances will trigger the execution of the {@link TemplateEngineBase#renderResource(ResourceTemplateReference,Map)}.</li>
	 * <li>Other implementations of {@link TemplateReference} will trigger the execution of {@link TemplateEngineBase#renderOtherType(TemplateReference,Map)}.</li>
	 * </ul>
	 * 
	 * @param reference		a {@link TemplateReference} representing the template to be used for the rendering. 
	 * 						It cannot be {@literal null}.
	 * 
	 * @param model		a {@link Map} implementation that stores the key-value pairs that are used to specialise the
	 * 					template pointed by <i>reference</i> with actual values. It is expected to not to be {@literal 
	 * 					null}.
	 * 
	 * @throws IllegalArgumentException	if <i>reference<i> or <i>model</i> are {@literal null}.
	 * 
	 * @throws TemplateException 	if there is any error while rendering the template. This also includes the 
	 * 								inability to use the given <i>reference</i> to retrieve the associated template.
	 */
	@Override
	public String render(TemplateReference reference, Map<String, Object> model) throws TemplateException {

		
		if (reference == null) {
			throw new IllegalArgumentException("Parameter 'reference' cannot be null.");
		}
		
		String output = null;
		
		if (reference instanceof InlineTemplateReference) {
			
			output = this.render(((InlineTemplateReference) reference).getContent(), model);
			
		} else if (reference instanceof FileTemplateReference) {
			
			output = this.render(((FileTemplateReference) reference).getFile(), model);
			
		} else if (reference instanceof ResourceTemplateReference) {
			
			output = this.renderResource((ResourceTemplateReference) reference, model);
			
		} else {
			
			output = this.renderOtherType(reference, model);
		}
		
		return output;
	}


	/**
	 * Renders the template that is pointed by <i>reference</i> and writes the rendered template to <i>output</i>. 
	 * The method uses reflection to determine the specific type of <i>reference</i> and based on the actual type 
	 * dispatches the execution of the rendering method as follows:
	 * <ul>
	 * <li>{@link InlineTemplateReference} instances will trigger the execution of the {@link TemplateEngineBase#render(String,Map,OutputStream)}.</li>
	 * <li>{@link FileTemplateReference} instances will trigger the execution of the @link TemplateEngineBase#render(File,Map,OutputStream)}.</li>
	 * <li>{@link ResourceTemplateReference} instances will trigger the execution of the {@link TemplateEngineBase#renderResource(ResourceTemplateReference,Map,OutputStream)}.</li>
	 * <li>Other implementations of {@link TemplateReference} will trigger the execution of {@link TemplateEngineBase#renderOtherType(TemplateReference,Map,OutputStream)}.</li>
	 * </ul>
	 * 
	 * @param reference		a {@link TemplateReference} representing the template to be used for the rendering. 
	 * 						It cannot be {@literal null}.
	 * 
	 * @param model		a {@link Map} implementation that stores the key-value pairs that are used to specialise the
	 * 					template pointed by <i>reference</i> with actual values. It is expected to not to be {@literal 
	 * 					null}.
	 * 
	 * @param output 	a {@link OutputStream} implementation where the rendered content of the template is written to.
	 * 					It cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException	if <i>reference<i> or <i>model</i> or <i>output</i> are {@literal null}.
	 * 
	 * @throws TemplateException 	if there is any error while rendering the template. This also includes the 
	 * 								inability to use the given <i>reference</i> to retrieve the associated template.
	 */
	@Override
	public void render(TemplateReference reference, Map<String, Object> model, OutputStream output) throws TemplateException {
		
		if (reference == null) {
			throw new IllegalArgumentException("Parameter 'reference' cannot be null.");
		}

		if (reference instanceof InlineTemplateReference) {
			
			this.render(((InlineTemplateReference) reference).getContent(), model, output);
			
		} else if (reference instanceof FileTemplateReference) {
			
			this.render(((FileTemplateReference) reference).getFile(), model, output);
			
		} else if (reference instanceof ResourceTemplateReference) {
			
			this.renderResource((ResourceTemplateReference) reference, model, output);
			
		} else {
			
			this.renderOtherType(reference, model, output);
		}

	}


	/**
	 * This method renders templates that are stored as resources into the current execution context. The default
	 * implementation accesses the stream associated to the resource via {@link TemplateResourceReference#getStream()}
	 * and then invokes {@link TemplateEngine#render(InputStream, Map, OutputStream)} to complete the rendering once
	 * it has obtained access to the stream attached to the resource.
	 * 
	 * @param reference	a {@link TemplateResourceReference} instance that points to the resource storing the definition
	 * 					of the template to render. It is expected to not to be {@literal null}.
	 * 
	 * @param model		a {@link Map} implementation that stores the key-value pairs that are used to specialise the
	 * 					template pointed by <i>reference</i> with actual values. It is expected to not to be {@literal 
	 * 					null}.
	 * 
	 * @param output 	a {@link OutputStream} implementation where the rendered content of the template is written to.
	 * 					It is expected to not to be {@literal null}.
	 * 
	 * @throws TemplateException	this version of the method always throws the exception. Inherited classes may have
	 * 								a different behaviour if they can support additional types of template references.
	 */
	protected void renderResource(ResourceTemplateReference reference, Map<String, Object> model,  OutputStream output) throws TemplateException {
		
		InputStream stream = reference.getClassLoader().getResourceAsStream(reference.getPath());
		if (stream != null) {
		
			this.render(stream, model, output);
		
		} else {
			
			throw new TemplateException(String.format("Could not render template: %1$s. Resource does not exist.", reference.getPath()));
		}
		
	}

	
	/**
	 * This method renders templates that are stored as resources into the current execution context. The default
	 * implementation accesses the stream associated to the resource via {@link TemplateResourceReference#getStream()}
	 * and reads its content into a {@link String}. It then invokes {@link TemplateEngine#render(String, Map)} to
	 * complete the rendering.
	 * 
	 * @param reference	a {@link TemplateResourceReference} instance that points to the resource storing the definition
	 * 					of the template to render. It is expected to not to be {@literal null}.
	 * 
	 * @param model		a {@link Map} implementation that stores the key-value pairs that are used to specialise the
	 * 					template pointed by <i>reference</i> with actual values. It is expected to not to be {@literal 
	 * 					null}.
	 * 
	 * @return a {@link String} containing the template specialised with values specified in <i>model</i>.
	 * 
	 * @throws TemplateException	this version of the method always throws the exception. Inherited classes may have
	 * 								a different behaviour if they can support additional types of template references.
	 */
	protected String renderResource(ResourceTemplateReference reference, Map<String, Object> model) throws TemplateException {
		
		InputStream stream = reference.getClassLoader().getResourceAsStream(reference.getPath());
		if (stream != null) {
		
			return this.render(stream, model);
		
		} else {
			
			throw new TemplateException(String.format("Could not render template: %1$s. Resource does not exist.", reference.getPath()));
		}
		
	}
	
	/**
	 * This method is an extension hook for inherited classes that can support the rendering of other implementations
	 * of {@link TemplateReference}. The current implementation throws a {@link TemplateException}, inherited classes
	 * can override this method to further discriminate additional types of template references that they are able to
	 * render.
	 * 
	 * @param reference	a {@link TemplateReference} instance that points to the template to render. It is expected to
	 * 					not to be {@literal null}.
	 * 
	 * @param model		a {@link Map} implementation that stores the key-value pairs that are used to specialise the
	 * 					template pointed by <i>reference</i> with actual values. It is expected to not to be {@literal 
	 * 					null}.
	 * 
	 * @param output	an {@link OutputStream} implementation that is used to write the rendered template to. It is
	 * 					expected to not to be {@literal null}.
	 * 
	 * @throws TemplateException	this version of the method always throws the exception. Inherited classes may have
	 * 								a different behaviour if they can support additional types of template references.
	 */
	protected void renderOtherType(TemplateReference reference, Map<String, Object> model, OutputStream output) throws TemplateException {
		
		throw new TemplateException("Unknown template reference type: " + reference.getClass().getName());
	}
	/**
	 * This method is an extension hook for inherited classes that can support the rendering of other implementations
	 * of {@link TemplateReference}. The current implementation throws a {@link TemplateException}, inherited classes
	 * can override this method to further discriminate additional types of template references that they are able to
	 * render.
	 * 
	 * @param reference	a {@link TemplateReference} instance that points to the template to render. It is expected to
	 * 					not to be {@literal null}.
	 * 
	 * @param model		a {@link Map} implementation that stores the key-value pairs that are used to specialise the
	 * 					template pointed by <i>reference</i> with actual values. It is expected to not to be {@literal 
	 * 					null}.
	 * 
	 * @return	a {@link String} representing the template rendered with the actual values.
	 * 
	 * @throws TemplateException	this version of the method always throws the exception. Inherited classes may have
	 * 								a different behaviour if they can support additional types of template references.
	 */
	protected String renderOtherType(TemplateReference reference, Map<String, Object> model) throws TemplateException {
		
		throw new TemplateException("Unknown template reference type: " + reference.getClass().getName());
	}


}
