package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.chain.FlowStatus;

import java.util.List;


/**
 * 
 * @author fl0yd
 *
 */
public interface ApprovalModelFlowRequestRepository extends DefaultRepository<ApprovalModelFlowRequest> {

	/**
	 * 
	 * @param orgId
	 * @param gxRequestId
	 * @param guaranteeId
	 * @param status
	 * @return
	 */
    List<ApprovalModelFlowRequest> find(String orgId, String gxRequestId, String guaranteeId, FlowStatus status);
}
