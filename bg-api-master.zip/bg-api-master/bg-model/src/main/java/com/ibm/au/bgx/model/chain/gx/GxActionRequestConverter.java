package com.ibm.au.bgx.model.chain.gx;

import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;

import java.util.List;

/**
 * 
 *
 */
public interface GxActionRequestConverter {

	/**
	 * 
	 * @param gxPrefillRequest
	 * @return
	 */
    GxAction from(GxPrefillRequest gxPrefillRequest);

    /**
     * 
     * @param approvalModelFlowAction
     * @return
     */
    GxAction from(ApprovalModelFlowRequest approvalModelFlowAction);

    /**
     * 
     * @param approvalModelFlowRequest
     * @return
     */
    List<GxAction> fromChildren(ApprovalModelFlowRequest approvalModelFlowRequest);
}