package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.pojo.api.request.OnboardingRequest;
import com.ibm.au.bgx.model.pojo.api.response.OnboardingResponse;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface NewCoAdminReferrerClient {

	/**
	 * 
	 * @param profileRequest
	 * @return
	 * @throws Exception
	 */
    OnboardingResponse onboard(OnboardingRequest profileRequest) throws Exception;

}
