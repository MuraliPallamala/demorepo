package com.ibm.au.bgx.model.chain.profile;

import com.ibm.au.bgx.model.PrincipalProvider;
import com.ibm.au.bgx.model.pojo.BankAccount;
import com.ibm.au.bgx.model.pojo.BaseRequest.RequestType;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import java.util.List;

/**
 * @author Peter Ilfrich
 */
public interface OrgChangeRequestManager extends PrincipalProvider {

    /**
     * This method will create a local record in the offchain-db with the given request payload.
     *
     * @param request - the request object holding the data
     * @return - the org change request including its ID and revision.
     */
    OrgChangeRequest createOrgChangeRequest(OrgChangeRequest request);


    /**
     * This is for NewCo admin. The method will add the given action to the request provided by the
     * requestId.
     *
     * @param requestId - the id of the org change request affected
     * @param action - the action request including the payload
     * @return the updated org change request
     */
    OrgChangeRequest addNewcoAdminOrgChangeRequestAction(String requestId, OrgRequestActionRequest action);

    /**
     * This is for NewCo. The method will add a given action to the request provided by the
     * requestId. An optional request response can be provided. This would be the response from
     * NewCo-admin, if the action requires itself to be sent to newco-admin.
     *
     * @param request - the org change request affected
     * @param finalAction - the action request including the payload
     * 
     * @return the updated {@link OrgChangeRequest} with the <i>finalAction</i>
     */
    OrgChangeRequest addFinalRequestAction(OrgChangeRequest request, OrgRequestAction finalAction);

    /**
     * Retrieves all org change requests for the currently logged in user.
     *
     * @return - a list of all org change requests (any status, including completed)
     */
    List<OrgChangeRequest> getAll();

    /**
     * Returns all org change requests that match the status provided as arguemnt. It will also only
     * return org change requests that belong to the organisation of the currently logged in user.
     *
     * @param status - the status to filter for
     * @return a list of org change requests.
     */
    List<OrgChangeRequest> getByStatus(Status status);

    /**
     * Retrieves records related to a specific org of a specific type in a specific state
     * @param status - the status of the requests to retrieve
     * @param type - the type of change request to retrieve
     * @return a list of org change requests matching the filter criteria.
     */
    List<OrgChangeRequest> getByOrgIdStatusAndType(Status status, RequestType type);

    /**
     * Retrieves a list of org requests that match the given org id and status
     * @param orgId - the id of the organization that triggered the request
     * @param status - the current status of the request
     * @return a list of org change requests
     */
    List<OrgChangeRequest> getByOrgIdAndStatus(String orgId, Status status);

    /**
     * Returns a request by the given ID. This is just a simple repository lookup.
     *
     * @param id - the ID of the request
     * @return - the request found in the database for the given ID
     */
    OrgChangeRequest getById(String id);

    /**
     * Retrieves a list of org change requests created for a given organisation.
     *
     * @param orgId - the ID of the organisation
     * @return - a list of org change requests for this organisation
     */
    List<OrgChangeRequest> getByOrgId(String orgId);

    /**
     * Add banking details to the currently logged in user / organisation. This will perform
     * duplicate check and add it to the offchain store.
     *
     * @param bankAccount - the bank account information to add
     * @return the updated organisation
     */
    Organization addBusinessAccount(BankAccount bankAccount);

    /**
     * Remove banking details from the currently logged in user / organisation.
     *
     * @param accId - the internal ID of the bank account details to remove
     * @return the updated organisation
     */
    Organization removeBusinessAccount(String accId);

    /**
     * Updates an existing business account of the currently logged in user's organisation.
     *
     * @param accountId - the id of the account to modify
     * @param accountInfo - the new data of the bank account (type, description, account number)
     * @return the updated organisation
     */
    Organization updateBusinessAccount(String accountId, BankAccount accountInfo);

    /**
     * Checks the local database if an organisation with the given id exists or not.
     *
     * @param orgId - the id of the organisation to search for
     * @return - true, if an organisation with that id exists
     */
    boolean checkOrganizationExists(String orgId);

    /**
     * Retrieves a list of org change requests affecting the org of the currently logged in user.
     *
     * @param requestStatus - optional filter for the request status (default: 'CONFIRMED')
     * @return - a list of org change request or type LINK or UNLINK affecting the currently logged
     * in user's organisation.
     */
    List<OrgChangeRequest> getByLinkedOrgId(Status requestStatus);

    /**
     * Executed when an org user approves a link request affecting the organisation of that user.
     *
     * @param request - the org change request for the link
     * @param approveAction - the approve action triggering the link creation
     * @return - the updated org change request
     */
    OrgChangeRequest createOrganizationLink(OrgChangeRequest request, OrgRequestAction approveAction);

    /**
     * Executed when an org user approves a unlink request affecting the organisation of that user.
     *
     * @param request - the org change request for the unlink
     * @param approveAction - the approve action triggering the unlink.
     * @return - the updated org change request
     */
    OrgChangeRequest deleteOrganizationLink(OrgChangeRequest request, OrgRequestAction approveAction);

    /**
     * Executed when an org user rejects a link/unlink request affecting the organisation of that
     * user.
     *
     * @param request - the org chanage reuqest to reject
     * @param rejectAction - the reject action
     * @return - the updated org change request
     */
    OrgChangeRequest rejectLinkRequest(OrgChangeRequest request, OrgRequestAction rejectAction);

    /**
     * Cancels an organisation link request
     *
     * @param request - the link request
     * @return the updated org change request
     */
    OrgChangeRequest cancelOrganizationLink(OrgChangeRequest request);
}
