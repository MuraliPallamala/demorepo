package com.ibm.au.bgx.model;


import com.ibm.au.bgx.model.pojo.system.SystemActionRequest;
import com.ibm.au.bgx.model.pojo.system.SystemActionResponse;

/**
 * 
 *
 */
public interface SystemActionsManager {

	/**
	 * 
	 * @param request
	 * @return
	 * @throws RuntimeException
	 */
    SystemActionResponse run(SystemActionRequest request) throws RuntimeException;
}
