package com.ibm.au.bgx.model.chain.profile;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileCreateException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.pojo.BaseRequest.RequestType;
import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.ContactInfo;
import com.ibm.au.bgx.model.pojo.OpenIdConfig;
import com.ibm.au.bgx.model.pojo.OrgProfile;
import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.OrgSettings;
import com.ibm.au.bgx.model.pojo.Organization;
import com.ibm.au.bgx.model.pojo.Permission;
import com.ibm.au.bgx.model.pojo.RelationshipInfo;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;
import com.ibm.au.bgx.model.pojo.Role;
import com.ibm.au.bgx.model.pojo.Role.Source;
import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.profile.Organizations.OrganizationPublicKey;

import java.security.PublicKey;
import java.util.List;
import java.util.Map;

/**
 * Interface <b>OrganizationManager</b>. This interface defines the contract for the management of
 * organisations within the platform. It provides access to capabilities for:
 * <ul>
 * <li>creating an organisation</li>
 * <li>retrieving information associated to an organisation</li>
 * <li>managing the organisation configuration settings</li>
 * <li>managing tasks and roles according the configured approval model</li>
 * <li>ensuring that the organisation can operate within the platform</li>
 * </ul>
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface OrganizationManager {

    /**
     * <p>
     * Create organization within the platform. This method initialises a new organisation within the platform. This method is
     * designed to support the administrative capabilities of the platform. The method requires the existence of an associated
     * blockchain user which will be used to represent the organisation within the ledger and that it is identified by <i>adminCert</i>.
     * </p>
     * <p>
     * The responsibility of this method are to create both the on-chain and off-chain data structure that represent the organisation
     * within the platform. The setup of the identity of the organisation and the authenticatio of its users to access the platform
     * will be completed at a later phase, once the primary contact of the organisation completes the onboarding process.
     * </p>
     *
     * @param profileRequest	an instance of {@link OrgProfileRequest} which contains the details about the organisation to
     * 							be created, such as its registered name, address, business identifier and contact references.
     * 							It cannot be {@literal null}.
     * 
     * @param adminCert 		a {@link String} representing the PEM representation of the X.509 certificate of the blockchain
     * 							user that is associated to the organisation. This argument can be {@literal null} but only in the
     * 							case of the creation of the Lygon organisation, for all the other cases the organisation will have
     * 							an associated user.
     * 
     * @param forceReconnect 	a {@literal boolean} flag that controls the behaviour of the manager with regards to the lack of
     * 							connectivity to the ledger. If {@literal true} the manager will attempt to reconnect to perform
     * 							those operations that require issuing transactions on the platform channel to persist the organisation
     * 							information, if {@literal false} the method will fail in case of lack of connectivity.
     * 
     * @return 	an {@link Organization} instance that represents the organisation entity created in the platform according to 
     * 			the given <i>profileRequest</i> and configured with the identity provided via <i>adminCert</i>.
     * 
     * @throws ProfileCreateException 	this exception is thrown when an error occurs while trying to create the organisation. The
     * 									causes can be several, for instance the existence of an organisation with the same information
     * 									in the platform. 
     * @throws ProfileChainException 	this exception is thrown when an error occurs while interacting with the ledger during the
     * 									creation of the organisation record.
     * 
     * @throws IllegalArgumentException	if <i>profileRequest</i> is {@literal null}.
     */
    Organization create(OrgProfileRequest profileRequest, String adminCert, boolean forceReconnect) throws ProfileCreateException, ProfileChainException;

    /**
     * Create organization within the platform. This method is an overloaded version of {@link OrganizationManager#create(OrgProfileRequest, String, boolean)}
     * that does not allow for controlling the behaviour of the manager in case of lack connectivity to the ledger.
     *
     * @param profileRequest	an instance of {@link OrgProfileRequest} which contains the details about the organisation to
     * 							be created, such as its registered name, address, business identifier and contact references.
     * 							It cannot be {@literal null}.
     * 
     * @param adminCert 		a {@link String} representing the PEM representation of the X.509 certificate of the blockchain
     * 							user that is associated to the organisation. This argument can be {@literal null} but only in the
     * 							case of the creation of the Lygon organisation, for all the other cases the organisation will have
     * 							an associated user. 
     * 
     * @return 	an {@link Organization} instance that represents the organisation entity created in the platform according to 
     * 			the given <i>profileRequest</i> and configured with the identity provided via <i>adminCert</i>.
     * 
     * @throws ProfileCreateException 	this exception is thrown when an error occurs while trying to create the organisation. The
     * 									causes can be several, for instance the existence of an organisation with the same information
     * 									in the platform. 
     * @throws ProfileChainException 	this exception is thrown when an error occurs while interacting with the ledger during the
     * 									creation of the organisation record.
     * 
     * @throws IllegalArgumentException	if <i>profileRequest</i> is {@literal null}.
     * 
     * @see OrganizationManager#create(OrgProfileRequest,String,boolean)
     */
    Organization create(OrgProfileRequest profileRequest, String adminCert) throws ProfileCreateException, ProfileChainException;

    /**
     * This method forces the refresh of the off-chain database that stores information about the organizations in the platform. This method is 
     * designed to ensure that the off-chain cache, which is the primary access point for the organisation manager to operate is synchronised with
     * the information that is stored in the ledger, for what concerns the organisation data, which is the one that gets updated first as new
     * organizations are onboarded into the platform.
     * 
     * @throws ProfileChainException 	this exception is thrown when an error occurs while interacting with the ledger during the refresh of
     * 									off-chain information.
     */
    void refreshCache() throws ProfileChainException;

    /**
     * This method updates the details of the off-chain database for the given organization.
     *
     * @param org	an instance of {@link Organization} that represents the record to update. It cannot be {@literal null}.
     * 
     * @return the updated organization record. It is guaranteed to not to be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>org</i> is {@literal null}.
     */
    Organization updateCache(Organization org);

    /**
     * Delete organization details from the off-chain database.
     *
     * @param id a {@link String} representing the unique identifier of the organization to delete. It cannot be {@literal null}
     * 
     * @return 	a {@link Organization} record representing the organization that has been deleted, it present, {@literal null} otherwise.
     * 
     * @throws IllegalArgumentException if <i>id</i> is {@literal null}.
     */
    Organization deleteCache(String id);

    /**
     * Retrieves the details of the organization that matches the given unique identifier. Implementations of this method are 
     * allowed to rely on internal caches but eventually, if the record if not found in the cache they need to follow through
     * with the data on the ledger (profile channel) and update the local cache.
     *
     * @param id 	a {@link String} representing the unique identifier of the the organization to retrieve. It cannot be {@literal 
     * 				null} or an empty string.
     * 
     * @return 	a {@link Organization} instance that stores all the information associated to the organization identified by <i>id</i>.
     * 
     * @throws ProfileNotFoundException 	if there is no organization with the given identifier.
     * @throws ProfileChainException 		if there is any error occurred while interacting with the ledger, while retrieving the
     * 										information about the organization.
     * @throws IllegalArgumentException 	if <i>id</i> is {@literal null} or an empty string.
     */
    Organization getById(String id) throws ProfileNotFoundException, ProfileChainException;

    /**
     * Get an organizatoin by its business identifier (ABN or ACN). This method allows for providing a partial business identifier 
     * and use such information as a prefix for the search. Implementations of this methods may relay on an internal cache, but 
     * should an empty set of organisation be found in the local cache, they must follow through by querying the ledger (profile
     * channel) and update the local cache.
     *
     * @param bid	a {@link String} representing the business identifier to search. This string is expected to represent an business
     * 				identifier in one of the formats allowed by the platform (currently only ABN and ACN) are supported. It can also
     * 				be a partial number, in that case it is used as a prefix for the search. It cannot be {@literal null} or an empty
     * 				string.
     * 
     * @return 	a {@link List} implementation containing the {@link Organization} instances that match the given identifier. If the
     * 			identifier is a complete business identifier, there should only be one instance of {@link Organization} in the list,
     * 			if the identifier is partial, there may be more than one entry in the list. It can be empty.
     * 
     * @throws ProfileNotFoundException 	this exception is not thrown, if there are no matching organizations, the list is
     * 										returned empty.
     * @throws ProfileChainException 		if there is any error occurred while interacting with the ledger, while retrieving the
     * 										information about the organization.
     * @throws IllegalArgumentException 	if <i>bid</i> is {@literal null} or an empty string.
     */
    // [CV] TODO: Remove ProfileNotFoundException because the semantics is such that the exception will never be thrown.
    //
    List<Organization> getByBusinessId(String bid) throws ProfileNotFoundException, ProfileChainException;

    /**
     * Retrieves all the organizations that are registered with the platform. Implementations of this method are allowed to relay 
     * on the off-chain database to fulfill this request. In that case, the information returned by the manager may be a subset of 
     * all the organisations in the platform, but eventually the implemented caching mechanism will sychronise the information that 
     * is stored off-chain with what is stored in the ledger.
     * 
     * @return 	a {@link List} implementation that contains {@link Organization} entities representing the organisations that are
     * 			registered with the platform.
     * 	
     * @throws ProfileChainException 		if there is any error occurred while interacting with the ledger, while retrieving the
     * 										information about the organisations.
     */
    List<Organization> getAll() throws ProfileChainException;

    /**
     * Retrieves all the organizations whose registered entity name matches the given <i>name</i>. Implementations of this method are
     * expected to support prefix matching. This means that the given <i>name</i> must be used as a prefix for the organisation name
     * while searching for organisations. Implementations of this method are allowed to use a off-chain cache, but in case of an empty
     * result-set they must follow through with a query on the ledger.
     *
     * @param name 	a {@link String} containing the registered entity name of the organisation to search for or a partial string that
     * 				is interpreted as its prefix. This value is compared against the attribute {@link OrgProfile#getEntityName()} of
     * 				the {@link Organization#getProfile()} property. It cannot be {@literal null} or an empty string.
     * 
     * @return 	a {@link List} containing all the exact and partial matches for the search. For each of the {@link Organization} record
     * 			returned the value of {@link OrgProfile#getEntityName()} is an exact match or a partial match to <i>name</i>. It can be
     * 			empty.
     * 
     * @throws ProfileNotFoundException 	this exception is not thrown, if there are no matching organizations, the list is
     * 										returned empty.
     * @throws ProfileChainException 		if there is any error occurred while interacting with the ledger, while retrieving the
     * 										information about the organization.
     * @throws IllegalArgumentException 	if <i>bid</i> is {@literal null} or an empty string.
     */
    // [CV] TODO: Remove ProfileNotFoundException because the semantics is such that the exception will never be thrown.
    //
    List<Organization> getByEntityName(String name) throws ProfileNotFoundException, ProfileChainException;

    /**
     * Retrieves all the organizations of the specified entity type. Implementations of this method are allowed to rely on the off-chain
     * cache to fulfill the request.
     *
     * @param type	a {@link EntityType} value that specifies the type of organization to search. This argument is matched against the
     * 				the value of {@link OrgProfile#getEntityType()} of {@link Organization#getProfile()}. It cannot be {@literal null}.
     * 
     * @return 	a {@link List} implementation containing the matching {@link Organization} records. For each of these entities the value
     * 			of {@link OrgProfile#getEntityType()} for the associated organisation profile, matches the given <i>type</i>. This result
     * 			set can be empty. 
     * 
     * @throws IllegalArgumentException	if <i>type</i> is {@literal null}.
     */
    // [CV] TODO: Fix semantics inconsistence, why this is the only method that does not follow through in the ledger? 
    //
    List<Organization> getByEntityType(EntityType type);

    /**
     * Retrieves the list of public keys that the specified organisation uses to transact in the ledger. By default an organisation is
     * associated to a default public key, which represents the public key that is encoded in the enrollment certificate of the fabric
     * user that represents such organisation. When an organisation is linked as a subsidiary within a parent-subsidiary relationship 
     * it exposes an additional public key that is associated to the parent organisation. As parent-subsidiary relationship may change
     * over time, there can be multiple parents associated to a given organisation and therefore multiple entries for the public keys. 
     * 
     * @param id 	a {@link String} representing the unique identifier of the organisation whose associated public keys are searched
     * 				for. It cannot be {@literal null} or an empty string.
     * 
     * @return 	a {@link Map} implementation that contains all the public keys that have been associated over time to the organization
     * 			that is identified by <i>id</i>. The maps uses th orgaization identifier of th orgnization for which the key was created
     * 			to 
     * 
     * @throws ProfileNotFoundException if there is no organization mapping the identifier specified by <i>id</i>. 
     * 
     * @throws IllegalArgumentException 	if <i>bid</i> is {@literal null} or an empty string.
     */
    Map<String, OrganizationPublicKey> getPublicKeys(String id) throws ProfileNotFoundException;


    /**
     * <p>
     * Retrieves the list of organisations that are identified by the specified issuer of the JSON Web Token (JWT) that
     * has been passed as argument. Distinct tokens are generated for API-to-API communications, and end user-to-API
     * communications. This method only considers the configuration of API clients that may be associated to an organisation.
     * </p>
     * <p>
     * Implmentations must respect the following condition: for every {@link Organization} returned, the value of {@link 
     * OpenIdConfig#getIssuer()} of the {@link OrgSettings#getApiAuth()} configuration associated the organisation settings 
     * (i.e. {@link Organization#getSettings()}), must match the given <i>iss</i> value.
     * </p>
     * 
     * @param iss 	a {@link String} representing the issuer of the JWT. This argument is set to the <i>iss</i> registered
     * 				claim of the payload section of a JWT (see <a href="https://tools.ietf.org/html/rfc7519#section-4.1.1">).
     * 				It cannot be {@literal null} or an empty string.
     * 
     * @return 	a {@link List} of {@link Organization} entries, whose API client uses a JWT issued by <i>iss</i>. It can be
     * 			empty if there are no organizations that match the selection criteria.
     * 
     * @throws IllegalArgumentException	if <i>iss</i> is {@literal null} or an empty string.
     */
    List<Organization> getByApiAuthJwtIssuer(String iss);
    
    /**
     * <p>
     * Retrieves the list of organisations that are identified by the specified issuer of the JSON Web Token (JWT) that
     * has been passed as argument. Distinct tokens are generated for API-to-API communications, and end user-to-API
     * communications. This method only considers the configuration of user clients that may be associated to an organisation.
     * </p>
     * <p>
     * Implmentations must respect the following condition: for every {@link Organization} returned, the value of {@link 
     * OpenIdConfig#getIssuer()} of the {@link OrgSettings#getUserAuth()} configuration associated the organisation settings 
     * (i.e. {@link Organization#getSettings()}), must match the given <i>iss</i> value.
     * </p>
     * 
     * @param iss 	a {@link String} representing the issuer of the JWT. This argument is set to the <i>iss</i> registered
     * 				claim of the payload section of a JWT (see <a href="https://tools.ietf.org/html/rfc7519#section-4.1.1">).
     * 				It cannot be {@literal null} or an empty string.
     * 
     * @return 	a {@link List} of {@link Organization} entries, whose user client uses a JWT issued by <i>iss</i>. It can be
     * 			empty if there are no organizations that match the selection criteria.
     * 
     * @throws IllegalArgumentException	if <i>iss</i> is {@literal null} or an empty string.
     */
    List<Organization> getByUserAuthJwtIssuer(String iss);

    /**
     * Retrieves the information associated to the organization that matches the given tenant key.
     * 
     * @param key	a {@link String} representing the tenant key associated to an organisation. The tenant key identifies 
     * 				an organisation during the process of onboarding and afterwards. During the process of onboarding the
     * 				tenant key is the only identifier used to refer to the organisation being onboarded and it is what links
     * 				the organisation to its onboarding request. After onboarding the tenant key is the 4 digit identifier
     * 				that an applicant/beneficiary uses to identify the login url of its own organisation. This argument
     * 				cannot be {@literal null} or empty.
     * 
     * @return 	the {@link Organization} instance that matches the given <i>key</i>. If not {@literal null}, the following
     * 			condition always apply: {@link OrgSettings#getKey()} matches the given <i>key</i>.
     * 
     * @throws IllegalArgumentException	if <i>key</i> is {@literal null} or an empty string.
     */
    Organization getByKey(String key);

    /**
     * <p>
     * Configures the organization with the set of default roles for its users and updates the local off-chain database
     * with the new information. This method is invoked within the context of an organisation setup, either as part of
     * the onboarding process of the primary user, or via bootstrapping from the backend.
     * </p>
     * <p>
     * The default roles include:
     * <ul>
     * <li>{@link BgxConstants#ROLE_PRIMARY} which identifies the primary contact for the organisation</li>
     * <li>{@link BgxConstants#ROLE_ADMIN} which identifies the administrator(s) of the organisation</li>
     * <li>{@link BgxConstants#ROLE_USER} which identifies a user of the organisation, entitled to perform business functions</li>
     * </ul>
     * All the other roles are dependent on the specific approval model being utilised, and will be set once the approval
     * model will be selected by the administrator of the organisation.
     * </p>
     * 
     * @param organization	a {@link Organization} instance that will be configured with default roles. It cannot be 
     * 						{@literal null}.
     * 
     * @return 	a {@link Organization} instance upated with the default roles. It is guaranteed to not to be {@literal 
     * 			null}.
     * 
     * @throws IllegalArgumentException	if <i>organization</i> is {@literal null}.
     */
    Organization setDefaultRoles(Organization organization);

    /**
     * Retrieves the default public key associated to the organisation. The default public key represents the public key
     * associated to the enrollment certificate of the Blockchain identity assigned to the organisation upon its creation.
     * This is default identity that is used to sign transactions on behalf of the organisation identified by <i>id</i>.
     * Such identity may be different in the scenario where an organisation is an parent-subsidiary relationship.
     * 
     * @param id 	a {@link String} representing the unique identifier of the organisation, whose default public key is
     * 				being retrieved. It cannot be {@literal null} or an empty string.
     * 
     * @return 	a {@link PublicKey} instance representing the public key associated to the organisation identifier by <i>id</i>.
     * 			Being the default public key a pre-requisite for the organisation creation within the ledger, this returned
     * 			value is expected to not to be {@literal null}.
     * 
     * @throws ProfileNotFoundException 		if the information about the organisation cannot be found. This means that
     * 											there is no organisation whose identifier matches the given <i>id</i>.
     * 
     * @throws IllegalArgumentException 		if <i>id</i> is {@literal null} or empty.
     */
    PublicKey getDefaultPublicKey(String id) throws ProfileNotFoundException;

    /**
     * Retrieves the information about the primary contact for the organisation. The primary contact is the person that is
     * representative for that organisation within the platform, it represents the user that owns the organisation onboarding
     * request and the first onboarded user of the organisation within the platform. In the absence of an administrator the
     * primary contact assumes the administrative role to allow the organisation to function.
     * 
     * @param organization 	a {@link Organization} instance whose the primary contact is being requested. It cannot be {@literal 
     * 						null}.
     * 
     * @return	a {@link ContactInfo} instance that contains the details of the primary contact for <i>organization</i>. Being
     * 			the primary contact a pre-requisite for the organisation, this reference is expected to be not {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>organization</i> is {@literal null}, or its profile, or list of contacts are 
     * 									{@literal null}.
     */
    ContactInfo getPrimaryContact(Organization organization);

    /**
     * Retrieves the information about the configured administrators for the organisation. The administrator is the person that
     * performs the administrative functions for the organisations (i.e. organisation managemnt, user management, configuration
     * of the approval model). There is always at least an administrator configured for the organisation, but the system allows
     * for having multiple administrators.
     * 
     * @param organization 	a {@link Organization} instance whose the administrator details are being requested. It cannot be 
     * 						{@literal null}. 
     * 
     * @return 	a {@link List} implementation containing at least one {@link ContactInfo} entry representing an administrator for
     * 			the platform. This list is not expected to be empty, and guaranteed to not to be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>organization</i> is {@literal null}, or its profile, or list of contacts are 
     * 									{@literal null}.
     */
    List<ContactInfo> getAdminContacts(Organization organization);

    /**
     * Retrieves the information about the specified administrator for the organisation. For this method to return the required
     * information there need to be a user in <i>organisation</i> that has the role of administrator, otherwise no information
     * is returned.
     * 
     * @param organization 	a {@link Organization} instance whose the administrator is being requested. It cannot be {@literal null}. 
     * @param email 		a {@link String} representing the email associated to the user to look up information about. It 
     * 						cannot be {@link null} or an empty string.
     * 
     * @return  {@link ContactInfo} instance that contains the details of the administrator identified by <i>email</i>. This
     * 			reference is not {@literal null} if there exist an administrator identified by <i>email</i> in <i>organization</i>.
     * 			A user identified by <i>email</i> that is not an administrator for <i>organization</i> causes this method to
     * 			return {@literal null}.
     * 
     * @see OrganizationManager#getAdminContacts(Organization)
     * @see OrganizationManager#getContact(Organization, String)
     * 
     * @throws IllegalArgumentException	if one of the following conditions are met:
     * 									<ul>
     * 									<li><i>organization</i> is {@literal null}</li>
     * 									<li><i>organization</i> has a {@literal null} profile</li>
     * 									<li><i>organization</i> has a {@literal null} list of contacts</li>
     * 									<li><i>email</i> is {@literal null}</li>
     * 									<li><i>email</i> is an empty string</li>
     * 									</ul>
     */
    ContactInfo getAdminContact(Organization organization, String email);

    /**
     * Retrieves the information about the specified user of the organisation. For this method to return the required information
     * there need to be a user in <i>organisation</i>, this can be any type of user (primary contact, administrator, normal user).
     * 
     * @param organization 	a {@link Organization} instance whose the user is being requested. It cannot be {@literal null}. 
     * 
     * @param email 		a {@link String} representing the email associated to the user to look up information about. It 
     * 						cannot be {@link null} or an empty string.
     * 
     * @return  {@link ContactInfo} instance that contains the details of the user identified by <i>email</i>. This reference is 
     * 			not {@literal null} if there exist a user identified by <i>email</i> in <i>organization</i>.
     * 
     * @see OrganizationManager#getAdminContact(Organization, String)
     * @see OrganizationManager#getPrimaryContact(Organization)
     * 
     * @throws IllegalArgumentException	if one of the following conditions are met:
     * 									<ul>
     * 									<li><i>organization</i> is {@literal null}</li>
     * 									<li><i>organization</i> has a {@literal null} profile</li>
     * 									<li><i>organization</i> has a {@literal null} list of contacts</li>
     * 									<li><i>email</i> is {@literal null}</li>
     * 									<li><i>email</i> is an empty string</li>
     * 									</ul>
     */
    ContactInfo getContact(Organization organization, String email);

    /**
     * Updates the organization identified by <i>orgId</i> in the off-chain database, according to the content of {@link OrgChangeRequest}. Implementations
     * are expected to compute the change that need to be applied by scanning the content of <i>changeRequest</i> and then update the organisation profile
     * of the identified organisation accordingly.
     * 
     * @param orgId 		a {@link String} representing the unique identifier of the organization to update. It cannot be {@literal null} or an empty string
     * 						and must reference an existing organisation.
     * 
     * @param changeRequest	a {@link OrgChangeRequest} instance that defines the updates to be made to the organisation. It cannot be {@literal null} and must
     * 						be in the {@link Status#APPROVED} state.
     * 
     * @return	a {@link Organization} instance that represents the updated organisation identified by <i>orgId</i>.
     * 
     * @throws IllegalArgumentException	if one of the following occurs:
     * 									<ul>
     * 									<li><i>orgId</i> is {@literal null} or an empty string</li>
     * 									<li><i>orgId</i> does not identify an existing organisation</li>
     * 									<li><i>changeRequest</i> is {@literal null}</li>
     * 									<li><i>changeRequest</i> is not in {@link Status#APPROVED}</li>
     * 									</ul>
     * 
     * @see OrganizationManager#getEffectiveOrgChange(OrgChangeRequest)
     */
    Organization updateOrganization(String orgId, OrgChangeRequest changeRequest);

    /**
     * This operations completes the life-cycle of an organisation change request as a result of its approval by the administrative
     * vertical of the platform. The approval of the request triggers the downstream process of updating the details of the organisation
     * that implementations must honor. This process include:
     * <ul>
     * <li>resolving the updates to be performed by inspecting the request</li>
     * <li>updating the on-chain record for the organisation</li>
     * <li>updating the off-chain database</li>
     * </ul>
     * This method is invoked within the context of the administrative vertical once the organisation update has been approved.
     * 
     * @param orgId 		a {@link String} representing the unique identifier of the organisation to update.
     * 						It cannot be {@literal null} or an empty string.
     * 
     * @param changeRequest	a {@link OrgChangeRequest} instance that defines the updates to be made to the organisation. It cannot be 
     * 						{@literal null} and must be in the {@link Status#APPROVED} state.
     * 
     * @return 	an instance of {@link Organization} that contains the updated details of the organisation, according to the information
     * 			passed with <i>changeRequest</i>.
     * 
     * @throws ProfileChainException in case of any error updating the organisation in the ledger.
     */
    Organization finishUpdateRequest(String orgId, OrgChangeRequest changeRequest) throws ProfileChainException;

    /**
     * Updates the approval model of the specified organisation. The approval model governs the workflows internal to an
     * organisation that are associated to the management of a bank guarantee. They define roles for organisation users
     * and associated actions that they can perform, as well as the ordered sequence of actions that are required to
     * complete any given workflow. The approval model is configured by the organisation administrator who is also responsible
     * for assigning the user roles that depend on the selected approval model.
     * 
     * @param orgId 				a {@link String} representing the unique identifier of the organisation to update.
     * 								It cannot be {@literal null} or an empty string.
     * 
     * @param approvalModelName 	a {@link com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo.Name} value that identifies
     * 								the specific approval model to configure. It cannot be {@literal null}.
     * 
     * @return 	a {@link com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelInfo.Name} value representing the updated approval
     * 			model.
     * 
     * @throws Exception 
     * 
     */
    // [CV] TODO: some things to consider (improvements):
    //            - check whether this method should be principal bound.
    //            - we should have a more specialised exception.
    //            - why we return what we have just set?, what is the benefit of it?
    //            - it does not seem we need even to declare Exception, all the exception in the implementation seems to be unchecked
    //
    ApprovalModelInfo.Name updateApprovalModel(String orgId, ApprovalModelInfo.Name approvalModelName) throws Exception;

    /**
     * <p>
     * Creates the name of the OpenID Realm that is being used to manage the identities of the users of the given <i>organization</i>.
     * The platform is a multi-tenant environment, where each organisation has its own set of identities that are isolated into distinct
     * realms, upon the creation of an organisation within the platform, an identity realm needs to be configured for it to enable its
     * users to authenticate with the platform and log in within their own organisation space.
     * </p>
     * <p>
     * This operation is currently used in the context of a managed identity provider, where the platform does manage the user base for
     * the organisation, in the scenario where an organisation is configured with an external identity provider, this capability may not
     * be needed, as the realm name will be provided.
     * </p>
     * 
     * @param organization	a {@link Organization} instance for which the security realm is created. It cannot be {@literal null}.
     * 
     * @return 	a {@link String} containing the name of the realm that has been associated to the given <i>organization</i>. It is expected
     * 			to not to be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>organization<i> is {@literal null}.
     * 
     * @see OrganizationManager#prepareRealmName(String)
     */
    String prepareRealmName(Organization organization);

    /**
     * <p>
     * Creates the name of the OpenID Realm that is being used to manage the identities of the users of the given organization identifier
     * by the given <i>orgId</i>. The platform is a multi-tenant environment, where each organisation has its own set of identities that 
     * are isolated into distinct realms, upon the creation of an organisation within the platform, an identity realm needs to be configured 
     * for it to enable its users to authenticate with the platform and log in within their own organisation space.
     * </p>
     * <p>
     * This operation is currently used in the context of a managed identity provider, where the platform does manage the user base for
     * the organisation, in the scenario where an organisation is configured with an external identity provider, this capability may not
     * be needed, as the realm name will be provided.
     * </p>
     * 
     * @param orgId		a {@link String} representing the unique identifier for the organization. It cannot be {@literal null} or an empty
     * 					string.
     * 
     * @return 	a {@link String} containing the name of the realm that has been associated to the given <i>organization</i>. It is expected
     * 			to not to be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>orgId<i> is {@literal null} or an empty string.
     * 
     * @see OrganizationManager#prepareRealmName(Organization)
     */
    String prepareRealmName(String orgId);

    /**
     * Retrieves the system role information for <i>roleName</i> as defined in <i>organization</i>. The platform allows for an extensible 
     * role system, this is primarily due to the use of the approval model capability which injects additional roles to the system, besides 
     * the default roles that are common to all organisations. System roles identifies those roles that are common to all organisations and
     * are configuted upon organisation creation.
     * 
     * @param organization 	a {@link Organization} instance whose system roles need to be retrieved. It cannot be {@literal null}.
     * @param roleName 		a {@link String} containing the name of the role to lookup. It cannot be {@literal null} or an empty string.
     * 
     * @return  a {@link Role} instance that wraps all the information about the specific role in <i>organization</i>. It can be {@literal 
     * 			null} if the specified <i>roleName</i> does not match any system role.
     * 
     * @throws IllegalArgumentException	is one of the following occurs:
     * 									<ul>
     * 									<li><i>organization</i> is {@literal null}</li>
     * 									<li><i>organization</i> has {@literal null} value for {@link Organization#getSettings()}</li>
     * 									<li><i>organization</i> has settings with a {@literal null} list of roles</li>
     * 									<li><i>roleName</i> is {@literal null}</li>
     * 									<li><i>roleName</i> is an empty string</li>
     * 									</ul>
     * 
     * @see OrganizationManager#setDefaultRoles(Organization)
     * @see OrganizationManager#getOrgRole(Organization, String)
     * @see OrganizationManager#isValidRole(Organization, String)
     * @see OrganizationManager#isValidRole(Organization, String, Source)
     */
    Role getSystemRole(Organization organization, String roleName);

    /**
     * Retrieves the role information for <i>roleName</i> as defined in <i>organization</i>. The platform allows for an extensible role 
     * system, this is primarily due to the use of the approval model capability which injects additional roles to the system, besides 
     * the default roles that are common to all organisations. This method allows for dynamically retrieving the information associated
     * to role by its name.
     * 
     * @param organization 	a {@link Organization} instance whose roles need to be retrieved. It cannot be {@literal null} and
     * 						must a be a validly configured instance of the organisation.
     * @param roleName 		a {@link String} containing the name of the role to lookup. It cannot be {@literal null} or an empty string.
     * 
     * @return  a {@link Role} instance that wraps all the information about the specific role in <i>organization</i>. It can be {@literal 
     * 			null} if the specified <i>roleName</i> does not match any role.
     * 
     * @throws IllegalArgumentException	is one of the following occurs:
     * 									<ul>
     * 									<li><i>organization</i> is {@literal null}</li>
     * 									<li><i>organization</i> has {@literal null} value for {@link Organization#getSettings()}</li>
     * 									<li><i>organization</i> has settings with a {@literal null} list of roles</li>
     * 									<li><i>roleName</i> is {@literal null}</li>
     * 									<li><i>roleName</i> is an empty string</li>
     * 									</ul>
     * 
     * @see OrganizationManager#setDefaultRoles(Organization)
     * @see OrganizationManager#getSystemRole(Organization, String) 
     * @see OrganizationManager#isValidRole(Organization, String)
     * @see OrganizationManager#isValidRole(Organization, String, Source)
     */
    Role getOrgRole(Organization organization, String roleName);

    /**
     * Determines whether the role identified by <i>roleName</i> is a valid role within <i>organization</i>. The platform allows for
     * a flexible and dynamic set of roles. This is primarily due to the fact that the approval model capability (which is configurable
     * overt time) defines approval model specific roles for the users in an organisation. As a result, at any given time an organisation
     * may have a different set of valid roles. This justifies the need for being able to query whether a role is valid or not.
     * 
     * @param organization 	a {@link Organization} instance whose query for the role validity refers to. It cannot be {@literal null} and
     * 						must a be a validly configured instance of the organisation.
     * 
     * @param roleName 		a {@link String} containing the name of the role to lookup. It cannot be {@literal null} or an empty string.
     * 
     * @return {@literal true} if <i>roleName</i> is defined in <i>organization</i>, {@literal false} otherwise.
     *  
     * @throws IllegalArgumentException	is one of the following occurs:
     * 									<ul>
     * 									<li><i>organization</i> is {@literal null}</li>
     * 									<li><i>organization</i> has {@literal null} value for {@link Organization#getSettings()}</li>
     * 									<li><i>organization</i> has settings with a {@literal null} list of roles</li>
     * 									<li><i>roleName</i> is {@literal null}</li>
     * 									<li><i>roleName</i> is an empty string</li>
     * 									</ul>
     * 
     * @see OrganizationManager#isValidRole(Organization, String, Source)
     */
    boolean isValidRole(Organization organization, String roleName);

    /**
     * <p>
     * Determines whether the role identified by <i>roleName</i> and <i>source</i> is a valid role within <i>organization</i>. The platform 
     * allows for a flexible and dynamic set of roles. This is primarily due to the fact that the approval model capability (configurable
     * overt time) defines approval model specific roles for the users in an organisation. As a result, at any given time an organisation
     * may have a different set of valid roles. This justifies the need for being able to query whether a role is valid or not.
     * </p>
     * <p>
     * Roles have sources. A source identifies the origin of the role. Currently there exist only two possible types of sources for the roles: 
     * the default set of system roles, and the approval models. This method constrains the validation of the role to a specific source that
     * is passed as additional parameter to the method.
     * </p>
     * 
     * @param organization 	a {@link Organization} instance whose query for the role validity refers to. It cannot be {@literal null} and
     * 						must a be a validly configured instance of the organisation.
     * 
     * @param roleName 		a {@link String} containing the name of the role to lookup. It cannot be {@literal null} or an empty string.
     * 
     * @param source		a {@link Source} value that narrows the search for the role to a specific role source. It cannot be {@literal null}.
     * 
     * @return 	{@literal true} if <i>roleName</i> is defined in <i>organization</i> and {@link Role#getSource()} matches <i>source</i>, 
     * 			{@literal false} otherwise.
     *  
     * @throws IllegalArgumentException	is one of the following occurs:
     * 									<ul>
     * 									<li><i>organization</i> is {@literal null}</li>
     * 									<li><i>organization</i> has {@literal null} value for {@link Organization#getSettings()}</li>
     * 									<li><i>organization</i> has settings with a {@literal null} list of roles</li>
     * 									<li><i>roleName</i> is {@literal null}</li>
     * 									<li><i>roleName</i> is an empty string</li>
     * 									<li><i>source</i> is {@literal null}</li>
     * 									</ul>
     * 
     * @see OrganizationManager#isValidRole(Organization, String)
     */
    boolean isValidRole(Organization organization, String roleName, Source source);

    /**
     * Determines whether the given <i>organization</i> has a specific type of relationship with another organization identified by <i>targetOrgId</i>.
     * Relationships are used to model the parent-subsidiary linking between two organizations, which provides the parent organization with the ability
     * to operate on the guarantees of the subsidiary according to a predefined set of permissions (read/write). This method allows for retrieving a
     * {@link RelationshipInfo} instance that represents a specific relationship between <i>organization</i> and the organization specified by <i>targetOrgId</i>
     * by also checking whether such relationship is of the specified <i>relationshipType</i> and includes all the specified <i>permissions</i>. If any
     * of these conditions are not satisfied the method returns {@literal null}.
     * 
     * 
     * @param organization 		a {@link Organization} instance representing the organisation for which the relationships need to be retrieved.
     * 							It cannot be {@literal null} and must be a validly configured organisation instance.
     * @param targetOrgId 		a {@link String} representing the unique identifier of the organisation which <i>organisation</i> may have 
     * 							relationship with. It cannot be {@literal null}.
     * 
     * @param permissions 		a {@link List} containing the list of permissions that we want to filter the relationships for. Given a non empty
     * 							list of permissions, the method will look for all those relationships that includes all the permissions included 
     * 							in this list. It cannot be {@literal null}.
     * 
     * @param relationshipType 	a {@link Relationship} value that indicates the type of relationship we want to filter for. 
     * 
     * @return  a {@link RelationshipInfo} instance that matches the filtering criteria defined by the search filter, if found otherwise {@literal null}.
     * 			
     * @throws IllegalArgumentException	if one of the following occurs:
     * 									<ul>
     * 									<li><i>organization</i> is {@literal null}</li>
     * 									<li><i>organization</i> has {@literal null} settings (i.e. {@link Organization#getSettings()})</li>
     * 									<li><i>organization</i> has a {@literal null} list of relationships {(i.e. OrgSettings#getRelationships()})</li>
     * 									<li><i>targetOrgId</i> is {@literal null}</li>
     * 									<li><i>permissions</i> is {@literal null}</li>
     * 									<li><i>relationshipType</i> is {@literal null}</li>
     * 									</ul>
     */
    RelationshipInfo getAllowedRelationship(Organization organization, String targetOrgId, List<Permission> permissions, Relationship relationshipType);

    /**
     * Schedules a job for updating the roles of an organization. The operation for bulk-role update is utilised within the context of establishment of
     * a parent-subsidiary relationship in which the users of the parent organisation have now also a set of roles in the subsidiary organisation. As a 
     * result if such organisation has "default roles", these need to be added to the users of the parent organisation too, for them to be able to operate
     * consistently in the subsidiary organisation.
     *
     * @param userOrgId 		a {@link String} representing the unique identifier of the organisation whose users are subject to the role update. In the 
     * 							context of a parent-subsidiary relationship, this is the unique identifier of the parent organisation. It cannot be {@literal 
     * 							null} or an empty string.
     * @param targetOrgId 		a {@link String} representing the unique identifier of the organisation for which roles are being updated. In the context of
     * 							a parent-subsidiary relationship, this is the unique identifier of the subsidiary organisation. It cannot be {@literal null} or
     * 							an empty string.
     * @param defaultRoles 		a {@link List} of role names that need to be applied to the users. These usually identify the set of default roles that a
     * 							specific approval model configuration naturally grants to all users. It cannot be {@literal null}.
     * 
     * @return 	a {@link BatchProcessTask} that captures the batch execution of the role update as indicated by the method signature. It is guaranteed to not
     * 			to be {@literal null}.	
     */
    // [CV] TODO: check whether it makes any sense for userOrgId and targetOrgId and defaultRoles to be null. The downstream code is resistant to these values
    //            being null, but I believe we should enforce (!= null, non-empty) for the string parameters, and (!= null) for the list of roles.
    //
    BatchProcessTask scheduleRoleUpdateTask(String userOrgId, String targetOrgId, List<String> defaultRoles);

    /**
     * Ensures that the given <i>organization</i> has at least an administrator. Implementations must assume that this method is invoked when a prospective
     * administrator has rejected the terms and conditions set by the platform for end-user participation. As a result, the corresponding contact is stripped
     * of the administrator role. Implementations must ensure that in the current setup of the organization there is another administrator. If no other user
     * with administrator role is present, the primary contact must be elevated to administrator for the organization.
     *
     * @param organization		a {@link Organization} instance representing the organization that needs to be checked for the presence of an administrator. It
     * 							cannot be {@literal null} and must represent a validly configured organization. 
     * 
     * @param rejectAdminEmail  a {@link String} representing the email address of the contact (prospective administrator) that has rejected the user terms and
     * 							conditions. It cannot be {@literal null} or an empty string.
     * 
     * @param otherAdminExists 	a {@literal boolean} flag that indicates whether the organization has already an administrator (i.e. {@literal true}) or not
     * 							(i.e {@literal false}). In the latter, the implementation is expected to elevate the primary contact of the organization to the
     * 							role of administrator.
     * 
     * @return a {@link Organization} instance that contains the updated set of contacts and roles. It is guaranteed to not to be {@literal null}.
     * 
     * @see OrganizationManager#getAdminContact(Organization, String)
     * @see OrganizationManager#getPrimaryContact(Organization)
     * @see OrganizationManager#getSystemRole(Organization, String)
     */
    Organization updateAdminContactsRejectUser(Organization organization, String rejectAdminEmail, boolean otherAdminExists);

    /**
     * Determines the resulting organisation profile update that needs to be applied to an organisation based on the given organisation update request.
     * Implementations are expected to resolve the values to be set of the organisation profile by looking at the list of actions associated to the
     * request. In scenarios where a recall action has been submitted to the request (or multiple recall actions have been submitted), the last valid
     * recall action, rather then the initial request will hold the most updated values to set for the organisation profile.
     * 
     * @param req	a {@link OrgChangeRequest} instance that is contains the update request to be applied to an organisation. It cannot be {@literal null}.
     * 
     * @return 	a {@link OrgProfile} instance that contains the updated values of organisation entity name and entity address based on the last valid
     * 			values set in the request.
     * 
     * @throws IllegalArgumentException if one the following conditions are met:
     * 									<ul>
     * 									<li><i>req</i> is {@literal null}</li>
     * 									<li><i>req</i> is not of type {@link RequestType#CHANGE_DETAILS} (currently the only request type supported)</li>
     * 									<li><i>req</i> has an invalid payload</li>
     * 									</ul>
     */
    OrgProfile getEffectiveOrgChange(OrgChangeRequest req);

}
