/**
 * 
 */
package com.ibm.au.bgx.model.repository;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * Copyright (C) 2015 IBM Corporation
 * All Rights Reserved
 */

/**
 * Interface <b>DefaultRepository</b>. This interface is the default
 * specialisation of {@link Repository} whereby the generic type used
 * for the identifier is set to {@link String}. This interface is a
 * convenient shortand, to simplify the number of generic types to
 * specify in most cases.
 * 
 * @param <T> 	this type parameter represents the type of the entities
 * 				that are managed by the repository.
 *
 * @author Christian Vecchiola
 */
public interface DefaultRepository<T> extends Repository<T,String> { 

}
