package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.ReferredGxAction;
import com.ibm.au.bgx.model.user.BgxPrincipal;

/**
 * @author Dain Liffman dainliff@au1.ibm.com
 */
public interface GxPrefillClient {

	/**
	 * 
	 * @param principal
	 * @param request
	 * @return
	 * @throws ServiceUnavailableException
	 */
    GxPrefillRequest sendGxPrefillNotification(BgxPrincipal principal, GxRequest request) throws ServiceUnavailableException;

    /**
     * 
     * @param issuerId
     * @param gxAction
     * @return
     * @throws ProfileNotFoundException
     * @throws ProfileChainException
     * @throws ServiceUnavailableException
     */
    ReferredGxAction sendOffchainGxActionNotification(String issuerId, GxAction gxAction) throws ProfileNotFoundException, ProfileChainException, ServiceUnavailableException;
}
