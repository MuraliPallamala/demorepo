/**
 * 
 */
package com.ibm.au.bgx.model.exception;


/**
 * Class <b>DataValidationException</b>. Specializes {@link DataException} to represent
 * error associated to the validation of input data.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class DataValidationException extends DataException {

	/**
	 * A {@literal long} value used to verify deserialisation of instances
	 * of this class, to ensure that they refer to the same definition of
	 * the type.
	 */
	private static final long serialVersionUID = 8011106021251702121L;

	/**
	 * A {@literal int} that defines the error code associated to the
	 * validation error.
	 */
	private final int errorCode;

    /**
     * Initialises a new instance of {@link DataValidationException} with the given <i>message</i>.
     * This constructor calls {@link DataValidationException#DataValidationException(String, int, Throwable)}
     * and passes 0 and {@literal null} as the last two parameters.
     *
     * @param message a {@link String} that provides a human intelligible
     *                information about the error that occurred and created
     *                this instance of {@link DataValidationException} to occur.
     */
    public DataValidationException(String message) {
        this(message, 0, null);
    }
	
    /**
     * Initialises a new instance of the {@link DataValidationException} with the given
     * <i>message</i> and <i>innerException</i>. This constructor invokes the overloaded
     * version {@link DataValidationException#DataValidationException(String, int, Throwable)}
     * and passes 0 as error code.
     *
     * @param message        a {@link String} containing a human intelligible
     *                       message providing information about the cause
     *                       of the exception.
     * @param innerException a {@link Throwable} instance that represents
     *                       the cause of this instance of {@link DataValidationException}
     *                       to be created.
     */
    public DataValidationException(String message, Throwable innerException) {
        this(message, 0, innerException);
    }

    /**
     * Initialises an instance of {@link DataValidationException} with th given <i>message</i>,
     * and <i>errorCode</i>. This constructor calls {@link #DataValidationException(String,int,Throwable)}
     * and passes {@literal null} to the last argument.
     *
     * @param message        a {@link String} containing a human intelligible
     *                       message providing information about the cause
     *                       of the exception. instance of {@link DataValidationException}
     *                       to be created.
     * @param errorCode		 a {@literal int} value that stores information about
     * 						 the error code associated to the current validation error.
     * 
     * @throws IllegalArgumentException	if the error is a negative number.
     */
    public DataValidationException(String message, int errorCode) {
    	this(message, errorCode, null);
    }
    
    /**
     * Initialises an instance of {@link DataValidationException} with th given <i>message</i>,
     * <i>errorCode</i>, and <i>innerException</i>..
     *
     * @param message        a {@link String} containing a human intelligible
     *                       message providing information about the cause
     *                       of the exception.
     * @param innerException a {@link Throwable} instance that represents
     *                       the cause of this instance of {@link DataValidationException}
     *                       to be created.
     * @param errorCode		 a {@literal int} value that stores information about
     * 						 the error code associated to the current validation error.
     * 
     * @throws IllegalArgumentException	if the error is a negative number.
     */
    public DataValidationException(String message, int errorCode, Throwable innerException) {
    	super(message, innerException);
    	if (errorCode < 0) {
    		throw new IllegalArgumentException("Error code cannot be a negative number.");
    	}
    	this.errorCode = errorCode;
    	
    }
    /**
     * Gets the error code that is associated to the validation error represented by 
     * this instance of {@link DataValidationException}.
     * 
     * @return 	an {@literal int} value indicating the code associated to the error.
     * 			It is guaranteed to not to be negative, by default it is set to 0.
     */
    public int getErrorCode() {
    	
    	return this.errorCode;
    }
}
