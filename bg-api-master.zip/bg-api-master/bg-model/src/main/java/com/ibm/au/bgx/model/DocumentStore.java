package com.ibm.au.bgx.model;

import java.util.Map;

/**
 * Interface for document store
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface DocumentStore {

    /**
     * Upload a document
     *
     * If meta data is passed, it creates a meta file in the document store.
     *
     * @param id A {@link String} containing the file id
     * @param bytes Bytes to write
     * @param meta A {@link Map} containing meta data about the file
     */
    void createDocument(String id, byte[] bytes, Map<String, Object> meta);

    /**
     * Upload a document
     *
     * @param id A {@link String} containing the file id
     * @param payload A {@link String} containing base64 encoded file bytes
     * @param meta 
     */
    void createDocumentWithBase64(String id, String payload, Map<String, Object> meta);

    /**
     * Download a document meta data
     *
     * @param id A {@link String} containing the file id
     * @return 
     */
    Map<String, Object> readDocumentMeta(String id);

    /**
     * Download a document
     *
     * @param id A {@link String} containing the file id
     * @return 
     */
    byte[] readDocument(String id);

    /**
     * Download a document as base64 string
     *
     * @param id A {@link String} containing the file id
     * @return A {@link String} base64 encoded byte[]
     */
    String readDocumentAsBase64(String id);

    /**
     * Check if the document exists or not
     * @param id 
     * @return 
     */
    boolean hasDocument(String id);

    /**
     * Check if the document meta exists or not
     * @param id 
     * @return 
     */
    boolean hasDocumentMeta(String id);

    /**
     * Delete if the document exists
     * @param id 
     * @return 
     */
    boolean deleteDocument(String id);
}
