package com.ibm.au.bgx.model.chain;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.ibm.au.bgx.model.BgxConstants;
import com.ibm.au.bgx.model.util.BasicBgxEncryptionUtil;
import com.ibm.au.bgx.model.util.BgxEncryptionUtil;
import java.io.IOException;
import java.security.PrivateKey;

/**
 * Class <b>DefaultEnrollmentDeserializer</b>. This class deserialize an
 * instance of {@link BgxDefaultEnrollment}
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * @todo Add description
 */

public class BgxDefaultEnrollmentDeserializer extends StdDeserializer<BgxDefaultEnrollment> {

    /**
     *
     */
    private static final long serialVersionUID = -3695159275658777598L;


    /**
     * 
     */
    public BgxDefaultEnrollmentDeserializer() {
        this(null);
    }

    /**
     * 
     * @param t
     */
    public BgxDefaultEnrollmentDeserializer(Class<BgxDefaultEnrollment> t) {
        super(t);
    }

    /**
     * 
     */
    @Override
    public BgxDefaultEnrollment deserialize(JsonParser jsonParser,
        DeserializationContext deserializationContext)
        throws IOException, JsonProcessingException {

        JsonNode node = jsonParser.getCodec().readTree(jsonParser);
        String key = node.get(BgxConstants.META_PRIVATE_KEY).asText();
        String cert = node.get(BgxConstants.META_CERT).asText();

        PrivateKey pkey = BasicBgxEncryptionUtil.parsePemPrivateKey(key, BgxEncryptionUtil.ECDSA);
        BgxDefaultEnrollment enrollment = new BgxDefaultEnrollment(pkey, cert);

        return enrollment;
    }

}
