package com.ibm.au.bgx.model.api.exceptions;

import java.math.BigInteger;
import java.util.Map;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public class ApiUnauthorizedException extends ApiException {

	/**
	 * A {@link Long} value used to discriminate among different instances that
	 * have the same class name (but may not be the same) during serialization.
	 */
	private static final long serialVersionUID = 6697701241096704673L;

	/**
	 * 
	 * @param path
	 * @param message
	 * @param description
	 * @param code
	 * @param context
	 * @param innerException
	 */
	public ApiUnauthorizedException(String path, String message, String description, BigInteger code, Map<String, Object> context, Throwable innerException) {
        super(path, message, description, code, context, innerException);
    }

	/**
	 * 
	 * @param path
	 * @param message
	 * @param description
	 * @param code
	 * @param context
	 */
    public ApiUnauthorizedException(String path, String message, String description, BigInteger code, Map<String, Object> context) {
        super(path, message, description, code, context);
    }

    /**
     * 
     * @param path
     * @param message
     * @param innerException
     */
    public ApiUnauthorizedException(String path, String message, Throwable innerException) {
        super(path, message, null, BigInteger.ZERO, null, innerException);
    }
}
