package com.ibm.au.bgx.model;

import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.pojo.Permission;
import com.ibm.au.bgx.model.pojo.RelationshipInfo.Relationship;

import java.util.List;

/**
 * <p>
 * Interface <b>Spawnable</b>. This interface defines the contract for components that are required
 * to <i>spawn</i> an another instance of itself, which is bound to another security principal that
 * is different from the default one assigned during the authentication process.
 * </p>
 * <p>
 * This requirement is manifested during scenarios where an identity needs to impersonate another 
 * identity, to be able to act on behalf of it. This is for instance the case of parent-subsidiary
 * relationships, where the parent organisation users need to operate on behalf of the users of the
 * subsidiary organisation.
 * </p>
 * <p>
 * <b>NOTE:</b> it is assumed that the spawnable class will have access to the principal so that the
 * implementation can check if the principal specified.
 * </p>
 * 
 * @param <T> 	the specific type that is being spawned.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface Spawnable<T> {

	/**
	 * Determines whether the current instance is the result of a spawning process, rather than
	 * being the original instance.
	 * 
	 * @return	{@literal true} whether the current instance is the result of the spawning process,
	 * 			{@literal false} otherwise.
	 */
    boolean isSpawned();


    /**
     * Gets the unique identifier of the organisation that is currently bound to the instance.
     * 
     * @return 	a {@link String} representing the organisation identifier of the organisation
     * 			that is bound to the current instance. It is guaranteed to not to be {@literal 
     * 			null}.
     * 
     * @throws IllegalStateException	if there is no organisation bound to the instance.
     */
    String getConfiguredForOrgId();

    /**
     * <p>
     * Spawns an instance of <i>T</i> for the given organisation, and configures it with the given <i>permissions</i>.
     * This method constrains the spawning  operation to the specific type of relationship identified by <i>relationship</i>.
     * </p>
     * 
     * @param relationship	a {@lik Relationship} value that indicates the specific role of the organisation bound to the
     * 						current instance, is expected to have in the relationship. It cannot be {@literal null}.
     *     
     * @param targetOrgId	a {@link String} representing the unique identifier for which an instance of <i>T</i> will be	
     * 						spawn and bound to. It cannot be {@literal null} or an empty string.
     * @param permissions	a {@link List} containing the set of permissions that need to be attributed to the spawned
     * 						entity while operating in the target organisation. These determines the set of operations that 
     * 						the spawned instance can perform in the organisation. It cannot be {@literal null}.
     * 
     * @return 	an instance of <i>T</i> configured to operate as an identity in the organisation identified by <i>targetOrgId</i>
     * 			with the specified permission. If the operation is successful, this reference it is guaranteed to not to be
     * 			{@literal null}.
     * 
     * @throws GuaranteeForbiddenException	if the required operation is not allowed because the conditions for impersonation
     * 										are not met. These can be:
     * 										<ul>
     * 										<li>there isn't a parent subsidiary relationship among the organisatio bound
     * 										to the current instance, and the organisation identified by <i>targetOrgId</i>
     * 										<li>there is a parent subsidiary relationship but the required permissions are
     * 										is not allowed by the relationship</li>
     * 										<li>the specific user associated to the current spawnable does not have roles
     * 										in the target organisation that allow him/her to perform the operations allowed
     * 										by the permissions specified</li>
     * 										</ul>
     * 
     * @throws IllegalArgumentException		if <i>targetOrgId</i> is {@literal null} or an empty string, <i>permissions</i>
     * 										is {@literal null}, or <i>relationship</i> is {@literal null}.
     * 
     * @see Spawnable#forOrg(String, Permission)
     * @see Spawnable#forOrg(Relationship, String, List)
     * @see Spawnable#forOrg(Relationship, String, Permission)
     */
    T forOrg(Relationship relationship, String targetOrgId, List<Permission> permissions) throws GuaranteeForbiddenException;

    /**
     * <p>
     * Spawns an instance of <i>T</i> for the given organisation, and configures it with the given <i>permissions</i>.
     * This method is used within the context of the parent-subsidiary organisation where the current identity is used
     * to impersonate an identity in the organisation defined by <i>targetOrgId</i>.
     * </p>
     * <p>
     * This method is a short form of {@link Spawnable#forOrg(Relationship, String, List)} where the value of the
     * {@link Relationship} argument is set to {@link Relationship#PARENT_OF}. Implementations must respect the equivalence
     * of these two semantics.
     * </p>
     * 
     * @param targetOrgId	a {@link String} representing the unique identifier for which an instance of <i>T</i> will be	
     * 						spawn and bound to. It cannot be {@literal null} or an empty string.
     * @param permissions	a {@link List} containing the set of permissions that need to be attributed to the spawned
     * 						entity while operating in the target organisation. These determines the set of operations that 
     * 						the spawned instance can perform in the organisation. It cannot be {@literal null}.
     * 
     * @return 	an instance of <i>T</i> configured to operate as an identity in the organisation identified by <i>targetOrgId</i>
     * 			with the specified permission. If the operation is successful, this reference it is guaranteed to not to be
     * 			{@literal null}.
     * 
     * @throws GuaranteeForbiddenException	if the required operation is not allowed because the conditions for impersonation
     * 										are not met. These can be:
     * 										<ul>
     * 										<li>there isn't a parent subsidiary relationship among the organisatio bound
     * 										to the current instance, and the organisation identified by <i>targetOrgId</i>
     * 										<li>there is a parent subsidiary relationship but the required permissions are
     * 										is not allowed by the relationship</li>
     * 										<li>the specific user associated to the current spawnable does not have roles
     * 										in the target organisation that allow him/her to perform the operations allowed
     * 										by the permissions specified</li>
     * 										</ul>
     * 
     * @throws IllegalArgumentException		if <i>targetOrgId</i> is {@literal null} or an empty string, or <i>permissions</i>
     * 										is {@literal null}.
     * 
     * @see Spawnable#forOrg(String, Permission)
     * @see Spawnable#forOrg(Relationship, String, List)
     * @see Spawnable#forOrg(Relationship, String, Permission)
     * 
     */
    T forOrg(String targetOrgId, List<Permission> permissions) throws GuaranteeForbiddenException;

    /**
     * <p>
     * Spawns an instance of <i>T</i> for the given organisation, and configures it with the given <i>permissions</i>.
     * This method constrains the spawning  operation to the specific type of relationship identified by <i>relationship</i>.
     * </p>
     * <p>
     * This method is a facilitation to invoke {@link Spawnable#forOrg(Relationship, String, List)} where the third
     * argument is constructed by creating an empty list and adding <i>permission</i> to it. Implementation must
     * respect the equivalence of the semantics.
     * </p>
     * 
     * @param relationship	a {@lik Relationship} value that indicates the specific role of the organisation bound to the
     * 						current instance, is expected to have in the relationship. It cannot be {@literal null}.
     *     
     * @param targetOrgId	a {@link String} representing the unique identifier for which an instance of <i>T</i> will be	
     * 						spawn and bound to. It cannot be {@literal null} or an empty string.
     * @param permission	a {@link Permission} value that indicates the specific permission that need to be set to the
     * 						spawn instance. This determines the set of operations that the spawned instance can perform
     * 						in the organisation. It cannot be {@literal null}.
     * 
     * @return 	an instance of <i>T</i> configured to operate as an identity in the organisation identified by <i>targetOrgId</i>
     * 			with the specified permission. If the operation is successful, this reference it is guaranteed to not to be
     * 			{@literal null}.
     * 
     * @throws GuaranteeForbiddenException	if the required operation is not allowed because the conditions for impersonation
     * 										are not met. These can be:
     * 										<ul>
     * 										<li>there isn't a parent subsidiary relationship among the organisatio bound
     * 										to the current instance, and the organisation identified by <i>targetOrgId</i>
     * 										<li>there is a parent subsidiary relationship but the required permissions are
     * 										is not allowed by the relationship</li>
     * 										<li>the specific user associated to the current spawnable does not have roles
     * 										in the target organisation that allow him/her to perform the operations allowed
     * 										by the permissions specified</li>
     * 										</ul>
     * 
     * @throws IllegalArgumentException		if <i>targetOrgId</i> is {@literal null} or an empty string, <i>permission</i>
     * 										is {@literal null}, or <i>relationship</i> is {@literal null}.
     * 
     * @see Spawnable#forOrg(String, Permission)
     * @see Spawnable#forOrg(Relationship, String, List)
     * @see Spawnable#forOrg(Relationship, String, Permission)
     */
    T forOrg(Relationship relationship, String targetOrgId, Permission permission) throws GuaranteeForbiddenException;

    /**
     * <p>
     * Spawns an instance of <i>T</i> for the given organisation, and configures it with the given <i>permission</i>.
     * This method is used within the context of the parent-subsidiary organisation where the current identity is used
     * to impersonate an identity in the organisation defined by <i>targetOrgId</i>.
     * </p>
     * <p>
     * This method is a short form of {@link Spawnable#forOrg(Relationship, String, Permission)} where the value of the
     * {@link Relationship} argument is set to {@link Relationship#PARENT_OF}. Implementations must respect the equivalence
     * of these two semantics.
     * </p>
     * 
     * @param targetOrgId	a {@link String} representing the unique identifier for which an instance of <i>T</i> will be	
     * 						spawn and bound to. It cannot be {@literal null} or an empty string.
     * @param permission	a {@link Permission} value that indicates the specific permission that need to be set to the
     * 						spawn instance. This determines the set of operations that the spawned instance can perform
     * 						in the organisation. It cannot be {@literal null}.
     * 
     * @return 	an instance of <i>T</i> configured to operate as an identity in the organisation identified by <i>targetOrgId</i>
     * 			with the specified permission. If the operation is successful, this reference it is guaranteed to not to be
     * 			{@literal null}.
     * 
     * @throws GuaranteeForbiddenException	if the required operation is not allowed because the conditions for impersonation
     * 										are not met. These can be:
     * 										<ul>
     * 										<li>there isn't a parent subsidiary relationship among the organisatio bound
     * 										to the current instance, and the organisation identified by <i>targetOrgId</i>
     * 										<li>there is a parent subsidiary relationship but the required permission is
     * 										is not allowed by the relationship</li>
     * 										<li>the specific user associated to the current spawnable does not have roles
     * 										in the target organisation that allow him/her to perform the operations allowed
     * 										by the permissions specified</li>
     * 										</ul>
     * 
     * @throws IllegalArgumentException		if <i>targetOrgId</i> is {@literal null} or an empty string, or <i>permission</i>
     * 										is {@literal null}.
     * 
     * @see Spawnable#forOrg(String, List)
     * @see Spawnable#forOrg(Relationship, String, List)
     * @see Spawnable#forOrg(Relationship, String, Permission)
     * 
     */
    T forOrg(String targetOrgId, Permission permission) throws GuaranteeForbiddenException;
}
