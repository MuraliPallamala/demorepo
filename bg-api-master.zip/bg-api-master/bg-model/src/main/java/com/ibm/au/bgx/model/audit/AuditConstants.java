package com.ibm.au.bgx.model.audit;

/**
 * <p>
 * Class <b>AuditConstants</b>. This class defines of constants that are of support
 * to the auditing activities.
 * </p>
 * <p>
 * The primary use of this constants is for determining the content of the payload of 
 * audit events, so that they can be interpreted correctly and cast it back to their 
 * corresponding Java types. Since the auditing infrastructure is a generic service
 * there is the need to implement some sort of loose typing to facilitate the storage
 * and management of the information added to the audit events.
 * </p>
 * 
 * @author Peter Ilfrich
 */
public interface AuditConstants {
	

    /****************************************************************************
     *                  DEFINITION OF THE AUDITING ATTRIBUTES                   *
     ****************************************************************************/

	/**
	 * A {@link String} constant that identifies the field in the audit event
	 * payload that stores information about the user profile. This information
	 * is reference in case of new user onboarding, user role updates, removal
	 * of a user, update of the user password, and any other auditable action
	 * that involves a single user.
	 * 
     * @see AuditConstants#AUDIT_DATA_STATUS
     * @see AuditConstants#AUDIT_DATA_ROLE
	 */
    String AUDIT_DATA_USER = "user";
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload storing information about the status of the user that is audited
     * in the event. This information is added to the audit event during the
     * onboarding of a user, or when the status of a user is modified. 
     * 
     * @see AuditConstants#AUDIT_DATA_USER
     * @see AuditConstants#AUDIT_DATA_ROLE
     */
    String AUDIT_DATA_STATUS = "status";
    /**
     * A {@link String} constant that identifies the file in the audit event
     * payload that stores information about user roles. This information is 
     * often added when the information about the user profile is update or 
     * when the roles of the user are modified.
     * 
     * @see AuditConstants#AUDIT_DATA_USER
     * @see AuditConstants#AUDIT_DATA_STATUS
     */
    String AUDIT_DATA_ROLE = "role";
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload that stores information about user updates performed by an
     * administrator.
     * 
     * @see AuditConstants#AUDIT_DATA_USER
     */
    String AUDIT_DATA_USER_PROFILE_REQUEST = "userProfileRequest";
    /**
     * A {@link String} constant that identifies the field in the audit event 
     * payload that stores a reference to the batch process identifier that
     * has performed user role / status updates.
     * 
     * @see AuditConstants#AUDIT_DATA_USER
     * @see AuditConstants#AUDIT_DATA_ROLE
     * @see AuditConstants#AUDIT_DATA_STATUS
     */
    String AUDIT_DATA_BATCH_PROCESS_ID = "batchProcessId";
    
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload that stores information about the organisation being audited.
     * This used to track the onboarding of an organisation as well as the
     * requests for changing registered details of an organisation or its
     * relationships.
     * 
     * @see AuditConstants#AUDIT_DATA_ORGCHANGE_REQUEST
     * @see AuditConstants#AUDIT_DATA_ONBOARDING_REQUEST
     * @see AuditConstants#AUDIT_DATA_ORG_REQUEST_ACTION_ID
     */
    String AUDIT_DATA_ORGANIZATION = "organization";
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload that stores a reference to an onboarding request. This field is
     * primarily used to track the onboarding of organisation into the platform.
     */
    String AUDIT_DATA_ONBOARDING_REQUEST = "onboardingRequest";
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload that stores a reference to the request for updating an organisation.
     * This could be in the context of an update of its registered details or in
     * the context of creating or updating a parent-subsidiary relationship.
     * 
     * @see AuditConstants#AUDIT_DATA_ORG_REQUEST_ACTION_ID
     */
    String AUDIT_DATA_ORGCHANGE_REQUEST = "orgChangeRequest";
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload that stores a reference to a particular action performed against
     * an organisation change request. This field is often used in conjunction
     * with the organisation and request references.
     * 
     * @see AuditConstants#ORGANIZATION
     * @see AuditConstants#ORG_CHANGE_REQUEST
     */
    String AUDIT_DATA_ORG_REQUEST_ACTION_ID = "actionId";
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload that stores information about the approval model set in an
     * organisation. This used to track approval model updates in an organisation.
     */
    String AUDIT_DATA_APPROVAL_MODEL = "approvalModel";
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload that stores information about the bank accounts associated to
     * an organisation. This field is used to track those organisation management
     * activities aimed at adding, removing, or updating bank account details.
     */
    String AUDIT_DATA_BANK_ACCOUNT = "bankAccount";
    
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload that stores information about a bank guarantee. For instance all
     * the auditable action that involve an existing guarantee executed through
     * request will have a reference to the corresponding guarantee.
     * 
     * @see AuditConstants#AUDIT_DATA_GX_REQUEST
     */
    String AUDIT_DATA_GX = "gx";
    /**
     * A {@link String} constant that identifies the field in the audit event
     * payload that stores information about a bank guarantee request. Any
     * auditable action that is associated to a bank guarantee request will store
     * a reference to the corresponding request.
     * 
     * @see AuditConstants#AUDIT_DATA_GX
     */
    String AUDIT_DATA_GX_REQUEST = "gxRequest";
    
    
    /****************************************************************************
     *                   DEFINITION OF THE AUDITING TYPES                       *
     ****************************************************************************/

    /**
     * A {@link String} constant that is used to identify the type of those audit
     * events whose target entity is the user profile.
     */
    String USER_PROFILE = "UserProfile";
    /**
     * A {@link String} constant that is used to identity the type of those audit
     * events whose target entity is an organisation.
     */
    String ORGANIZATION = "Organisation";
    /**
     * A {@link String} constant that is used to identify the type of those audit
     * events whose target entity is the bank account that is configured within an
     * organisation.
     */
    String BUSINESS_ACCOUNT = "BankAccount";
    /**
     * A {@link String} constant that is used to identify the type of those audit
     * events whose target entity is the onboarding request. This type of events
     * track all those actions that are required for onboarding an organisation.
     */
    String ORG_ONBOARDING_REQUEST = "OrgProfileRequest";
    /**
     * A {@link String} constant that is used to identify the type of those audit
     * events whose target entity is the onboarding action.
     */
    // [CV] TODO: verify the use of this constant
    String ONBOARDING_ACTION = "OrgRequestAction";
    /**
     * A {@link String} constant that is used to identify the type of those audit
     * events whose target entity are requests for changing the public details of
     * an organisation or for linking/unlinking an organisation in a parent-subsidiary
     * relationship. 
     */
    String ORG_CHANGE_REQUEST = "OrgChangeRequest";
    /**
     * A {@link String} constant that is used to identify the type of those audit
     * events whose target entity are organisation roles.
     */
    String ROLE = "Role";
    /**
     * A {@link String} constant that is used to identify the type of those audit
     * events whose target entity is the approval model. For instance events of
     * this type capture the configuration of the approval model or its update.
     */
    String APPROVAL_MODEL = "ApprovalModel";
    /**
     * A {@link String} constant that is used to identity the type of those audit 
     * events whose target entity is a bank guarantee.
     */
    String GUARANTEE = "Gx";
    /**
     * A {@link String} constant that is used to identity the type of those audit 
     * events whose target entity is a bank guarantee request.
     */
    String GX_REQUEST = "GxRequest";
}
