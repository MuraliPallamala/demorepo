package com.ibm.au.bgx.model;

import com.ibm.au.bgx.model.pojo.task.BatchProcessTask.Type;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public class BgxConstants {

	/**
	 * 
	 */
    // disable public constructor
    private BgxConstants() {
    }

    /**
     * 
     */
    public static final String BOOTSTRAP_ORG_CERT = "cert";

    /**
     * 
     */
    public static final String CRYPTO_PUBLIC_KEY = "publicKey";

    /**
     * 
     */
    public static final String CRYPTO_PRIVATE_KEY = "privateKey";

    /**
     * 
     */
    public static final String BOOTSTRAP_ORG_ID = "id";

    /**
     * 
     */
    public static final String BOOTSTRAP_ORG_API_URL = "apiUrl";

    /**
     * 
     */
    public static final String HEADER_BOOTSTRAP_MARKER = "X-DLT-Bootstrap";

    /**
     * 
     */
    public static final String HEADER_OPENID_AUTHORIZATION_CODE = "X-DLT-OIDC-Authorization-Code";

    /**
     * 
     */
    public static final String HEADER_OPENID_REFRESH_TOKEN = "X-DLT-OIDC-Refresh-Token";

    /**
     * 
     */
    public static final String BOOTSTRAP_USER_REDIRECT_URI_LIST = "userRedirectUriList";

    /**
     * 
     */
    public static final String BOOTSTRAP_USER_TEMP_SECRET = "userTempSecret";

    /**
     * 
     */
    public static final String SERVICE_READY = "serviceReady";

    /**
     * 
     */
    public static final String KEY_DEFAULT = "default";

    /**
     * 
     */
    public static final String KEY_ORG_ID = "orgId";

    /**
     * 
     */
    public static final String KEY_USER_EMAIL = "email";


    /**
     * API auth client is prefixed as below.
     */
    public static final String API_AUTH_CLIENT_PREFIX = "service-account";

    /**
     * 
     */
    public static final String ONBOARDED_ORGANIZATION = "organization";

    /**
     * Default property value for properties that do not have meaningful default values
     */
    public static final String PROPERTY_NOT_SET = "PROP_NOT_SET";

    /**
     * 
     */
    public static final int ORG_KEY_LEN = 4;

    /**
     * 
     */
    public static final int USER_KEY_LEN = 6;

    /**
     * 
     */
    public static final int SIGNUP_TOKEN_LEN = 4;
    
    /**
     * 
     */
    public static final String KEY_REDIRECT_URI = "redirectUri";

    /**
     * 
     */
    public static final String KEY_TOKEN = "token";

    /*
     * Constants for Oauth2 and OIDC fields used in headers, requests and responses.
     */
    
    /**
     * 
     */
    public static final String OAUTH_ACCESS_TOKEN = "access_token";

    /**
     * 
     */
    public static final String OAUTH_REFRESH_TOKEN = "refresh_token";

    /**
     * 
     */
    public static final String OAUTH_ISS = "iss";

    /**
     * 
     */
    public static final String OAUTH_CLIENT_ID = "client_id";

    /**
     * 
     */
    public static final String OAUTH_CLIENT_SECRET = "client_secret";

    /**
     * 
     */
    public static final String OAUTH_GRANT_TYPE = "grant_type";

    /**
     * 
     */
    public static final String OAUTH_CLIENT_CREDENTIALS_GRANT_TYPE = "client_credentials";

    /**
     * 
     */
    public static final String OAUTH_PASSWORD_GRANT_TYPE = "password";

    /**
     * 
     */
    public static final String OAUTH_USERNAME = "username";

    /**
     * 
     */
    public static final String OAUTH_PASSWORD = "password";

    /**
     * 
     */
    public static final String JWT_USERNAME = "preferred_username";

    /**
     * 
     */
    public static final String JWT_ACCESS_TOKEN= "access_token";

    /**
     * 
     */
    public static final String AUTHORIZATION_HEADER = "Authorization";

    /**
     * 
     */
    public static final String BEARER_PREFIX = "Bearer ";

    /**
     * 
     */
    public static final String OPENID_SCOPE = "openid";

    /**
     * 
     */
    public static final String KEY_REFERRER_ID = "referrerId";

    /**
     * 
     */
    public static final String KEY_USER_PROFILE = "userProfile";

    /**
     * 
     */
    // Ref: https://stackoverflow.com/questions/19605150/regex-for-password-must-contain-at-least-eight-characters-at-least-one-number-a
    // Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character
    public static final String PASSWORD_REGEX = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!\"\\\\#$%&'()*+,-./:;<=>?@\\[\\]\\{\\}\\|^ _`\\{\\}|~]).{8,}$";
    /**
     * Fabric user fields
     */
    public static final String FABRIC_USER = "fabricUser";
    /**
     * 
     */
    public static final String FABRIC_USER_NAME = "name";
    /**
     * 
     */
    public static final String FABRIC_USER_AFFILIATION = "affiliation";
    /**
     * 
     */
    public static final String FABRIC_USER_MSP_ID = "mspId";
    /**
     * 
     */
    public static final String FABRIC_USER_ORG_ID = "orgId";
    /**
     * 
     */
    public static final String FABRIC_USER_ENROLLMENT_SECRET = "enrollmentSecret";
    /**
     * 
     */
    public static final String FABRIC_USER_ENROLLMENT_CERT = "enrollmentCert";
    /**
     * 
     */
    public static final String FABRIC_USER_ENROLLMENT_KEY = "enrollmentKey";

    // Meta information about the subsidiary
    /**
     * 
     */
    public static final String FABRIC_USER_RELATIONSHIP_ID = "relationshipId";
    /**
     * 
     */
    public static final String FABRIC_USER_SUBSIDIARY_ORG_ID = "subsidiaryOrgId";


    /**
     * Various constants for notification payload
     */
    public static final String NOTIFICATION_TYPE = "notificationType";
    /**
     * 
     */
    public static final String USER_COMPLETED_ONBOARDING = "userCompletedOnboarding";
    /**
     * 
     */
    public static final String USER_REJECTED_ONBOARDING = "userRejectedOnboarding";

    /**
     * User fields
     * 
     * @return
     */
    // Allowed fields for update
    public static final List<String> allowedUserFieldsForUpdate = Arrays.asList(
            BgxConstants.USER_FIRST_NAME,
            BgxConstants.USER_LAST_NAME,
            BgxConstants.USER_PHONE,
            BgxConstants.USER_ROLES,
            BgxConstants.GX_LIMIT
    );

    /**
     * List of restricted roles
     * <p>
     * It is not possible to create users of these roles without special permission or settings
     * 
     * @return
     */
    public static final List<String> restrictedRoles = Arrays.asList(
            BgxConstants.ROLE_PRIMARY,
            BgxConstants.ROLE_ADMIN
    );

    /**
     * List of roles that are required for approval model
     * 
     * @return
     */
    public static final List<String> orgApprovalModelDefaultRoles = Arrays.asList( BgxConstants.ROLE_USER );

    /**
     * 
     */
    public static final String USER_FIRST_NAME = "firstName";
    /**
     * 
     */
    public static final String USER_LAST_NAME = "lastName";
    /**
     * 
     */
    public static final String USER_PHONE = "phone";
    /**
     * 
     */
    public static final String USER_ROLES = "userRoles";
    /**
     * 
     */
    public static final String GX_LIMIT = "gxLimit";

    /**
     * 
     */
    public static final String ROLE_ADMIN = "ADMIN";
    /**
     * 
     */
    public static final String ROLE_PRIMARY = "PRIMARY";
    /**
     * 
     */
    public static final String ROLE_USER = "USER";

    /**
     * 
     */
    public static final String OTP_ENCODED_SECRET = "secret";
    /**
     * 
     */
    public static final String OTP_TOKEN = "token";

    /**
     * Task related constants
     */

    public static final String TASK = "task";

    /**
     * 
     */
    public static final String TASK_ID = "taskId";

    /**
     * 
     */
    public static final String TASK_SCOPE_ROLE = "role";

    /**
     * 
     */
    public static final String TASK_SCOPE_ROLE_USER = "USER";

    /**
     * 
     */
    public static final long MAX_TASK_BATCH_SIZE = 100;

    /**
     * 
     */
    public static final String TASK_FOR_ALL = "_";


    /**
     * 
     */
    public static final List<Type> VALID_USER_TASK_TYPES = Collections.unmodifiableList(Arrays.asList( Type.UPDATE_USER_ROLES, Type.SET_USER_STATUS ));

    /**
     * Default error messages
     */

    /**
     * 
     */
    public static final String ERR_RECORD_NOT_FOUND = "%s not found with ID '%s'"; // User not found with ID 'XYZ'
    
    /**
     * 
     */
    public static final String ERR_INVALID = "%s '%s' is invalid"; // Parameter 'XYZ' is invalid


    /**
     * API keys related constants
     */
    public static final String USER_API_KEY_PREFIX = "APIKEY-";

    /**
     * Network Sync notification related
     */
    public static final String NETWORK_SYNC_PAYLOAD= "payload";

    /**
     * 
     */
    public static final String NETWORK_SYNC_REMOTE_ORG_ID = "orgId";

    /**
     * 
     */
    public static final String NETWORK_SYNC_REMOTE_ORG_API_AUTH = "apiAuth";

    /**
     * 
     */
    public static final String NETWORK_SYNC_REMOTE_ORG_API_URL = "apiUrl";


    /**
     * For OrganizationBound components config
     */
    public static final String CONFIG_PERMISSIONS = "permissions";

    /**
     * Parent Subsidiary related constants to be put in Meta
     *
     */

    public static final String META_TARGET_ORG_ID = "targetOrgId";

    /**
     * 
     */
    public static final String META_PRINCIPAL_ORG_ID = "primaryOrgId";

    /**
     * Encryption related fields in meta
     */
    public static final String META_ENCRYPTION_VERSION = "encryptionVersion";

    /**
     * 
     */
    public static final String META_ENCRYPTION_DATE= "encryptionDate";

    /**
     * 
     */
    public static final String META_PRIVATE_KEY = "privateKey";

    /**
     * 
     */
    public static final String META_CERT = "cert";

    /**
     * 
     */
    public static final String META_ENROLLMENT_SECRET = "enrollmentSecret";

    /**
     * 
     */
    public static final String META_RESTRICTED = "restricted";

    /**
     * 
     */
    public static final String META_PAYLOAD = "payload";

    /**
     * Default MAX GX LIMIT is -1 instead of null
     */
    public static final BigInteger UNLIMITED_GX_LIMIT = BigInteger.valueOf(-1);

    // We use Long.MAX, because Gx amount values are converted into long before it is sent to chain
    // FIXME Maybe we should change the amount fields from BigInteger to Long
    // However we call GxUtil.validateGxLimitValue in order to validate that we store a valid limit
    /**
     * 
     */
    public static final BigInteger MAX_POSSIBLE_GX_LIMIT = BigInteger.valueOf(Long.MAX_VALUE);


    /**
     * 
     */
    public static final String SYSTEM_USER = "SYSTEM";

    /**
     * 
     */
    public static final String ANONYMOUS_USER = "ANONYMOUS";


    /**
     * 
     */
    public static final int ABN_LENGTH = 11;

    /**
     * 
     */
    public static final int ACN_LENGTH = 9;


    /**
     * Some constants for document stores meta data about the document
     */
    public static final String META_CONTENT_TYPE = "contentType";

    /**
     * 
     */
    public static final String META_FILE = "file";

    
    
	/**
	 * Name of the vertical representing applicants and beneficiaries.
	 */
	public static final String APPLICANT_BENEFICIARY_VERTICAL_NAME = "newco";
}

