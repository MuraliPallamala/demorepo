package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.UserProfile;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest;
import com.ibm.au.bgx.model.pojo.api.response.OrgRequestActionResponse;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface NewCoAdminOnboardingClient {

	/**
	 * 
	 * @param key
	 * @param token
	 * @return
	 * @throws ServiceUnavailableException
	 */
    OrgProfileRequest getOnboardingDetails(String key, String token) throws ServiceUnavailableException;

    /**
     * 
     * @param request
     * @param key
     * @param token
     * @param actionRequest
     * @return
     * @throws ServiceUnavailableException
     */
    OrgRequestActionResponse sendConfirmAction(OrgProfileRequest request, String key, String token, OrgRequestActionRequest actionRequest) throws ServiceUnavailableException;

    /**
     * 
     * @param requestId
     * @return
     * @throws ServiceUnavailableException
     */
    String getToken(String requestId) throws ServiceUnavailableException;

    /**
     * 
     * @param requestId
     * @param key
     * @param token
     * @return
     * @throws ServiceUnavailableException
     */
    boolean removeOnboardingRequest(String requestId, String key, String token) throws ServiceUnavailableException;

    /**
     * 
     * @param userProfile
     * @param key
     * @param token
     * @return
     * @throws ServiceUnavailableException
     */
    OrgRequestActionResponse sendCompleteSignupNotification(UserProfile userProfile, String key, String token) throws ServiceUnavailableException;

    /**
     * 
     * @param orgId
     * @param rejectUserEmail
     * @throws ServiceUnavailableException
     */
    void sendAdminUserRejection(String orgId, String rejectUserEmail) throws ServiceUnavailableException;
}
