package com.ibm.au.bgx.model.web;

import com.ibm.au.bgx.model.Entity;

/**
 * Interface <b>SockerEndpoint</b>. This interface represents a simple endpoint
 * of for a client web socket, which is used to abstract away from the application
 * logic the details of the implementation an expose only those capabilities that
 * are of interest to the application logic. These are essentially the capabilities
 * for sending messages of different types through a specific session.
 * 
 * @author Peter Ilfrich
 */
public interface SocketEndpoint {

	/**
	 * <p>
	 * Sends a simple string message to the client web socket connected to the session
	 * identified by the given <i>sessionId</i>.
	 * </p>
	 * <p>
	 * Implementations are expected to lookup the web client socket session identified
	 * by <i>sessionId</i> and if this does not match any existing session, quietly
	 * terminate the method.
	 * </p>
	 * 
	 * @param sessionId		a {@link String} representing the unique identifier of the
	 * 						client web socket session where to send the message. It
	 * 						cannot be {@literal null} or an empty string, and it should
	 * 						identify an existing session.
	 * @param message		a {@link String} representing the message to be sent.
	 */
	// [CV] TODO: enforce constraints on sessionId (!= null, not empty) --> IllegalArgumentException
    // [CV] TODO: enforce constraints on message (!= null) --> IllegalArgumentException
    void send(String sessionId, String message);

    /**
     * <p>
     * Sends a message to the client web socket connected to the session identified by
     * the given <i>sessionId</i> where the message sent is represented by the given
     * entity.
	 * </p>
	 * <p>
	 * Implementations are expected to lookup the web client socket session identified
	 * by <i>sessionId</i> and if this does not match any existing session, quietly
	 * terminate the method.
	 * </p>
     * 
	 * 
	 * @param sessionId		a {@link String} representing the unique identifier of the
	 * 						client web socket session where to send the message. It
	 * 						cannot be {@literal null} or an empty string, and it should
	 * 						identify an existing session.
     * @param message		a {@link Entity} representing the information that will be
     * 						sent to the client web socket.
     */
	// [CV] TODO: enforce constraints on sessionId (!= null, not empty) --> IllegalArgumentException
    // [CV] TODO: enforce constraints on message (!= null) --> IllegalArgumentException
    void send(String sessionId, Entity message);

    /**
     * <p>
     * Sends a message to the client web socket connected to the session identified by
     * the given <i>sessionId</i> where the message sent is represented by a generic
     * object.
	 * </p>
	 * <p>
	 * Implementations are expected to lookup the web client socket session identified
	 * by <i>sessionId</i> and if this does not match any existing session, quietly
	 * terminate the method.
	 * </p>
	 * 
	 * @param sessionId		a {@link String} representing the unique identifier of the
	 * 						client web socket session where to send the message. It
	 * 						cannot be {@literal null} or an empty string, and it should
	 * 						identify an existing session.
     * @param message		a {@link Object} reference representing to instance to
     * 						send to the web socket client.
     */
	// [CV] TODO: enforce constraints on sessionId (!= null, not empty) --> IllegalArgumentException
    // [CV] TODO: enforce constraints on message (!= null) --> IllegalArgumentException
    void send(String sessionId, Object message);

}
