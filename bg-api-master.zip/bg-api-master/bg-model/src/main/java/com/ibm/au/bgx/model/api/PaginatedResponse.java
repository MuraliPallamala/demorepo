package com.ibm.au.bgx.model.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.time.Instant;
import java.util.List;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * A wrapper class for paginated API response
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * @param <T> 
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "result",
    "next",
    "timestamp"
})
public class PaginatedResponse<T> {

	/**
	 * 
	 */
    @JsonProperty("result")
    private List<T> result;

    /**
     * 
     */
    @JsonProperty("timestamp")
    private String timestamp;

    /**
     * 
     */
    @JsonProperty("next")
    private String next;

    /**
     * 
     */
    @JsonCreator
    public PaginatedResponse() {
        this.timestamp = Instant.now().toString();
    }

    /**
     * 
     * @param result
     */
    public PaginatedResponse(List<T> result) {
        super();
        this.result = result;
    }

    /**
     * 
     * @param result
     * @param next
     */
    public PaginatedResponse(List<T> result, String next) {
        super();
        this.result = result;
    }

    /**
     * 
     * @return
     */
    public List<T> getResult() {
        return this.result;
    }

    /**
     * 
     * @param result
     */
    public void setResult(List<T> result) {
        this.result = result;
    }

    /**
     * 
     * @return
     */
    public String getTimestamp() {
        return this.timestamp;
    }

    /**
     * 
     * @param ts
     */
    public void setTimestamp(String ts) {
        this.timestamp = ts;
    }

    /**
     * 
     * @return
     */
    public String getNext() {
        return this.next;
    }

    /**
     * 
     * @param next
     */
    public void setNext(String next) {
        this.next = next;
    }

    /**
     * 
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    /**
     * 
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(result).append(timestamp).toHashCode();
    }
}
