package com.ibm.au.bgx.model;

import com.ibm.au.bgx.model.user.BgxPrincipal;

/**
 * @author Peter Ilfrich
 */
public abstract class AbstractPrincipalProvider implements PrincipalProvider {

	/**
	 * 
	 */
    private BgxPrincipal principal;

    /**
     * 
     */
    @SuppressWarnings("unused")
	private AbstractPrincipalProvider() {
        // avoid instantiating this without principal or org
    }

    /**
     * 
     * @param principal
     */
    protected AbstractPrincipalProvider(BgxPrincipal principal) {
        if (principal == null) {
            throw new IllegalArgumentException("Missing principal when creating principal-bound manager");
        }

        this.principal = principal;
    }

    /**
     * 
     */
    @Override
    public BgxPrincipal getPrincipal() {
        return this.principal;
    }

}
