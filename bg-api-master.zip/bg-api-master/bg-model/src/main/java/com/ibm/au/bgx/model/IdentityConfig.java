package com.ibm.au.bgx.model;

/**
 * @author Peter Ilfrich
 */
public interface IdentityConfig {

	/**
	 * 
	 * @return
	 */
    boolean isNewCoAdmin();

    /**
     * 
     * @return
     */
    boolean isIssuer();

    /**
     * 
     * @return
     */
    String getPortalUrl();

    /**
     * 
     * @return
     */
    String getNewcoPortalUrl();

    /**
     * 
     * @return
     */
    String getInternalUrl();

    /**
     * 
     * @return
     */
    String getIdentity();

    /**
     * 
     * @param identity
     */
    void setIdentity(String identity);

    /**
     * 
     * @return
     */
    String getFabricUser();
}
