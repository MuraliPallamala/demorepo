package com.ibm.au.bgx.model.chain.profile;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.api.request.OnboardingRequest;
import com.ibm.au.bgx.model.pojo.api.response.OnboardingResponse;
import com.ibm.au.bgx.model.pojo.onboarding.OrgRequestAction;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest.Type;

import java.util.List;

/**
 * Interface <b>OrgProfileRequestManager</b>. Extends {@link ProfileRequestManager} and specialises
 * the interface for the management of onboarding requests (i.e. {@link OrgProfileRequest}). This
 * interface enriches the base definition with methods to:
 * <ul>
 * <li>retrieve organisation onboarding request by various attributes, acting as unique identifiers</li>
 * <li>facilitate the creation of requests from other types</li>
 * <li>validate the access to requests based on the credentials provided</li>
 * </ul>
 * This component is used primarily during the onboarding process of an organisation across multiple
 * verticals (user, issuer, admin) in different capacity.
 * 
 * @see ProfileRequestManager
 * @see OrgProfileRequest
 * @see OnboardingRequest
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public interface OrgProfileRequestManager extends ProfileRequestManager<OrgProfileRequest> {

    /**
     * A {@link String} constant that is used to build the payload of notifications associated
     * to onboarding request. In particular, this is used to store the information about the 
     * action that has approved the onboarding request, which is sent from the administrative
     * vertical to the user vertical to complete the onboarding process, or to the issuer vertical
     * in case of approval or rejectio of the request.
     */
    String KEY_ACTION = "action";
    /**
     * A {@link String} constant that contains the key used to store the information about the 
     * reject reason for a specific onboarding request. This is an attribute of the payload
     * associated to the rejection action that is submitted by the administrative staff of the
     * platform and it is further propagated to the primary contact of the organisation via
     * an email communication.
     */
    String KEY_REJECT_REASON = "reason";
    /**
     * A {@link String} constant that is used to build the payload of notifications associated
     * to onboarding request. In particular, this key is used to represent the attribute that
     * is storing the unique identifier of an approved request in the notification that is sent
     * by the administrative vertical to the user vertical as a result of an approval of the
     * onboarding request.
     */
    String KEY_REQUEST_ID = "requestId";
    /**
     * A {@link String} constant that is used as attribute identifier (i.e. key) in the payload
     * of actions of type {@link ActionType#VERIFY} to store the information about the entity that 
     * is being verified.
     */
    String KEY_VERIFY_OBJECT = "verifyObject";
    /**
     * A {@link String} constant that is used as attribute value for the attribute {@link #KEY_VERIFY_OBJECT}
     * in the notification paylod of actions of type {@link ActionType#VERIFY} to specify which entity is
     * being verified by the current action. More specifically, to identify the company details as the
     * information being verified.
     */
    String VALUE_VERIFY_COMPANY = "CompanyDetails";
    /**
     * A {@link String} constant that is used as attribute value for the attribute {@link #KEY_VERIFY_OBJECT}
     * in the notification paylod of actions of type {@link ActionType#VERIFY} to specify which entity is
     * being verified by the current action. More specifically, to identify the primary contact as the
     * information being verified.
     */
    String VALUE_VERIFY_PRIMARY_CONTACT = "PrimaryContact";

    /**
     * A {@link String} constant that is used as attribute value for the attribute {@link #KEY_VERIFY_OBJECT}
     * in the notification paylod of actions of type {@link ActionType#VERIFY} to specify which entity is
     * being verified by the current action. More specifically, to identify the organisation administrator as 
     * the information being verified.
     */
    String VALUE_VERIFY_ADMIN_CONTACT = "AdminContact";
    


    /**
     * This method creates a local organisation profile request, based on the result of the submission of the
     * onboarding request to the administrative vertical. This operation is used in the context of the user and
     * issuer verticals to create a local copy of the onboarding request based on the submission of the client
     * and the result received by the administrative staff as a result of the forwarding of the request. This
     * capability supports both self-onboarding and assisted onboarding.
     *
     * @param onboardingRequest 	a {@link OnboardingRequest} instance representing the onboarding request that
     * 								has been submitted by the client containing the organisation profile of the
     * 								organisation to onboard and eventually the information about a referrer in
     * 								case of assisted onboarding. It cannot be {@literal null}.
     * 
     * @param adminResponse 		a {@link OnboardingResponse} instance representing the response that has been
     * 								received by the administrative vertical as a result of the forwarding of the
     * 								the given <i>onboardingRequest</i>. It cannot be {@literal null}.
     * 
     * @return	the updated information about the organisation profile once it has been entered into the system.
     * 			It is guaranteed to not to be {@literal null} and to be a valid organisation profile.
     * 
     * @throws IllegalArgumentException	if <i>onboardingRequest</i> or <i>adminResponse</i> is {@literal null}.
     */
    OrgProfileRequest create(OnboardingRequest onboardingRequest, OnboardingResponse adminResponse);

    /**
     * Retrieves onboarding requests by business identifier. The operation also includes the ability to specify
     * the identifier of the referrer and the status.
     * 
     * @param referrerId 	a {@link String} representing the unique identifier of the organisation that referred
     * 						the onboarding request of interest. It cannot be {@literal null} or an empty string.
     * 
     * @param bid 			a {@link String} representing the business identifier associated to the organisation
     * 						that is being onboarded through the request. It cannot be {@literal null} or an empty
     * 						string.
     * 
     * @param status 		a {@link Status} value representing the filter to apply to the status of the request to
     * 						retrieve. It cannot be {@literal null}.
     * 
     * @return 	a {@link List} implementation that contains all the {@link OrgProfileRequest} instances matching the
     * 			specified selection criteria. It is guaranteed to not to be {@literal null} but it can be empty.
     * 
     * @throws	IllegalArgumentException	if one of the following conditions are met:
     * 										<ul>
     * 										<li><i>referrerId</i> is {@literal null} or an empty string</li>
     * 										<li><i>bid</i> is {@literal null} or an empty string</li>
     * 										<li><i>status</i> is {@literal null}</li>
     * 										</ul>
     * 
     * @see OrgProfileRequestManager#getByBusinessId(String, String)
     */
    List<OrgProfileRequest> getByBusinessId(String referrerId, String bid, Status status);

    /**
     * Retrieves onboarding requests by business identifier. The operation also includes the ability to specify
     * the identifier of the referrer.
     * 
     * @param referrerId 	a {@link String} representing the unique identifier of the organisation that referred
     * 						the onboarding request of interest. It cannot be {@literal null} or an empty string.
     * 
     * @param bid 			a {@link String} representing the business identifier associated to the organisation
     * 						that is being onboarded through the request. It cannot be {@literal null} or an empty
     * 						string.
     * 
     * @return 	a {@link List} implementation that contains all the {@link OrgProfileRequest} instances matching the
     * 			specified selection criteria. It is guaranteed to not to be {@literal null} but it can be empty.
     * 
     * @throws	IllegalArgumentException	if one of the following conditions are met:
     * 										<ul>
     * 										<li><i>referrerId</i> is {@literal null} or an empty string</li>
     * 										<li><i>bid</i> is {@literal null} or an empty string</li>
     * 										</ul>
     * 
     * @see OrgProfileRequestManager#getByBusinessId(String, String, Status)
     */
    List<OrgProfileRequest> getByBusinessId(String referrerId, String bid);

    /**
     * Retrieves onboarding requests that have been submitted by a specific organisation on behalf of others.
     * This is identified by the unique identifier of the organisation in the platform.
     * 
     * @param referrerId 	a {@link String} representing the unique identifier of the organisation that referred
     * 						the onboarding request of interest. It cannot be {@literal null} or an empty string.
     * 
     * @return 	a {@link List} implementation that contains all the {@link OrgProfileRequest} instances matching the
     * 			specified selection criteria. It is guaranteed to not to be {@literal null} but it can be empty.
     * 
     * @throws	IllegalArgumentException	if <i>referrerId</i> is {@literal null} or an empty string.
     * 
     * @see OrgProfileRequestManager#getByReferrerIdAndStatus(String, Status)
     * 
     */
    List<OrgProfileRequest> getByReferrerId(String referrerId);

    /**
     * Retrieves onboarding requests that have been submitted by a specific organisation on behalf of others.
     * This is identified by the unique identifier of the organisation in the platform. The method also includes
     * the ability to specify the status of the request to retrieve.
     * 
     * @param referrerId 	a {@link String} representing the unique identifier of the organisation that referred
     * 						the onboarding request of interest. It cannot be {@literal null} or an empty string.
     * 
     * @param status 		a {@link Status} value representing the filter to apply to the status of the request to
     * 						retrieve. It cannot be {@literal null}.
     * 
     * @return 	a {@link List} implementation that contains all the {@link OrgProfileRequest} instances matching the
     * 			specified selection criteria. It is guaranteed to not to be {@literal null} but it can be empty.
     * 
     * @throws	IllegalArgumentException	if one of the following conditions are met:
     * 										<ul>
     * 										<li><i>referrerId</i> is {@literal null} or an empty string</li>
     * 										<li><i>status</i> is {@literal null}</li>
     * 										</ul>
     * 
     * @see OrgProfileRequestManager#getByReferrerId(String)
     * 
     */
    List<OrgProfileRequest> getByReferrerIdAndStatus(String referrerId, Status status);

    /**
     * Retrieves a specific onboarding request by searching for the provided unique referral token.
     * The referral token is a unique identifier that identifies an onboarding request. This is set
     * for an onboarding request that has been prepared through facilitated onboarding and it is an
     * additional identifier that is used for request retrieval.
     * 
     * 
     * @param referralToken 	a {@link String} representing the referrer token. This is usually in
     * 							the form of a {@link UUID} serialised into a string. It cannot be 
     * 							{@literal null} or an empty string.
     * 
     * @return 	an {@link OrgProfileRequest} that matches the given <i>referralToken</i>. If not {@literal 
     * 			null} then {@link OrgProfileRequest#getReferrer()} returns a non {@literal null} instance
     * 			with the value of {@link ReferrerInfo#getReferrerToken()} matching <i>referralToken</i>.
     */
    OrgProfileRequest getByReferralToken(String referralToken);

    /**
     * Retrieves an onboarding request based on the given <i>key<i>,<i>token</i> pair. These are the security
     * credentials that are used in place of the unique identifier of the request to retrieve it. This method
     * allows to implement additional access control to the request: if the value of <i>token</i> does not match
     * the stored value of the token for the request retrieved by using <i>key</i>, the value {@literal null}
     * will be returned, thus negating the access to the request.
     * 
     * @param key 		a {@link String} representing the key associated to an anboarding request. This is a 
     * 					random alphanumeric string composed by 6 characters that is generated by the system
     * 					upon submission of the onboarding request and that is communicated via email to the
     * 					primary contact of the prospective organisation. It cannot be {@literal null} or an
     * 					empty string.
     * 
     * @param token 	a {@link String} representing the security PIN associated to an onboarding request. This
     * 					is a random numeric string composed by 4 characters that is generated by the system at
     * 					different stages and communicated (eventually) to the primary contact to the prospective
     * 					organisation. It cannot be {@literal null} or an empty string.
     * 
     * @return	an instance of {@link OrgProfileRequest} that matches the given pair  <i>key</i>,<i>token</i> or
     * 			{@literal null} if there is none. 
     * 
     * @throws IllegalArgumentException if <i>key</i> or <i>token</i> is {@literal null} or an empty string.
     */
    OrgProfileRequest getByOnboardingKey(String key, String token);

    /**
     * Adds an action to the onboarding request. This method is meant to the check the validity of the action
     * with respect to the status of the request that is identified by <i>id</i>. More specifically:
     * <ul>
     * <li>actions of type {@link ActionType#CANCEL} can only be submitted if the corresponding request is 
     * in the {@link Status#DRAFTED} status. This operation also causes the request status to be changed to
     * {@link Status#ABANDONED}.</li>
     * <li>actions of type {@link ActionType#CONFIRM} can only be submitted if the corresponding request is 
     * in the {@link Status#DRAFTED} status. This operation also causes the request status to be changed to
     * {@link Status#CONFIRMED}.</li>
     * <li>actions of type {@link ActionType#VERIFY} can only be submitted if the corresponding request is 
     * in the {@link Status#CONFIRMED} status and must have a paylod that correctly verifies one of the allowed
     * entitites of the onboarding request</li>
     * <li>actions of type {@link ActionType#REVOKE} can only be submitted if the corresponding request is 
     * in the {@link Status#CONFIRMED} status and must reference a corresponding action of type {@link 
     * ActionType#VERIFY}</li>
     * <li>actions of type {@link ActionType#APPROVE} can only be submitted if the corresponding request is 
     * in the {@link Status#CONFIRMED} status and after unrevoked actions of type {@link ActionType#VERIFY} 
     * for all the entities that are to be verified in an onboarding request. This operation also causes the 
     * request status to be changed to {@link Status#APPROVED}.</li>
     * <li>actions of type {@link ActionType#REJECT} can only be submitted if the corresponding request is 
     * in the {@link Status#CONFIRMED} status. This operation also causes the request status to be changed to
     * {@link Status#REJECTED}.</li>
     * </ul>
     * 
     * @param id 		a {@link String} representing the unique identifier of the request to add the action
     * 					to. It cannot be {@literal null} or an empty string, and it must identify an existing
     * 					request.
     * 
     * @param action 	a {@link OrgRequestAction} representing the action to add to the request. It cannot be
     * 					{@literal null} and it must represent a valid and consistent action with the status of
     * 					the request.
     * 
     * @return	an instance of {@link OrgProfileRequest} that represents the request identifier by <i>id</i>
     * 			updated by the given <i>action</i>. It is guaranteed to not to be {@literal null}.
     * 
     * @throws	IllegalArgumentException	if <i>id</i> is {@literal null} or an empty string, or <i>action</i>
     * 										is {@literal null}.
     * @throws 	DataNotFoundException		if <i>id</i> does not match an existing request.
     * @throws 	IllegalStateException		if <i>action</i> is not allowed or incosistent with the current
     * 										status of the request identified by <i>id</i>.
     */
    OrgProfileRequest addOnboardingAction(String id, OrgRequestAction action);

    /**
     * Determines whether the given pair <i>key</i>,<i>token</i> provides access to an existing request. A
     * possible implementation for this operation is the retrieval of an onboarding request via the given
     * <i>key</i> and the verification that the associated tokens matches the given <i>token</i>. The pair
     * <i>key</i>,<i>token</i> is used to refer to an oboarding request without disclosing the associated
     * unique system identifier and to provide access control for that request.
     * 
     * @param key 		a {@link String} representing the key associated to an anboarding request. This is a 
     * 					random alphanumeric string composed by 6 characters that is generated by the system
     * 					upon submission of the onboarding request and that is communicated via email to the
     * 					primary contact of the prospective organisation. It cannot be {@literal null} or an
     * 					empty string.
     * 
     * @param token 	a {@link String} representing the security PIN associated to an onboarding request. This
     * 					is a random numeric string composed by 4 characters that is generated by the system at
     * 					different stages and communicated (eventually) to the primary contact to the prospective
     * 					organisation. It cannot be {@literal null} or an empty string.
     * 
     * @return  {@literal true} if the request identified by <i>id</i> has a security token that matches the
     * 			given <i>token</i>,  {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException if <i>key</i> or <i>token</i> is {@literal null} or an empty string.
     */
    boolean validateTokenForKey(String key, String token);

    /**
     * Determines whether the given access <i>token</i> is associated to the specified request identified by 
     * <i>id</i>. This operation is used to ensure that the access to an onboarding request is only granted to 
     * the entity that is required to confirm it.
     * 
     * @param id 		a {@link String} representing the unique identifier of the request. It cannot
     * 					be {@literal null} or an empty string, and it must identify an existing
     * 					onboarding request.
     * 
     * @param token 	a {@link String} representing the security PIN associated to an onboarding request. This
     * 					is a random numeric string composed by 4 characters that is generated by the system at
     * 					different stages and communicated (eventually) to the primary contact to the prospective
     * 					organisation. It cannot be {@literal null} or an empty string.
     * 
     * @return 	{@literal true} if there exist a request identified by <i>key</i> and this has a security PIN that 
     * 			matches the given <i>token</i>, {@literal false} otherwise.
     * 
     * @throws IllegalArgumentException if <i>id</i> or <i>token</i> is {@literal null} or an empty string.
     * @throws DataNotFoundException if there is not request matching the given <i>id</i>.
     */
    boolean validateTokenForId(String id, String token);

}
