package com.ibm.au.bgx.model.identityprovider;

import com.ibm.au.bgx.model.exception.IdentityProviderException;
import java.util.Map;

/**
 * OTP client for OTP API provided by our custom keycloak module bg-keycloak-otp
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface OtpClient {

    /**
     * Get OTP setup include secret and QR code for the user
     *
     * @param realmName
     * @param email
     * @return
     * @throws IdentityProviderException
     */
    Map<String, Object> generateOtpSetup(String realmName, String email) throws IdentityProviderException;

    /**
     * Set OTP secret for the user
     * @param realmName
     * @param email
     * @param encodedSecret
     * @param token
     * @throws IdentityProviderException
     */
    void setOtp(String realmName, String email, String encodedSecret, String token) throws IdentityProviderException;

    /**
     * Delete OTP seed of the user
     *
     * @param realmName
     * @param email
     * @return
     * @throws IdentityProviderException
     */
    void deleteOtp(String realmName, String email) throws IdentityProviderException;

}
