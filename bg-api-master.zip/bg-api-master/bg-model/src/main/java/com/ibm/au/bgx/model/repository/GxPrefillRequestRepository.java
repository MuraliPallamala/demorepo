package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;

import java.util.List;

/**
 * 
 * @author fl0yd
 *
 */
public interface GxPrefillRequestRepository extends DefaultRepository<GxPrefillRequest> {

	/**
	 * 
	 * @param orgId
	 * @param gxRequestId
	 * @return
	 */
    List<GxPrefillRequest> find(String orgId, String gxRequestId);
}
