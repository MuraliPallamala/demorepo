package com.ibm.au.bgx.model.chain.gx;

import com.ibm.au.bgx.model.exception.ProfileChainException;
import com.ibm.au.bgx.model.exception.ProfileNotFoundException;
import com.ibm.au.bgx.model.pojo.gx.*;

/**
 * 
 *
 */
public interface FullEntitiesConverter {

	/**
	 * 
	 * @param gx
	 * @return
	 * @throws ProfileNotFoundException
	 * @throws ProfileChainException
	 */
    GxFullEntities from(Gx gx) throws ProfileNotFoundException, ProfileChainException;

    /**
     * 
     * @param gxRequest
     * @return
     * @throws ProfileNotFoundException
     * @throws ProfileChainException
     */
    GxRequestFullEntities from(GxRequest gxRequest) throws ProfileNotFoundException, ProfileChainException;

    /**
     * 
     * @param gxAction
     * @return
     * @throws ProfileNotFoundException
     * @throws ProfileChainException
     */
    GxActionFullEntities from(GxAction gxAction) throws ProfileNotFoundException, ProfileChainException;
}