package com.ibm.au.bgx.model.chain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ibm.au.bgx.model.Entity;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.validation.Valid;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hyperledger.fabric.sdk.Enrollment;
import org.hyperledger.fabric.sdk.User;

/**
 * Class <b>ChannelUser</b>. This class implements the {@link User} interface and
 * provides setters to configure the information about the entity. It also provides
 * capabilities to store enrollment secrets. A {@link ChannelUser} represents the
 * identity that is used to sign transactions that are submitted within the context
 * of a channel. This user usually identifies a specific organisation within the 
 * Bank Guarantee platform.
 *
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
@JsonIgnoreProperties(value = {"enrolled"})
public class ChannelUser extends Entity implements User, Serializable {

	/**
	 * This field provides information to the deserialisation runtime about the 
	 * specific version of the class the serialised instance belongs to. This is
	 * to ensure that when serialising instances across JVMs the same version of
	 * the class defining the instance is used.
	 */
    private static final long serialVersionUID = 4031273059307226662L;

    // [CV] NOTE: this needs to be made serialisable.
    //
	/**
	 * A {@link Map} implementation that contains additional attributes associated
	 * to the user. 
	 */
    @JsonProperty("meta")
    @Valid
    private Map<String, Object> meta;

    /**
     * A {@link String} containing the id of the user. Cannot be {@literal null}.
     * By default it is computed as name@orgDomain
     */
    private String id;

    /**
     * A {@link String} containing the name of the user. Cannot be {@literal null}.
     */
    private String name;
    
    /**
     * A {@link Set} implementation that contains the collection of roles that the
     * user has.
     */
    private Set<String> roles;
    
    /**
     * A {@link String} representing the user account.
     */
    private String account;
    
    /**
     * A {@link String} representing the user affiliation. This parameter contains
     * the organization the user belongs to.
     *
     * This is like org1.department1, org2.department2 etc. as set in CA config
     */
    private String affiliation;
    
    /**
     * A {@link String} representing the user org domain. This parameter contains
     * the organization the user belongs to.
     *
     * This is like org1.example1.com, org2.example2.com etc.
     */
    private String orgDomain;
    
    /**
     * A {@link String} representing the secret used to enroll the user with the
     * membership services.
     */
    private String enrollmentSecret;
    
    /**
     * A {@link Enrollment} instance providing the information about the user
     * enrollment with the membership services.
     */
    private BgxDefaultEnrollment enrollment;
    
    /**
     * A {@link String} representing the unique identifier of the membership services
     * provider used to enroll/verify the user.
     */
    private String mspID;

    /**
     * A {@link Boolean} describing if the user is active or not
     */
    private boolean activeStatus;

    /**
     * A {@link String} describing the org the user belongs to
     */
    private String orgId;

    /**
     * Initialises an instance of {@link ChannelUser} with the given <i>name</i>
     * and <i>affiliation</i> and identifier of the membership provider.
     *
     * @param name 			a {@link String} containing the name of the user. It cannot be {@literal null}.
     * @param affiliation 	a {@link String} containing the name of the affiliation.
     * @param mspId 		a {@link String} containing the unique identifier of the membership provider.
     * 
     * @throws IllegalArgumentException if <i>name</i> is {@literal null} or <i>affiliation</i> is
     * 									{@literal null}.
     */
    @JsonCreator
    public ChannelUser(
    		@JsonProperty("name") String name,
    		@JsonProperty("affiliation") String affiliation,
    		@JsonProperty("mspId") String mspId
    	) {

        if (name == null) {
            throw new IllegalArgumentException("Parameter 'name' cannot be null.");
        }
        if (affiliation == null) {
            throw new IllegalArgumentException("Parameter 'affiliation' cannot be null.");
        }

        this.name = name;
        this.affiliation = affiliation;
        this.mspID = mspId;
        this.activeStatus = true;
        this.id = String.format("%s@%s", this.getName(), this.getMspId());
        this.meta = new HashMap<>();
    }

    /**
     * Gets the name of the user.
     *
     * @return 	a {@link String} representing the unique identifier of the user. 
     * 			It cannot be {@literal null}.
     */
    @Override
    public String getName() {

        return this.name;
    }

    /**
     * Gets the roles that the user belongs to.
     *
     * @return a {@link String} set containing the list of roles of the user.
     */
    @Override
    public Set<String> getRoles() {

        return this.roles;
    }

    /**
     * Gets the account for the user.
     *
     * @return a {@link String} representing the user account.
     */
    @Override
    public String getAccount() {

        return this.account;
    }

    /**
     * Gets the affiliation of the user.
     *
     * @return a {@link String} representing the organization the user belongs to.
     */
    @Override
    public String getAffiliation() {

        return this.affiliation;
    }

    /**
     * Sets the organisation domain of the user.
     * 
     * @param orgDomain 	a {@link String} contanining the organisation of the user.
     */
    public void setOrgDomain(String orgDomain) {

        this.orgDomain = orgDomain;
    }

    /**
     * Gets the org domain of the user.
     *
     * @return a {@link String} representing the organization the user belongs to.
     */
    public String getOrgDomain() {

        return this.orgDomain;
    }

    /**
     * Gets the enrollment for the current user. An enrollment contains the private key information
     * and the certificate that the user received when enrolled with the membership services provider.
     *
     * @return	an {@link BgxDefaultEnrollment} implementation that contains the details of the user
     * 			enrollment with the membership services.
     */
    @Override
    public BgxDefaultEnrollment getEnrollment() {

        return this.enrollment;
    }

    /**
     * Gets the unique identifier of the membership services provider used to enroll the user.
     *
     * @return 	a {@link String} representing the unique identifier of the membership services
     * 			provider.
     */
    @Override
    public String getMspId() {

        return this.mspID;
    }

    /**
     * Gets the enrollment secret received upon registration with the membership services provider. 
     * This secret is used then to further retrieve the enrollment certificate to sign transactions.
     *
     * @return 	a {@link String} representing the enrollment certificate, {@literal null} if the user
     * 			has not been registered yet.
     */
    public String getEnrollmentSecret() {

        return this.enrollmentSecret;
    }


    /**
     * Checks whether the user is enrolled. If the user is enrolled it has
     * received an enrollment certificate from the membership services provider
     * that has verified his identity. This is just a convenience method to
     * check whether {@link ChannelUser#getEnrollment()} returns {@literal
     * null}.
     *
     * @return {@literal true} if the user has a configured {@link Enrollment}
     */
    public boolean isEnrolled() {

        return this.getEnrollment() != null;
    }

    /**
     * Sets the roles that the user belongs to.
     *
     * @param roles a {@link Set} implementation that contains the list of roles the user belongs
     * to.
     */
    public void setRoles(Set<String> roles) {

        this.roles = roles;
    }

    /**
     * Sets the account for the user.
     *
     * @param account a {@link String} representing the user account.
     */
    public void setAccount(String account) {

        this.account = account;
    }

    /**
     * Sets the enrollment for the user. This contains the information about
     * the private key and the corresponding certificate associated to the
     * user upon enrollment.
     *
     * @param enrollment a {@link BgxDefaultEnrollment} implementation.
     */
    public void setEnrollment(BgxDefaultEnrollment enrollment) {

        this.enrollment = enrollment;
    }

    /**
     * Sets the unique identifier of the membership services provider that
     * provides information about the user, can verify its credentials, and
     * erogate enroll certificate for him/her.
     *
     * @param mspID a {@link String} representing the membership services provider identifier.
     */
    public void setMspId(String mspID) {

        this.mspID = mspID;
    }


    /**
     * Sets the enrollment secret received upon registration with
     * the membership provider. This secret is used to retrieve
     * the enrollment certificate from the membership services
     * provider.
     *
     * @param secret a {@link String} representing the enrollment certificate.
     */
    public void setEnrollmentSecret(String secret) {

        this.enrollmentSecret = secret;
    }

    /**
     * Sets the unique identifier of the channel user.
     * 
     * @param id	a {@link String} representing the unique identifier of the 
     * 				channel user. It is expected to not to be {@literal null}.
     */
    @Override
    public void setId(String id) {

        this.id = id;
    }

    /**
     * Sets the name of the user.
     * 
     * @param name 	a {@link String} representing the name of the user. It is
     * 				expected to not to be {@literal null}.
     * 
     * @return 	a {@link String} representing the user name just set.
     */
    public String setName(String name) {
        this.name = name;
        return this.name;
    }

    /**
     * Gets the unique identifier of the {@link ChannelUser}. This is computed as the 
     * name of the user followed by <i>@</i> and the name of the affiliation.
     *
     * @return a {@link String} containing the unique identifier of the user.
     */
    @Override
    public String getId() {

        return this.id;

    }

    /**
     * Set the status of the user. 
     * 
     * @param status 	a {@literal boolean} value that indicates whether the user is
     * 					active (i.e. {@literal true}) or not (i.e. {@literal false}).
     */
    public void setActiveStatus(boolean status) {
        this.activeStatus = status;
    }

    /**
     * Gets the status of the user.
     * 
     * @return 	a {@literal boolean} value that indicates whether the user is
     * 			active (i.e. {@literal true}) or not (i.e. {@literal false}).
     */
    public boolean getActiveStatus() {
        return this.activeStatus;
    }

    /**
     * Sets the unique identifier of the organisation associated to the current channel user.
     * This represents the unique identifier of the Blockchain organisation that the user belongs 
     * to. In a scenario where this instance is used to connect to the channel from the issuer or 
     * the administrative vertical, the organisation represents the corresponding Blockchain 
     * organisation, in the scenario where this instance is used to connect to the channel from the
     * user vertical, this organisation represents the "umbrella" organisation that represents all
     * the user organisations in the platform.
     * 
     * @param orgId a {@link String} representing the unique identifier of the organisation.
     * 				
     */
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    /**
     * Gets the unique identifier of the organisation associated to the current channel user.
     * In a scenario where this instance is used to connect to the channel from the issuer or 
     * the administrative vertical, the organisation represents the corresponding Blockchain 
     * organisation, in the scenario where this instance is used to connect to the channel from 
     * the user vertical, this organisation represents the "umbrella" organisation that represents 
     * all the user organisations in the platform.
     * 
     * @return  {@link String} representing the unique identifier of the blockchain organisation
     * 			that the current instanc of the channel user belongs to.
     */
    public String getOrgId() {
        return this.orgId;
    }

    /**
     * Gets the additional attributes associated to the channel user.
     * 
     * @return	a {@link Map} implementation that can be used to store additional attributes in
     * 			the form of key-value pairs. This map can be {@literal null} if no attributes 
     * 			are defined.
     */
    @JsonProperty("meta")
    public Map<String, Object> getMeta() {
        return this.meta;
    }
    
    /**
     * Sets the collection of additional attributes associated to the channel user.
     * 
     * @param meta	a {@link Map} implementation that can be used to store additional attributes in
     * 				the form of key-value pairs. This map can be {@literal null} if no attributes 
     * 				are defined.
     */
    @JsonProperty("meta")
    public void setMeta(Map<String, Object> meta) {
        this.meta = meta;
    }

    /**
     * Gets the string representation for the user. This is set to be the unique identifier of
     * the channel user, which eventually contains information about the user name, and the
     * affiliation of the user (i.e. Blockchain organisation).
     *
     * @return 	a {@link String} in the form of an email address where the email name is the user
     * 			name and the email domain is the affiliation (if not {@literal null}).
     */
    @Override
    public String toString() {

        return this.getId();
    }

    /**
     * Creates an hash-code representation of the current {@link ChannelUser} instance.
     * 
     * @return 	a {@literal int} value that has been built by using {@link HashCodeBuilder} and
     * 			appending all the user properties in the following order: <i>id</i>, <i>name</i>,
     * 			<i>roles</i>, <i>account</i>, <i>affiliation</i>, <i>orgDomain</i>, <i>enrollmentSecret</i>,
     * 			<i>enrollment</i>, <i>mspID</i>, <i>activeStatus</i>, <i>orgId</i>, and <i>meta</i>. 
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(id)
            .append(name)
            .append(roles)
            .append(account)
            .append(affiliation)
            .append(orgDomain)
            .append(enrollmentSecret)
            .append(enrollment)
            .append(mspID)
            .append(activeStatus)
            .append(orgId)
            .append(meta)
            .toHashCode();
    }

    /**
     * Determines whether the given reference it is equal to the current {@link ChannelUser}.
     * The comparison is performed by first assessing whether <i>other</i> references the
     * current instance. If such test fails the method checks whether <i>other</i> is of an
     * instance of {@link ChannelUser} and if so it uses the {@link EqualsBuilder} class to
     * verify that both instances have the same properties.
     * 
     * @return 	{@literal true} if <i>other</i> is not {@literal null} and it references the
     * 			same instance as the current instance or it is a {@link ChannelUser} instance
     * 			with the same properties. {@literal false} otherwise.
     */
    @Override
    public boolean equals(java.lang.Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ChannelUser)) {
            return false;
        }
        ChannelUser rhs = ((ChannelUser) other);
        return new EqualsBuilder()
            .append(id, rhs.id)
            .append(name, rhs.name)
            .append(roles, rhs.roles)
            .append(account, rhs.account)
            .append(affiliation, rhs.affiliation)
            .append(orgDomain, rhs.orgDomain)
            .append(enrollmentSecret, rhs.enrollmentSecret)
            .append(enrollment, rhs.enrollment)
            .append(mspID, rhs.mspID)
            .append(activeStatus, rhs.activeStatus)
            .append(orgId, rhs.orgId)
            .append(meta, rhs.meta)
            .isEquals();
    }

}
