package com.ibm.au.bgx.model.chain;

import com.ibm.au.bgx.fabric.model.IbpConfig;
import com.ibm.au.bgx.model.guarantee.GXAPI;
import com.ibm.au.bgx.model.profile.OrganizationAPI;
import com.ibm.au.bgx.model.profile.PurposeFormatsAPI;
import com.ibm.au.bgx.model.profile.TermsConditionsAPI;

import java.util.List;

/**
 * Interface <b>ChannelSelector</b>. This component is responsible for providing chaincode access. 
 * It allows to read the configuration ({@link IbpConfig}) and creates a connector to Fabric. It 
 * uses a connector to enroll, register new users, enroll existing users and connect to channels 
 * providing chaincode.
 *
 * @author Peter Ilfrich
 * @author Lenin Mehedy
 */
public interface ChannelSelector {


    /**
     * Retrieves a connected instance of an {@link OrganizationAPI} (or Profile API) configured with
     * the identity represented by <i>userName</i>. The method will lookup the actual fabric-user in 
     * the offchain DB and register a new user, if the provided user name doesn't exist. It'll then 
     * connect as that user and return an instance of a connected {@link OrganizationAPI}.
     *
     * @param userName 		a {@link String} representing the identity that will be used to interact
     * 						with the channel associated to the organisation API. It is expected to not
     * 						to be {@literal null}.
     * 
     * @return 	a {@link OrganizationAPI} implementation that represents a connected instance to the channel
     * 			using the identity credentials represented by <i>userName</i>. This instance can be used to
     * 			interact with the smart contract capabilities that manage organisations on the ledger.
     * 
     * @throws Exception	if any error occurs during the setup of the organisation API.
     */
    OrganizationAPI getOrganisationApi(String userName) throws Exception;

    /**
     * Retrieves a connected instance of an {@link OrganizationAPI} (or Profile API) configured with
     * the identity represented by <i>userName</i>. The method will lookup the actual fabric-user in 
     * the offchain DB and register a new user, if the provided user name doesn't exist. It'll then 
     * connect as that user and return an instance of a connected {@link OrganizationAPI}. This is an
     * overloaded version of {@link ChannelSelector#getOrganisationApi(String)} which allows for setting
     * the component's behaviour on disconnections.
     *
     * @param userName       	a {@link String} representing the channel user that will be used to
     * 							configure the organisation API. This represents the identity that will
     * 							sign and issue transactions in the underlying channel. It is expected 
     * 							to not to be {@literal null}.
     * 
     * @param forceReconnect 	a {@literal boolean} flag indicating whether to force a new connection or
     *                       	attempt to re-use an existing connection.

     * @return 	a {@link OrganizationAPI} implementation that represents a connected instance to the channel
     * 			using the identity credentials represented by <i>userName</i>. This instance can be used to
     * 			interact with the smart contract capabilities that manage organisations on the ledger.
     * 
     * @throws Exception	if any error occurs during the setup of the organisation API.
     */
    OrganizationAPI getOrganisationApi(String userName, boolean forceReconnect) throws Exception;

    /**
     * Retrieves a connected instance of a {@link PurposeFormatsAPI} (or Profile API) configured with
     * the identity represented by <i>userName</i>. The method will lookup the actual fabric-user in the 
     * offchain DB and register a new user, if the provided user name doesn't exist. It'll then connect 
     * as that user and return an instance of a connected {@link PurposeFormatsAPI}.
     *
     * @param userName      a {@link String} representing the channel user that will be used to configure 
     * 						the purpose format API. This represents the identity that will sign and issue
     *  					transactions in the underlying channel. It is expected to not to be {@literal 
     *  					null}.

     * @return 	a {@link PurposeFormatsAPI} implementation that represents a connected instance to the channel
     * 			using the identity credentials represented by <i>userName</i>. This instance can be used to
     * 			interact with the smart contract capabilities that manage purpose formats on the ledger.
     * 
     * @throws Exception	if any error occurs during the setup of the purpose format API.
     */
    PurposeFormatsAPI getPurposeFormatApi(String userName) throws Exception;

    /**
     * Retrieves a connected instance of an GuaranteeApi for a specific user and channel. The method
     * will lookup the actual fabric-user in the offchain DB and register a new user, if the
     * provided user name doesn't exist. It'll then connect as that user and return an instance of a
     * connected GuaranteeApi, which is connected to the provided channel.
     *
     * @param userName      a {@link String} representing the channel user that will be used to configure 
     * 						the purpose format API. This represents the identity that will sign and issue
     *  					transactions in the underlying channel. It is expected to not to be {@literal 
     *  					null}.
     *  
     * @param channelName 	a {@link String} representing the name of the channel to create the guarantee
     * 						API for. The guarantees in the platform are partitioned within channels, one
     * 						per each issuer. This parameter is expected to not to be {@literal null}.
     * 
     * @return 	a {@link GXAPI} implementation that represents a connected instance to the channel using the 
     * 			identity credentials represented by <i>userName</i>. This instance can be used to transact
     * 			on <i>channelName</i> to manage guarantees on the ledger.
     * 
     * @throws Exception	if any error occurs during the setup of the guarantee API.
     */
    GXAPI getGuaranteeApi(String userName, String channelName) throws Exception;

    /**
     * Retrieves a connected instance of an GuaranteeApi for a specific user and channel. The method
     * will lookup the actual fabric-user in the offchain DB and register a new user, if the provided
     * user name doesn't exist. It'll then connect as that user and return an instance of a connected 
     * {@link GXAPI}, which is connected to the provided channel. This is an overloaded version of the 
     * method {@link ChannelSelector#getGuaranteeApi(String, String)}.
     *
     * @param userName      a {@link String} representing the channel user that will be used to configure 
     * 						the guarantee API. This represents the identity that will sign and issue
     *  					transactions in the underlying channel. It is expected to not to be {@literal 
     *  					null}.
     *  
     * @param channelName 	a {@link String} representing the name of the channel to create the guarantee
     * 						API for. The guarantees in the platform are partitioned within channels, one
     * 						per each issuer. This parameter is expected to not to be {@literal null}.
     * 
     * @param forceReconnect 	a {@literal boolean} flag indicating whether to force a new connection or
     *                       	attempt to re-use an existing connection.
     * 
     * @return 	a {@link GXAPI} implementation that represents a connected instance to the channel using the 
     * 			identity credentials represented by <i>userName</i>. This instance can be used to transact
     * 			on <i>channelName</i> to manage guarantees on the ledger.
     * 
     * @throws Exception	if any error occurs during the setup of the guarantee API.
     */
    GXAPI getGuaranteeApi(String userName, String channelName, boolean forceReconnect) throws Exception;

    /**
     * Retrieves a connected instance of an GuaranteeApi for a specific user and channel. It'll then
     * connect as that user and return an instance of a connected GuaranteeApi, which is connected
     * to the provided channel. This method is similar to {@link ChannelSelector#getGuaranteeApi(String, 
     * String)} but uses a {@link ChannelUser} instance, rather than the username.
     *
     * @param user        	a {@link ChannelUser} instance representing the Blockchain identity to configure
     * 						the guarantee API with. It is expected to not to be {@literal null}.
     *  
     * @param channelName 	a {@link String} representing the name of the channel to create the guarantee
     * 						API for. The guarantees in the platform are partitioned within channels, one
     * 						per each issuer. This parameter is expected to not to be {@literal null}.
     * 
     * @return 	a {@link GXAPI} implementation that represents a connected instance to the channel using the 
     * 			identity credentials represented by <i>user</i>. This instance can be used to transact on
     * 			<i>channelName</i> to manage guarantees on the ledger.
     * 
     * @throws Exception	if any error occurs during the setup of the guarantee API.
     */
    GXAPI getGuaranteeApi(ChannelUser user, String channelName) throws Exception;

    /**
     * Retrieves a connected instance of an {@link TermsConditionsAPI} for a specific user. The method 
     * will lookup the actual fabric-user in the offchain DB and register a new user, if the provided
     * user name doesn't exist. It'll then connect as that user and return an instance of a connected 
     * {@link TermsConditionsAPI}.
     *
     * @param userName      a {@link String} representing the channel user that will be used to configure 
     * 						the terms and conditions API. This represents the identity that will sign and 
     * 						issue transactions in the underlying channel. It is expected to not to be {@literal 
     *  					null}.
     * 
     * @return 	a {@link TermsConditionsAPI} implementation that represents a connected instance to the 
     * 			channel using the identity credentials represented by <i>userName</i>. This instance can 
     * 			be used to transact on <i>channelName</i> to manage terms and conditions on the ledger.
     * 
     * @throws Exception	if any error occurs during the setup of the terms and conditions API.
     */
    TermsConditionsAPI getTermsConditionsApi(String userName) throws Exception;

    /**
     * This method retrieves the channel user that is identified by <i>userName</i>. This method may create
     * and register the user according to the value of <i>createIfNotFound</i> but <b>WILL NOT</b> enroll the
     * user with the corresponding CA of the organisation.
     *
     * @param userName      a {@link String} representing the name of the user to retrieve. It is expected to 
     * 						not to be {@literal null}
     * 
     * @param createIfNotFound 	a {@literal boolean} flag indicating whether in case the user is not present,
     * 							the metho should create it by registering a user with <i>userName</i>
     * 							(i.e {@literal true}) or not (i.e. {@literal false}).
     * 
     * @return a {@link ChannelUser} instance that represents the user that is identified by <i>userName</i>.
     * 
     * @throws Exception 	if any error occurs during the retrieval of the user.
     */	
    ChannelUser getUser(String userName, boolean createIfNotFound) throws Exception;

    /**
     * This method retrieves the channel user that is identified by <i>userName</i>. This method may create
     * and register the user according to the value of <i>createIfNotFound</i> but <b>WILL NOT</b> enroll the
     * user with the corresponding CA of the organisation. This method is an overloaded version of the method
     * {@link ChannelSelector#getUser(String, boolean)}, which allows for specifying the organisation for the
     * user, which may differ from the primary organisation of the user within the context of a parent-sub
     * relationship.
     *
     *
     * @param userName      a {@link String} representing the name of the user to retrieve. It is expected to 
     * 						not to be {@literal null}
     * @param orgId 		a {@link String} representig the unique identifier of the organisation for which
     * 						the user needs to be retrieved/created.
     * 
     * @param createIfNotFound 	a {@literal boolean} flag indicating whether in case the user is not present,
     * 							the metho should create it by registering a user with <i>userName</i>
     * 							(i.e {@literal true}) or not (i.e. {@literal false}).
     * 
     * @return a {@link ChannelUser} instance that represents the user that is identified by <i>userName</i>
     * 		   and <i>orgId</i>.
     * 
     * @throws Exception	if any error occurs during the setup of the guarantee API.
     */
    ChannelUser getUser(String userName, String orgId, boolean createIfNotFound) throws Exception;

    /**
     * Gets an enrolled user that can be used to interact with the Blockchain. Implementations of this method
     * are expected to register and enroll the given user if it has not been already registered and enrolled 
     * based on the value set for <i>createIfNotFound</i>. 
     *
     * @param userName         	the name of the user to retrieve. It is expected to not to be {@literal null}.
     * @param orgId            	the id of the organisation the user belongs to. It is expected to not to be {@literal 
     * 							null}.
     * @param createIfNotFound 	a {@literal boolean} flag indicating whether in case the user is not present,
     * 							the metho should create it by registering and enrolling a user with <i>userName</i>
     * 							(i.e {@literal true}) or not (i.e. {@literal false}).
     * 
     * @return a {@link ChannelUser} instance that represents the user identified by <i>userName</i> and <i>orgId</i>.
     * 
     * @throws Exception	if any error occurs during the retrieval of the user.
     */
    ChannelUser getEnrolledUser(String userName, String orgId, boolean createIfNotFound) throws Exception;

    /**
     * Retrieve the channel admin user. An administrative user is a user that has capabilities of
     * creating and registering other users.
     * 
     * @return 	a {@link ChannelUser} instance that represents the administrative user.
     */
    ChannelUser getAdminUser();

    /**
     * Retrieves a list of available channels configured in this API. This method only returns the 
     * list of channels where the guarantees smart contract are deployed. This method is used to 
     * provide a uniform access method to the channel configuration for guarantees across verticals.
     * Issuer verticals will only have one channel, while the user vertical will retrieve as many
     * channels as there are issuers on the platform.
     *
     * @return a {@link List} containing the names of the channels that are configured with the APIs.
     */
    List<String> getChannelNameList();

    /**
     * Retrieves the name of the platform channel (also known as profile channel). This channel stores
     * the information (and associated smart contracts governing its lifecycle) of platform-wide entities
     * such as <i>organisations</i>, <i>terms and conditions</i>, and <i>purpose formats</i>.
     * 
     * @return 	a {@link String} representing the name of the platform channel. It is expected to not to
     * 			be {@literal null}.
     */
    String getProfileChannelName();

    // [CV] TODO: Check whether we need to expose this method, because they are only used by the 
    //            implementations of this interface internally, to implement reconnection behaviour.
    //
    /**
     * Retrieves a connected instance of an {@link OrganizationAPI} (or Profile API) configured with
     * the identity represented by <i>userName</i>. The method will lookup the actual fabric-user in 
     * the offchain DB and register a new user, if the provided user name doesn't exist. It'll then 
     * connect as that user and return an instance of a connected {@link OrganizationAPI}. 
     *
     *
     * @param userName 		a {@link String} representing the identity that will be used to interact
     * 						with the channel associated to the organisation API. It is expected to not
     * 						to be {@literal null}.

     * @return 	a {@link OrganizationAPI} implementation that represents a connected instance to the channel
     * 			using the identity credentials represented by <i>userName</i>. This instance can be used to
     * 			interact with the smart contract capabilities that manage organisations on the ledger.
     * 
     * @throws Exception	if any error occurs during the setup of the organisation API.
     */
    OrganizationAPI connectOrganizationApi(String userName) throws Exception;


    // [CV] TODO: Check whether we need to expose this method, because they are only used by the 
    //            implementations of this interface internally, to implement reconnection behaviour.
    //
    /**
     * Retrieves a connected instance of an GuaranteeApi for a specific user and channel. The method
     * will lookup the actual fabric-user in the offchain DB and register a new user, if the
     * provided user name doesn't exist. It'll then connect as that user and return an instance of a
     * connected GuaranteeApi, which is connected to the provided channel.
     *
     * @param userName      a {@link String} representing the channel user that will be used to configure 
     * 						the purpose format API. This represents the identity that will sign and issue
     *  					transactions in the underlying channel. It is expected to not to be {@literal 
     *  					null}.
     *  
     * @param channelName 	a {@link String} representing the name of the channel to create the guarantee
     * 						API for. The guarantees in the platform are partitioned within channels, one
     * 						per each issuer. This parameter is expected to not to be {@literal null}.
     * 
     * @return 	a {@link GXAPI} implementation that represents a connected instance to the channel using the 
     * 			identity credentials represented by <i>userName</i>. This instance can be used to transact
     * 			on <i>channelName</i> to manage guarantees on the ledger.
     * 
     * @throws Exception	if any error occurs during the setup of the guarantee API.
     */
    GXAPI connectGuaranteeApi(String userName, String channelName) throws Exception;
}
