package com.ibm.au.bgx.model.web;

/**
 * <p>
 * Interface <b>SocketEndpoint</b>. It handles the technical aspects of the connection such as authorization and
 * establishment the connection. This interface provides methods to hook the technical {@link SocketEndpoint} into 
 * the business-knowing queue-handler component for web notifications. 
 * </p>
 * <p>
 * It provides methods to register and deregister sessions as they are created, creating a bridge between session 
 * ID, which is relevant to actually send web socket messages and user ID, which is relevant to actually figure out 
 * which websocket session to send messages to (routing).
 * </p>
 *
 * @author Peter Ilfrich
 */
public interface SocketHandler {

    /**
     * Configures the handler with the given endpoint for dispatching messages to the associated
     * client web socket.
     *
     * @param endpoint 	a {@link SocketEndpoint} implementation that represents the client web socket
     * 					to send messages to. It cannot be {@literal null}.
     * 
     * @throws IllegalArgumentException if <i>endpoint</i> is {@literal null}
     */
	// [CV] TODO: enforce constraints endpoint != null -> IllegalArgumentException.
    void setEndpoint(SocketEndpoint endpoint);

    /**
     * Associates the given session id to the give user. This method links the session that is
     * connected to a particular web socket client to the user that has been extracted from the
     * client identity of the session. As most of the web notifications can target specific user
     * it is important to establish a mapping between the session identifier and the related user.
     *
     * @param sessionId	a {@link String} representing the unique identifier of the session
     * 					associated to the user. It cannot be {@literal null} or an empty
     * 					string.
     * 
     * @param userId	a {@link String} representing the unique identifier of the user
     * 					It cannot be {@literal null} or an empty string. 
     * 
     * @throws IllegalArgumentException	one of the following occurs:
     * 									<ul>
     * 									<li><i>sessionId<i> is {@literal null}</li>
     * 									<li><i>userId</i> is {@literal null}</li>
     * 									</ul>
     */
	// [CV] TODO: enforce constraints on  sessionId (!= null, not empty) -> IllegalArgumentException.
	// [CV] TODO: enforce constraints on  userId (!= null, not empty) -> IllegalArgumentException.
    void registerSession(String sessionId, String userId);

    /**
     * Terminates a client session. This method removes the mapping between the session identifier
     * and the associated user.
     *
     * @param sessionId a {@link String} representing the unique identifier of the session associated
     * 					to a particular web client socket. It cannot be {@literal null} or an empty
     * 					string.
     * 
     * @throws IllegalArgumentException	if <i>sessionId</i> is {@literal null}
     */
	// [CV] TODO: enforce constraints on  sessionId (!= null, not empty) -> IllegalArgumentException.
    void closeSession(String sessionId);
}
