package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.audit.AuditEvent;
import java.util.List;

/**
 * @author Peter Ilfrich
 */
public interface AuditEventRepository extends DefaultRepository<AuditEvent> {

	/**
	 * 
	 * @param type
	 * @return
	 */
    List<AuditEvent> findByType(String type);

    /**
     * 
     * @param type
     * @param orgId
     * @param beforeDate
     * @param afterDate
     * @return
     */
    List<AuditEvent> findByTypeAndOrgId(String type, String orgId, String beforeDate, String afterDate);

    /**
     * 
     * @param orgId
     * @param beforeDate
     * @param afterDate
     * @return
     */
    List<AuditEvent> findByOrgId(String orgId, String beforeDate, String afterDate);

    /**
     * 
     * @param orgId
     * @param userId
     * @param beforeDate
     * @param afterDate
     * @return
     */
    List<AuditEvent> findByUser(String orgId, String userId, String beforeDate, String afterDate);

    /**
     * 
     * @param gxId
     * @param beforeDate
     * @param afterDate
     * @return
     */
    List<AuditEvent> findByGuarantee(String gxId, String beforeDate, String afterDate);

    /**
     * 
     * @param targetOrgId
     * @param beforeDate
     * @param afterDate
     * @return
     */
    List<AuditEvent> findByTargetOrgId(String targetOrgId, String beforeDate, String afterDate);

    /**
     * 
     * @param type
     * @param targetOrgId
     * @param beforeDate
     * @param afterDate
     * @return
     */
    List<AuditEvent> findByTypeAndTargetOrgId(String type, String targetOrgId, String beforeDate, String afterDate);
}
