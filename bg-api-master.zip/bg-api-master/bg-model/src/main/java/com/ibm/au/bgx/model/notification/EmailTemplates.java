/**
 * 
 */
package com.ibm.au.bgx.model.notification;

/**
 * Class <b>EmailTemplates</b>. This class defines the collection of constants that
 * are used to specify the templates to use for a given email.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class EmailTemplates {

	/**
	 * This is a private constructor to prevent that instances of this class are created. This
	 * class is essentially a wrapper of constant values, hence there is no need to have instances.
	 */
	EmailTemplates() {}
	
	/**
	 * This is the unique identifier utilised to reference the template configured for sending
	 * the email notifying the coming expiration of a bank guarantee.
	 */
	public static final String EXPIRATION_NOTICE_TEMPLATE_ID 			= 	"guarantee.expiration";
	/**
	 * This is the unique identifier utilised to reference the template configured for sending
	 * the email about the acceptance of an onboarding application, to the primary contact of 
	 * that organisation.
	 */
	public static final String ONBOARDING_ACCEPTED_TEMPLATE_ID 			=	"onboarding.accepted";
	/**
	 * This is the unique identifier utilised to reference the template configured for sending
	 * the email about the rejection of an onboarding application, to the primary contact of 
	 * that organisation.
	 */
	public static final String ONBOARDING_REJECTED_TEMPLATE_ID  		=   "onboarding.rejected";
	/**
	 * This is the unique identifier utilised to reference the template configured for sending
	 * the email to the primary contact of an onboarded organisation once onboarding process is
	 * completed and the primary contact can access the platform to complete the setup of his/her
	 * account (e.g. password setup).
	 */
	public static final String ONBOARDING_FIRST_LOGIN_TEMPLATE_ID		=	"onboarding.first.login";
	/**
	 * This is the unique identifier utilised to reference the template configured for sending
	 * the email about the primary contact of an organisation whose onboarding request was accepted
	 * to remind him/her to complete the setup process.
	 */
	public static final String ONBOARDING_REMINDER_TEMPLATE_ID		    = 	"onboarding.primary.reminder";
	/**
	 * This is the unique identifier utilised to reference the template configured for sending
	 * the email to a prospective platform user, to notify the user that an account for his/her
	 * has been created and he/she can now access the platform and complete the setup of the
	 * account.
	 */
	public static final String USER_ACCOUNT_CREATION_TEMPLATE_ID		=	"user.account.creation";
	/**
	 * This is the unique identifier utilised to reference the template configured for sending
	 * the email to a platform user to notify him/her that his/her account has been deleted.
	 */
	public static final String USER_ACCOUNT_DELETION_TEMPLATE_ID		=	"user.account.deletion";
	/**
	 * This is the unique identifier utilised to reference the template configured for sending
	 * the email to a platform user to notify him/her that his/her account has been deactivated.
	 */
	public static final String USER_ACCOUNT_STATUS_TEMPLATE_ID			=	"user.account.status";
	/**
	 * This is the unique identifier utilised to reference the template configured for sending
	 * the email to the administrator of a vertical to nofify him/her that an error occurred on
	 * the platform during the backend processing.
	 */
	public static final String PLATFORM_ERROR_TEMPLATE_ID				=	"platform.error";
	

}
