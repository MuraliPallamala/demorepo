package com.ibm.au.bgx.model.exception;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */

import java.math.BigInteger;

/**
 * Class <b>GuaranteePreconditionFailsException</b>. Extends {@link GuaranteeException} 
 * and specialises to those error conditions indicating that preconditions required to
 * execute a particular action against a bank guarantee / bank guarantee request are not
 * met.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public class GuaranteePreconditionFailsException extends GuaranteeException {


    /**
     * A {@link Long} value used to discriminate among different instances that
     * have the same class name (but may not be the same) during serialization.
     */
    private static final long serialVersionUID = 2865061880915691109L;


    /**
     * Constructs a new exception with the specified detail message. The cause
     * is not initialized, and may subsequently be initialized by a call to
     * {@link #initCause}.
     *
     * @param message 	the detail message (which is saved for later retrieval by 
     * 					the {@link #getMessage()} method).
     */
    public GuaranteePreconditionFailsException(String message) {
        this(message, BigInteger.ZERO, null);
    }

    /**
     * Constructs a new exception with the specified cause and a detail message
     * of <tt>(cause==null ? null : cause.toString())</tt> (which typically
     * contains the class and detail message of <tt>cause</tt>).
     * 
     * @param cause 	the cause (which is saved for later retrieval by the {@link 
     * 					#getCause()} method). (A <tt>null</tt> value is permitted, 
     * 					and indicates that the cause is nonexistent or unknown.)
     */
    public GuaranteePreconditionFailsException(Throwable cause) {
        this(null, cause);
    }

    /**
     * Constructs a new exception with the specified detail message and cause.
     */
    public GuaranteePreconditionFailsException(String message, Throwable cause) {
        this(message, BigInteger.ZERO, cause);
    }

    /**
     * Initialises an instance of {@link GuaranteePreconditionFailsException} with the 
     * given <i>message</i> and <i>code</i>.
     *
     * @param message 	the detail message (which is saved for later retrieval by 
     * 					the {@link #getMessage()} method).
     *            
     * @param code		a {@link BigInteger} value that indicates the specific error
     * 					code associated to the cause of this exception. It cannot be
     * 					{@literal null}.
     *            
     * @throws IllegalArgumentException	if <i>code</i> is {@literal null}.
     */
    public GuaranteePreconditionFailsException(String message, BigInteger code) {
        this(message, code, null);
    }

    /**
     * Initialises an instance of {@link GuaranteePreconditionFailsException} with the 
     * given <i>message</i>, <i>code</i>, and <i>cause</i>.
     *
     * @param message 	the detail message (which is saved for later retrieval by 
     * 					the {@link #getMessage()} method).
     *            
     * @param code		a {@link BigInteger} value that indicates the specific error
     * 					code associated to the cause of this exception. It cannot be
     * 					{@literal null}.
     * 
     * @param cause 	the cause (which is saved for later retrieval by the {@link 
     * 					#getCause()} method). (A <tt>null</tt> value is permitted, 
     * 					and indicates that the cause is nonexistent or unknown.)
     *            
     * @throws IllegalArgumentException	if <i>code</i> is {@literal null}.
     */
    public GuaranteePreconditionFailsException(String message, BigInteger code, Throwable cause) {
        super(message, code, cause);
    }
}
