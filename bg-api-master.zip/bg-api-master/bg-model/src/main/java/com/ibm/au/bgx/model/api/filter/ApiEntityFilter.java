package com.ibm.au.bgx.model.api.filter;

import com.ibm.au.bgx.model.user.BgxPrincipal;
import java.util.List;

/**
 * <p>
 * Interface <b>ApiEntityFilter</b>. Defines the contract for a generic filtering capability that can
 * be applied to a single entity or a collection of entities of the same type.
 * </p>
 * <p>
 * Scenarios where these capabilities are required, include removing (or nullifying} some attributes
 * of an entity that are of a sensitive nature and may not visible to all the clients, or complete
 * removal of entire entities within a collection if these are not meant to be visible to the client.
 * </p>
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 * 
 * @param <T> The entity being subject to the filtering process
 */

public interface ApiEntityFilter<T> {

    /**
     * Filter a single item. This is an overloaed version of {@link ApiEntityFilter#filterOne(Object)} that
     * takes as a second argument a reference to the security principal associated to the execution context.
     *
     * @param item 		an instance of type <i>T</i> representing the entity being filtered. It cannot be
     * 					{@literal null}.
     * 
     * @param principal an instance of {@link BgxPrincipal} that represents the security principal that is
     * 					associated to the execution context of the filter. This argument may or may not be
     * 					allowed to be {@literal null}. This depends on the specific implementation of the
     * 					filter class.
     * 
     * @return the filtered item, it can be {@literal null}.
     * 
     * @throws IllegalArgumentException 	if <i>item</i> is {@literal null}.
     * 
     * @see ApiEntityFilter#filterOne(Object)
     */
    T filterOne(T item, BgxPrincipal principal);

    /**
     * <p>
     * Filter a single item.
     * </p>
     * <p>
     * This method may be implemented as {@link ApiEntityFilter#filterOne(Object, BgxPrincipal)} with 
     * the value of the principal set to {@literal null}.
     * </p>
     *
     * @param item 	an instance of type <i>T</i> which is processed by the filtered.
     * 
     * @return 	an instance of type <i>T</i>, which has been filtered according to the logic of the filter.
     * 			It can be {@literal null}.
     * 
     * @throws IllegalArgumentException  if <i>items</i> is {@literal null}.
     * 
     * @see ApiEntityFilter#filterOne(Object, BgxPrincipal)
     */
    T filterOne(T item);

    /**
     * <p>
     * Filter a list of items. This is an overloaed version of {@link ApiEntityFilter#filterMany(List)} that
     * takes as a second argument a reference to the security principal associated to the execution context.
     * </p>
     * <p>
     * The expectation is that there is no dependency among the items in the list. Hence, implementations
     * may consider, where appropriate, to implement this method as the list aggregation of the references
     * returned by {@link ApiEntityFilter#filterOne(Object, BgxPrincipal)} applied to all the entities in
     * <i>item</i>.
     * </p>
     *
     *
     * @param items 	a {@link List} implementation that contains the list of items to be filtered.
     * 					It cannot be {@literal null}.
     * 
     * @param principal an instance of {@link BgxPrincipal} that represents the security principal that is
     * 					associated to the execution context of the filter. This argument may or may not be
     * 					allowed to be {@literal null}. This depends on the specific implementation of the
     * 					filter class.
     * 
     * @return a {@link List} implementation that represent the set of filtered entities.
     * 
     * @throws IllegalArgumentException	if <i>items</i> is {@literal null}.
     * 
     * @see ApiEntityFilter#filterMany(List)
     */
    List<T> filterMany(List<T> items, BgxPrincipal principal);

    /**
     * <p>
     * Filter a list of items and returns the corresponding list of filtered items.
     * </p>
     * <p>
     * This method may be implemented as {@link ApiEntityFilter#filterMany(List, BgxPrincipal)} with 
     * the value of the principal set to {@literal null}. Moreover, the expectation is that there is
     * no dependence among entities being filtered. This allows for, where appropriate, implementing
     * this method as the list aggregation of the entities returned by the method that filters one
     * single item, applied to each of the items passed as argument.
     * </p>
     *
     * @param items 	a {@link List} implementation that contains the list of items to be filtered.
     * 					It cannot be {@literal null}.
     * 
     * @return a {@link List} implementation that represent the set of filtered entities.
     * 
     * @throws IllegalArgumentException	if <i>items</i> is {@literal null}.
     * 
     * @see ApiEntityFilter#filterMany(List)
     */
    List<T> filterMany(List<T> items);
}
