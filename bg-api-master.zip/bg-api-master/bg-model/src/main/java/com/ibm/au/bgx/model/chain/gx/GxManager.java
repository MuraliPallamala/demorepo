package com.ibm.au.bgx.model.chain.gx;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.exception.GuaranteeException;
import com.ibm.au.bgx.model.exception.GuaranteeForbiddenException;
import com.ibm.au.bgx.model.exception.GuaranteeNotFoundException;
import com.ibm.au.bgx.model.exception.GuaranteePreconditionFailsException;
import com.ibm.au.bgx.model.pojo.gx.*;

import java.util.List;

/**
 * Interface for gx manager
 * Extends on GxChain operations and provides offchain capabilities
 *
 * @author Dain LIffman <dainliff@au1.ibm.com>
 */

public interface GxManager {

	/**
	 * 
	 * @param gxRequest
	 * @return
	 * @throws GuaranteeException
	 * @throws GuaranteeForbiddenException
	 */
    GxRequest submitRequest(GxRequest gxRequest) throws GuaranteeException, GuaranteeForbiddenException;

    /**
     * 
     * @param gxAction
     * @return
     */
    GxAction submitAction(GxAction gxAction);

    /**
     * 
     * @param searchRequest
     * @return
     * @throws GuaranteeException
     * @throws GuaranteeForbiddenException
     */
    GxSearchResponse search(GxSearchRequest searchRequest) throws GuaranteeException, GuaranteeForbiddenException;

    /**
     * 
     * @param guaranteeId
     * @return
     * @throws GuaranteeException
     * @throws GuaranteeNotFoundException
     * @throws GuaranteeForbiddenException
     */
    Gx get(String guaranteeId) throws GuaranteeException, GuaranteeNotFoundException, GuaranteeForbiddenException;

    /**
     * 
     * @param flowsSearchRequest
     * @return
     * @throws GuaranteeException
     * @throws GuaranteeForbiddenException
     */
    GxFlowsSearchResponse searchFlows(GxFlowsSearchRequest flowsSearchRequest) throws GuaranteeException, GuaranteeForbiddenException;

    /**
     * 
     * @param flowId
     * @return
     * @throws GuaranteeException
     * @throws GuaranteeNotFoundException
     * @throws GuaranteeForbiddenException
     */
    GxRequest getFlow(String flowId) throws GuaranteeException, GuaranteeNotFoundException, GuaranteeForbiddenException;

    /**
     * 
     * @param flowId
     * @return
     * @throws GuaranteeException
     * @throws GuaranteeForbiddenException
     * @throws GuaranteePreconditionFailsException
     */
    List<GxAction> getFlowActions(String flowId) throws GuaranteeException, GuaranteeForbiddenException, GuaranteePreconditionFailsException;

    /**
     * 
     * @param flowId
     * @param actionId
     * @return
     * @throws GuaranteeException
     * @throws GuaranteeNotFoundException
     * @throws GuaranteeForbiddenException
     * @throws GuaranteePreconditionFailsException
     */
    GxAction getFlowAction(String flowId, String actionId) throws GuaranteeException, GuaranteeNotFoundException, GuaranteeForbiddenException, GuaranteePreconditionFailsException;
}
