package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.BaseRequest.Status;
import com.ibm.au.bgx.model.pojo.organization.OrgChangeRequest;
import java.util.List;

/**
 * @author Peter Ilfrich
 */
public interface OrgChangeRequestRepository extends DefaultRepository<OrgChangeRequest> {

	/**
	 * 
	 * @param requestStatus
	 * @return
	 */
    List<OrgChangeRequest> findByStatus(Status requestStatus);

    /**
     * 
     * @param orgId
     * @return
     */
    List<OrgChangeRequest> findByOrgId(String orgId);

    /**
     * 
     * @param orgId
     * @param requestStatus
     * @return
     */
    List<OrgChangeRequest> findByOrgIdAndStatus(String orgId, Status requestStatus);

    /**
     * 
     * @param linkOrgId
     * @param requestStatus
     * @return
     */
    List<OrgChangeRequest> findByLinkOrgId(String linkOrgId, Status requestStatus);

    /**
     * 
     * @param orgId
     * @param requestStatus
     * @param requestType
     * @return
     */
    List<OrgChangeRequest> findByOrgIdStatusAndType(String orgId, String requestStatus, String requestType);
}
