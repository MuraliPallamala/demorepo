package com.ibm.au.bgx.model.chain.profile;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.pojo.api.request.UserProfileRequest;
import java.util.List;

/**
 * Interface <b>UserProfileRequestManager</b>. Extends {@link ProfileRequestManager} and specialises
 * it for the management of {@link UserProfileRequest} instances.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public interface UserProfileRequestManager extends ProfileRequestManager<UserProfileRequest> {

	/**
	 * Retrieves all the user profile requests that match the given email.
	 * 
	 * @param email	a {@link String} representing the email associated to the profile request
	 * 				to retrieve. It cannot be {@literal null} or an empty string.
	 * 
	 * @return	a {@link List} implementation containing {@link UserProfileRequest} instances whose
	 * 			attribute {@link UserProfileRequest#getEmail()} matches the given <i>email</i>. It
	 * 			is guaranteed to not to be {@literal null} but it may be empty.
	 * 
	 * @throws IllegalArgumentException if <i>email</i> is {@literal null} or an empty string.
	 */
    List<UserProfileRequest> getByEmail(String email);
}
