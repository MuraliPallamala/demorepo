/**
 * 
 */
package com.ibm.au.bgx.model.text;


/**
 * 
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
public interface TemplateResolver {
	
	/**
	 * Returns the sequence of template identifiers managed by this resolver.
	 * 
	 * @return	a {@link Iterable} implementation that allows for iterating 
	 * 			over all the template identifier registered with this instance
	 * 			of {@link TemplateResolver}. It cannot be {@literal null}.
	 */
	public Iterable<String> getTemplates();
	/**
	 * Resolves a template from the given unique identifier <i>templateId</i>.
	 * 
	 * @param templateId	a {@link String} representing the unique identifier of
	 * 						the template to resolve. It cannot be null or an empty
	 * 						string.
	 * 
	 * @return	a {@link TemplateReference} instance providing access to the template
	 * 			mapped by <i>templateId</i> or {@literal null} if there is no matching
	 * 			template.
	 * 
	 * @throws IllegalArgumentException	if <i>templateId</i> is {@literal null} or
	 * 									an empty string.
	 * 
	 * @throws TemplateException	if there is any error while trying to resolve
	 * 								<i>templateId</i>.
	 */
	public TemplateReference resolve(String templateId) throws TemplateException;

}
