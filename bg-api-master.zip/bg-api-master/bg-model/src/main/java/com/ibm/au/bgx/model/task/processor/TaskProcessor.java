package com.ibm.au.bgx.model.task.processor;

/**
 * Interface <b>TaskProcessor</b>. Provides a generic contract for implementing
 * processors of generic tasks. The intent of this interface is to provide means
 * for executing operations that may required complex processing.
 * 
 * @param <T> the type of task being processed.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public interface TaskProcessor<T> {

	/**
	 * Processes the given <i>task</i>
	 * 
	 * @param task	a task instance that represents the task to be
	 * 				processed. It cannot be {@literal null}.
	 * 
	 * @return 	the same task instance updated with the outcome of execution
	 * 			of the task. It is guaranteed to not to be {@literal null}.
	 */
    T process(T task);
}
