package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.chain.BlockchainEventMetaData;

/**
 * @author Peter Ilfrich
 */
public interface BlockchainEventRepository extends DefaultRepository<BlockchainEventMetaData> {

	/**
	 * 
	 * @param channelName
	 * @return
	 */
    BlockchainEventMetaData getLast(String channelName);
}
