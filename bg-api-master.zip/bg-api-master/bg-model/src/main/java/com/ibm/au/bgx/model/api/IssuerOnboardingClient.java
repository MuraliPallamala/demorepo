package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.pojo.OrgProfileRequest;
import com.ibm.au.bgx.model.pojo.api.request.OrgRequestActionRequest.Type;

/**
 * @author Peter Ilfrich
 */
public interface IssuerOnboardingClient {

	/**
	 * 
	 * @param request
	 * @throws ServiceUnavailableException
	 */
    void sendDeleteRequestNotification(OrgProfileRequest request) throws ServiceUnavailableException;

    /**
     * 
     * @param request
     * @param actionType
     */
    void sendCompleteRequestNotification(OrgProfileRequest request, Type actionType);

}
