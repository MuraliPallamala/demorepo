package com.ibm.au.bgx.model.text.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.ibm.au.bgx.model.text.FileTemplateReference;
import com.ibm.au.bgx.model.text.TemplateException;
import com.ibm.au.bgx.model.text.TemplateReference;
import com.ibm.au.bgx.model.text.TemplateResolver;




/**
 * Class <b>FileTemplateResolver</b>. This class implements the {@link TemplateResolver} interface
 * and defines a template resolution mechanism based on files. The component is configured with a
 * <i>manifest file</i>, which maps template identifiers to the corresponding locations in the file
 * system of the templates.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
@Component
@Primary
public class FileTemplateResolver implements TemplateResolver {
	/**
	 * A {@link String} containing the name of the default manifest file.
	 */
	public static final String DEFAULT_MANIFEST_FILE = "templates.manifest";

	/**
	 * A {@link Logger} instance that is used to collect the messages of all the instances of
	 * this class.
	 */
    private static final Logger LOGGER = LoggerFactory.getLogger(FileTemplateResolver.class);
	
	/**
	 * A {@link String} containing the path to the manifest
	 * file.
	 */
	@Value("${template.manifest.path:templates.manifest}")
	private String manifestPath = FileTemplateResolver.DEFAULT_MANIFEST_FILE;
	
	/**
	 * A {@link Properties} instance that contains the mapping 
	 * of the template ids to the corresponding template files.
	 */
	private Properties manifest = new Properties();
	
	/**
	 * Sets the path to the manifest file that contains a mapping
	 * between the supported template identifiers and the corresponding
	 * template files.
	 * 
	 * @param path	a {@link String} representing the path to the
	 * 				manifest file. It cannot be {@literal null} or
	 * 				an empty string.
	 * 
	 * @throws IllegalArgumentException	if <i>path</i> is {@literal null}
	 * 									or empty.
	 */
	public void setManifestPath(String path) {
		if (path == null || path.isEmpty()) {
			
			throw new IllegalArgumentException("Paramter 'path' cannot be null or an empty string.");
		}
		
		this.manifestPath = path;
	}
	/**
	 * Gets the path to the manifest file that contains a mapping
	 * between the supported template identifiers and the corresponding
	 * template files.
	 * 
	 * @return	a {@link String} representing the path to the manifest file. 
	 * 			It cannot be {@literal null} or an empty string. By default
	 * 			it is set to {@link FileTemplateResolver#DEFAULT_MANIFEST_FILE}.
	 * 
	 */
	public String getManifestPath() {
		
		return this.manifestPath;
	}
	
	/**
	 * This method initialises the template resolver. This method reads the configured manifest
	 * file, checks all the templates for existence, and creates a {@link Properties} instance 
	 * to store all the mappings (templateId ==> filePath) as it is specified in the manifest
	 * file.
	 */
	@PostConstruct
	public void init() {
		
		String path = this.getManifestPath();
		
		// pre-emptive clear in case we use
		// the resolver multipl times.
		//
		this.manifest.clear();
		
		File file = new File(path);
		if (file.exists() && file.canRead()) {
			
			
			File parent = file.getParentFile();
			
			if (file.isFile()) {
			
				try(InputStream stream = new FileInputStream(path)) {
					
					this.manifest.load(stream);
					
					// we can list all the templates and check whether we can
					// read them.
					LOGGER.info("Registered Templates");

					
					for(Object entry : this.manifest.keySet()) {
						
						
						String key = entry.toString();
					
						String filePath = this.manifest.getProperty(key);
						
						File tf = new File(filePath);
						if (!tf.isAbsolute() && parent != null) {
							
							File atf = new File(parent, filePath);
							this.manifest.setProperty(key, atf.getAbsolutePath());
							tf = atf;

						}
						
						boolean fe = tf.exists();
						boolean fr = tf.canRead();
						boolean ff = tf.isFile();
						boolean fOk = fe && fr && ff;
						
						String format = "[%1$s] - [tId: %7$s] (exist: %4$s, read: %5$b, file: %6$b) - %2$s ==> %3$s.";
						
						if (LOGGER.isInfoEnabled()) {
							
							LOGGER.info(String.format(format, fOk ? "OK" : "NO", filePath, tf.getPath(), fe, fr, ff, key));
						}
						
						
						if (!fOk) {
							
							if (LOGGER.isErrorEnabled()) {
				        	
								LOGGER.error(String.format(format, "NO", filePath, tf.getPath(), fe,fr,ff, key));
				        	
							}
						}
					}
					
					
				} catch (IOException ioex) {
	
					// Handling the case where the component cannot read
					// the manifest file, and logging an error.
					//
			        LOGGER.error(String.format("Could not read manifest file: '%1$s'", path), ioex);
	
				}
			
			} else {
				
				 LOGGER.error(String.format("Manifest file: '%1$s' is not a file (directory?).", path));
			}
			
		} else {
			
			LOGGER.error(String.format("Manifest file: '%1$s' does not exist or cannot be read.", path));
		}
		
	}
	/**
	 * Returns an {@link Iterable} implementation that can be used to iterate over all the
	 * registered template identifiers with this instance.
	 * 
	 * @return	a {@link Iterable} implementation containing the names of the templates identifier
	 * 			reads from the manifest file, or an empty set. It cannot be {@literal null}.
	 */
	@Override
	public Iterable<String> getTemplates() {
		
		return this.manifest.stringPropertyNames();
	}
	
	/**
	 * This method resolves the given template identifier to a reference to an existing template.
	 * 
	 * @param templateId	a {@link String} containing the unique identifier of the template to
	 * 						resolve. It cannot be {@literal null}.
	 * 
	 * @return 	an instance of {@link TemplateReference} that provides access to the template mapped
	 * 			by <i>templateId</i> or {@literal null} if the template identifier does not map to
	 * 			any template. As this class manages file templates, the specific type of {@link 
	 * 			TemplateReference} returned is {@link FileTemplateReference}.
	 * 
	 * @throws TemplateException 	no exception is thrown by the current implementation of this
	 * 								method.
	 */
	@Override
	public TemplateReference resolve(String templateId) throws TemplateException {

		if (templateId == null || templateId.isEmpty()) {
			throw new IllegalArgumentException("Parameter 'templateId' cannot be null or an empty string.");
		}

		
		FileTemplateReference reference = null;
		String templatePath = this.manifest.getProperty(templateId);

		if (templatePath != null) {
			
			reference = new FileTemplateReference(templatePath);
			
			if (!reference.getFile().exists()) {
				
				LOGGER.warn(String.format("Template id '%1$s' references not existing path '%2$s'.", templateId, reference.getFile().getPath()));
			}
		}
		
		return reference;
	}

}
