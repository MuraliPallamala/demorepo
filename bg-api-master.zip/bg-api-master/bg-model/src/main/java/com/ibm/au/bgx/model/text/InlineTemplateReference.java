package com.ibm.au.bgx.model.text;



/**
 * Class <b>InlineTemplateReference</b>. Extends {@link TemplateReference} to
 * support the definition of inline templates, which are directly specified
 * within the instance of the reference. The use of this class is appropriate
 * when the template is a short string.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class InlineTemplateReference extends TemplateReference {

	
	/**
	 * A {@link String} representing the content of the template.
	 */
	private String content;
	
	/**
	 * Initialises an instance of {@link InlineTemplateReference} with the
	 * given <i>content</i>.
	 * 
	 * @param content	a {@link String} representing the definition of the
	 * 					template. It cannot be {@literal null}.
	 * 
	 * @throws IllegalArgumentException	if <i>content</i> is {@literal null}.
	 */
	public InlineTemplateReference(String content) {
		
		if (content == null) {
			throw new IllegalArgumentException("Parameter 'content' cannot be null.");
		}

		this.content = content;
	}
	
	/**
	 * Gets the template's content.
	 * 
	 * @return	a {@link String} representing the definition of the
	 * 			template. It cannot be {@literal null}.
	 */
	public String getContent() {

		return this.content;	
	}
	
	

}
