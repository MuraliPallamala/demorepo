package com.ibm.au.bgx.model.audit;

/**
 * Class <b>AuditParameter</b>. Audit parameters are used to store
 * references to identifiers of entities with information associated
 * to the type of entity in the log. This allows for:
 * <ul>
 * <li>removing sensitive data from the audit log itself</li>
 * <li>reconstructing the information associated to events for human 
 * consumption</li>
 * </ul>
 * The use of audit parameters primarily serves the internal details
 * of {@link AuditManager} implementations that are meant to strip
 * and reconstruct the sensitive information from the audit log.
 * 
 * @author Peter Ilfrich
 */
public class AuditParameter {

	/**
	 * A {@link String} containing information about the type of
	 * entity that is referenced by the audit parameter.
	 */
    private String type;
    
    /**
     * A {@link String} containing the unique identifier of the
     * entity being referenced.
     */
    private String id;

    /**
     * Initialises a blank instance of {@link AuditParameter}. This
     * constructor sets both the <i>type</i> and <i>id</i> properties
     * to {@literal null}.
     */
    public AuditParameter() { }

    /**
     * Initialises an instance of the {@link AuditParameter} with the
     * given properties.
     * 
     * @param type	a {@link String} representing the type of entity
     * 				that is referenced by the audit parameter. This
     * 				value should be set to one of the available entity
     * 				types:
     * 				<ul>
     * 				<li>{@link AuditConstants#ORG_CHANGE_REQUEST}</li>
     * 				<li>{@link AuditConstants#ORG_ONBOARDING_REQUEST}</li>
     * 				<li>{@link AuditConstants#ONBOARDING_ACTION}</li>
     * 				<li>{@link AuditConstants#ORGANIZATION}</li>
     * 				<li>{@link AuditConstants#BUSINESS_ACCOUNT}</li>
     * 				<li>{@link AuditConstants#APPROVAL_MODEL}</li>
     * 				<li>{@link AuditConstants#ROLE}</li>
     * 				<li>{@link AuditConstants#USER_PROFILE}</li>
     * 				<li>{@link AuditConstants#GX_REQUEST}</li>
     * 				<li>{@link AuditConstants#GUARANTEE}</li>
     * 				</ul>
     * 				It can be {@literal null}.
     * 
     * @param id	a {@link String} representing the unique identifier
     * 				of the entity being referenced by the parameter. It
     * 				can be {@literal null}.
     */
    public AuditParameter(String type, String id) {
        this.type = type;
        this.id = id;
    }

    /**
     * Gets the type of the entity referenced by the audit parameter.
     * 
     * @return	a {@link String} instance, if not {@literal null} it 
     * 			may contain one of the following well known types:
     * 			<ul>
     * 			<li>{@link AuditConstants#ORG_CHANGE_REQUEST}</li>
     * 			<li>{@link AuditConstants#ORG_ONBOARDING_REQUEST}</li>
     * 			<li>{@link AuditConstants#ONBOARDING_ACTION}</li>
     * 			<li>{@link AuditConstants#ORGANIZATION}</li>
     * 			<li>{@link AuditConstants#BUSINESS_ACCOUNT}</li>
     * 			<li>{@link AuditConstants#APPROVAL_MODEL}</li>
     * 			<li>{@link AuditConstants#ROLE}</li>
     * 			<li>{@link AuditConstants#USER_PROFILE}</li>
     * 			<li>{@link AuditConstants#GX_REQUEST}</li>
     * 			<li>{@link AuditConstants#GUARANTEE}</li>
     * 			</ul>
     * 			other types may potentially be returned but they are 
     * 			not currently supported by the platform.
     * 
     */
    public String getType() {
        return this.type;
    }

    /**
     * Sets the type of the entity referenced by the audit parameter.
     * 
     * 
     * @param type	a {@link String} representing the type of entity
     * 				that is referenced by the audit parameter. This
     * 				value should be set to one of the available entity
     * 				types:
     * 				<ul>
     * 				<li>{@link AuditConstants#ORG_CHANGE_REQUEST}</li>
     * 				<li>{@link AuditConstants#ORG_ONBOARDING_REQUEST}</li>
     * 				<li>{@link AuditConstants#ONBOARDING_ACTION}</li>
     * 				<li>{@link AuditConstants#ORGANIZATION}</li>
     * 				<li>{@link AuditConstants#BUSINESS_ACCOUNT}</li>
     * 				<li>{@link AuditConstants#APPROVAL_MODEL}</li>
     * 				<li>{@link AuditConstants#ROLE}</li>
     * 				<li>{@link AuditConstants#USER_PROFILE}</li>
     * 				<li>{@link AuditConstants#GX_REQUEST}</li>
     * 				<li>{@link AuditConstants#GUARANTEE}</li>
     * 				</ul>
     * 				It can be {@literal null}.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the unique identifier of the entity referenced by the audit
     * parameter.
     * 
     * @return	a {@link String} representing the unique identifier 
     * 			(usually in the form of a UUID). It can be {@literal 
     * 			null}.
     */
    public String getId() {
        return this.id;
    }

    /**
     * Sets the unique identifier of the entity referenced by the audit
     * parameter.
     * 
     * @param id	a {@link String} representing the unique identifier 
     * 				(usually in the form of a UUID). It can be {@literal 
     * 				null}.
     */
    public void setId(String id) {
        this.id = id;
    }
}
