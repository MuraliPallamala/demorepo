package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.exception.ServiceUnavailableException;
import com.ibm.au.bgx.model.pojo.AsicBusinessRecord;
/**
 * Interface <i>AsicRemoteClient</i>. This interface defines the contract of a simple
 * client to the ASIC Remote Web Service, which allows to search for a registered 
 * business by either its ABN or ACN.
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface AsicRemoteClient {

	/**
	 * Retrieves the information associated to the organisation that has been
	 * registered with the given <i>abn</i>.
	 * 
	 * @param abn	a {@link String} representing the Australian Business Number
	 * 				(ABN) to lookup for. The expectation is that this value is
	 * 				a 11-digit number compliant with the ABN formula, but the
	 * 				method is not expected to check its structural validity. The 
	 * 				argument cannot be be {@literal null}.
	 * 
	 * @return 	an {@link AsicBusinessRecord} instance containing the information
	 * 			about the organisation that has been registered with the given
	 * 			<i>abn</i>, if not {@literal null}. {@literal null} if no match
	 * 			is found.
	 * 
	 * @throws IllegalArgumentException	if <i>abn</i> is {@literal null}
	 * 	
	 * @throws ServiceUnavailableException	if the remote ASIC web service is not
	 * 										available.
	 */
    AsicBusinessRecord getByAbn(String abn) throws ServiceUnavailableException;

    /**
	 * Retrieves the information associated to the organisation that has been
	 * registered with the given <i>abn</i>.
	 * 
	 * @param acn	a {@link String} representing the Australian Company Number
	 * 				(ACN) to lookup for. The expectation is that this value is
	 * 				a 9-digit number compliant with the ACN formula, but the
	 * 				method is not expected to check its structural validity. The 
	 * 				argument cannot be be {@literal null}.
	 * 
	 * @return 	an {@link AsicBusinessRecord} instance containing the information
	 * 			about the organisation that has been registered with the given
	 * 			<i>acn</i>, if not {@literal null}. {@literal null} if no match
	 * 			is found.
	 * 
	 * @throws IllegalArgumentException	if <i>acn</i> is {@literal null}
	 * 	
	 * @throws ServiceUnavailableException	if the remote ASIC web service is not
	 * 										available.
     */
    AsicBusinessRecord getByAcn(String acn) throws ServiceUnavailableException;
}
