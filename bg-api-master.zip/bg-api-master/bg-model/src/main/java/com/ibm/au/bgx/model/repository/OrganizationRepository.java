package com.ibm.au.bgx.model.repository;
/**
 * Licensed Materials - Property of IBM
 *
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.pojo.OrgProfile.EntityType;
import com.ibm.au.bgx.model.pojo.Organization;
import java.util.List;

/**
 * Repository interface to store organization profile and other details
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com> 
 */

public interface OrganizationRepository extends DefaultRepository<Organization> {

    List<Organization> getByBusinessId(String bid);

    List<Organization> getByEntityName(String name);

    List<Organization> getByEntityType(EntityType type);

    /**
     * Retrieve the organization by the issuer for API to API auth
     *
     * We support same JWT issuer for multiple organizations. e.g. any external openID provider
     * Also we support separate JWT issuer for api-to-api auth or user-auth
     *
     * @param iss
     * @return
     */
    List<Organization> getByApiAuthJwtIssuer(String iss);

    /**
     * Retrieve the organization by the issuer for user auth
     *
     * We support same JWT issuer for multiple organizations. e.g. any external openID provider
     * Also we support separate JWT issuer for api-to-api auth or user-auth
     *
     * @param iss
     * @return
     */
    List<Organization> getByUserAuthJwtIssuer(String iss);

    /**
     * Retrieve the organization by the key
     *
     * @param key
     * @return
     */
    Organization getByKey(String key);
}
