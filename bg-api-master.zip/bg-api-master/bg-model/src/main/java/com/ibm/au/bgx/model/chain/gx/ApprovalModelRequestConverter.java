package com.ibm.au.bgx.model.chain.gx;

import com.ibm.au.bgx.model.pojo.approvalmodel.ApprovalModelFlowRequest;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.user.BgxPrincipal;

/**
 *
 */
public interface ApprovalModelRequestConverter {

    // Converts GxRequest
	/**
	 * 
	 * @param principal
	 * @param gxRequest
	 * @return
	 */
    ApprovalModelFlowRequest from(BgxPrincipal principal, GxRequest gxRequest);

    // Converts GxAction
    /**
     * 
     * @param principal
     * @param gxAction
     * @param gxRequest
     * @param workflowId
     * @return
     */
    ApprovalModelFlowRequest from(BgxPrincipal principal, GxAction gxAction, GxRequest gxRequest, String workflowId);
}