package com.ibm.au.bgx.model.chain;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.exception.GuaranteeChainException;
import com.ibm.au.bgx.model.exception.GuaranteeException;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchResponse;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchResponse;
import java.text.ParseException;
import java.util.List;

/**
 * Interface for gx chain
 *
 * @author Dain LIffman <dainliff@au1.ibm.com>
 */

public interface GxChain {

    GxRequest startIssue(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxRequest startAmend(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxRequest startCancel(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxRequest startDemand(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxRequest startPayWalk(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxRequest startTransfer(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxRequest expire(String channelName, GxRequest gxRequest)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxAction actionApprove(String channelName, GxAction action)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxAction actionCancel(String channelName, GxAction action)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxAction actionRevoke(String channelName, GxAction action)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxAction actionReject(String channelName, GxAction action)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxAction actionDefer(String channelName, GxAction action)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    // TODO remove or refactor
    GxAction actionRecallIssue(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeException;

    GxAction actionRecallAmend(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeException;

    GxAction actionRecallCancel(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeException;

    GxAction actionRecallDemand(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeException;

    GxAction actionRecallTransfer(String channelName, String flowId, GxRequest gxRequest)
        throws GuaranteeChainException, GuaranteeException;

    GxSearchResponse search(String channelName, GxSearchRequest searchRequest)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    Gx get(String channelName, String guaranteeId)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxFlowsSearchResponse searchFlows(String channelName, GxFlowsSearchRequest flowsSearchRequest)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    GxRequest getFlow(String channelName, String flowId)
        throws GuaranteeChainException, ParseException, GuaranteeException;

    List<GxAction> getFlowActions(String channelName, String flowId)
        throws GuaranteeChainException, ParseException, GuaranteeException;
}
