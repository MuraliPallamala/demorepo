package com.ibm.au.bgx.model.chain;
/**
 * Licensed Materials - Property of IBM
 * <p>
 * (C) Copyright IBM Corp. 2016. All Rights Reserved.
 * <p>
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP
 * Schedule Contract with IBM Corp.
 */


import com.ibm.au.bgx.model.exception.GuaranteeChainException;
import com.ibm.au.bgx.model.pojo.gx.Gx;
import com.ibm.au.bgx.model.pojo.gx.GxAction;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxFlowsSearchResponse;
import com.ibm.au.bgx.model.pojo.gx.GxRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchRequest;
import com.ibm.au.bgx.model.pojo.gx.GxSearchResponse;
import java.text.ParseException;
import java.util.List;

/**
 * Interface for gx chain
 *
 * @author Dain LIffman <dainliff@au1.ibm.com>
 */

public interface ChannelGxChain {

    GxRequest startIssue(GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxRequest startAmend(GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxRequest startCancel(GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxRequest startDemand(GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxRequest startPayWalk(GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxRequest startTransfer(GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxRequest expire(GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxAction actionApprove(GxAction action) throws GuaranteeChainException, ParseException;

    GxAction actionCancel(GxAction action) throws GuaranteeChainException, ParseException;

    GxAction actionRevoke(GxAction action) throws GuaranteeChainException, ParseException;

    GxAction actionReject(GxAction action) throws GuaranteeChainException, ParseException;

    GxAction actionDefer(GxAction action) throws GuaranteeChainException, ParseException;

    // TODO remove or refactor
    GxAction actionRecallIssue(String flowId, GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxAction actionRecallAmend(String flowId, GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxAction actionRecallCancel(String flowId, GxRequest gxRequest)  throws GuaranteeChainException, ParseException;

    GxAction actionRecallDemand(String flowId, GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxAction actionRecallTransfer(String flowId, GxRequest gxRequest) throws GuaranteeChainException, ParseException;

    GxSearchResponse search(GxSearchRequest searchRequest) throws GuaranteeChainException, ParseException;

    Gx get(String guaranteeId) throws GuaranteeChainException, ParseException;

    GxFlowsSearchResponse searchFlows(GxFlowsSearchRequest flowsSearchRequest) throws GuaranteeChainException, ParseException;

    GxRequest getFlow(String flowId) throws GuaranteeChainException, ParseException;

    List<GxAction> getFlowActions(String flowId) throws GuaranteeChainException, ParseException;
}
