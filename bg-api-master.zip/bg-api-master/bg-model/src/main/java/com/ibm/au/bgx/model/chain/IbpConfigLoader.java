package com.ibm.au.bgx.model.chain;

import com.ibm.au.bgx.fabric.model.IbpConfig;

/**
 * A generic interface to load IBP config
 *
 * We plan to implement two version where one version will load from a mounted file, whereas the other
 * will load the confing from a URL
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface IbpConfigLoader {

	/**
	 * 
	 * @param channelName
	 * @return
	 * @throws Exception
	 */
    IbpConfig load(String channelName) throws Exception;
}
