package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.pojo.tc.TcExternalContent;
import com.ibm.au.bgx.model.pojo.tc.TermsAndCond;

/**
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */

public interface NewCoTermsAndCondClient {

	/**
	 * 
	 * @param title
	 * @param type
	 * @return
	 * @throws Exception
	 */
    PaginatedResponse<TermsAndCond> getAll(String title, String type) throws Exception;

    /**
     * 
     * @param id
     * @return
     * @throws Exception
     */
    TcExternalContent getDocumentPayload(String id) throws Exception;

    /**
     * 
     * @param id
     * @return
     * @throws Exception
     */
    TermsAndCond getById(String id) throws Exception;

}
