package com.ibm.au.bgx.model.util;

import java.util.Optional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

/**
 * Class <b>JacksonUtil</b>. This class wraps some capabilities for creating
 * {@link ObjectMapper} implementations that are configured to read and write
 * JSON documents according to the serialisation conventions adopted by the
 * platform, in particular with the representation of date tim values.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 *
 */
public class JacksonUtil {

	/**
	 * <p>
	 * Creates a default {@link ObjectMapper} instance, configured to serialise
	 * and deserialise JSON documents according to platform conventions.
	 * </p>
	 * <p>
	 * This method is a short form for {@link JacksonUtil#createObjectMapper(ObjectMapper)}
	 * invoked with a new instance of {@link ObjectMapper}.
	 * </p>
	 * 
	 * @return	an instance of {@link ObjectMapper} configured according to platform
	 * 			conventions. It is guaranteed to not to be {@literal null}.
	 * 
	 * @see JacksonUtil#createObjectMapper(ObjectMapper)
	 */
    public static ObjectMapper createObjectMapper() {
        return JacksonUtil.createObjectMapper(new ObjectMapper());

    }
    
    /**
     * <p>
     * Configures an instance of {@link ObjectMapper} to comply with the requirements for
     * serialisation and deserialisation of JSON documents set by the platform. 
     * </p>
     * <p>
     * The conventions for JSON serialisation/deserialisation include:
     * <ul>
     * <li>ability to support the new Java 8 data types (i.e. {@link Optional}, ....).</li>
     * <li>ability to support Java date/time (i.e. JSR-310 specification for date and time).</li>
     * <li>ability to support constructors, factory methods and property names).</li>
     * <li>serialisation of date fields as time stamps</li>
     * </ul>
     * </p>
     * 
     * @param objectMapper	an instance of {@link ObjectMapper} that needs to be configured
     * 			`			according to the platform serialisation/deserialisation conventions.
     * 						It cannot be {@literal null}.
     * 
     * @return	the {@link ObjectMapper} instance passed as argument configured as described.
     * 			It is guaranteed to not to be {@literal null}.
     * 
     * @throws IllegalArgumentException	if <i>objectMapper</i> is {@literal null}.
     */
    public static ObjectMapper createObjectMapper(ObjectMapper objectMapper) {
    	
    	if (objectMapper == null) {
    		throw new IllegalArgumentException("Parameter 'objectMapper' cannot be null.");
    	}
    	
        return objectMapper.registerModule(new ParameterNamesModule())
                		   .registerModule(new Jdk8Module())
                		   .registerModule(new JavaTimeModule())
                		   .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    }
}
