package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.task.BatchProcessTask;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask.Status;
import com.ibm.au.bgx.model.pojo.task.BatchProcessTask.Type;
import java.util.List;

/**
 * @author Peter Ilfrich
 * @author Lenin Mehedy
 */
public interface BatchProcessTaskRepository extends DefaultRepository<BatchProcessTask> {

    /**
     * Retrieve tasks by user Id
     * @param orgId 
     * @param userId 
     * @return 
     */
    List<BatchProcessTask> findByUserId(String orgId, String userId);

    /**
     * Retrieves a list of process configs for an org with a given process type.
     * @param orgId 
     * @return 
     */
    List<BatchProcessTask> findByOrgId(String orgId);

    /**
     * Retrieves a list of process configs with a given process type.
     * @param type 
     * @param status 
     * @return 
     */
    List<BatchProcessTask> findByTypeAndStatus(Type type, Status status);

}
