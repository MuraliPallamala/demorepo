package com.ibm.au.bgx.model.identityprovider;

import com.ibm.au.bgx.model.exception.IdentityProviderException;

/**
 * @author Bruno Marques <brunomar@au1.ibm.com>
 *
 */
public interface LogoutClient {

    /**
     * Invalidates the JWT token associated with the refreshToken.
     * @param clientId 
     * @param clientSecret 
     * @param refreshTokenString 
     * @param realmName 
     * @throws IdentityProviderException 
     * 
     */
    public void logout(String clientId, String clientSecret, String refreshTokenString, String realmName) throws IdentityProviderException;

}
