package com.ibm.au.bgx.model.repository;

import com.ibm.au.bgx.model.pojo.notification.WebNotification;
import java.util.List;

/**
 * Interface <b>WebNotificationRepository</i>. This interface specialises {@link DefaultRepository}
 * for {@link WebNotification} instances. It enriches the capabilities exposed by the base interface
 * by providing specific search methods.
 * 
 * @author Peter Ilfrich
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>	
 */
public interface WebNotificationRepository extends DefaultRepository<WebNotification> {
	
	/**
	 * Retrieves all the notifications that have the given <i>receiverId<i>. 
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
	 * 
	 * @return	a {@link List} of {@link WebNotification} instances whose value of the attribute
	 * 			{@link WebNotification#getReceiverId()} matches the provided <i>receiverId</i>.
     * 			The list can be empty but not {@literal null}.
	 */
    List<WebNotification> findByReceiverId(String receiverId);
    
	/**
	 * Retrieves all the notifications that have the given <i>receiverId<i> and whose date/time is
	 * equal or bigger than <i>minDate</i>. This is an overloaded version of the method {@link 
	 * WebNotificationRepository#findByReceiverId(String)} that allows point-in-time filtering.
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
	 * 
	 * @param startDate		a {@link String} containing the date/time information used to filter
	 * 						the list of notifications, in conjunction with <i>receiverId</i>. This
	 * 						argument is matched against the string representation of the attribute
	 * 						{@link WebNotification#getCreatedAt()}. It is expected to not to be 
	 * 						{@literal null}.
	 * 
	 * @return	a {@link List} of {@link WebNotification} instances whose value of the attribute
	 * 			{@link WebNotification#getReceiverId()} matches the provided <i>receiverId</i> and
	 * 			whose value of {@link WebNotification#getCreatedAt()} is equal or bigger than 
	 * 			<i>startDate</i>. The list can be empty but not {@literal null}.
	 */
    List<WebNotification> findByReceiverIdDate(String receiverId, String startDate);

    /**
     * Retrieves all the web notifications that have the given <i>receiverId</i> and match the
     * additional filtering criteria for to the action associated to the notification. This is
     * an overloaded version of {@link WebNotificationRepository#findByReceiverId(String)} that
     * allows for filtering on action status.
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
     * @param actionRequired	a {@literal boolean} value used as a filtering criteria for the
     * 							attribute {@link WebNotification#getActionRequired()}.
     * @param actionDone		a {@literal boolean} value used as a filtering criteria for the
     * 							attribute {@link WebNotification#getActionDone()}.
     * 
     * @return	a {@link List} of {@link WebNotification} instances whose entries fulfill the
     * 			following conditions:
     * 			<ul>
     * 			<li>{@link WebNotification#getReceiverId()} matches <i>receiverId</i></li>
     * 			<li>{@link WebNotification#getActionRequired()} matches <i>getActionRequired</i></li>
     * 			<li>{@link WebNotification#getActionDone()} matches <i>actionDone</i></li>
     * 			</ul>
     * 			The list can be empty but not {@literal null}.
     */
    List<WebNotification> findByReceiverAction(String receiverId, boolean actionRequired, boolean actionDone);

    /**
     * Retrieves all the notifications pertaining the given reference identifier and the provided action
     * selection criteria.
     * 
     * @param referenceId		a {@link String} value that is used to reference the entity associated
     * 							to the notifications of interest. This argument is matched against the
     * 							the value of {@link WebNotification#getReferenceId()}. Based on the value
     * 							of {@link WebNotification#getReferenceType()} the value of this argument
     * 							is interpreted differently and may point to identifiers of different entities
     * 							types.
     * @param actionRequired	a {@literal boolean} value used as a filtering criteria for the attribute 
     * 							{@link WebNotification#getActionRequired()}.
     * @param actionDone		a {@literal boolean} value used as a filtering criteria for the attribute 
     * 							{@link WebNotification#getActionDone()}.
     * 
     * @return	a {@link List} of {@link WebNotification} instances whose entries fulfill the
     * 			following conditions:
     * 			<ul>
     * 			<li>{@link WebNotification#getReferenceId()} matches <i>referenceId</i></li>
     * 			<li>{@link WebNotification#getActionRequired()} matches <i>getActionRequired</i></li>
     * 			<li>{@link WebNotification#getActionDone()} matches <i>actionDone</i></li>
     * 			</ul>
     * 			The list can be empty but not {@literal null}.
     */
    List<WebNotification> findByReferenceIdAction(String referenceId, boolean actionRequired, boolean actionDone);

    /**
     * Retrieves all the notifications that match the given <i>receiverId</i>, <i>topic</i>, and that
     * have been created on or after <i>startDate</i>.
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
     * @param topic			a {@link String} representing the topic identifier used to filter the
     * 						notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getReferenceType()} and as a consequence it is expected
     * 						to be the string representation of one of the values of the enumeration
     * 						{@link WebNotification.ReferenceType}.
	 * @param startDate		a {@link String} containing the date/time information used to filter
	 * 						the list of notifications, in conjunction with the other arguments. This
	 * 						argument is matched against the string representation of the attribute
	 * 						{@link WebNotification#getCreatedAt()}. It is expected to not to be 
	 * 						{@literal null}.
	 * 
     * @return	a {@link List} of {@link WebNotification} instances whose entries fulfill the
     * 			following conditions:
     * 			<ul>
     * 			<li>{@link WebNotification#getReceiverId()} matches <i>receiverId</i></li>
     * 			<li>{@link WebNotification#getReferenceType()} matches <i>topic</i></li>
     * 			<li>{@link WebNotification#getCreatedAt()} is equal or bigger then <i>startDate</i></li>
     * 			</ul>
     * 			The list can be empty but not {@literal null}.
     */
    List<WebNotification> findByReceiverTopic(String receiverId, String topic, String startDate);
    
    /**
     * Retrieves all the notifications that match the given <i>receiverId</i>, <i>topic</i>, <i>status</i>
     * and that have been created on or after <i>startDate</i>.
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
     * @param topic			a {@link String} representing the topic identifier used to filter the
     * 						notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getReferenceType()} and as a consequence it is expected
     * 						to be the string representation of one of the values of the enumeration
     * 						{@link WebNotification.ReferenceType}.
     * @param status		a {@link String} containing the status information used to filter the
     * 						notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getStatus()} and as a consequence it is expected to be
     * 						the string representation of one of the value of the enumeration {@link 
     * 						WebNotification.Status}.
	 * @param startDate		a {@link String} containing the date/time information used to filter
	 * 						the list of notifications, in conjunction with the other arguments. This
	 * 						argument is matched against the string representation of the attribute
	 * 						{@link WebNotification#getCreatedAt()}. It is expected to not to be 
	 * 						{@literal null}.
	 * 
     * @return	a {@link List} of {@link WebNotification} instances whose entries fulfill the
     * 			following conditions:
     * 			<ul>
     * 			<li>{@link WebNotification#getReceiverId()} matches <i>receiverId</i></li>
     * 			<li>{@link WebNotification#getReferenceType()} matches <i>topic</i></li>
     * 			<li>{@link WebNotification#getStatus()} matches <i>status</i></li>
     * 			<li>{@link WebNotification#getCreatedAt()} is equal or bigger then <i>startDate</i></li>
     * 			</ul>
     * 			The list can be empty but not {@literal null}.
     */
    List<WebNotification> findByReceiverTopicStatus(String receiverId, String topic, String status, String startDate);

    /**
     * Retrieves all the notifications that match the given <i>receiverId</i>, <i>topic</i>, <i>type</i>
     * and that have been created on or after <i>startDate</i>.
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
     * @param topic			a {@link String} representing the topic identifier used to filter the
     * 						notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getReferenceType()} and as a consequence it is expected
     * 						to be the string representation of one of the values of the enumeration
     * 						{@link WebNotification.ReferenceType}.
     * @param type			a {@link String} representing the type of notification used to filter 
     * 						the notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getMessageType()} and as a consequence it is expected to
     * 						be the string representation of one of the values of the enumeration 
     * 						{@link WebNotification.MessageType}
	 * @param startDate		a {@link String} containing the date/time information used to filter
	 * 						the list of notifications, in conjunction with the other arguments. This
	 * 						argument is matched against the string representation of the attribute
	 * 						{@link WebNotification#getCreatedAt()}. It is expected to not to be 
	 * 						{@literal null}.
	 * 
     * @return	a {@link List} of {@link WebNotification} instances whose entries fulfill the
     * 			following conditions:
     * 			<ul>
     * 			<li>{@link WebNotification#getReceiverId()} matches <i>receiverId</i></li>
     * 			<li>{@link WebNotification#getReferenceType()} matches <i>topic</i></li>
     * 			<li>{@link WebNotification#getMessageType()} matches <i>type</i></li>
     * 			<li>{@link WebNotification#getCreatedAt()} is equal or bigger then <i>startDate</i></li>
     * 			</ul>
     * 			The list can be empty but not {@literal null}.
     */
    List<WebNotification> findByReceiverTopicType(String receiverId, String topic, String type, String startDate);

    /**
     * Retrieves all the notifications that match the given <i>receiverId</i>, <i>topic</i>, <i>status</i>
     * <i>type</i>, and that have been created on or after <i>startDate</i>.
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
     * @param topic			a {@link String} representing the topic identifier used to filter the
     * 						notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getReferenceType()} and as a consequence it is expected
     * 						to be the string representation of one of the values of the enumeration
     * 						{@link WebNotification.ReferenceType}.
     * @param type			a {@link String} representing the type of notification used to filter 
     * 						the notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getMessageType()} and as a consequence it is expected to
     * 						be the string representation of one of the values of the enumeration 
     * 						{@link WebNotification.MessageType}
     * @param status		a {@link String} containing the status information used to filter the
     * 						notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getStatus()} and as a consequence it is expected to be
     * 						the string representation of one of the value of the enumeration {@link 
     * 						WebNotification.Status}.
	 * @param startDate		a {@link String} containing the date/time information used to filter
	 * 						the list of notifications, in conjunction with the other arguments. This
	 * 						argument is matched against the string representation of the attribute
	 * 						{@link WebNotification#getCreatedAt()}. It is expected to not to be 
	 * 						{@literal null}.
	 * 
     * @return	a {@link List} of {@link WebNotification} instances whose entries fulfill the
     * 			following conditions:
     * 			<ul>
     * 			<li>{@link WebNotification#getReceiverId()} matches <i>receiverId</i></li>
     * 			<li>{@link WebNotification#getReferenceType()} matches <i>topic</i></li>
     * 			<li>{@link WebNotification#getMessageType()} matches <i>type</i></li>
     * 			<li>{@link WebNotification#getStatus()} matches <i>status</i></li>
     * 			<li>{@link WebNotification#getCreatedAt()} is equal or bigger then <i>startDate</i></li>
     * 			</ul>
     * 			The list can be empty but not {@literal null}.
     */
    List<WebNotification> findByReceiverTopicTypeStatus(String receiverId, String topic, String type, String status, String startDate);

    /**
     * Retrieves all the notifications that match the given <i>receiverId</i>, <i>type</i>
     * and that have been created on or after <i>startDate</i>.
     * 
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
     * @param type			a {@link String} representing the type of notification used to filter 
     * 						the notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getMessageType()} and as a consequence it is expected to
     * 						be the string representation of one of the values of the enumeration 
     * 						{@link WebNotification.MessageType}
	 * @param startDate		a {@link String} containing the date/time information used to filter
	 * 						the list of notifications, in conjunction with the other arguments. This
	 * 						argument is matched against the string representation of the attribute
	 * 						{@link WebNotification#getCreatedAt()}. It is expected to not to be 
	 * 						{@literal null}.
	 * 
     * @return	a {@link List} of {@link WebNotification} instances whose entries fulfill the
     * 			following conditions:
     * 			<ul>
     * 			<li>{@link WebNotification#getReceiverId()} matches <i>receiverId</i></li>
     * 			<li>{@link WebNotification#getMessageType()} matches <i>type</i></li>
     * 			<li>{@link WebNotification#getCreatedAt()} is equal or bigger then <i>startDate</i></li>
     * 			</ul>
     * 			The list can be empty but not {@literal null}.
     */
    List<WebNotification> findByReceiverType(String receiverId, String type, String startDate);

    /**
     * Retrieves all the notifications that match the given <i>receiverId</i>, <i>status</i>
     * and that have been created on or after <i>startDate</i>.
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
     * @param status		a {@link String} containing the status information used to filter the
     * 						notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getStatus()} and as a consequence it is expected to be
     * 						the string representation of one of the value of the enumeration {@link 
     * 						WebNotification.Status}.
	 * @param startDate		a {@link String} containing the date/time information used to filter
	 * 						the list of notifications, in conjunction with the other arguments. This
	 * 						argument is matched against the string representation of the attribute
	 * 						{@link WebNotification#getCreatedAt()}. It is expected to not to be 
	 * 						{@literal null}.
	 * 
     * @return	a {@link List} of {@link WebNotification} instances whose entries fulfill the
     * 			following conditions:
     * 			<ul>
     * 			<li>{@link WebNotification#getReceiverId()} matches <i>receiverId</i></li>
     * 			<li>{@link WebNotification#getStatus()} matches <i>status</i></li>
     * 			<li>{@link WebNotification#getCreatedAt()} is equal or bigger then <i>startDate</i></li>
     * 			</ul>
     * 			The list can be empty but not {@literal null}.
     */
    List<WebNotification> findByReceiverStatus(String receiverId, String status, String startDate);

    /**
     * Retrieves all the notifications that match the given <i>receiverId</i>, <i>type</i>, <i>status</i>
     * and that have been created on or after <i>startDate</i>.
     * 
	 * 
	 * @param receiverId	a {@link String} representing the unique identifier of the receiver
	 * 						of the notification used as a filtering criteria. This argument is
	 * 						matched against the value of {@link WebNotification#getReceiverId()}.
	 * 						It is expected to not to be {@literal null}.
     * @param type			a {@link String} representing the type of notification used to filter 
     * 						the notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getMessageType()} and as a consequence it is expected to
     * 						be the string representation of one of the values of the enumeration 
     * 						{@link WebNotification.MessageType}
     * @param status		a {@link String} containing the status information used to filter the
     * 						notifications. This argument is matched against the value of {@link 
     * 						WebNotification#getStatus()} and as a consequence it is expected to be
     * 						the string representation of one of the value of the enumeration {@link 
     * 						WebNotification.Status}.
	 * @param startDate		a {@link String} containing the date/time information used to filter
	 * 						the list of notifications, in conjunction with the other arguments. This
	 * 						argument is matched against the string representation of the attribute
	 * 						{@link WebNotification#getCreatedAt()}. It is expected to not to be 
	 * 						{@literal null}.
	 * 
     * @return	a {@link List} of {@link WebNotification} instances whose entries fulfill the
     * 			following conditions:
     * 			<ul>
     * 			<li>{@link WebNotification#getReceiverId()} matches <i>receiverId</i></li>
     * 			<li>{@link WebNotification#getMessageType()} matches <i>type</i></li>
     * 			<li>{@link WebNotification#getStatus()} matches <i>status</i></li>
     * 			<li>{@link WebNotification#getCreatedAt()} is equal or bigger then <i>startDate</i></li>
     * 			</ul>
     * 			The list can be empty but not {@literal null}.
     */
    List<WebNotification> findByReceiverTypeStatus(String receiverId, String type, String status, String startDate);

}
