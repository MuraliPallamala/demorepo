package com.ibm.au.bgx.model.api;

import com.ibm.au.bgx.model.exception.ServiceUnavailableException;

/**
 * @author Peter Ilfrich
 */
public interface CacheRefreshClient {


	String CACHE_REQUESTS = "/cache/requests";

    /**
     * 
     * @param orgId
     * @throws ServiceUnavailableException
     */
    void sendOrganizationCacheRefresh(String orgId) throws ServiceUnavailableException;

    /**
     * 
     * @param formatId
     * @throws ServiceUnavailableException
     */
    void sendPurposeFormatCacheRefresh(String formatId) throws ServiceUnavailableException;
}
