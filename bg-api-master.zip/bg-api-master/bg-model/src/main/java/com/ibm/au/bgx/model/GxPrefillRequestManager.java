package com.ibm.au.bgx.model;


import com.ibm.au.bgx.model.pojo.gx.GxPrefillRequest;

import java.util.List;

/**
 * 
 * @author fl0yd
 *
 */
// [CV] TODO: Move this interface somewhere else, together with the GxManager?
public interface GxPrefillRequestManager {

	/**
	 * 
	 * @param request
	 * @return
	 */
    GxPrefillRequest add(GxPrefillRequest request);

    /**
     * 
     * @param id
     * @return
     */
    GxPrefillRequest get(String id);

    /**
     * 
     * @param gxRequestId
     * @return
     */
    List<GxPrefillRequest> find(String gxRequestId);
}
