/**
 * 
 */
package com.ibm.au.bgx.model.text;

/**
 * Class <b>TemplateReference<b>. This class represent a reference to 
 * a template. It is used to abstract away the specific details accessing
 * a template's content.
 * 
 * @author Christian Vecchiola <christian.vecchiola@au1.ibm.com>
 */
public abstract class TemplateReference {
	
	/**
	 * Initialises an instance of {@link TemplateReference}. This constructor
	 * is protected to avoid creation of instances of this type. 
	 */
	protected TemplateReference() {}

}
