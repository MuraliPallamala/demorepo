package com.ibm.au.bgx.model;

import com.ibm.au.bgx.model.api.NewCoNotificationClient;
import com.ibm.au.bgx.model.chain.ChannelSelector;
import com.ibm.au.bgx.model.chain.ProfileChain;
import com.ibm.au.bgx.model.chain.profile.OrganizationManager;
import com.ibm.au.bgx.model.notification.WebNotificationManager;
import com.ibm.au.bgx.model.queue.QueueClient;
import com.ibm.au.bgx.model.repository.AuditEventRepository;
import com.ibm.au.bgx.model.repository.BatchProcessTaskRepository;
import com.ibm.au.bgx.model.repository.ChannelUserRepository;
import com.ibm.au.bgx.model.repository.GxRequestRepository;
import com.ibm.au.bgx.model.repository.OrgChangeRequestRepository;
import com.ibm.au.bgx.model.repository.OrgProfileRequestRepository;
import com.ibm.au.bgx.model.repository.OrganizationRepository;
import com.ibm.au.bgx.model.repository.UserProfileRepository;

/**
 * <p>
 * Interface <b>BgxComponentProvider</b>. This interface implements the facade pattern and
 * acts as main provider for the most the components of the solution. The intent is to have
 * a single access point to retrieve all the relevant components that have been configured
 * to perform the various functions required by the implemented business processes.
 * </p>
 * <p>
 * Implementations of this interface may provide access to the following services:
 * <ul>
 * <li><i>api-to-api interaction</i></li>
 * <li><i>notification management</i></li>
 * <li><i>organisation management</i></li>
 * <li><i>request management</i></li>
 * <li><i>user profiles</i></li>
 * <li><i>task management</i></li>
 * <li><i>queuing services</i></li>
 * <li><i>ledger access</i></li>
 * <li><i>identity configuration</i></li>
 * </ul>
 * </p>
 * <p>
 * Implementations may fulfill the provision of all these services or just some of them. The
 * expectation is that all of these are fulfilled, unless a specific implementation of this
 * interface is used in a context where only a subset of this services are required.
 * </p>
 * <p>
 * An example of use of this interface is the implementation of the {@link BgxPrincipal} interface
 * which does provide access to several of the services provided by this interface.
 * </p>
 */
public interface BgxComponentProvider {
	
    /**
     * Provides access to the services for sending notifications to the user vertical.
     * The user vertical is the API deployment that provides platform services to 
     * applicants and beneficiaries. This component is primarily used by the issuer and
     * administrative vertical to implements callback flows based on notifications.
     * 
     * @return	a {@link NewCoNotificationClient} implementation, configured to send
     * 			notification to the current user vertical.
     */
    NewCoNotificationClient getNewCoNotificationClient();
    
    /**
     * Provides access to the organisation management services via an implementation
     * of {@link OrganizationManager}. The capability of this component are somewhat
     * constrained by the vertical that is bound to the execution context:
     * <ul>
     * <li>in an issuer vertical, this manager is essentially used to manage the
     * organisation of the issuer</li>
     * <li>in the administrative vertical, this manager is used to manage the administrative
     * organisation and perform additional administrative tasks on all organisations</li>
     * <li>in the user vertical, this manager is used to manage all applicant/beneficiary
     * organisations, and support organisation setup during onboarding</li>
     * </ul>
     * 
     * @return	a {@link OrganizationManager} implementation.
     */
    OrganizationManager getOrganizationManager();
    
    /**
     * Provides access to the repository managing the requests for organisation details
     * update. This repository is used to persist the information associated to the 
     * business processes for updating the public detail of an organisation or establishing
     * parent-subsidiary relationships.
     * 
     * @return	an implementation of {@link OrgChangeRequestRepository} configured to
     * 			access the onboarding requests that are visible to the vertical bound
     * 			to the current execution context.
     */
    OrgChangeRequestRepository getOrgChangeRequestRepository();
    
    /**
     * Provides access to the repository storing information about the organisations that
     * are registered with the platform. This repository will provide access to all the
     * organisations in the platform, but of these organisations only the public details
     * will be available in all verticals, the private part of the organisation will be
     * differently available based on the vertical bound to the execution context:
     * <ul>
     * <li>in a single-tenant environment (i.e. issuer, admin) only the organisation
     * configured with the tenant will be fully accessible, while for the others only
     * the public data will be exposed</li>
     * <li>in a multi-tenant environment (i.e. user) all the applicant and beneficiary
     * organisations will be fully accessible, the issuers and admin organisations will
     * only be exposed through their public data</li>
     * </ul>
     * 
     * @return	an implementation of {@link OrganizationRepository} which provides access 
     * 			to the off-chain data for organizations, which is visible to the vertical
     * 			bound to the current execution context.
     */
    OrganizationRepository getOrganizationRepository();

    /**
     * Provides access to the repository storing information about auditing events. The 
     * information that is available to this repository is somewhat limited by the vertical
     * that is bound to the current execution context:
     * <ul>
     * <li>in the issuer vertical this repository provides access to the auditing events
     * generated by that issuer only</li>
     * <li>in the user vertical this repository provides access to the auditing events that
     * have generated by applicants/beneficiaries</li>
     * <li>
     * <li>in the admin vertical this repository provides access to the auditing events that
     * are generated by the administrative users of the platform</li>
     * </ul>
     * Besides this basic set of rules, there exist a set of audit events that are recorded
     * as system actions, which do not necessarily resolve to a specific identity but are
     * still confined with the vertical that they belong to.
     * 
     * @return	an implementation of {@link AuditEventRepository} which provides access to
     * 			the information that has been audited by the vertical bound to the current
     * 			execution context.
     */
    AuditEventRepository getAuditEventRepository();

    /**
     * Provides access to the repository storing information about platform users. When
     * invoked in an execution context bound to a multi-tenant environment (i.e. user 
     * vertical) this repository will provide access to all the users of all the applicant
     * and beneficiary organisations. When invoked within an execution context that is bound
     * to a single-tenant environment (i.e. issuer, admin) this repository will provide
     * access only to the users of that tenant.
     * 
     * @return	an implementation of {@link UserProfileRepository} which provides access to 
     * 			the user profiles of the platform users that are visible to the vertical
     * 			that is bound to the execution context.
     */
    UserProfileRepository getUserProfileRepository();

    /**
     * Provides access to the repository storing information about the onboarding requests
     * of organisations. The set of onboarding requests that this repository has access to
     * is determined by the vertical bound to the execution context:
     * <ul>
     * <li>in the issuer vertical only the onboarding requests that have been facilitated by
     * that issuer will be available</li>
     * <li>in the admin vertical all the onboarding requests created within the platform
     * will be available</li>
     * <li>in the user vertical all the onboarding requests for applicant/beneficiaries will
     * be available</li>
     * </ul>
     * 
     * @return	an implementation of {@link OrgProfileRequestRepository} that is configured
     * 			to access the onboarding requests that are visible to the vertical that is
     * 			bound to the execution context.
     */
    OrgProfileRequestRepository getOrgProfileRequestRepository();

    /**
     * Provides access to the smart contract services of the platform. In particular access
     * to their API to interact with the Blockchain Network supporting the platform. 
     * 
     * @return	a {@link ChannelSelector} implementation that exposes methods to retrieves
     * 			smart contract API clients.
     */
    ChannelSelector getChannelSelector();

    /**
     * Provides access to the repository that stores the identities used to transact on the
     * Blockchain as organisations. The set of identities that are available through this
     * repository depends upon the vertical that is bound to the current execution context:
     * <ul>
     * <li>in the issuer vertical only the identity of the issuer organisation is accessible</li>
     * <li>in the user vertical only the identities of applicant/beneficiaries are accessible</li>
     * <li>in the administrative vertical only the identity of the administrative organisation, 
     * and possibly a copy of all the identities of all the other organisation (as a safeguard)</li>
     * </ul>
     * 
     * @return	a {@link ChannelUserRepository} configured to provide access to the Blockchain
     * 			identities that are visible to the vertical bound to the execution context.
     */
    ChannelUserRepository getChannelUserRepository();

    /**
     * Provides access to the smart contracts that are hosted in the platform channel. These
     * include the smart contract that provides access to organisations, terms and conditions,
     * and purpose formats.
     * 
     * @return	a {@link ProfileChain} implementation that is configured to interact with the
     * 			smart contracts in the platform channel, with the identity of the vertical
     * 			that is bound to the current execution context.
     */
    ProfileChain getProfileChain();

    /**
     * Provides access to the queuing services, which are used to enable asynchronous processing
     * within the scope of a single vertical. 
     * 
     * @return	a {@link QueueClient} implementation that is configured to send/consume messages
     * 			to the queue configured with the vertical bound to the current execution context.
     */
    QueueClient getQueueClient();

    /**
     * Provides access to the repository that stores information about batch tasks. The set of
     * tasks that are available through this repository is constrained by the vertical that is
     * bound to the execution context:
     * <ul>
     * <li>within an issuer vertical, this repository will provide access to all batch tasks that
     * are generated by that issuer.</li>
     * <li>within the administrative vertical, this repository will provide access to all batch
     * tasks that are generated by the admin vertical</li>
     * <li>within the user vertical, this repository will provide access to all batch tasks that
     * are generated by applicant/beneficiary organisations</li>
     * </ul>
     * 
     * @return	a {@link BatchProcessTaskRepository} configured to access the tasks that are
     * 			visible to the vertical configured with the current execution context.
     */
    BatchProcessTaskRepository getTaskRepository();

    /**
     * Provides access to the web notification management capabilities, which provides the ability
     * of managing the web notifications that are designated to the organisation(s) that are managed
     * by the vertical bound to the current execution context.
     * 
     * @return	a {@link WebNotificationManager} implementation that is configured to send web
     * 			notifications to all the organisations hosted within the vertical bound to the
     * 			current execution context.
     */
    WebNotificationManager getWebNotificationManager();

    /**
     * Provides access to the identity configuration of the current execution context. The identity 
     * configuration provides information about the vertical that is bound to the execution context 
     * and allows to determine whether the executing code is running in an issuer, applicant/beneficiary, 
     * or admin role.
     * 
     * @return	an {@link IdentityConfig} instance that is configured according to the settings of the 
     * 			vertical bound to the execution context.
     */
    IdentityConfig getIdentityConfig();

    /**
     * Provides access to the repository that manages the guarantee requests. The set of requests that 
     * this repository has access to depends upon the vertical that is bound to the execution context:
     * <ul>
     * <li>an issuer vertical has access only to the guarantee requests made/initiated by that issuer</li>
     * <li>the user vertical has access to all the guarantee requests</li>
     * <li>the admin vertical does not have access to any guarantee request</li>
     * </ul>
     * 
     * @return	a {@link GxRequestRepository} scoped by the vertical bound to the current execution
     * 			context.
     */
    GxRequestRepository getGxRequestRepository();
}
