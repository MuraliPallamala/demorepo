#!/bin/bash

# This script install BigFix and configures it as a client for either a
# primary BigFix or a relay server. The script requires two parameters:
#
# - an environment file containing specialisation parameters 
#
# - a configuration file for the BigFix client
#
# - a certificate file for the BigFix client to connect to the BigFix 
#   server
#
# The script creates the directories that are required and installs the
# package.

# NOTE: open firewall ports to allow port 52311/TCP to/from 129.34.20.42
#
#       - you can test if this is working by running curl http://129.34.20.42:52311/rd 
#         (you'll get an HTML message if the connection is successful)
#

set -e

S_BIGFIX_PACKAGE_NAME=BESAgent-9.5.7.90-ubuntu10.amd64.deb
S_BIGFIX_PACKAGE_URL=http://software.bigfix.com/download/bes/95/${S_BIGFIX_PACKAGE_NAME}

S_BIGFIX_ENV=${1:-.env}
S_BIGFIX_CONFIG=${2:-besclient.config}
S_BIGFIX_SOURCE_AFX=${3:-masthead.afxm}
S_BIGFIX_TARGET_AFX=actionsite.afxm
S_BIGFIX_ETC_DIR=/etc/opt/BESClient
S_BIGFIX_VAR_DIR=/var/opt/BESClient
S_BIGFIX_LOCAL_AFX=${S_BIGFIX_ETC_DIR}/${S_BIGFIX_TARGET_AFX}

S_PREREQ_OK=true

S_ERROR_PREREQ_FAILED=1
S_ERROR_NO_ROOT=2


S_CURRENT_USER=$(whoami)


echo "0. Checking Prerequisites..."

if [ -f ${S_BIGFIX_ENV} ]; then

    echo "   - [OK] Environment file    :  ${S_BIGFIX_ENV}"

else

    echo "   - [NO] Environment file    :  ${S_BIGFIX_ENV}"
    S_PREREQ_OK=false
fi

if [ -f ${S_BIGFIX_CONFIG} ]; then
    
    echo "   - [OK] Client config file  :  ${S_BIGFIX_CONFIG}"

else

    echo "   - [NO] Client config file  :  ${S_BIGFIX_CONFIG}"
    S_PREREQ_OK=false
fi

if [ -f ${S_BIGFIX_SOURCE_AFX} ]; then
 
    echo "   - [OK] Certificate file    :  ${S_BIGFIX_SOURCE_AFX}"

else

    echo "   - [NO] Certificate file    :  ${S_BIGFIX_SOURCE_AFX}"
    S_PREREQ_OK=false
fi

if [ ! -f ${S_BIGFIX_PACKAGE_NAME} ]; then 

    echo "   - BigFix local package cannot be found, downloading.."
    echo "     - curl ${S_BIGFIX_PACKAGE_URL} > ${S_BIGFIX_PACKAGE_NAME}"

    curl ${S_BIGFIX_PACKAGE_URL} > ${S_BIGFIX_PACKAGE_NAME}
    S_CURL_EXIT=$?

    if [ "${S_CURL_EXIT}" -ne 0 ]; then
	    echo "     - <download failed, exit code: ${S_CURL_EXIT}>"
    	S_PREREQ_OK=false
    fi 
else
    echo "   - [OK] BigFix package      :  ${S_BIGFIX_PACKAGE_NAME}"
fi

if [ ! ${S_PREREQ_OK} ]; then

    echo ""
    echo "[ERROR] - Some prerequisites are missing."
    echo ""
    exit ${S_ERROR_PREREQ_FAILED}    

fi

echo ""

echo "1. Checking User Permissions..."

if [ "${S_CURRENT_USER}" == "root" ]; then

    echo "   - [OK] user is root."
    echo ""
else
    echo "   - [NO] user is NOT root (user: ${S_CURRENT_USER})."
    echo ""
    echo "[ERROR] - Root permisions are required for installation."
    echo ""
    exit "${S_ERROR_NO_ROOT}"    
fi

echo "2. Installing BigFix..." 

echo "   - dpkg -i ${S_BIGFIX_PACKAGE_NAME}"
dpkg -i ${S_BIGFIX_PACKAGE_NAME}

echo "   - mkdir -p ${S_BIGFIX_ETC_DIR}"
mkdir -p ${S_BIGFIX_ETC_DIR}

echo "   - cp ${S_BIGFIX_SOURCE_AFX} ${S_BIGFIX_LOCAL_AFX}"
cp ${S_BIGFIX_SOURCE_AFX} ${S_BIGFIX_LOCAL_AFX}

echo "   - specializing client configuration:"
echo "     - source ${S_BIGFIX_ENV}"
source ${S_BIGFIX_ENV}

echo "     - sed -i -- 's/__BIG_FIX_RELAY_1__/'${S_BIGFIX_RELAY_1}'/g' ${S_BIGFIX_CONFIG}"
sed -i -- 's/__BIG_FIX_RELAY_1__/'${S_BIGFIX_RELAY_1}'/g' ${S_BIGFIX_CONFIG}

echo "     - sed -i -- 's/__BIG_FIX_RELAY_2__/'${S_BIGFIX_RELAY_2}'/g' ${S_BIGFIX_CONFIG}"
sed -i -- 's/__BIG_FIX_RELAY_2__/'${S_BIGFIX_RELAY_2}'/g' ${S_BIGFIX_CONFIG}

echo "     - cat ${S_BIGFIX_CONFIG}"
echo ""
echo "---------------------------------------------------"
cat ${S_BIGFIX_CONFIG}
echo "---------------------------------------------------"
echo ""
echo "   - cp ${S_BIGFIX_CONFIG} ${S_BIGFIX_VAR_DIR}/"
cp ${S_BIGFIX_CONFIG} ${S_BIGFIX_VAR_DIR}/

echo ""

echo "3. Staring BigFix Client..."
echo "   - /etc/init.d/besclient start"
/etc/init.d/besclient start
echo ""

echo "4. Done"
echo ""


