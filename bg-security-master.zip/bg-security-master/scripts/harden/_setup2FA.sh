#!/usr/bin/env bash

#
# Sets up 2FA using Google Authenticator
#

# Exit when a command fails
set -e

# Exit when undeclared variables are used 
set -o nounset

sudo apt-get install libpam-google-authenticator -y
#google-authenticator -t -f -d --rate-limit=3 --rate-time=30 -W
if ! grep  "^auth required pam_google_authenticator.so" /etc/pam.d/sshd; then
 echo '' >> /etc/pam.d/sshd
 echo $'auth required pam_google_authenticator.so' >> /etc/pam.d/sshd
fi
if grep  "^ChallengeResponseAuthentication" /etc/ssh/sshd_config; then
  sed -i "s/^ChallengeResponseAuthentication.*/ChallengeResponseAuthentication yes/" /etc/ssh/sshd_config
else
  echo '' >> /etc/ssh/sshd_config
  echo 'ChallengeResponseAuthentication yes' >> /etc/ssh/sshd_config
fi
systemctl restart sshd.service