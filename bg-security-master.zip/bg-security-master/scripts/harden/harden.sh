#!/usr/bin/env bash

#
# The purpose of this script is to harden Ubuntu systems.
#

# Exit when a command fails
set -e


USAGE="\nUsage: $0 --pre | --post"
  
if [ "$#" -lt 1 ]; then
  echo -e "$USAGE" >&2
  exit 1
fi

#
# Parsing input
#
POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    --pre)
    PRE='Y'
	  shift # past argument
	  ;;
    --post)
    POST='Y'
  	shift # past argument
  	;;    
    *)    # unknown option
     echo -e "$USAGE" >&2
    exit 1
#    POSITIONAL+=("$1") # save it in an array for later
#    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters



# Applying OS patches
apt-get update
apt-get -y upgrade
DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" dist-upgrade
apt-get -y autoremove

if [ "$PRE" = 'Y' ]; then
  ###
  ### Pre hardening actions
  ###

  # Setting DIR_MODE
  sed -i "s/^DIR_MODE=.*/DIR_MODE=0700/" /etc/adduser.conf

  # Setting UMASK value
  sed -i "s/^UMASK\s.*/UMASK 077/" /etc/login.defs

  # Set up motd and banner
  bash _setupMotd.sh

  # Set up NTP
  bash _setupNTP.sh

  # Enabling SSH Business Use Notice
  sed -i "s/^PrintMotd no/PrintMotd yes/" /etc/ssh/sshd_config

  # SSH Service Availability Management
  if grep  "MaxAuthTries" /etc/ssh/sshd_config; then
    sed -i "s/^MaxAuthTries.*/MaxAuthTries 5/" /etc/ssh/sshd_config
  else
    echo '' >> /etc/ssh/sshd_config
    echo 'MaxAuthTries 5' >> /etc/ssh/sshd_config
  fi

  # Set password Strength, Minimum Password Age and Maximum Password Age
  sed -i "s/^PASS_MAX_DAYS.*/PASS_MAX_DAYS 90/" /etc/login.defs
  sed -i "s/^PASS_MIN_DAYS.*/PASS_MIN_DAYS 1/" /etc/login.defs

  # Linux Kernel Denial of Service Prevention
  sed -i "s/^#net.ipv4.conf.all.accept_redirects = 0/net.ipv4.conf.all.accept_redirects = 0/" /etc/sysctl.conf
  sysctl -p
 
  # Configure retention and rotation of /var/log/syslog, /var/log/auth.log, /var/log/wtmp and /var/log/faillog
  bash _setupLogRetention.sh

  # Setup IBMsinit script 
  bash _setupIBMInit.sh

  # Remove insecure consoles in /etc/securetty
  bash _setupSecuretty.sh

  # Fixing non-absolute tasks in crontab
  bash _setupCron.sh
fi 


if [ "$POST" = 'Y' ]; then
  ###
  ### Post hardening actions
  ###

  # Configure PAM
  bash _setupPAM.sh

  # Set Maximum Password Age
  passwd -x 90 root
  passwd -n 1 root
  passwd

  # setup 2FA for SSH login
  bash _setup2FA.sh

  # create unique id for sysadmin
  bash _setupSysadmin.sh

  # Disabling root access via ssh
  sed -i "s/^PermitRootLogin yes/PermitRootLogin no/" /etc/ssh/sshd_config

  # Removing .ssh keys under /root/.ssh
  > /root/.ssh/authorized_keys

  # Set up auditd
  bash _setupAuditd.sh

   # Check hardening status with Tonic if it exists
  dpkg -l tonic
  if [ "$?" -eq 0 ]; then
    touch /etc/tonic/remind/SSH_Passphrases
    touch /etc/tonic/remind/Shared_Root_ID
    touch /etc/tonic/remind/Password_Expiry
    touch /etc/tonic/remind/Sudo_Secondary_Logging_revalidated
    touch /etc/tonic/remind/User_Resource_Requirements
    touch /etc/tonic/remind/Sudo_access_revalidated
    tonic -o ITCS
  fi
fi
