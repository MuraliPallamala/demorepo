#!/usr/bin/env bash

#
# Sets up NTP
#

# Exit when a command fails
set -e

# Exit when undeclared variables are used 
set -o nounset

timedatectl set-ntp no
sudo apt-get install ntp -y
sudo ntpq -p

/bin/cat <<EOM >/etc/ntp.conf
tinker panic 0 allan 1500 dispersion 15 step 0.128 stepout 900
statsdir /var/log/ntpstats/
leapfile /etc/ntp.leapseconds
driftfile /var/lib/ntp/ntp.drift

statistics loopstats peerstats clockstats
filegen loopstats file loopstats type day enable
filegen peerstats file peerstats type day enable
filegen clockstats file clockstats type day enable



disable monitor


server servertime.service.softlayer.com iburst minpoll 6 maxpoll 10
restrict servertime.service.softlayer.com nomodify notrap noquery

restrict default kod notrap nomodify nopeer noquery
restrict 127.0.0.1
restrict -6 default kod notrap nomodify nopeer noquery
restrict -6 ::1
EOM

# Set timezone to Australia
if grep  "^export TZ=" /etc/profile; then
  sed -i "s/^export TZ=.*/export TZ='Australia\/Melbourne'/" /etc/profile
else
  echo '' >> /etc/profile
  echo "export TZ='Australia/Melbourne'" >> /etc/profile
fi

service ntp restart
