#!/usr/bin/env bash

#
# Fixes non-absolute tasks in crontab
#

# Exit when a command fails
set -e

# Exit when undeclared variables are used 
set -o nounset

sed -i "s/run-parts/\/bin\/run-parts/g" /etc/crontab
sed -i "s/test/\/usr\/bin\/test/g" /etc/crontab
sed -i "s/date/\/usr\/bin\/date/g" /etc/cron.d/mdadm
sed -i "s/test/\/usr\/bin\/test/g" /etc/cron.d/popularity-contest