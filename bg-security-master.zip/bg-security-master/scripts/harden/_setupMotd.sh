#!/usr/bin/env bash

#
# Sets up motd and banner
#

# Exit when a command fails
set -e

# Exit when undeclared variables are used 
set -o nounset

/bin/cat <<EOM >/etc/motd
IBM's internal systems must only be used for conducting IBM's business, or for purposes authorized by IBM management.

Confidential IBM and customer data may be stored or processed on this system, if the Research IT Security Standard controls for systems that store or process Confidential data are sufficient to meet all legal and contractual obligations for the protection of the data.

Highly-sensitive data including Sensitive Personal Information (SPI), E-payment data, "Crown Jewel" data, Financially-significant data, or regulated health information (HIPAA or other privacy laws), may not be stored or processed on this system at any time.  

Personal information may be stored or processed on this system if a Global Privacy Assessment has determined that the system controls implemented on this system meet all applicable privacy law requirements.

Software technology, or technology design and implementation data, may not be stored on this system if its US State Department export classification is higher than Blue, or if other applicable export control laws prohibit unlicensed export of the technology to countries that are not on the US State Department list of embargoed/terrorist countries. This includes all data regulated under ITAR.
EOM

/bin/cat <<EOM >/etc/login.warn
IBM's internal systems must only be used for conducting IBM's business, or for purposes authorized by IBM management.

Confidential IBM and customer data may be stored or processed on this system, if the Research IT Security Standard controls for systems that store or process Confidential data are sufficient to meet all legal and contractual obligations for the protection of the data.

Highly-sensitive data including Sensitive Personal Information (SPI), E-payment data, "Crown Jewel" data, Financially-significant data, or regulated health information (HIPAA or other privacy laws), may not be stored or processed on this system at any time.  

Personal information may be stored or processed on this system if a Global Privacy Assessment has determined that the system controls implemented on this system meet all applicable privacy law requirements.

Software technology, or technology design and implementation data, may not be stored on this system if its US State Department export classification is higher than Blue, or if other applicable export control laws prohibit unlicensed export of the technology to countries that are not on the US State Department list of embargoed/terrorist countries. This includes all data regulated under ITAR.
EOM
sed -i "s/^#Banner .*/Banner \/etc\/login.warn/" /etc/ssh/sshd_config