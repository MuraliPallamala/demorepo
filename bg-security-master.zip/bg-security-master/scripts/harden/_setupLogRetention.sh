#!/usr/bin/env bash

#
# Configures log retention rules
#

# Exit when a command fails
set -e

# Exit when undeclared variables are used 
set -o nounset

sed -i "s/rotate 7/rotate 90/" /etc/logrotate.d/rsyslog
sed -i "s/rotate 4/rotate 13/" /etc/logrotate.d/rsyslog
sed -i "s/rotate 1/rotate 90/" /etc/logrotate.conf
touch /var/log/faillog
chmod --reference=/var/log/btmp /var/log/faillog
chown --reference=/var/log/btmp /var/log/faillog
sed -i "s/rotate 7/rotate 90/" /etc/logrotate.d/rsyslog



# Configure logrotation for dlt logs
/bin/cat <<EOM >/etc/logrotate.d/dlt
/opt/dlt/logs/*.log /opt/dlt/logs/*/*.log
{
        rotate 90
        copytruncate
        daily
        missingok
        notifempty
        compress
}
EOM