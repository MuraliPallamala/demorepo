#!/usr/bin/env bash

#
# Configures auditd as a mechanism for secondary logging.
#

# Exit when a command fails
set -e

# Exit when undeclared variables are used 
set -o nounset

apt-get install auditd -y
if ! grep  "^-a exit,always -F arch=b64 -F euid=0 -S execve" /etc/audit/audit.rules; then
  echo '' >> /etc/audit/audit.rules
  echo '-a exit,always -F arch=b64 -F euid=0 -S execve' >> /etc/audit/audit.rules
  echo '-a exit,always -F arch=b32 -F euid=0 -S execve' >> /etc/audit/audit.rules
fi
if grep  "^audit=1" /etc/default/grub; then
  sed -i "s/^audit=.*/audit=1/" /etc/default/grub
else
  echo '' >> /etc/default/grub
  echo 'audit=1' >> /etc/default/grub
fi

# Disable auditd log rotation
sed -i "s/^max_log_file_action .*/max_log_file_action = IGNORE/" /etc/audit/auditd.conf

# Configure logrotation for auditd
/bin/cat <<EOM >/etc/logrotate.d/auditd
/var/log/audit/audit.log
{
        rotate 90
        daily
        missingok
        notifempty
        compress
        postrotate
                /usr/sbin/service auditd restart
        endscript
}
EOM

service auditd restart