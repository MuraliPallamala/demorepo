#!/usr/bin/env bash

#
# Sets up umask rules
#

# Exit when a command fails
set -e

/bin/cat <<EOM >/etc/profile.d/IBMsinit.csh
if (\$uid > 199) then
    umask 077
endif
EOM
chmod 755 /etc/profile.d/IBMsinit.csh

/bin/cat <<EOM >/etc/profile.d/IBMsinit.sh
if [ \$UID -gt 199 ]; then
    umask 077
fi
EOM
chmod 755 /etc/profile.d/IBMsinit.sh

