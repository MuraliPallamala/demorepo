#!/usr/bin/env bash

#
# Adds the sysadmin users
#

# Exit when a command fails
set -e

# Exit when undeclared variables are used 
set -o nounset

SYSADMIN=${1:-"prjlygon"}

if ! id -u ${SYSADMIN}; then
  echo "Creating sysadmin ${SYSADMIN}"
  adduser ${SYSADMIN} || true
  usermod -aG sudo ${SYSADMIN} || true
  passwd -x 90 ${SYSADMIN} || true
  passwd -n 1 ${SYSADMIN} || true
  chage -d 0 ${SYSADMIN} || true
  su -c "google-authenticator -t -f -d --rate-limit=3 --rate-time=30" ${SYSADMIN}
fi