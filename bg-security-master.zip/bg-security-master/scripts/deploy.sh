#!/usr/bin/env bash

#
# Deploys the application to a specified host.
# This is script is supposed to be run from the sysadmin machine.
#

set -e


USAGE="\nUsage: $0 --host <host> <OPTIONS>\n\nOPTIONS: \n --domain <domain> | --all | --skip-login | --dedicated-host-provision | --dedicated-virtual-servers-provision | --pre-firewall-setup | --reload-os | --pre-harden | --bigfix-deploy | --logging-deploy | --cos-bucket-provision | --container-orchestration-deploy | --services-deploy | --application-deploy | --post-harden | --post-firewall-setup"
  
if [ "$#" -lt 1 ]; then
  echo -e "$USAGE" >&2
  exit 1
fi

#
# Parsing input
#
DOMAIN=dlt.res.ibm.com
ORGANIZATION=wilcon
SPACE=lygonspace

POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    --skip-login)
    OPTION_SKIP_LOGIN='Y'
	  shift # past argument
	  ;;
    --dedicated-host-provision)
    OPTION_DEDICATED_HOST_PROVISION='Y'
  	shift # past argument
  	;;    
    --dedicated-virtual-servers-provision)
    OPTION_DEDICATED_VIRTUAL_SERVERS_PROVISION='Y'
  	shift # past argument
  	;;
    --cos-bucket-provision)
    OPTION_COS_BUCKET_PROVISION='Y'
  	shift # past argument
  	;;    
    --bigfix-deploy)
    OPTION_BIGFIX_DEPLOY='Y'
  	shift # past argument
  	;;
    --logging-deploy)
    OPTION_LOGGING_DEPLOY='Y'
  	shift # past argument
  	;;
    --services-deploy)
    OPTION_SERVICES_DEPLOY='Y'
  	shift # past argument
  	;;
    --container-orchestration-deploy)
    OPTION_CONTAINER_ORCHESTRATION_DEPLOY='Y'
  	shift # past argument
  	;;
    --application-deploy)
    OPTION_APPLICATION_DEPLOY='Y'
    shift # past argument
    ;;
    --pre-harden)
    OPTION_PRE_HARDEN='Y'
    shift # past argument
    ;;
    --post-harden)
    OPTION_POST_HARDEN='Y'
    shift # past argument
    ;;
    --pre-firewall-setup)
    OPTION_PRE_FIREWALL_SETUP='Y'
    shift # past argument
    ;;
    --post-firewall-setup)
    OPTION_POST_FIREWALL_SETUP='Y'
    shift # past argument
    ;;
	  --reload-os)
    OPTION_RELOAD_OS='Y'
	  shift # past argument
	  ;;
    --all)
    OPTION_DEDICATED_HOST_PROVISION='Y'
    OPTION_DEDICATED_VIRTUAL_SERVERS_PROVISION='Y'
    OPTION_BIGFIX_DEPLOY='Y'
    OPTION_LOGGING_DEPLOY='Y'
    OPTION_SERVICES_DEPLOY='Y'
    OPTION_CONTAINER_ORCHESTRATION_DEPLOY='Y'
    OPTION_APPLICATION_DEPLOY='Y'
    OPTION_PRE_HARDEN='Y'
    OPTION_POST_FIREWALL_SETUP='Y'
    OPTION_POST_HARDEN='Y'    
    shift # past argument
    ;;
    --host)
    HOST="$2"
    shift # past argument
    shift
    ;;
    --domain)
    DOMAIN="$2"
    shift # past argument
    shift
    ;;     
    *)    # unknown option
     echo -e "$USAGE" >&2
    exit 1
#    POSITIONAL+=("$1") # save it in an array for later
#    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters


if [[ -z "$HOST" ]]; then
  echo -e "$USAGE" >&2
  exit 1
fi

if [ "$OPTION_SKIP_LOGIN" != 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Logging in into IBM Cloud via API_KEY'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''

  if [[ -z "$API_KEY" ]]; then
    echo "You need to set the environment variable for the API_KEY first" >&2
    exit 1
  fi
  ibmcloud login --apikey $API_KEY
  #bx sl init -c 1703041
fi

HOST_IP=$(bx sl vs list | sed -n '1!p' | tr -s ' ' | grep "$HOST " | grep $DOMAIN | cut -d ' ' -f7)
if [[ -z "$HOST_IP" ]]; then
  echo "Not able to retrieve private ip of the host" >&2
  exit 1
fi

if [ "$OPTION_PRE_FIREWALL_SETUP" = 'Y' ]; then
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Setting up the firewall (Security Groups and iptables)'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  # 
  # Setup firewall (Security Groups and iptables)
  #
  bash firewall/remove-all-security-groups.sh --host-ip $HOST_IP
  bash firewall/create-pre-security-groups.sh --host-ip $HOST_IP
fi

# Variables
echo ''
echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
echo '# Setting up variables'
echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
echo ''
ACCOUNT_ID=$(ibmcloud account list | grep "GBS c/o Scentre Limited" | tr -s ' ' | cut -d ' ' -f1)
SSH_KEY_LABEL=prjlygon
SSH_KEY_ID=$(bx sl security sshkey-list | sed -n '1!p' | grep $SSH_KEY_LABEL | tr -s ' ' | cut -d ' ' -f1)
if [ -z $SSH_KEY_ID ]; then
  echo "You need to have a ssh key labeled as $SSH_KEY_LABEL in IBM Cloud to be used during provisioning"
  exit
fi

ALLOW_OUTBOUND_ID=$(bx sl securitygroup list | sed -n '1!p' | grep "allow_outbound " | tr -s ' ' | cut -d ' ' -f1)
ALLOW_SSH_ID=$(bx sl securitygroup list | sed -n '1!p' | grep "allow_ssh " | tr -s ' ' | cut -d ' ' -f1)
ALLOW_ICMP_ID=$(bx sl securitygroup list | sed -n '1!p' | grep "allow_icmp " | tr -s ' ' | cut -d ' ' -f1)
if [ -z "$ALLOW_OUTBOUND_ID" ]; then
  echo "You need to have allow_outbound security group defined to be associated with all private interfaces for all VMs"
  exit
fi
if [ -z "$ALLOW_SSH_ID" ]; then
  echo "You need to have allow_ssh security group defined to be associated with all private interfaces for all VMs"
  exit
fi
if [ -z "$ALLOW_ICMP_ID" ]; then
  echo "You need to have allow_icmp security group defined to be associated with all private interfaces for all VMs"
  exit
fi


#################################################################################################################################


if [ "$OPTION_DEDICATED_HOST_PROVISION" = 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Provisioning Dedicated Host'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  #TODO This was performed manually using the IBM Cloud Customer Portal. 
  bash infrastructure/provision_dedicated_host.sh
fi


#################################################################################################################################


if [ "$OPTION_DEDICATED_VIRTUAL_SERVERS_PROVISION" = 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Provisioning Dedicated Virtual Servers'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  #TODO This was performed manually using the IBM Cloud Customer Portal.
  bash infrastructure/provision_dedicated_virtual_server.sh
fi


#################################################################################################################################


if [ "$OPTION_RELOAD_OS" = 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Reloading Operating System on Dedicated Virtual Server'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  bash infrastructure/reload_os.sh --host-ip $HOST_IP
fi


#################################################################################################################################

echo ''
echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
echo '# Creating sandbox folder on host'
echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
echo ''
ssh -o "StrictHostKeyChecking no" root@$HOST_IP mkdir -p /root/sandbox

#################################################################################################################################


if [ "$OPTION_PRE_HARDEN" = 'Y' ]; then
  #
  # Harden VM
  # At this initial stage, the VMs should be acessible via ssh using a private key.
  # After hardening, the VMs will only be accessible via ssh using one of the sysadmin accounts and 2FA.
  #
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Pre hardening Virtual Dedicated Server'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  
  scp -r harden root@$HOST_IP:/root/sandbox/.
  
ssh -o "StrictHostKeyChecking no" root@$HOST_IP /bin/bash << EOF
  cd /root/sandbox/harden
  bash harden.sh --pre
EOF
  
#   echo "# Launching another tab"
# osascript <<-eof
#   tell application "iTerm2"
#     # Create Window.
#     tell current window
#       create tab with default profile
#     end tell
#
#     tell session 1 of current tab of current window
#       set name to "Pre hardening"
#       write text "ssh root@$HOST_IP"
#       write text "cd /root/sandbox/harden"
#       write text "bash harden.sh --pre" newline NO
#     end tell
#
#   end tell
# eof
fi


#################################################################################################################################



if [ "$OPTION_BIGFIX_DEPLOY" = 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Deploying Bigfix'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  
  echo "# Copying Bigfix installation scripts to host"
  scp -r bigfix root@$HOST_IP:/root/sandbox/.
  scp env/bigfix.$HOST.env root@$HOST_IP:/root/sandbox/bigfix/.env
  
ssh -o "StrictHostKeyChecking no" root@$HOST_IP /bin/bash << EOF
  cd /root/sandbox/bigfix
  bash install-bigfix.sh
EOF
  
#   echo "# Launching another tab"
#
# osascript <<-eof
#   tell application "iTerm2"
#     # Create Window.
#     tell current window
#       create tab with default profile
#     end tell
#
#     tell session 1 of current tab of current window
#       set name to "Installing Bigfix"
#       write text "ssh root@$HOST_IP"
#       write text "cd /root/sandbox/bigfix"
#       write text "bash install-bigfix.sh" newline NO
#
#     end tell
#
#   end tell
# eof
  
fi


#################################################################################################################################


if [ "$OPTION_LOGGING_DEPLOY" = 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Deploying Logging server'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  ibmcloud target -o $ORGANIZATION -s $SPACE
  
  LSF_TARGET="ingest-au-syd.logging.bluemix.net:9091"
  LSF_TOKEN="$(ibmcloud logging token-get | tail -n 1 | tr -s ' ')"
  LSF_TENANT_ID="$(echo $LSF_TOKEN | cut -d ' ' -f1)"
  LSF_PASSWORD="$(echo $LSF_TOKEN | cut -d ' ' -f2)"
  LSF_GROUP_ID="$HOST.$DOMAIN"
  
  echo "# Setting logging retention to 90 days"
  ibmcloud logging option-update -r space -e 90
  
  echo "# Copying Logging installation scripts to host"
  scp -r logging root@$HOST_IP:/root/sandbox/.
  
ssh -o "StrictHostKeyChecking no" root@$HOST_IP /bin/bash << EOF
mkdir -p /etc/mt-logstash-forwarder
mkdir -p /etc/mt-logstash-forwarder/conf.d
touch /etc/mt-logstash-forwarder/mt-lsf-config.sh
EOF

source env/logging.$HOST.env
for conf in "${logging_confs[@]}"
do
   echo "$conf"
   scp -r logging/conf.d/$conf.conf root@$HOST_IP:/etc/mt-logstash-forwarder/conf.d/.
done


  echo -e "LSF_INSTANCE_ID=\"$HOST.$DOMAIN\"\nLSF_TARGET=\"$LSF_TARGET\"\nLSF_TENANT_ID=\"$LSF_TENANT_ID\"\nLSF_PASSWORD=\"$LSF_PASSWORD\"\nLSF_GROUP_ID=\"$LSF_GROUP_ID\"" | ssh -o "StrictHostKeyChecking no" root@$HOST_IP "cat > /etc/mt-logstash-forwarder/mt-lsf-config.sh"

  
ssh -o "StrictHostKeyChecking no" root@$HOST_IP /bin/bash << EOF
  cd /root/sandbox/logging
  bash install-logging.sh
EOF
  
#   echo "# Launching another tab"
#
# osascript <<-eof
#   tell application "iTerm2"
#     # Create Window.
#     tell current window
#       create tab with default profile
#     end tell
#
#     tell session 1 of current tab of current window
#       set name to "Installing Bigfix"
#       write text "ssh root@$HOST_IP"
#       write text "cd /root/sandbox/logging"
#       write text "bash install-logging.sh" newline NO
#
#     end tell
#
#   end tell
# eof

  
  
fi


#################################################################################################################################



if [ "$RESOURCE_GROUP_NAME" = 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Provisioning COS buckets for the configuration environment'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  
  COS_NAME="Cloud Object Storage-prjlygon"
  RESOURCE_GROUP_NAME="Project-bgx"
  
  bx target -g "$RESOURCE_GROUP_NAME"
  
  bx resource service-instances | grep "$COS_NAME"
  RESULT=$?
  # If the COS does not exist
  if [ $RESULT == 1 ]; then
    echo ''
    echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
    echo "Create the a Cloud Object Storage in Sydney region named as \"$COS_NAME\""
    echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
    echo ''
    exit
    bx resource service-instance-create "$COS_NAME" cloud-object-storage standard au-syd
  fi
  
  # Create buckets for host
  TOKEN=$(bx iam oauth-tokens | grep IAM | tr -s ' ' | cut -d ' ' -f4)
  #
  curl "https://s3.mel01.objectstorage.service.networklayer.com/leonardo-conf/?acl" -H "Authorization: bearer $TOKEN"
  
  # Listing buckets
  #
  # curl "https://s3.mel01.objectstorage.softlayer.net/" -H "Authorization: bearer $(bx iam oauth-tokens | grep IAM | tr -s ' ' | cut -d ' ' -f4)" -H "ibm-service-instance-id: crn:v1:bluemix:public:cloud-object-storage:global:a/c15ecdd5890bdc705dd4e448a0a4b68d:008d0e4c-23c7-43bf-88e8-ea03f1d3c6e8::"
  #
  #
  # curl -X "GET" "https://s3.mel01.objectstorage.service.networklayer.com/buckets" \
  #      -H "Authorization: Bearer $TOKEN" \
  #      -H "ibm-service-instance-id: <resource-instance-id>"
  #
  # curl -X "PUT" "https://s3.mel01.objectstorage.service.networklayer.com/<bucket-name>" \
  #      -H "Authorization: Bearer $TOKEN" \
  #      -H "ibm-service-instance-id: <resource-instance-id>"

  declare -a SERVICE_CREDENTIAL_LABELS=("newco-admin-conf" "newco-admin-core-conf" "newco-user-conf" "newco-user-core-conf" "newco-services-conf" "newco-services-core-conf" "leonardo-conf" "leonardo-core-conf" "raffaello-conf" "raffaello-core-conf" "michelangelo-conf" "michelangelo-core-conf" "donatello-conf" "donatello-core-conf" "mock-ibp-conf" "support-conf")
  for SERVICE_CREDENTIAL_LABEL in "${SERVICE_CREDENTIAL_LABELS[@]}"
  do
     echo "$service_id"
     bx iam service-id-create $SERVICE_CREDENTIAL_LABEL
     SERVICE_ID=$(bx iam service-ids | grep $SERVICE_CREDENTIAL_LABEL | tr -s ' ' | cut -d ' ' -f1)
     bx resource service-key-create "$SERVICE_CREDENTIAL_LABEL" Reader --instance-name "$COS_NAME" --service-id $SERVICE_ID --parameters '{"HMAC":true}'
     SERVICE_INSTANCE_ID=$(bx resource service-instances --long | grep "$COS_NAME" | tr -s ' ' | cut -d ' ' -f2)
     bx iam service-policy-create $SERVICE_ID  -r Reader --service-name cloud-object-storage --service-instance $SERVICE_INSTANCE_ID --resource-type bucket --resource $SERVICE_CREDENTIAL_LABEL 
  done
fi



#################################################################################################################################


if [ "$OPTION_CONTAINER_ORCHESTRATION_DEPLOY" = 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Installing Container Orchestration environment'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  
#   echo "# Copying Container Orchestration installation scripts to host"
#   scp -r container-orchestration root@$HOST_IP:/root/sandbox/.
#   scp env/container-orchestration.$HOST.env root@$HOST_IP:/root/sandbox/container-orchestration/.env
#
# ssh -o "StrictHostKeyChecking no" root@$HOST_IP /bin/bash << EOF
# cd /root/sandbox/container-orchestration
# ./install-container-orchestration.sh
# EOF
  
  source env/container-orchestration.$HOST.env
  for bucket in "${buckets[@]}"
  do
    echo "Bucket $bucket"
    access_key_id=$(bx resource service-key $bucket | grep access_key_id | tr -s ' ' | cut -d ' ' -f3)
    secret_access_key=$(bx resource service-key $bucket | grep secret_access_key | tr -s ' ' | cut -d ' ' -f3)
      
ssh -o "StrictHostKeyChecking no" root@$HOST_IP /bin/bash << EOF
mkdir -p /opt/dlt/data/conf
echo -e "$access_key_id:$secret_access_key" > /etc/passwd-s3fs
chmod 600 /etc/passwd-s3fs
echo 'test'
if ! grep  "^s3fs#$bucket /opt/dlt/data/conf fuse _netdev,allow_other,umask=0022,use_path_request_style,url=https://s3.mel01.objectstorage.service.networklayer.com/ 0 0" /etc/fstab; then
  echo '' >> /etc/fstab
  echo "s3fs#$bucket /opt/dlt/data/conf fuse _netdev,allow_other,umask=0022,use_path_request_style,url=https://s3.mel01.objectstorage.service.networklayer.com/ 0 0" >> /etc/fstab
fi
cd /root/sandbox/container-orchestration
./_mountCOS.sh
EOF
  done

#   echo "# Launching another tab"
#
# osascript <<-eof
#   tell application "iTerm2"
#     # Create Window.
#     tell current window
#       create tab with default profile
#     end tell
#
#     tell session 1 of current tab of current window
#       set name to "Installing Container Orchestration environment"
#       write text "ssh root@$HOST_IP"
#       write text "cd /root/sandbox/container-orchestration"
#       write text "bash install-container-orchestration.sh" newline NO
#
#     end tell
#
#   end tell
# eof

fi


#################################################################################################################################


if [ "$OPTION_SERVICES_DEPLOY" = 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Deploying Services (Keycloak)'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''

fi


#################################################################################################################################


if [ "$OPTION_APPLICATION_DEPLOY" = 'Y' ]; then
  echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Deploying the application'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  # TODO
fi


#################################################################################################################################


if [ "$OPTION_POST_HARDEN" = 'Y' ]; then
  #
  # Harden VMs
  # At this initial stage, the VMs should be acessible via ssh using a private key.
  # After hardening, the VMs will only be accessible via ssh using one of the sysadmin accounts and 2FA.
  #
  # echo ''
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Post hardening the Virtual Dedicated Servers'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''

ssh -o "StrictHostKeyChecking no" root@$HOST_IP /bin/bash << EOF
  cd /root/sandbox/harden
  bash harden.sh --post
EOF
fi


#################################################################################################################################


if [ "$OPTION_POST_FIREWALL_SETUP" = 'Y' ]; then
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo '# Setting up the firewall (Security Groups and iptables)'
  echo '# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #'
  echo ''
  # 
  # Setup firewall (Security Groups and iptables)
  #
  bash firewall/remove-all-security-groups.sh
  bash firewall/create-post-security-groups.sh
fi