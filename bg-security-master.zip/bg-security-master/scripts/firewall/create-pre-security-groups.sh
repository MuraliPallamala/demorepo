#!/usr/bin/env bash

#
# Creates the security groups for the environment
#

# Exit when a command fails
set -e
#set -o xtrace

USAGE="\nUsage: $0 --host-ip <HOST_IP>"
  
#
# Parsing input
#
POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    --host-ip)
    HOST_IP="$2"
    shift # past argument
    shift
  	;;    
    *)    # unknown option
     echo -e "$USAGE" >&2
    exit 1
#    POSITIONAL+=("$1") # save it in an array for later
#    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters
 

# Creating environment variables for each VM to map name with id
IFS=$'\n'
if [ "$ALL" = 'Y' ]; then
  INSTANCES=( $(bx sl vs list | sed -n '1!p' | tr -s ' ' | cut -d ' ' -f1-7) )
else
  INSTANCES=( $(bx sl vs list | sed -n '1!p' | tr -s ' ' | cut -d ' ' -f1-7 | grep $HOST_IP) )
fi
unset IFS
#printf '%s\n' "${INSTANCES[@]}" | grep "leonardo dlt" | cut -d ' ' -f1
for instance in "${INSTANCES[@]}"; do
  name=bg_$(echo $instance | cut -d ' ' -f2 | tr - _)
  id=$(echo $instance | cut -d ' ' -f1)
  export $name=$id
done


PRIVATE_NETWORK="10.118.78.192/26"

# Get list of available security groups
IFS=$'\n'
SECURITY_GROUPS=( $(bx sl securitygroup list | sed -n '1!p' | tr -s ' ' | cut -d ' ' -f1-2) )
unset IFS

# Allow all egress traffic from private network 
ALLOW_OUTBOUND=allow_outbound
ID_ALLOW_OUTBOUND=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_OUTBOUND$" | cut -d ' ' -f1`

ALLOW_ALL=allow_all
ID_ALLOW_ALL=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_ALL$" | cut -d ' ' -f1`

sleep 1
wait

#
# Security groups for jumpbox.dlt.res.ibm.com
#
VM=$bg_jumpbox
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for bigfix.dlt.res.ibm.com
#
VM=$bg_bigfix
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for logging.dlt.res.ibm.com
#
VM=$bg_mock_ibp
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for services.dlt.res.ibm.com
#
VM=$bg_services
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for services-core.dlt.res.ibm.com
#
VM=$bg_services_core
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for admin.dlt.res.ibm.com
#
VM=$bg_admin
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for admin-core.dlt.res.ibm.com
#
VM=$bg_admin_core
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for user.dlt.res.ibm.com
#
VM=$bg_user
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for user-core.dlt.res.ibm.com
#
VM=$bg_user_core
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for donatello.dlt.res.ibm.com
#
VM=$bg_donatello
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for donatello-core.dlt.res.ibm.com
#
VM=$bg_donatello_core
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for leonardo.dlt.res.ibm.com
#
VM=$bg_leonardo
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for leonardo-core.dlt.res.ibm.com
#
VM=$bg_leonardo_core
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for michelangelo.dlt.res.ibm.com
#
VM=$bg_michelangelo
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for michelangelo-core.dlt.res.ibm.com
#
VM=$bg_michelangelo_core
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for raffaello.dlt.res.ibm.com
#
VM=$bg_raffaello
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

#
# Security groups for raffaello-core.dlt.res.ibm.com
#
VM=$bg_raffaello_core
if [ ! -z "$VM" ]; then
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_ALL -s $VM -i private || true
  bx sl securitygroup interface-add $ID_ALLOW_OUTBOUND -s $VM -i public || true
  bx sl vs reboot -f --soft $VM &
  sleep 1
fi

wait

VM_IP=$(bx sl vs list | grep $HOST_IP | tr -s ' ' | cut -d ' ' -f7)
printf "%s" "waiting for $HOST_IP ..."
while ! ping -c 1 -W 1 $VM_IP &> /dev/null
do
    printf "%c" "."
done
printf "\n%s\n"  "Server is back online"
sleep 10

echo '#############'
echo '####DONE#####'
echo '#############'
