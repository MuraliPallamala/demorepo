#!/usr/bin/env bash

#
# Removes the security groups for the environment
#

# Exit when a command fails
set -e
#set -o xtrace

USAGE="\nUsage: $0 --host-ip <HOST_IP> | --all"
  
#
# Parsing input
#
POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    --all)
    ALL='Y'
	  shift # past argument
	  ;;
    --host-ip)
    HOST_IP="$2"
    shift # past argument
    shift
  	;;    
    *)    # unknown option
     echo -e "$USAGE" >&2
    exit 1
#    POSITIONAL+=("$1") # save it in an array for later
#    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters

# Creating environment variables for each VM to map name with id
IFS=$'\n'
if [ "$ALL" = 'Y' ]; then
  INSTANCES=( $(bx sl vs list | sed -n '1!p' | tr -s ' ' | cut -d ' ' -f1-7) )
else
  INSTANCES=( $(bx sl vs list | sed -n '1!p' | tr -s ' ' | cut -d ' ' -f1-7 | grep $HOST_IP) )
fi
unset IFS
#printf '%s\n' "${INSTANCES[@]}" | grep "leonardo dlt" | cut -d ' ' -f1
for instance in "${INSTANCES[@]}"; do
  name=bg_$(echo $instance | cut -d ' ' -f2 | tr - _)
  id=$(echo $instance | cut -d ' ' -f1)
  export $name=$id
  echo "$name=$id"
done


PRIVATE_NETWORK="10.118.78.192/26"

# Get list of available security groups
IFS=$'\n'
SECURITY_GROUPS=( $(bx sl securitygroup list | sed -n '1!p' | tr -s ' ' | cut -d ' ' -f1-2) )
unset IFS

#
# Unassociate security groups from instances
#
#for instance in "${INSTANCES[@]}"; do
for security_group in "${SECURITY_GROUPS[@]}"; do
  sg=$(echo $security_group | cut -d ' ' -f1)
  if bx sl securitygroup interface-list $sg | grep "No interfaces are binded to security group"; then
    echo "Skipping security group $sg because there are no interfaces are binded to it"
  else
    for instance in "${INSTANCES[@]}"; do
      id=$(echo $instance | cut -d ' ' -f1)
      name=bg_$(echo $instance | cut -d ' ' -f2 | tr - _)
      echo "Removing security rules for VS $name"
      bx sl securitygroup interface-remove $sg -s $id -i public || true &
      bx sl securitygroup interface-remove $sg -s $id -i private || true &
    done
    sleep 1
  fi
done

wait

# #
# # Deleting security groups
# #
# ALLOW_BIGFIX_RELAY=allow_bigfix_relay
# ID_ALLOW_BIGFIX_RELAY=`bx sl securitygroup list | grep $ALLOW_BIGFIX_RELAY | cut -d ' ' -f 1`
# if [ ! -z "$ID_ALLOW_BIGFIX_RELAY" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_BIGFIX_RELAY &
# fi
#
# ALLOW_BIGFIX_CLIENT=allow_bigfix_client
# ID_ALLOW_BIGFIX_CLIENT=`bx sl securitygroup list | grep $ALLOW_BIGFIX_CLIENT | cut -d ' ' -f 1`
# if [ ! -z "$ID_ALLOW_BIGFIX_CLIENT" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_BIGFIX_CLIENT &
# fi
#
# ALLOW_SSH_FROM_JUMPBOX_ONLY=allow_ssh_from_jumpbox_only
# ID_ALLOW_SSH_FROM_JUMPBOX_ONLY=`bx sl securitygroup list | grep $ALLOW_SSH_FROM_JUMPBOX_ONLY | cut -d ' ' -f 1`
# if [ ! -z "$ID_ALLOW_SSH_FROM_JUMPBOX_ONLY" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_SSH_FROM_JUMPBOX_ONLY &
# fi
#
# ALLOW_ICMP=allow_icmp
# ID_ALLOW_ICMP=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_ICMP$" | cut -d ' ' -f1`
# if [ ! -z "$ID_ALLOW_ICMP" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_ICMP &
# fi
#
# ALLOW_HTTPS_CORE=allow_https_core
# ID_ALLOW_HTTPS_CORE=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE$" | cut -d ' ' -f1`
# if [ ! -z "$ID_ALLOW_HTTPS_CORE" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_HTTPS_CORE &
# fi
#
# ALLOW_HTTPS_CORE_MICHELANGELO=allow_https_core_michelangelo
# ID_ALLOW_HTTPS_CORE_MICHELANGELO=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_MICHELANGELO$" | cut -d ' ' -f1`
# if [ ! -z "$ID_ALLOW_HTTPS_CORE_MICHELANGELO" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_HTTPS_CORE_MICHELANGELO &
# fi
#
# ALLOW_HTTPS_CORE_RAFFAELLO=allow_https_core_raffaello
# ID_ALLOW_HTTPS_CORE_RAFFAELLO=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_RAFFAELLO$" | cut -d ' ' -f1`
# if [ ! -z "$ID_ALLOW_HTTPS_CORE_RAFFAELLO" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_HTTPS_CORE_RAFFAELLO &
# fi
#
# ALLOW_HTTPS_CORE_DONATELLO=allow_https_core_donatello
# ID_ALLOW_HTTPS_CORE_DONATELLO=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_DONATELLO$" | cut -d ' ' -f1`
# if [ ! -z "$ID_ALLOW_HTTPS_CORE_DONATELLO" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_HTTPS_CORE_DONATELLO &
# fi
#
# ALLOW_HTTPS_CORE_LEONARDO=allow_https_core_leonardo
# ID_ALLOW_HTTPS_CORE_LEONARDO=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_LEONARDO$" | cut -d ' ' -f1`
# if [ ! -z "$ID_ALLOW_HTTPS_CORE_LEONARDO" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_HTTPS_CORE_LEONARDO &
# fi
#
# ALLOW_HTTPS_CORE_USER=allow_https_core_user
# ID_ALLOW_HTTPS_CORE_USER=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_USER$" | cut -d ' ' -f1`
# if [ ! -z "$ID_ALLOW_HTTPS_CORE_USER" ]; then
#   bx sl securitygroup delete -f $ID_ALLOW_HTTPS_CORE_USER &
# fi
#
# wait
#
# # bigfix instance should allow income connections from all the other VMs via private network
# # bigfix instance should allow outgoing connections to bigfix server in US via public network
# ALLOW_BIGFIX_RELAY=allow_bigfix_relay
# ID_ALLOW_BIGFIX_RELAY=`bx sl securitygroup list | grep $ALLOW_BIGFIX_RELAY | cut -d ' ' -f 1`
# if [ -z "$ID_ALLOW_BIGFIX_RELAY" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_BIGFIX_RELAY..."
#   bx sl securitygroup create -n $ALLOW_BIGFIX_RELAY -d "allows ingress connections from all the other VMs via private network and allows egress connections to bigfix server in US via public network"
#   ID_ALLOW_BIGFIX_RELAY=`bx sl securitygroup list | grep $ALLOW_BIGFIX_RELAY | cut -d ' ' -f 1`
#   bx sl securitygroup rule-add -r 129.34.20.42 -d egress -e IPv4 -M 52311 -m 52311 -p tcp $ID_ALLOW_BIGFIX_RELAY
#   bx sl securitygroup rule-add -r 129.34.20.42 -d ingress -e IPv4 -M 52311 -m 52311 -p udp $ID_ALLOW_BIGFIX_RELAY
#   bx sl securitygroup rule-add -r 129.34.20.42 -d ingress -e IPv4 -M 52311 -m 52311 -p tcp $ID_ALLOW_BIGFIX_RELAY
#   bx sl securitygroup rule-add -r $PRIVATE_NETWORK -d ingress -e IPv4 -M 52311 -m 52311 -p udp $ID_ALLOW_BIGFIX_RELAY
# fi
#
# # bigfix clients should allow outgoing connections to bigfix relay via the private network
# ALLOW_BIGFIX_CLIENT=allow_bigfix_client
# ID_ALLOW_BIGFIX_CLIENT=`bx sl securitygroup list | grep $ALLOW_BIGFIX_CLIENT | cut -d ' ' -f 1`
# if [ -z "$ID_ALLOW_BIGFIX_CLIENT" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_BIGFIX_CLIENT..."
#   bx sl securitygroup create -n $ALLOW_BIGFIX_CLIENT -d "allows egress connections to bigfix server in US via public network"
#   bigfix_relay_private_ip=`printf '%s\n' "${INSTANCES[@]}" | grep "bigfix" | cut -d ' ' -f7`
#   ID_ALLOW_BIGFIX_CLIENT=`bx sl securitygroup list | grep $ALLOW_BIGFIX_CLIENT | cut -d ' ' -f 1`
#   bx sl securitygroup rule-add -r $bigfix_relay_private_ip -d egress -e IPv4 -M 52311 -m 52311 -p udp $ID_ALLOW_BIGFIX_CLIENT
# fi
#
# # all VMs except for the jumpbox should only allow income ssh connections from the jumpbox via the private network
# ALLOW_SSH_FROM_JUMPBOX_ONLY=allow_ssh_from_jumpbox_only
# ID_ALLOW_SSH_FROM_JUMPBOX_ONLY=`bx sl securitygroup list | grep $ALLOW_SSH_FROM_JUMPBOX_ONLY | cut -d ' ' -f 1`
# if [ -z "$ID_ALLOW_SSH_FROM_JUMPBOX_ONLY" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_SSH_FROM_JUMPBOX_ONLY..."
#   bx sl securitygroup create -n $ALLOW_SSH_FROM_JUMPBOX_ONLY -d "allows ingress ssh connections from the jumpbox"
#   ID_ALLOW_SSH_FROM_JUMPBOX_ONLY=`bx sl securitygroup list | grep $ALLOW_SSH_FROM_JUMPBOX_ONLY | cut -d ' ' -f 1`
#   jumpbox_private_ip=`printf '%s\n' "${INSTANCES[@]}" | grep "jumpbox" | cut -d ' ' -f7`
#   bx sl securitygroup rule-add -r $jumpbox_private_ip -d ingress -e IPv4 -M 22 -m 22 -p tcp $ID_ALLOW_SSH_FROM_JUMPBOX_ONLY
# fi
# # ALLOW_SSH_FROM_JUMPBOX_ONLY=allow_ssh
# # ID_ALLOW_SSH_FROM_JUMPBOX_ONLY=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_SSH_FROM_JUMPBOX_ONLY$" | cut -d ' ' -f1`
#
# # Only the jumpbox should have the allow_ssh security group associated with it
#
# # Allow all VMs to be pingable via the private network
# ALLOW_ICMP=allow_icmp
# ID_ALLOW_ICMP=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_ICMP$" | cut -d ' ' -f1`
# if [ -z "$ID_ALLOW_ICMP" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_ICMP..."
#   bx sl securitygroup create -n $ALLOW_ICMP -d "Allow all ingress ICMP traffic."
#   ID_ALLOW_ICMP=`bx sl securitygroup list | grep $ALLOW_ICMP | cut -d ' ' -f 1`
#   bx sl securitygroup rule-add -r 0.0.0.0/0 -d ingress -e IPv4 -m 8 -M 0 -p icmp $ID_ALLOW_ICMP
# fi
#
# ALLOW_HTTPS_CORE=allow_https_core
# ID_ALLOW_HTTPS_CORE=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE$" | cut -d ' ' -f1`
# if [ -z "$ID_ALLOW_HTTPS_CORE" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_HTTPS_CORE..."
#   bx sl securitygroup create -n $ALLOW_HTTPS_CORE -d "Allow all ingress TCP traffic on port 8443."
#   ID_ALLOW_HTTPS_CORE=`bx sl securitygroup list | grep $ALLOW_HTTPS_CORE | cut -d ' ' -f 1`
#   bx sl securitygroup rule-add -r 0.0.0.0/0 -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE
# fi
#
# admin_core_private_ip=`printf '%s\n' "${INSTANCES[@]}" | grep "admin-core" | cut -d ' ' -f7`
#
# ALLOW_HTTPS_CORE_MICHELANGELO=allow_https_core_michelangelo
# ID_ALLOW_HTTPS_CORE_MICHELANGELO=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_MICHELANGELO$" | cut -d ' ' -f1`
# if [ -z "$ID_ALLOW_HTTPS_CORE_MICHELANGELO" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_HTTPS_CORE_MICHELANGELO..."
#   bx sl securitygroup create -n $ALLOW_HTTPS_CORE_MICHELANGELO -d "Allow all ingress TCP traffic on port 8443 from michelangelo, admin-core."
#   ID_ALLOW_HTTPS_CORE_MICHELANGELO=`bx sl securitygroup list | grep $ALLOW_HTTPS_CORE_MICHELANGELO | cut -d ' ' -f 1`
#   issuer_private_ip=`printf '%s\n' "${INSTANCES[@]}" | grep "michelangelo " | cut -d ' ' -f7`
#   bx sl securitygroup rule-add -r $issuer_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_MICHELANGELO
#   bx sl securitygroup rule-add -r $admin_core_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_MICHELANGELO
# fi
#
# ALLOW_HTTPS_CORE_RAFFAELLO=allow_https_core_raffaello
# ID_ALLOW_HTTPS_CORE_RAFFAELLO=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_RAFFAELLO$" | cut -d ' ' -f1`
# if [ -z "$ID_ALLOW_HTTPS_CORE_RAFFAELLO" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_HTTPS_CORE_RAFFAELLO..."
#   bx sl securitygroup create -n $ALLOW_HTTPS_CORE_RAFFAELLO -d "Allow all ingress TCP traffic on port 8443 from raffaello, admin-core."
#   ID_ALLOW_HTTPS_CORE_RAFFAELLO=`bx sl securitygroup list | grep $ALLOW_HTTPS_CORE_RAFFAELLO | cut -d ' ' -f 1`
#   issuer_private_ip=`printf '%s\n' "${INSTANCES[@]}" | grep "raffaello " | cut -d ' ' -f7`
#   bx sl securitygroup rule-add -r $issuer_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_RAFFAELLO
#   bx sl securitygroup rule-add -r $admin_core_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_RAFFAELLO
# fi
#
# ALLOW_HTTPS_CORE_DONATELLO=allow_https_core_donatello
# ID_ALLOW_HTTPS_CORE_DONATELLO=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_DONATELLO$" | cut -d ' ' -f1`
# if [ -z "$ID_ALLOW_HTTPS_CORE_DONATELLO" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_HTTPS_CORE_DONATELLO..."
#   bx sl securitygroup create -n $ALLOW_HTTPS_CORE_DONATELLO -d "Allow all ingress TCP traffic on port 8443 from donatello, admin-core."
#   ID_ALLOW_HTTPS_CORE_DONATELLO=`bx sl securitygroup list | grep $ALLOW_HTTPS_CORE_DONATELLO | cut -d ' ' -f 1`
#   issuer_private_ip=`printf '%s\n' "${INSTANCES[@]}" | grep "donatello " | cut -d ' ' -f7`
#   bx sl securitygroup rule-add -r $issuer_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_DONATELLO
#   bx sl securitygroup rule-add -r $admin_core_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_DONATELLO
# fi
#
# ALLOW_HTTPS_CORE_LEONARDO=allow_https_core_leonardo
# ID_ALLOW_HTTPS_CORE_LEONARDO=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_LEONARDO$" | cut -d ' ' -f1`
# if [ -z "$ID_ALLOW_HTTPS_CORE_LEONARDO" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_HTTPS_CORE_LEONARDO..."
#   bx sl securitygroup create -n $ALLOW_HTTPS_CORE_LEONARDO -d "Allow all ingress TCP traffic on port 8443 from leonardo, admin-core."
#   ID_ALLOW_HTTPS_CORE_LEONARDO=`bx sl securitygroup list | grep $ALLOW_HTTPS_CORE_LEONARDO | cut -d ' ' -f 1`
#   issuer_private_ip=`printf '%s\n' "${INSTANCES[@]}" | grep "leonardo " | cut -d ' ' -f7`
#   bx sl securitygroup rule-add -r $issuer_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_LEONARDO
#   bx sl securitygroup rule-add -r $admin_core_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_LEONARDO
# fi
#
# ALLOW_HTTPS_CORE_USER=allow_https_core_user
# ID_ALLOW_HTTPS_CORE_USER=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS_CORE_USER$" | cut -d ' ' -f1`
# if [ -z "$ID_ALLOW_HTTPS_CORE_USER" ]; then
#   # Creating security group
#   echo "Creating $ALLOW_HTTPS_CORE_USER..."
#   bx sl securitygroup create -n $ALLOW_HTTPS_CORE_USER -d "Allow all ingress TCP traffic on port 8443 from user and admin-core."
#   ID_ALLOW_HTTPS_CORE_USER=`bx sl securitygroup list | grep $ALLOW_HTTPS_CORE_USER | cut -d ' ' -f 1`
#   user_private_ip=`printf '%s\n' "${INSTANCES[@]}" | grep "user " | cut -d ' ' -f7`
#   bx sl securitygroup rule-add -r $user_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_USER
#   bx sl securitygroup rule-add -r $admin_core_private_ip -d ingress -e IPv4 -M 8443 -m 8443 -p tcp $ID_ALLOW_HTTPS_CORE_USER
# fi
#
#
# ALLOW_HTTPS=allow_https
# ID_ALLOW_HTTPS=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_HTTPS$" | cut -d ' ' -f1`
#
# ALLOW_SSH=allow_ssh
# ID_ALLOW_SSH=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_SSH$" | cut -d ' ' -f1`
#
# # Allow all egress traffic from private network
# ALLOW_OUTBOUND=allow_outbound
# ID_ALLOW_OUTBOUND=`printf '%s\n' "${SECURITY_GROUPS[@]}" | grep "$ALLOW_OUTBOUND$" | cut -d ' ' -f1`
#
# sleep 1
# wait

echo '#############'
echo '####DONE#####'
echo '#############'