#!/bin/bash

echo
read -p "Enter SMTP password: " PASSWORD
echo


echo "[smtp.sendgrid.net]:587 apikey:${PASSWORD}" > /etc/postfix/sasl_passwd
postmap /etc/postfix/sasl_passwd
chown root:root /etc/postfix/sasl_passwd /etc/postfix/sasl_passwd.db
chmod 0600 /etc/postfix/sasl_passwd /etc/postfix/sasl_passwd.db
rm /etc/postfix/sasl_passwd