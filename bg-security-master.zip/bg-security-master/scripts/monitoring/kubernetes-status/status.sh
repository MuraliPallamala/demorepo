#!/bin/bash

CONTINUE=0
WORKING_DIR=$(dirname $0)
TO_EMAILS=$(cat ${WORKING_DIR}/to.list | tr '\n' ' ')
DEPLOYMENTS=$(cat ${WORKING_DIR}/deployment.list | tr '\n' ' ')


DISK_THRESHOLD=$(head -n 1 ${WORKING_DIR}/disk.threshold)
# Check disk space
df -PkH | grep -vE '^Filesystem|tmpfs|cdrom|media|/var/lib/docker' | awk '{ print $5 " " $6 }' | while read output;
do

percentage=$(echo $output | awk '{ print $1}' | cut -d'%' -f1)
partition_name=$(echo $output | awk '{print $2}')
if [ ${percentage} -ge ${DISK_THRESHOLD} ]; then
  echo "Running out of space \"${partition_name} (${percentage}%)\"" >> ${WORKING_DIR}/down_list
fi

done


# Check status of kubernetes
#kubectl get services > /dev/null
kubectl get services
if [ ! $? -eq 0 ]; then
  echo "kubectl not running properly." >> ${WORKING_DIR}/down_list
  CONTINUE=1
fi



if [ ! ${CONTINUE} -eq 1 ]; then
  # Check status of deployments
  for DEPLOYMENT in ${DEPLOYMENTS[@]}; do
  #  kubectl rollout status deployment.v1.apps/${DEPLOYMENT} > /dev/null
    kubectl rollout status deployment.v1.apps/${DEPLOYMENT}
    if [ ! $? -eq 0 ]; then
      echo "Deployment: ${DEPLOYMENT} is not rolled out" >> ${WORKING_DIR}/down_list
      echo
    fi
  done
fi

SUBJECT="[ALERT] Possible issues on ${HOSTNAME}!"

if [ -e ${WORKING_DIR}/down_list ]; then
  echo "Sending email..."
  echo "$(cat ${WORKING_DIR}/down_list)" | mail -s "${SUBJECT}" ${TO_EMAILS}
  rm -f ${WORKING_DIR}/down_list
else
  exit 0
fi

exit 0