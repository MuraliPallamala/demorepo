#!/bin/bash

WORKING_DIR=$(dirname $0)
TO_EMAILS=$(cat ${WORKING_DIR}/to.list | tr '\n' ' ')

# Check status of the hosts. Are they pingable?
HOSTS=$(cat ${WORKING_DIR}/hosts.list)
for HOST in ${HOSTS}; do
  #ping -q -c 3 ${HOST} > /dev/null
  ping -q -c 3 ${HOST}
  if [ ! $? -eq 0 ]; then
    echo "Host: ${HOST} is not responding" >> ${WORKING_DIR}/down_list
  fi
done

SUBJECT="[ALERT] Hosts not responding!"

if [ -e ${WORKING_DIR}/down_list ]; then
  echo "Sending email..."
  echo "$(cat ${WORKING_DIR}/down_list)" | mail -s "${SUBJECT}" ${TO_EMAILS}
  rm -f ${WORKING_DIR}/down_list
else
  exit 0
fi

exit 0