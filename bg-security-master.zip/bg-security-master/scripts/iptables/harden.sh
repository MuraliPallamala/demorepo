#!/bin/bash

# This script hardens the sandbox  machines (Reverse Proxy for NginX) to
# secure the network traffic to what is strictly needed for the solution
# to work and be administered.


# Reference to the name of the script, used in messages and help functions.
#
S_SCRIPT_NAME=$(basename $0)

# Path to the default preset file that will be looked for when the script
# tries to customize the template rules.
#
# This file should contain the definition of the parameters that are sensitive
# to the specific machine that is being hardened and global properties that we
# do not want to hard-code in the script such as (for Type 3.1 machines):
#
# [HARDEN SCRIPT CONTROL]
#
# ${HSC_NO_BACKUP}    - If declared (and set to TRUE) prevents the script from
#                       backing up the previous set of rule.
# ${HSC_NO_FLUSH}     - If declared (and set to TRUE) prevents the script from
#                       flushing the existing ser of rules before adding the new
#                       rules.
#
# [ALL MACHINES]
#
# ${JUMPBOX_ADMIN_IP} - IP of the jumpbox machine in the administrative network.
# ${IFC_ADMIN_NET}    - Interfance name of the virtual ethernet card that is used
#                       to emulate the administrative network.
# ${INTERNAL_NET}     - IP range representing the internal network (including the
#                       VPN used to connect into the sandbox environment).
#
# [TYPE 3.1]
#
# ${PORTAL_P2P_IP}    - IP of the portal in the point-to-point network connecting
#                       the reverse proxy to the application server hosting the
#                       portal
# ${IFC_PORTAL_NET}   - Interface name of the virtual ethernet card that is used
#                       emulate the point to point network connecting the reverse
#                       proxy to the application server hosting the portal.
#
# [TYPE 3.2] - TODO
# 
# [TYPE 2] - TODO
#
# [TYPE 1.x] - TODO
#
S_DEFAULT_PRESET_PATH=.harden.env

# Path to the default rules file that will be used to setup the firewall rules for
# the machine. This file may reference the environment variables that are defined
# in the preset file.
#
S_DEFAULT_RULE_PATH=.harden.rules


# These are exit codes used by the script.
#
S_EXIT_OK=0
S_EXIT_NO_ROOT=1
S_EXIT_NO_PREREQUISITES=2
S_EXIT_NO_PRESET_FILE=3
S_EXIT_NO_RULES_FILE=4


# This function implements a basic logging capability to make the output
# of the script more consistent. In this way we limit errors and typos.
# The script accepts two parameters:
# 
# $1: log level (INFO,WARN,ERROR,...)
# $2: the message to log
#
#
function log() {

   echo "[$1] - $2";
}


# This function explains the usage of the of the script.
#
#
function usage() {

   log "INFO" "usage: ${S_SCRIPT_NAME} [test] [<preset-file-path>] [<rules-file>]"
   log "INFO" 
   log "INFO" "where:"
   log "INFO" 
   log "INFO" 
   log "INFO" "  test            if specified, it only runs the preparation of the rules"
   log "INFO" "                  and dumps the specialized rules into a file,  which  is"
   log "INFO" "                  named as <rules-file>.actual. This  modality  does  not"
   log "INFO" "                  require the user to be root, and the existence  of  the"
   log "INFO" "                  iptables, iptables-save, and iptables-restore commands." 
   log "INFO"   
   log "INFO" "  <preset-file>   path to the environment preset file. This file contains"
   log "INFO" "                  the definition of  variables that  will  customize  the"
   log "INFO" "                  IPTables firewall rules used to configure  the  machine"
   log "INFO" "                  being secured. The default value is:"
   log "INFO" 
   log "INFO" "                  .harden.env"
   log "INFO" 
   log "INFO" "  <rules-file>    path to the file containing the templatized rules  that"
   log "INFO" "                  will be used in conjuction with the preset-file to  set"
   log "INFO" "                  the firewall rules for the machine being secured.  This"
   log "INFO" "                  file may reference the variabless defined in the preset"
   log "INFO" "                  fie. The default value is:"
   log "INFO"
   log "INFP" "                  .harden.rules"   
   log "INFO" 
   log "INFO" " Additional notes:"
   log "INFO"
   log "INFO" " The environment preset file declares not only environment variables that"
   log "INFO" " affect the customization of the IPTabls rules, but also other  variables"
   log "INFO" " that are used to alter the behaviour of the script:"
   log "INFO"
   log "INFO" " - HSC_NO_BACKUP  this variable if defined prevents the script from doing" 
   log "INFO" "                  a backup of the existing firewall rules before changing"
   log "INFO" "                  them.By default the current set of rules is saved to:"
   log "INFO" 
   log "INFO" "                  iptables.YYYY-mm-dd_HH-MM-SS.backup"
   log "INFO" 
   log "INFO" "                  if such a file already exist the script will wait for 2" 
   log "INFO" "                  seconds before trying  to  save  the  rules  again.  To"
   log "INFO" "                  prevent the script from saving the rules the caller can"
   log "INFO" "                  specify this additional flag."
   log "INFO" 
   log "INFO" " - HSC_NO_FLUSH   this variable  if  defined  prevents  the  script  from"
   log "INFO" "                  flushing the rules that are currently configured in the"
   log "INFO" "                  firewall. By default the script will clean firewall."   
 
}

# This function dumps the content of a file that is passed as argument. The content
# is dumped to the shell console by using the cat command.
#
function dump_content() {

   echo ""
   echo "--------------------------------------------------------------------"
   cat --number $1
   echo "--------------------------------------------------------------------"
   echo ""
}


# This function implements a basic logging capability to make the output
# of the script more consistent. In this way we limit errors and typos.
# The script accepts two parameters:
# 
# $1: log level (INFO,WARN,ERROR,...)
# $2: the message to log
#
#
function log() {

   echo "[$1] - $2";	
}


# Configuring script parameters to their default or specified values.
#
S_TEST=false

if [ "$1" == "test" ]; then

    log "WARN" "Running in test mode: $1"
    S_TEST=true
    shift 1
fi

S_PRESET_PATH=${1:-${S_DEFAULT_PRESET_PATH}}

S_RULES_PATH=${2:-${S_DEFAULT_RULE_PATH}}
S_ACTUAL_RULES_PATH="${S_RULES_PATH}.actual"

# This function prints the current configuration of the script. The
# function has debugging purposes.
#
function initialize() {

    log "INFO" "Initializing the script."
    log "INFO" "  - preset file        :     $S_PRESET_PATH"
    log "INFO" "  - rule file          :     $S_RULES_PATH"
    log "INFO" "  - actual rule file   :     $S_ACTUAL_RULES_PATH"
    echo ""
}


# This function checks whether the current user is root. In order to perform 
# the proper hardening we need to be able to access the information that is 
# stored in IPTables. For that we need be root.
#
function check_root() {
	
    S_CURRENT_USER=$(whoami)

    if [ "${S_CURRENT_USER}" != "root" ]; then 

        if [[ "${S_TEST}" == true ]]; then
	    log "WARN" "This script (${S_SCRIPT_NAME} require the user to be root, but we are running in test mode and the constraint is not enforced."
	    echo ""
        else

            log "WARN" "This script (${S_SCRIPT_NAME}) requires the user to be root. Exiting gracefully."
	    echo ""

            exit $S_EXIT_NO_ROOT
	fi
    fi
}

# This function checks whether all the required commands and utilities are 
# installed in the target machine. These checks are performed before running
# the script logic to ensure that we do not progress half-way through with
# the process.
#
function check_prerequisites() {

    local LS_FILE_PATH="."
    local LS_FILE_FOUND=TRUE

    local LS_DEPENDENCIES="cat sed date which"

    if [[ "${S_TEST}" != true ]]; then
	LS_DEPENDENCIES="${LS_DEPENDENCIES} iptables iptables-save iptables-restore"
    fi

    log "INFO" "Checking script pre-requisites"
    for FILE in ${LS_DEPENDENCIES};  do   
        LS_FILE_PATH=$(which $FILE)
        if [ "$?" -ne 0 ]; then

            log "WARN" "  - [no] ${FILE}"
            LS_FILE_FOUND=FALSE;
        else
	    log "INFO" "  - [ok] ${FILE}:${LS_FILE_PATH}"
        fi
    done

    if [ ! ${LS_FILE_FOUND} ]; then
	
	log "ERROR" "Some prerequisite is missing."
	exit $S_EXIT_NO_PREREQUISITES
    fi	    
}

# This function checks the existence of the configured environment preset file.
# If the file does not exist it terminates the script with exit code:
#
# S_EXIT_NO_PRESET_FILE
#
# If found, it sources the file into the shell environment to make available the
# environment variables for substitution. In this case the content of the file is
# also dumped to the screen.
#
function check_and_load_preset() {

    log "INFO" "Looking for environment preset file.."

    if [ ! -f ${S_PRESET_PATH} ]; then

        log "ERROR" "Environment preset file (${S_PRESET_PATH}) not found. Cannot continue."
        exit $S_EXIT_NO_PRESET_FILE
    else

	log "INFO" "  - Found preset file: ${S_PRESET_PATH}." 
	log "INFO" "  - Sourcing it into the environment..."
        source ${S_PRESET_PATH}

	dump_content ${S_PRESET_PATH}
    fi

    echo ""
}

# This function checks the existence of the configured rules file. If the file does
# not exist it terminates the script with the exit code:
#
# S_EXIT_NO_RULES_FILE
#
# If found it generates a specialized version of the file by substituting occurrences
# of the environment variables that are loaded in the environment. The specialized
# version of the file is pointed by S_ACTUAL_RULE_PATH.
#
function check_and_load_rules() {

    log "INFO" "Looking for rule template file..."

    if [ ! -f ${S_RULES_PATH} ]; then

        log "ERROR" "Rule template  file (${S_RULES_PATH}) not found. Cannot continue."
        exit $S_EXIT_NO_RULES_FILE

    else

        log "INFO" "  - Found rule template file: ${S_RULES_PATH}"
	
	dump_content ${S_RULES_PATH}


	log "INFO" "  - Specializing the template file to ${S_ACTUAL_RULES_PATH}.."
        LS_COUNTER=1

	rm -f ${S_ACTUAL_RULES_PATH}
	while IFS='' read -r LINE || [[ -n "$LINE" ]]; do
            
            # To make this work we need to be able to replace the occurence
	    # of environment variables in $LINE. If we try to simply do:
	    #
	    # echo ${LINE} >> ${S_ACTUAL_RULES_PATH}
	    #
	    # the content of line will be copied as it is, without triggering
	    # parameter expanaion. This happens because parameter expansions
	    # only work with string literals. Since we have a variable that
	    # contains a string, there is an additional level of indirection
	    # that prevent the natural parameter expansion mechanism to work.
	    #
	    # In order to trigger parameter expansion, what we need to do is
	    # forcing the evaluation of the string, which can be done by using
	    # the combintion of 'eval' and 'echo' commands:
	    #
	    # LS_LINE=$(eval echo ${LINE})
	    #
	    # This is how it works:
	    #
	    # - echo ${LINE} simply writes the content of the variable to the
	    #                output. This enables us to unwrap one level of
	    #                indirection.
	    #
	    # - eval ....    evaluates the argument and trigger parameters
	    #                expansion if there are parameter references. The
	    #                argument passed to the eval is the string that is
	    #                referenced by $LINE. There is no more indirection
	    #                here, from the perspective of eval, this is a
	    #                string literal and therefore parameter expansion
	    #                will be triggered if there are occurrences.
	    #
	    # - LS_LINE=$(eval ...)   we save the output of the eval command
	    #                         in a variable so that we can reuse it
	    #                         later. At this point all the variables
	    #                         that were referenced are expanded to 
	    #                         their corresponding values.
	    #
	    # A sub-sequent call to:
	    #
	    # echo "${LS_LINE}" >> ${S_ACTUAL_RULES_PATH}
	    #
	    # will dump the content of ${LS_LINE} to the file, thus achieving 
	    # what we needed to do, which is replacing the occurrences of 
	    # environment variables in the source file before copying it to
	    # the target file..

	    # NOTE: eval will also interpret strings and unwrap them from
	    #       their double quotes enclosures. We need to AVOID this as
	    #       the comments in a IPTables rules file need to be preserved
	    #       so that when pass them to the IPTables command they are
	    #       interpreted as a single string and not exploded into
	    #       pieces.
	    #
	    #       We can use the built-in parameter substitution capabilities
            #       of bash:
	    #      
	    #       - ${variable/pattern/replacement} for first occurrence
	    #       - ${variable//pattern/replacement} for all occurrences
	    #
	    #       We then want to replace " with \". Both " and \ have a
	    #       special meaning in bash. Therefore, they need to be escaped
	    #       when we reference them in the pattern and replacement parts
	    #       of the parameter substitution, which then become:
	    #
	    #       - " becomes \"
	    #       - \" becomes \\\"
	    # 
	    LINE=${LINE//\"/\\\"}
            LINE=${LINE//\'/\\\'}
            # NOTE: we also need to escape: ! and ( ) as eval will try to 
            #       interpret given their special meaning. As above we need
            #       to double up with the backslashes:
            #      
            #
            #       - ! becomes \!, and \! becomes \\\!
            #       - ( becomes \(, and \( becomes \\\(
            #       - ) becomes \), and \) becomes \\\)
	    #
            #
            LINE=${LINE//\!/\\\!}
            LINE=${LINE//\(/\\\(}
            LINE=${LINE//\)/\\\)}
            
            echo "[Line: $(printf '%4s' ${LS_COUNTER})] - ${LINE}"
            
	    if [[ "${LINE}" == \#* ]]; then

                # Because of the way eval works, also comments are evaluated
		# and the nature of the comment is to be transparent to the
		# evaluation process (they are comments!). 
		#
		# What we would like to do here is copy the comments into the
		# target file and replacing occurrences of environment variables
		# if there are any references. 
		#
		# In order to do so, we need to make eval believe that the line
		# is not a comment, but a normal string. Hence, we need to:
		#
		# - strip the comment character
		# - forcing parameter expansion on the remaining string
	        # - put the comment character back at the beginning of the string.	
                #
                # If there is a comment we copy it as it is. If we do not
		# differentiate comments from the rest of the handling, we
		# end up swallowing all the comments into the source file
		# and not copying them into the target file.
		
		LS_LINE="# $(eval echo ${LINE:1})"
	    else

		# This is the normal behaviour, where we take the entire line
	        # as it is intended to be either a blank line or a string to
	        # be interpreted.	
		#
                LS_LINE=$(eval echo ${LINE})
            fi
	    echo "${LS_LINE}" >> ${S_ACTUAL_RULES_PATH}
 
            LS_COUNTER=$((LS_COUNTER+1))

	done < ${S_RULES_PATH}
    
        log "INFO" "  - Generated specialized file:"

	dump_content ${S_ACTUAL_RULES_PATH}

	echo ""
    fi
}

# This function checks whether the caller has specified whether to save the
# existing IPTables firewall rules or not. In case the default behaviour is
# selected, this function will generate a backup file that will store the
# output of the iptables-save command.
#
function check_and_save_rules() {

    log "INFO" "Checking for IPTables rules backup..."
    if [[ "${S_TEST}" == true ]]; then
	log "WARN" "  - Running in test mode (SKIPPING)."
    else
        if [[ "${HSC_NO_BACKUP}" == true ]]; then
            
            log "INFO" "  - HSC_NO_BACKUP is set to true, backup is disabled."
            log "WARN" "  - backup has been disabled, skipping rule backup."
        else

            log "INFO" "  - HCS_NO_BACKUP is not defined or set to FALSE, backup is enabled."

	    local LS_NOW=$(date '+%Y-%m-%d_%H-%M-%S')
	    local LS_BACKUP_FILE="iptables.${LS_NOW}.backup"

	    # we loop until we don't find a file name that
	    # does not match an existing file. This is done
	    # by letting the script go to sleep for 2 seconds
	    # and re-generating the time dependent name again.
	    #
            while [ -f  ${LS_BACKUP_FILE} ]; do
         
	        sleep 2s
                LS_NOW=$(date '+%Y-%m-%d %H:%M:%S')
                LS_BACKUP_FILE="iptables.${LS_NOW}.backup"
        
            done  

	    log "INFO" "  - executing backup to ${LS_BACKUP_FILE}.."
	    log "INFO" "  - iptables-save > ${LS_BACKUP_FILE}"

            iptables-save > ${LS_BACKUP_FILE}

	    log "INFO" "  - current ruleset saved:"

	    dump_content ${LS_BACKUP_FILE}

        fi 
    fi

    echo ""
}

# This function applies the rules that have been specialized. The function
# locates and reads the file pointed by S_ACTUAL_RULES_PATH and uses the
# iptables-restore command to load the rules. 
#
function apply_rules() {

    log "INFO" "Applying new firewall rules"
    if [[ "${S_TEST}" == true ]]; then
	log "WARN" "  - Running in test mode (SKIPPING)."
    else
        if [[ "${HSC_NO_FLUSH}" == true ]]; then
	
           log "INFO" "  - HSC_NO_FLUSH is true, mode is APPEND."
	   log "INFO" "  - Adding the new firewall rules.."
	   log "INFO" "  - iptables-restore --noflush < ${S_ACTUAL_RULES_PATH}"

	   echo ""
	   iptables-restore --noflush < ${S_ACTUAL_RULES_PATH}
	   echo ""

       else
           log "INFO" "  - HSC_NO_FLUSH is not defined or false, mode is REPLACE."
           log "INFO" "  - Removing the existing firewall rules.."
	   log "INFO" "  - iptables-restore < ${S_ACTUAL_RULES_PATH}"

	   echo ""
	   iptables-restore < ${S_ACTUAL_RULES_PATH}
	   echo ""
        fi    
    
        log "INFO" "  - Current rules are:"

        echo ""
        iptables-save
    fi
    echo ""
}



initialize
check_root
check_prerequisites
check_and_load_preset
check_and_load_rules
check_and_save_rules
apply_rules

exit $S_EXIT_OK



