#!/usr/bin/env bash

#
# Configure aggregated logging using IBM Cloud Log Analysis service
# Followed instruction from:
# https://console.bluemix.net/docs/services/CloudLogAnalysis/vm/logging_vm_ov.html#logging_vm_ov
# https://console.bluemix.net/docs/services/CloudLogAnalysis/how-to/send-data/send_data_mt.html#send_data_mt
# Pre-requisites:
# - IBM Cloud Log Analysis service should already exist

# Exit when a command fails
#set -e


# Installing Log Analysis service
echo ''
echo '# Installing Log Analysis service'
echo ''
wget -O - https://downloads.opvis.bluemix.net/client/IBM_Logmet_repo_install.sh | bash
 
DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" install mt-logstash-forwarder

service mt-logstash-forwarder restart
