#TODO This was performed manually using the IBM Cloud Customer Portal.
#TODO Provisioning via CLI does not allow setting boot mode to HVM which might be a problem.

# jumpbox.dlt.res.ibm.com

# bigfix.dlt.res.ibm.com

# logging.dlt.res.ibm.com
# current_hostname=$VS_HOSTNAME_LOGGING
# type_core=$TYPE4_CORE
# type_memory=$TYPE4_MEMORY
# type_disk1=$TYPE4_DISK1
# type_disk2=$TYPE4_DISK2

# echo "# bx sl vs create --dedicated --host-id $DEDICATED_HOST_ID --hostname $current_hostname --domain $VS_DOMAIN --cpu $type_core --memory $type_memory --datacenter $DATACENTER --os $OPERATING_SYSTEM $type_disk1 $type_disk2 --network $NETWORK_SPEED -s $ALLOW_OUTBOUND_ID -s $ALLOW_SSH_ID -s $ALLOW_ICMP_ID --key $SSH_KEY_ID"
#
# bx sl vs create --dedicated --host-id $DEDICATED_HOST_ID --hostname $current_hostname --domain $VS_DOMAIN --cpu $type_core --memory $type_memory --datacenter $DATACENTER --os $OPERATING_SYSTEM $type_disk1 $type_disk2 --network $NETWORK_SPEED -s $ALLOW_OUTBOUND_ID -s $ALLOW_SSH_ID -s $ALLOW_ICMP_ID --key $SSH_KEY_ID
#
# vsid=$(bx sl vs list | grep " $current_hostname " | tr -s ' ' | cut -d ' ' -f1)
# ready=$(bx sl vs ready $vsid)
# while [[ $ready = *"Not ready:"* ]]; do
#   sleep 60
#   ready=$(bx sl vs ready $vsid)
#   echo $ready
# done

# services.dlt.res.ibm.com
# Avoid changing the ip of this VM because it needs to be in sync with the IBM external DNS.

# services-core.dlt.res.ibm.com

# admin.dlt.res.ibm.com
# Avoid changing the ip of this VM because it needs to be in sync with the IBM external DNS.

# admin-core.dlt.res.ibm.com

# user.dlt.res.ibm.com
# Avoid changing the ip of this VM because it needs to be in sync with the IBM external DNS.

# user-core.dlt.res.ibm.com

# raffaello.dlt.res.ibm.com
# Avoid changing the ip of this VM because it needs to be in sync with the IBM external DNS.

# raffaello-core.dlt.res.ibm.com

# michelangelo.dlt.res.ibm.com
# Avoid changing the ip of this VM because it needs to be in sync with the IBM external DNS.

# michelangelo-core.dlt.res.ibm.com

# leonardo.dlt.res.ibm.com
# Avoid changing the ip of this VM because it needs to be in sync with the IBM external DNS.

# leonardo-core.dlt.res.ibm.com

# donatello.dlt.res.ibm.com
# Avoid changing the ip of this VM because it needs to be in sync with the IBM external DNS.

# donatello-core.dlt.res.ibm.com