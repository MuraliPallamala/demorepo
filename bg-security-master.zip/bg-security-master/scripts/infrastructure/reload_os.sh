#!/usr/bin/env bash

#
# Reloads all the OS for all instances
#

# Exit when a command fails
set -e


USAGE="\nUsage: $0 --host-ip <host_ip>"
  
if [ "$#" -lt 1 ]; then
  echo -e "$USAGE" >&2
  exit 1
fi

#
# Parsing input
#
DOMAIN=dlt.res.ibm.com

POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    --host-ip)
    HOST_IP="$2"
    shift # past argument
    shift
    ;;
    *)    # unknown option
     echo -e "$USAGE" >&2
    exit 1
#    POSITIONAL+=("$1") # save it in an array for later
#    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters
 

# Getting ssh key
SSH_KEY=$(bx sl security sshkey-list | grep prjlygon | tr -s ' ' | cut -d ' ' -f1)

INSTANCE_ID=$(bx sl vs list | grep $HOST_IP | tr -s ' ' | cut -d ' ' -f1)
bx sl vs reload "$INSTANCE_ID" -k $SSH_KEY -f
sed -i '' "/$HOST_IP/d" $HOME/.ssh/known_hosts

# Getting list of instances
# IFS=$'\n'
# INSTANCES=( $(bx sl vs list | sed -n '1!p' | tr -s ' ' | cut -d ' ' -f1) )
# unset IFS
#
# # Reloading instances
# for instance in "${INSTANCES[@]}"; do
#   bx sl vs reload "$instance" -k $SSH_KEY -f
# done

sleep 120

printf "%s" "waiting for $HOST_IP ..."
while ! ping -c 1 -W 1 $HOST_IP &> /dev/null
do
    printf "%c" "."
done
printf "\n%s\n"  "Server is back online"
sleep 10
