


IFS=$'\n'
INSTANCES=( $(bx sl vs list | sed -n '1!p' | grep dlt.res.ibm.com | tr -s ' ' | cut -d ' ' -f2-3,7) )
unset IFS
#printf '%s\n' "${INSTANCES[@]}" | grep "leonardo dlt" | cut -d ' ' -f1
for instance in "${INSTANCES[@]}"; do
  host=$(echo $instance | cut -d ' ' -f1)
  domain=$(echo $instance | cut -d ' ' -f2)
  ip=$(echo $instance | cut -d ' ' -f3)
  sudo sed -i '' "/$host\.$domain/d" /etc/hosts
  sudo sed -i '' "/$host\.$domain/d" $HOME/.ssh/known_hosts
  echo -e "$ip\t$host.$domain" | sudo tee -a /etc/hosts
done
echo "" | sudo tee -a /etc/hosts
