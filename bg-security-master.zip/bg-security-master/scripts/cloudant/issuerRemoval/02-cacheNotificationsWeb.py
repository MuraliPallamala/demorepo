from cloudant.client import Cloudant
from cloudant.error import CloudantException
from cloudant.result import Result, ResultByKey
import os
import subprocess

#import sys
#print (sys.argv)
import getpass

issuerNameToBeRemoved = raw_input('Issuer Name to be Removed: ')
databasePrefix = raw_input("Cloudant Database Prefix: ")
selectedChannelName = raw_input("Name of the channel that contains the issuer guarantees: ")
serviceUsername = raw_input("Cloudant Username: ")
servicePassword = getpass.getpass("Cloudant Password: ")
serviceURL = raw_input("Cloudant URL: ")

client = Cloudant(serviceUsername, servicePassword, url=serviceURL)
client.connect()

databaseName = databasePrefix + '-notifications-web'
client.create_database(databaseName)
myDatabase=client[databaseName]

gxIds = set(line.strip() for line in open(databasePrefix+'-requests'+'-gxIds.txt'))

docIdSetToBeDeleted = set()

view = myDatabase.get_design_document("CouchDbWebNotification").get_view("all")

resultCollection = Result(view, include_docs=True)
for result in resultCollection:
  doc = myDatabase[result['id']]

  try:
    gxId = doc['content']['payload']['gxId']
    if gxId in gxIds:
      docIdSetToBeDeleted.add(doc['content']['id'])
  except:
    a = 0

  try:
    issuerEntityName = doc['content']['payload']['issuerEntityName']
    if issuerNameToBeRemoved in issuerEntityName:
      docIdSetToBeDeleted.add(doc['content']['id'])
  except:
    a = 0

print 'Number of NotificationsWeb to be deleted: ', len(docIdSetToBeDeleted)

with open(databaseName+'-NotificationsWebToBeDeleted.txt', 'w') as f:
  for item in docIdSetToBeDeleted:
    f.write("%s\n" % item)

