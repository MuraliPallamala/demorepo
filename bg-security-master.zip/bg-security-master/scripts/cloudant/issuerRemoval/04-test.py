from cloudant.client import Cloudant
from cloudant.error import CloudantException
from cloudant.result import Result, ResultByKey
import os
import subprocess

#import sys
#print (sys.argv)
import getpass

databaseName = raw_input("Cloudant Database Name: ")
#fileWithDocIds = raw_input("Enter the path of the file containing the document ids to be deleted: ")
serviceUsername = raw_input("Cloudant Username: ")
servicePassword = getpass.getpass("Cloudant Password: ")
serviceURL = raw_input("Cloudant URL: ")

client = Cloudant(serviceUsername, servicePassword, url=serviceURL)
client.connect()

client.create_database(databaseName)
myDatabase=client[databaseName]

#print 'db.get_revision_limit(): ', myDatabase.get_revision_limit()
myDatabase.set_revision_limit(1)

#l =  ['3-b5d8f71ac30a710fb65e59ffb4f6b445']
#docId = '7fdcad7a6e30d143c32a6f2cf330755c'
#print myDatabase.revisions_diff(docId, l)

#documentIds = set(line.strip() for line in open(fileWithDocIds))




