from cloudant.client import Cloudant
from cloudant.error import CloudantException
from cloudant.result import Result, ResultByKey
import os
import subprocess

#import sys
#print (sys.argv)
import getpass

databasePrefix = raw_input("Cloudant Database Prefix: ")
selectedChannelName = raw_input("Name of the channel that contains the issuer guarantees: ")
serviceUsername = raw_input("Cloudant Username: ")
servicePassword = getpass.getpass("Cloudant Password: ")
serviceURL = raw_input("Cloudant URL: ")

client = Cloudant(serviceUsername, servicePassword, url=serviceURL)
client.connect()

databaseName = databasePrefix + '-audit-events'
client.create_database(databaseName)
myDatabase=client[databaseName]

gxIds = set(line.strip() for line in open(databasePrefix+'-requests'+'-gxIds.txt'))

docIdSetToBeDeleted = set()

view = myDatabase.get_design_document("CouchDbAuditEvent").get_view("all")

gxRemainingCount = 0
gxUnrelatedCount = 0

resultCollection = Result(view, include_docs=True)
for result in resultCollection:
  doc = myDatabase[result['id']]

  try:
    gxId = doc['content']['data']['gx']['id']
    if gxId in gxIds:
      docIdSetToBeDeleted.add(doc['content']['id'])
    else:
      gxUnrelatedCount += 1
  except:
    print doc, '\n'
    gxRemainingCount += 1
  

print 'Number of AuditEvents to be deleted: ', len(docIdSetToBeDeleted)
print 'Number of AuditEvents related to unrelated gxs: ', gxUnrelatedCount
print 'Number of documents without reference to any gx id: ', gxRemainingCount

with open(databaseName+'-AuditEventsToBeDeleted.txt', 'w') as f:
  for item in docIdSetToBeDeleted:
    f.write("%s\n" % item)

