from cloudant.client import Cloudant
from cloudant.error import CloudantException
from cloudant.result import Result, ResultByKey
import os
import subprocess

#import sys
#print (sys.argv)
import getpass

databaseName = raw_input("Cloudant Database Name: ")
fileWithDocIds = raw_input("Enter the path of the file containing the document ids to be deleted: ")
serviceUsername = raw_input("Cloudant Username: ")
servicePassword = getpass.getpass("Cloudant Password: ")
serviceURL = raw_input("Cloudant URL: ")

client = Cloudant(serviceUsername, servicePassword, url=serviceURL)
client.connect()

client.create_database(databaseName)
myDatabase=client[databaseName]

documentIds = set(line.strip() for line in open(fileWithDocIds))

print 'Removing ', len(documentIds), ' documents from ', databaseName, ' using ', fileWithDocIds, '\n'

for docId in documentIds:
  #print myDatabase[docId]
  myDatabase[docId].delete()

#deleted = 0
#for docId in documentIds:
#  try:
#    print myDatabase[docId]
#  except:
#    deleted += 1
#print deleted, ' documents were deleted\n'

