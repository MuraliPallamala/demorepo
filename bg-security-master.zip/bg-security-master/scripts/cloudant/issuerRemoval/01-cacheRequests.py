from cloudant.client import Cloudant
from cloudant.error import CloudantException
from cloudant.result import Result, ResultByKey
import os
import subprocess

#import sys
#print (sys.argv)
import getpass

databasePrefix = raw_input("Cloudant Database Prefix: ")
selectedChannelName = raw_input("Name of the channel that contains the issuer guarantees: ")
serviceUsername = raw_input("Cloudant Username: ")
servicePassword = getpass.getpass("Cloudant Password: ")
serviceURL = raw_input("Cloudant URL: ")

client = Cloudant(serviceUsername, servicePassword, url=serviceURL)
client.connect()


def handleGxRequests():
  databaseName = databasePrefix + '-requests'
  client.create_database(databaseName)
  myDatabase=client[databaseName]

  resultCollection = Result(myDatabase.all_docs, include_docs=True)

  docCount = 0

  docWithCdbGxRequestCount = 0
  docWithCdbPrefillRequestCount = 0
  docWithCdbApprovalModelFlowRequestCount = 0
  docRemainingCount = 0

  gxRequestIdSet = set()
  gxIdSet = set()

  # Stores the quantity of GxRequests per channel
  requestsByChannelMap = {}

  for result in resultCollection:
    doc = myDatabase[result['id']]

    docCount += 1
  
    #print doc
  
    if 'cdbGxRequest' in doc: 
      docWithCdbGxRequestCount += 1

      try:
        channelName = doc['content']['channelName']
      except: 
        print '##### GxRequest without channelName: '
        print doc, '\n'
    
      # Increment requestsByChannelMap count
      if channelName in requestsByChannelMap:
        requestsByChannelMap[channelName] += 1  
      else:
        requestsByChannelMap[channelName] = 0

      # Process requests related to the selected channel name
      if selectedChannelName in channelName:
        #extractGxRequestIds(doc)
        gxRequestIdSet.add(doc['content']['id'])

        #extractGuaranteeIds(doc)
        try:
          guaranteeId = doc['content']['guaranteeId']
          if len(guaranteeId) > 0: 
            gxIdSet.add(guaranteeId) 
        except:
          print '##### GxRequest from ', selectedChannelName, ' without guaranteeId: ', doc['content']['id']
          print doc, '\n'

    elif 'cdbPrefillRequest' in doc:
      docWithCdbPrefillRequestCount += 1
    elif 'cdbApprovalModelFlowRequest' in doc:
      docWithCdbApprovalModelFlowRequestCount += 1
    else:
      docRemainingCount += 1

  print 'docCount: ', docCount
  print 'docWithCdbGxRequestCount: ', docWithCdbGxRequestCount
  print 'docWithCdbPrefillRequestCount: ', docWithCdbPrefillRequestCount
  print 'docWithCdbApprovalModelFlowRequestCount: ', docWithCdbApprovalModelFlowRequestCount
  print 'docRemainingCount: ', docRemainingCount 

  print 'requestsByChannel: ', requestsByChannelMap

  print 'Number of GxRequests in ', selectedChannelName, ': ', len(gxRequestIdSet)
  print 'Number of GxIds in ', selectedChannelName, ': ', len(gxIdSet)

  #print 'Gx Request Ids (doc.id) to be deleted: ', gxRequestIdSet, '\n'
  #print 'Gx Ids (guaranteeId) to be deleted: ', gxIdSet, '\n'

  with open(databaseName+'-gxRequestIdsToBeDeleted.txt', 'w') as f:
    for item in gxRequestIdSet:
      f.write("%s\n" % item)

  with open(databaseName+'-gxIds.txt', 'w') as f:
    for item in gxIdSet:
      f.write("%s\n" % item)




def handlePrefillRequests():
  databaseName = databasePrefix + '-requests'
  client.create_database(databaseName)
  myDatabase=client[databaseName]

  gxRequestIds = set(line.strip() for line in open(databaseName+'-gxRequestIds.txt'))

  docIdSetToBeDeleted = set()

  view = myDatabase.get_design_document("CouchDbGxPrefillRequest").get_view("all")
  resultCollection = Result(view, include_docs=True)
  for result in resultCollection:
    doc = myDatabase[result['id']]
    if doc['content']['gxRequestId'] in gxRequestIds:
      docIdSetToBeDeleted.add(doc['content']['id'])

  print 'Number of PrefillRequests to be deleted: ', len(docIdSetToBeDeleted)
    
  with open(databaseName+'-prefillRequestsToBeDeleted.txt', 'w') as f:
    for item in docIdSetToBeDeleted:
      f.write("%s\n" % item)





def handleApprovalModelFlowRequests():
  databaseName = databasePrefix + '-requests'
  client.create_database(databaseName)
  myDatabase=client[databaseName]

  gxRequestIds = set(line.strip() for line in open(databaseName+'-gxRequestIds.txt'))

  docIdSetToBeDeleted = set()

  view = myDatabase.get_design_document("CouchDbApprovalModelFlowRequest").get_view("all")
  resultCollection = Result(view, include_docs=True)
  for result in resultCollection:
    doc = myDatabase[result['id']]
    if doc['content']['gxRequestId'] in gxRequestIds:
      docIdSetToBeDeleted.add(doc['content']['id'])

  print 'Number of ApprovalModelFlowRequests to be deleted: ', len(docIdSetToBeDeleted)

  with open(databaseName+'-approvalModelFlowRequestsToBeDeleted.txt', 'w') as f:
    for item in docIdSetToBeDeleted:
      f.write("%s\n" % item)

#### MAIN

handleGxRequests()
handlePrefillRequests()
handleApprovalModelFlowRequests()
