from cloudant.client import Cloudant
from cloudant.error import CloudantException
from cloudant.result import Result, ResultByKey
import os
import subprocess

#import sys
#print (sys.argv)
import getpass

databasePrefix = raw_input("Cloudant Database Prefix: ")
selectedChannelName = raw_input("Name of the channel that contains the issuer guarantees: ")
serviceUsername = raw_input("Cloudant Username: ")
servicePassword = getpass.getpass("Cloudant Password: ")
serviceURL = raw_input("Cloudant URL: ")

client = Cloudant(serviceUsername, servicePassword, url=serviceURL)
client.connect()

databaseName = databasePrefix + '-gx-expiration-jobs'
client.create_database(databaseName)
myDatabase=client[databaseName]

gxIds = set(line.strip() for line in open(databasePrefix+'-requests'+'-gxIds.txt'))

docIdSetToBeDeleted = set()

view = myDatabase.get_design_document("CouchDbGxExpirationJob").get_view("all")

remainingCount = 0
unrelatedCount = 0

resultCollection = Result(view, include_docs=True)
for result in resultCollection:
  doc = myDatabase[result['id']]

  try:
    status = doc['content']['status']
    if 'EMAILS_PROCESSED' in status:
      for gxId in gxIds:
        if gxId in str(doc['content']) or selectedChannelName in str(doc['content']):
          docIdSetToBeDeleted.add(doc['content']['id'])
          break
    else:
      unrelatedCount += 1
  except:
    print doc, '\n'
    remainingCount += 1
  

print 'Number of GxExpirationJobs to be deleted: ', len(docIdSetToBeDeleted)
print 'Number of GxExpirationJobs that are not in EMAILS_PROCESSED state: ', unrelatedCount
print 'Number of remaining documents: ', remainingCount

with open(databaseName+'-GxExpirationJobsToBeDeleted.txt', 'w') as f:
  for item in docIdSetToBeDeleted:
    f.write("%s\n" % item)

