from cloudant.client import Cloudant
from cloudant.error import CloudantException
from cloudant.result import Result, ResultByKey
import os
import subprocess

names = ['newco-admin', 'newco-user', 'michelangelo', 'raffaello', 'donatello', "leonardo"]

import getpass
serviceUsername = raw_input("Cloudant Username: ")
servicePassword = getpass.getpass("Cloudant Password: ")
serviceURL = raw_input("Cloudant URL: ")

client = Cloudant(serviceUsername, servicePassword, url=serviceURL)
client.connect()

# First, let's backup the contents of -crypto-keys and -fabric-users databases
print ("### Backing up crypto-keys and fabric-users databases...")
databasePrefixes = ['-crypto-keys', '-fabric-users']

f= open("backup.txt","w+")

for name in names:
  for databasePrefix in databasePrefixes:
    database_name = name + databasePrefix
    my_database = client[database_name]
    result_collection = Result(my_database.all_docs, include_docs=True)

    import time
    time.sleep(0.2)

    f.write("\n\n\n### Printing documents in database " + database_name + "\n\n\n")
    for result in result_collection:
      #f.write(result)
      my_document = my_database[result['id']]
      f.write(str(my_document))

f.close()



# Then, let's reset all databases
databasePrefixes = ['-audit-events', '-batch-process-configs', '-crypto-keys', '-fabric-users', '-notifications-email', '-notifications-web', '-org-change-requests', '-org-profile-requests', '-organizations', '-requests', '-user-profiles', '-gx-expiration-jobs', '-blockchain-events', '-terms-conditions']

permissions = ['', '', '', '', '', '']
permissions[0] = raw_input("Newco Admin Permission Username: ")
permissions[1] = raw_input("Newco User Permission Username: ")
permissions[2] = raw_input("Michelangelo Permission Username: ")
permissions[3] = raw_input("Raffaello Permission Username: ")
permissions[4] = raw_input("Donatello Permission Username: ")
permissions[5] = raw_input("Leonardo Permission Username: ")

for name in names:
  for databasePrefix in databasePrefixes:
    database_name = name + databasePrefix
    if database_name in client.all_dbs():
      my_database = client[database_name]
      print ('### Deleting database ' + database_name)
      my_database.delete()

i = 0
for name in names:
  permission = permissions[i]
  i = i+1
  for databasePrefix in databasePrefixes:
    database_name = name + databasePrefix
    if database_name not in client.all_dbs():
      print ('### Creating database ' + database_name)
      client.create_database(database_name)
      my_database = client[database_name]
      print ('### Setting permission ' + permission + ' on ' + database_name)
      my_database.share_database(permission, ['_admin','_writer','_reader', '_replicator'])
