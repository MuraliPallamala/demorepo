#!/usr/bin/env bash

#
# Creates the container registry
#

# Exit when a command fails
set -e
#set -o xtrace

if [[ -z "$API_KEY" ]]; then
  echo "You need to set the environment variable for the API_KEY first" >&2
  exit 1
fi

ibmcloud cr namespace-list | grep prjlygon
RESULT=$?
if [ $RESULT -eq 1 ]; then
  ibmcloud cr namespace-add prjlygon
fi
