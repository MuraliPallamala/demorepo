#!/usr/bin/env bash
#
# Deletes realms.
#
# 
# Author: Bruno Marques - brunomar@au1.ibm.com
#

# Exit when a command fails
set -o errexit

# Return error if any command after pipe fails
set -o pipefail


echo "Deleting realms except for master"

echo
echo; read -r -p '# Enter Keycloak URL: ' KEYCLOAK_URL
echo; read -r -p '# Enter Keycloak username: ' KEYCLOAK_USERNAME
echo; read -r -p '# Enter Keycloak password: ' KEYCLOAK_PASSWORD
echo

echo "curl -d \"client_id=admin-cli&username=$KEYCLOAK_USERNAME&password=$KEYCLOAK_PASSWORD&grant_type=password\" -k -X POST $KEYCLOAK_URL/auth/realms/master/protocol/openid-connect/token | python -c \"import sys, json; print json.load(sys.stdin)['access_token']\""

ACCESS_TOKEN=$(curl -d "client_id=admin-cli&username=$KEYCLOAK_USERNAME&password=$KEYCLOAK_PASSWORD&grant_type=password" -k -X POST $KEYCLOAK_URL/auth/realms/master/protocol/openid-connect/token | python -c "import sys, json; print json.load(sys.stdin)['access_token']")

REALMS=( $(curl -H "Content-Type: application/json" -H "Authorization: Bearer $ACCESS_TOKEN" -k -X GET $KEYCLOAK_URL/auth/admin/realms | python -c "exec(\"import sys, json\\nfor r in json.load(sys.stdin): print r['id']\")" | grep -v ^master) )

echo "Realms to be deleted:"
for f in "${REALMS[@]}"
do
  echo "${f}"
done


while true; do
    read -p "Do you wish to delete all the listed realms?" yn
    case $yn in
        [Yy]* ) 
              for f in "${REALMS[@]}"
              do
                echo "Deleting ${f}..."
                ACCESS_TOKEN=$(curl -d "client_id=admin-cli&username=$KEYCLOAK_USERNAME&password=$KEYCLOAK_PASSWORD&grant_type=password" -k -X POST $KEYCLOAK_URL/auth/realms/master/protocol/openid-connect/token | python -c "import sys, json; print json.load(sys.stdin)['access_token']")
        	      curl -H "Content-Type: application/json" -H "Authorization: Bearer $ACCESS_TOKEN" -k -X DELETE "$KEYCLOAK_URL/auth/admin/realms/${f}" &
              done
              break
              ;;
        [Nn]* ) exit;;
        * ) echo "Please answer yes or no.";;
    esac
done

wait