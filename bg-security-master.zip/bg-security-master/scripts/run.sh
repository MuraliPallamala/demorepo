bash deploy.sh --host user --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host admin --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host leonardo --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host michelangelo --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host donatello --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host raffaello --domain dlt.res.ibm.com --skip-login --logging-deploy

bash deploy.sh --host user-core --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host admin-core --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host leonardo-core --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host michelangelo-core --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host donatello-core --domain dlt.res.ibm.com --skip-login --logging-deploy
bash deploy.sh --host raffaello-core --domain dlt.res.ibm.com --skip-login --logging-deploy