#!/usr/bin/env bash

#
# SSH to all VMs
#

set -e

SYSADMIN_USERNAME=root
DOMAIN=dlt.res.ibm.com

name_jumpbox=jumpbox.$DOMAIN
name_bigfix=bigfix.$DOMAIN
name_services=services.$DOMAIN
name_services_core=services-core.$DOMAIN
name_admin=admin.$DOMAIN
name_admin_core=admin-core.$DOMAIN
name_user=user.$DOMAIN
name_user_core=user-core.$DOMAIN
name_leonardo=leonardo.$DOMAIN
name_leonardo_core=leonardo-core.$DOMAIN
name_michelangelo=michelangelo.$DOMAIN
name_michelangelo_core=michelangelo-core.$DOMAIN
name_donatello=donatello.$DOMAIN
name_donatello_core=donatello-core.$DOMAIN
name_raffaello=raffaello.$DOMAIN
name_raffaello_core=raffaello-core.$DOMAIN
name_mock_ibp=mock-ibp.$DOMAIN

ip_jumpbox=$(cat /etc/hosts | grep $name_jumpbox | tr -s ' ' | cut -d ' ' -f1)
ip_bigfix=$(cat /etc/hosts | grep $name_bigfix | tr -s ' ' | cut -d ' ' -f1)
ip_services=$(cat /etc/hosts | grep $name_services | tr -s ' ' | cut -d ' ' -f1)
ip_services_core=$(cat /etc/hosts | grep $name_services_core | tr -s ' ' | cut -d ' ' -f1)
ip_admin=$(cat /etc/hosts | grep $name_admin | tr -s ' ' | cut -d ' ' -f1)
ip_admin_core=$(cat /etc/hosts | grep $name_admin_core | tr -s ' ' | cut -d ' ' -f1)
ip_user=$(cat /etc/hosts | grep $name_user | tr -s ' ' | cut -d ' ' -f1)
ip_user_core=$(cat /etc/hosts | grep $name_user_core | tr -s ' ' | cut -d ' ' -f1)
ip_leonardo=$(cat /etc/hosts | grep $name_leonardo | tr -s ' ' | cut -d ' ' -f1)
ip_leonardo_core=$(cat /etc/hosts | grep $name_leonardo_core | tr -s ' ' | cut -d ' ' -f1)
ip_michelangelo=$(cat /etc/hosts | grep $name_michelangelo | tr -s ' ' | cut -d ' ' -f1)
ip_michelangelo_core=$(cat /etc/hosts | grep $name_michelangelo_core | tr -s ' ' | cut -d ' ' -f1)
ip_donatello=$(cat /etc/hosts | grep $name_donatello | tr -s ' ' | cut -d ' ' -f1)
ip_donatello_core=$(cat /etc/hosts | grep $name_donatello_core | tr -s ' ' | cut -d ' ' -f1)
ip_raffaello=$(cat /etc/hosts | grep $name_raffaello | tr -s ' ' | cut -d ' ' -f1)
ip_raffaello_core=$(cat /etc/hosts | grep $name_raffaello_core | tr -s ' ' | cut -d ' ' -f1)
ip_mock_ibp=$(cat /etc/hosts | grep $name_mock_ibp | tr -s ' ' | cut -d ' ' -f1)

var=-1

osascript <<-eof
  tell application "iTerm2"
    # Create Window.
    tell current window
      create window with default profile
    end tell

    tell session $(((var+=1))) of current tab of current window
      set name to "SSHing"
      split horizontally with default profile
      split horizontally with default profile
      split horizontally with default profile
      split horizontally with default profile
      split horizontally with default profile
    end tell 
    
    # Exec commands
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_jumpbox"
        write text "export VSI_HOSTNAME=$name_jumpbox"
        write text "export VSI_IP=$ip_jumpbox"
        
        split vertically with default profile
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_mock_ibp"
        write text "export VSI_HOSTNAME=$name_mock_ibp"
        write text "export VSI_IP=$ip_mock_ibp"
    end tell
    
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_bigfix"
        write text "export VSI_HOSTNAME=$name_bigfix"
        write text "export VSI_IP=$ip_bigfix"
        
        split vertically with default profile
        split vertically with default profile
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_services"
        write text "export VSI_HOSTNAME=$name_services"
        write text "export VSI_IP=$ip_services"
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_user"
        write text "export VSI_HOSTNAME=$name_user"
        write text "export VSI_IP=$ip_user"
    end tell
    
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_admin"
        write text "export VSI_HOSTNAME=$name_admin"
        write text "export VSI_IP=$ip_admin"
        
        split vertically with default profile
        split vertically with default profile
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_leonardo"
        write text "export VSI_HOSTNAME=$name_leonardo"
        write text "export VSI_IP=$ip_leonardo"
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_michelangelo"
        write text "export VSI_HOSTNAME=$name_michelangelo"
        write text "export VSI_IP=$ip_michelangelo"
    end tell
    
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_donatello"
        write text "export VSI_HOSTNAME=$name_donatello"
        write text "export VSI_IP=$ip_donatello"
        
        split vertically with default profile
        split vertically with default profile
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_raffaello"
        write text "export VSI_HOSTNAME=$name_raffaello"
        write text "export VSI_IP=$ip_raffaello"
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_services_core"
        write text "export VSI_HOSTNAME=$name_services_core"
        write text "export VSI_IP=$ip_services_core"
    end tell
    
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_user_core"
        write text "export VSI_HOSTNAME=$name_user_core"
        write text "export VSI_IP=$ip_user_core"
        
        split vertically with default profile
        split vertically with default profile
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_admin_core"
        write text "export VSI_HOSTNAME=$name_admin_core"
        write text "export VSI_IP=$ip_admin_core"
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_leonardo_core"
        write text "export VSI_HOSTNAME=$name_leonardo_core"
        write text "export VSI_IP=$ip_leonardo_core"
    end tell
    
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_michelangelo_core"
        write text "export VSI_HOSTNAME=$name_michelangelo_core"
        write text "export VSI_IP=$ip_michelangelo_core"
        
        split vertically with default profile
        split vertically with default profile
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_donatello_core"
        write text "export VSI_HOSTNAME=$name_donatello_core"
        write text "export VSI_IP=$ip_donatello_core"
    end tell
    tell session $(((var+=1))) of current tab of current window
        #write text "ssh $SYSADMIN_USERNAME@$ip_raffaello_core"
        write text "export VSI_HOSTNAME=$name_raffaello_core"
        write text "export VSI_IP=$ip_raffaello_core"
    end tell
    
  end tell
eof
