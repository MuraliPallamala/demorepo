#!/usr/bin/env bash

#
# Installs s3fs-fuse and mounts the COS.
# Followed instruction from:
# https://developer.ibm.com/recipes/tutorials/mounting-a-cos-bucket-with-s3fs/

# Exit when a command fails
set -e

# Installing Docker
echo ''
echo '# Installing s3fs-fuse'
echo ''
mkdir -p /root/sandbox/container-orchestration
cd /root/sandbox/container-orchestration
apt-get update
apt-get install -y automake autotools-dev g++ git libcurl4-openssl-dev libfuse-dev libssl-dev libxml2-dev make pkg-config
git clone https://github.com/s3fs-fuse/s3fs-fuse.git
cd s3fs-fuse
./autogen.sh
./configure
make
sudo make install

mount /opt/dlt/data/conf

# s3fs newco-user-web /opt/dlt/data/web -o passwd_file=$HOME/.cos_creds-newco-user-web -o sigv2 -o use_path_request_style -o url=https://s3.mel01.objectstorage.service.networklayer.com
# s3fs newco-user-conf /opt/dlt/data/conf -o passwd_file=$HOME/.cos_creds-newco-user-conf -o sigv2 -o use_path_request_style -o url=https://s3.mel01.objectstorage.service.networklayer.com
