#!/usr/bin/env bash

#
# Installs the container orchestration environment
# Followed instruction from:
# https://kubernetes.io/docs/setup/independent/create-cluster-kubeadm/
# https://kubernetes.io/docs/setup/independent/install-kubeadm/

# Exit when a command fails
set -e

# Installing Docker
echo ''
echo '# Installing Docker'
echo ''
apt-get update
apt-get install -y docker.io


echo ''
echo '# Installing kubeadm, kubelet and kubectl'
echo ''
apt-get update && apt-get install -y apt-transport-https curl
curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add -
cat <<EOF >/etc/apt/sources.list.d/kubernetes.list
deb http://apt.kubernetes.io/ kubernetes-xenial main
EOF
apt-get update
apt-get install -y kubelet kubeadm kubectl
apt-mark hold kubelet kubeadm kubectl

swapoff -a
sed -ri '/\sswap\s/s/^#?/#/' /etc/fstab

MY_IP=$(ifconfig eth0 | grep inet | grep -v inet6 | awk '{print $2}' | cut -d ':'  -f2)

# starts the cluster
kubeadm reset -f
kubeadm init --pod-network-cidr=192.168.0.0/16 --apiserver-advertise-address=$MY_IP
#kubeadm init --pod-network-cidr=192.168.0.0/24 --apiserver-advertise-address=$MY_IP --service-cidr=192.168.1.0/24
#kubeadm init --apiserver-advertise-address=$MY_IP --service-cidr=192.170.0.0/16 --pod-network-cidr=192.168.0.0/16

# sed the file to change port range
sed -i '/- kube-apiserver/a \ \ \ \ - --service-node-port-range=80-52767' /etc/kubernetes/manifests/kube-apiserver.yaml

export KUBECONFIG=/etc/kubernetes/admin.conf
if grep  "^export KUBECONFIG=" $HOME/.bashrc; then
  sed -i "s/^export KUBECONFIG=.*/export KUBECONFIG=\/etc\/kubernetes\/admin.conf/" $HOME/.bashrc
else
  echo '' >> $HOME/.bashrc
  echo "export KUBECONFIG=/etc/kubernetes/admin.conf" >> $HOME/.bashrc
fi


#Wait to see one container running
while ! kubectl get pods --all-namespaces | grep Running > /dev/null;
do
  sleep 2
done

# Pod network: Calico
kubectl apply -f https://docs.projectcalico.org/v3.3/getting-started/kubernetes/installation/hosted/rbac-kdd.yaml
kubectl apply -f https://docs.projectcalico.org/v3.3/getting-started/kubernetes/installation/hosted/kubernetes-datastore/calico-networking/1.7/calico.yaml

# Pod network: Weave
# sysctl net.bridge.bridge-nf-call-iptables=1
# kubectl apply -f "https://cloud.weave.works/k8s/net?k8s-version=$(kubectl version | base64 | tr -d '\n')&env.IPALLOC_RANGE=192.168.0.0/16"


kubectl get pods --all-namespaces

kubectl taint nodes --all node-role.kubernetes.io/master-
  
systemctl enable kubelet
systemctl daemon-reload
systemctl restart kubelet


# # load hosts that need to added from enviroment file
# source .env
#
# # kubectl get configMap coredns -n kube-system -o json > coredns-configMap.json
# kubectl get configMap coredns -n kube-system -o json > coredns-configMap.json
# HOSTS=''
# for host in "${hosts[@]}"
# do
#   HOSTS="$HOSTS$host\\\\n"
# done
# echo $HOSTS
#
# sed -i -e "s/proxy\ .\ \/etc\/resolv.conf\\n/proxy\ .\ \/etc\/resolv.conf\\n$HOSTS/g" coredns-configMap.json
#
#
# sed -i -e "s#proxy\ \.\ /etc/resolv\.conf\\\\n#proxy\ \.\ /etc/resolv\.conf\\\\n$HOSTS#g" coredns-configMap.json
#
# # kill coredns
# 
# 
