#!/bin/bash

# exit when any command fails
set -e

read -sp "If you want to use the same password for all keys and keystore, please enter it now. Otherwise, press ENTER:" MASTER_PASSWORD
echo
CAKEY_PASSWORD=${MASTER_PASSWORD}
CERTKEY_PASSWORD=${MASTER_PASSWORD}
KEYSTORE_PASSWORD=${MASTER_PASSWORD}
TRUSTSTORE_PASSWORD=${MASTER_PASSWORD}

S_COUNTRY=${3:-AU}
S_STATE=${4:-Victoria}
S_LOCATION=${5:-Melbourne}
S_ORGANIZATION=${6:-International Business Machines}
S_ORGANIZATION_UNIT=${7:-IBM Research}
S_EMAIL=${8:-prjlygonmic@au1.ibm.com}

CUR_DIR=`pwd`
CERTS_DIR=$DEV_ROOT/bg-network/setups/test/data/common/conf

for VERTICAL in bg-pilot-qa bg-pilot-testbox; do
  mkdir -p ${CERTS_DIR}/${VERTICAL}
done

STEP_COUNTER=0

# # # # # # # # # # # # # # # #
# external client certificates
# # # # # # # # # # # # # # # #
for VM in bg-pilot-qa bg-pilot-testbox; do
  STEP_COUNTER=$((STEP_COUNTER+1))
  echo
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo " STEP ${STEP_COUNTER}: Generating CA Root for ${DOMAIN} for creation of external client certificates..."
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo

  DOMAIN="${VM}.sl.cloud9.ibm.com"
  COMMON_NAME="${DOMAIN}.CLIENT.ca"
  CAKEY="${CERTS_DIR}/${VM}/${COMMON_NAME}.key"
  CAPEM="${CERTS_DIR}/${VM}/${COMMON_NAME}.pem"

  [ -z "${MASTER_PASSWORD}" ] && read -sp "Password for ${CAKEY}:" CAKEY_PASSWORD
  echo

  echo "      - openssl genrsa -des3 -out ${CAKEY} ..."
  openssl genrsa -des3 -out ${CAKEY} -passout pass:${CAKEY_PASSWORD} 4096

  echo "   - openssl req -new -x509 -days 365 -key ${CAKEY} -sha256 -out ${CAPEM} ..."
  openssl req -passin pass:${CAKEY_PASSWORD} -new -x509 -subj "/C=${S_COUNTRY}/ST=${S_STATE}/L=${S_LOCATION}/O=${S_ORGANIZATION}/OU=${S_ORGANIZATION_UNIT}/CN=${COMMON_NAME}/emailAddress=${S_EMAIL}" -days 365 -key ${CAKEY} -sha256 -out ${CAPEM} 

  echo ""

  STEP_COUNTER=$((STEP_COUNTER+1))
  echo
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo " STEP ${STEP_COUNTER}: Generating external client certificates for ${DOMAIN}: "
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo

  ECC_COMMON_NAME="web.${VM}.dlt.res.ibm.com.CLIENT"
  ECC_KEY="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.key"
  ECC_CSR="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.csr"
  ECC_PEM="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.pem"
  ECC_COMB_PEM="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.combined.pem"
  ECC_P12="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.p12"

  [ -z "${MASTER_PASSWORD}" ] && read -sp "Password for ${ECC_KEY}:" CERTKEY_PASSWORD
  echo

  echo "   - openssl genrsa -des3 -out ${ECC_KEY} 4096 ..."
  openssl genrsa -des3 -out ${ECC_KEY} -passout pass:${CERTKEY_PASSWORD} 4096

  echo "   - openssl req -new -key ${ECC_KEY} -sha256 -out ${ECC_CSR} ..."
  openssl req -passin pass:${CERTKEY_PASSWORD} -subj "/C=${S_COUNTRY}/ST=${S_STATE}/L=${S_LOCATION}/O=${S_ORGANIZATION}/OU=${S_ORGANIZATION_UNIT}/CN=${ECC_COMMON_NAME}/emailAddress=${S_EMAIL}" -new -key ${ECC_KEY} -sha256 -out ${ECC_CSR}

  #sed -i -E "s/^DNS.*/DNS\.1 = ${ECC_COMMON_NAME}/" v3.ext
  echo "   - [SELF SIGNING] openssl x509 -req -days 365 -sha256 -in ${ECC_CSR} -CA ${CAPEM} -CAkey ${CAKEY} -set_serial 01 -out ${ECC_PEM} ..."
  openssl x509 -passin pass:${CAKEY_PASSWORD} -req -days 365 -sha256 -in ${ECC_CSR} -CA ${CAPEM} -CAkey ${CAKEY} -set_serial 01 -out ${ECC_PEM} -extfile client.cnf

  echo "   - Removing the password from the Key file ..."
  echo
  echo "   - openssl rsa -in ${ECC_KEY} -out ${ECC_KEY}.nopwd"
  openssl rsa -passin pass:${CERTKEY_PASSWORD} -in ${ECC_KEY} -out ${ECC_KEY}.nopwd
  echo ""

  echo "   - Converting to PKCS ..."
  echo
  echo "   - openssl pkcs12 -export -clcerts -in ${ECC_PEM} -inkey ${ECC_KEY} -out ${ECC_P12} ..."
  openssl pkcs12 -passin pass:${CERTKEY_PASSWORD} -passout pass:${CERTKEY_PASSWORD} -export -clcerts -in ${ECC_PEM} -inkey ${ECC_KEY} -out ${ECC_P12}

  echo ""

  echo "   - Converting Client Key to (combined) PEM ..."
  echo
  echo "   - openssl pkcs12 -in ${ECC_P12} -out ${ECC_COMB_PEM} -clcerts ..."
  openssl pkcs12 -password pass:${CERTKEY_PASSWORD} -passin pass:${CERTKEY_PASSWORD} -passout pass:${CERTKEY_PASSWORD} -in ${ECC_P12} -out ${ECC_COMB_PEM} -clcerts

  echo ""

  echo ""

done
