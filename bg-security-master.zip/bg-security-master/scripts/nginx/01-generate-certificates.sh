#!/bin/bash

# exit when any command fails
set -e

read -sp "If you want to use the same password for all keys and keystore, please enter it now. Otherwise, press ENTER:" MASTER_PASSWORD
echo
CAKEY_PASSWORD=${MASTER_PASSWORD}
CERTKEY_PASSWORD=${MASTER_PASSWORD}
KEYSTORE_PASSWORD=${MASTER_PASSWORD}
TRUSTSTORE_PASSWORD=${MASTER_PASSWORD}

S_COUNTRY=${3:-AU}
S_STATE=${4:-Victoria}
S_LOCATION=${5:-Melbourne}
S_ORGANIZATION=${6:-International Business Machines}
S_ORGANIZATION_UNIT=${7:-IBM Research}
S_EMAIL=${8:-prjlygonmic@au1.ibm.com}

EXTERNAL_WEB_CER_DIR="${HOME}/.ssh/prjlygon"

CUR_DIR=`pwd`
OUTPUT_DIR=${CUR_DIR}/output
BUCKET_DIR=${OUTPUT_DIR}/buckets
CERTS_DIR=${OUTPUT_DIR}/certs

# Deleting old data and recreating folders

rm -rf ${OUTPUT_DIR}
mkdir -p ${BUCKET_DIR}
mkdir -p ${CERTS_DIR}

for VERTICAL in services admin user michelangelo raffaello donatello leonardo support; do
  # The following 2 directories will store all the generated certificates and keys.
  mkdir -p ${CERTS_DIR}/${VERTICAL}
  mkdir -p ${CERTS_DIR}/${VERTICAL}-core
  
  # The following 2 directories will store only the certificates, keys and keystores are are needed by the VMs.
  mkdir -p ${BUCKET_DIR}/${VERTICAL}-conf/certs
  mkdir -p ${BUCKET_DIR}/${VERTICAL}-core-conf/certs
done

echo
echo "There are 3 distinct CA certificates for each vertical: "
echo "    - one for generating external client certificates "
echo "    - one for generating internal client certificates"
echo "    - one for generating internal web server certificates"
echo

STEP_COUNTER=0

# # # # # # # # # # # # # # # #
# external client certificates
# # # # # # # # # # # # # # # #
for VM in services admin user michelangelo raffaello donatello leonardo; do
  STEP_COUNTER=$((STEP_COUNTER+1))
  echo
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo " STEP ${STEP_COUNTER}: Generating CA Root for ${DOMAIN} for creation of external client certificates..."
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo

  DOMAIN="${VM}.dlt.res.ibm.com"
  COMMON_NAME="${DOMAIN}.CLIENT.ca"
  CAKEY="${CERTS_DIR}/${VM}/${COMMON_NAME}.key"
  CAPEM="${CERTS_DIR}/${VM}/${COMMON_NAME}.pem"

  [ -z "${MASTER_PASSWORD}" ] && read -sp "Password for ${CAKEY}:" CAKEY_PASSWORD
  echo

  echo "      - openssl genrsa -des3 -out ${CAKEY} ..."
  openssl genrsa -des3 -out ${CAKEY} -passout pass:${CAKEY_PASSWORD} 4096

  echo "   - openssl req -new -x509 -days 365 -key ${CAKEY} -sha256 -out ${CAPEM} ..."
  openssl req -passin pass:${CAKEY_PASSWORD} -new -x509 -subj "/C=${S_COUNTRY}/ST=${S_STATE}/L=${S_LOCATION}/O=${S_ORGANIZATION}/OU=${S_ORGANIZATION_UNIT}/CN=${COMMON_NAME}/emailAddress=${S_EMAIL}" -days 365 -key ${CAKEY} -sha256 -out ${CAPEM} 

  echo ""

  STEP_COUNTER=$((STEP_COUNTER+1))
  echo
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo " STEP ${STEP_COUNTER}: Generating external client certificates for ${DOMAIN}: "
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo

  ECC_COMMON_NAME="web.${VM}.dlt.res.ibm.com.CLIENT"
  ECC_KEY="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.key"
  ECC_CSR="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.csr"
  ECC_PEM="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.pem"
  ECC_COMB_PEM="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.combined.pem"
  ECC_P12="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.p12"

  [ -z "${MASTER_PASSWORD}" ] && read -sp "Password for ${ECC_KEY}:" CERTKEY_PASSWORD
  echo

  echo "   - openssl genrsa -des3 -out ${ECC_KEY} 4096 ..."
  openssl genrsa -des3 -out ${ECC_KEY} -passout pass:${CERTKEY_PASSWORD} 4096

  echo "   - openssl req -new -key ${ECC_KEY} -sha256 -out ${ECC_CSR} ..."
  openssl req -passin pass:${CERTKEY_PASSWORD} -subj "/C=${S_COUNTRY}/ST=${S_STATE}/L=${S_LOCATION}/O=${S_ORGANIZATION}/OU=${S_ORGANIZATION_UNIT}/CN=${ECC_COMMON_NAME}/emailAddress=${S_EMAIL}" -new -key ${ECC_KEY} -sha256 -out ${ECC_CSR}

  #sed -i -E "s/^DNS.*/DNS\.1 = ${ECC_COMMON_NAME}/" v3.ext
  echo "   - [SELF SIGNING] openssl x509 -req -days 365 -sha256 -in ${ECC_CSR} -CA ${CAPEM} -CAkey ${CAKEY} -set_serial 01 -out ${ECC_PEM} ..."
  openssl x509 -passin pass:${CAKEY_PASSWORD} -req -days 365 -sha256 -in ${ECC_CSR} -CA ${CAPEM} -CAkey ${CAKEY} -set_serial 01 -out ${ECC_PEM} -extfile client.cnf

  echo "   - Removing the password from the Key file ..."
  echo
  echo "   - openssl rsa -in ${ECC_KEY} -out ${ECC_KEY}.nopwd"
  openssl rsa -passin pass:${CERTKEY_PASSWORD} -in ${ECC_KEY} -out ${ECC_KEY}.nopwd
  echo ""

  echo "   - Converting to PKCS ..."
  echo
  echo "   - openssl pkcs12 -export -clcerts -in ${ECC_PEM} -inkey ${ECC_KEY} -out ${ECC_P12} ..."
  openssl pkcs12 -passin pass:${CERTKEY_PASSWORD} -passout pass:${CERTKEY_PASSWORD} -export -clcerts -in ${ECC_PEM} -inkey ${ECC_KEY} -out ${ECC_P12}

  echo ""

  echo "   - Converting Client Key to (combined) PEM ..."
  echo
  echo "   - openssl pkcs12 -in ${ECC_P12} -out ${ECC_COMB_PEM} -clcerts ..."
  openssl pkcs12 -password pass:${CERTKEY_PASSWORD} -passin pass:${CERTKEY_PASSWORD} -passout pass:${CERTKEY_PASSWORD} -in ${ECC_P12} -out ${ECC_COMB_PEM} -clcerts

  echo ""

  echo ""

done

# # # # # # # # # # # # # # # #
# internal client certificates
# # # # # # # # # # # # # # # #
#
for VM in services-core admin-core user-core michelangelo-core raffaello-core donatello-core leonardo-core support; do
  DOMAIN="${VM}.dlt.res.ibm.com"
  COMMON_NAME="${DOMAIN}.CLIENT.ca"
  CAKEY="${CERTS_DIR}/${VM}/${COMMON_NAME}.key"
  CAPEM="${CERTS_DIR}/${VM}/${COMMON_NAME}.pem"
  CA_CERTIFICATE_SERIAL_PATH="${CERTS_DIR}/${VM}/${COMMON_NAME}.csp"

  [ -z "${MASTER_PASSWORD}" ] && read -sp "Password for ${CAKEY}:" CAKEY_PASSWORD
  echo

  STEP_COUNTER=$((STEP_COUNTER+1))
  echo
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo " STEP ${STEP_COUNTER}: Generating CA Root for ${DOMAIN} for creation of internal client certificates..."
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo

  echo "      - openssl genrsa -des3 -out ${CAKEY} ..."
  openssl genrsa -des3 -out ${CAKEY} -passout pass:${CAKEY_PASSWORD} 4096

  echo "   - openssl req -new -x509 -days 365 -key ${CAKEY} -sha256 -out ${CAPEM} ..."
  openssl req -passin pass:${CAKEY_PASSWORD} -new -x509 -subj "/C=${S_COUNTRY}/ST=${S_STATE}/L=${S_LOCATION}/O=${S_ORGANIZATION}/OU=${S_ORGANIZATION_UNIT}/CN=${COMMON_NAME}/emailAddress=${S_EMAIL}" -days 365 -key ${CAKEY} -sha256 -out ${CAPEM}

  echo ""

  STEP_COUNTER=$((STEP_COUNTER+1))
  echo
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo " STEP ${STEP_COUNTER}: Generating internal client certificates for ${DOMAIN}: "
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo

  for FROM in services services-core admin admin-core user user-core michelangelo michelangelo-core raffaello raffaello-core donatello donatello-core leonardo leonardo-core support; do

    ECC_COMMON_NAME="${FROM}.${VM}.dlt.res.ibm.com.CLIENT"
    ECC_KEY="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.key"
    ECC_CSR="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.csr"
    ECC_PEM="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.pem"
    ECC_COMB_PEM="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.combined.pem"
    ECC_P12="${CERTS_DIR}/${VM}/${ECC_COMMON_NAME}.p12"

    [ -z "${MASTER_PASSWORD}" ] && read -sp "Password for ${ECC_KEY}:" CERTKEY_PASSWORD
    echo

    echo "   - openssl genrsa -des3 -out ${ECC_KEY} 4096 ..."
    openssl genrsa -des3 -out ${ECC_KEY} -passout pass:${CERTKEY_PASSWORD} 4096

    echo "   - openssl req -new -key ${ECC_KEY} -sha256 -out ${ECC_CSR} ..."
    openssl req -passin pass:${CERTKEY_PASSWORD} -subj "/C=${S_COUNTRY}/ST=${S_STATE}/L=${S_LOCATION}/O=${S_ORGANIZATION}/OU=${S_ORGANIZATION_UNIT}/CN=${ECC_COMMON_NAME}/emailAddress=${S_EMAIL}" -new -key ${ECC_KEY} -sha256 -out ${ECC_CSR}

    #sed -i -E "s/^DNS.*/DNS\.1 = ${ECC_COMMON_NAME}/" v3.ext
    echo "   - [SELF SIGNING] openssl x509 -req -days 365 -sha256 -in ${ECC_CSR} -CA ${CAPEM} -CAkey ${CAKEY} -CAcreateserial -CAserial ${CA_CERTIFICATE_SERIAL_PATH} -out ${ECC_PEM} ..."
    openssl x509 -passin pass:${CAKEY_PASSWORD} -req -days 365 -sha256 -in ${ECC_CSR} -CA ${CAPEM} -CAkey ${CAKEY} -CAcreateserial -CAserial ${CA_CERTIFICATE_SERIAL_PATH} -out ${ECC_PEM} -extfile client.cnf

    echo "   - Removing the password from the Key file ..."
    echo
    echo "   - openssl rsa -in ${ECC_KEY} -out ${ECC_KEY}.nopwd"
    openssl rsa -passin pass:${CERTKEY_PASSWORD} -in ${ECC_KEY} -out ${ECC_KEY}.nopwd
    echo ""

    echo "   - Converting to PKCS ..."
    echo
    echo "   - openssl pkcs12 -export -clcerts -in ${ECC_PEM} -inkey ${ECC_KEY} -out ${ECC_P12} ..."
    openssl pkcs12 -passin pass:${CERTKEY_PASSWORD} -passout pass:${CERTKEY_PASSWORD} -export -clcerts -in ${ECC_PEM} -inkey ${ECC_KEY} -out ${ECC_P12}

    echo ""

    echo "   - Converting Client Key to (combined) PEM ..."
    echo
    echo "   - openssl pkcs12 -in ${ECC_P12} -out ${ECC_COMB_PEM} -clcerts ..."
    openssl pkcs12 -password pass:${CERTKEY_PASSWORD} -passin pass:${CERTKEY_PASSWORD} -passout pass:${CERTKEY_PASSWORD} -in ${ECC_P12} -out ${ECC_COMB_PEM} -clcerts

    echo ""

    echo ""
  done
done

# # # # # # # # # # # # # # # # # #
# internal web server certificates
# # # # # # # # # # # # # # # # # #
for VM in services-core admin-core user-core michelangelo-core raffaello-core donatello-core leonardo-core support; do
  DOMAIN="${VM}.dlt.res.ibm.com"
  COMMON_NAME="${DOMAIN}.ca"
  CAKEY="${CERTS_DIR}/${VM}/${COMMON_NAME}.key"
  CAPEM="${CERTS_DIR}/${VM}/${COMMON_NAME}.pem"
  CA_CERTIFICATE_SERIAL_PATH="${CERTS_DIR}/${VM}/${COMMON_NAME}.csp"

  [ -z "${MASTER_PASSWORD}" ] && read -sp "Password for ${CAKEY}:" CAKEY_PASSWORD
  echo

  STEP_COUNTER=$((STEP_COUNTER+1))
  echo
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo " STEP ${STEP_COUNTER}: Generating CA Root for ${DOMAIN} for creation of internal client certificates.."
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo

  echo "      - openssl genrsa -des3 -out ${CAKEY} ..."
  openssl genrsa -des3 -out ${CAKEY} -passout pass:${CAKEY_PASSWORD} 4096

  echo "   - openssl req -new -x509 -days 365 -key ${CAKEY} -sha256 -out ${CAPEM} ..."
  openssl req -passin pass:${CAKEY_PASSWORD} -new -x509 -subj "/C=${S_COUNTRY}/ST=${S_STATE}/L=${S_LOCATION}/O=${S_ORGANIZATION}/OU=${S_ORGANIZATION_UNIT}/CN=${COMMON_NAME}/emailAddress=${S_EMAIL}" -days 365 -key ${CAKEY} -sha256 -out ${CAPEM}

  echo ""

  STEP_COUNTER=$((STEP_COUNTER+1))
  echo
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo " STEP ${STEP_COUNTER}: Generating internal web server certificates for ${DOMAIN}:"
  echo " # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo

  IWS_COMMON_NAME="${VM}.dlt.res.ibm.com"
  IWS_KEY="${CERTS_DIR}/${VM}/${IWS_COMMON_NAME}.key"
  IWS_CSR="${CERTS_DIR}/${VM}/${IWS_COMMON_NAME}.csr"
  IWS_PEM="${CERTS_DIR}/${VM}/${IWS_COMMON_NAME}.pem"
  IWS_COMB_PEM="${CERTS_DIR}/${VM}/${IWS_COMMON_NAME}.combined.pem"
  IWS_P12="${CERTS_DIR}/${VM}/${IWS_COMMON_NAME}.p12"

  [ -z "${MASTER_PASSWORD}" ] && read -sp "Password for ${IWS_KEY}:" CERTKEY_PASSWORD
  echo

  echo "   - openssl genrsa -des3 -out ${IWS_KEY} 4096 ..."
  openssl genrsa -des3 -out ${IWS_KEY} -passout pass:${CERTKEY_PASSWORD} 4096

  echo "   - openssl req -new -key ${IWS_KEY} -sha256 -out ${IWS_CSR} ..."
  openssl req -passin pass:${CERTKEY_PASSWORD} -subj "/C=${S_COUNTRY}/ST=${S_STATE}/L=${S_LOCATION}/O=${S_ORGANIZATION}/OU=${S_ORGANIZATION_UNIT}/CN=${IWS_COMMON_NAME}/emailAddress=${S_EMAIL}" -new -key ${IWS_KEY} -sha256 -out ${IWS_CSR}

  sed -i -E "s/^DNS.*/DNS\.1 = ${IWS_COMMON_NAME}/" v3.ext
  echo "   - [SELF SIGNING] openssl x509 -req -days 365 -extfile v3.ext -sha256 -in ${IWS_CSR} -CA ${CAPEM} -CAkey ${CAKEY} -CAcreateserial -CAserial ${CA_CERTIFICATE_SERIAL_PATH} -out ${IWS_PEM} ..."
  openssl x509 -passin pass:${CAKEY_PASSWORD} -req -days 365 -extfile v3.ext -sha256 -in ${IWS_CSR} -CA ${CAPEM} -CAkey ${CAKEY} -CAcreateserial -CAserial ${CA_CERTIFICATE_SERIAL_PATH} -out ${IWS_PEM}

  echo "   - Removing the password from the Key file ..."
  echo
  echo "   - openssl rsa -in ${IWS_KEY} -out ${IWS_KEY}.nopwd"
  openssl rsa -passin pass:${CERTKEY_PASSWORD} -in ${IWS_KEY} -out ${IWS_KEY}.nopwd
  echo ""

  echo "   - Converting to PKCS ..."
  echo
  echo "   - openssl pkcs12 -export -clcerts -in ${IWS_PEM} -inkey ${IWS_KEY} -out ${IWS_P12} ..."
  openssl pkcs12 -passin pass:${CERTKEY_PASSWORD} -passout pass:${CERTKEY_PASSWORD} -export -clcerts -in ${IWS_PEM} -inkey ${IWS_KEY} -out ${IWS_P12}

  echo ""

  echo "   - Converting Client Key to (combined) PEM ..."
  echo
  echo "   - openssl pkcs12 -in ${IWS_P12} -out ${IWS_COMB_PEM} -clcerts ..."
  openssl pkcs12 -password pass:${CERTKEY_PASSWORD} -passin pass:${CERTKEY_PASSWORD} -passout pass:${CERTKEY_PASSWORD} -in ${IWS_P12} -out ${IWS_COMB_PEM} -clcerts

  echo ""

  echo ""
done



# # # # # # # # # # # # # # # # # #
# Preparing buckets
# # # # # # # # # # # # # # # # # #

# Admin, User, Michelangelo, Raffaello, Donatello Leonardo Portal
for VM in services admin user michelangelo raffaello donatello leonardo; do
  BUCKET=${VM}-conf/certs

  cp ${EXTERNAL_WEB_CER_DIR}/${VM}.dlt.res.ibm.com.chain.pem ${BUCKET_DIR}/${BUCKET}/.
  cp ${EXTERNAL_WEB_CER_DIR}/${VM}.dlt.res.ibm.com.key ${BUCKET_DIR}/${BUCKET}/${VM}.dlt.res.ibm.com.key
  cp ${CERTS_DIR}/${VM}/${VM}.dlt.res.ibm.com.CLIENT.ca.pem ${BUCKET_DIR}/${BUCKET}/.
  cp ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.ca.pem ${BUCKET_DIR}/${BUCKET}/.
  cp ${CERTS_DIR}/${VM}-core/${VM}.${VM}-core.dlt.res.ibm.com.CLIENT.key.nopwd ${BUCKET_DIR}/${BUCKET}/${VM}.${VM}-core.dlt.res.ibm.com.CLIENT.key
  cp ${CERTS_DIR}/${VM}-core/${VM}.${VM}-core.dlt.res.ibm.com.CLIENT.pem ${BUCKET_DIR}/${BUCKET}/.

done

# Certificates in services portal related to JIRA (support)
BUCKET=services-conf/certs
cp ${CERTS_DIR}/support/support.dlt.res.ibm.com.ca.pem ${BUCKET_DIR}/${BUCKET}/.
cp ${CERTS_DIR}/support/services.support.dlt.res.ibm.com.CLIENT.key.nopwd ${BUCKET_DIR}/${BUCKET}/services.support.dlt.res.ibm.com.CLIENT.key
cp ${CERTS_DIR}/support/services.support.dlt.res.ibm.com.CLIENT.pem ${BUCKET_DIR}/${BUCKET}/.


# Admin and User Core
for VM in admin user; do
  BUCKET=${VM}-core-conf/certs

  ## api.keystore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/api.keystore.jks
  
  [ -z "${MASTER_PASSWORD}" ] && read -sp "Keystore password for ${BUCKET_DIR}/${BUCKET}/api.keystore.jks: " KEYSTORE_PASSWORD
  echo
  
  for VERTICAL in admin user services michelangelo raffaello donatello leonardo; do

    ### Adding web.*.CLIENT p12s
    # Update password 
    openssl rsa -des3 -passin pass:${KEYSTORE_PASSWORD} -in ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.key.nopwd -passout pass:${KEYSTORE_PASSWORD} -out ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.otherpwd

    # Add certificate and key to pkcs12 file
    COMBINED_CERT=${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.combined.pem
    openssl pkcs12 -passin pass:${KEYSTORE_PASSWORD} -passout pass:${KEYSTORE_PASSWORD} -export -in ${COMBINED_CERT} -inkey ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.otherpwd -certfile ${COMBINED_CERT} -out ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.p12.otherpwd

    # Convert file to jks
    keytool -importkeystore -srckeystore ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.p12.otherpwd -srcstoretype pkcs12 -destkeystore ${BUCKET_DIR}/${BUCKET}/api.keystore.jks -srcalias 1 -deststoretype jks -destalias web.${VERTICAL}.dlt.res.ibm.com.CLIENT -destkeypass ${KEYSTORE_PASSWORD} -deststorepass ${KEYSTORE_PASSWORD} -srckeypass ${KEYSTORE_PASSWORD} -srcstorepass ${KEYSTORE_PASSWORD}


    ### Adding [admin|user]-core.*-core.*CLIENT p12s
    # Update password 
    openssl rsa -des3 -passin pass:${KEYSTORE_PASSWORD} -in ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.key.nopwd -passout pass:${KEYSTORE_PASSWORD} -out ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.key.otherpwd

    # Add certificate and key to pkcs12 file
    COMBINED_CERT=${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.combined.pem
    openssl pkcs12 -passin pass:${KEYSTORE_PASSWORD} -passout pass:${KEYSTORE_PASSWORD} -export -in ${COMBINED_CERT} -inkey ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.key.otherpwd -certfile ${COMBINED_CERT} -out ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.p12.otherpwd

    # Convert file to jks
    keytool -importkeystore -srckeystore ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.p12.otherpwd -srcstoretype pkcs12 -destkeystore ${BUCKET_DIR}/${BUCKET}/api.keystore.jks -srcalias 1 -deststoretype jks -destalias ${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT -destkeypass ${KEYSTORE_PASSWORD} -deststorepass ${KEYSTORE_PASSWORD} -srckeypass ${KEYSTORE_PASSWORD} -srcstorepass ${KEYSTORE_PASSWORD}

  done  
  

  ## api.truststore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/api.truststore.jks
  
  [ -z "${MASTER_PASSWORD}" ] && read -sp "Truststore password for ${BUCKET_DIR}/${BUCKET}/api.truststore.jks: " TRUSTSTORE_PASSWORD
  echo
  
  cp ${JAVA_HOME}/jre/lib/security/cacerts ${BUCKET_DIR}/${BUCKET}/api.truststore.jks
  keytool -storepass changeit -storepasswd -keystore ${BUCKET_DIR}/${BUCKET}/api.truststore.jks -new ${TRUSTSTORE_PASSWORD}
  
  for VERTICAL in admin user services michelangelo raffaello donatello leonardo; do
    keytool -import -alias ${VERTICAL}-core.dlt.res.ibm.com.ca -file ${CERTS_DIR}/${VERTICAL}-core/${VERTICAL}-core.dlt.res.ibm.com.ca.pem -storetype JKS -keystore ${BUCKET_DIR}/${BUCKET}/api.truststore.jks -storepass ${TRUSTSTORE_PASSWORD} -noprompt
  done
  
  

  ## tomcat.keystore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/tomcat.keystore.jks
  
  [ -z "${MASTER_PASSWORD}" ] && read -sp "Keystore password for ${BUCKET_DIR}/${BUCKET}/tomcat.keystore.jks: " KEYSTORE_PASSWORD
  echo
  
  # Update password 
  openssl rsa -des3 -passin pass:${KEYSTORE_PASSWORD} -in ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.key.nopwd -passout pass:${KEYSTORE_PASSWORD} -out ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.key.otherpwd

  # Add certificate and key to pkcs12 file
  COMBINED_CERT=${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.combined.pem
  openssl pkcs12 -passin pass:${KEYSTORE_PASSWORD} -passout pass:${KEYSTORE_PASSWORD} -export -in ${COMBINED_CERT} -inkey ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.key.otherpwd -certfile ${COMBINED_CERT} -out ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.p12.otherpwd

  # Convert file to jks
  keytool -importkeystore -srckeystore ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.p12.otherpwd -srcstoretype pkcs12 -destkeystore ${BUCKET_DIR}/${BUCKET}/tomcat.keystore.jks -srcalias 1 -deststoretype jks -destalias ${VM}-core.dlt.res.ibm.com -destkeypass ${KEYSTORE_PASSWORD} -deststorepass ${KEYSTORE_PASSWORD} -srckeypass ${KEYSTORE_PASSWORD} -srcstorepass ${KEYSTORE_PASSWORD}
  
  

  ## tomcat.truststore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks

  [ -z "${MASTER_PASSWORD}" ] && read -sp "Truststore password for ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks: " TRUSTSTORE_PASSWORD
  echo
  
  cp ${JAVA_HOME}/jre/lib/security/cacerts ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks
  keytool -storepass changeit -storepasswd -keystore ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks -new ${TRUSTSTORE_PASSWORD}
  
  for VERTICAL in admin user services michelangelo raffaello donatello leonardo; do
    keytool -import -alias ${VERTICAL}-core.dlt.res.ibm.com.ca -file ${CERTS_DIR}/${VERTICAL}-core/${VERTICAL}-core.dlt.res.ibm.com.ca.pem -storetype JKS -keystore ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks -storepass ${TRUSTSTORE_PASSWORD} -noprompt
  done
  keytool -import -alias ${VM}-core.dlt.res.ibm.com.CLIENT.ca -file ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.CLIENT.ca.pem -storetype JKS -keystore ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks -storepass ${TRUSTSTORE_PASSWORD} -noprompt
  
done



# Issuer's Core
for VM in michelangelo raffaello donatello leonardo; do
  BUCKET=${VM}-core-conf/certs

  ## api.keystore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/api.keystore.jks
  
  [ -z "${MASTER_PASSWORD}" ] && read -sp "Keystore password for ${BUCKET_DIR}/${BUCKET}/api.keystore.jks: " KEYSTORE_PASSWORD
  echo
  
  for VERTICAL in admin user services ${VM}; do

    ### Adding web.*.CLIENT p12s
    # Update password 
    openssl rsa -des3 -passin pass:${KEYSTORE_PASSWORD} -in ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.key.nopwd -passout pass:${KEYSTORE_PASSWORD} -out ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.otherpwd

    # Add certificate and key to pkcs12 file
    COMBINED_CERT=${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.combined.pem
    openssl pkcs12 -passin pass:${KEYSTORE_PASSWORD} -passout pass:${KEYSTORE_PASSWORD} -export -in ${COMBINED_CERT} -inkey ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.otherpwd -certfile ${COMBINED_CERT} -out ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.p12.otherpwd

    # Convert file to jks
    keytool -importkeystore -srckeystore ${CERTS_DIR}/${VERTICAL}/web.${VERTICAL}.dlt.res.ibm.com.CLIENT.p12.otherpwd -srcstoretype pkcs12 -destkeystore ${BUCKET_DIR}/${BUCKET}/api.keystore.jks -srcalias 1 -deststoretype jks -destalias web.${VERTICAL}.dlt.res.ibm.com.CLIENT -destkeypass ${KEYSTORE_PASSWORD} -deststorepass ${KEYSTORE_PASSWORD} -srckeypass ${KEYSTORE_PASSWORD} -srcstorepass ${KEYSTORE_PASSWORD}


    ### Adding [admin|user]-core.*-core.*CLIENT p12s
    # Update password 
    openssl rsa -des3 -passin pass:${KEYSTORE_PASSWORD} -in ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.key.nopwd -passout pass:${KEYSTORE_PASSWORD} -out ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.key.otherpwd

    # Add certificate and key to pkcs12 file
    COMBINED_CERT=${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.combined.pem
    openssl pkcs12 -passin pass:${KEYSTORE_PASSWORD} -passout pass:${KEYSTORE_PASSWORD} -export -in ${COMBINED_CERT} -inkey ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.key.otherpwd -certfile ${COMBINED_CERT} -out ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.p12.otherpwd

    # Convert file to jks
    keytool -importkeystore -srckeystore ${CERTS_DIR}/${VERTICAL}-core/${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT.p12.otherpwd -srcstoretype pkcs12 -destkeystore ${BUCKET_DIR}/${BUCKET}/api.keystore.jks -srcalias 1 -deststoretype jks -destalias ${VM}-core.${VERTICAL}-core.dlt.res.ibm.com.CLIENT -destkeypass ${KEYSTORE_PASSWORD} -deststorepass ${KEYSTORE_PASSWORD} -srckeypass ${KEYSTORE_PASSWORD} -srcstorepass ${KEYSTORE_PASSWORD}

  done  
  

  ## api.truststore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/api.truststore.jks
  
  [ -z "${MASTER_PASSWORD}" ] && read -sp "Truststore password for ${BUCKET_DIR}/${BUCKET}/api.truststore.jks: " TRUSTSTORE_PASSWORD
  echo
  
  cp ${JAVA_HOME}/jre/lib/security/cacerts ${BUCKET_DIR}/${BUCKET}/api.truststore.jks
  keytool -storepass changeit -storepasswd -keystore ${BUCKET_DIR}/${BUCKET}/api.truststore.jks -new ${TRUSTSTORE_PASSWORD}
  
  for VERTICAL in admin user services ${VM}; do
    keytool -import -alias ${VERTICAL}-core.dlt.res.ibm.com.ca -file ${CERTS_DIR}/${VERTICAL}-core/${VERTICAL}-core.dlt.res.ibm.com.ca.pem -storetype JKS -keystore ${BUCKET_DIR}/${BUCKET}/api.truststore.jks -storepass ${TRUSTSTORE_PASSWORD} -noprompt
  done
  
  

  ## tomcat.keystore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/tomcat.keystore.jks
  
  [ -z "${MASTER_PASSWORD}" ] && read -sp "Keystore password for ${BUCKET_DIR}/${BUCKET}/tomcat.keystore.jks: " KEYSTORE_PASSWORD
  echo
  
  # Update password 
  openssl rsa -des3 -passin pass:${KEYSTORE_PASSWORD} -in ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.key.nopwd -passout pass:${KEYSTORE_PASSWORD} -out ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.key.otherpwd

  # Add certificate and key to pkcs12 file
  COMBINED_CERT=${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.combined.pem
  openssl pkcs12 -passin pass:${KEYSTORE_PASSWORD} -passout pass:${KEYSTORE_PASSWORD} -export -in ${COMBINED_CERT} -inkey ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.key.otherpwd -certfile ${COMBINED_CERT} -out ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.p12.otherpwd

  # Convert file to jks
  keytool -importkeystore -srckeystore ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.p12.otherpwd -srcstoretype pkcs12 -destkeystore ${BUCKET_DIR}/${BUCKET}/tomcat.keystore.jks -srcalias 1 -deststoretype jks -destalias ${VM}-core.dlt.res.ibm.com -destkeypass ${KEYSTORE_PASSWORD} -deststorepass ${KEYSTORE_PASSWORD} -srckeypass ${KEYSTORE_PASSWORD} -srcstorepass ${KEYSTORE_PASSWORD}
  
  

  ## tomcat.truststore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks

  [ -z "${MASTER_PASSWORD}" ] && read -sp "Truststore password for ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks: " TRUSTSTORE_PASSWORD
  echo
  
  cp ${JAVA_HOME}/jre/lib/security/cacerts ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks
  keytool -storepass changeit -storepasswd -keystore ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks -new ${TRUSTSTORE_PASSWORD}
  
  for VERTICAL in admin user services ${VM}; do
    keytool -import -alias ${VERTICAL}-core.dlt.res.ibm.com.ca -file ${CERTS_DIR}/${VERTICAL}-core/${VERTICAL}-core.dlt.res.ibm.com.ca.pem -storetype JKS -keystore ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks -storepass ${TRUSTSTORE_PASSWORD} -noprompt
  done
  keytool -import -alias ${VM}-core.dlt.res.ibm.com.CLIENT.ca -file ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.CLIENT.ca.pem -storetype JKS -keystore ${BUCKET_DIR}/${BUCKET}/tomcat.truststore.jks -storepass ${TRUSTSTORE_PASSWORD} -noprompt
  
done





# echo
# echo "- 3. Generating keycloak.jks used by services-core"
# echo

# Services Core
for VM in services; do
  BUCKET=${VM}-core-conf/certs

  ## keycloak.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/keycloak.jks
  
  [ -z "${MASTER_PASSWORD}" ] && read -sp "Keystore password for ${BUCKET_DIR}/${BUCKET}/keycloak.jks: " KEYSTORE_PASSWORD
  echo

  keytool -import -keystore ${BUCKET_DIR}/${BUCKET}/keycloak.jks -file ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.ca.pem -alias root -storepass ${KEYSTORE_PASSWORD} -noprompt

  # Update password 
  openssl rsa -des3 -passin pass:${KEYSTORE_PASSWORD} -in ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.key.nopwd -passout pass:${KEYSTORE_PASSWORD} -out ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.key.otherpwd

  # Add certificate and key to pkcs12 file
  COMBINED_CERT=${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.combined.pem
  openssl pkcs12 -passin pass:${KEYSTORE_PASSWORD} -passout pass:${KEYSTORE_PASSWORD} -export -in ${COMBINED_CERT} -inkey ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.key.otherpwd -certfile ${COMBINED_CERT} -out ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.p12.otherpwd

  # Convert file to jks
  keytool -importkeystore -srckeystore ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.p12.otherpwd -srcstoretype pkcs12 -destkeystore ${BUCKET_DIR}/${BUCKET}/keycloak.jks -srcalias 1 -deststoretype jks -destalias ${VM}-core.dlt.res.ibm.com -destkeypass ${KEYSTORE_PASSWORD} -deststorepass ${KEYSTORE_PASSWORD} -srckeypass ${KEYSTORE_PASSWORD} -srcstorepass ${KEYSTORE_PASSWORD}
  keytool -import -file ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.ca.pem -keystore ${BUCKET_DIR}/${BUCKET}/keycloak.jks -storetype JKS -storepass ${KEYSTORE_PASSWORD} -noprompt
 

  ## truststore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/truststore.jks
  
  [ -z "${MASTER_PASSWORD}" ] && read -sp "Truststore password for ${BUCKET_DIR}/${BUCKET}/truststore.jks: " TRUSTSTORE_PASSWORD
  echo

  keytool -import -keystore ${BUCKET_DIR}/${BUCKET}/truststore.jks -file ${CERTS_DIR}/${VM}-core/${VM}-core.dlt.res.ibm.com.CLIENT.ca.pem -alias root -storepass ${TRUSTSTORE_PASSWORD} -noprompt
 
done


# Support
for VM in support; do
  BUCKET=${VM}-conf/certs

  ## keystore.p12
  cp ${CERTS_DIR}/${VM}/${VM}.dlt.res.ibm.com.p12 ${BUCKET_DIR}/${BUCKET}/keystore.p12
  
  ## truststore.jks
  rm -f ${BUCKET_DIR}/${BUCKET}/truststore.jks
  
  [ -z "${MASTER_PASSWORD}" ] && read -sp "Truststore password for ${BUCKET_DIR}/${BUCKET}/truststore.jks: " TRUSTSTORE_PASSWORD
  echo

  keytool -import -keystore ${BUCKET_DIR}/${BUCKET}/truststore.jks -file ${CERTS_DIR}/${VM}/${VM}.dlt.res.ibm.com.CLIENT.ca.pem -alias root -storepass ${TRUSTSTORE_PASSWORD} -noprompt
  
done