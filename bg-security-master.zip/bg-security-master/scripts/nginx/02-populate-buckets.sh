#!/bin/bash

set -e

CUR_DIR=`pwd`

OUTPUT_DIR=${CUR_DIR}/output
BUCKET_DIR=${OUTPUT_DIR}/buckets
BG_NETWORK_FOR_PILOT=${DEV_ROOT}/bg-network/setups/uat


## Populate -setup buckets
echo
echo "1. Populating -setup buckets (used by Portals) "
echo

for VERTICAL in services; do
  BUCKET=${VERTICAL}-setup
  mkdir -p ${BUCKET_DIR}/${BUCKET} 2>/dev/null || true
  rm -rf ${BUCKET_DIR}/${BUCKET}/*

  echo 
  echo " - Populating ${BUCKET}..."
  touch ${BUCKET_DIR}/${BUCKET}/.env
  touch ${BUCKET_DIR}/${BUCKET}/.pedigree
  cp -f ${BG_NETWORK_FOR_PILOT}/../env-setup.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/stop.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/update.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -rf ${BG_NETWORK_FOR_PILOT}/type1/keycloak/templates ${BUCKET_DIR}/${BUCKET}/.  
done

for VERTICAL in admin user michelangelo raffaello donatello leonardo; do
  BUCKET=${VERTICAL}-setup
  mkdir -p ${BUCKET_DIR}/${BUCKET} 2>/dev/null || true
  rm -rf ${BUCKET_DIR}/${BUCKET}/*

  echo 
  echo " - Populating ${BUCKET}..."
  touch ${BUCKET_DIR}/${BUCKET}/.env
  touch ${BUCKET_DIR}/${BUCKET}/.pedigree
  cp -f ${BG_NETWORK_FOR_PILOT}/../env-setup.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/stop.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/update.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -rf ${BG_NETWORK_FOR_PILOT}/type1/portal/templates ${BUCKET_DIR}/${BUCKET}/.
done


## Populate -core-setup
echo
echo "2. Populating -core-setup buckets (used by Middleware) "
echo

for VERTICAL in admin user; do
  BUCKET=${VERTICAL}-core-setup
  mkdir -p ${BUCKET_DIR}/${BUCKET} 2>/dev/null || true
  rm -rf ${BUCKET_DIR}/${BUCKET}/*

  echo 
  echo " - Populating ${BUCKET}..."
  touch ${BUCKET_DIR}/${BUCKET}/.env
  touch ${BUCKET_DIR}/${BUCKET}/.pedigree
  cp -f ${BG_NETWORK_FOR_PILOT}/../env-setup.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/stop.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/update.sh ${BUCKET_DIR}/${BUCKET}/.
  
  cp -rf ${BG_NETWORK_FOR_PILOT}/type2/${VERTICAL}/templates ${BUCKET_DIR}/${BUCKET}/.
done

for VERTICAL in michelangelo raffaello donatello leonardo; do
  BUCKET=${VERTICAL}-core-setup
  mkdir -p ${BUCKET_DIR}/${BUCKET} 2>/dev/null || true
  rm -rf ${BUCKET_DIR}/${BUCKET}/*

  echo 
  echo " - Populating ${BUCKET}..."
  touch ${BUCKET_DIR}/${BUCKET}/.env
  touch ${BUCKET_DIR}/${BUCKET}/.pedigree
  cp -f ${BG_NETWORK_FOR_PILOT}/../env-setup.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/stop.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/update.sh ${BUCKET_DIR}/${BUCKET}/.
  
  cp -rf ${BG_NETWORK_FOR_PILOT}/type2/issuer/templates ${BUCKET_DIR}/${BUCKET}/.
done

for VERTICAL in services; do
  BUCKET=${VERTICAL}-core-setup
  mkdir -p ${BUCKET_DIR}/${BUCKET} 2>/dev/null || true
  rm -rf ${BUCKET_DIR}/${BUCKET}/*

  echo 
  echo " - Populating ${BUCKET}..."
  touch ${BUCKET_DIR}/${BUCKET}/.env
  touch ${BUCKET_DIR}/${BUCKET}/.pedigree
  cp -f ${BG_NETWORK_FOR_PILOT}/../env-setup.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/stop.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/update.sh ${BUCKET_DIR}/${BUCKET}/.
  
  cp -rf ${BG_NETWORK_FOR_PILOT}/type2/keycloak/templates ${BUCKET_DIR}/${BUCKET}/.
done

for VERTICAL in support; do
  BUCKET=${VERTICAL}-core-setup
  mkdir -p ${BUCKET_DIR}/${BUCKET} 2>/dev/null || true
  rm -rf ${BUCKET_DIR}/${BUCKET}/*

  echo 
  echo " - Populating ${BUCKET}..."
  touch ${BUCKET_DIR}/${BUCKET}/.env
  touch ${BUCKET_DIR}/${BUCKET}/.pedigree
  cp -f ${BG_NETWORK_FOR_PILOT}/../env-setup.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/stop.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/update.sh ${BUCKET_DIR}/${BUCKET}/.
  
  cp -rf ${BG_NETWORK_FOR_PILOT}/type2/jira/templates ${BUCKET_DIR}/${BUCKET}/.
done

## Populate -conf buckets (data)
echo
echo "3. Populating -conf buckets (used by Portals) "
echo

for VERTICAL in services; do
  BUCKET=${VERTICAL}-conf
  cp -rf ${BG_NETWORK_FOR_PILOT}/type1/keycloak/data/jira.template ${BUCKET_DIR}/${BUCKET}/.
done


## Populate core-conf bucket (data)
echo
echo "4. Populating -core-conf buckets (used by Middleware) "
echo

for VERTICAL in admin; do
  BUCKET=${VERTICAL}-core-conf
  mkdir -p ${BUCKET_DIR}/${BUCKET} 2>/dev/null || true
  
  echo 
  echo " - Populating ${BUCKET}..."
  touch ${BUCKET_DIR}/${BUCKET}/.env
  touch ${BUCKET_DIR}/${BUCKET}/.pedigree
  cp -f ${BG_NETWORK_FOR_PILOT}/../env-setup.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/stop.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/update.sh ${BUCKET_DIR}/${BUCKET}/.
  
  # Copying folders and their contents
  for FOLDER in document-store ibp migration profiles purpose-format templates terms-and-conditions; do
    mkdir -p ${BUCKET_DIR}/${BUCKET}/${FOLDER}
    if [ ! -z "$(ls -A ${BG_NETWORK_FOR_PILOT}/type2/${VERTICAL}/data/conf/${FOLDER})" ]; then
      cp -rf ${BG_NETWORK_FOR_PILOT}/type2/${VERTICAL}/data/conf/${FOLDER}/* ${BUCKET_DIR}/${BUCKET}/${FOLDER}/.
    fi
  done
  
  # Copying api.properties, service-api.properties, templates.manifest and whitelist.json
  cp ${BG_NETWORK_FOR_PILOT}/type2/${VERTICAL}/data/conf/*.* ${BUCKET_DIR}/${BUCKET}/.
done

for VERTICAL in user; do
  BUCKET=${VERTICAL}-core-conf
  mkdir -p ${BUCKET_DIR}/${BUCKET} 2>/dev/null || true
  
  echo 
  echo " - Populating ${BUCKET}..."
  touch ${BUCKET_DIR}/${BUCKET}/.env
  touch ${BUCKET_DIR}/${BUCKET}/.pedigree
  cp -f ${BG_NETWORK_FOR_PILOT}/../env-setup.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/stop.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/update.sh ${BUCKET_DIR}/${BUCKET}/.
  
  # Copying folders and their contents
  for FOLDER in ibp migration profiles purpose-format templates; do
    mkdir -p ${BUCKET_DIR}/${BUCKET}/${FOLDER}
    if [ ! -z "$(ls -A ${BG_NETWORK_FOR_PILOT}/type2/${VERTICAL}/data/conf/${FOLDER})" ]; then
      cp -rf ${BG_NETWORK_FOR_PILOT}/type2/${VERTICAL}/data/conf/${FOLDER}/* ${BUCKET_DIR}/${BUCKET}/${FOLDER}/.
    fi
  done
  
  # Copying api.properties, service-api.properties, templates.manifest
  cp ${BG_NETWORK_FOR_PILOT}/type2/${VERTICAL}/data/conf/*.* ${BUCKET_DIR}/${BUCKET}/.
done

for VERTICAL in michelangelo raffaello donatello leonardo; do
  BUCKET=${VERTICAL}-core-conf
  mkdir -p ${BUCKET_DIR}/${BUCKET} 2>/dev/null || true
  
  echo 
  echo " - Populating ${BUCKET}..."
  touch ${BUCKET_DIR}/${BUCKET}/.env
  touch ${BUCKET_DIR}/${BUCKET}/.pedigree
  cp -f ${BG_NETWORK_FOR_PILOT}/../env-setup.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/stop.sh ${BUCKET_DIR}/${BUCKET}/.
  cp -f ${BG_NETWORK_FOR_PILOT}/update.sh ${BUCKET_DIR}/${BUCKET}/.
  
  # Copying folders and their contents
  for FOLDER in migration purpose-format templates; do
    mkdir -p ${BUCKET_DIR}/${BUCKET}/${FOLDER}
    if [ ! -z "$(ls -A ${BG_NETWORK_FOR_PILOT}/type2/issuer/data/conf/${FOLDER})" ]; then
      cp -rf ${BG_NETWORK_FOR_PILOT}/type2/issuer/data/conf/${FOLDER}/* ${BUCKET_DIR}/${BUCKET}/${FOLDER}/.
    fi
  done
  
  # Copying ibp folder and relevant file
  mkdir -p ${BUCKET_DIR}/${BUCKET}/ibp
  cp -rf ${BG_NETWORK_FOR_PILOT}/type2/issuer/data/conf/ibp/${VERTICAL}* ${BUCKET_DIR}/${BUCKET}/ibp/ibp-channel-mapping.properties
  
   # Copying profiles folder and relevant file
   # 
   mkdir -p ${BUCKET_DIR}/${BUCKET}/profiles
   cp -rf ${BG_NETWORK_FOR_PILOT}/type2/issuer/data/conf/profiles/${VERTICAL}* ${BUCKET_DIR}/${BUCKET}/profiles/bootstrap-profiles.json
  
  # Copying api.properties, service-api.properties, templates.manifest
  cp ${BG_NETWORK_FOR_PILOT}/type2/issuer/data/conf/*.* ${BUCKET_DIR}/${BUCKET}/.
done
