#!/bin/bash

# This script establishes a ssh connection with the jumpbox so that the 
# Cloudant database can be accessed from this machine.
# You need to update your proxy settings after establishing this 
# in order to access cloudant connection.

ssh -D 1981 -f -C -q -N prjlygon@jumpbox.dlt.res.ibm.com