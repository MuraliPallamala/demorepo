#!/bin/bash

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This scripts creates the IBP network for the project
# via the API using curl.
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

set -e
set -x

TESTISSUER_GX_PREFIX=${TESTISSUER_GX_PREFIX:-000000}
ANZ_GX_PREFIX=${ANX_GX_PREFIX:-000001}
COMMBANK_GX_PREFIX=${COMMBANK_GX_PREFIX:-000002}
WESTPAC_GX_PREFIX=${WESTPAC_GX_PREFIX:-000003}

SUFFIX=${SUFFIX:-l1b}

TESTISSUER_CHANNEL=${TESTISSUER_CHANNEL:-testissuer-channel-${SUFFIX}}
ANZ_CHANNEL=${ANZ_CHANNEL:-anz-channel-${SUFFIX}}
COMMBANK_CHANNEL=${COMMBANK_CHANNEL:-commbank-channel-${SUFFIX}}
WESTPAC_CHANNEL=${WESTPAC_CHANNEL:-westpac-channel-${SUFFIX}}
PLATFORM_CHANNEL=${PLATFORM_CHANNEL:-platform-channel-${SUFFIX}}

USAGE="Usage: $0 --all | --ibp-url <ibp-url without protocol and port> | --network-id <network-id> | --newco-credentials <user:secret> | --anz-credentials <user:secret> | --commbank-credentials <user:secret> | --testissuer-credentials <user:secret> | --westpac-credentials <user:secret> | --skip-sending-invites | --skip-adding-peers | --skip-creating-channels | --skip-joining-peers-into-channels | --skip-installing-chaincode | --skip-instantiating-chaincode | --skip-confirmation"

if [ "$#" -lt 1 ]; then
  echo "$USAGE" >&2
  exit 1
fi


#
# Parsing input
#
POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    --skip-confirmation)
    SKIP_CONFIRMATION='Y'
	  shift # past argument
	  ;;    
	  --skip-sending-invites)
    SKIP_SENDING_INVITES='Y'
	  shift # past argument
	  ;;
    --skip-adding-peers)
    SKIP_ADDING_PEERS='Y'
    shift # past argument
    ;;
    --skip-creating-channels)
    SKIP_CREATING_CHANNELS='Y'
    shift # past argument
    ;;
    --skip-joining-peers-into-channels)
    SKIP_JOINING_PEERS_INTO_CHANNELS='Y'
    shift # past argument
    ;;
    --skip-installing-chaincode)
    SKIP_INSTALLING_CHAINCODE='Y'
    shift # past argument
    ;;
    --skip-instantiating-chaincode)
    SKIP_INSTANTIATING_CHAINCODE='Y'
    shift # past argument
    ;;
    --ibp-url)
    IBP_URL="$2"
    shift # past argument
    shift
    ;;
    --network-id)
    NETWORK_ID="$2"
    shift # past argument
    shift
    ;;
    --newco-credentials)
    NEWCO_CREDENTIALS="$2"
    shift # past argument
    shift
    ;;
    --anz-credentials)
    ANZ_CREDENTIALS="$2"
    shift # past argument
    shift
    ;;
    --commbank-credentials)
    COMMBANK_CREDENTIALS="$2"
    shift # past argument
    shift
    ;;
    --testissuer-credentials)
    TESTISSUER_CREDENTIALS="$2"
    shift # past argument
    shift
    ;;
    --westpac-credentials)
    WESTPAC_CREDENTIALS="$2"
    shift # past argument
    shift
    ;;
    --all)
    shift # past argument
    ;;
    *)    # unknown option
     echo "$USAGE" >&2
    exit 1
#    POSITIONAL+=("$1") # save it in an array for later
#    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters





if [ -z "${IBP_URL}" ]; then
  IBP_URL=ibp-mel.4.secure.blockchain.ibm.com
fi

if [ -z "${NETWORK_ID}" ]; then
  echo
  echo; read -r -p '# Enter the network id: ' NETWORK_ID
  echo
fi

if [ -z "${NEWCO_CREDENTIALS}" ]; then
  echo; read -r -p '# Enter username and secret for newco org (username:secret): ' NEWCO_CREDENTIALS
fi
NEWCO_ENDPOINT=https://${NEWCO_CREDENTIALS}@${IBP_URL}





if [ "$SKIP_SENDING_INVITES" != 'Y' ]; then
  
  echo 
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo "# Sending invites to members                                          #"
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo 
  
  API_ENDPOINT="networks/${NETWORK_ID}/invite"

  echo; read -r -p '# Enter operator email for testissuer: ' TESTISSUER_OPERATOR
  echo "# Inviting testissuer with operator ${TESTISSUER_OPERATOR}"
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"invites\": [ { \"email\": \"${TESTISSUER_OPERATOR}\", \"company_name\": \"testissuer\" } ]}"
  echo;

  echo; read -r -p '# Enter operator email for anz: ' ANZ_OPERATOR
  echo "# Inviting anz with operator ${ANZ_OPERATOR}"
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"invites\": [ { \"email\": \"${ANZ_OPERATOR}\", \"company_name\": \"anz\" } ]}"
  echo;

  echo; read -r -p '# Enter operator email for commbank: ' COMMBANK_OPERATOR
  echo "# Inviting commbank with operator ${COMMBANK_OPERATOR}"
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"invites\": [ { \"email\": \"${COMMBANK_OPERATOR}\", \"company_name\": \"commbank\" } ]}"
  echo;

  echo; read -r -p '# Enter operator email for westpac: ' WESTPAC_OPERATOR
  echo "# Inviting westpac with operator ${WESTPAC_OPERATOR}"
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"invites\": [ { \"email\": \"${WESTPAC_OPERATOR}\", \"company_name\": \"westpac\" } ]}"
  echo;
  
  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
  # Waiting for members to join
  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
  key=''
  while [[ "${key}" != "continue" ]]; do
    echo; read -r -p '# [MANUAL STEP] Wait for members to join. Once it is done,  type "continue" to proceed: ' key
  done
  
  echo;
fi




if [ -z "${TESTISSUER_CREDENTIALS}" ]; then
  echo; read -r -p '# Enter username and secret for testissuer org (username:secret): ' TESTISSUER_CREDENTIALS
fi
TESTISSUER_ENDPOINT=https://${TESTISSUER_CREDENTIALS}@${IBP_URL}

if [ -z "${ANZ_CREDENTIALS}" ]; then
  echo; read -r -p '# Enter username and secret for anz org (username:secret): ' ANZ_CREDENTIALS
fi
ANZ_ENDPOINT=https://${ANZ_CREDENTIALS}@${IBP_URL}

if [ -z "${COMMBANK_CREDENTIALS}" ]; then
  echo; read -r -p '# Enter username and secret for commbank org (username:secret): ' COMMBANK_CREDENTIALS
fi
COMMBANK_ENDPOINT=https://${COMMBANK_CREDENTIALS}@${IBP_URL}

if [ -z "${WESTPAC_CREDENTIALS}" ]; then
  echo; read -r -p '# Enter username and secret for westpac org (username:secret): ' WESTPAC_CREDENTIALS
fi
WESTPAC_ENDPOINT=https://${WESTPAC_CREDENTIALS}@${IBP_URL}





if [ "$SKIP_ADDING_PEERS" != 'Y' ]; then
  
  echo 
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo "# Adding peers                                                        #"
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo 

  API_ENDPOINT="networks/${NETWORK_ID}/peer"

  # Add additional peers to the newco org
  echo '# Adding 5 peers to newco. '
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  curl -X POST "${NEWCO_ENDPOINT}/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"num_peers\": 5}"

  # Add peer to testissuer org
  echo '# Adding a peer to testissuer. '
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  curl -X POST "${TESTISSUER_ENDPOINT}/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"num_peers\": 1}"
  
  # Add peer to anz org
  echo '# Adding a peer to anz. '
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  curl -X POST "${ANZ_ENDPOINT}/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"num_peers\": 1}"

  # Add peer to commbank org
  echo '# Adding a peer to commbank. '
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  curl -X POST "${COMMBANK_ENDPOINT}/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"num_peers\": 1}" 

  # Add peer to westpac org
  echo '# Adding a peer to westpac. '
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  curl -X POST "${WESTPAC_ENDPOINT}/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"num_peers\": 1}"

fi





if [ "$SKIP_CREATING_CHANNELS" != 'Y' ]; then
  
  echo 
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo "# Creating channels                                                   #"
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo 

  echo; echo "# Creating ${PLATFORM_CHANNEL}."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${PLATFORM_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/create"
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"channel_req\": { \"channel_description\": \"Channel for organisation profiles and terms conditions\", \"members\": { \"PeerOrg1\": { \"roles\": [ \"admin\", \"editor\", \"viewer\" ] }, \"PeerOrg2\": { \"roles\": [ \"editor\", \"viewer\" ] }, \"PeerOrg3\": { \"roles\": [ \"editor\", \"viewer\" ] }, \"PeerOrg4\": { \"roles\": [ \"editor\", \"viewer\" ] }, \"PeerOrg5\": { \"roles\": [ \"editor\", \"viewer\" ] } }, \"updatePolicy\": { \"n_out_of\": 1, \"implicit_policy\": \"ANY\" } }}"

  echo; echo "# Creating ${TESTISSUER_CHANNEL}."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${TESTISSUER_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/create"
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"channel_req\": { \"channel_description\": \"Channel for bank guarantees for testissuer\", \"members\": { \"PeerOrg1\": { \"roles\": [ \"admin\", \"editor\", \"viewer\" ] }, \"PeerOrg2\": { \"roles\": [ \"admin\", \"editor\", \"viewer\" ] } }, \"updatePolicy\": { \"n_out_of\": 2, \"implicit_policy\": \"ALL\" } }}"

  echo; echo "# Creating ${ANZ_CHANNEL}."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${ANZ_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/create"
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"channel_req\": { \"channel_description\": \"Channel for bank guarantees for anz\", \"members\": { \"PeerOrg1\": { \"roles\": [ \"admin\", \"editor\", \"viewer\" ] }, \"PeerOrg3\": { \"roles\": [ \"admin\", \"editor\", \"viewer\" ] } }, \"updatePolicy\": { \"n_out_of\": 2, \"implicit_policy\": \"ALL\" } }}"

  echo; echo "# Creating ${COMMBANK_CHANNEL}."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${COMMBANK_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/create"
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"channel_req\": { \"channel_description\": \"Channel for bank guarantees for commbank\", \"members\": { \"PeerOrg1\": { \"roles\": [ \"admin\", \"editor\", \"viewer\" ] }, \"PeerOrg4\": { \"roles\": [ \"admin\", \"editor\", \"viewer\" ] } }, \"updatePolicy\": { \"n_out_of\": 2, \"implicit_policy\": \"ALL\" } }}"

  echo; echo "# Creating ${WESTPAC_CHANNEL}."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${WESTPAC_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/create"
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"channel_req\": { \"channel_description\": \"Channel for bank guarantees for westpac\", \"members\": { \"PeerOrg1\": { \"roles\": [ \"admin\", \"editor\", \"viewer\" ] }, \"PeerOrg5\": { \"roles\": [ \"admin\", \"editor\", \"viewer\" ] } }, \"updatePolicy\": { \"n_out_of\": 2, \"implicit_policy\": \"ALL\" } }}"

  key=''
  while [[ "${key}" != "continue" ]]; do
    echo; read -r -p '# [MANUAL STEP] Update "Advanced channel configuration" of each channel by setting the "Maximum message count" field to 1. Once it is done,  type "continue" to proceed: ' key
  done
fi





if [ "$SKIP_JOINING_PEERS_INTO_CHANNELS" != 'Y' ]; then

  echo 
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo "# Joining peers into channels                                         #"
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo 

  echo; echo "# Peers in the issuers orgs being joined to the ${PLATFORM_CHANNEL}. "; 
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${PLATFORM_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/join"
  for IBP_ENDPOINT in ${NEWCO_ENDPOINT} ${ANZ_ENDPOINT} ${COMMBANK_ENDPOINT} ${TESTISSUER_ENDPOINT} ${WESTPAC_ENDPOINT}; do
  curl -X POST "${IBP_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json"
  done

  echo; echo "# Peer in the testissuer org being joined to the ${TESTISSUER_CHANNEL}. "
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${TESTISSUER_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/join"
  for IBP_ENDPOINT in ${TESTISSUER_ENDPOINT}; do
  curl -X POST "${IBP_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json"
  done
  
  echo; echo "# Peer in the anz org being joined to the ${ANZ_CHANNEL}. "
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${ANZ_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/join"
  for IBP_ENDPOINT in ${ANZ_ENDPOINT}; do
  curl -X POST "${IBP_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json"
  done

  echo; echo "# Peer in the commbank org being joined to the ${COMMBANK_CHANNEL}. "
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${COMMBANK_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/join"
  for IBP_ENDPOINT in ${COMMBANK_ENDPOINT}; do
  curl -X POST "${IBP_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json"
  done

  echo; echo "# Peer in the westpac org being joined to the ${WESTPAC_CHANNEL}."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue...' key
  CHANNEL_ID="${WESTPAC_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/join"
  for IBP_ENDPOINT in ${WESTPAC_ENDPOINT}; do
  curl -X POST "${IBP_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json"
  done
  
  key=''
  while [[ "${key}" != "continue" ]]; do
    echo;
    echo "# The join channel endpoint on IBP API when invoked currently joins all peers of an organisation to a channel."
    echo "# We do not want this to happen for newco."
    read -r -p '# [MANUAL STEP] So, for NEWCO, this step will need to be performed MANUALLY. Once it is done,  type "continue" to proceed: ' key
  done
  echo

fi





if [ "$SKIP_INSTALLING_CHAINCODE" != 'Y' ]; then
  
  echo 
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo "# Installing chaincode.                                               #"
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo 

  echo; read -r -p '# Enter the name of the profile chaincode to be installed: ' PROFILE_CHAINCODE_NAME  
  echo; read -r -p '# Enter the version of the profile chaincode to be installed: ' PROFILE_CHAINCODE_VERSION
  echo; read -r -p '# Enter the path of the profile chaincode to be installed: ' PROFILE_CHAINCODE_PATH

  echo; read -r -p '# Enter the name of the guarantee chaincode to be installed: ' GUARANTEE_CHAINCODE_NAME
  echo; read -r -p '# Enter the version of the guarantee chaincode to be installed: ' GUARANTEE_CHAINCODE_VERSION
  echo; read -r -p '# Enter the path of the guarantee chaincode to be installed: ' GUARANTEE_CHAINCODE_PATH





  ## Installing profile chaincode
  API_ENDPOINT="networks/${NETWORK_ID}/chaincode/install"

  echo '# Installing profile chaincode in all peers from all orgs.'
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue... ' key
  for IBP_ENDPOINT in ${NEWCO_ENDPOINT} ${TESTISSUER_ENDPOINT} ${ANZ_ENDPOINT} ${COMMBANK_ENDPOINT} ${WESTPAC_ENDPOINT}; do
    curl -X POST "${IBP_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: multipart/form-data" -F "files=@${PROFILE_CHAINCODE_PATH};type=application/zip" -F "chaincode_id=${PROFILE_CHAINCODE_NAME}" -F "chaincode_version=${PROFILE_CHAINCODE_VERSION}" -F "chaincode_type=golang"
  done
  

  echo '# Installing guarantee chaincode in all peers from all issuer orgs.'
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue... ' key
  for IBP_ENDPOINT in ${TESTISSUER_ENDPOINT} ${ANZ_ENDPOINT} ${COMMBANK_ENDPOINT} ${WESTPAC_ENDPOINT}; do
  curl -X POST "${IBP_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: multipart/form-data" -F "files=@${GUARANTEE_CHAINCODE_PATH};type=application/zip" -F "chaincode_id=${GUARANTEE_CHAINCODE_NAME}" -F "chaincode_version=${GUARANTEE_CHAINCODE_VERSION}" -F "chaincode_type=golang"
  done

  key=''
  while [[ "${key}" != "continue" ]]; do
    echo;
    echo "# Manually install the guarantee chaincode to all the peers on newco side except for the peer joined to only the platform channel."
    read -r -p '# [MANUAL STEP] So, for NEWCO, this step will need to be performed MANUALLY. Once it is done,  type "continue" to proceed: ' key
  done
  echo

fi


if [ "$SKIP_INSTANTIATING_CHAINCODE" != 'Y' ]; then

  if [ -z $PROFILE_CHAINCODE_NAME ]; then
    echo; read -r -p '# Enter the name of the profile chaincode to be installed: ' PROFILE_CHAINCODE_NAME 
  fi
  
  if [ -z $PROFILE_CHAINCODE_VERSION ]; then
    echo; read -r -p '# Enter the version of the profile chaincode to be installed: ' PROFILE_CHAINCODE_VERSION
  fi
  
  if [ -z $GUARANTEE_CHAINCODE_NAME ]; then
    echo; read -r -p '# Enter the name of the guarantee chaincode to be installed: ' GUARANTEE_CHAINCODE_NAME
  fi
  
  if [ -z $GUARANTEE_CHAINCODE_VERSION ]; then
    echo; read -r -p '# Enter the version of the guarantee chaincode to be installed: ' GUARANTEE_CHAINCODE_VERSION
  fi

   

  echo 
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo "# Instantiating chaincodes.                                           #"
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
  echo 

  # 
  # Instantiate chaincode on a channel
  ## Instantiating profile chaincode on platform-channel
  CHANNEL_ID="${PLATFORM_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/chaincode/instantiate"
  echo "# Instantiating profile chaincode on ${PLATFORM_CHANNEL} from newco org."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue... ' key
  curl -X POST "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"chaincode_id\": \"${PROFILE_CHAINCODE_NAME}\", \"chaincode_version\": \"${PROFILE_CHAINCODE_VERSION}\", \"chaincode_type\": \"golang\", \"chaincode_arguments\": [ \"{\\\"newcoMspId\\\":\\\"PeerOrg1\\\"}\" ], \"endorsement_policy\": { \"identities\": [ { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg5\" } }, { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg4\" } }, { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg3\" } }, { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg2\" } }, { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg1\" } } ], \"policy\": { \"1-of\": [ { \"signed-by\": 4 } ] } }}"

  CHANNEL_ID="${TESTISSUER_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/chaincode/instantiate"
  echo "# Instantiating guarantee chaincode on ${TESTISSUER_CHANNEL} from newco org."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue... ' key
  curl -X POST "${TESTISSUER_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"chaincode_id\": \"${GUARANTEE_CHAINCODE_NAME}\", \"chaincode_version\": \"${GUARANTEE_CHAINCODE_VERSION}\", \"chaincode_type\": \"golang\", \"chaincode_arguments\": [ \"{\\\"prefix\\\":\\\"${TESTISSUER_GX_PREFIX}\\\",\\\"platformChannelId\\\":\\\"${PLATFORM_CHANNEL}\\\",\\\"profileCc\\\":\\\"${PROFILE_CHAINCODE_NAME}\\\",\\\"newcoMspId\\\":\\\"PeerOrg1\\\",\\\"migrate\\\":false}\"], \"endorsement_policy\": { \"identities\": [ { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg2\" } }, { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg1\" } } ], \"policy\": { \"2-of\": [ { \"signed-by\": 0 }, { \"signed-by\": 1 } ] } }}"

  CHANNEL_ID="${ANZ_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/chaincode/instantiate"
  echo "# Instantiating guarantee chaincode on ${ANZ_CHANNEL} from newco org."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue... ' key
  curl -X POST "${ANZ_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"chaincode_id\": \"${GUARANTEE_CHAINCODE_NAME}\", \"chaincode_version\": \"${GUARANTEE_CHAINCODE_VERSION}\", \"chaincode_type\": \"golang\", \"chaincode_arguments\": [ \"{\\\"prefix\\\":\\\"${ANZ_GX_PREFIX}\\\",\\\"platformChannelId\\\":\\\"${PLATFORM_CHANNEL}\\\",\\\"profileCc\\\":\\\"${PROFILE_CHAINCODE_NAME}\\\",\\\"newcoMspId\\\":\\\"PeerOrg1\\\",\\\"migrate\\\":false}\" ], \"endorsement_policy\": { \"identities\": [ { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg3\" } }, { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg1\" } } ], \"policy\": { \"2-of\": [ { \"signed-by\": 0 }, { \"signed-by\": 1 } ] } }}"

  CHANNEL_ID="${COMMBANK_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/chaincode/instantiate"
  echo "# Instantiating guarantee chaincode on ${COMMBANK_CHANNEL} from newco org."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue... ' key
  curl -X POST "${COMMBANK_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"chaincode_id\": \"${GUARANTEE_CHAINCODE_NAME}\", \"chaincode_version\": \"${GUARANTEE_CHAINCODE_VERSION}\", \"chaincode_type\": \"golang\", \"chaincode_arguments\": [ \"{\\\"prefix\\\":\\\"${COMMBANK_GX_PREFIX}\\\",\\\"platformChannelId\\\":\\\"${PLATFORM_CHANNEL}\\\",\\\"profileCc\\\":\\\"${PROFILE_CHAINCODE_NAME}\\\",\\\"newcoMspId\\\":\\\"PeerOrg1\\\",\\\"migrate\\\":false}\" ], \"endorsement_policy\": { \"identities\": [ { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg4\" } }, { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg1\" } } ], \"policy\": { \"2-of\": [ { \"signed-by\": 0 }, { \"signed-by\": 1 } ] } }}"

  CHANNEL_ID="${WESTPAC_CHANNEL}"
  API_ENDPOINT="networks/${NETWORK_ID}/channels/${CHANNEL_ID}/chaincode/instantiate"
  echo "# Instantiating guarantee chaincode on ${WESTPAC_CHANNEL} from newco org."
  [[ -z "${SKIP_CONFIRMATION}" ]] && read -n1 -r -p 'Press enter to continue... ' key
  curl -X POST "${WESTPAC_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"chaincode_id\": \"${GUARANTEE_CHAINCODE_NAME}\", \"chaincode_version\": \"${GUARANTEE_CHAINCODE_VERSION}\", \"chaincode_type\": \"golang\", \"chaincode_arguments\": [ \"{\\\"prefix\\\":\\\"${WESTPAC_GX_PREFIX}\\\",\\\"platformChannelId\\\":\\\"${PLATFORM_CHANNEL}\\\",\\\"profileCc\\\":\\\"${PROFILE_CHAINCODE_NAME}\\\",\\\"newcoMspId\\\":\\\"PeerOrg1\\\",\\\"migrate\\\":false}\" ], \"endorsement_policy\": { \"identities\": [ { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg5\" } }, { \"role\": { \"name\": \"member\", \"mspId\": \"PeerOrg1\" } } ], \"policy\": { \"2-of\": [ { \"signed-by\": 0 }, { \"signed-by\": 1 } ] } }}"

fi



echo 
echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
echo "# Downloading config files.                                           #"
echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #"
echo

ORG=newco
echo "# Saving ${ORG} connection profile to ${ORG}.connection_profile.json"
API_ENDPOINT=networks/${NETWORK_ID}/connection_profile
curl -X GET "${NEWCO_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H  "accept: application/json" | jq > ${ORG}-connection-profile.json

ORG=anz
echo "# Saving ${ORG} connection profile to ${ORG}.connection_profile.json"
API_ENDPOINT=networks/${NETWORK_ID}/connection_profile
curl -X GET "${ANZ_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H  "accept: application/json" | jq > ${ORG}-connection-profile.json

ORG=commbank
echo "# Saving ${ORG} connection profile to ${ORG}.connection_profile.json"
API_ENDPOINT=networks/${NETWORK_ID}/connection_profile
curl -X GET "${COMMBANK_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H  "accept: application/json" | jq > ${ORG}-connection-profile.json

ORG=testissuer
echo "# Saving ${ORG} connection profile to ${ORG}.connection_profile.json"
API_ENDPOINT=networks/${NETWORK_ID}/connection_profile
curl -X GET "${TESTISSUER_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H  "accept: application/json" | jq > ${ORG}-connection-profile.json

ORG=westpac
echo "# Saving ${ORG} connection profile to ${ORG}.connection_profile.json"
API_ENDPOINT=networks/${NETWORK_ID}/connection_profile
curl -X GET "${WESTPAC_ENDPOINT}:443/api/v1/${API_ENDPOINT}" -H  "accept: application/json" | jq > ${ORG}-connection-profile.json

