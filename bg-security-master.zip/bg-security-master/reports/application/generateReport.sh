#!/usr/bin/env bash
#
# Generates an IRX file using IBM appscan.
# Requirement: appscan.sh
#
# 
# Author: Bruno Marques - brunomar@au1.ibm.com
#

# Exit when a command fails
set -o errexit

echo "Logging in using key id '${APPSCAN_KEY_ID}'"
appscan.sh api_login -P ${APPSCAN_KEY_SECRET} -u ${APPSCAN_KEY_ID} -persist

# Clone bg-api
cd bg-api
appscan.sh prepare

# Clone bg-portal
cd bg-portal
appscan.sh prepare

# Upload IRX files to AppScan website


