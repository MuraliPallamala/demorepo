# Package: `@std/esm 0.25.5`
**Package Path:** `node_modules/@std/esm`

## File: `LICENSE`
**Path:** `node_modules/@std/esm/LICENSE`  
**Hash:** `24b3e8364c5b76877fce4f89a22e304a`  
**Legal File:** YES  
**License Types Detected**: MIT, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin MIT>

The MIT License (MIT)

<End MIT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright @std/esm contributors

<End COPYRIGHT>

<Begin unknown text>

Based on reify, copyright Ben Newman <

<End unknown text>

<Begin ACCEPTABLE>

https://github.com/benjamn/reify

<End ACCEPTABLE>

<Begin ACCEPTABLE>

>

<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

<End MIT>
```

# Package: `chrome-trace-event 1.0.0`
**Package Path:** `node_modules/chrome-trace-event`

## File: `LICENSE.txt`
**Path:** `node_modules/chrome-trace-event/LICENSE.txt`  
**Hash:** `8020c8e8de67f42b83d8fbbb5a8ec85c`  
**Legal File:** YES  
**License Types Detected**: MIT, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin unknown text>

# This is

<End unknown text>

<Begin MIT>

the MIT license

<End MIT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright (c) 2015 Joyent Inc. All rights reserved.

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>
```

# Package: `common-tags 1.8.0`
**Package Path:** `node_modules/common-tags`

## File: `license.md`
**Path:** `node_modules/common-tags/license.md`  
**Hash:** `c5d59ef27a58aabec6ae0c037024d093`  
**Legal File:** YES  
**License Types Detected**: KEYWORD, MIT  
**Contains Keywords:** YES  

**File Text:**
```
<Begin KEYWORD>

License

<End KEYWORD>

<Begin ACCEPTABLE>

(

<End ACCEPTABLE>

<Begin MIT>

MIT)

<End MIT>

<Begin ACCEPTABLE>

-------------

<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright © Declan de Wet

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>
```

# Package: `file-saver 2.0.0`
**Package Path:** `node_modules/file-saver`

## File: `LICENSE.md`
**Path:** `node_modules/file-saver/LICENSE.md`  
**Hash:** `c0717aa4fcf2b4b54987659b19c135d2`  
**Legal File:** YES  
**License Types Detected**: MIT, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin MIT>

The MIT License

<End MIT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright © 2016 [Eli Grey][1].

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>

<Begin unknown text>

[1]:

<End unknown text>

<Begin ACCEPTABLE>

http://eligrey.com

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>
```

# Package: `flow-bin 0.76.0`
**Package Path:** `node_modules/flow-bin`

## File: `license`
**Path:** `node_modules/flow-bin/license`  
**Hash:** `16a2ef08e8b9362611637572059abb54`  
**Legal File:** YES  
**License Types Detected**: MIT, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin MIT>

MIT License

<End MIT>

<Begin unknown text>

For flow-bin software

<End unknown text>

<Begin COPYRIGHT>

Copyright (c) 2015-present, Facebook, Inc.

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

<End MIT>
```

# Package: `http-parser-js 0.5.0`
**Package Path:** `node_modules/http-parser-js`

## File: `LICENSE.md`
**Path:** `node_modules/http-parser-js/LICENSE.md`  
**Hash:** `42ad9b2a32fceca5101c0e34bf8480ca`  
**Legal File:** YES  
**License Types Detected**: KEYWORD, MIT, UNKNOWN  
**Contains Keywords:** YES  

**File Text:**
```
<Begin COPYRIGHT>

Copyright (c) 2015 Tim Caswell (https://github.com/creationix) and other

<End COPYRIGHT>

<Begin unknown text>

contributors. All rights reserved.

<End unknown text>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

<End MIT>

<Begin unknown text>

Some files from the tests folder are from joyent/node and mscedex/io.js, a fork
of nodejs/io.js:

- tests/iojs/test-http-parser-durability.js

  This file is from

<End unknown text>

<Begin ACCEPTABLE>

https://github.com/mscdex/io.js/blob/js-http-parser/test/pummel/test-http-parser-durability.js

<End ACCEPTABLE>

<Begin unknown text>

with modifications by Jan Schär (jscissr).

  """

<End unknown text>

<Begin COPYRIGHT>

Copyright io.js contributors. All rights reserved.

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to
  deal in the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
  sell copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.

<End MIT>

<Begin unknown text>

"""

- tests/fixtures/*
  tests/parallel/*
  tests/testpy/*
  tests/common.js
  tests/test.py
  tests/utils.py

  These files are from

<End unknown text>

<Begin ACCEPTABLE>

https://github.com/nodejs/node

<End ACCEPTABLE>

<Begin unknown text>

with changes by
  Jan Schär (jscissr).

  Node.js is

<End unknown text>

<Begin KEYWORD>

licensed

<End KEYWORD>

<Begin unknown text>

for use as follows:
  
  """

<End unknown text>

<Begin COPYRIGHT>

Copyright Node.js contributors. All rights reserved.

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to
  deal in the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
  sell copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.

<End MIT>

<Begin unknown text>

"""

  This

<End unknown text>

<Begin KEYWORD>

license

<End KEYWORD>

<Begin unknown text>

applies to parts of Node.js originating from the

<End unknown text>

<Begin ACCEPTABLE>

https://github.com/joyent/node

<End ACCEPTABLE>

<Begin unknown text>

repository:

  """

<End unknown text>

<Begin COPYRIGHT>

Copyright Joyent, Inc. and other Node contributors. All rights reserved.

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to
  deal in the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
  sell copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.
  """

<End MIT>
```

# Package: `isemail 3.2.0`
**Package Path:** `node_modules/isemail`

## File: `LICENSE`
**Path:** `node_modules/isemail/LICENSE`  
**Hash:** `e61745af217cd2c45d5086e2915b87bf`  
**Legal File:** YES  
**License Types Detected**: BSD-3-Clause, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin COPYRIGHT>

Copyright (c) 2014-2015, Eli Skeggs and Project contributors

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright (c) 2013-2014, GlobeSherpa

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright (c) 2008-2011, Dominic Sayers
All rights reserved.

<End COPYRIGHT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin BSD-3-Clause>

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * The names of any contributors may not be used to endorse or promote
      products derived from this software without specific prior written
      permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS AND CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

<End BSD-3-Clause>

<Begin ACCEPTABLE>

*   *   *

<End ACCEPTABLE>

<Begin ACCEPTABLE>

The complete list of contributors can be found at:

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin ACCEPTABLE>

https://github.com/hapijs/isemail/graphs/contributors

<End ACCEPTABLE>

<Begin unknown text>

Previously published under the 2-Clause-

<End unknown text>

<Begin BSD-3-Clause>

BSD license

<End BSD-3-Clause>

<Begin unknown text>

published here:

<End unknown text>

<Begin ACCEPTABLE>

https://github.com/hapijs/isemail/blob/v1.2.0/LICENSE

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>
```

# Package: `lodash.includes 4.3.0`
**Package Path:** `node_modules/lodash.includes`

## File: `LICENSE`
**Path:** `node_modules/lodash.includes/LICENSE`  
**Hash:** `3c85d59232f31460a884d1e7280b1c15`  
**Legal File:** YES  
**License Types Detected**: CC0-1.0, KEYWORD, MIT, UNKNOWN  
**Contains Keywords:** YES  

**File Text:**
```
<Begin COPYRIGHT>

Copyright jQuery Foundation and other contributors <https://jquery.org/>

<End COPYRIGHT>

<Begin unknown text>

Based on Underscore.js, copyright Jeremy Ashkenas,
DocumentCloud and Investigative Reporters & Editors <

<End unknown text>

<Begin ACCEPTABLE>

http://underscorejs.org/

<End ACCEPTABLE>

<Begin ACCEPTABLE>

>

<End ACCEPTABLE>

<Begin ACCEPTABLE>

This software consists of voluntary contributions made by many
individuals. For exact contribution history, see the revision history
available at

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin ACCEPTABLE>

https://github.com/lodash/lodash

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin ACCEPTABLE>

The following license applies to all parts of this software except as
documented below:

<End ACCEPTABLE>

<Begin ACCEPTABLE>

====

<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>

<Begin ACCEPTABLE>

====

<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright and related rights for sample code are waived via CC0. Sample

<End COPYRIGHT>

<Begin unknown text>

code is defined as all source code displayed within the prose of the
documentation.

CC0:

<End unknown text>

<Begin CC0-1.0>

http://creativecommons.org/publicdomain/zero/1.0/

<End CC0-1.0>

<Begin unknown text>

====

Files located in the node_modules and vendor directories are externally
maintained libraries used by this software which have their own

<End unknown text>

<Begin KEYWORD>

licenses

<End KEYWORD>

<Begin unknown text>

; we recommend you read them, as their terms may differ from the
terms above.

<End unknown text>
```

# Package: `lodash.isboolean 3.0.3`
**Package Path:** `node_modules/lodash.isboolean`

## File: `LICENSE`
**Path:** `node_modules/lodash.isboolean/LICENSE`  
**Hash:** `e9a6825166e2bc4f7b0432307b53103c`  
**Legal File:** YES  
**License Types Detected**: MIT, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin COPYRIGHT>

Copyright 2012-2016 The Dojo Foundation <http://dojofoundation.org/>

<End COPYRIGHT>

<Begin unknown text>

Based on Underscore.js, copyright 2009-2016 Jeremy Ashkenas,
DocumentCloud and Investigative Reporters & Editors <

<End unknown text>

<Begin ACCEPTABLE>

http://underscorejs.org/

<End ACCEPTABLE>

<Begin ACCEPTABLE>

>

<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>
```

# Package: `lodash.isinteger 4.0.4`
**Package Path:** `node_modules/lodash.isinteger`

## File: `LICENSE`
**Path:** `node_modules/lodash.isinteger/LICENSE`  
**Hash:** `3c85d59232f31460a884d1e7280b1c15`  
**Legal File:** YES  
**License Types Detected**: CC0-1.0, KEYWORD, MIT, UNKNOWN  
**Contains Keywords:** YES  

**File Text:**
```
<Begin COPYRIGHT>

Copyright jQuery Foundation and other contributors <https://jquery.org/>

<End COPYRIGHT>

<Begin unknown text>

Based on Underscore.js, copyright Jeremy Ashkenas,
DocumentCloud and Investigative Reporters & Editors <

<End unknown text>

<Begin ACCEPTABLE>

http://underscorejs.org/

<End ACCEPTABLE>

<Begin ACCEPTABLE>

>

<End ACCEPTABLE>

<Begin ACCEPTABLE>

This software consists of voluntary contributions made by many
individuals. For exact contribution history, see the revision history
available at

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin ACCEPTABLE>

https://github.com/lodash/lodash

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin ACCEPTABLE>

The following license applies to all parts of this software except as
documented below:

<End ACCEPTABLE>

<Begin ACCEPTABLE>

====

<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>

<Begin ACCEPTABLE>

====

<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright and related rights for sample code are waived via CC0. Sample

<End COPYRIGHT>

<Begin unknown text>

code is defined as all source code displayed within the prose of the
documentation.

CC0:

<End unknown text>

<Begin CC0-1.0>

http://creativecommons.org/publicdomain/zero/1.0/

<End CC0-1.0>

<Begin unknown text>

====

Files located in the node_modules and vendor directories are externally
maintained libraries used by this software which have their own

<End unknown text>

<Begin KEYWORD>

licenses

<End KEYWORD>

<Begin unknown text>

; we recommend you read them, as their terms may differ from the
terms above.

<End unknown text>
```

# Package: `lodash.isnumber 3.0.3`
**Package Path:** `node_modules/lodash.isnumber`

## File: `LICENSE`
**Path:** `node_modules/lodash.isnumber/LICENSE`  
**Hash:** `e9a6825166e2bc4f7b0432307b53103c`  
**Legal File:** YES  
**License Types Detected**: MIT, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin COPYRIGHT>

Copyright 2012-2016 The Dojo Foundation <http://dojofoundation.org/>

<End COPYRIGHT>

<Begin unknown text>

Based on Underscore.js, copyright 2009-2016 Jeremy Ashkenas,
DocumentCloud and Investigative Reporters & Editors <

<End unknown text>

<Begin ACCEPTABLE>

http://underscorejs.org/

<End ACCEPTABLE>

<Begin ACCEPTABLE>

>

<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>
```

# Package: `lodash.template 4.4.0`
**Package Path:** `node_modules/lodash.template`

## File: `LICENSE`
**Path:** `node_modules/lodash.template/LICENSE`  
**Hash:** `3c85d59232f31460a884d1e7280b1c15`  
**Legal File:** YES  
**License Types Detected**: CC0-1.0, KEYWORD, MIT, UNKNOWN  
**Contains Keywords:** YES  

**File Text:**
```
<Begin COPYRIGHT>

Copyright jQuery Foundation and other contributors <https://jquery.org/>

<End COPYRIGHT>

<Begin unknown text>

Based on Underscore.js, copyright Jeremy Ashkenas,
DocumentCloud and Investigative Reporters & Editors <

<End unknown text>

<Begin ACCEPTABLE>

http://underscorejs.org/

<End ACCEPTABLE>

<Begin ACCEPTABLE>

>

<End ACCEPTABLE>

<Begin ACCEPTABLE>

This software consists of voluntary contributions made by many
individuals. For exact contribution history, see the revision history
available at

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin ACCEPTABLE>

https://github.com/lodash/lodash

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin ACCEPTABLE>

The following license applies to all parts of this software except as
documented below:

<End ACCEPTABLE>

<Begin ACCEPTABLE>

====

<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>

<Begin ACCEPTABLE>

====

<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright and related rights for sample code are waived via CC0. Sample

<End COPYRIGHT>

<Begin unknown text>

code is defined as all source code displayed within the prose of the
documentation.

CC0:

<End unknown text>

<Begin CC0-1.0>

http://creativecommons.org/publicdomain/zero/1.0/

<End CC0-1.0>

<Begin unknown text>

====

Files located in the node_modules and vendor directories are externally
maintained libraries used by this software which have their own

<End unknown text>

<Begin KEYWORD>

licenses

<End KEYWORD>

<Begin unknown text>

; we recommend you read them, as their terms may differ from the
terms above.

<End unknown text>
```

# Package: `lodash.templatesettings 4.1.0`
**Package Path:** `node_modules/lodash.templatesettings`

## File: `LICENSE`
**Path:** `node_modules/lodash.templatesettings/LICENSE`  
**Hash:** `3c85d59232f31460a884d1e7280b1c15`  
**Legal File:** YES  
**License Types Detected**: CC0-1.0, KEYWORD, MIT, UNKNOWN  
**Contains Keywords:** YES  

**File Text:**
```
<Begin COPYRIGHT>

Copyright jQuery Foundation and other contributors <https://jquery.org/>

<End COPYRIGHT>

<Begin unknown text>

Based on Underscore.js, copyright Jeremy Ashkenas,
DocumentCloud and Investigative Reporters & Editors <

<End unknown text>

<Begin ACCEPTABLE>

http://underscorejs.org/

<End ACCEPTABLE>

<Begin ACCEPTABLE>

>

<End ACCEPTABLE>

<Begin ACCEPTABLE>

This software consists of voluntary contributions made by many
individuals. For exact contribution history, see the revision history
available at

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin ACCEPTABLE>

https://github.com/lodash/lodash

<End ACCEPTABLE>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin ACCEPTABLE>

The following license applies to all parts of this software except as
documented below:

<End ACCEPTABLE>

<Begin ACCEPTABLE>

====

<End ACCEPTABLE>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>

<Begin ACCEPTABLE>

====

<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright and related rights for sample code are waived via CC0. Sample

<End COPYRIGHT>

<Begin unknown text>

code is defined as all source code displayed within the prose of the
documentation.

CC0:

<End unknown text>

<Begin CC0-1.0>

http://creativecommons.org/publicdomain/zero/1.0/

<End CC0-1.0>

<Begin unknown text>

====

Files located in the node_modules and vendor directories are externally
maintained libraries used by this software which have their own

<End unknown text>

<Begin KEYWORD>

licenses

<End KEYWORD>

<Begin unknown text>

; we recommend you read them, as their terms may differ from the
terms above.

<End unknown text>
```

# Package: `neo-async 2.6.0`
**Package Path:** `node_modules/neo-async`

## File: `LICENSE`
**Path:** `node_modules/neo-async/LICENSE`  
**Hash:** `1d93b9c9ef3b4c3f266489a30d628a85`  
**Legal File:** YES  
**License Types Detected**: MIT, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin MIT>

MIT License

<End MIT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright (c) 2014-2018 Suguru Motegi

<End COPYRIGHT>

<Begin unknown text>

Based on Async.js, Copyright Caolan McMahon

<End unknown text>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

<End MIT>
```

# Package: `react-transition-group 2.5.0`
**Package Path:** `node_modules/react-transition-group`

## File: `LICENSE`
**Path:** `node_modules/react-transition-group/LICENSE`  
**Hash:** `397133593cf0a19ac2cc498f975428e9`  
**Legal File:** YES  
**License Types Detected**: BSD-3-Clause, KEYWORD, UNKNOWN  
**Contains Keywords:** YES  

**File Text:**
```
<Begin unknown text>

BSD 3-Clause

<End unknown text>

<Begin KEYWORD>

License

<End KEYWORD>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright (c) 2016, React Community

<End COPYRIGHT>

<Begin unknown text>

Forked from React (

<End unknown text>

<Begin ACCEPTABLE>

https://github.com/facebook/react

<End ACCEPTABLE>

<Begin unknown text>

) Copyright 2013-present, Facebook, Inc.
All rights reserved.

<End unknown text>

<Begin BSD-3-Clause>

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

* Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

<End BSD-3-Clause>
```

# Package: `semver-compare 1.0.0`
**Package Path:** `node_modules/semver-compare`

## File: `LICENSE`
**Path:** `node_modules/semver-compare/LICENSE`  
**Hash:** `f372d26aebc6696646e8afb05e30ba19`  
**Legal File:** YES  
**License Types Detected**: MIT, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin unknown text>

This software is released under

<End unknown text>

<Begin MIT>

the MIT license:

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>
```

# Package: `to-fast-properties 2.0.0`
**Package Path:** `node_modules/to-fast-properties`

## File: `license`
**Path:** `node_modules/to-fast-properties/license`  
**Hash:** `839bd592c2662bbed7210e247da65fb8`  
**Legal File:** YES  
**License Types Detected**: MIT, UNKNOWN  
**Contains Keywords:** NO  

**File Text:**
```
<Begin MIT>

MIT License

<End MIT>

<Begin ACCEPTABLE>



<End ACCEPTABLE>

<Begin COPYRIGHT>

Copyright (c) 2014 Petka Antonov

<End COPYRIGHT>

<Begin unknown text>

2015 Sindre Sorhus

<End unknown text>

<Begin MIT>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

<End MIT>
```

# Package: `yargs 12.0.2`
**Package Path:** `node_modules/yargs`

## File: `LICENSE`
**Path:** `node_modules/yargs/LICENSE`  
**Hash:** `eeb98f51ff1c34e4302ac1b1ab61ac83`  
**Legal File:** YES  
**License Types Detected**: UNKNOWN, X11  
**Contains Keywords:** NO  

**File Text:**
```
<Begin COPYRIGHT>

Copyright 2010 James Halliday (mail@substack.net)

<End COPYRIGHT>

<Begin unknown text>

Modified work Copyright 2014 Contributors (ben@

<End unknown text>

<Begin ACCEPTABLE>

npmjs.com

<End ACCEPTABLE>

<Begin unknown text>

)

This project is free software released under the

<End unknown text>

<Begin X11>

MIT/

<End X11>

<Begin X11>

X11 license:

<End X11>

<Begin X11>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

<End X11>
```