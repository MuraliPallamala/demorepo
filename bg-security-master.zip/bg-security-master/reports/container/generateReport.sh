#!/usr/bin/env bash
#
# Use Bluemix Vulnerability Advisor to check for vulnerabilites in the container images.
#
# 
# Author: Bruno Marques - brunomar@au1.ibm.com
#

# Exit when a command fails
set -o errexit

PORTAL_IMAGES=( bg-portal:uat bg-nginx-keycloak:uat )
CORE_IMAGES=( bg-newco-admin-api:uat bg-service-api:uat bg-newco-api:uat bg-issuer-api:uat )
KEYCLOAK_IMAGES=( bg-keycloak:uat )
MOCK_IBP_IMAGES=( bg-mock-ibp:uat )
JIRA_IMAGES=( bg-jira:7.12.1-ubuntu )

# Bank Guarantees images
IMAGES=( "${PORTAL_IMAGES[@]}" "${CORE_IMAGES[@]}" "${KEYCLOAK_IMAGES[@]}" "${MOCK_IBP_IMAGES[@]}" "${JIRA_IMAGES[@]}" )

FILENAME=$(date "+%Y-%m-%d").txt 
touch ${FILENAME}
for image in "${IMAGES[@]}"
do
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # " >> ${FILENAME} 
  echo "# VULNERABILITY SCANNING RESULTS FOR ${image} #" >> ${FILENAME} 
  echo "# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # " >> ${FILENAME} 
  
  bx cr va -e --output json registry.au-syd.bluemix.net/prjlygon/${image} >> ${FILENAME}  
  
  echo " - - - - - - - - - - - - - - - - - - - - - - -  " >> ${FILENAME} 
  echo "" >> ${FILENAME} 
done

