# bg-security
This repository contains artefacts for implementing the controls listed in the security proposal for the Bank Guarantees project.
