# Introduction

The purpose of this document is to describe the operational procedures related to setting up and maintaining the environment for the Bank Guarantee project.

## Getting access to the IBM Cloud Account

In order to be able to provision and maintain cloud resources, the first step a sysadmin need to take is to get access to the IBM Cloud account that was provision for the project.
The current owner of the account is **Kimiko Wilson (kimiko.wilson@au1.ibm.com)**, and a request should be submitted to her.

The first sysadmin to get access to the account was **Bruno de Assis Marques via the functional id prjlygonmic@au1.ibm.com**.
Access to the account for provisioning resources is via https://bluemix.net.
Besides using username and password credentials to login, it is also recommended to enable 2-factor authentication for every sysadmin who is granted access to the account.

Access logs can be verified by going to https://control.bluemix.net, and selecting **Account** -> **Manage** -> **Audit Log**.

## Configuring VPN access

- Go to https://control.bluemix.net
- Select **Account** -> **VPN Access**
- Find the row associated with the username that needs VPN access (for example, 1703041_prjlygon@au1.ibm.com) and:
  - change the **VPN Access** value from *None* to *SSL*
  - click on **Reset** to set the VPN password
  
- Install MotionPro Plus client from App Store
- Follow instructions from http://knowledgelayer.softlayer.com/articles/standalone-vpn-clients-windows-linux-and-mac-os-x 
  - Point it to: Melb - vpn.mel01.softlayer.com - 1703041_prjlygon@au1.ibm.com
  
  
## Provisioning a Dedicated Host for the Virtual Server Instances

For the pilot and opsrun phase, the VMs supporting the frontend and middleware, including the default managed identity provider, centralised logging and jumpbox, will be running in a Dedicated Virtual Server which offers single tenancy for workloads requiring physical isolation compliance and maximum placement control.

In order to provision a dedicated host, execute the following steps:

- Go to https://control.bluemix.net
- Select **Devices** -> **Device List**
- Select **Order Devices**
- Select **Virtual Server**
- Select **Dedicated Virtual Server** and click **Create**
- Under the "Dedicated Host" section, click on **Create Host**
  - Set "Quantity" as 1
  - Set "Hostname" as dedicatedhost01
  - Set "Location" as Asia-Pacific, MEL 01 - Melbourne
  - Set "Host size" as 56 Cores X 242 RAM X 1.2 TB
- Wait for the dedicated host to be provisioned before proceeding with creating dedicated virtual server instances.

## Provisioning Dedicated Virtual Server Instances

- Go to https://control.bluemix.net
- Select **Devices** -> **Device List**
- Select **Order Devices**
- Select **Virtual Server**
- Select **Dedicated Virtual Server** and click **Create**
- Under the "Virtual Server" section, select:
  - Type: Dedicated
- Under "Dedicated Host" section, select:
  - "Specify Host" -> "dedicatedhost01" (which is the dedicate host that was created previously)
- Then, the next sections should be filled in according to the type of each VM as specified below:

### Type 1: Frontend Virtual Server
There will be 7 VMs of this type: one per issuer, one for newco users, one for newco admins and one for the default identity provider. They will have a public ip, run NGINX and host issuer portals.
- Hostnames:
  - michelangelo
  - raffaello
  - donatello
  - leonardo
  - admin
  - user
  - services
- Domain: dtl.res.ibm.com
- vCPU: 2
- RAM: 4 GB
- SSH Keys: Add the sysadmin public key. This key should only be used for the first login in order to create a non-root user for the sysadmin. After that, the key should be removed from /root/.ssh.
- Image: Ubuntu 16.04 Minimal TLS (64 bit) - HVM
- Add-ons:
  - Database Software: None
  - Services: Advanced Monitoring, VPN Management, Vulnerability Management, Primary IP Address, Notification, Monitoring, Response, Remote Management
- Attached Storage Disks:
  - Boot disk - SAN - 25GB
- Network Interface
  - Uplink Port Speeds: 1 Gbps Public & Private Network Uplinks (Dedicated Host)
  - Private Security Group: allow_web, allow_ssh, allow_outbound
  - Public Security Group: None
  - Add-ones: Bandwidth, Hardware & software firewalls (APF Software Firewall for Linux)

### Type 2a: Issuer Backend Virtual Server
There will be 4 VMs of this type: one per issuer. They will host the middleware (APIs and other possibly other services as databases if Cloudant and DB2 Hosted are not suitable).
- Hostnames:
  - michelangelo-core
  - raffaello-core
  - donatello-core
  - leonardo-core
- Domain: dtl.res.ibm.com
- vCPU: 4
- RAM: 16 GB
- SSH Keys: Add the sysadmin public key. This key should only be used for the first login in order to create a non-root user for the sysadmin. After that, the key should be removed from /root/.ssh.
- Image: Ubuntu 16.04 Minimal TLS (64 bit) - HVM
- Add-ons:
  - Database Software: None
  - Services: Advanced Monitoring, VPN Management, Vulnerability Management, Primary IP Address, Notification, Monitoring, Response, Remote Management
- Attached Storage Disks:
  - Boot disk - Local - 100GB
- Network Interface
  - Uplink Port Speeds: 1 Gbps Public & Private Network Uplinks (Dedicated Host)
  - Private Security Group: allow_web, allow_ssh, allow_outbound
  - Public Security Group: None
  - Add-ones: Bandwidth, Hardware & software firewalls (APF Software Firewall for Linux)
  
### Type 2b: User Backend Virtual Server
There will be 1 VM of this type representing NewCo user backend. It will host the middleware (APIs and other possibly other services as databases if Cloudant and DB2 Hosted are not suitable).
- It uses the same settings as Type 2a except for:
  - Hostname: user-core

### Type 2c: Admin Backend Virtual Server
There will be 1 VM of this type representing NewCo admin backend. It will host the middleware (APIs and other possibly other services as databases if Cloudant and DB2 Hosted are not suitable).
- It uses the same settings as Type 2a except for:
  - Hostname: admin-core

### Type 2d: Managed Identity Provider Server
There will be 1 VM of this type representing Managed Identity Provider backend. It will host Keycloak and its database. 
- It uses the same settings as Type 2a except for:
  - Hostname: services-core

### Type 3: Jumpbox
There will be 1 VM of this type which will provide ssh access to the other VMs via private network. In order to get access to this private network, the sysadmin will need to establish a VPN connection with Softlayer. 

- Hostname: jumpbox
- Domain: dtl.res.ibm.com
- vCPU: 1
- RAM: 1 GB
- SSH Keys: Add the sysadmin public key. This key should only be used for the first login in order to create a non-root user for the sysadmin. After that, the key should be removed from /root/.ssh.
- Image: Ubuntu 16.04 Minimal TLS (64 bit) - HVM
- Add-ons:
  - Database Software: None
  - Services: Advanced Monitoring, VPN Management, Vulnerability Management, Primary IP Address, Notification, Monitoring, Response, Remote Management
- Attached Storage Disks:
  - Boot disk - SAN - 25GB
- Network Interface
  - Uplink Port Speeds: 1 Gbps Public & Private Network Uplinks (Dedicated Host)
  - Private Security Group: allow_ssh, allow_outbound
  - Public Security Group: None
  - Add-ones: Bandwidth, Hardware & software firewalls (APF Software Firewall for Linux)
  
### Type 4: Mock-IBP
There will be 1 VM of this type which will emulate IBM Blockchain functionality.
- Hostname: mock-ibp
- Domain: dtl.res.ibm.com
- vCPU: 4
- RAM: 16 GB
- SSH Keys: Add the sysadmin public key. This key should only be used for the first login in order to create a non-root user for the sysadmin. After that, the key should be removed from /root/.ssh.
- Image: Ubuntu 16.04 Minimal TLS (64 bit) - HVM
- Add-ons:
  - Database Software: None
  - Services: Advanced Monitoring, VPN Management, Vulnerability Management, Primary IP Address, Notification, Monitoring, Response, Remote Management
- Attached Storage Disks:
  - Boot disk - LOCAL - 100GB
- Network Interface
  - Uplink Port Speeds: 1 Gbps Public & Private Network Uplinks (Dedicated Host)
  - Private Security Group: allow_ssh, allow_outbound
  - Public Security Group: None
  - Add-ones: Bandwidth, Hardware & software firewalls (APF Software Firewall for Linux)
  
###  Exposure to the internet
The only VMs exposed to the internet via the public interface should be the frontend virtual servers. The public interfaces for non frontend virtual servers should only allow outgoing traffic. 


### Security Groups

![Security Group - allow_outbound](https://github.ibm.com/bank-guarantees/bg-security/blob/master/processes/images/sg-allow_outbound.png)

![Security Group - allow_icmp](https://github.ibm.com/bank-guarantees/bg-security/blob/master/processes/images/sg-allow_icmp.png)

![Security Group - allow_ssh](https://github.ibm.com/bank-guarantees/bg-security/blob/master/processes/images/sg-allow_ssh.png)

![Security Group - allow_ssh_from_jumpbox_only](https://github.ibm.com/bank-guarantees/bg-security/blob/master/processes/images/sg-allow_ssh_from_jumpbox_only.png)

![Security Group - allow_web](https://github.ibm.com/bank-guarantees/bg-security/blob/master/processes/images/sg-allow_web.png)

![Security Group - allow_bigfix_relay](https://github.ibm.com/bank-guarantees/bg-security/blob/master/processes/images/sg-allow_bigfix_relay.png)

![Security Group - allow_bigfix_client](https://github.ibm.com/bank-guarantees/bg-security/blob/master/processes/images/sg-allow_bigfix_client.png)


The table below maps security groups to virtual instances:

Virtual Server | Private Interface | Public Interface
------------ | ------------- | -------------
services | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`, `allow_web`
services-core | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`
admin | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`, `allow_web`
admin-core | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`
user | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`, `allow_web`
user-core | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`
michelangelo | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`, `allow_web`
michelangelo-core | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`
raffaello | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`, `allow_web`
raffaello-core | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`
donatelo | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`, `allow_web`
donatelo-core | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`
leonardo | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`, `allow_web`
leonardo-core | `allow_outbound`, `allow_web`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`
mock-ibp | `allow_outbound`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_client` | `allow_outbound`
bigfix | `allow_outbound`, `allow_ssh_from_jumpbox_only`, `allow_bigfix_relay` | `allow_outbound`, `allow_bigfix_relay`
jumpbox | `allow_outbound`, `allow_ssh`, `allow_icmp`, `allow_bigfix_client` | `allow_outbound`



## Registering Virtual Server Instances in IBM Inventory System
- Access the IBM System Inventory
- Fill in a form for each system:
  - Name: hostname of the system
  - Security owner: Project Lygon/Australia/IBM
  - Business owner: Ermyas Abebe/Australia/IBM
  - Location: Australia - Melbourne
  - Operating system: Linux - Ubuntu
  - Operating system version: Version 16.04 LTS - Xenial Xerus
  - Function: Demo, Education, or Test System
  - Properties: Hosted in Softlayer
  - IES attribute: None
  - Additional owner 1: Bill Rippon/Watson/IBM
  - Additional owner 2: RISSecurity/Watson/Contr/IBM
  - Additional owner 3: RIS MAD Management/Poughkeepsie/Contr/IBM
  - Asset owner: Project Lygon/Australia/IBM
  - Virtual system: Yes
  - Owning Business Unit: IBM Research
  - Comment: IBM Cloud account provided by GBS for the Prj Lygon project at IBM Research Australia
  - IP type: Static
  - Hostname: hostname of the system
  - IP: Ip of the system

## Generating DNS names for VMs with public IPs under res.ibm.com
Submit a request for reserving DNS names under .res.ibm.com for all the VMs with public IPs used in the solution according to the process "External DNS for Research".

In the request, make sure to ask for DNS entries for the following systems and include their public ips:
- user.dlt.res.ibm.com: `<public ip>`
- admin.dlt.res.ibm.com: `<public ip>`
- michelangelo.dlt.res.ibm.com: `<public ip>`
- raffaello.dlt.res.ibm.com: `<public ip>`
- donatello.dlt.res.ibm.com: `<public ip>`
- leonardo.dlt.res.ibm.com: `<public ip>`
- services.dlt.res.ibm.com: `<public ip>`

## Provisioning IBM Cloud Object Storage

The virtual server instances hosting the frontend and backend make use of the IBM Cloud Object Storage offering in order to load configuration files required for the bringing up and down of environments. 

For the pilot phase, one instance of IBM Cloud Object Storage will be provisioned containing one bucket for each virtual server instance. The bucket is mounted on the virtual server instance with S3FS on the following path: `/opt/dlt/data/conf`

In order to provision the Cloud Object Storage instance, perform the following steps:
- Go to https://bluemix.bluemix.net
- Select **Devices** -> **Device List**
- Select **Order Devices**
- Select **Virtual Server**
- Select **Dedicated Virtual Server** and click **Create**
- Under the "Dedicated Host" section, click on **Create Host**
  - Set "Quantity" as 1
  - Set "Hostname" as dedicatedhost01
  - Set "Location" as Asia-Pacific, MEL 01 - Melbourne
  - Set "Host size" as 56 Cores X 242 RAM X 1.2 TB
- Wait for the dedicated host to be provisioned before proceeding with creating dedicated virtual server instances.


## Generating Certificates for Virtual Server Instances facing the Internet

If the certificates are being issued by GeoTrust, follow the recommendations available at https://knowledge.digicert.com/solution/SO17539.html.

In order to generate the private keys and certificate signing requests use the following commands:

```
openssl req -new -newkey rsa:2048 -sha256 -nodes -keyout services.dlt.res.ibm.com.key -out services.dlt.res.ibm.com.csr

openssl req -new -newkey rsa:2048 -sha256 -nodes -keyout user.dlt.res.ibm.com.key -out user.dlt.res.ibm.com.csr

openssl req -new -newkey rsa:2048 -sha256 -nodes -keyout admin.dlt.res.ibm.com.key -out admin.dlt.res.ibm.com.csr

openssl req -new -newkey rsa:2048 -sha256 -nodes -keyout michelangelo.dlt.res.ibm.com.key -out michelangelo.dlt.res.ibm.com.csr

openssl req -new -newkey rsa:2048 -sha256 -nodes -keyout raffaello.dlt.res.ibm.com.key -out raffaello.dlt.res.ibm.com.csr

openssl req -new -newkey rsa:2048 -sha256 -nodes -keyout donatello.dlt.res.ibm.com.key -out donatello.dlt.res.ibm.com.csr

openssl req -new -newkey rsa:2048 -sha256 -nodes -keyout leonardo.dlt.res.ibm.com.key -out leonardo.dlt.res.ibm.com.csr

```

Fill in the questions prompted by the command as shown below:

```
Country Name (2 letter code) [AU]:AU
State or Province Name (full name) [Some-State]:Victoria
Locality Name (eg, city) []:Melbourne
Organization Name (eg, company) [Internet Widgits Pty Ltd]:International Business Machines
Organizational Unit Name (eg, section) []:IBM Research
Common Name (e.g. server FQDN or YOUR name) []:<hostname depending on which csr is being generated>
Email Address []:

Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:
An optional company name []:
```

Once the CSRs are created, provide them to the trusted third party certificate authority so that they can generate the certificates that need to be installed in the web server.

The trusted third party certificate authority should send you the certificates and further instructions on how to concatenate intermediate certificates to the original certificate. The instructions performed last time were available at https://knowledge.digicert.com/solution/SO17482.html. It basically consisted on concatenating the Geotrust intermediate certificate to the existing certificate. Suggestion: instead of replacing the original certificate with the concatenated version, create a new file names, for example, user.dlt.res.ibm.com.chain.pem, and put the concatenated version in there. That is the version that should be installed in Nginx.


## Provisioning Email Service

- Go to https://control.bluemix.net/
- On the left navigation pane, select **Services** -> **Email Delivery** and select **Order Email Delivery Service**.
- The Free Package (up to 25000 emails per month) should be enough.
- Fill in the required information.


