# Introduction

## Daily Back-ups

Daily backups of off-chain data is confirmed (Cloudant database, RabbitMQ, PostgreSQL). These backups are stored in an encrypted bucket on Cloud Object Storage protected by a root key from Key Protect. Each organisation has their own encryption key.

IBP is backed up off-site once every 24 hours and is restored to the same site, or alternate site only in the event of a disaster.

The ledger data is not required to be backed up because of the nature of it’s environment. In the very worst case scenario where there is a catastrophic failure of a peer (e.g disk failure) the peer can be brought up with no ledger at all. You can have the peer re-join the desired channels and as a result, the peer will automatically create a ledger for each of the channels.

Observations:
Currently, off-chain back-ups are taken everyday at 16:00 UTC (~3am AEST). This is an automated off-chain backup that happens  7 days a week (including public holiday)

To increase consistency amongst all off-chain databases, it would be recommended to shut down the API to perform the back-ups and start them again. This would be an automated process and the system would be down for 20 minutes during after-hours (16:00 UTC)

The diagram below shows how the Backend Virtual Instances communicate with the data stores in order to perform the backups:

![Daily Backups](https://github.ibm.com/bank-guarantees/bg-security/blob/master/processes/images/daily_backups.png)

## Restore Process

### Identity Management - Postgresql

1. Provision a new instance of Compose Postgresql in IBM Cloud;\
2. Install postgresql client:
  - `sudo add-apt-repository "deb http://apt.postgresql.org/pub/repos/apt/ $(lsb_release -sc)-pgdg main"`
  - `wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -`
  - `sudo apt-get update`
  - `sudo apt-get install postgresql-9.6`
3. Restore the backup file (.dump) stored in IBM Cloud Object Store into the new Postgresql instance;
  - `PGPASSWORD=<password_from_pg_instance> dropdb -h <host_from_pg_instance> -p <port_from_pg_instance> -U <user_from_pg_instance> compose`
  - `PGPASSWORD=<password_from_pg_instance> pg_restore -d compose -h <host_from_pg_instance> -p <port_from_pg_instance> -U admin -C -d compose <.dump file>`
  - `PGPASSWORD=<password_from_pg_instance> psql 'host=<host_from_pg_instance> port=<port_from_pg_instance> dbname=compose user=admin sslmode=require'`
4. Update the Backend Virtual Instance configuration to point to the new instance only for `services-core` VM.

### Cloudant databases

1. Provision a new instance of Cloudant in IBM Cloud;
2. Create Cloudant credentials;
3. Create databases and set credentials for databases
  - *Run script for creating databases*
4. Install couchbackup by running:
  - `npm install -g @cloudant/couchbackup`
  - `export COUCH_URL=https://<myusername>:<mypassword>@<cloudant_url>`
5. Restore the backup files stored in IBM Cloud Object Store into the new Cloudant databases;
  - `for backup_file in $(ls backup*.txt); do cat ${backup_file} | couchrestore --db $(echo ${backup_file} | cut -d '-' -f2- | cut -d '.' -f1); done`
6. Update the Backend Virtual Instance configuration to point to the new instance for each backend VM: `admin-core`, `user-core`, `michelangelo-core`, `raffaello-core`, `donatello-core`, `leonardo-core`


### RabbitMQ

RabbitMQ backups are a JSON representation of your broker's metadata. It does not backup the messages that were not processed by the queuing system.

1. Provision new instances of Compose RabbitMQ in IBM Cloud;
2. No need to restore the broker's metadata as the middleware will create it once it connects to RabbitMQ;
3. Update Backend Virtual Instance configuration to point to the new instances.



