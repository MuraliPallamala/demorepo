# Deployment Procedure for UAT/PROD

## Introduction

This document describes the set of steps for deploying the solution in the UAT/PROD environment. Only the high-level sequence of steps is reported, the nitty gritty details of the configuration of each vertical are covered in the Deploymnt Guide deliverable.

## Preliminary Actions

1. Ensure that the environment is not running:
   - Probe endpoints: https://(vertical).dlt.res.ibm.com 
   - Log into each of the machines and shutdown the services except for:
     - services-core.dlt.res.ibm.com (needed for `cleanRealm.sh`)
     - services.dlt.res.ibm.com (needed for `cleanRealm.sh`)
     - support.dlt.res.ibm.com (JIRA)

2. Install the cloudant client for Python:
   - `pip install cloudant`
   
3. Configure the proxy for your browser to access the Cloudant/Sendgrid/Compose Consoles
   - run `ssh -D 1981 -f -C -q -N <user-id>@jumpbox.dlt.res.ibm.com`
   - configure Firefox to use the localhost:1981 (manual proxy) as proxy for SOCKS v5 connection

## Process

1. Reset databases by using scripts in the `scripts` folder:
   - `cleanRealms.sh`: cleans all the realms in PostGRE SQL. This can be run from your local machine.
   - `resetCloudantDatabases.py`: cleans all th Cloudant databases and set permissions. Change of credentials may be required. This must be run from the jumpbox (/root/sandbox/cloudant) or by proxying through the jumpbox.
   
2. Generate chaincode packages on your workstation from the repository: [bg-chaincode](https://github.ibm.com/bank-guarantees/bg-chaincode).

3. Reset IBP 
   - Provision a new IBP Enterprise instance via the IMS Portal (slack Matt to fast-track the provision process).
   - Once the instance is approved and provisioned, proceed with network creation using the IMS portal.
   - Use the IBP provisioning script to provision the rest.
   - If you are only creating new channels, remember to:
   1. Update bgx.fabricUser property on all api.properties and service-api.properties files.
   2. Update the value of the variable BG_ENV_SPRING_CHANNEL_SUFFIX= in the .env files.
   3. Change the channel names and configuration under /opt/dlt/data/conf/ibp.
   
4. Tag and push the images from bg-pilot-qa to the Bluemix Registry.

5. Check for image vulnerability on the Vulnerability Advisor.

6. SSH to each VM of the deployment environment via the jumpbox.

7. Check if there are security patches to be installed.

8. Check for disk space and see whether there any abnormal disk comsuption (one cause can be logs growing too big and a misconfiguration of the log rotation settings).

9. Check YAML templates in case there is need to update the configuration profiles.

10. Check the `api.properties` and `service-api.properties` in case there is a need to update the Spring configuration file.

11. Check the `.env` fiiles for updates of the sensitive information:
    - Use Jasypt to encrypt and decrypt properties.
    - Jasypt depends on the Bouncy Castle libraries.
    
12. Check the `.pedigree` file

13. Pull the newest images from the Bluemix Registry.

14. Configure the truststores across all the API verticals.

15. Run `/opt/dlt/setup/update.sh`

### Deployment from 27/Feb/2019

#### Preparation

1. Tag and create releases on Github for the following repositories: bg-api, bg-portal, bg-chaincode, bg-chaincode-model, weave-client-java, weave-cc-go.
2. Generate chaincode packages by running bg-chaincode from Jenkins.
3. Update bg-securiy/scrips/ibp/create-network.sh script used to provision the IBP instance or part of it including installation and instantiation of chaincode. 
4. SSH to middleware VMs (admin-core, user-core, michelangelo-core, raffaello-core, donatello-core, leonardo-core, admin, user, michelangelo, raffaello, donatello, leonardo).
  4.1. Disable alerts running as cron jobs
  4.2. Apply security patches by upgrading OS libs and kernels
  4.3. Update kubernetes templates, add files to buckets in COS, update api.properties and services-api.properties
5. Push docker images from internal qa to IBM Cloud Registry.
6. Check for container vulnerabilities in the docker images using the IBM Cloud Vulnerability Advisor.
7. Pull docker images from the middleware VMs.

### Execution
1. Stop portal containers.
2. Stop API containers.
3. Stop Service API containers.
4. Reset/Update IBP network by running bg-securiy/scrips/ibp/create-network.sh.
5. Start API containers.
6. Start Service API containers.
7. Start portal containers.
