# Introduction

This procedure demonstrates the capability of removing an issuer from the system by performing steps on both onchain and offchain components.

# Steps

The steps that need to be performed onchain and offchain are listed below:

## Onchain Issuer Removal

1. **Newco**: updates channel configuration and makes the issuer that is leaving the only operator;
1. **Issuer**: deletes all its peers/nodes and leaves the Blockchain network by deleting its Blockchain instance in the IBM Cloud account;
1. **Newco**: deletes the peer that was part of the guarantee channel related to the issuer that is leaving;
1. **Newco**: checks that the channel related to the issuer is not in the list of available channels anymore;
1. **Newco**: Run backoffice operation to deactivate the issuer in the platform channel.

## Offchain Issuer Removal

The steps below need to be executed by a sysadmins with access to the IBM Cloud account and to the instances used in the system. The sysadmin will need to establish a Softlayer VPN connection to perform some of steps. 

Let's use `issuerA` and the name of the issuer that is leaving the platform to make the steps more clear.

1. Delete Virtual Server Instances (VSIs) related to the vertical representing the issuer;
  - Delete `issuerA.dlt.res.ibm.com` VSI which hosts the portal;
  - Delete `issuerA-core.dlt.res.ibm.com` VSI which hosts the API;
2. Delete the Cloud Object Store buckets related to the issuer;
  - Delete `issuerA-backup` bucket;
  - Delete `issuerA-conf` bucket;
  - Delete `issuerA-core-conf` bucket;
  - Delete the `offchain-issuerA-enckey` key from KeyProtect instance.
3. Delete the Keycloak realm related to the issuer;
  - Delete the `issuerA` realm from Keycloak.
4. Delete the Compose RabbitMQ instance related to the issuer;
  - Delete the `Compose for RabbitMQ-prjlygon-issuerA` instance from IBM Cloud;
5. Delete Cloudant databases related to the issuer;
  - Delete the following databases from the Cloudant instance:
    - `issuerA-audit-events`
    - `issuerA-batch-process-configs`
    - `issuerA-blockchain-events`
    - `issuerA-crypto-keys`
    - `issuerA-fabric-users`
    - `issuerA-gx-expiration-jobs`
    - `issuerA-notifications-email`
    - `issuerA-notifications-web`
    - `issuerA-org-change-requests`
    - `issuerA-org-profile-requests`
    - `issuerA-organizations`
    - `issuerA-requests`
    - `issuerA-terms-conditions`
    - `issuerA-user-profiles`
  - *Note that access to the Cloudant dashboard requires proxying via the jumpbox.*
6. Selectively remove all documents from Newco Cloudant databases related to the issuer;
  - List all document ids that need to be deleted from Newco User and Newco Admin Cloudant databases. You can run the following python scripts from the jumpbox to accomplish that:
    - `bg_security/scripts/cloudant/issuerRemoval/01-cacheRequests.py`: Scans through the `newco-user-requests` or `newco-admin-requests` database locating all bank guarantee ids related to the issuer as well as ids of the documents representing those bank guarantees. This script generates 2 text (.txt) files: `newco-user-gxIds.txt` and `newco-user-gxRequestIdsToBeDeleted.txt`, or `newco-admin-gxIds.txt` and `newco-admin-gxRequestIdsToBeDeleted.txt`.
    - `bg_security/scripts/cloudant/issuerRemoval/02-cacheBlockchainEvents.py`: Scans through the `newco-user-blockchain-events` or `newco-admin-blockchain-events` database locating all entries related to any bank guarantee id in `newco-user-gxIds.txt` or `newco-admin-gxIds.txt`. This script generates a text (.txt) called `newco-user-blockchain-events-BlockchainEventsToBeDeleted.txt` or `newco-admin-blockchain-events-BlockchainEventsToBeDeleted.txt`.
    - `bg_security/scripts/cloudant/issuerRemoval/02-cacheAuditEvents.py`: Scans through the `newco-user-audit-events` datatabase locating all entries related to any bank guarantee id in `newco-user-gxIds.txt` file. This script generates a text (.txt) called `newco-user-audit-events-AuditEventsToBeDeleted.txt`.
    - `bg_security/scripts/cloudant/issuerRemoval/02-cacheGxExpirationJobs.py`: Scans through the `newco-user-gx-expiration-jobs` datatabase locating all entries related to any bank guarantee id in `newco-user-gxIds.txt` file. This script generates a text (.txt) called `newco-user-gx-expiration-jobs-GxExpirationJobsToBeDeleted.txt`.
    - `bg_security/scripts/cloudant/issuerRemoval/02-cacheNotificationsEmail.py`: Scans through the `newco-user-notifications-email` datatabase locating all entries related to any bank guarantee id in `newco-user-gxIds.txt` file. This script generates a text (.txt) called `newco-user-notifications-email-NotificationEmailsToBeDeleted.txt`.
    - `bg_security/scripts/cloudant/issuerRemoval/02-cacheNotificationsWeb.py`: Scans through the `newco-user-notifications-web` datatabase locating all entries related to any bank guarantee id in `newco-user-gxIds.txt` file. This script generates a text (.txt) called `newco-user-notifications-web-NotificationsWebToBeDeleted.txt`.
    - `bg_security/scripts/cloudant/issuerRemoval/03-deleteDocuments.py`: Deletes each of the documents listed in the generated files (*ToBeDeleted.txt*).
7. Send compaction request to the affected database via _compact endpoint. For example:
curl -X POST -H "Content-Type: application/json" https://558afea6-5d0b-4ded-a0d9-eccf46686075-bluemix.cloudant.com/newco-user-requests/_compact
7. Deactivate issuer in the platform channel;
  - Invoke the `deactivate` chaincode from a client in order to deactivate the organization in the platform-channel
8. Logging data will be purged after 3 months.
9. Update the portal source code and remove the `issuerA` tab from Newco User portal and the remove it from the select box used when creating a gx;
10. Destroy web certificates and related keys used in the portal and for TLS communication.

