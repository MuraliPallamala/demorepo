#!/bin/sh

# This script perform a set of environment variable replacement
# in the files that define the locations of the application servers
# so that we can abstract the specific details of the URLs of the
# application proxied from the configuration files.

# The script can be invoked with an argument which represents the
# name of the prefix of the names of the environment variables that
# will be considered for the substitution. If there is no prefix
# defined, it will use the default prefix TMPL_

# Checking for the script argument and defaulting to TMPL_
#
S_LIST_PREFIX=${1:-TMPL_}



# We can run the script in debug mode to verify the substitution
# by adding the string -d
#
S_DEBUG=$2
S_DEBUG=-d

echo "0. Creating substitution list..."
echo "   - Prefix             : $S_LIST_PREFIX"

# This is pretty hard stuff, let me explain it.
# 1. env: we list all the environment variables
# 2. grep "^${PREFIX}*": we filter out all the variables that do not match the given prefix
# 3. sed 's/=.*//': we remove whatever comes after and including =
# 4. sed 's/^/$/': we prefix the remaining content with $
# 5. tr '\n' ',': we remove new-line characters and replace them with comma
# 6. sed 's/.$//': we remove the last character (which would be a comma)
#
S_LIST=$(env | grep "^${S_LIST_PREFIX}*" | sed 's/=.*//' | sed 's/^/$/' | tr '\n' ',' | sed 's/.$//')
echo "   - Substitution List  : $S_LIST"
echo ""
echo "1. Processing SSL configuration .."
echo "   - /etc/nginx/ssl-config.conf.template => /etc/nginx/conf.d/ssl-config.conf"

envsubst $S_LIST < /etc/nginx/ssl-config.conf.template > /etc/nginx/conf.d/ssl-config.conf
if [ "$QA_ENV" == "true" ]; then
  echo "   - /etc/nginx/ssl-client.conf.template => /etc/nginx/conf.d/ssl-client.conf"
  envsubst $S_LIST < /etc/nginx/ssl-client.conf.template > /etc/nginx/conf.d/ssl-client.conf
fi


echo "2. Processing main NginX configuration .."
echo "   - /etc/nginx/${S_ENV}_nginx.conf.template => /etc/nginx/nginx.conf"

envsubst $S_LIST < /etc/nginx/${S_ENV}_nginx.conf.template > /etc/nginx/nginx.conf

if [ "$S_DEBUG" == "-d" ]; then
  cat /etc/nginx/nginx.conf
fi

echo ""

# We iterate over all the files that have extension .template
# in the conf.d folder, and we apply the substitution of the
# given list of environment variables.
#
echo "3. Processing template configuration files.."
for S_TEMPLATE in `ls /etc/nginx/conf.d/${S_ENV}/*.template`; do

  envsubst $S_LIST < $S_TEMPLATE > $S_TEMPLATE.conf
  echo "   - $S_TEMPLATE => $S_TEMPLATE.conf"

  if [ "$S_DEBUG" == "-d" ]; then
    cat $S_TEMPLATE.conf
  fi

done

echo ""
echo "4. Starting NGINX.."

nginx -g "daemon off;"
