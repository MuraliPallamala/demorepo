#!/bin/sh

# This script perform a set of environment variable replacement
# in the files that define the locations of the application servers
# so that we can abstract the specific details of the URLs of the
# application proxied from the configuration files.

# The script can be invoked with an argument which represents the
# name of the prefix of the names of the environment variables that
# will be considered for the substitution. If there is no prefix
# defined, it will use the default prefix TMPL_

# Checking for the script argument and defaulting to TMPL_
#
S_LIST_PREFIX=${1:-TMPL_}

NGINX_ROOT=/etc/nginx
NGINX_CONF=${NGINX_ROOT}/nginx.conf
NGINX_CONF_TEMPLATE=${NGINX_CONF}.template
NGINX_TEMPLATE_ROOT=${NGINX_ROOT}/templates
NGINX_INCLUDE_ROOT=${NGINX_ROOT}/includes

SSL_CLIENT=${SSL_CLIENT:-true}
OCSP_STAPLING=${OCSP_STAPLING:-false}
STRICT_TRANSPORT_SECURITY=${STRICT_TRANSPORT_SECURITY:-true}

# This function process the content of the NginX configuration file template
# and allows for including sections that enable more capabilities in the server.
# We do not use the normal include capability of NginX because we want to
# conditionally control the inclusion based on selected environment variables.
#
# $1: name of the placeholder to locate in the file.
# $2: variable that controls the inclusion of the section.
# $3: file to include if required.
#
function process_include {

  local LS_PLACEHOLDER=$1
  local LS_CONDITION=$2
  local LS_FILE=$3

  local LS_NGINX_TEMP=${NGINX_CONF_TEMPLATE}.tmp

  if [ "${LS_CONDITION}" == "true" ]; then

      echo "   - ${LS_PLACEHOLDER} (${LS_CONDITION}) => ${LS_FILE}"
      cat ${NGINX_CONF_TEMPLATE} | sed -e '\|!{'${LS_PLACEHOLDER}'}|r '$LS_FILE''  -e '\|!{'${LS_PLACEHOLDER}'}|d' > ${LS_NGINX_TEMP}

  else

      echo "   - ${LS_PLACEHOLDER} (${LS_CONDITION}) => (omitted)"
      cat ${NGINX_CONF_TEMPLATE} | sed -e '\|!{'${LS_PLACEHOLDER}'}|d' > ${LS_NGINX_TEMP}
  fi

  mv  ${LS_NGINX_TEMP} ${NGINX_CONF_TEMPLATE}
}

# This function is used to dump the content of a file into the console for
# the purpose of debugging the outcome of a substitution. It accepts one
# argument that is the path to th file to show.
#
function show_content {

    echo ""
    echo "[BEGIN: $1]"

    cat $1

    echo "[END: $1]"
    echo ""
}

# We can run the script in debug mode to verify the substitution
# by adding the string -d
#
S_DEBUG=$2


echo "0. Processing includes..."
process_include INCLUDE_SSL_CLIENT ${SSL_CLIENT} ${NGINX_INCLUDE_ROOT}/ssl-client.include.var
process_include INCLUDE_OCSP_STAPLING ${OCSP_STAPLING} ${NGINX_INCLUDE_ROOT}/ocsp-stapling.include.var
process_include INCLUDE_STRICT_TRANSPORT_SECURITY ${STRICT_TRANSPORT_SECURITY} ${NGINX_INCLUDE_ROOT}/strict-transport-security.include
echo ""

echo "0. Creating substitution list..."
echo "   - Prefix             : $S_LIST_PREFIX"

# This is pretty hard stuff, let me explain it.
# 1. env: we list all the environment variables
# 2. grep "^${PREFIX}*": we filter out all the variables that do not match the given prefix
# 3. sed 's/=.*//': we remove whatever comes after and including =
# 4. sed 's/^/$/': we prefix the remaining content with $
# 5. tr '\n' ',': we remove new-line characters and replace them with comma
# 6. sed 's/.$//': we remove the last character (which would be a comma)
#
S_LIST=$(env | grep "^${S_LIST_PREFIX}*" | sed 's/=.*//' | sed 's/^/$/' | tr '\n' ',' | sed 's/.$//')
echo "   - Substitution List  : $S_LIST"
echo ""
echo "1. Processing main NginX configuration .."
echo "   - ${NGINX_CONF_TEMPLATE} => ${NGINX_CONF}"

if [ "${S_LIST}" == "" ]; then
  echo "   - [WARN] Substitution list is empty, skipping  substitution."
  echo "   - cp ${NGINX_CONF_TEMPLATE} ${NGINX_CONF}"
  cp ${NGINX_CONF_TEMPLATE} ${NGINX_CONF}   

else

  echo "   - envsubst ${S_LIST} < ${NGINX_CONF_TEMPLATE} > ${NGINX_CONF}"
  envsubst ${S_LIST} < ${NGINX_CONF_TEMPLATE} > ${NGINX_CONF}

fi

if [ "${S_DEBUG}" == "-d" ]; then
  
  show_content ${NGINX_CONF}
fi

echo ""

# We iterate over all the files that have extension .template
# in the conf.d folder, and we apply the substitution of the
# given list of environment variables.
#
echo "2. Processing template configuration files.."
for S_TEMPLATE in $(ls ${NGINX_TEMPLATE_ROOT}/*.template); do

  S_TEMPLATE_FILE=$(basename $S_TEMPLATE)
  S_TEMPLATE_TARGET="${NGINX_ROOT}/conf.d/${S_TEMPLATE_FILE}.conf"

  echo "   - ${S_TEMPLATE} => ${S_TEMPLATE_TARGET}"
  
  if [ "${S_LIST}" == "" ]; then

    echo "   - [WARN] Substitution list is empty, skipping  substitution."
    echo "   - cp ${S_TEMPLATE} ${S_TEMPLATE_TARGET}"
    cp ${S_TEMPLATE} ${S_TEMPLATE_TARGET}
  
  else 
    
    echo "   - envsubst ${S_LIST} < ${S_TEMPLATE} > ${S_TEMPLATE_TARGET}"
    envsubst ${S_LIST} < ${S_TEMPLATE} > ${S_TEMPLATE_TARGET}
  
  fi

  if [ "${S_DEBUG}" == "-d" ]; then
     show_content ${S_TEMPLATE_TARGET}
  fi

done

echo ""
echo "3. Starting NginX.."

nginx -g "daemon off;"
