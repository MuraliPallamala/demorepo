# Reverse NginX Proxy for CouchDb Instances in QA

This custom image of NginX is designed to front the CouchDb instances that are deployed in the internal QA environment. The image is based on a custom version of the bg-nginx container that is used to reverse proxy the portals, that has been specifically modified to only expose the portals. 

The repository already comes configured with a collection of certificates that can be used to try the solution locally and are designed to expose the domain name: `qa.dlt.res.ibm.com`. In order to enable this server to run on your local machine via the `docker-compose up` command, include the following mapping to the `/etc/hosts` file:

```
    127.0.0.1       qa.dlt.res.ibm.com
``` 

Once this mapping is done you can install the `qa.CLIENT.p12` into your keychain or certificate store for allowing the browser to connect to the website.

To run, just execute:

```
    make build
    docker-compose up
```

The following endpoint should be available:

- https://qa.dlt.res.ibm.com:460/
- https://qa.dlt.res.ibm.com:461/
- https://qa.dlt.res.ibm.com:462/
- https://qa.dlt.res.ibm.com:463/
- https://qa.dlt.res.ibm.com:464/
- https://qa.dlt.res.ibm.com:466/


