# QA Internal Environment

Root folder for th Reverse Proxy mapping the CouchDb Servers.

DO NOT DELETE THIS FILE.

