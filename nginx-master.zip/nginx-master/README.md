# NginX Reverse Proxy for Bank Guarantee

[![Build Status](https://travis.ibm.com/shared-kyc/nginx.svg?token=Cx8NfmCxFfkpMqExE3LM&branch=master)](https://travis.ibm.com/shared-kyc/nginx)

## How to Run This?

_**Environment Setup**_

Open the `/etc/hosts` file:

```$ sudo vi /etc/hosts```

and add the following line:

```
127.0.0.1      bank-guarantee.res.ibm.com
127.0.0.1      admin.bank-guarantee.res.ibm.com
```


This will allow you to access localhost using the fake-domain bank-guarantee.res.ibm.com.


_**Build**_

Run:

```
make clean build
```

to build a new Docker container called `bg-nginx`

_**Use**_

Start the container using the docker-compose script:

```docker-compose up```

or

```make start```

This will allow you to access:

* https://bank-guarantee.res.ibm.com/* (redirect to localhost:3000 `bg-portal` _user/newco_)
* https://bank-guarantee.res.ibm.com/admin* (redirect to localhost:3100 `bg-portal` _admin/newco_)
* https://bank-guarantee.res.ibm.com/api/* (redirect to localhost:9080 `bg-newco-api` _user_)
* https://bank-guarantee.res.ibm.com/admin/api/* (redirect to localhost:9082 `bg-newco-admin-api` _admin_)
* https://bank-guarantee.res.ibm.com/service/* (redirect to localhost:9081 `bg-service-api` for `bg-newco-api`)
* https://bank-guarantee.res.ibm.com:444/* (redirect to localhost:4000 `bg-portal` _user/anz_)
* https://bank-guarantee.res.ibm.com:444/api/* (redirect to localhost:9090 `bg-issuer-api`)
* https://bank-guarantee.res.ibm.com:444/service/* (redirect to localhost:9091 `bg-service-api` for `bg-issuer-api`)

You can adjust the docker-compose config to use different endpoints for the various redirects,
keeping in mind that `$LOCAL_IP` will refer to your local machine (outside any docker environment)

## General Information

This repository contains a specialization of the NginX official image to serve as secure reverse proxy for the applications that compose the Bank Guarantees solution.

The proxy is based on the `library/nginx:1.13.3-alpine` image of NginX, which allows for a very small footprint. By using this basis we have added only the `openssl`
package to be able to generate the Diffie-Hellman parameters required for Ellyptic Curve Cryptography algorithms.

The configuration of the NginX server has been locked down to only allow for a limited set of supported protocols and cyphers that are considered today secure. This
allows us to expose all the Bank Guarantee application components through a secure HTTPS reverse proxy.

## Configuring the Reverse Proxy

The image has been designed to be fully configurable in terms of the backend components that are served. It is possible to customize the number of applications exposed
through the reverse proxy by adding a `<service-name>.template` file in the `services` directory. The build process of the image will automatically include all the
template files in the NginX configuration.

Here is a sample file of the for an additional service that needs to be exposed through the reverse proxy:

```
# http {
#    server {
        location /exposed-path {

           proxy_pass ${ENV_VAR_POINTING_TO_SERVICE_URL};

           # Put any configuration here that is required
           # to customize the connectivity with the
           # backend component.
        }
#    }
# }
```

By default the image is designed to apply environment variable substitution for any variable found in the template files that starts with `TMPL_`. Therefore, given that in services we have:

```
# http {
#    server {
        location /service {

           proxy_pass ${TMPL_SERVICE_URL};

           # Put any configuration here that is required
           # to customize the connectivity with the
           # backend component.
        }
#    }
# }    
```

More examples are in the folder: `/services/` one for the proxying a website (`portal.template.sample`) and another for proxying REST APIs (`api.template.sample`).

the following command will be able to configure the reverse proxy to service located at: `http://my-server:9090`:

```
   docker run --name nginx-reverse-proxy                                     \
              -e TMPL_SERVICE_URL=http://my-server:9090                      \
              -v /path/to/cert.key:/etc/nginx/certs/server.key               \
              -v /path/to/cert.chain.pem:/etc/nginx/certs/server.chain.pem   \
              -p "80:80"                                                     \
              -p "443:443"                                                   \
              shared-kyc/nginx:latest
```

Should we need to use variables with different prefix (i.e. `API_`) we can invoke the initialization script of the container with the prefix as follows:

```

   docker run --name nginx-reverse-proxy                                     \
              -e TMPL_SERVICE_URL=http://my-server:9090                      \
              -v /path/to/cert.key:/etc/nginx/certs/server.key               \
              -v /path/to/cert.chain.pem:/etc/nginx/certs/server.chain.pem   \
              -p "80:80"                                                     \
              -p "443:443"                                                   \
              shared-kyc/nginx:latest					     \
              /etc/nginx/init.sh API_
```

It is also possible to verify the output of the substitution by appending the `-d` switch command __after__ the prefix variable. This will make the script dump the content of the
generated `*.conf` files onto the standard output before starting the NginX server.

All this setup, is conveniently packaged in a `docker-compose.yml` and its corresponding `.env` file for the configuration required by Bank Guarantees.


## Building this Repository

### Local Build

The build is controlled by `make` and the following targets are available:

- `build`, `all` [default]: builds the docker image defined in this repository.
- `start`: this target depends logically on `build` and spins a container with the reverse proxy.
- `clean`: this target removes (if any) the running container and removes the image.
- `push` : this target depends logically on `build` and pushes the image to the docker registry configured for the project.

The make process can be customized with the following variables:

- `DOCKER_IMAGE_NAME` : by default is `shared-kyc/nginx:latest`
- `CONTAINER_NAME` : by default is `nginx`
- `COMMIT` : by default is `00000000` (used by the CI to inject commit information)
- `DOCKER_REGISTRY` : by default is `bit-docker-local.artifactory.swg-devops.com`
- `<component-name>_URL` : these variables point to the corresponding containers in the test server.

For more details about the configuration with `make` please see the [Makefile].  

### CI Build

The continuous integration build process is run in [Travis](travis.ibm.com). The build process is controlled by the [.travis.yml] file and uses [Swiss-Knife](https://github.ibm.com/shared-kyc/swiss-knife) for controlling
the life cycle of the build process.

### Environment Variables

Currently, when starting nginx, the following environment variables are expected to be passed in to the container:

| Env Variable  | Mandatory | Default value | Description |
| ------------- | ------------- | ------------- | ------------- | 
| `TMPL_HOST_NAME`  | Required  | - | Hostname of the nginx server.  |
| `TMPL_WEB_ROOT`  | Required  | - | Root folder to have a mount point for static content. |
| `TMPL_WEBSERVER_CERT_FILEPATH`  | Required  | - | The web server should always have TLS communication enabled. This variable specifies the file path of the certificate in the PEM format for the web server. |
| `TMPL_WEBSERVER_CERT_KEY_FILEPATH`  | Required  | - | This variable specifies the file path of the private key in the PEM format for the web server. |
| `TMPL_RATE_LIMIT_IN_REQUESTS_PER_SECOND`  | Required  | - |  Used for rate limiting configuration for POST requests to the API upstream server. |
| | | | |
| **`SSL_CLIENT`**| Optional  | `true` | When true, enables client certificate validation. |
| `TMPL_CLIENTCERT_CA_FILEPATH`  | Required if `SSL_CLIENT` is `true`  | - |  File path of CA certificate to be used for the client certificate validation. |
| `TMPL_CLIENT_VERIFY_DEPTH`  | Required if `SSL_CLIENT` is `true`  | - | Depth of the verification process of the trust chain associated to the client certificate. This is useful if we use intermediate certificates to sign the client certificates that are distributed to application clients.  |
| | | | |
| **`SSL_CLIENT_CERT_AUTHENTICATION`** | Optional  | `true` | When true, allows specifying client certificates that should be presented to the upstream server in case the upstream server requires client certificate validation. |
| `TMPL_UPSTREAM_CLIENTCERT_FILEPATH`  | Required if `SSL_CLIENT_CERT_AUTHENTICATION` is `true` | - |  File path of the client certificate that will be used to authenticate nginx with the upstream server. |
| `TMPL_UPSTREAM_CLIENTCERT_KEY_FILEPATH`  | Required if `SSL_CLIENT_CERT_AUTHENTICATION` is `true`  | - | File path of the client certificate private key that will be used for authentication of nginx with the upstream server.  |
| | | | |
| **`OCSP_STAPLING`** | Optional | `false` | When true,  allows for checking the revocation status of a certificate.|
| `TMPL_OCSP_TRUSTED_CHAIN_PATH`  | Required if `OCSP_STAPLING` is `true`  | - | File path of the trusted certificate.  |
| `TMPL_OCSP_DNS`  | Required if `OCSP_STAPLING` is `true`  | - | DNS resolver  |
| | | | |
| **`STRICT_TRANSPORT_SECURITY`**  | Optional | `true` | When true,  it essentially communicates to the browsers that they should always try to use HTTPS to contact this server.|
| | | | |
| `TMPL_API_URL`  | Required for api.template only  | - |  Applies to the API template which defines settings for communication with the API upstream server. This variable specifies the URL of the upstream API server.  |
| `TMPL_UPSTREAM_CA_FILEPATH`  | Required for api.template only | - | Applies to the API template. This variable specifies the file path of the CA certificate necessary to establish TLS connection with the upstream API server. |
| `TMPL_MAX_CLIENT_BODY_SIZE`  | Required for api.template only | - | Applies to the API template. It specifies the max client body size. |
| `TMPL_RATE_LIMIT_BURST`  | Required   for api.template only| - |   Used for rate limiting configuration for POST requests to the API upstream server. |


