package main

import (
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/guarantee/gx"

	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
)

var logger = shim.NewLogger("guarantee")

func main() {
	err := guaranteePB.StartCC(new(gx.APICC))

	if err != nil {
		logger.Errorf("Error starting chaincode: %s", err)
	}
}
