package main

import (
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/organization"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/purposeformat"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/tc"

	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
)

var logger = shim.NewLogger("profile")

func main() {
	err := profilePB.StartCC(
		new(organization.APICC),
		new(purposeformat.APICC),
		new(tc.APICC))

	if err != nil {
		logger.Errorf("Error starting chaincode: %s", err)
	}
}
