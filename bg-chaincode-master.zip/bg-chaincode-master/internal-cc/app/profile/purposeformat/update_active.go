package purposeformat

import (
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

// UpdateActiveStatus updates a specific purpose format to the provided active status
func (t *APICC) UpdateActiveStatus(stub *profilePB.ChaincodeStub, update *sharedPB.PurposeFormatUpdate) (*sharedPB.IDValue, error) {

	purposeFormat, err := t.Get(stub, &sharedPB.IDValue{Value: update.GetFormatId()})

	if err != nil {
		return nil, err
	}

	purposeFormat.Active = update.GetActiveStatus()

	pfKey, err := generatePFKey(stub, purposeFormat.GetId())
	if err != nil {
		return nil, err
	}
	err = ccutil.PutStatePB(stub, pfKey, purposeFormat)
	if err != nil {
		return nil, err
	}

	event := &profilePB.OrganizationEvent{
		Id:        stub.GetTxID(),
		CreatedAt: purposeFormat.GetCreatedAt(),
		Payload: &profilePB.OrganizationEvent_PurposeFormatEvent{
			PurposeFormatEvent: &profilePB.PurposeFormatEvent{
				PurposeFormat: purposeFormat,
			},
		},
	}

	// Store Event
	err = StorePurposeFormatEvent(stub, event)
	if err != nil {
		return nil, err
	}

	// Emit Event
	err = stub.SetUpdatePurposeFormatEvent(event)
	if err != nil {
		return nil, err
	}

	return &sharedPB.IDValue{Value: purposeFormat.GetId()}, nil
}
