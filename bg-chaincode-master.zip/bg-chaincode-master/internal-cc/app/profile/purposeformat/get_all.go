package purposeformat

import (
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// GetAll retrieves all existing purpose formats, regardless of whether they're active or not
func (t *APICC) GetAll(stub *profilePB.ChaincodeStub, empty *sharedPB.Empty) (*sharedPB.PurposeFormatList, error) {
	profileutil.Setup()
	// fetch iterator containing key/value pairs of matching entries
	iterator, err := GeneratePFIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	// init result
	var purposeFormats []*sharedPB.PurposeFormat

	for iterator.HasNext() {
		// retrieve item from key/value iterator
		pfKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		pfBytes := pfKV.GetValue()

		// unmarshal bytes
		var purposeFormat sharedPB.PurposeFormat
		err = ccutil.Unmarshal(pfBytes, &purposeFormat)
		if err != nil {
			return nil, err
		}

		// append to result list
		purposeFormats = append(purposeFormats, &purposeFormat)
	}

	return &sharedPB.PurposeFormatList{Formats: purposeFormats}, nil
}
