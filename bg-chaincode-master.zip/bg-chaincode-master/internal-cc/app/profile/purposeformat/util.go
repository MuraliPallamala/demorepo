package purposeformat

import (
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// APICC is a concrete implementation of the generated interface PurposeFormatAPIInterface
type APICC struct{}

func generatePFKey(stub shim.ChaincodeStubInterface, formatID string) (string, error) {
	return stub.CreateCompositeKey(profileutil.OTPurposeFormat, []string{formatID})
}

// GeneratePFIterator generates an interator over all PurposeFormats
func GeneratePFIterator(stub shim.ChaincodeStubInterface) (shim.StateQueryIteratorInterface, error) {
	return stub.GetStateByPartialCompositeKey(profileutil.OTPurposeFormat, []string{})
}

// StorePurposeFormatEvent saves the event on the blockchain for later retrieval in case the service API missed it
func StorePurposeFormatEvent(stub *profilePB.ChaincodeStub, event *profilePB.OrganizationEvent) error {
	eventKey, err := generatePurposeFormatEventKey(stub, event.GetId())
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, eventKey, event)
	return err
}

func generatePurposeFormatEventKey(stub shim.ChaincodeStubInterface, eventID string) (string, error) {
	return stub.CreateCompositeKey(profileutil.OTOrganizationEvents, []string{eventID})
}
