package purposeformat

import (
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// Get retrieves an existing purpose format
func (t *APICC) Get(stub *profilePB.ChaincodeStub, idValue *sharedPB.IDValue) (*sharedPB.PurposeFormat, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Getting TC for ID: %v\n", idValue)

	var pf sharedPB.PurposeFormat
	pfKey, err := generatePFKey(stub, idValue.GetValue())
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, pfKey, &pf)
	return &pf, err
}
