package purposeformat

import (
	"fmt"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

// Create adds a new purpose format
func (t *APICC) Create(stub *profilePB.ChaincodeStub, purposeFormat *sharedPB.PurposeFormat) (*sharedPB.IDValue, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Processing PF Create request %v\n", purposeFormat)
	ccutil.Logger.Info("Request CREATE Purpose Format\n")

	if purposeFormat.GetId() == "" {
		return nil, fmt.Errorf("ID cannot be empty")
	}

	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}
	creatorOrganizationID, err := profileutil.GetOrganizationIDFromCert(stub, creatorCert)
	if err != nil {
		return nil, err
	}
	err = ccutil.SetCreatedMetadata(stub, purposeFormat, creatorOrganizationID)
	if err != nil {
		return nil, err
	}

	pfKey, err := generatePFKey(stub, purposeFormat.GetId())
	if err != nil {
		return nil, err
	}

	err = ccutil.PutStatePB(stub, pfKey, purposeFormat)
	if err != nil {
		return nil, err
	}

	event := &profilePB.OrganizationEvent{
		Id:        stub.GetTxID(),
		CreatedAt: purposeFormat.GetCreatedAt(),
		Payload: &profilePB.OrganizationEvent_PurposeFormatEvent{
			PurposeFormatEvent: &profilePB.PurposeFormatEvent{
				PurposeFormat: purposeFormat,
			},
		},
	}

	// Store Event
	err = StorePurposeFormatEvent(stub, event)
	if err != nil {
		return nil, err
	}

	// Emit Event
	err = stub.SetCreatePurposeFormatEvent(event)
	if err != nil {
		return nil, err
	}

	return &sharedPB.IDValue{Value: purposeFormat.GetId()}, nil
}
