package tc

import (
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// APICC is a concrete implementation of the generated interface TermsConditionsAPIInterface
type APICC struct{}

func generateTCKey(stub shim.ChaincodeStubInterface, tcID string) (string, error) {
	return stub.CreateCompositeKey(profileutil.OTTermsConditions, []string{tcID})
}

// GenerateTCIterator generates an interator over all TCs
func GenerateTCIterator(stub shim.ChaincodeStubInterface) (shim.StateQueryIteratorInterface, error) {
	return stub.GetStateByPartialCompositeKey(profileutil.OTTermsConditions, []string{})
}
