package tc

import (
	"fmt"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

// Create adds a new Terms and Conditions
func (t *APICC) Create(stub *profilePB.ChaincodeStub, termsConditions *profilePB.TermsConditions) (*sharedPB.IDValue, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Processing TC Create request %v\n", termsConditions)
	ccutil.Logger.Infof("Create TERMS and CONDITIONS (title: %v, scope: %v)\n", termsConditions.Title, termsConditions.Scope)

	if termsConditions.GetId() == "" {
		return nil, fmt.Errorf("ID cannot be empty")
	}

	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}
	creatorOrganizationID, err := profileutil.GetOrganizationIDFromCert(stub, creatorCert)
	if err != nil {
		return nil, err
	}
	err = ccutil.SetCreatedMetadata(stub, termsConditions, creatorOrganizationID)
	if err != nil {
		return nil, err
	}

	tcKey, err := generateTCKey(stub, termsConditions.GetId())
	if err != nil {
		return nil, err
	}

	termsConditions.Active = true

	err = ccutil.PutStatePB(stub, tcKey, termsConditions)
	if err != nil {
		return nil, err
	}

	return &sharedPB.IDValue{Value: termsConditions.GetId()}, nil
}
