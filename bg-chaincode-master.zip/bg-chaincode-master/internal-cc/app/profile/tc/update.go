package tc

import (
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

// Update updates a specific T&Cs document to the provided active status
func (t *APICC) Update(stub *profilePB.ChaincodeStub, termsConditionsUpdate *profilePB.TermsConditionsUpdateRequest) (*sharedPB.IDValue, error) {

	termsConditions, err := t.Get(stub, &sharedPB.IDValue{Value: termsConditionsUpdate.GetId()})

	if err != nil {
		return nil, err
	}

	termsConditions.Active = termsConditionsUpdate.GetActiveStatus()

	tcKey, err := generateTCKey(stub, termsConditionsUpdate.GetId())
	if err != nil {
		return nil, err
	}
	err = ccutil.PutStatePB(stub, tcKey, termsConditions)
	if err != nil {
		return nil, err
	}

	return &sharedPB.IDValue{Value: termsConditions.GetId()}, nil
}
