package tc

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

// test search with no search parameters defined
func TestSearch(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	tcTypePLATFORM := profilePB.TermsConditionsScope_PLATFORM
	tcTypeBG := profilePB.TermsConditionsScope_BANK_GUARANTEE

	// create two T&C records with different titles and scope
	tcID1 := "test 1"
	tc1 := generateExampleTermsConditionsBytes(t, tcID1, "example title 1", tcTypePLATFORM, nil)
	args := [][]byte{[]byte(ccMethods.Create), tc1}
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	tcID2 := "test2"
	tc2 := generateExampleTermsConditionsBytes(t, tcID2, "example title 2", tcTypeBG, nil)
	args = [][]byte{[]byte(ccMethods.Create), tc2}
	txID2 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID2, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	// search for record without any search parameters specified
	args = [][]byte{[]byte(ccMethods.Search), generateExampleSearchRequestBytes(t, "", nil)}
	txID3 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID3, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get t&c: %s", string(res.Message))
	}

	// test that all T&C records are returned
	var responsePayload profilePB.TermsConditionsList
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetTermsConditions()) != 2 {
		t.Fatalf("Expected two T&C records returned, but got: %v", responsePayload.GetTermsConditions())
	}
}

// test get all with title search parameter defined
func TestGetAllTitle(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	title1 := "example title 1"
	// create two T&C records with different titles and scope
	tcID1 := "test1"
	tc1 := generateExampleTermsConditionsBytes(t, tcID1, title1, profilePB.TermsConditionsScope_PLATFORM, nil)
	args := [][]byte{[]byte(ccMethods.Create), tc1}
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	tcID2 := "test2"
	tc2 := generateExampleTermsConditionsBytes(t, tcID2, "example title 2", profilePB.TermsConditionsScope_BANK_GUARANTEE, nil)
	args = [][]byte{[]byte(ccMethods.Create), tc2}
	txID2 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID2, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	// search for T&C records with a non-existent title
	args = [][]byte{[]byte(ccMethods.Search), generateExampleSearchRequestBytes(t, "Wrong title", nil)}
	txID3 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID3, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get t&c: %s", string(res.Message))
	}

	// test that no search results were returned
	var responsePayload profilePB.TermsConditionsList
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetTermsConditions()) != 0 {
		t.Fatalf("Expected empty tc response, but got: %v", responsePayload.GetTermsConditions())
	}

	// search for T&C records with title1
	args = [][]byte{[]byte(ccMethods.Search), generateExampleSearchRequestBytes(t, title1, nil)}
	txID5 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID5, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get t&c: %s", string(res.Message))
	}

	// Test that only T&C record with title1 is returned
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetTermsConditions()) != 1 {
		t.Fatalf("Expected one T&C record returned, but got: %v", responsePayload.GetTermsConditions())
	}
}

// Test get all with scope search parameters defined
func TestGetAllScope(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	tcScopePLATFORM := profilePB.TermsConditionsScope_PLATFORM
	tcScopeBG := profilePB.TermsConditionsScope_BANK_GUARANTEE

	// create two T&C records of type platform
	tcID1 := "test1"
	tc1 := generateExampleTermsConditionsBytes(t, tcID1, "example title", tcScopePLATFORM, nil)
	args := [][]byte{[]byte(ccMethods.Create), tc1}
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	tcID2 := "test2"
	tc2 := generateExampleTermsConditionsBytes(t, tcID2, "example title", tcScopePLATFORM, nil)
	args = [][]byte{[]byte(ccMethods.Create), tc2}
	txID2 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID2, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	// search for T&C record of type bank guarantee
	args = [][]byte{[]byte(ccMethods.Search), generateExampleSearchRequestBytes(t, "", &profilePB.TermsConditionsScopeValue{Value: tcScopeBG})}
	txID3 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID3, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get t&c: %s", string(res.Message))
	}

	// test that no search results were returned
	var responsePayload profilePB.TermsConditionsList
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetTermsConditions()) != 0 {
		t.Fatalf("Expected empty tc response, but got: %v", responsePayload.GetTermsConditions())
	}

	// create a T&C record of type bank guarantee
	tcID3 := "test3"
	tc3 := generateExampleTermsConditionsBytes(t, tcID3, "example title", tcScopeBG, nil)
	args = [][]byte{[]byte(ccMethods.Create), tc3}
	txID4 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID4, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	// search for T&C records of type platform
	args = [][]byte{[]byte(ccMethods.Search), generateExampleSearchRequestBytes(t, "", &profilePB.TermsConditionsScopeValue{Value: tcScopePLATFORM})}
	txID5 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID5, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get t&c: %s", string(res.Message))
	}

	// Test that only T&C records with type platform are returned
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetTermsConditions()) != 2 {
		t.Fatalf("Expected two T&C records returned, but got: %v", responsePayload.GetTermsConditions())
	}
}

// test get all with scope and title search parameters defined
func TestGetAllTitleAndScope(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	title1 := "Title 1"
	title2 := "Title 2"

	// Create T&C record of with title1 and type platform
	tcID1 := "test1"
	tc1 := generateExampleTermsConditionsBytes(t, tcID1, title1, profilePB.TermsConditionsScope_PLATFORM, nil)
	args := [][]byte{[]byte(ccMethods.Create), tc1}
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	// Create T&C record of with title1 and type platform
	tcID2 := "test2"
	tc2 := generateExampleTermsConditionsBytes(t, tcID2, title2, profilePB.TermsConditionsScope_PLATFORM, nil)
	args = [][]byte{[]byte(ccMethods.Create), tc2}
	txID2 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID2, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	// Create a T&C record of type bank guarantee
	tcID3 := "test3"
	tc3 := generateExampleTermsConditionsBytes(t, tcID3, "example title", profilePB.TermsConditionsScope_BANK_GUARANTEE, nil)
	args = [][]byte{[]byte(ccMethods.Create), tc3}
	txID4 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID4, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	// Search for T&C records of type platform with title1
	args = [][]byte{[]byte(ccMethods.Search), generateExampleSearchRequestBytes(t, title1, &profilePB.TermsConditionsScopeValue{Value: profilePB.TermsConditionsScope_PLATFORM})}
	txID5 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID5, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get t&c: %s", string(res.Message))
	}

	// Test that only T&C records with title1 and of type platform are returned
	var responsePayload profilePB.TermsConditionsList
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetTermsConditions()) != 1 {
		t.Fatalf("Expected one T&C record returned, but got: %v", responsePayload.GetTermsConditions())
	}

}
