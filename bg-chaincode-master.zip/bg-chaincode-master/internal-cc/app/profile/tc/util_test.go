package tc

import (
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/organization"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/purposeformat"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

/*
Utility functions
*/

var ccMethods = ccutil.CCMethods.Profile.TC

func setupChaincodeMockStub(t *testing.T) *cctest.MockStub {
	return profiletest.SetupChaincodeMockStub(t, new(organization.APICC), new(purposeformat.APICC), new(APICC))
}

func generateExampleTermsConditions(t *testing.T, id string, title string, tcScope profilePB.TermsConditionsScope, content *profilePB.TermsConditionsContent) profilePB.TermsConditions {
	return profilePB.TermsConditions{
		Id:      id,
		Title:   title,
		Content: content,
		Scope:   tcScope,
	}
}

func generateExampleTermsConditionsBytes(t *testing.T, id string, title string, tcScope profilePB.TermsConditionsScope, content *profilePB.TermsConditionsContent) []byte {
	tc := generateExampleTermsConditions(t, id, title, tcScope, content)

	b, err := ccutil.Marshal(&tc)
	if err != nil {
		t.Fatalf("Could not marshal TermsConditions: %s", err.Error())
	}

	return b
}

func generateExampleSearchRequest(t *testing.T, title string, scopeValue *profilePB.TermsConditionsScopeValue) profilePB.TermsConditionsSearchRequest {
	return profilePB.TermsConditionsSearchRequest{
		Title: title,
		Scope: scopeValue,
	}
}

func generateExampleSearchRequestBytes(t *testing.T, title string, scopeValue *profilePB.TermsConditionsScopeValue) []byte {

	getAllRequest := generateExampleSearchRequest(t, title, scopeValue)

	bytes, err := ccutil.Marshal(&getAllRequest)
	if err != nil {
		t.Fatalf("Could not marshal GetAllRequest: %s", err.Error())
	}

	return bytes
}
