package tc

import (
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// Search retrieves existing Terms and Conditions based off scope (e.g. Platform or BG) and/or title
func (t *APICC) Search(stub *profilePB.ChaincodeStub, request *profilePB.TermsConditionsSearchRequest) (*profilePB.TermsConditionsList, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Searching TC with parameters: %v\n", request)

	iterator, err := GenerateTCIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var tcs []*profilePB.TermsConditions

	for iterator.HasNext() {
		tcKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		tcBytes := tcKV.GetValue()

		var tc profilePB.TermsConditions
		err = ccutil.Unmarshal(tcBytes, &tc)
		if err != nil {
			return nil, err
		}

		// check which search parameters have been specified
		if (request.GetTitle() == "" || tc.GetTitle() == request.GetTitle()) && (request.GetScope() == nil ||
				request.GetScope().GetValue() == tc.GetScope()) && (!request.GetActiveStatus() || tc.GetActive() == true) {
			tcs = append(tcs, &tc)
		}
	}

	return &profilePB.TermsConditionsList{TermsConditions: tcs}, nil
}
