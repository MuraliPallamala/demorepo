package tc

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestGet(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	tcID := "test"
	tcScope := profilePB.TermsConditionsScope_PLATFORM

	// Test for failure when T&C doesn't exist
	args := [][]byte{[]byte(ccMethods.Get), profiletest.GenerateIDValueBytes(t, tcID)}
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status == shim.OK {
		t.Fatalf("Expected get to fail since t&c does not exist: %s", string(res.Message))
	}

	// create a record
	tc := generateExampleTermsConditionsBytes(t, tcID, "example title", tcScope, nil)
	args = [][]byte{[]byte(ccMethods.Create), tc}
	txID2 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID2, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	args = [][]byte{[]byte(ccMethods.Get), profiletest.GenerateIDValueBytes(t, tcID)}
	txID3 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID3, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get t&c: %s", string(res.Message))
	}

	// Test that organization is returned
	// TODO find nice way to check all fields, currently only checking ID
	var responsePayload profilePB.TermsConditions
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if responsePayload.GetId() != tcID {
		t.Fatalf("Error incorrect t&c ID, expected: %s, got: %s", tcID, responsePayload.GetId())
	}

	if responsePayload.GetScope() != tcScope {
		t.Fatalf("Error incorrect t&c type, expected: %s, got: %s", tcScope, responsePayload.GetScope())
	}
}
