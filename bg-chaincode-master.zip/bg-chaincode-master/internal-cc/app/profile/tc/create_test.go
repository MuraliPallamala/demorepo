package tc

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestCreate(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	tcID := "test"
	tcScope := profilePB.TermsConditionsScope_PLATFORM
	tc := generateExampleTermsConditionsBytes(t, tcID, "example title", tcScope, nil)

	args := [][]byte{[]byte(ccMethods.Create), tc}

	// Test for successful invokes
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create T&C: %s", string(res.Message))
	}

	// Test that ID is returned
	var responsePayload sharedPB.IDValue
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// TODO check that t&c is correctly stored at returned ID
	if len(responsePayload.GetValue()) == 0 {
		t.Fatal("Error empty T&C ID returned")
	}

	if responsePayload.GetValue() != tcID {
		t.Fatalf("Error incorrect t&c ID, expected: %s, got: %s", tcID, responsePayload.GetValue())
	}
}
