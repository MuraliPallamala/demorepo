package organization

import (
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// GetPublicKeys retrieves the public keys of an Organization
func (t *APICC) GetPublicKeys(stub *profilePB.ChaincodeStub, idValue *sharedPB.IDValue) (*profilePB.OrganizationPublicKeyMap, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Getting public keys for ID: %v\n", idValue)

	var organizationPublicKeyMap profilePB.OrganizationPublicKeyMap
	organizationPublicKeyMapKey, err := generateOrganizationPublicKeyMapKey(stub, idValue.GetValue())
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, organizationPublicKeyMapKey, &organizationPublicKeyMap)
	return &organizationPublicKeyMap, err
}
