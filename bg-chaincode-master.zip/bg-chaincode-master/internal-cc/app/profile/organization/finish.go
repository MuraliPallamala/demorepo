package organization

import (
	"fmt"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

func finishOrganizationCreate(stub *profilePB.ChaincodeStub, organizationCreateRequest *profilePB.OrganizationCreateRequest) error {
	organization := organizationCreateRequest.GetOrganization()

	// Check that organization does not exist
	organizationKey, err := generateOrganizationKey(stub, organizationCreateRequest.GetOrganization().GetId())
	if err != nil {
		return err
	}
	err = ccutil.GetStatePB(stub, organizationKey, organizationCreateRequest.GetOrganization())
	if err == nil {
		return fmt.Errorf("Organization %s already onboarded", organizationCreateRequest.GetOrganization().GetId())
	}

	// Add Organization metadata
	err = ccutil.SetFlowResultCreatedMetadata(stub, organizationCreateRequest, organization)
	if err != nil {
		return err
	}
	// Put Organization into state
	err = ccutil.PutStatePB(stub, organizationKey, organization)
	if err != nil {
		return err
	}

	// Put PublicKeyMap into state
	cert, err := ccutil.PEMToCert(organizationCreateRequest.GetAdminCertificate())
	if err != nil {
		return err
	}
	organizationPublicKeyString, err := ccutil.GetPublicKeyPEMFromCertPEM(organizationCreateRequest.GetAdminCertificate())
	if err != nil {
		return err
	}
	var organizationPublicKeyMap profilePB.OrganizationPublicKeyMap
	organizationPublicKeyMap.Map = make(map[string]*profilePB.OrganizationPublicKey)
	defaultPublicKey := &profilePB.OrganizationPublicKey{
		Key: organizationPublicKeyString,
		AllowedTimeRanges: []*sharedPB.DateRange{
			&sharedPB.DateRange{
				StartDate: organizationCreateRequest.GetCreatedAt(),
			},
		},
	}

	// store under hash
	keyHash := ccutil.HashS(organizationPublicKeyString)
	organizationPublicKeyMap.Map[keyHash] = defaultPublicKey

	// store under "default" key for easy usage by clients
	organizationPublicKeyMap.Map["default"] = defaultPublicKey

	organizationPublicKeyMapKey, err := generateOrganizationPublicKeyMapKey(stub, organization.GetId())
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, organizationPublicKeyMapKey, &organizationPublicKeyMap)
	if err != nil {
		return err
	}

	// Link public key to organization ID
	err = profileutil.LinkCertificateToOrganizationID(stub, cert, organization.GetId())
	if err != nil {
		return err
	}

	// Finalise flow
	flowID := organizationCreateRequest.GetId()
	statusKey, err := profileutil.GenerateFlowStatusKey(stub, flowID)
	if err != nil {
		return err
	}

	err = ccutil.PutStateInt(stub, statusKey, int(sharedPB.FlowStatus_FLOW_APPROVED))
	if err != nil {
		return err
	}

	// Emit event
	return storeAndEmitCreateOrganizationEvent(stub, organization)
}

func storeAndEmitCreateOrganizationEvent(stub *profilePB.ChaincodeStub, organization *profilePB.Organization) error {
	createdAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}
	event := &profilePB.OrganizationEvent{
		Id:        stub.GetTxID(),
		CreatedAt: createdAt,
		Payload: &profilePB.OrganizationEvent_CreateOrganizationEvent{
			CreateOrganizationEvent: &profilePB.CreateOrganizationEvent{
				Organization: organization,
			},
		},
	}

	ccutil.Logger.Debugf("Storing+Emitting CreateOrganization Event %v\n", event)
	ccutil.Logger.Infof("Triggering EVENT <Create Organization> (id: %v, organizationId: %v)\n", event.Id, organization.Id)

	// Store Event
	err = StoreOrganizationEvent(stub, event)
	if err != nil {
		return err
	}

	// Emit Event
	err = stub.SetCreateOrganizationEvent(event)
	return err
}

func finishOrganizationProfileChange(stub *profilePB.ChaincodeStub, profileChangeRequest *profilePB.OrganizationProfileChangeRequest) error {
	var organization profilePB.Organization
	organizationKey, err := generateOrganizationKey(stub, profileChangeRequest.GetOrganizationId())
	if err != nil {
		return err
	}
	err = ccutil.GetStatePB(stub, organizationKey, &organization)
	if err != nil {
		return err
	}
	organizationKey, err = generateOrganizationKey(stub, organization.GetId())
	if err != nil {
		return err
	}

	// Update Organization object fields
	updateOrganization(&organization, profileChangeRequest.GetEntityName(), profileChangeRequest.GetAddress(), profileChangeRequest.GetStatus())

	// Add Organization metadata
	err = ccutil.SetFlowResultUpdatedMetadata(stub, profileChangeRequest, &organization)
	if err != nil {
		return err
	}

	// Put organization into state
	err = ccutil.PutStatePB(stub, organizationKey, &organization)
	if err != nil {
		return err
	}

	// Finalise flow
	flowID := profileChangeRequest.GetId()

	statusKey, err := profileutil.GenerateFlowStatusKey(stub, flowID)
	if err != nil {
		return err
	}

	err = ccutil.PutStateInt(stub, statusKey, int(sharedPB.FlowStatus_FLOW_APPROVED))
	if err != nil {
		return err
	}

	// Emit event
	return storeAndEmitProfileChangeEvent(stub, &organization)
}

func storeAndEmitProfileChangeEvent(stub *profilePB.ChaincodeStub, organization *profilePB.Organization) error {
	createdAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}
	event := &profilePB.OrganizationEvent{
		Id:        stub.GetTxID(),
		CreatedAt: createdAt,
		Payload: &profilePB.OrganizationEvent_ProfileChangeEvent{
			ProfileChangeEvent: &profilePB.ProfileChangeEvent{
				Organization: organization,
			},
		},
	}

	ccutil.Logger.Debugf("Storing+Emitting ProfileChange Event %v\n", event)
	ccutil.Logger.Infof("Triggering EVENT <Update Organization> (id: %v, requestId: %v)\n", event.Id, organization.Id)

	// Store Event
	err = StoreOrganizationEvent(stub, event)
	if err != nil {
		return err
	}

	// Emit Event
	err = stub.SetProfileChangeEvent(event)
	return err
}

func updateOrganization(organization *profilePB.Organization, entityName string, address *sharedPB.AddressValue, status *profilePB.OrganizationStatusValue) {
	// TODO investigate whether there is a better approach
	if entityName != "" {
		organization.EntityName = entityName
	}
	if address != nil {
		organization.Address = address.GetValue()
	}
	if status != nil {
		organization.Status = status.GetValue()
	}
}
