package organization

import (
	"errors"
	"fmt"
	"strings"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"

	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

// StartFlow handles the start of a new Flow
func (t *APICC) StartFlow(stub *profilePB.ChaincodeStub, organizationStartRequest *profilePB.OrganizationStartRequest) (*sharedPB.FlowIDValue, error) {
	profileutil.Setup()
	ccutil.Logger.Debugf("Processing StartFlow request %v\n", organizationStartRequest)
	ccutil.Logger.Info("Request CREATE flow\n")

	switch t := organizationStartRequest.Request.(type) {
	case *profilePB.OrganizationStartRequest_CreateRequest:
		return startCreateOrganization(stub, organizationStartRequest.GetCreateRequest())
	case *profilePB.OrganizationStartRequest_ProfileChangeRequest:
		return startOrganizationProfileChange(stub, organizationStartRequest.GetProfileChangeRequest())
	default:
		return nil, fmt.Errorf("Invalid Request Type %T", t)
	}
}

func startCreateOrganization(stub *profilePB.ChaincodeStub, organizationCreateRequest *profilePB.OrganizationCreateRequest) (*sharedPB.FlowIDValue, error) {
	// Check whether issuer is a part of the consortium organization
	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}

	isConsortium, err := ccutil.IsConsortium(stub, creatorCert)
	if err != nil {
		return nil, err
	}
	if !isConsortium {
		return nil, errors.New("StartFlow CreateOrganization is a consortium only operation")
	}

	// Check that organization does not exist
	organizationKey, err := generateOrganizationKey(stub, organizationCreateRequest.GetOrganization().GetId())
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, organizationKey, organizationCreateRequest.GetOrganization())
	if err == nil {
		return nil, fmt.Errorf("Organization %s already onboarded", organizationCreateRequest.GetOrganization().GetId())
	}

	if organizationCreateRequest.GetSelfOnboarding() {
		timestamp, err := ccutil.GetTxTimestamp(stub)
		if err != nil {
			return nil, err
		}
		organizationCreateRequest.CreatedBy = organizationCreateRequest.GetOrganization().GetId()
		organizationCreateRequest.CreatedAt = timestamp
		pem, err := ccutil.GetCreatorPEM(stub)
		if err != nil {
			return nil, err
		}
		organizationCreateRequest.AdminCertificate = pem
	} else {
		// Check that certificate has't been used before
		orgCert, err := ccutil.PEMToCert(organizationCreateRequest.GetAdminCertificate())
		if err != nil {
			return nil, err
		}
		existingOrgID, err := profileutil.GetOrganizationIDFromCert(stub, orgCert)
		if existingOrgID != "" {
			return nil, fmt.Errorf("Public key is already used and is linked to %s", existingOrgID)
		}
		// TODO HACK refactor to have distinct error types
		if err != nil && !strings.Contains(err.Error(), "does not exist") {
			return nil, err
		}

		creatorOrganizationID, err := profileutil.GetOrganizationIDFromCert(stub, creatorCert)
		if err != nil {
			return nil, err
		}

		ccutil.SetCreatedMetadata(stub, organizationCreateRequest, creatorOrganizationID)
	}

	flowID := ccutil.GenerateFlowID(stub)

	organizationCreateRequest.Id = flowID

	// store as startRequest to keep consistancy with type of request sent
	startRequest := &profilePB.OrganizationStartRequest{Request: &profilePB.OrganizationStartRequest_CreateRequest{CreateRequest: organizationCreateRequest}}
	err = putStartFlow(stub, flowID, startRequest)
	if err != nil {
		return nil, err
	}

	return &sharedPB.FlowIDValue{Value: flowID}, nil
}

func startOrganizationProfileChange(stub *profilePB.ChaincodeStub, organizationProfileChangeRequest *profilePB.OrganizationProfileChangeRequest) (*sharedPB.FlowIDValue, error) {
	// Check whether issuer is a part of the consortium organization
	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}

	isConsortium, err := ccutil.IsConsortium(stub, creatorCert)
	if err != nil {
		return nil, err
	}
	if !isConsortium {
		return nil, errors.New("StartFlow ProfileChange is a consortium only operation")
	}

	// Check that organization exists
	organizationKey, err := generateOrganizationKey(stub, organizationProfileChangeRequest.GetOrganizationId())
	if err != nil {
		return nil, err
	}
	existingOrgBytes, err := stub.GetState(organizationKey)
	if err != nil {
		return nil, err
	}
	if len(existingOrgBytes) == 0 {
		return nil, fmt.Errorf("Organization %s does not exist", organizationProfileChangeRequest.GetOrganizationId())
	}

	creatorOrganizationID, err := profileutil.GetOrganizationIDFromCert(stub, creatorCert)
	if err != nil {
		return nil, err
	}

	ccutil.SetCreatedMetadata(stub, organizationProfileChangeRequest, creatorOrganizationID)

	flowID := ccutil.GenerateFlowID(stub)

	organizationProfileChangeRequest.Id = flowID

	// store as startRequest to keep consistancy with type of request sent
	startRequest := &profilePB.OrganizationStartRequest{Request: &profilePB.OrganizationStartRequest_ProfileChangeRequest{ProfileChangeRequest: organizationProfileChangeRequest}}

	err = putStartFlow(stub, flowID, startRequest)
	if err != nil {
		return nil, err
	}

	return &sharedPB.FlowIDValue{Value: flowID}, nil
}

func putStartFlow(stub *profilePB.ChaincodeStub, flowID string, startRequest *profilePB.OrganizationStartRequest) error {
	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, flowKey, startRequest)
	if err != nil {
		return err
	}
	// Handle case where no approvals are needed
	switch startRequest.Request.(type) {
	case *profilePB.OrganizationStartRequest_CreateRequest:
		// Does not require approvals
		return finishOrganizationCreate(stub, startRequest.GetCreateRequest())
	case *profilePB.OrganizationStartRequest_ProfileChangeRequest:
		if len(startRequest.GetProfileChangeRequest().GetRequiredApprovals()) == 0 {
			return finishOrganizationProfileChange(stub, startRequest.GetProfileChangeRequest())
		}
	default:
		// Do nothing
	}

	statusKey, err := profileutil.GenerateFlowStatusKey(stub, flowID)
	if err != nil {
		return err
	}
	ccutil.PutStateInt(stub, statusKey, int(sharedPB.FlowStatus_FLOW_ACTIVE))
	return err
}
