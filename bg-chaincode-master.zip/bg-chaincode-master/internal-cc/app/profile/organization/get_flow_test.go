package organization

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestGetFlowCreateProfile(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	newOrganizationID := "orgid2"
	newOrganization := profiletest.GenerateExampleOrganization(newOrganizationID)
	newOrganizationCertificate := cctest.ANZPEM
	startRequestBytes := profiletest.GenerateStartRequestCreateBytes(t, &profilePB.OrganizationCreateRequest{Organization: &newOrganization, AdminCertificate: newOrganizationCertificate})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Invoke start flow
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start create flow: %s", string(res.Message))
	}

	// Test that flow ID is returned
	var startFlowResponsePayload sharedPB.FlowIDValue
	err = ccutil.Unmarshal(res.GetPayload(), &startFlowResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}
	flowID := startFlowResponsePayload.GetValue()
	if len(startFlowResponsePayload.GetValue()) == 0 {
		t.Fatal("Empty Flow ID is returned")
	}

	// Test that startRequest has been stored in state

	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)
	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	storedStartRequestBytes, err := stub.GetState(flowKey)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	var storedStartRequest profilePB.OrganizationStartRequest
	err = ccutil.Unmarshal(storedStartRequestBytes, &storedStartRequest)
	if err != nil {
		t.Fatal(err.Error())
	}

	storedCreateRequest := storedStartRequest.GetCreateRequest()

	// Check all fields of stored create request
	if storedCreateRequest.GetId() != startFlowResponsePayload.GetValue() {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", startFlowResponsePayload.GetValue(), storedCreateRequest.GetId())
	}
	if storedCreateRequest.GetOrganization().GetId() != newOrganizationID {
		t.Fatalf("Error incorrect organization ID in stored flow request, expected: %s, got: %s", storedCreateRequest.GetOrganization().GetId(), newOrganizationID)
	}
	if storedCreateRequest.GetAdminCertificate() != newOrganizationCertificate {
		t.Fatalf("Error incorrect certificate in stored flow request, expected: %s, got: %s", storedCreateRequest.GetAdminCertificate(), newOrganizationCertificate)
	}
	if storedCreateRequest.GetCreatedBy() != creatorOrganizationID {
		t.Fatalf("Error incorrect 'createdBy' of stored flow request, expected: %s, got: %s", creatorOrganizationID, storedCreateRequest.GetCreatedBy())
	}
}

func TestGetFlowProfileChange(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// New organization details
	newOrganizationID := "orgid2"
	organization := profiletest.GenerateExampleOrganization(newOrganizationID)
	organizationID := organization.GetId()
	organizationKey, err := generateOrganizationKey(stub, newOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Organization update details
	entityName := "acn:0000000"

	createFlowRequestTxID := cctest.GenerateMockTxID("")
	stub.TxID = createFlowRequestTxID

	startRequestBytes := profiletest.GenerateStartRequestProfileChangeBytes(t, &profilePB.OrganizationProfileChangeRequest{OrganizationId: organizationID, EntityName: entityName})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Test for failure when Organization doesn't exist
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status == shim.OK {
		t.Fatalf("Expected Start Profile Change to fail since organization does not exist: %s", string(res.Message))
	}

	// Add organization through mock transaction
	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)
	err = ccutil.PutStatePB(stub, organizationKey, &organization)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	// Test for successful invoke
	txID3 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID3, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start profile change flow: %s, of organization: %s", string(res.Message), organizationKey)
	}

	// Test that flow ID is returned
	var startFlowResponsePayload sharedPB.FlowIDValue
	err = ccutil.Unmarshal(res.GetPayload(), &startFlowResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Test that ID is returned
	flowID := startFlowResponsePayload.GetValue()
	if len(startFlowResponsePayload.GetValue()) == 0 {
		t.Fatal("Empty Flow ID is returned")
	}

	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Test that startRequest has been stored in state
	txID4 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID4)
	storedStartRequestBytes, err := stub.GetState(flowKey)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID4)

	var storedStartRequest profilePB.OrganizationStartRequest
	err = ccutil.Unmarshal(storedStartRequestBytes, &storedStartRequest)
	if err != nil {
		t.Fatal(err.Error())
	}

	storedProfileChangeRequest := storedStartRequest.GetProfileChangeRequest()

	// Check all fields
	if storedProfileChangeRequest.GetId() != startFlowResponsePayload.GetValue() {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", startFlowResponsePayload.GetValue(), storedProfileChangeRequest.GetId())
	}

	if storedProfileChangeRequest.GetOrganizationId() != organization.GetId() {
		t.Fatalf("Error incorrect organisation ID of stored flow request, expected: %s, got: %s", organization.GetId(), storedProfileChangeRequest.GetOrganizationId())
	}

	if storedProfileChangeRequest.GetUpdatedAt() != organization.GetUpdatedAt() {
		t.Fatalf("Error incorrect updated time of stored flow request, expected: %s, got: %s", organization.GetUpdatedAt(), storedProfileChangeRequest.GetUpdatedAt())
	}

	if storedProfileChangeRequest.GetUpdatedBy() != organization.GetUpdatedBy() {
		t.Fatalf("Error incorrect 'updated by' of stored flow request, expected: %s, got: %s", organization.GetUpdatedBy(), storedProfileChangeRequest.GetUpdatedBy())
	}
}
