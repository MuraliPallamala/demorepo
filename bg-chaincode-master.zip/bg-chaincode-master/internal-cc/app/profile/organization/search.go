package organization

import (
	"strings"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// Search retrieves existing organizations based on a single search parameter (entity name, business ID, or status)
func (t *APICC) Search(stub *profilePB.ChaincodeStub, request *profilePB.OrganizationSearchRequest) (*profilePB.OrganizationsList, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Searching Organizations, using search request: %v\n", request)

	iterator, err := GenerateOrganizationIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var organizations []*profilePB.Organization

	for iterator.HasNext() {
		organizationKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		organizationBytes := organizationKV.GetValue()

		var organization profilePB.Organization
		err = ccutil.Unmarshal(organizationBytes, &organization)
		if err != nil {
			return nil, err
		}

		requestID := request.GetBusinessId()
		requestName := request.GetEntityName()
		requestStatus := request.GetStatus()

		orgID := organization.GetBusinessId()
		orgName := organization.GetEntityName()
		orgStatus := organization.GetStatus()

		// Check which search parameters have been specified
		if (requestID == "" || strings.HasPrefix(orgID, requestID)) && (requestName == "" || strings.HasPrefix(orgName, requestName)) && (requestStatus == nil || orgStatus == requestStatus.GetValue()) {
			organizations = append(organizations, &organization)
		}

	}

	return &profilePB.OrganizationsList{Organizations: organizations}, nil
}
