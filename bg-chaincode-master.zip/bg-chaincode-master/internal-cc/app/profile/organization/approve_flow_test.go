package organization

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// TODO split into separate tests
// TODO refactor to reuse code
// Test approve flow of profile change request
func TestApproveFlowProfileChange(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// New organization details
	newOrganizationID := "orgid2"
	newOrganizationKey, err := generateOrganizationKey(stub, newOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	newOrganization := profiletest.GenerateExampleOrganization(newOrganizationID)

	// Add organization through mock transaction
	txID1 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID1)
	err = ccutil.PutStatePB(stub, newOrganizationKey, &newOrganization)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID1)

	// Organization update details
	entityName := "acn:0000000"

	// Submit start flow request with updated newOrganization details
	approvingOrganization1ID := "orgid3"
	approvingOrganization2ID := "orgid4"
	approvingOrganizations := []string{approvingOrganization1ID, approvingOrganization2ID}
	createFlowRequestTxID := cctest.GenerateMockTxID("")
	profileChangeRequest := profilePB.OrganizationProfileChangeRequest{
		OrganizationId:    newOrganizationID,
		EntityName:        entityName,
		RequiredApprovals: approvingOrganizations,
	}
	createFlowPayload := profiletest.InvokeOrganizationStartFlowProfileChange(t, stub, createFlowRequestTxID, &profileChangeRequest)
	flowID := createFlowPayload.GetValue()

	// Check that creator organization is not allowed to approve
	approveRequestBytes := cctest.GenerateFlowActionRequestBytes(t, flowID)
	args := [][]byte{[]byte(ccMethods.ApproveFlow), approveRequestBytes}
	txID2 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID2, args)
	if res.Status == shim.OK {
		t.Fatalf("Expected approve flow to fail as creator is not allowed to approve: %s", string(res.Message))
	}

	// Change Identity to approving organization 1 and create new approve request
	err = profiletest.LinkPEMOrganizationID(stub, cctest.ANZPEM, approvingOrganization1ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	cctest.SetMockStubCert(t, stub, cctest.ANZPEM)
	approveRequestBytes = cctest.GenerateFlowActionRequestBytes(t, flowID)
	args = [][]byte{[]byte(ccMethods.ApproveFlow), approveRequestBytes}

	// Validate that response returns correct flowID
	txID3 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID3, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke approve flow: %s", string(res.Message))
	}
	var approveFlowResponsePayload sharedPB.FlowIDValue
	err = ccutil.Unmarshal(res.GetPayload(), &approveFlowResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}
	if approveFlowResponsePayload.GetValue() != flowID {
		t.Fatalf("Incorrect flowID, expected: %s, got: %s", flowID, approveFlowResponsePayload.GetValue())
	}

	// Check that approving organization 1 is not allowed to approve again
	approveRequestBytes = cctest.GenerateFlowActionRequestBytes(t, flowID)
	args = [][]byte{[]byte(ccMethods.ApproveFlow), approveRequestBytes}
	txID4 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID4, args)
	if res.Status == shim.OK {
		t.Fatalf("Expected approve flow to fail as approver has already approved: %s", string(res.Message))
	}

	statusKey, err := profileutil.GenerateFlowStatusKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// check that flow status is still active given there is still an approver
	var approveFlowResponseStatus sharedPB.FlowStatus
	approveFlowResponseStatusInt, err := ccutil.GetStateInt(stub, statusKey)
	if err != nil {
		t.Fatalf(err.Error())
	}
	approveFlowResponseStatus = sharedPB.FlowStatus(approveFlowResponseStatusInt)

	if approveFlowResponseStatus != sharedPB.FlowStatus_FLOW_ACTIVE {
		t.Fatalf("Incorrect status. Should be FLOW_ACTIVE, got: %v", approveFlowResponseStatus)
	}

	// Change Identity to approving organization 2 and create new approve request
	err = profiletest.LinkPEMOrganizationID(stub, cctest.CommbankPEM, approvingOrganization2ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	cctest.SetMockStubCert(t, stub, cctest.CommbankPEM)
	approveRequestBytes = cctest.GenerateFlowActionRequestBytes(t, flowID)
	args = [][]byte{[]byte(ccMethods.ApproveFlow), approveRequestBytes}

	// Invoke new approve request and validate that response returns correct flowID
	txID5 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID5, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke approve flow: %s", string(res.Message))
	}
	err = ccutil.Unmarshal(res.GetPayload(), &approveFlowResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}
	if approveFlowResponsePayload.GetValue() != flowID {
		t.Fatalf("Incorrect flowID, expected: %s, got: %s", flowID, approveFlowResponsePayload.GetValue())
	}

	// check that flow status is now successful
	approveFlowResponseStatusInt, err = ccutil.GetStateInt(stub, statusKey)
	if err != nil {
		t.Fatalf(err.Error())
	}
	approveFlowResponseStatus = sharedPB.FlowStatus(approveFlowResponseStatusInt)

	if approveFlowResponseStatus != sharedPB.FlowStatus_FLOW_APPROVED {
		t.Fatalf("Incorrect status. Should be FLOW_APPROVED, got: %v", approveFlowResponseStatus)
	}

	// check that approve request is rejected given that flow is not active
	err = profiletest.LinkPEMOrganizationID(stub, cctest.NABPEM, "orgID5")
	if err != nil {
		t.Fatalf(err.Error())
	}
	cctest.SetMockStubCert(t, stub, cctest.NABPEM)
	approveRequestBytes = cctest.GenerateFlowActionRequestBytes(t, flowID)
	args = [][]byte{[]byte(ccMethods.ApproveFlow), approveRequestBytes}

	// Invoke new approve request and validate that response returns correct flowID
	txID6 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID6, args)
	if res.Status == shim.OK {
		t.Fatalf("Expected approve flow to fail given that flow is inactive: %s", string(res.Message))
	}

}
