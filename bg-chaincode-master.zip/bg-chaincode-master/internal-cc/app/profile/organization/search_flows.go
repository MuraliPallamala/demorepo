package organization

import (
	"fmt"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// SearchFlows retrieves flows. It takes optional filter arguments allowing it to filter by organizationID and status
func (t *APICC) SearchFlows(stub *profilePB.ChaincodeStub, organizationFlowsRequest *profilePB.OrganizationFlowsSearchRequest) (*profilePB.OrganizationFlowsResponse, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Searching Flows, using search request: %v\n", organizationFlowsRequest)

	iterator, err := ccutil.GenerateFlowIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var fullFlows []*profilePB.OrganizationFullFlow

	for iterator.HasNext() {

		flowKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}

		flowKey := flowKV.GetKey()
		flowID, err := ccutil.GetFlowIDFromFlowKey(stub, flowKey)
		if err != nil {
			return nil, err
		}

		flowBytes := flowKV.GetValue()

		noOrgFilter := organizationFlowsRequest.GetOrganizationId() == ""
		noStatusFilter := organizationFlowsRequest.GetStatus() == nil
		var orgMatch bool

		flowStatus, err := profileutil.GetFlowStatus(stub, flowID)
		if err != nil {
			return nil, err
		}

		var flow profilePB.OrganizationStartRequest
		err = ccutil.Unmarshal(flowBytes, &flow)
		if err != nil {
			return nil, err
		}

		if !noOrgFilter {
			// Check whether ORG ID matches
			switch t := flow.Request.(type) {
			case *profilePB.OrganizationStartRequest_CreateRequest:
				createRequest := flow.GetCreateRequest()
				orgMatch = organizationFlowsRequest.GetOrganizationId() == createRequest.Organization.GetId()
			case *profilePB.OrganizationStartRequest_ProfileChangeRequest:
				profileChangeRequest := flow.GetProfileChangeRequest()
				orgMatch = organizationFlowsRequest.GetOrganizationId() == profileChangeRequest.GetOrganizationId()
			default:
				return nil, fmt.Errorf("Invalid Request Type %T", t)
			}
		}

		if (noOrgFilter || orgMatch) && (noStatusFilter || flowStatus == organizationFlowsRequest.GetStatus().GetValue()) {
			fullFlow := profilePB.OrganizationFullFlow{Flow: &flow, Status: flowStatus}
			fullFlows = append(fullFlows, &fullFlow)
		}
	}

	return &profilePB.OrganizationFlowsResponse{FullFlows: fullFlows}, nil
}
