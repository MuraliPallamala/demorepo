package organization

import (
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestSearchEvents(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"

	// Create Organization
	createOrganizationPayload := profiletest.InvokeOrganizationStartFlowCreate(t, stub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id: creatorOrganizationID,
		},
		SelfOnboarding: true,
	})

	// Profile Change
	profileChangePayload := profiletest.InvokeOrganizationStartFlowProfileChange(t, stub, cctest.GenerateMockTxID(""), &profilePB.OrganizationProfileChangeRequest{
		OrganizationId: creatorOrganizationID,
		EntityName:     "1234",
	})

	flowResponses := []sharedPB.FlowIDValue{createOrganizationPayload, profileChangePayload}

	// perform search
	events := profiletest.InvokeSearchEvents(t, stub, cctest.GenerateMockTxID(""), &sharedPB.EventSearchRequest{}).GetEvents()

	if len(events) != len(flowResponses) {
		t.Fatalf("Error expected %d events, but got %d", len(flowResponses), len(events))
	}

	// TODO do comparison with organization
	if events[0].GetCreateOrganizationEvent().GetOrganization() == nil {
		t.Fatal("Error expected first event to be for createOrganization")
	}
	if events[1].GetProfileChangeEvent().GetOrganization() == nil {
		t.Fatal("Error expected first event to be for profileChange")
	}
}
