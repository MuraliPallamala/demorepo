package organization

import (
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/purposeformat"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/tc"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

/*
Utility functions
*/

var ccMethods = ccutil.CCMethods.Profile.Organization

func setupChaincodeMockStub(t *testing.T) *cctest.MockStub {
	return profiletest.SetupChaincodeMockStub(t, new(APICC), new(purposeformat.APICC), new(tc.APICC))
}
