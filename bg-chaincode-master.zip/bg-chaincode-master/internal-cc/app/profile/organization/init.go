package organization

import (
	types "github.com/gogo/protobuf/types"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// Init is the Init function for the profile chaincode (TODO move to common profile folder)
func (t *APICC) Init(stub *profilePB.ChaincodeStub, initRequest *profilePB.OrganizationInitRequest) error {
	profileutil.Setup()

	ccutil.Logger.Debugf("Initialising with parameters %v\n", initRequest)

	newcoMspID := initRequest.GetNewcoMspId()
	if newcoMspID == "" {
		newcoMspID = "newco"
	}
	newcoMspIDValue := types.StringValue{Value: newcoMspID}
	newcoMspIDKey, err := ccutil.GenerateSystemPropertyKey(stub, ccutil.SPKeyNewcoMspID)
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, newcoMspIDKey, &newcoMspIDValue)
	return err
}
