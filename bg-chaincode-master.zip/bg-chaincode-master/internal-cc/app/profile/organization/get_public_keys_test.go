package organization

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

// TODO refactor to reuse code
func TestGetPublicKeys(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	newOrganizationID := "orgid2"
	newOrganization := profiletest.GenerateExampleOrganization(newOrganizationID)
	newOrganizationCertificate := cctest.ANZPEM
	startRequestBytes := profiletest.GenerateStartRequestCreateBytes(t, &profilePB.OrganizationCreateRequest{Organization: &newOrganization, AdminCertificate: newOrganizationCertificate})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Invoke start flow
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start create flow: %s", string(res.Message))
	}

	// Check that organization Public Key map was stored in state
	args = [][]byte{[]byte(ccMethods.GetPublicKeys), profiletest.GenerateIDValueBytes(t, newOrganizationID)}

	// Test for successful invoke
	txID2 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID2, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organization Public Keys: %s", string(res.Message))
	}

	// Check the organization certificate is correct
	var publicKeyResponsePayload profilePB.OrganizationPublicKeyMap
	err = ccutil.Unmarshal(res.GetPayload(), &publicKeyResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	expectedPublicKeyString, err := ccutil.GetPublicKeyPEMFromCertPEM(newOrganizationCertificate)
	if err != nil {
		t.Fatalf(err.Error())
	}

	defaultKey := publicKeyResponsePayload.Map["default"]
	if defaultKey.GetKey() != expectedPublicKeyString {
		t.Fatalf("Incorrect organization public key, expected:\n %v, got: %v", expectedPublicKeyString, defaultKey.GetKey())
	}
}
