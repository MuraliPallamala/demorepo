package organization

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

func TestCancelFlowNoApprovals(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	createFlowRequestTxID := cctest.GenerateMockTxID("")
	mockFlowID := "mockflowid123"

	// Create Organization
	profiletest.InvokeOrganizationStartFlowCreate(t, stub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id: creatorOrganizationID,
		},
		SelfOnboarding: true,
	})

	// Test for failure when Flow doesn't exist
	txID1 := cctest.GenerateMockTxID("")
	args1 := [][]byte{[]byte(ccMethods.CancelFlow), cctest.GenerateFlowActionRequestBytes(t, mockFlowID)}
	res := stub.MockInvoke(txID1, args1)
	if res.Status == shim.OK {
		t.Fatalf("Expected CancelFlow to fail since organization does not exist: %s", string(res.Message))
	}

	// Place StartFlowCreate into state using creatorOrganizationID identity
	createFlowPayload := profiletest.InvokeOrganizationStartFlowProfileChange(t, stub, createFlowRequestTxID, &profilePB.OrganizationProfileChangeRequest{OrganizationId: creatorOrganizationID, EntityName: "1234"})
	flowID := createFlowPayload.GetValue()

	// Validate that cancel fails since flow is completed (requires zero approvals)
	txID2 := cctest.GenerateMockTxID("")
	args2 := [][]byte{[]byte(ccMethods.CancelFlow), cctest.GenerateFlowActionRequestBytes(t, flowID)}
	res = stub.MockInvoke(txID2, args2)
	if res.Status == shim.OK {
		t.Fatalf("Expected CancelFlow to fail since flow is finished: %s", string(res.Message))
	}
}

func TestCancelFlowProfileChange(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	secondOrganizationID := "orgid2"

	// Create Organizations
	profiletest.InvokeOrganizationStartFlowCreate(t, stub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id: creatorOrganizationID,
		},
		SelfOnboarding: true,
	})
	profiletest.InvokeOrganizationStartFlowCreate(t, stub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id: secondOrganizationID,
		},
		AdminCertificate: cctest.ANZPEM,
	})

	createFlowRequestTxID := cctest.GenerateMockTxID("")
	mockFlowID := "mockflowid123"

	// Test for failure when Flow doesn't exist
	txID1 := cctest.GenerateMockTxID("")
	args1 := [][]byte{[]byte(ccMethods.RejectFlow), cctest.GenerateFlowActionRequestBytes(t, mockFlowID)}
	res := stub.MockInvoke(txID1, args1)
	if res.Status == shim.OK {
		t.Fatalf("Expected RejectFlow to fail since organization does not exist: %s", string(res.Message))
	}

	// Place StartFlowProfileChange into state
	createFlowPayload := profiletest.InvokeOrganizationStartFlowProfileChange(t, stub, createFlowRequestTxID, &profilePB.OrganizationProfileChangeRequest{OrganizationId: secondOrganizationID, EntityName: "1234", RequiredApprovals: []string{secondOrganizationID}})

	flowID := createFlowPayload.GetValue()

	// Validate that response returns correct flowID
	txID2 := cctest.GenerateMockTxID("")
	args2 := [][]byte{[]byte(ccMethods.CancelFlow), cctest.GenerateFlowActionRequestBytes(t, flowID)}
	res = stub.MockInvoke(txID2, args2)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke reject flow: %s", string(res.Message))
	}

	var startFlowResponsePayload sharedPB.FlowIDValue
	err := ccutil.Unmarshal(res.GetPayload(), &startFlowResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}
	if startFlowResponsePayload.GetValue() != flowID {
		t.Fatalf("Incorrect flowID, expected: %s, got: %s", flowID, startFlowResponsePayload.GetValue())
	}

	statusID, err := profileutil.GenerateFlowStatusKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// TODO check that status was changed
	var cancelFlowResponseStatus sharedPB.FlowStatus
	cancelFlowResponseStatusInt, err := ccutil.GetStateInt(stub, statusID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	cancelFlowResponseStatus = sharedPB.FlowStatus(cancelFlowResponseStatusInt)

	if cancelFlowResponseStatus != sharedPB.FlowStatus_FLOW_CANCELLED {
		t.Fatalf("Incorrect status. Should be FLOW_CANCELLED, got: %v", cancelFlowResponseStatus)
	}
}
