package organization

import (
	"errors"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

// Deactivate deactivates an organization
func (t *APICC) Deactivate(stub *profilePB.ChaincodeStub, organizationID *sharedPB.IDValue) (*sharedPB.Empty, error) {
	profileutil.Setup()
	ccutil.Logger.Debugf("Processing deactivate request %v\n", organizationID)
	ccutil.Logger.Infof("Request DEACTIVATE Organization (id: %v)\n", organizationID)

	// Check whether issuer is a part of the consortium organization
	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}

	isConsortium, err := ccutil.IsConsortium(stub, creatorCert)
	if err != nil {
		return nil, err
	}
	if !isConsortium {
		return nil, errors.New("Deactivate is a consortium only operation")
	}

	// Get organization
	var organization profilePB.Organization
	orgKey, err := generateOrganizationKey(stub, organizationID.GetValue())
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, orgKey, &organization)
	if err != nil {
		return nil, err
	}

	if organization.GetStatus() == profilePB.OrganizationStatus_ORGANIZATION_INACTIVE {
		return nil, errors.New("Organization is already inactive, cannot deactivate")
	}

	organization.Status = profilePB.OrganizationStatus_ORGANIZATION_INACTIVE

	err = ccutil.PutStatePB(stub, orgKey, &organization)
	if err != nil {
		return nil, err
	}

	return &sharedPB.Empty{}, nil
}
