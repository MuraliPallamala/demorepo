package organization

import (
	"errors"
	"fmt"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

// DeactivateKey de-activates a key with an organization
func (t *APICC) DeactivateKey(stub *profilePB.ChaincodeStub, deactivateKeyRequest *profilePB.DeactivateKeyRequest) (*sharedPB.Empty, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Processing DeactiveKey request %v\n", deactivateKeyRequest)
	ccutil.Logger.Info("Request DEACTIVATE KEY\n")

	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}

	creatorOrganizationID, err := profileutil.GetOrganizationIDFromCert(stub, creatorCert)
	if err != nil {
		return nil, err
	}

	var organizationPublicKeyMap profilePB.OrganizationPublicKeyMap
	organizationPublicKeyMapKey, err := generateOrganizationPublicKeyMapKey(stub, creatorOrganizationID)
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, organizationPublicKeyMapKey, &organizationPublicKeyMap)
	if err != nil {
		return nil, err
	}

	keyMap := organizationPublicKeyMap.GetMap()

	defaultKey, ok := keyMap["default"]
	if !ok {
		// NOTE should never occur
		return nil, errors.New("Error organization doesn't have a default key")
	}
	if defaultKey.GetKey() == creatorOrganizationID {
		return nil, errors.New("Cannot deactivate key, as is default key")
	}

	keyHash := ccutil.HashS(deactivateKeyRequest.GetKey())

	foundKey, ok := keyMap[keyHash]
	if !ok {
		return nil, fmt.Errorf("Error organization doesn't have a key %s", deactivateKeyRequest.GetKey())
	}

	allowedTimeRanges := foundKey.GetAllowedTimeRanges()
	lastRange := allowedTimeRanges[len(allowedTimeRanges)-1]
	if lastRange.GetExpiryDate() != nil {
		return nil, errors.New("Key is already deactivated")
	}

	timestamp, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return nil, err
	}

	lastRange.ExpiryDate = timestamp
	err = ccutil.PutStatePB(stub, organizationPublicKeyMapKey, &organizationPublicKeyMap)
	if err != nil {
		return nil, err
	}

	return &sharedPB.Empty{}, nil
}
