package organization

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestSearchFlowsCreate(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	organizationID := creatorOrganizationID

	args := [][]byte{[]byte(ccMethods.SearchFlows), profiletest.GenerateOrganizationFlowsRequestBytes(t, organizationID, "")}

	// Test that empty arrays are returned when no flows exist
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)

	var flowResponsePayload profilePB.OrganizationFlowsResponse
	err := ccutil.Unmarshal(res.GetPayload(), &flowResponsePayload)
	if err != nil {
		t.Fatal(err.Error())
	}
	if res.Status != shim.OK {
		t.Fatalf("Failed to get flows: %s", string(res.Message))
	}

	if len(flowResponsePayload.GetFullFlows()) != 0 {
		t.Fatalf("Expected empty flow response, but got: %v", flowResponsePayload.GetFullFlows())
	}

	// Submit start flow request
	createFlowRequestTxID := cctest.GenerateMockTxID("")
	createFlowPayload := profiletest.InvokeOrganizationStartFlowCreate(t, stub, createFlowRequestTxID, &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id: creatorOrganizationID,
		},
		SelfOnboarding: true,
	})
	expectedFlowID := createFlowPayload.GetValue()

	// Test that array is returned containing start flow
	txID2 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID2, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get flows: %s", string(res.Message))
	}

	var flowresponsePayload2 profilePB.OrganizationFlowsResponse
	err = ccutil.Unmarshal(res.GetPayload(), &flowresponsePayload2)
	if err != nil {
		t.Fatal(err.Error())
	}

	if len(flowresponsePayload2.GetFullFlows()) != 1 {
		t.Fatalf("Expected response to contain single FullFlow, but recieved: %v", flowresponsePayload2.GetFullFlows())
	}

	fullFlow := flowresponsePayload2.GetFullFlows()[0]

	flowID := fullFlow.GetFlow().GetCreateRequest().GetId()

	if flowID != expectedFlowID {
		t.Fatalf("Response contains incorrect flow ID. Expected: %s, recieved: %s", expectedFlowID, flowID)
	}
}

func TestSearchFlowsProfileChange(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// New organization details
	newOrganizationID := "orgid2"
	newOrganizationKey, err := generateOrganizationKey(stub, newOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	newOrganization := profiletest.GenerateExampleOrganization(newOrganizationID)

	// Add organization through mock transaction
	txID1 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID1)
	err = ccutil.PutStatePB(stub, newOrganizationKey, &newOrganization)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID1)

	// Test for successful invoke of get organization
	args := [][]byte{[]byte(ccMethods.Get), profiletest.GenerateIDValueBytes(t, newOrganizationID)}
	txID10 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID10, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organization: %s", string(res.Message))
	}

	// Check all fields of the organization
	var getOrganizationResponsePayload profilePB.Organization
	err = ccutil.Unmarshal(res.GetPayload(), &getOrganizationResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if getOrganizationResponsePayload.GetId() != newOrganizationID {
		t.Fatalf("Error incorrect organization ID, expected: %s, got: %s", newOrganizationID, getOrganizationResponsePayload.GetId())
	}

	// Organization update details
	entityName := "acn:0000000"

	// Submit start flow request
	approvingOrganization1ID := "orgid3"
	createFlowRequestTxID := cctest.GenerateMockTxID("")
	profileChangeRequest := profilePB.OrganizationProfileChangeRequest{
		OrganizationId:    newOrganizationID,
		EntityName:        entityName,
		RequiredApprovals: []string{approvingOrganization1ID},
	}
	createFlowPayload := profiletest.InvokeOrganizationStartFlowProfileChange(t, stub, createFlowRequestTxID, &profileChangeRequest)
	expectedFlowID := createFlowPayload.GetValue()

	// Test that array is returned containing start flow
	args = [][]byte{[]byte(ccMethods.SearchFlows), profiletest.GenerateOrganizationFlowsRequestBytes(t, newOrganizationID, "")}

	txID2 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID2, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get flows: %s", string(res.Message))
	}

	var flowResponsePayload profilePB.OrganizationFlowsResponse
	err = ccutil.Unmarshal(res.GetPayload(), &flowResponsePayload)
	if err != nil {
		t.Fatal(err.Error())
	}

	if len(flowResponsePayload.GetFullFlows()) != 1 {
		t.Fatalf("Expected response to contain single FullFlow, but recieved: %v", flowResponsePayload.GetFullFlows())
	}

	fullFlow := flowResponsePayload.GetFullFlows()[0]

	flowID := fullFlow.GetFlow().GetProfileChangeRequest().GetId()

	if flowID != expectedFlowID {
		t.Fatalf("Response contains incorrect flow ID. Expected: %s, recieved: %s", expectedFlowID, flowID)
	}
}
