package organization

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestGetEvent(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	newOrganizationID := "orgid2"
	newOrganization := profiletest.GenerateExampleOrganization(newOrganizationID)
	newOrganizationCertificate := cctest.ANZPEM
	startRequestBytes := profiletest.GenerateStartRequestCreateBytes(t, &profilePB.OrganizationCreateRequest{Organization: &newOrganization, AdminCertificate: newOrganizationCertificate})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Invoke start flow
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start create flow: %s", string(res.Message))
	}

	if stub.Event.Payload == nil {
		t.Fatal("Error expected Event to be set")
	}

	expectedName := "createOrganization"

	if stub.Event.Name != expectedName {
		t.Fatalf("Error expected event name to be %s, but got %s", expectedName, stub.Event.Name)
	}

	var eventPayload profilePB.OrganizationEvent
	err = ccutil.Unmarshal(stub.Event.Payload, &eventPayload)
	if err != nil {
		t.Fatal(err)
	}
	if eventPayload.GetId() == "" {
		t.Fatal("Error expected event ID to be set")
	}

	storedEvent, err := getEvent(stub, eventPayload.GetId())
	if err != nil {
		t.Fatal(err)
	}

	if storedEvent.GetId() == "" {
		t.Fatal("Error expected event ID to be set")
	}
}
