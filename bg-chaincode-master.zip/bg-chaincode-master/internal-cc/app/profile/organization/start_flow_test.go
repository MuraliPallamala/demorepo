package organization

import (
	"strings"
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// TODO split into separate tests
// TODO refactor to reuse code
func TestStartFlowCreate(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	newOrganizationID := "orgid2"
	newOrganization := profiletest.GenerateExampleOrganization(newOrganizationID)
	newOrganizationCertificate := cctest.ANZPEM
	startRequestBytes := profiletest.GenerateStartRequestCreateBytes(t, &profilePB.OrganizationCreateRequest{Organization: &newOrganization, AdminCertificate: newOrganizationCertificate})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Invoke start flow
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start create flow: %s", string(res.Message))
	}

	// Test that flow ID is returned
	var startFlowResponsePayload sharedPB.FlowIDValue
	err = ccutil.Unmarshal(res.GetPayload(), &startFlowResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}
	flowID := startFlowResponsePayload.GetValue()
	if len(startFlowResponsePayload.GetValue()) == 0 {
		t.Fatal("Empty Flow ID is returned")
	}

	// Test that startRequest has been stored in state

	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)
	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	storedStartRequestBytes, err := stub.GetState(flowKey)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	var storedStartRequest profilePB.OrganizationStartRequest
	err = ccutil.Unmarshal(storedStartRequestBytes, &storedStartRequest)
	if err != nil {
		t.Fatal(err.Error())
	}

	storedCreateRequest := storedStartRequest.GetCreateRequest()

	// Check all fields of stored create request
	if storedCreateRequest.GetId() != startFlowResponsePayload.GetValue() {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", startFlowResponsePayload.GetValue(), storedCreateRequest.GetId())
	}
	if storedCreateRequest.GetOrganization().GetId() != newOrganizationID {
		t.Fatalf("Error incorrect organization ID in stored flow request, expected: %s, got: %s", storedCreateRequest.GetOrganization().GetId(), newOrganizationID)
	}
	if storedCreateRequest.GetAdminCertificate() != newOrganizationCertificate {
		t.Fatalf("Error incorrect certificate in stored flow request, expected: %s, got: %s", storedCreateRequest.GetAdminCertificate(), newOrganizationCertificate)
	}
	if storedCreateRequest.GetCreatedBy() != creatorOrganizationID {
		t.Fatalf("Error incorrect 'createdBy' of stored flow request, expected: %s, got: %s", creatorOrganizationID, storedCreateRequest.GetCreatedBy())
	}

	// Check that organization was created
	args = [][]byte{[]byte(ccMethods.Get), profiletest.GenerateIDValueBytes(t, newOrganizationID)}

	txID3 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID3, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organization: %s", string(res.Message))
	}

	// Check that created organization matches request
	var getOrganizationResponsePayload profilePB.Organization
	err = ccutil.Unmarshal(res.GetPayload(), &getOrganizationResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if getOrganizationResponsePayload.GetId() != newOrganizationID {
		t.Fatalf("Error incorrect organization ID, expected: %s, got: %s", newOrganizationID, getOrganizationResponsePayload.GetId())
	}

	if getOrganizationResponsePayload.GetStatus() != profilePB.OrganizationStatus_ORGANIZATION_ACTIVE {
		t.Fatal("Error expected created organization to be ACTIVE")
	}

	// Check that invoking start request on existing org creates an error
	args = [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Invoke start flow
	txID4 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID4, args)
	if res.Status == shim.OK {
		t.Fatalf("Expected Start Request to fail since organization already exists: %s", string(res.Message))
	}

	// check that status was changed
	statusKey, err := profileutil.GenerateFlowStatusKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	startFlowResponseStatusInt, err := ccutil.GetStateInt(stub, statusKey)
	if err != nil {
		t.Fatalf(err.Error())
	}
	var startFlowResponseStatus sharedPB.FlowStatus
	startFlowResponseStatus = sharedPB.FlowStatus(startFlowResponseStatusInt)

	if startFlowResponseStatus != sharedPB.FlowStatus_FLOW_APPROVED {
		t.Fatalf("Incorrect status. Should be FLOW_APPROVED, got: %v", startFlowResponseStatus)
	}
}

func TestStartFlowCreateFailAlreadyOnboarded(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	creatorCertificate := cctest.ConsortiumPEM
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	newOrganization := profiletest.GenerateExampleOrganization(creatorOrganizationID)
	startRequestBytes := profiletest.GenerateStartRequestCreateBytes(t, &profilePB.OrganizationCreateRequest{Organization: &newOrganization, AdminCertificate: creatorCertificate})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Invoke start flow
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status == shim.OK || !strings.Contains(res.Message, "Public key is already used") {
		t.Fatalf("Error expected to fail as a public key can only be linked once. Message: %s", string(res.Message))
	}
}

func TestStartFlowCreateNonConsortium(t *testing.T) {
	stub := setupChaincodeMockStub(t)
	// Switch to ANZPEM Cert
	cctest.SetMockStubCert(t, stub, cctest.ANZPEM)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ANZPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	newOrganizationID := "orgid2"
	newOrganization := profiletest.GenerateExampleOrganization(newOrganizationID)
	newOrganizationCertificate := cctest.CommbankPEM
	startRequestBytes := profiletest.GenerateStartRequestCreateBytes(t, &profilePB.OrganizationCreateRequest{Organization: &newOrganization, AdminCertificate: newOrganizationCertificate})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Invoke start flow
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status == shim.OK || !strings.Contains(res.Message, "consortium") {
		t.Fatalf("Error expected to fail as only the consortium is allowed to perform this operation. Message: %s", string(res.Message))
	}
}

func TestStartFlowCreateOnboardSelf(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	newOrganizationID := "orgid1"

	organization := profiletest.GenerateExampleOrganization(newOrganizationID)
	startRequestBytes := profiletest.GenerateStartRequestCreateBytes(t, &profilePB.OrganizationCreateRequest{Organization: &organization, SelfOnboarding: true})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start create flow: %s", string(res.Message))
	}

	// Test that flow ID is returned
	var startFlowResponsePayload sharedPB.FlowIDValue
	err := ccutil.Unmarshal(res.GetPayload(), &startFlowResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Test that flow ID is returned
	flowID := startFlowResponsePayload.GetValue()
	if len(startFlowResponsePayload.GetValue()) == 0 {
		t.Fatal("Empty Flow ID is returned")
	}

	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Test that startRequest has been stored in state

	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)
	storedStartRequestBytes, err := stub.GetState(flowKey)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	var storedStartRequest profilePB.OrganizationStartRequest
	err = ccutil.Unmarshal(storedStartRequestBytes, &storedStartRequest)
	if err != nil {
		t.Fatal(err.Error())
	}

	storedCreateRequest := storedStartRequest.GetCreateRequest()

	// TODO find good way to check all fields. Currently is only checking ID and createdBy
	if storedCreateRequest.GetId() != startFlowResponsePayload.GetValue() {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", startFlowResponsePayload.GetValue(), storedCreateRequest.GetId())
	}

	if storedCreateRequest.GetCreatedBy() != newOrganizationID {
		t.Fatalf("Error incorrect 'createdBy' of stored flow request, expected: %s, got: %s", newOrganizationID, storedCreateRequest.GetCreatedBy())
	}

	// TODO check created organization

	statusKey, err := profileutil.GenerateFlowStatusKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// check that status was changed
	var startFlowResponseStatus sharedPB.FlowStatus
	startFlowResponseStatusInt, err := ccutil.GetStateInt(stub, statusKey)
	if err != nil {
		t.Fatalf(err.Error())
	}
	startFlowResponseStatus = sharedPB.FlowStatus(startFlowResponseStatusInt)

	if startFlowResponseStatus != sharedPB.FlowStatus_FLOW_APPROVED {
		t.Fatalf("Incorrect status. Should be FLOW_APPROVED, got: %v", startFlowResponseStatus)
	}
}

// TODO split into separate tests
// TODO refactor to reuse code
func TestOrganizationStartFlowProfileChange(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// target organization details
	targetOrganizationID := "orgid2"
	targetOrganization := profiletest.GenerateExampleOrganization(targetOrganizationID)
	targetOrganizationKey, err := generateOrganizationKey(stub, targetOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Organization update details
	entityName := "acn:0000000"

	startRequestBytes := profiletest.GenerateStartRequestProfileChangeBytes(t, &profilePB.OrganizationProfileChangeRequest{OrganizationId: targetOrganizationID, EntityName: entityName})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Test for failure when Organization doesn't exist
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status == shim.OK {
		t.Fatalf("Expected Start Profile Change to fail since organization does not exist: %s", string(res.Message))
	}

	// Add organization through mock transaction
	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)
	err = ccutil.PutStatePB(stub, targetOrganizationKey, &targetOrganization)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	// Test for successful invoke
	txID3 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID3, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start profile change flow: %s, of organization: %s", string(res.Message), targetOrganizationKey)
	}

	// Test that flow ID is returned
	var startFlowResponsePayload sharedPB.FlowIDValue
	err = ccutil.Unmarshal(res.GetPayload(), &startFlowResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Test that ID is returned
	flowID := startFlowResponsePayload.GetValue()
	if len(startFlowResponsePayload.GetValue()) == 0 {
		t.Fatal("Empty Flow ID is returned")
	}

	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Test that startRequest has been stored in state
	txID4 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID4)
	storedStartRequestBytes, err := stub.GetState(flowKey)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID4)

	var storedStartRequest profilePB.OrganizationStartRequest
	err = ccutil.Unmarshal(storedStartRequestBytes, &storedStartRequest)
	if err != nil {
		t.Fatal(err.Error())
	}

	storedProfileChangeRequest := storedStartRequest.GetProfileChangeRequest()

	// Check all fields
	if storedProfileChangeRequest.GetId() != startFlowResponsePayload.GetValue() {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", startFlowResponsePayload.GetValue(), storedProfileChangeRequest.GetId())
	}

	if storedProfileChangeRequest.GetOrganizationId() != targetOrganization.GetId() {
		t.Fatalf("Error incorrect organisation ID of stored flow request, expected: %s, got: %s", targetOrganization.GetId(), storedProfileChangeRequest.GetOrganizationId())
	}

	if storedProfileChangeRequest.GetUpdatedAt() != targetOrganization.GetUpdatedAt() {
		t.Fatalf("Error incorrect updated time of stored flow request, expected: %s, got: %s", targetOrganization.GetUpdatedAt(), storedProfileChangeRequest.GetUpdatedAt())
	}

	if storedProfileChangeRequest.GetUpdatedBy() != targetOrganization.GetUpdatedBy() {
		t.Fatalf("Error incorrect 'updated by' of stored flow request, expected: %s, got: %s", targetOrganization.GetUpdatedBy(), storedProfileChangeRequest.GetUpdatedBy())
	}

	statusKey, err := profileutil.GenerateFlowStatusKey(stub, flowID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Check that status was changed
	var startFlowResponseStatus sharedPB.FlowStatus
	startFlowResponseStatusInt, err := ccutil.GetStateInt(stub, statusKey)
	if err != nil {
		t.Fatalf(err.Error())
	}
	startFlowResponseStatus = sharedPB.FlowStatus(startFlowResponseStatusInt)

	if startFlowResponseStatus != sharedPB.FlowStatus_FLOW_APPROVED {
		t.Fatalf("Incorrect status. Should be FLOW_ACTIVE, got: %v", startFlowResponseStatus)
	}
}

func TestStartFlowProfileChangeNonConsortium(t *testing.T) {
	stub := setupChaincodeMockStub(t)
	// Switch to ANZPEM Cert
	cctest.SetMockStubCert(t, stub, cctest.ANZPEM)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ANZPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// target organization details
	targetOrganizationID := "orgid2"

	// Organization update details
	entityName := "acn:0000000"

	startRequestBytes := profiletest.GenerateStartRequestProfileChangeBytes(t, &profilePB.OrganizationProfileChangeRequest{OrganizationId: targetOrganizationID, EntityName: entityName})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Invoke start flow
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status == shim.OK || !strings.Contains(res.Message, "consortium") {
		t.Fatalf("Error expected to fail as only the consortium is allowed to perform this operation. Message: %s", string(res.Message))
	}
}
