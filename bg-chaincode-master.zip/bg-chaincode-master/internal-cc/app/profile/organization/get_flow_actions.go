package organization

import (
	"fmt"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// GetFlowActions retrieves the actions belonging to a single Flow
func (t *APICC) GetFlowActions(stub *profilePB.ChaincodeStub, flowIDValue *sharedPB.FlowIDValue) (*profilePB.OrganizationFlowActionsResponse, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Getting actions for flow with ID %s\n", flowIDValue)

	flowKey, err := ccutil.GenerateFlowKey(stub, flowIDValue.GetValue())
	if err != nil {
		return nil, err
	}

	flowStatusBytes, err := stub.GetState(flowKey)
	if err != nil {
		return nil, err
	}

	if len(flowStatusBytes) == 0 {
		return nil, fmt.Errorf("Flow %s does not exist", flowIDValue.GetValue())
	}

	actions, err := GetOrganizationFlowActions(stub, flowIDValue.GetValue())
	if err != nil {
		return nil, err
	}

	return &profilePB.OrganizationFlowActionsResponse{Requests: actions}, nil
}
