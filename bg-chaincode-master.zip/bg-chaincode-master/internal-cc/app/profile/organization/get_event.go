package organization

import (
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// GetEvent gets a OrganizationEvent by ID
func (t *APICC) GetEvent(stub *profilePB.ChaincodeStub, idValue *sharedPB.IDValue) (*profilePB.OrganizationEvent, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Getting Event with ID %v\n", idValue)

	return getEvent(stub, idValue.GetValue())
}

func getEvent(stub shim.ChaincodeStubInterface, eventID string) (*profilePB.OrganizationEvent, error) {
	var event profilePB.OrganizationEvent
	eventKey, err := generateOrganizationEventKey(stub, eventID)
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, eventKey, &event)
	if err != nil {
		return nil, err
	}
	return &event, nil
}
