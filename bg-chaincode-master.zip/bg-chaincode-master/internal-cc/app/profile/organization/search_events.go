package organization

import (
	"errors"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"

	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

// SearchEvents searches through flows and returns a subset
func (t *APICC) SearchEvents(stub *profilePB.ChaincodeStub, request *sharedPB.EventSearchRequest) (*profilePB.OrganizationEventSearchResponse, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Searching Events, using search request: %v\n", request)

	events, err := getAllOrganizationEventsWeakTyping(stub)
	if err != nil {
		return nil, err
	}

	if request.GetLimit() == 0 {
		request.Limit = 50
	}

	ccutil.EventSort(events)

	paginationResult, err := ccutil.EventSearchFilter(stub, events, request)
	if err != nil {
		return nil, err
	}

	organizationEvents, err := eventInterfacesToOrganizationEvents(paginationResult.Events)
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return &profilePB.OrganizationEventSearchResponse{Events: organizationEvents, Next: paginationResult.Next}, nil
}

func getAllOrganizationEventsWeakTyping(stub *profilePB.ChaincodeStub) ([]ccutil.EventInterface, error) {
	iterator, err := generateOrganizationEventIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var events []ccutil.EventInterface

	for iterator.HasNext() {
		eventKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		eventBytes := eventKV.GetValue()

		var event profilePB.OrganizationEvent
		err = ccutil.Unmarshal(eventBytes, &event)
		if err != nil {
			return nil, err
		}

		events = append(events, &event)
	}

	return events, nil
}

func organizationEventsToEventInterfaces(organizationEvents []*profilePB.OrganizationEvent) []ccutil.EventInterface {
	events := make([]ccutil.EventInterface, len(organizationEvents))
	for i, v := range organizationEvents {
		events[i] = ccutil.EventInterface(v)
	}
	return events
}

func eventInterfacesToOrganizationEvents(events []ccutil.EventInterface) ([]*profilePB.OrganizationEvent, error) {
	organizationEvents := make([]*profilePB.OrganizationEvent, len(events))
	for i, v := range events {
		var ok bool
		organizationEvents[i], ok = v.(*profilePB.OrganizationEvent)
		if !ok {
			return nil, errors.New("Could not serialize OrganizationEvent")
		}
	}
	return organizationEvents, nil
}
