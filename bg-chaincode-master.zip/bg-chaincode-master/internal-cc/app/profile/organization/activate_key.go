package organization

import (
	"errors"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

// ActivateKey links or re-activates a key with an organization
func (t *APICC) ActivateKey(stub *profilePB.ChaincodeStub, activateKeyRequest *profilePB.ActivateKeyRequest) (*sharedPB.Empty, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Processing ActivateKey request %v\n", activateKeyRequest)
	ccutil.Logger.Info("Request ACTIVATE KEY\n")

	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}

	creatorOrganizationID, err := profileutil.GetOrganizationIDFromCert(stub, creatorCert)
	if err != nil {
		return nil, err
	}

	var organizationPublicKeyMap profilePB.OrganizationPublicKeyMap
	organizationPublicKeyMapKey, err := generateOrganizationPublicKeyMapKey(stub, creatorOrganizationID)
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, organizationPublicKeyMapKey, &organizationPublicKeyMap)
	if err != nil {
		return nil, err
	}

	keyMap := organizationPublicKeyMap.GetMap()

	defaultKey, ok := keyMap["default"]
	if !ok {
		// NOTE should never occur
		return nil, errors.New("Error organization doesn't have a default key")
	}
	if defaultKey.GetKey() == creatorOrganizationID {
		return nil, errors.New("Cannot activate key, as is default key")
	}

	keyHash := ccutil.HashS(activateKeyRequest.GetKey())
	if foundKey, ok := keyMap[keyHash]; ok {
		// found an existing key
		allowedTimeRanges := foundKey.GetAllowedTimeRanges()
		lastRange := allowedTimeRanges[len(allowedTimeRanges)-1]
		if lastRange.GetExpiryDate() == nil {
			return nil, errors.New("Key is already active")
		}

		timestamp, err := ccutil.GetTxTimestamp(stub)
		if err != nil {
			return nil, err
		}

		foundKey.AllowedTimeRanges = append(allowedTimeRanges, &sharedPB.DateRange{
			StartDate: timestamp,
		})
		keyMap[keyHash] = foundKey
	} else {
		timestamp, err := ccutil.GetTxTimestamp(stub)
		if err != nil {
			return nil, err
		}
		// did not find existing key
		keyMap[keyHash] = &profilePB.OrganizationPublicKey{
			Key: activateKeyRequest.GetKey(),
			AllowedTimeRanges: []*sharedPB.DateRange{
				&sharedPB.DateRange{
					StartDate: timestamp,
				},
			},
		}
		err = profileutil.LinkPublicKeyStringToOrganizationID(stub, activateKeyRequest.GetKey(), creatorOrganizationID)
		if err != nil {
			return nil, err
		}

	}
	err = ccutil.PutStatePB(stub, organizationPublicKeyMapKey, &organizationPublicKeyMap)
	if err != nil {
		return nil, err
	}

	return &sharedPB.Empty{}, nil
}
