package organization

import (
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// GetFlow retrieves a single flow
func (t *APICC) GetFlow(stub *profilePB.ChaincodeStub, flowIDValue *sharedPB.FlowIDValue) (*profilePB.OrganizationFullFlow, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Getting flow with ID %v\n", flowIDValue)

	var status sharedPB.FlowStatus
	var startRequest profilePB.OrganizationStartRequest

	flowKey, err := ccutil.GenerateFlowKey(stub, flowIDValue.GetValue())
	if err != nil {
		return nil, err
	}

	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	status, err = profileutil.GetFlowStatus(stub, flowIDValue.GetValue())
	if err != nil {
		return nil, err
	}

	return &profilePB.OrganizationFullFlow{Flow: &startRequest, Status: status}, nil
}
