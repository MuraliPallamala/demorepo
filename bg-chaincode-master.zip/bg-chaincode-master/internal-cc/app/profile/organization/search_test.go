package organization

import (
	"strings"
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

// test search with no search parameters defined
func TestSearch(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "creatorOrgID"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Add Organization 1 through mock transaction
	organization1ID := "orgid1"
	organization1Key, err := generateOrganizationKey(stub, organization1ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	organization1 := profilePB.Organization{
		Id:         organization1ID,
		EntityName: "Organization 123",
		EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		BusinessId: "acn:123456789",
		Address:    &sharedPB.Address{StreetAddress: "123 Example Street"},
		Status:     profilePB.OrganizationStatus_ORGANIZATION_INACTIVE,
	}

	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)
	err = ccutil.PutStatePB(stub, organization1Key, &organization1)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	// Add Organization 2 through mock transaction
	organization2ID := "orgid2"
	organization2Key, err := generateOrganizationKey(stub, organization2ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	organization2 := profilePB.Organization{
		Id:         organization2ID,
		EntityName: "Organization 234",
		EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		BusinessId: "acn:987654321",
		Address:    &sharedPB.Address{StreetAddress: "987 Example Street"},
		Status:     profilePB.OrganizationStatus_ORGANIZATION_ACTIVE,
	}

	txID3 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID3)
	err = ccutil.PutStatePB(stub, organization2Key, &organization2)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID3)

	// search for organization without any search parameters specified
	args := [][]byte{[]byte(ccMethods.Search), profiletest.GenerateSearchRequestBytes(t, "", "", nil)}
	txID4 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID4, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organizations: %s", string(res.Message))
	}

	// test that all T&C records are returned
	var responsePayload profilePB.OrganizationsList
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetOrganizations()) != 2 {
		t.Fatalf("Expected two organizations returned, but got %v", len(responsePayload.GetOrganizations()))
	}
}

// Test Search with entity name as a search parameter
func TestSearchByEntityName(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "creatorOrgID"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Add Organization 1 through mock transaction
	organization1ID := "orgid1"
	organization1Key, err := generateOrganizationKey(stub, organization1ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	organization1 := profilePB.Organization{
		Id:         organization1ID,
		EntityName: "Organization 123",
		EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		BusinessId: "acn:123456789",
		Address:    &sharedPB.Address{StreetAddress: "123 Example Street"},
		Status:     profilePB.OrganizationStatus_ORGANIZATION_INACTIVE,
	}

	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)
	err = ccutil.PutStatePB(stub, organization1Key, &organization1)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	// Add Organization 2 through mock transaction
	organization2ID := "orgid2"
	organization2Key, err := generateOrganizationKey(stub, organization2ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	organization2 := profilePB.Organization{
		Id:         organization2ID,
		EntityName: "Organization 234",
		EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		BusinessId: "acn:987654321",
		Address:    &sharedPB.Address{StreetAddress: "987 Example Street"},
		Status:     profilePB.OrganizationStatus_ORGANIZATION_ACTIVE,
	}

	txID3 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID3)
	err = ccutil.PutStatePB(stub, organization2Key, &organization2)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID3)

	// search for organization without any search parameters specified
	args := [][]byte{[]byte(ccMethods.Search), profiletest.GenerateSearchRequestBytes(t, "", "Organization 2", nil)}
	txID4 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID4, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organizations: %s", string(res.Message))
	}

	// test that all T&C records are returned
	var responsePayload profilePB.OrganizationsList
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetOrganizations()) != 1 {
		t.Fatalf("Expected one organization returned, but got %v", len(responsePayload.GetOrganizations()))
	}

	if responsePayload.GetOrganizations()[0].GetEntityName() == "Organization 2" {
		t.Fatalf("Expected organization 'Organization 2' returned, but got %v", len(responsePayload.GetOrganizations()[0].GetEntityName()))
	}
}

// Test Search with business ID as a search parameter
func TestSearchByBusinessID(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "creatorOrgID"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Add Organization 1 through mock transaction
	organization1ID := "orgid1"
	organization1Key, err := generateOrganizationKey(stub, organization1ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	organization1 := profilePB.Organization{
		Id:         organization1ID,
		EntityName: "Organization 123",
		EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		BusinessId: "acn:123456789",
		Address:    &sharedPB.Address{StreetAddress: "123 Example Street"},
		Status:     profilePB.OrganizationStatus_ORGANIZATION_INACTIVE,
	}

	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)
	err = ccutil.PutStatePB(stub, organization1Key, &organization1)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	// Add Organization 2 through mock transaction
	organization2ID := "orgid2"
	organization2Key, err := generateOrganizationKey(stub, organization2ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	organization2 := profilePB.Organization{
		Id:         organization2ID,
		EntityName: "Organization 234",
		EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		BusinessId: "acn:987654321",
		Address:    &sharedPB.Address{StreetAddress: "987 Example Street"},
		Status:     profilePB.OrganizationStatus_ORGANIZATION_ACTIVE,
	}

	txID3 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID3)
	err = ccutil.PutStatePB(stub, organization2Key, &organization2)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID3)

	// search for organization without any search parameters specified
	args := [][]byte{[]byte(ccMethods.Search), profiletest.GenerateSearchRequestBytes(t, "acn:98765432", "", nil)}
	txID4 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID4, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organizations: %s", string(res.Message))
	}

	// test that all T&C records are returned
	var responsePayload profilePB.OrganizationsList
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetOrganizations()) != 1 {
		t.Fatalf("Expected one organization returned, but got %v", len(responsePayload.GetOrganizations()))
	}

	if !strings.HasPrefix(responsePayload.GetOrganizations()[0].GetBusinessId(), "acn:98765432") {
		t.Fatalf("Expected organization to contain acn:98765432, but got %v", len(responsePayload.GetOrganizations()[0].GetBusinessId()))
	}
}

// Test Search with status as a search parameter
func TestSearchByStatus(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "creatorOrgID"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Add Organization 1 through mock transaction
	organization1ID := "orgid1"
	organization1Key, err := generateOrganizationKey(stub, organization1ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	organization1 := profilePB.Organization{
		Id:         organization1ID,
		EntityName: "Organization 123",
		EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		BusinessId: "acn:123456789",
		Address:    &sharedPB.Address{StreetAddress: "123 Example Street"},
		Status:     profilePB.OrganizationStatus_ORGANIZATION_INACTIVE,
	}

	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)
	err = ccutil.PutStatePB(stub, organization1Key, &organization1)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	// Add Organization 2 through mock transaction
	organization2ID := "orgid2"
	organization2Key, err := generateOrganizationKey(stub, organization2ID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	organization2 := profilePB.Organization{
		Id:         organization2ID,
		EntityName: "Organization 234",
		EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		BusinessId: "acn:987654321",
		Address:    &sharedPB.Address{StreetAddress: "987 Example Street"},
		Status:     profilePB.OrganizationStatus_ORGANIZATION_ACTIVE,
	}

	txID3 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID3)
	err = ccutil.PutStatePB(stub, organization2Key, &organization2)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID3)

	// search for organization without any search parameters specified
	args := [][]byte{[]byte(ccMethods.Search), profiletest.GenerateSearchRequestBytes(t, "", "", &profilePB.OrganizationStatusValue{Value: profilePB.OrganizationStatus_ORGANIZATION_ACTIVE})}
	txID4 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID4, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organizations: %s", string(res.Message))
	}

	// test that all T&C records are returned
	var responsePayload profilePB.OrganizationsList
	err = ccutil.Unmarshal(res.GetPayload(), &responsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if len(responsePayload.GetOrganizations()) != 1 {
		t.Fatalf("Expected one organization returned, but got %v", len(responsePayload.GetOrganizations()))
	}

	if responsePayload.GetOrganizations()[0].GetStatus() != profilePB.OrganizationStatus_ORGANIZATION_ACTIVE {
		t.Fatalf("Expected returned organization to have status ACTIVE, but got %v", responsePayload.GetOrganizations()[0].GetStatus())
	}
}
