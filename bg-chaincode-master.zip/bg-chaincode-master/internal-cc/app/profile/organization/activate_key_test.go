package organization

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestActivateKey(t *testing.T) {

	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Onboard Parent Organization
	parentOrgID := "parentOrg"
	parentOrg := profiletest.GenerateExampleOrganization(parentOrgID)
	parentOrgCertificate := cctest.AppBenPEM1
	startRequestBytes := profiletest.GenerateStartRequestCreateBytes(t, &profilePB.OrganizationCreateRequest{Organization: &parentOrg, AdminCertificate: parentOrgCertificate})
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}
	res := stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start create flow: %s", string(res.Message))
	}

	// Onboard Subsidiary Organization
	subOrgID := "subOrg"
	subOrg := profiletest.GenerateExampleOrganization(subOrgID)
	subOrgCertificate := cctest.AppBenPEM2
	startRequestBytes = profiletest.GenerateStartRequestCreateBytes(t, &profilePB.OrganizationCreateRequest{Organization: &subOrg, AdminCertificate: subOrgCertificate})
	args = [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}
	res = stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start create flow: %s", string(res.Message))
	}

	// Activate Key
	// Switch to subsidiary org
	cctest.SetMockStubCert(t, stub, subOrgCertificate)
	linkedCertificate := cctest.AppBenPEM3
	linkedKey, err := ccutil.GetPublicKeyPEMFromCertPEM(linkedCertificate)
	if err != nil {
		t.Fatalf(err.Error())
	}

	activateKeyRequestBytes := profiletest.GenerateActivateKeyRequestBytes(t, linkedKey)
	args = [][]byte{[]byte(ccMethods.ActivateKey), activateKeyRequestBytes}
	res = stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to activate key: %s", string(res.Message))
	}

	// Check that can receive orgID from linked key
	publicKeyValueBytes := profiletest.GeneratePublicKeyValueBytes(t, linkedKey)
	args = [][]byte{[]byte(ccMethods.GetViaPublicKey), publicKeyValueBytes}
	res = stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to retrieve org via key: %s", string(res.Message))
	}
	var foundOrganizationWithKey profilePB.OrganizationWithPublicKeyInfo
	err = ccutil.Unmarshal(res.GetPayload(), &foundOrganizationWithKey)
	if err != nil {
		t.Fatalf(err.Error())
	}
	foundOrganization := foundOrganizationWithKey.GetOrganization()

	if foundOrganization.GetId() != subOrgID {
		t.Fatalf("Linked organization ID incorrect. Expected %s, but got %s", subOrgID, foundOrganization.GetId())
	}

	// Check that organization Public Key map was stored in state
	args = [][]byte{[]byte(ccMethods.GetPublicKeys), profiletest.GenerateIDValueBytes(t, subOrgID)}
	res = stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organization Public Keys: %s", string(res.Message))
	}

	var publicKeyResponsePayload profilePB.OrganizationPublicKeyMap
	err = ccutil.Unmarshal(res.GetPayload(), &publicKeyResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	storedLinkedOrgKey := publicKeyResponsePayload.Map[ccutil.HashS(linkedKey)]
	if storedLinkedOrgKey.GetKey() != linkedKey {
		t.Fatalf("Incorrect organization public key, expected:\n %v, got: %v", linkedKey, storedLinkedOrgKey.GetKey())
	}

	// Check that linked key is active
	if storedLinkedOrgKey.GetAllowedTimeRanges()[len(storedLinkedOrgKey.GetAllowedTimeRanges())-1].GetExpiryDate() != nil {
		t.Fatal("Expected linked key to be active, but it is deactivated")
	}
}
