package organization

import (
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// GetViaPublicKey retrieves the organization via a public key
func (t *APICC) GetViaPublicKey(stub *profilePB.ChaincodeStub, publicKeyValue *profilePB.PublicKeyValue) (*profilePB.OrganizationWithPublicKeyInfo, error) {
	profileutil.Setup()

	organizationID, err := profileutil.GetOrganizationIDFromPublicKey(stub, publicKeyValue.GetValue())
	if err != nil {
		return nil, err
	}
	idValue := &sharedPB.IDValue{Value: organizationID}
	organization, err := t.Get(stub, idValue)
	if err != nil {
		return nil, err
	}
	organizationPublicKeyMap, err := t.GetPublicKeys(stub, idValue)
	if err != nil {
		return nil, err
	}

	inputKeyHash := ccutil.HashS(publicKeyValue.GetValue())
	publicKey := organizationPublicKeyMap.GetMap()[inputKeyHash]

	return &profilePB.OrganizationWithPublicKeyInfo{
		Organization: organization,
		PublicKey:    publicKey,
	}, nil
}
