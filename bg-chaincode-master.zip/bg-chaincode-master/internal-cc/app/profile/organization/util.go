package organization

import (
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

// APICC is a concrete implementation of the generated interface OrganizationAPIInterface
type APICC struct{}

// StoreOrganizationEvent stores an organisation event on the ledger
func StoreOrganizationEvent(stub *profilePB.ChaincodeStub, event *profilePB.OrganizationEvent) error {
	eventKey, err := generateOrganizationEventKey(stub, event.GetId())
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, eventKey, event)
	return err
}

func generateOrganizationKey(stub shim.ChaincodeStubInterface, orgID string) (string, error) {
	return stub.CreateCompositeKey(profileutil.OTOrganization, []string{orgID})
}

func generateOrganizationPublicKeyMapKey(stub shim.ChaincodeStubInterface, orgID string) (string, error) {
	return stub.CreateCompositeKey(profileutil.OTOrganizationPublicKeyMap, []string{orgID})
}

// GenerateOrganizationIterator generates an interator over all organizations
func GenerateOrganizationIterator(stub shim.ChaincodeStubInterface) (shim.StateQueryIteratorInterface, error) {
	return stub.GetStateByPartialCompositeKey(profileutil.OTOrganization, []string{})
}

func generateOrganizationEventKey(stub shim.ChaincodeStubInterface, eventID string) (string, error) {
	return stub.CreateCompositeKey(profileutil.OTOrganizationEvents, []string{eventID})
}

// generateOrganizationEventIterator generates an interator over all organization events
func generateOrganizationEventIterator(stub shim.ChaincodeStubInterface) (shim.StateQueryIteratorInterface, error) {
	return stub.GetStateByPartialCompositeKey(profileutil.OTOrganizationEvents, []string{})
}

func getRequestFromStartRequest(startRequest *profilePB.OrganizationStartRequest) (ccutil.RequestInterface, error) {
	switch t := startRequest.Request.(type) {
	case *profilePB.OrganizationStartRequest_CreateRequest:
		return startRequest.GetCreateRequest(), nil
	case *profilePB.OrganizationStartRequest_ProfileChangeRequest:
		return startRequest.GetProfileChangeRequest(), nil
	default:
		return nil, fmt.Errorf("Invalid Request Type %T", t)
	}
}

// GetOrganizationFlowActions gets all action for a flow
func GetOrganizationFlowActions(stub shim.ChaincodeStubInterface, flowID string) ([]*profilePB.OrganizationFlowActionRequest, error) {
	var requests []*profilePB.OrganizationFlowActionRequest

	iterator, err := ccutil.GenerateFlowActionIterator(stub, flowID)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	for iterator.HasNext() {
		requestKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		requestBytes := requestKV.GetValue()

		var request profilePB.OrganizationFlowActionRequest
		err = ccutil.Unmarshal(requestBytes, &request)
		if err != nil {
			return nil, err
		}

		requests = append(requests, &request)
	}

	return requests, nil
}

// hasActivePreviouslyCreatedOrApprovedFlow checks whether the creator has previously approved a flow
func hasActivePreviouslyCreatedOrApprovedFlow(start ccutil.MetadataInterface, approvals []*sharedPB.FlowActionRequest, creatorOrganizationID string) bool {
	if start.GetCreatedBy() == creatorOrganizationID {
		return true
	}

	for _, approval := range approvals {
		if approval.GetCreatedBy() == creatorOrganizationID {
			return true
		}
	}

	return false
}
