package organization

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

// TODO refactor to reuse code
func TestGet(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// New organization details
	newOrganizationID := "orgid2"
	newOrganizationKey, err := generateOrganizationKey(stub, newOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}
	newOrganization := profiletest.GenerateExampleOrganization(newOrganizationID)

	args := [][]byte{[]byte(ccMethods.Get), profiletest.GenerateIDValueBytes(t, newOrganizationID)}

	// Test for failure when Organization doesn't exist
	txID1 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID1, args)
	if res.Status == shim.OK {
		t.Fatalf("Expected Organization to fail since organization does not exist: %s", string(res.Message))
	}

	// Add organization through mock transaction
	txID2 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID2)

	err = ccutil.PutStatePB(stub, newOrganizationKey, &newOrganization)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID2)

	// Test for successful invoke of get organization
	txID3 := cctest.GenerateMockTxID("")
	res = stub.MockInvoke(txID3, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organization: %s", string(res.Message))
	}

	// Check all fields of the organization
	var getOrganizationResponsePayload profilePB.Organization
	err = ccutil.Unmarshal(res.GetPayload(), &getOrganizationResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	if getOrganizationResponsePayload.GetId() != newOrganizationID {
		t.Fatalf("Error incorrect organization ID, expected: %s, got: %s", newOrganizationID, getOrganizationResponsePayload.GetId())
	}

	if getOrganizationResponsePayload.GetEntityName() != newOrganization.EntityName {
		t.Fatalf("Error incorrect organization name, expected: %s, got: %s", newOrganization.EntityName, getOrganizationResponsePayload.GetEntityName())
	}

	if getOrganizationResponsePayload.GetEntityType() != newOrganization.EntityType {
		t.Fatalf("Error incorrect organization type, expected: %s, got: %s", newOrganization.EntityType, getOrganizationResponsePayload.GetEntityType())
	}

	if getOrganizationResponsePayload.GetAddress().StreetAddress != newOrganization.Address.StreetAddress {
		t.Fatalf("Error incorrect organization type, expected: %s, got: %s", newOrganization.Address, getOrganizationResponsePayload.GetAddress())
	}

	if getOrganizationResponsePayload.GetBusinessId() != newOrganization.BusinessId {
		t.Fatalf("Error incorrect organization business ID, expected: %s, got: %s", newOrganization.BusinessId, getOrganizationResponsePayload.GetBusinessId())
	}

	if getOrganizationResponsePayload.GetStatus() != newOrganization.Status {
		t.Fatalf("Error incorrect organization status, expected: %s, got: %s", newOrganization.Status, getOrganizationResponsePayload.GetStatus())
	}
}
