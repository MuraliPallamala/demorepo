package organization

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestGetFlowActionsCreateProfile(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"

	// Test that error is returned when no flow exist
	txID1 := cctest.GenerateMockTxID("")
	args1 := [][]byte{[]byte(ccMethods.GetFlowActions), profiletest.GenerateFlowIDValueBytes(t, "mockFlowID123")}
	res := stub.MockInvoke(txID1, args1)
	if res.Status == shim.OK {
		t.Fatalf("Expected GetFlowActions to fail since flow does not exist: %s", string(res.Message))
	}

	// Submit start flow request
	createflowRequestTxID := cctest.GenerateMockTxID("")
	createFlowResponsePayload := profiletest.InvokeOrganizationStartFlowCreate(t, stub, createflowRequestTxID, &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id: creatorOrganizationID,
		},
		SelfOnboarding: true,
	})
	flowID := createFlowResponsePayload.GetValue()

	// Test that actions is returned containing no flow
	txID2 := cctest.GenerateMockTxID("")
	args2 := [][]byte{[]byte(ccMethods.GetFlowActions), profiletest.GenerateFlowIDValueBytes(t, flowID)}
	res = stub.MockInvoke(txID2, args2)

	var flowActionsResponsePayload profilePB.OrganizationFlowActionsResponse
	if res.Status != shim.OK {
		t.Fatalf("Failed to get flow actions: %s", string(res.Message))
	}

	err := ccutil.Unmarshal(res.GetPayload(), &flowActionsResponsePayload)
	if err != nil {
		t.Fatal(err.Error())
	}

	if len(flowActionsResponsePayload.GetRequests()) != 0 {
		t.Fatalf("Expected response to contain 0 requests, but recieved: %v", flowActionsResponsePayload.GetRequests())
	}
}

func TestGetFlowActionsProfileChange(t *testing.T) {
	stub := setupChaincodeMockStub(t)

	creatorOrganizationID := "orgid1"
	err := profiletest.LinkPEMOrganizationID(stub, cctest.ConsortiumPEM, creatorOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// New organization details
	newOrganizationID := "orgid2"
	newOrganization := profiletest.GenerateExampleOrganization(newOrganizationID)
	newOrganizationKey, err := generateOrganizationKey(stub, newOrganizationID)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Add organization through mock transaction
	txID1 := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID1)

	err = ccutil.PutStatePB(stub, newOrganizationKey, &newOrganization)
	if err != nil {
		t.Fatal(err.Error())
	}
	stub.MockTransactionEnd(txID1)

	// Organization update details
	entityName := "acn:0000000"
	// TODO add address and status changes

	profileChangeRequest := profilePB.OrganizationProfileChangeRequest{
		OrganizationId: newOrganizationID,
		EntityName:     entityName,
	}

	startRequestBytes := profiletest.GenerateStartRequestProfileChangeBytes(t, &profileChangeRequest)
	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	// Test for successful invoke
	txID2 := cctest.GenerateMockTxID("")
	res := stub.MockInvoke(txID2, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start profile change flow: %s", string(res.Message))
	}

	// Test that flow ID is returned
	var startFlowResponsePayload sharedPB.FlowIDValue
	err = ccutil.Unmarshal(res.GetPayload(), &startFlowResponsePayload)
	if err != nil {
		t.Fatalf(err.Error())
	}

	// Test that ID is returned
	flowID := startFlowResponsePayload.GetValue()
	if len(startFlowResponsePayload.GetValue()) == 0 {
		t.Fatal("Empty Flow ID is returned")
	}

	// Test that history is returned containing start flow
	txID3 := cctest.GenerateMockTxID("")
	args2 := [][]byte{[]byte(ccMethods.GetFlowActions), profiletest.GenerateFlowIDValueBytes(t, flowID)}
	res = stub.MockInvoke(txID3, args2)

	var payload2 profilePB.OrganizationFlowActionsResponse
	if res.Status != shim.OK {
		t.Fatalf("Failed to get flow actions: %s", string(res.Message))
	}

	err = ccutil.Unmarshal(res.GetPayload(), &payload2)
	if err != nil {
		t.Fatal(err.Error())
	}

	if len(payload2.GetRequests()) != 0 {
		t.Fatalf("Expected response to contain no requests request, but recieved: %v", payload2.GetRequests())
	}
}
