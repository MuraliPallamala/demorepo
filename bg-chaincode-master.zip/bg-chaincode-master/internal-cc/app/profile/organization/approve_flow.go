package organization

import (
	"errors"
	"fmt"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

// ApproveFlow handles the approval of existing Flow
func (t *APICC) ApproveFlow(stub *profilePB.ChaincodeStub, flowActionRequest *sharedPB.FlowActionRequest) (*sharedPB.FlowIDValue, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Processing ApproveFlow action %v\n", flowActionRequest)
	ccutil.Logger.Infof("Action APPROVE flow (id: %v, requestId: %v)\n", flowActionRequest.Id, flowActionRequest.GetFlowId())

	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}

	creatorOrganizationID, err := profileutil.GetOrganizationIDFromCert(stub, creatorCert)
	if err != nil {
		return nil, err
	}

	err = ccutil.SetCreatedMetadata(stub, flowActionRequest, creatorOrganizationID)
	if err != nil {
		return nil, err
	}
	flowActionRequest.RequestType = sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE

	// Check if Flow is active
	flowActive, err := profileutil.CheckFlowStatus(stub, flowActionRequest.GetFlowId(), sharedPB.FlowStatus_FLOW_ACTIVE)
	if err != nil {
		return nil, err
	}
	if !flowActive {
		return nil, errors.New("Request is not active")
	}

	// Get Start Request (implicitly an approval)
	flowKey, err := ccutil.GenerateFlowKey(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}

	var startRequest profilePB.OrganizationStartRequest
	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	// Check if creator is part of approval flow
	allowedToApprove, err := isAllowedToApproveFlow(&startRequest, creatorOrganizationID)
	if err != nil {
		return nil, err
	}
	if !allowedToApprove {
		return nil, errors.New("Organization is not allowed to approve request")
	}

	// Get Previous approvals
	var approvals []*sharedPB.FlowActionRequest
	actions, err := GetOrganizationFlowActions(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}
	for _, action := range actions {
		actionRequest := action.GetFlowActionRequest()
		if actionRequest.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE {
			approvals = append(approvals, actionRequest)
		}
	}

	// Check if Creator has already approved
	previouslyApprovedFlow, err := hasPreviouslyCreatedOrApprovedOrganizationFlow(&startRequest, approvals, creatorOrganizationID)
	if err != nil {
		return nil, err
	}
	if previouslyApprovedFlow {
		return nil, errors.New("Organization has previously approved")
	}

	// Write approval to state
	flowActionKey, err := ccutil.GenerateFlowActionKey(stub, flowActionRequest.GetFlowId(), len(approvals))
	if err != nil {
		return nil, err
	}
	err = ccutil.PutStatePB(stub, flowActionKey, &profilePB.OrganizationFlowActionRequest{Request: &profilePB.OrganizationFlowActionRequest_FlowActionRequest{FlowActionRequest: flowActionRequest}})
	if err != nil {
		return nil, err
	}

	// start request + actions + current request
	numApprovals := 1 + len(approvals)

	// Finish if required number of approvals have been met
	switch startRequest.Request.(type) {
	case *profilePB.OrganizationStartRequest_ProfileChangeRequest:
		if numApprovals >= len(startRequest.GetProfileChangeRequest().GetRequiredApprovals()) {
			err := finishOrganizationProfileChange(stub, startRequest.GetProfileChangeRequest())
			if err != nil {
				return nil, err
			}
		}
	default:
		return nil, fmt.Errorf("Invalid Request Type %T", t)
	}

	return &sharedPB.FlowIDValue{Value: flowActionRequest.GetFlowId()}, nil
}

func hasPreviouslyCreatedOrApprovedOrganizationFlow(start *profilePB.OrganizationStartRequest, approvals []*sharedPB.FlowActionRequest, creatorOrganizationID string) (bool, error) {
	var request ccutil.MetadataInterface
	switch t := start.Request.(type) {
	case *profilePB.OrganizationStartRequest_CreateRequest:
		request = start.GetCreateRequest()
	case *profilePB.OrganizationStartRequest_ProfileChangeRequest:
		request = start.GetProfileChangeRequest()
	default:
		return false, fmt.Errorf("Invalid Request Type %T", t)
	}
	return hasActivePreviouslyCreatedOrApprovedFlow(request, approvals, creatorOrganizationID), nil
}

func isAllowedToApproveFlow(start *profilePB.OrganizationStartRequest, creatorOrganizationID string) (bool, error) {
	var requiredApprovals []string
	switch t := start.Request.(type) {
	case *profilePB.OrganizationStartRequest_ProfileChangeRequest:
		requiredApprovals = start.GetProfileChangeRequest().GetRequiredApprovals()
	default:
		return false, fmt.Errorf("Invalid Request Type %T", t)
	}

	return ccutil.ContainsString(requiredApprovals, creatorOrganizationID), nil
}
