package organization

import (
	"errors"
	"fmt"
	"strings"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

// AdminUpdate : Updates the public certificate of an organization
func (t *APICC) AdminUpdate(stub *profilePB.ChaincodeStub, organizationUpdateRequest *profilePB.OrganizationUpdateRequest) (*sharedPB.Empty, error) {
	profileutil.Setup()

	var orgID = organizationUpdateRequest.OrganizationId

	ccutil.Logger.Debugf("Processing admin certificate update request for %v\n", orgID)
	ccutil.Logger.Infof("Request UPDATE ADMIN CERTIFICATE (orgId: %v)\n", orgID)

	// Check whether issuer is a part of the consortium organization
	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}

	isConsortium, err := ccutil.IsConsortium(stub, creatorCert)
	if err != nil {
		return nil, err
	}
	if !isConsortium {
		return nil, errors.New("AdminUpdate is a consortium only operation")
	}

	// Get organization
	var organization profilePB.Organization
	orgKey, err := generateOrganizationKey(stub, orgID)
	if err != nil {
		return nil, err
	}

	err = ccutil.GetStatePB(stub, orgKey, &organization)
	if err != nil {
		return nil, err
	}

	// Check Certificate has not been used before
	orgCert, err := ccutil.PEMToCert(organizationUpdateRequest.GetAdminCertificate())
	if err != nil {
		return nil, err
	}

	existingOrgID, err := profileutil.GetOrganizationIDFromCert(stub, orgCert)

	if existingOrgID != "" {
		return nil, fmt.Errorf("Public key is already used and is linked to %s", existingOrgID)
	}

	// TODO HACK refactor to have distinct error types
	if err != nil && !strings.Contains(err.Error(), "does not exist") {
		return nil, err
	}

	// creatorOrganizationID, err := profileutil.GetOrganizationIDFromCert(stub, creatorCert)
	// if err != nil {
	//   return nil, err
	// }

	// ccutil.SetCreatedMetadata(stub, organizationUpdateRequest, creatorOrganizationID)

	organizationPublicKeyString, err := ccutil.GetPublicKeyPEMFromCertPEM(organizationUpdateRequest.GetAdminCertificate())
	if err != nil {
		return nil, err
	}

	var organizationPublicKeyMap profilePB.OrganizationPublicKeyMap
	organizationPublicKeyMap.Map = make(map[string]*profilePB.OrganizationPublicKey)
	defaultPublicKey := &profilePB.OrganizationPublicKey{
		Key: organizationPublicKeyString,
		AllowedTimeRanges: []*sharedPB.DateRange{
			&sharedPB.DateRange{
				StartDate: organizationUpdateRequest.GetCreatedAt(),
			},
		},
	}

	// store under hash
	keyHash := ccutil.HashS(organizationPublicKeyString)
	organizationPublicKeyMap.Map[keyHash] = defaultPublicKey

	// store under "default" key for easy usage by clients
	organizationPublicKeyMap.Map["default"] = defaultPublicKey

	organizationPublicKeyMapKey, err := generateOrganizationPublicKeyMapKey(stub, organization.GetId())
	if err != nil {
		return nil, err
	}
	err = ccutil.PutStatePB(stub, organizationPublicKeyMapKey, &organizationPublicKeyMap)
	if err != nil {
		return nil, err
	}

	// Link public key to organization ID
	err = profileutil.LinkCertificateToOrganizationID(stub, orgCert, organization.GetId())
	if err != nil {
		return nil, err
	}

	err = ccutil.PutStatePB(stub, orgKey, &organization)
	if err != nil {
		return nil, err
	}

	return &sharedPB.Empty{}, nil
}
