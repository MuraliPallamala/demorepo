package organization

import (
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestActivate(t *testing.T) {
	stub := setupChaincodeMockStub(t)
	consortiumOrganizationID := "consortium"
	issuerOrgID := "issuer"

	profiletest.InvokeOrganizationStartFlowCreate(t, stub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id:         consortiumOrganizationID,
			EntityType: profilePB.OrganizationEntityType_ORGANIZATION_CONSORTIUM,
		},
		SelfOnboarding: true,
	})

	// Create Issuer Organization
	profiletest.InvokeOrganizationStartFlowCreate(t, stub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id:         issuerOrgID,
			EntityType: profilePB.OrganizationEntityType_ORGANIZATION_ISSUER,
		},
		AdminCertificate: cctest.ANZPEM,
	})

	// Deactivate Organization
	profiletest.InvokeOrganizationDeactivate(t, stub, cctest.GenerateMockTxID(""), issuerOrgID)

	// Inspect deactivated Organization
	issuer := profiletest.InvokeOrganizationGet(t, stub, cctest.GenerateMockTxID(""), issuerOrgID)

	if issuer.GetStatus() != profilePB.OrganizationStatus_ORGANIZATION_INACTIVE {
		t.Fatal("Precondition failed, cannot deactivate organization.")
	}

  // Deactivate Organization
	profiletest.InvokeOrganizationActivate(t, stub, cctest.GenerateMockTxID(""), issuerOrgID)

  // Inspect activated Organization
	issuer = profiletest.InvokeOrganizationGet(t, stub, cctest.GenerateMockTxID(""), issuerOrgID)

  if issuer.GetStatus() != profilePB.OrganizationStatus_ORGANIZATION_ACTIVE {
  		t.Fatal("Expected organization to be set ACTIVE.")
  }
}
