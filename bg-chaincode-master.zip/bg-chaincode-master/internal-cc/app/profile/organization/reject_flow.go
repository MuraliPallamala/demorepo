package organization

import (
	"errors"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

// RejectFlow handles the rejection of existing Flow
func (t *APICC) RejectFlow(stub *profilePB.ChaincodeStub, flowActionRequest *sharedPB.FlowActionRequest) (*sharedPB.FlowIDValue, error) {
	profileutil.Setup()

	ccutil.Logger.Debugf("Processing RejectFlow action %v\n", flowActionRequest)
	ccutil.Logger.Infof("Action REJECT flow (requestId: %v)\n", flowActionRequest.GetFlowId())

	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return nil, err
	}
	creatorOrganizationID, err := profileutil.GetOrganizationIDFromCert(stub, creatorCert)
	if err != nil {
		return nil, err
	}
	err = ccutil.SetCreatedMetadata(stub, flowActionRequest, creatorOrganizationID)
	if err != nil {
		return nil, err
	}
	flowActionRequest.RequestType = sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_REJECT

	flowActive, err := profileutil.CheckFlowStatus(stub, flowActionRequest.GetFlowId(), sharedPB.FlowStatus_FLOW_ACTIVE)
	if err != nil {
		return nil, err
	}
	if !flowActive {
		return nil, errors.New("Request is not active")
	}

	// Get Start Request
	var startRequest profilePB.OrganizationStartRequest
	flowKey, err := ccutil.GenerateFlowKey(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	// Check whether current creator is part of approval flow as they are the only ones allowed to reject
	allowedToApprove, err := isAllowedToApproveFlow(&startRequest, creatorOrganizationID)
	if err != nil {
		return nil, err
	}
	if !allowedToApprove {
		return nil, errors.New("Organization is not allowed to reject request")
	}

	// TODO confirm that organization is allowed to reject after approving otherwise add check to make sure it hasn't approved

	seqNum := 0
	iterator, err := ccutil.GenerateFlowActionIterator(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}
	defer iterator.Close()
	for iterator.HasNext() {
		seqNum++
		_, err = iterator.Next()
		if err != nil {
			return nil, err
		}
	}

	// Add cancel request to flow
	flowActionKey, err := ccutil.GenerateFlowActionKey(stub, flowActionRequest.GetFlowId(), seqNum)
	if err != nil {
		return nil, err
	}
	err = ccutil.PutStatePB(stub, flowActionKey, &profilePB.OrganizationFlowActionRequest{Request: &profilePB.OrganizationFlowActionRequest_FlowActionRequest{FlowActionRequest: flowActionRequest}})
	if err != nil {
		return nil, err
	}

	// Update flow status to cancelled
	flowStatusKey, err := profileutil.GenerateFlowStatusKey(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}
	err = ccutil.PutStateInt(stub, flowStatusKey, int(sharedPB.FlowStatus_FLOW_REJECTED))
	if err != nil {
		return nil, err
	}

	return &sharedPB.FlowIDValue{Value: flowActionRequest.GetFlowId()}, nil
}
