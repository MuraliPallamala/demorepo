package gx

import (
	"errors"
	"fmt"
	"math"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

func (t *APICC) finishFlow(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, actions []*guaranteePB.GXFlowActionRequest, info *creatorInfo) error {
	guaranteeutil.Setup()

	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		return err
	}

	valid, err := t.validateFinishFlow(stub, startRequest, info)
	if err != nil {
		return err
	}
	if !valid {
		return errors.New("Cannot finish flow, request is invalid")
	}

	// Look for any recall requests
	var targetStartRequest *guaranteePB.GXStartRequest
	if actions != nil {
		for i := len(actions) - 1; i >= 0; i-- {
			action := actions[i]
			if x, ok := action.GetRequest().(*guaranteePB.GXFlowActionRequest_RecallRequest); ok {
				targetStartRequest = x.RecallRequest.GetUpdatedRequest()
				break
			}
		}
	}
	if targetStartRequest == nil {
		targetStartRequest = startRequest
	}

	requestType, err := getRequestType(startRequest)
	if err != nil {
		return err
	}

	if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_ISSUE {
		// Add Guararantee ID to request
		gxID, err := t.generateGXIDFromFlowID(stub, baseRequest.GetId())
		if err != nil {
			return err
		}
		targetStartRequest.GetGxIssueRequest().GxId = gxID
	}

	var closedFlowIds []string
	// Close open flows
	if requestType != guaranteePB.GXRequestType_GX_REQUEST_TYPE_ISSUE {
		gx, err := get(stub, baseRequest.GetGxId())
		if err != nil {
			return err
		}

		isCloseRequestResult, err := t.isCloseRequest(targetStartRequest, gx)
		if err != nil {
			return err
		}

		if isCloseRequestResult {
			activeFlowsMask := ccutil.Bitmask(gx.GetActiveFlows())
			if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_CANCEL {
				activeFlowsMask.Clear(guaranteeutil.AFCancel)
			} else if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_DEMAND {
				activeFlowsMask.Clear(guaranteeutil.AFDemand)
			} else if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_TRANSFER {
				activeFlowsMask.Clear(guaranteeutil.AFTransfer)
			}

			// Check if there are any active flows
			if activeFlowsMask != 0 {
				activeFlows, err := t.getActiveFlows(stub, baseRequest.GetId(), baseRequest.GetGxId())
				if err != nil {
					return err
				}
				closedFlowIds, err = t.closeFlows(stub, activeFlows, info)
				if err != nil {
					return err
				}
			}
		} else if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_AMEND || requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_DEMAND {
			// If is an amend or a demand that doesn't close guarantee, close amend+demand+transfer requests
			activeFlowsMask := ccutil.Bitmask(gx.GetActiveFlows())

			if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_DEMAND {
				activeFlowsMask.Clear(guaranteeutil.AFDemand)
			} else if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_AMEND {
				activeFlowsMask.Clear(guaranteeutil.AFAmend)
			}

			if activeFlowsMask.Has(guaranteeutil.AFAmend) || activeFlowsMask.Has(guaranteeutil.AFDemand) || activeFlowsMask.Has(guaranteeutil.AFTransfer) {
				activeFlows, err := t.getActiveFlows(stub, baseRequest.GetId(), baseRequest.GetGxId())
				if err != nil {
					return err
				}
				flowsToClose := []*guaranteePB.GXStartRequest{}
				for _, activeFlow := range activeFlows {
					requestType, err := getRequestType(startRequest)
					if err != nil {
						return err
					}
					if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_AMEND || requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_DEMAND || requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_TRANSFER {
						flowsToClose = append(flowsToClose, activeFlow)
					}
				}
				closedFlowIds, err = t.closeFlows(stub, flowsToClose, info)
				if err != nil {
					return err
				}

			}
		}
	}

	switch rType := targetStartRequest.Request.(type) {
	case *guaranteePB.GXStartRequest_GxIssueRequest:
		err = t.finishIssue(stub, targetStartRequest, actions, info.organization)
	case *guaranteePB.GXStartRequest_GxAmendRequest:
		err = t.finishAmend(stub, targetStartRequest, actions, closedFlowIds, info.organization)
	case *guaranteePB.GXStartRequest_GxDemandRequest:
		err = t.finishDemand(stub, targetStartRequest, actions, closedFlowIds, info.organization)
	case *guaranteePB.GXStartRequest_GxPayWalkRequest:
		err = t.finishPayWalk(stub, targetStartRequest, closedFlowIds, info.organization)
	case *guaranteePB.GXStartRequest_GxCancelRequest:
		err = t.finishCancel(stub, targetStartRequest, actions, closedFlowIds, info.organization)
	case *guaranteePB.GXStartRequest_GxTransferRequest:
		newGXID := actions[len(actions)-1].GetFlowActionRequest().GetNewGxId() // Retreive gxID from last action
		err = t.finishTransfer(stub, targetStartRequest, actions, closedFlowIds, newGXID, info.organization)
	case *guaranteePB.GXStartRequest_GxExpireRequest:
		err = t.finishExpire(stub, targetStartRequest, closedFlowIds, info.organization)
	default:
		err = fmt.Errorf("Invalid Request Type %T", rType)
	}
	if err != nil {
		return err
	}

	stub.SetResponseCode(200)
	return nil
}

func (t *APICC) validateFinishFlow(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, info *creatorInfo) (bool, error) {
	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		return false, err
	}

	if baseRequest.GetStatus() != sharedPB.FlowStatus_FLOW_ACTIVE {
		return false, errors.New("Cannot finish flow, as flow is no longer active")
	}
	requestType, err := getRequestType(startRequest)
	if err != nil {
		return false, err
	}

	var gx *guaranteePB.GX

	if requestType != guaranteePB.GXRequestType_GX_REQUEST_TYPE_ISSUE {
		gx, err = get(stub, baseRequest.GetGxId())
		if err != nil {
			return false, err
		}
		active, err := isGXActive(stub, gx)
		if err != nil {
			return false, err
		}

		if !active &&
			!(requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_EXPIRE && gx.GetStatus() == guaranteePB.GXStatus_GX_ACTIVE) {
			return false, errors.New("Cannot finish flow, as guarantee is no longer active")
		}
	}

	if (requestType != guaranteePB.GXRequestType_GX_REQUEST_TYPE_DEMAND) &&
		(requestType != guaranteePB.GXRequestType_GX_REQUEST_TYPE_PAY_WALK) {
		activeFlowsMask := ccutil.Bitmask(gx.GetActiveFlows())
		if activeFlowsMask.Has(guaranteeutil.AFDemand) {
			return false, errors.New("Cannot finish flow, demand in progress")
		}
		if (requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_AMEND || requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_TRANSFER) &&
			activeFlowsMask.Has(guaranteeutil.AFCancel) {
			return false, errors.New("Cannot finish flow, cancel in progress")
		}
	}

	return true, nil
}

func (t *APICC) getActiveFlows(stub *guaranteePB.ChaincodeStub, currFlowID, gxID string) ([]*guaranteePB.GXStartRequest, error) {
	if gxID == "" {
		return make([]*guaranteePB.GXStartRequest, 0), nil
	}
	searchRequest := &guaranteePB.GXFlowSearchRequest{
		GxId: gxID,
		Status: &sharedPB.FlowStatusValue{
			Value: sharedPB.FlowStatus_FLOW_ACTIVE,
		},
		Limit: math.MaxInt32,
	}
	searchFlowsResponse, err := t.SearchFlows(stub, searchRequest)
	if err != nil {
		return nil, err
	}
	searchActiveFlows := searchFlowsResponse.GetFlows()

	// Filter out current request
	activeFlows := make([]*guaranteePB.GXStartRequest, 0)
	for _, activeFlow := range searchActiveFlows {
		activeBaseRequest, err := getRequestFromStartRequest(activeFlow)
		if err != nil {
			return nil, err
		}
		if activeBaseRequest.GetId() != currFlowID {
			activeFlows = append(activeFlows, activeFlow)
		}
	}

	return activeFlows, nil
}

func (t *APICC) closeFlows(stub *guaranteePB.ChaincodeStub, activeFlows []*guaranteePB.GXStartRequest, info *creatorInfo) ([]string, error) {
	closedIds := make([]string, 0)
	for _, activeFlow := range activeFlows {
		activeBaseRequest, err := getRequestFromStartRequest(activeFlow)
		if err != nil {
			return nil, err
		}

		setStatus(activeBaseRequest, sharedPB.FlowStatus_FLOW_CANCELLED)

		// cases where there are additional approvals
		flowKey, err := ccutil.GenerateFlowKey(stub, activeBaseRequest.GetId())
		if err != nil {
			return nil, err
		}
		err = ccutil.PutStatePB(stub, flowKey, activeFlow)
		if err != nil {
			return nil, err
		}
		closedIds = append(closedIds, activeBaseRequest.GetId())
	}

	return closedIds, nil
}

func (t *APICC) finishIssue(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, actions []*guaranteePB.GXFlowActionRequest, organization *profilePB.Organization) error {
	// Finish Flow
	err := t.finaliseFlowRequest(stub, organization, startRequest, actions, nil)
	if err != nil {
		return err
	}

	gxIssueRequest := startRequest.GetGxIssueRequest()

	// last action is the issuer's which contains the bank reference.
	gxIssueRequest.Gx.BankReference = actions[len(actions)-1].GetFlowActionRequest().GetBankReference()

	gx := gxIssueRequest.GetGx()
	// Add Guarantee metadata. NOTE these updates are not permanently stored on the Request
	issuedAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}
	gx.IssuedAt = issuedAt
	gx.UpdatedAt = issuedAt
	gx.Id = gxIssueRequest.GetGxId()

	// Put Guarantee into state
	gxKey, err := generateGXKey(stub, gx.GetId())
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, gxKey, gx)
	if err != nil {
		return err
	}

	// Emit event
	return t.storeAndEmitFinishFlowEvent(stub, startRequest, actions, nil)
}

func (t *APICC) finishAmend(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, actions []*guaranteePB.GXFlowActionRequest, closedFlowIds []string, organization *profilePB.Organization) error {
	// Finish Flow
	err := t.finaliseFlowRequest(stub, organization, startRequest, actions, closedFlowIds)
	if err != nil {
		return err
	}

	gxAmendRequest := startRequest.GetGxAmendRequest()
	gx, err := get(stub, gxAmendRequest.GetGxId())
	if err != nil {
		return err
	}

	// Generate Guarantee key
	gxKey, err := generateGXKey(stub, gx.GetId())
	if err != nil {
		return err
	}

	// Modify fields
	if gxAmendRequest.Purpose != nil {
		gxPurpose := gx.GetPurpose()
		amendPurpose := gxAmendRequest.GetPurpose()

		for k, v := range amendPurpose {
			if gxPurpose[k] != nil {
				if gxPurpose[k].GetElementType() == guaranteePB.GxPurposeElementType_MAP {
					for k2, v2 := range amendPurpose[k].GetMapValue() {
						gxPurpose[k].GetMapValue()[k2] = v2
					}
				} else {
					gxPurpose[k] = v
				}
			} else {
				gxPurpose[k] = v
			}
		}
	}

	if gxAmendRequest.GetAmount() != 0 {
		gx.Amount.Outstanding = gxAmendRequest.GetAmount()
	}

	if gxAmendRequest.GetExpiresAt() != nil || gxAmendRequest.GetExpiresAtOpenEnded() {
		// TODO validate that it's not before the gx was created
		gx.ExpiresAt = gxAmendRequest.GetExpiresAt()
	}

	// Clear activeRequests amend bitmask flag
	activeFlowsMask := ccutil.Bitmask(gx.GetActiveFlows())
	activeFlowsMask.Clear(guaranteeutil.AFAmend)
	gx.ActiveFlows = uint32(activeFlowsMask)

	// Add Guarantee metadata
	updatedAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}
	gx.UpdatedAt = updatedAt

	// Put Guarantee into state
	err = ccutil.PutStatePB(stub, gxKey, gx)
	if err != nil {
		return err
	}

	// Emit event
	return t.storeAndEmitFinishFlowEvent(stub, startRequest, actions, closedFlowIds)
}

func (t *APICC) finishDemand(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, actions []*guaranteePB.GXFlowActionRequest, closedFlowIds []string, organization *profilePB.Organization) error {
	// Make demand visible to applicant
	gxDemandRequest := startRequest.GetGxDemandRequest()
	gx, err := get(stub, gxDemandRequest.GetGxId())
	if err != nil {
		return err
	}

	gxDemandRequest.OrgIds = append(gx.GetApplicants(), gx.GetBeneficiaries()...)

	// Finish Flow
	err = t.finaliseFlowRequest(stub, organization, startRequest, actions, closedFlowIds)
	if err != nil {
		return err
	}

	err = validateGxDemand(gx, gxDemandRequest)
	if err != nil {
		return err
	}

	gx.Amount.Outstanding -= gxDemandRequest.GetAmount()
	gx.Amount.Demanded += gxDemandRequest.GetAmount()

	// Generate Guarantee key
	gxKey, err := generateGXKey(stub, gx.GetId())
	if err != nil {
		return err
	}

	// Add Guarantee metadata
	updatedAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}
	gx.UpdatedAt = updatedAt

	if gx.GetAmount().GetOutstanding() == 0 {
		gx.Status = guaranteePB.GXStatus_GX_DEMANDED

		// Clear all activeRequests
		gx.ActiveFlows = 0
	} else {
		// Clear activeRequests demand bitmask flag
		activeFlowsMask := ccutil.Bitmask(gx.GetActiveFlows())
		activeFlowsMask.Clear(guaranteeutil.AFDemand)
		gx.ActiveFlows = uint32(activeFlowsMask)
	}

	// Put Guarantee into state
	err = ccutil.PutStatePB(stub, gxKey, gx)
	if err != nil {
		return err
	}

	// Emit event
	return t.storeAndEmitFinishFlowEvent(stub, startRequest, actions, closedFlowIds)
}

func (t *APICC) finishPayWalk(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, closedFlowIds []string, organization *profilePB.Organization) error {
	// Finish Flow
	err := t.finaliseFlowRequest(stub, organization, startRequest, nil, closedFlowIds)
	if err != nil {
		return err
	}

	_, err = t.updateGXSetStatus(stub, guaranteePB.GXStatus_GX_PAYWALKED, startRequest, organization, true)
	if err != nil {
		return err
	}

	// Emit event
	return t.storeAndEmitFinishFlowEvent(stub, startRequest, nil, closedFlowIds)
}

func (t *APICC) finishCancel(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, actions []*guaranteePB.GXFlowActionRequest, closedFlowIds []string, organization *profilePB.Organization) error {
	// Finish Flow
	err := t.finaliseFlowRequest(stub, organization, startRequest, actions, closedFlowIds)
	if err != nil {
		return err
	}
	_, err = t.updateGXSetStatus(stub, guaranteePB.GXStatus_GX_CANCELLED, startRequest, organization, true)
	if err != nil {
		return err
	}

	// Emit event
	return t.storeAndEmitFinishFlowEvent(stub, startRequest, actions, closedFlowIds)
}

func (t *APICC) finishTransfer(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, actions []*guaranteePB.GXFlowActionRequest, closedFlowIds []string, newGXID string, organization *profilePB.Organization) error {
	// Set newGXID
	startRequest.GetGxTransferRequest().NewGxId = newGXID
	// Finish Flow
	err := t.finaliseFlowRequest(stub, organization, startRequest, actions, closedFlowIds)
	if err != nil {
		return err
	}

	gxTransferRequest := startRequest.GetGxTransferRequest()
	// Update old gx to TRANSFERRED
	_, err = t.updateGXSetStatus(stub, guaranteePB.GXStatus_GX_TRANSFERRED, startRequest, organization, true)
	if err != nil {
		return err
	}

	gx := gxTransferRequest.GetGx()

	// Clear all activeRequests
	gx.ActiveFlows = 0

	// Clone gx underneath new ID
	gx.PrevGxId = gxTransferRequest.GetGxId()
	gx.Id = newGXID

	// Generate Guarantee key
	gxKey, err := generateGXKey(stub, gx.GetId())
	if err != nil {
		return err
	}

	// Modify fields
	gx.Beneficiaries = gxTransferRequest.GetBeneficiaries()

	// Add Guarantee metadata
	updatedAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}
	gx.UpdatedAt = updatedAt

	// Put Guarantee into state
	err = ccutil.PutStatePB(stub, gxKey, gx)
	if err != nil {
		return err
	}

	// Emit event
	return t.storeAndEmitFinishFlowEvent(stub, startRequest, actions, closedFlowIds)
}

func (t *APICC) finishExpire(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, closedFlowIds []string, organization *profilePB.Organization) error {
	// Finish Flow
	err := t.finaliseFlowRequest(stub, organization, startRequest, nil, closedFlowIds)
	if err != nil {
		return err
	}

	gxExpireRequest := startRequest.GetGxExpireRequest()
	gx, err := get(stub, gxExpireRequest.GetGxId())
	if err != nil {
		return err
	}

	// Check that guarantee is expired
	expired, err := isGXExpired(stub, gx)
	if err != nil {
		return err
	}
	if !expired {
		return errors.New("Guarantee hasn't expired")
	}

	// Clear all activeRequests
	gx.ActiveFlows = 0
	_, err = t.updateGXStatusGivenGx(stub, organization, guaranteePB.GXStatus_GX_EXPIRED, gx)
	if err != nil {
		return err
	}

	// Emit event
	return t.storeAndEmitFinishFlowEvent(stub, startRequest, nil, closedFlowIds)
}

func (t *APICC) updateGXSetStatus(stub *guaranteePB.ChaincodeStub, status guaranteePB.GXStatus, startRequest *guaranteePB.GXStartRequest, organization *profilePB.Organization, closesRequests bool) (*guaranteePB.GX, error) {
	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		return nil, err
	}
	gx, err := get(stub, baseRequest.GetGxId())
	if err != nil {
		return nil, err
	}
	if closesRequests {
		// Clear all activeRequests
		gx.ActiveFlows = 0
	}

	return t.updateGXStatusGivenGx(stub, organization, status, gx)
}

func (t *APICC) updateGXStatusGivenGx(stub *guaranteePB.ChaincodeStub, organization *profilePB.Organization, status guaranteePB.GXStatus, gx *guaranteePB.GX) (*guaranteePB.GX, error) {

	// Generate Guarantee key
	gxKey, err := generateGXKey(stub, gx.GetId())
	if err != nil {
		return nil, err
	}

	// Modify fields
	gx.Status = status

	// Add Guarantee metadata
	updatedAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return nil, err
	}
	gx.UpdatedAt = updatedAt

	// Put Guarantee into state
	err = ccutil.PutStatePB(stub, gxKey, gx)
	if err != nil {
		return nil, err
	}

	return gx, nil
}

func (t *APICC) storeAndEmitFinishFlowEvent(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, actions []*guaranteePB.GXFlowActionRequest, closedFlowIds []string) error {
	createdAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}
	var lastAction *guaranteePB.GXFlowActionRequest
	if actions != nil && len(actions) > 0 {
		lastAction = actions[len(actions)-1]
	}

	event := &guaranteePB.GXEvent{
		Id:        stub.GetTxID(),
		CreatedAt: createdAt,
		Payload: &guaranteePB.GXEvent_FinishFlowEvent{
			FinishFlowEvent: &guaranteePB.FinishFlowEvent{
				StartRequest:  startRequest,
				LastAction:    lastAction,
				ClosedFlowIds: closedFlowIds,
			},
		},
	}

	ccutil.Logger.Debugf("Storing+Emitting FinishFlow Event %v\n", event)
	ccutil.Logger.Infof("Triggering EVENT <Finish Flow> (id: %v)\n", event.Id)

	// Store Event
	err = t.storeGXEvent(stub, event)
	if err != nil {
		return err
	}

	// Emit Event
	err = stub.SetFinishFlowEvent(event)
	return err
}

func (t *APICC) isCloseRequest(request *guaranteePB.GXStartRequest, gx *guaranteePB.GX) (bool, error) {
	requestType, err := getRequestType(request)
	if err != nil {
		return false, err
	}
	return (requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_CANCEL ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_EXPIRE ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_PAY_WALK ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_TRANSFER ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_DEMAND && request.GetGxDemandRequest().GetAmount() == gx.GetAmount().GetOutstanding()), nil
}

func (t *APICC) finaliseFlowRequest(stub *guaranteePB.ChaincodeStub, organization *profilePB.Organization, startRequest *guaranteePB.GXStartRequest, actions []*guaranteePB.GXFlowActionRequest, closedFlowIds []string) error {
	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		return err
	}

	// Set flow to approved
	setStatus(baseRequest, sharedPB.FlowStatus_FLOW_APPROVED)
	// Set flow's updated at field
	ccutil.SetUpdatedMetadata(stub, baseRequest, organization.GetId())

	flowKey, err := ccutil.GenerateFlowKey(stub, baseRequest.GetId())
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, flowKey, startRequest)
	return err
}
