package gx

import (
	"errors"
	"fmt"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// RevokeAction revokes an approve flow action
func (t *APICC) RevokeAction(stub *guaranteePB.ChaincodeStub, flowActionRequest *sharedPB.FlowActionRequest) (*sharedPB.FlowActionRequest, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Processing RevokeAction action %v\n", flowActionRequest)

	// Set ID
	flowActionRequest.Id = ccutil.GenerateFlowActionID(stub)
	ccutil.Logger.Infof("Action REVOKE action (id: %v, flow: %v)\n", flowActionRequest.Id, flowActionRequest.GetFlowId())

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}

	// Get stored start request and confirm it is of right type and status
	flow, err := getFlow(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		return nil, err
	}

	if baseRequest.GetStatus() != sharedPB.FlowStatus_FLOW_ACTIVE {
		return nil, errors.New("Flow is not active")
	}

	if flowActionRequest.GetActionId() == "" {
		return nil, errors.New("Must specify actionId field")
	}

	// Get actions
	actions, err := getGXFlowActions(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}

	actionIDToSeqNumMap, err := generateActionIDToSeqNumMap(actions)
	if err != nil {
		return nil, err
	}

	targetSeqNum, ok := actionIDToSeqNumMap[flowActionRequest.GetActionId()]
	if !ok {
		return nil, errors.New("Invalid actionId field")
	}

	// Check that action is an approval
	if x, ok := actions[targetSeqNum].GetRequest().(*guaranteePB.GXFlowActionRequest_FlowActionRequest); !ok ||
		x.FlowActionRequest.GetRequestType() != sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE {
		return nil, fmt.Errorf("Action at actionId %d is not an approval", targetSeqNum)
	}

	// Check that action belongs to organization
	if actions[targetSeqNum].GetFlowActionRequest().GetCreatedBy() != info.organization.GetId() {
		return nil, fmt.Errorf("Action at actionId %d does not belong to organization", targetSeqNum)
	}

	// Check that action hasn't already been cancelled
	for _, action := range actions {
		if x, ok := action.GetRequest().(*guaranteePB.GXFlowActionRequest_FlowActionRequest); ok &&
			x.FlowActionRequest.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_REVOKE &&
			x.FlowActionRequest.GetActionId() == flowActionRequest.GetActionId() {
			return nil, errors.New("Approval has already been revoke")
		}
	}

	// Set RequestType
	flowActionRequest.RequestType = sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_REVOKE

	// Set metadata
	err = ccutil.SetCreatedMetadata(stub, flowActionRequest, info.organization.GetId())
	if err != nil {
		return nil, err
	}

	// Write approval to state and emit event
	err = t.addAction(stub, flowActionRequest.GetFlowId(), &guaranteePB.GXFlowActionRequest{
		Request: &guaranteePB.GXFlowActionRequest_FlowActionRequest{FlowActionRequest: flowActionRequest},
	})
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return flowActionRequest, nil
}
