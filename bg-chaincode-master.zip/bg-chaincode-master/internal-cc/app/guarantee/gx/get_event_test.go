package gx

import (
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
)

func TestGetEvent(t *testing.T) {
	stub, _ := setup(t)

	// Initiate start request
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	gx := generateExampleBasicGX()
	invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx})

	if stub.Event.Payload == nil {
		t.Fatal("Error expected Event to be set")
	}

	expectedName := "startFlow"

	if stub.Event.Name != expectedName {
		t.Fatalf("Error expected event name to be %s, but got %s", expectedName, stub.Event.Name)
	}

	var eventPayload guaranteePB.GXEvent
	err := ccutil.Unmarshal(stub.Event.Payload, &eventPayload)
	if err != nil {
		t.Fatal(err)
	}
	if eventPayload.GetId() == "" {
		t.Fatal("Error expected event ID to be set")
	}

	storedEvent, err := getEvent(stub, eventPayload.GetId())
	if err != nil {
		t.Fatal(err)
	}

	if storedEvent.GetId() == "" {
		t.Fatal("Error expected event ID to be set")
	}
}
