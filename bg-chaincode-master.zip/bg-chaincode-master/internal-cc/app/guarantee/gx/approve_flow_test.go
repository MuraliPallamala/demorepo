package gx

import (
	"reflect"
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

// TODO add unhappy path tests

func TestApproveFlowIssue(t *testing.T) {
	stub, _ := setup(t)

	cctest.SetMockStubCert(t, stub, appOrgPEM)
	initGX := generateExampleBasicGX()
	issueReq := invokeStartFlowIssueAndGetRequest(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})
	flowID := issueReq.GetId()
	gx := issueReq.GetGx()

	// test ben approval and issuer approval
	doApprovalsStandard(t, stub, flowID, gx)

	// Get GXID
	storedIssueRequest := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID}).GetGxIssueRequest()

	// Test that Guarantee exists in state
	storedGX, err := get(stub, storedIssueRequest.GetGxId())
	if err != nil {
		t.Fatal(err.Error())
	}

	// TODO check all fields match up, currently only checking ID
	if storedGX.GetId() != storedIssueRequest.GetGxId() {
		t.Fatalf("Error incorrect ID of stored gx, expected: %s, got: %s", storedIssueRequest.GetGxId(), storedGX.GetId())
	}
	checkGuaranteeStatus(t, storedGX.GetStatus(), guaranteePB.GXStatus_GX_ACTIVE)
}

func TestApproveFlowAmend(t *testing.T) {
	testApproveFlowStandardTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			return invokeStartFlowAmend(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXAmendRequest{GxId: gx.GetId(), Amount: 20})
		},
		doApprovalsStandard,
		func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX) {
			checkGuaranteeStatus(t, gx.GetStatus(), guaranteePB.GXStatus_GX_ACTIVE)
			amendRequest := startRequest.GetGxAmendRequest()
			if amendRequest.GetAmount() != gx.GetAmount().GetOutstanding() {
				t.Fatalf("Error incorrect Amount of stored gx, expected: %v, got: %v", amendRequest.GetAmount(), gx.GetAmount().GetOutstanding())
			}
		},
	)
}

func TestApproveFlowDemandFull(t *testing.T) {
	var initOutstanding uint64
	testApproveFlowDemandTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			initOutstanding = gx.GetAmount().GetOutstanding()
			return invokeStartFlowDemand(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: gx.GetAmount().GetOutstanding()})
		},
		doApprovalsIssuerOnly,
		func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX) {
			checkGuaranteeStatus(t, gx.GetStatus(), guaranteePB.GXStatus_GX_DEMANDED)
			if gx.GetAmount().GetDemanded() != initOutstanding {
				t.Fatalf("Error expected gx.Amount.Demanded to equal initial outstanding, expected: %d, got: %d", initOutstanding, gx.GetAmount().GetDemanded())
			}
			if gx.GetAmount().GetOutstanding() != 0 {
				t.Fatalf("Error expected gx.Amount.Outstanding to equal 0, expected: %d, got: %d", 0, gx.GetAmount().GetOutstanding())
			}
		},
	)
}

func TestApproveFlowDemandPartial(t *testing.T) {
	var expectedFinalOutstandingAmount uint64 = 1
	var expectedDemandedAmount uint64
	testApproveFlowDemandTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			demandRequest := guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: gx.GetAmount().GetOutstanding() - expectedFinalOutstandingAmount}
			expectedDemandedAmount = gx.GetAmount().GetDemanded() + demandRequest.GetAmount()
			return invokeStartFlowDemand(t, stub, cctest.GenerateMockTxID(""), &demandRequest)
		},
		doApprovalsIssuerOnly,
		func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX) {
			checkGuaranteeStatus(t, gx.GetStatus(), guaranteePB.GXStatus_GX_ACTIVE)
			if gx.GetAmount().GetDemanded() != expectedDemandedAmount {
				t.Fatalf("Error unexpected value for gx.Amount.Demanded expected: %d, got: %d", expectedDemandedAmount, gx.GetAmount().GetDemanded())
			}
			if gx.GetAmount().GetOutstanding() != expectedFinalOutstandingAmount {
				t.Fatalf("Error unexpected value for gx.Amount.Outstanding expected: %d, got: %d", expectedFinalOutstandingAmount, gx.GetAmount().GetOutstanding())
			}
		},
	)
}

func TestApproveFlowCancelApplicantInitiated(t *testing.T) {
	testApproveFlowStandardTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			return invokeStartFlowCancel(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXCancelRequest{GxId: gx.GetId()})
		},
		doApprovalsStandard,
		func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX) {
			checkGuaranteeStatus(t, gx.GetStatus(), guaranteePB.GXStatus_GX_CANCELLED)
		},
	)
}

func TestApproveFlowCancelBeneficiaryInitiated(t *testing.T) {
	testApproveFlowStandardTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			cctest.SetMockStubCert(t, stub, benOrgPEM)
			return invokeStartFlowCancel(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXCancelRequest{GxId: gx.GetId()})
		},
		doApprovalsIssuerOnly,
		func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX) {
			checkGuaranteeStatus(t, gx.GetStatus(), guaranteePB.GXStatus_GX_CANCELLED)
		},
	)
}

func TestApproveFlowTransferApplicantInitiated(t *testing.T) {
	var mockStub *cctest.MockStub
	var initGX *guaranteePB.GX
	testApproveFlowStandardTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			mockStub = stub
			initGX = gx
			return invokeStartFlowTransfer(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXTransferRequest{GxId: gx.GetId(), Beneficiaries: []string{ben2OrgID}})
		},
		doApprovalsTransferApplicantInitiated,
		func(startRequest *guaranteePB.GXStartRequest, prevGX *guaranteePB.GX) {
			testPostTransfer(t, mockStub, startRequest, initGX, prevGX)
		},
	)
}

func TestApproveFlowTransferBeneficiaryInitiated(t *testing.T) {
	var mockStub *cctest.MockStub
	var initGX *guaranteePB.GX
	testApproveFlowStandardTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			mockStub = stub
			initGX = gx
			cctest.SetMockStubCert(t, stub, benOrgPEM)
			return invokeStartFlowTransfer(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXTransferRequest{GxId: gx.GetId(), Beneficiaries: []string{ben2OrgID}})
		},
		doApprovalsTransferBeneficiaryInitiated,
		func(startRequest *guaranteePB.GXStartRequest, prevGX *guaranteePB.GX) {
			testPostTransfer(t, mockStub, startRequest, initGX, prevGX)
		},
	)
}

func testPostTransfer(t *testing.T, stub *cctest.MockStub, startRequest *guaranteePB.GXStartRequest, initGX *guaranteePB.GX, prevGX *guaranteePB.GX) {
	transferRequest := startRequest.GetGxTransferRequest()
	newGX := getNewGXPostTransfer(t, stub, transferRequest)

	// Check old guarantee
	checkGuaranteeStatus(t, prevGX.GetStatus(), guaranteePB.GXStatus_GX_TRANSFERRED)
	if !reflect.DeepEqual(prevGX.GetBeneficiaries(), initGX.GetBeneficiaries()) {
		t.Fatalf("Error expected beneficiaries of old gx to be unchanged. Expected %v, but got: %v", initGX.GetBeneficiaries(), prevGX.GetBeneficiaries())
	}

	// Check new guarantee
	checkGuaranteeStatus(t, newGX.GetStatus(), guaranteePB.GXStatus_GX_ACTIVE)
	if !reflect.DeepEqual(newGX.GetBeneficiaries(), transferRequest.GetBeneficiaries()) {
		t.Fatalf("Error expected beneficiaries of new gx to equal beneficiaries of transfer request. Expected %v, but got: %v", transferRequest.GetBeneficiaries(), newGX.GetBeneficiaries())
	}
}

type invokeStartRequest func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest
type approveCheck func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX)
type doApprovals func(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX)

func testApproveFlowStandardTemplate(t *testing.T, invStartReq invokeStartRequest, doAprvls doApprovals, check approveCheck) {
	t.Helper()
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Initiate start request
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	startRequest := invStartReq(stub, gx)
	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	flowID := baseRequest.GetId()

	// issue approvals
	doAprvls(t, stub, flowID, gx)

	// Get Guarantee from state
	storedGX, err := get(stub, gx.GetId())
	if err != nil {
		t.Fatal(err.Error())
	}

	// Get Stored startRequest
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})

	// Check GX
	check(flow, storedGX)
}

func testApproveFlowDemandTemplate(t *testing.T, invStartReq invokeStartRequest, doAprvls doApprovals, check approveCheck) {
	t.Helper()
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Initiate start request
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	startRequest := invStartReq(stub, gx)
	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	flowID := baseRequest.GetId()

	// issue approvals
	doAprvls(t, stub, flowID, gx)

	// Get Guarantee from state
	storedGX, err := get(stub, gx.GetId())
	if err != nil {
		t.Fatal(err.Error())
	}

	// Get Stored startRequest
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})

	// Check GX
	check(flow, storedGX)
}

func doApprovalsStandard(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX) {
	t.Helper()
	// approve as beneficiary
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	benApproveFlowRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	benApproveFlowID := benApproveFlowRes.GetFlowId()
	if flowID != benApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, benApproveFlowID)
	}
	// check that flow status is still active given there is still an approver
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_ACTIVE)

	// approve as issuer
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	issuerApproveFlowRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	issuerApproveFlowID := issuerApproveFlowRes.GetFlowId()
	if flowID != issuerApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, issuerApproveFlowID)
	}

	// check that flow status is approved, as all approvals have been met
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_APPROVED)
}

func doApprovalsIssuerOnly(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX) {
	t.Helper()

	// approve as issuer
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	issuerApproveFlowRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	issuerApproveFlowID := issuerApproveFlowRes.GetFlowId()
	if flowID != issuerApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, issuerApproveFlowID)
	}

	// check that flow status is approved, as all approvals have been met
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_APPROVED)
}

func doApprovalsTransferApplicantInitiated(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX) {
	t.Helper()
	// approve as old beneficiary
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	benApproveFlowRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	benApproveFlowID := benApproveFlowRes.GetFlowId()
	if flowID != benApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, benApproveFlowID)
	}
	// check that flow status is still active given there is still an approver
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_ACTIVE)

	// approve as new beneficiary
	cctest.SetMockStubCert(t, stub, ben2OrgPEM)
	ben2ApproveFlowRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	ben2ApproveFlowID := ben2ApproveFlowRes.GetFlowId()
	if flowID != ben2ApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, ben2ApproveFlowID)
	}
	// check that flow status is still active given there is still an approver
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_ACTIVE)

	// approve as issuer
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	issuerApproveFlowRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	issuerApproveFlowID := issuerApproveFlowRes.GetFlowId()
	if flowID != issuerApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, issuerApproveFlowID)
	}
	// check that flow status is approved, as all approvals have been met
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_APPROVED)
}

func doApprovalsTransferBeneficiaryInitiated(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX) {
	t.Helper()
	// approve as new beneficiary
	cctest.SetMockStubCert(t, stub, ben2OrgPEM)
	ben2ApproveFlowRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	ben2ApproveFlowID := ben2ApproveFlowRes.GetFlowId()
	if flowID != ben2ApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, ben2ApproveFlowID)
	}
	// check that flow status is still active given there is still an approver
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_ACTIVE)

	// approve as issuer
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	issuerApproveFlowRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	issuerApproveFlowID := issuerApproveFlowRes.GetFlowId()
	if flowID != issuerApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, issuerApproveFlowID)
	}
	// check that flow status is approved, as all approvals have been met
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_APPROVED)
}

func getNewGXPostTransfer(t *testing.T, stub *cctest.MockStub, transferRequest *guaranteePB.GXTransferRequest) *guaranteePB.GX {
	t.Helper()

	actions, err := getGXFlowActions(stub, transferRequest.GetId())
	if err != nil {
		t.Fatal(err.Error())

	}

	newGXID := actions[len(actions)-1].GetFlowActionRequest().GetNewGxId()
	newGX, err := get(stub, newGXID)
	if err != nil {
		t.Fatal(err)
	}
	return newGX
}
