package gx

import (
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

func TestRecallFlowIssue(t *testing.T) {
	stub, _ := setup(t)

	cctest.SetMockStubCert(t, stub, appOrgPEM)
	initGX := generateExampleBasicGX()
	issueReq := invokeStartFlowIssueAndGetRequest(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})
	flowID := issueReq.GetId()
	gx := issueReq.GetGx()
	gx.Amount = &guaranteePB.GXAmount{
		Outstanding: 100,
	}

	updatedGX := generateExampleBasicGX()
	updatedGX.Amount = &guaranteePB.GXAmount{
		Outstanding: 200,
	}

	// Invoke RecallFlow
	payload := invokeRecallFlow(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXRecallRequest{
		FlowId:         flowID,
		UpdatedRequest: generateStartRequestIssue(&guaranteePB.GXIssueRequest{Gx: &updatedGX}),
	})
	if payload.GetFlowId() != flowID {
		t.Fatalf("Expected recall flow ID to equal start flow ID, instead: start Flow ID %s, recall Flow ID %s", flowID, payload.GetFlowId())
	}
	// check that Recall action was added
	checkRecallAdded(t, stub, flowID, func(storedRecall *guaranteePB.GXRecallRequest) {
		storedRecallGX := storedRecall.GetUpdatedRequest().GetGxIssueRequest().GetGx()
		if storedRecallGX.GetAmount().GetOutstanding() != updatedGX.GetAmount().GetOutstanding() {
			t.Fatalf("Error incorrect Amount for stored recall gx, expected: %d, got: %d", updatedGX.GetAmount().GetOutstanding(), storedRecallGX.GetAmount().GetOutstanding())
		}
	})

	// Test beneficiary approval and issuer approval
	doApprovalsStandard(t, stub, flowID, gx)

	// Now updated with GX_ID
	storedIssueRequest := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID}).GetGxIssueRequest()

	// Test that Guarantee exists in state
	storedGX, err := get(stub, storedIssueRequest.GetGxId())
	if err != nil {
		t.Fatal(err.Error())
	}

	// check all fields match up, currently only checking ID and amount
	if storedGX.GetId() != storedIssueRequest.GetGxId() {
		t.Fatalf("Error incorrect ID of stored gx, expected: %s, got: %s", storedIssueRequest.GetGxId(), storedGX.GetId())
	}
	if storedGX.GetAmount().GetOutstanding() != updatedGX.GetAmount().GetOutstanding() {
		t.Fatalf("Error incorrect Amount for stored gx, expected: %d, got: %d", updatedGX.GetAmount().GetOutstanding(), storedGX.GetAmount().GetOutstanding())
	}
	checkGuaranteeStatus(t, storedGX.GetStatus(), guaranteePB.GXStatus_GX_ACTIVE)
}

func TestRecallFlowIssueMulti(t *testing.T) {
	stub, _ := setup(t)

	cctest.SetMockStubCert(t, stub, appOrgPEM)
	initGX := generateExampleBasicGX()
	issueReq := invokeStartFlowIssueAndGetRequest(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})
	flowID := issueReq.GetId()
	gx := issueReq.GetGx()
	gx.Amount = &guaranteePB.GXAmount{
		Outstanding: 100,
	}

	updatedGX := generateExampleBasicGX()
	updatedGX.Amount = &guaranteePB.GXAmount{
		Outstanding: 200,
	}

	// Invoke RecallFlow
	payload := invokeRecallFlow(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXRecallRequest{
		FlowId:         flowID,
		UpdatedRequest: generateStartRequestIssue(&guaranteePB.GXIssueRequest{Gx: &updatedGX}),
	})
	if payload.GetFlowId() != flowID {
		t.Fatalf("Expected recall flow ID to equal start flow ID, instead: start Flow ID %s, recall Flow ID %s", flowID, payload.GetFlowId())
	}
	// check that Recall action was added
	checkRecallAdded(t, stub, flowID, func(storedRecall *guaranteePB.GXRecallRequest) {
		storedRecallGX := storedRecall.GetUpdatedRequest().GetGxIssueRequest().GetGx()
		if storedRecallGX.GetAmount().GetOutstanding() != updatedGX.GetAmount().GetOutstanding() {
			t.Fatalf("Error incorrect Amount for stored recall gx, expected: %d, got: %d", updatedGX.GetAmount().GetOutstanding(), storedRecallGX.GetAmount().GetOutstanding())
		}
	})

	// Test beneficiary approval, recall, beneficiary approval, and issuer approval
	doApprovalsStandardWithRecall(t, stub, flowID, gx, func() *guaranteePB.GXRecallRequest {
		// set cert to applicant
		cctest.SetMockStubCert(t, stub, appOrgPEM)
		return invokeRecallFlow(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXRecallRequest{
			FlowId:         flowID,
			UpdatedRequest: generateStartRequestIssue(&guaranteePB.GXIssueRequest{Gx: &updatedGX}),
		})
	})

	// Now updated with GX_ID
	storedIssueRequest := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID}).GetGxIssueRequest()

	// Test that Guarantee exists in state
	storedGX, err := get(stub, storedIssueRequest.GetGxId())
	if err != nil {
		t.Fatal(err.Error())
	}

	// check all fields match up, currently only checking ID and amount
	if storedGX.GetId() != storedIssueRequest.GetGxId() {
		t.Fatalf("Error incorrect ID of stored gx, expected: %s, got: %s", storedIssueRequest.GetGxId(), storedGX.GetId())
	}
	if storedGX.GetAmount().GetOutstanding() != updatedGX.GetAmount().GetOutstanding() {
		t.Fatalf("Error incorrect Amount for stored gx, expected: %d, got: %d", updatedGX.GetAmount().GetOutstanding(), storedGX.GetAmount().GetOutstanding())
	}
	checkGuaranteeStatus(t, storedGX.GetStatus(), guaranteePB.GXStatus_GX_ACTIVE)
}

func TestRecallFlowAmend(t *testing.T) {
	updatedAmendRequest := &guaranteePB.GXAmendRequest{Amount: 500}
	testApproveFlowStandardTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			return invokeStartFlowAmend(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXAmendRequest{GxId: gx.GetId(), Amount: 20})
		},
		func(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX) {
			payload := invokeRecallFlow(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXRecallRequest{
				FlowId:         flowID,
				UpdatedRequest: generateStartRequestAmend(updatedAmendRequest),
			})
			if payload.GetFlowId() != flowID {
				t.Fatalf("Expected recall flow ID to equal start flow ID, instead: start Flow ID %s, recall Flow ID %s", flowID, payload.GetFlowId())
			}
			// check that Recall action was added
			checkRecallAdded(t, stub, flowID, func(storedRecall *guaranteePB.GXRecallRequest) {
				storedRecallAmend := storedRecall.GetUpdatedRequest().GetGxAmendRequest()
				if storedRecallAmend.GetAmount() != updatedAmendRequest.GetAmount() {
					t.Fatalf("Error incorrect Amount for stored recall amend, expected: %d, got: %d", updatedAmendRequest.GetAmount(), storedRecallAmend.GetAmount())
				}
			})

			doApprovalsStandard(t, stub, flowID, gx)
		},
		func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX) {
			if gx.GetAmount().GetOutstanding() != updatedAmendRequest.GetAmount() {
				t.Fatalf("Error incorrect Amount of stored gx, expected: %v, got: %v", updatedAmendRequest.GetAmount(), gx.GetAmount())
			}
		},
	)
}

func TestRecallFlowDemandFull(t *testing.T) {
	updatedDemandRequest := &guaranteePB.GXDemandRequest{Reason: "Some Reason"}
	testApproveFlowDemandTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			updatedDemandRequest.Amount = gx.GetAmount().GetOutstanding() - gx.GetAmount().GetDemanded()
			return invokeStartFlowDemand(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: 1000})
		},
		func(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX) {
			payload := invokeRecallFlow(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXRecallRequest{
				FlowId:         flowID,
				UpdatedRequest: generateStartRequestDemand(updatedDemandRequest),
			})
			if payload.GetFlowId() != flowID {
				t.Fatalf("Expected recall flow ID to equal start flow ID, instead: start Flow ID %s, recall Flow ID %s", flowID, payload.GetFlowId())
			}
			// check that Recall action was added
			checkRecallAdded(t, stub, flowID, func(storedRecall *guaranteePB.GXRecallRequest) {
				storedRecallDemand := storedRecall.GetUpdatedRequest().GetGxDemandRequest()
				if storedRecallDemand.GetReason() != updatedDemandRequest.GetReason() {
					t.Fatalf("Error incorrect Reason for stored recall demand, expected: %s, got: %s", updatedDemandRequest.GetReason(), storedRecallDemand.GetReason())
				}

				if storedRecallDemand.GetAmount() != updatedDemandRequest.GetAmount() {
					t.Fatalf("Error incorrect Amount for stored recall demand, expected: %d, got: %d", updatedDemandRequest.GetAmount(), storedRecallDemand.GetAmount())
				}
			})

			doApprovalsIssuerOnly(t, stub, flowID, gx)
		},
		func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX) {
			checkGuaranteeStatus(t, gx.GetStatus(), guaranteePB.GXStatus_GX_DEMANDED)
		},
	)
}

func TestRecallFlowDemandPartial(t *testing.T) {
	updatedDemandRequest := &guaranteePB.GXDemandRequest{Reason: "Some Reason", Amount: 3000}
	testApproveFlowDemandTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			return invokeStartFlowDemand(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: 1000})
		},
		func(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX) {
			payload := invokeRecallFlow(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXRecallRequest{
				FlowId:         flowID,
				UpdatedRequest: generateStartRequestDemand(updatedDemandRequest),
			})
			if payload.GetFlowId() != flowID {
				t.Fatalf("Expected recall flow ID to equal start flow ID, instead: start Flow ID %s, recall Flow ID %s", flowID, payload.GetFlowId())
			}
			// check that Recall action was added
			checkRecallAdded(t, stub, flowID, func(storedRecall *guaranteePB.GXRecallRequest) {
				storedRecallDemand := storedRecall.GetUpdatedRequest().GetGxDemandRequest()
				if storedRecallDemand.GetReason() != updatedDemandRequest.GetReason() {
					t.Fatalf("Error incorrect Reason for stored recall demand, expected: %s, got: %s", updatedDemandRequest.GetReason(), storedRecallDemand.GetReason())
				}

				if storedRecallDemand.GetAmount() != updatedDemandRequest.GetAmount() {
					t.Fatalf("Error incorrect Amount for stored recall demand, expected: %d, got: %d", updatedDemandRequest.GetAmount(), storedRecallDemand.GetAmount())
				}
			})

			doApprovalsIssuerOnly(t, stub, flowID, gx)
		},
		func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX) {
			checkGuaranteeStatus(t, gx.GetStatus(), guaranteePB.GXStatus_GX_ACTIVE)
		},
	)
}

func TestRecallFlowCancelApplicantInitiated(t *testing.T) {
	updatedCancelRequest := &guaranteePB.GXCancelRequest{Reason: "Some Reason"}
	testApproveFlowStandardTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			return invokeStartFlowCancel(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXCancelRequest{GxId: gx.GetId()})
		},
		func(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX) {
			payload := invokeRecallFlow(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXRecallRequest{
				FlowId:         flowID,
				UpdatedRequest: generateStartRequestCancel(updatedCancelRequest),
			})
			if payload.GetFlowId() != flowID {
				t.Fatalf("Expected recall flow ID to equal start flow ID, instead: start Flow ID %s, recall Flow ID %s", flowID, payload.GetFlowId())
			}
			// check that Recall action was added
			checkRecallAdded(t, stub, flowID, func(storedRecall *guaranteePB.GXRecallRequest) {
				storedRecallCancel := storedRecall.GetUpdatedRequest().GetGxCancelRequest()
				if storedRecallCancel.GetReason() != updatedCancelRequest.GetReason() {
					t.Fatalf("Error incorrect Reason for stored recall cancel, expected: %s, got: %s", updatedCancelRequest.GetReason(), storedRecallCancel.GetReason())
				}
			})

			doApprovalsStandard(t, stub, flowID, gx)
		},
		func(startRequest *guaranteePB.GXStartRequest, gx *guaranteePB.GX) {
			if gx.GetStatus() != guaranteePB.GXStatus_GX_CANCELLED {
				t.Fatalf("Error expected status %s, but got: %s", guaranteePB.GXStatus_name[int32(guaranteePB.GXStatus_GX_CANCELLED)], guaranteePB.GXStatus_name[int32(gx.GetStatus())])
			}
		},
	)
}

func TestRecallFlowTransferApplicantInitiated(t *testing.T) {
	var mockStub *cctest.MockStub
	var initGX *guaranteePB.GX
	var updatedRecallRequest *guaranteePB.GXTransferRequest

	testApproveFlowStandardTemplate(
		t,
		func(stub *cctest.MockStub, gx *guaranteePB.GX) *guaranteePB.GXStartRequest {
			mockStub = stub
			initGX = gx
			updatedRecallRequest = &guaranteePB.GXTransferRequest{GxId: gx.GetId(), Beneficiaries: []string{ben2OrgID}, Reason: "some reason"}
			return invokeStartFlowTransfer(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXTransferRequest{GxId: gx.GetId(), Beneficiaries: []string{ben2OrgID}})
		},
		func(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX) {
			payload := invokeRecallFlow(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXRecallRequest{
				FlowId:         flowID,
				UpdatedRequest: generateStartRequestTransfer(updatedRecallRequest),
			})
			if payload.GetFlowId() != flowID {
				t.Fatalf("Expected recall flow ID to equal start flow ID, instead: start Flow ID %s, recall Flow ID %s", flowID, payload.GetFlowId())
			}
			// check that Recall action was added
			checkRecallAdded(t, stub, flowID, func(storedRecall *guaranteePB.GXRecallRequest) {
				storedRecallTransfer := storedRecall.GetUpdatedRequest().GetGxTransferRequest()
				if storedRecallTransfer.GetReason() != updatedRecallRequest.GetReason() {
					t.Fatalf("Error incorrect Reason for stored recall transfer, expected: %s, got: %s", updatedRecallRequest.GetReason(), storedRecallTransfer.GetReason())
				}
			})

			doApprovalsTransferApplicantInitiated(t, stub, flowID, gx)
		},
		func(startRequest *guaranteePB.GXStartRequest, prevGX *guaranteePB.GX) {
			testPostTransfer(t, mockStub, startRequest, initGX, prevGX)
		},
	)
}

type validateRecall func(storedRecall *guaranteePB.GXRecallRequest)
type invokeRecallRequest func() *guaranteePB.GXRecallRequest

func checkRecallAdded(t *testing.T, stub *cctest.MockStub, flowID string, validate validateRecall) {
	t.Helper()
	actions, err := getGXFlowActions(stub, flowID)
	if err != nil {
		t.Fatal(err.Error())

	}
	if len(actions) == 0 {
		t.Fatal("Can't call validateRecallAdded with no actions")
	}
	action := actions[len(actions)-1]

	x, ok := action.GetRequest().(*guaranteePB.GXFlowActionRequest_RecallRequest)
	if !ok {
		t.Fatal("Invalid action retrieved")
	}
	validate(x.RecallRequest)
}

func doApprovalsStandardWithRecall(t *testing.T, stub *cctest.MockStub, flowID string, gx *guaranteePB.GX, invRecallRequest invokeRecallRequest) {
	t.Helper()
	// approve as beneficiary
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	benApproveRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	benApproveFlowID := benApproveRes.GetFlowId()
	if flowID != benApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, benApproveFlowID)
	}
	// check that flow status is still active given there is still an approver
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_ACTIVE)

	recallRes := invRecallRequest()
	if flowID != recallRes.GetFlowId() {
		t.Fatalf("Expected recall flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, benApproveFlowID)
	}

	// approve as beneficiary
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	benApproveRes = invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	benApproveFlowID = benApproveRes.GetFlowId()
	if flowID != benApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, benApproveFlowID)
	}

	// check that flow status is still active given there is still an approver
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_ACTIVE)

	// approve as issuer
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	issuerApproveRes := invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})
	issuerApproveFlowID := issuerApproveRes.GetFlowId()
	if flowID != issuerApproveFlowID {
		t.Fatalf("Expected approve flow ID to equal start flow ID, instead: start Flow ID %s, approve Flow ID %s", flowID, issuerApproveFlowID)
	}

	// check that flow status is successful, as all approvals have been met
	validateFlowStatus(t, stub, flowID, sharedPB.FlowStatus_FLOW_APPROVED)
}
