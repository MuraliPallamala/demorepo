package gx

import (
	"testing"

	"github.com/gogo/protobuf/types"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/organization"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/purposeformat"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/app/profile/tc"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteetest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

var newcoOrgID = "newco-org"
var newcoOrgPEM = cctest.ConsortiumPEM
var appOrgID = "app-org"
var appOrgPEM = cctest.AppBenPEM1
var benOrgID = "ben-org"
var benOrgPEM = cctest.AppBenPEM2
var ben2OrgID = "ben2-org"
var ben2OrgPEM = cctest.AppBenPEM3
var issuerOrgID = "issuer-org"
var issuerOrgPEM = cctest.ANZPEM

var ccMethods = ccutil.CCMethods.Guarantee.GX

var exampleGXTCID = "gxTC"

func setup(t *testing.T) (*cctest.MockStub, *cctest.MockStub) {
	t.Helper()
	profileStub := setupProfileChaincodeMockStub(t)
	setupOrganizations(t, profileStub)
	setupTC(t, profileStub)
	setupPurposeFormat(t, profileStub)
	stub := setupChaincodeMockStub(t, profileStub)
	return stub, profileStub
}

func setupProfileChaincodeMockStub(t *testing.T) *cctest.MockStub {
	t.Helper()
	return profiletest.SetupChaincodeMockStub(t, new(organization.APICC), new(purposeformat.APICC), new(tc.APICC))
}

func setupChaincodeMockStub(t *testing.T, profileStub *cctest.MockStub) *cctest.MockStub {
	t.Helper()
	return guaranteetest.SetupChaincodeMockStub(t, profileStub, new(APICC))
}

func setupPurposeFormat(t *testing.T, profileStub *cctest.MockStub) {
	t.Helper()

	profiletest.InvokePurposeFormatCreate(t, profileStub, cctest.GenerateMockTxID(""), &sharedPB.PurposeFormat{
		Id: "guaranteePB.GXType_GX_COMMERCIAL_LEASE",
		PurposeField: []*sharedPB.PurposeField{
			&sharedPB.PurposeField{
				Name:     "propertyAddress",
				Optional: false,
				Type:     sharedPB.PurposeFieldType_PFT_OBJECT,
				SubFields: []*sharedPB.PurposeField{
					&sharedPB.PurposeField{
						Name:     "addressCountry",
						Type:     sharedPB.PurposeFieldType_PFT_STRING,
						Optional: false,
					},
					// TODO: we should have the other fields here, but the base GX doesn't have that data
				},
			},
			&sharedPB.PurposeField{
				Name:     "propertyDetails",
				Optional: false,
				Type:     sharedPB.PurposeFieldType_PFT_OBJECT,
				SubFields: []*sharedPB.PurposeField{
					&sharedPB.PurposeField{
						Name:     "propertyName",
						Type:     sharedPB.PurposeFieldType_PFT_STRING,
						Optional: false,
					},
					&sharedPB.PurposeField{
						Name:     "shopNumber",
						Type:     sharedPB.PurposeFieldType_PFT_STRING,
						Optional: false,
					},
				},
			},
			&sharedPB.PurposeField{
				Name:     "purpose",
				Optional: false,
				Type:     sharedPB.PurposeFieldType_PFT_OBJECT,
				SubFields: []*sharedPB.PurposeField{
					&sharedPB.PurposeField{
						Name:     "comment",
						Type:     sharedPB.PurposeFieldType_PFT_STRING,
						Optional: true,
					},
				},
			},
		},
		Name:    "commercial-lease",
		Active:  true,
		Version: "1.0.0",
		Label:   "Commercial Lease",
	})
}

func setupTC(t *testing.T, profileStub *cctest.MockStub) {
	t.Helper()

	profiletest.InvokeTCCreate(t, profileStub, cctest.GenerateMockTxID(""), &profilePB.TermsConditions{
		Id:    exampleGXTCID,
		Scope: profilePB.TermsConditionsScope_BANK_GUARANTEE,
	})
}

func setupOrganizations(t *testing.T, profileStub *cctest.MockStub) {
	t.Helper()
	// Create Newco admin
	profiletest.InvokeOrganizationStartFlowCreate(t, profileStub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id:         newcoOrgID,
			EntityType: profilePB.OrganizationEntityType_ORGANIZATION_CONSORTIUM,
		},
		SelfOnboarding: true,
	})

	// Create Issuer
	profiletest.InvokeOrganizationStartFlowCreate(t, profileStub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id:         issuerOrgID,
			EntityType: profilePB.OrganizationEntityType_ORGANIZATION_ISSUER,
		},
		AdminCertificate: cctest.ANZPEM,
	})

	// Create Applicant
	profiletest.InvokeOrganizationStartFlowCreate(t, profileStub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id:         appOrgID,
			EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		},
		AdminCertificate: cctest.AppBenPEM1,
	})

	// Create Beneficiary
	profiletest.InvokeOrganizationStartFlowCreate(t, profileStub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id:         benOrgID,
			EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		},
		AdminCertificate: cctest.AppBenPEM2,
	})

	// Create Beneficiary 2
	profiletest.InvokeOrganizationStartFlowCreate(t, profileStub, cctest.GenerateMockTxID(""), &profilePB.OrganizationCreateRequest{
		Organization: &profilePB.Organization{
			Id:         ben2OrgID,
			EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		},
		AdminCertificate: cctest.AppBenPEM3,
	})
}

func generateExampleBasicGX() guaranteePB.GX {
	purpose := make(map[string]*guaranteePB.GxPurposeElement)
	propertyDetails := make(map[string]*guaranteePB.GxPurposeElement)
	propertyAddress := make(map[string]*guaranteePB.GxPurposeElement)
	purposeComment := make(map[string]*guaranteePB.GxPurposeElement)
	// prop address
	propertyAddress["addressCountry"] = &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_STRING,
		StringValue: &types.StringValue{Value: "Australia"},
	}
	// prop details
	propertyDetails["shopNumber"] = &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_STRING,
		StringValue: &types.StringValue{Value: "123"},
	}
	propertyDetails["propertyName"] = &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_STRING,
		StringValue: &types.StringValue{Value: "Baker Shop"},
	}
	// comment
	purposeComment["comment"] = &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_STRING,
		StringValue: &types.StringValue{Value: "abc123"},
	}
	// final composition of purpose map
	purpose["propertyDetails"] = &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_MAP,
		MapValue:    propertyDetails,
	}
	purpose["purpose"] = &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_MAP,
		MapValue:    purposeComment,
	}
	purpose["propertyAddress"] = &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_MAP,
		MapValue:    propertyAddress,
	}

	return guaranteePB.GX{
		PurposeType:   "guaranteePB.GXType_GX_COMMERCIAL_LEASE",
		Applicants:    []string{appOrgID},
		Beneficiaries: []string{benOrgID},
		Purpose:       purpose,
		Amount: &guaranteePB.GXAmount{
			Currency:    sharedPB.Currency_AUD,
			Outstanding: 1000000,
		},
		BankReference: "123",
		TcId:          exampleGXTCID,
		// ExpiresAt:     ptypes.TimestampNow(),
	}
}

func generateStartRequestIssue(issueRequest *guaranteePB.GXIssueRequest) *guaranteePB.GXStartRequest {
	return &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxIssueRequest{GxIssueRequest: issueRequest}}
}

func generateStartRequestAmend(amendRequest *guaranteePB.GXAmendRequest) *guaranteePB.GXStartRequest {
	return &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxAmendRequest{GxAmendRequest: amendRequest}}
}

func generateStartRequestCancel(cancelRequest *guaranteePB.GXCancelRequest) *guaranteePB.GXStartRequest {
	return &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxCancelRequest{GxCancelRequest: cancelRequest}}
}

func generateStartRequestDemand(demandRequest *guaranteePB.GXDemandRequest) *guaranteePB.GXStartRequest {
	return &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxDemandRequest{GxDemandRequest: demandRequest}}
}

func generateStartRequestPayWalk(paywalkRequest *guaranteePB.GXPayWalkRequest) *guaranteePB.GXStartRequest {
	return &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxPayWalkRequest{GxPayWalkRequest: paywalkRequest}}
}

func generateStartRequestTransfer(transferRequest *guaranteePB.GXTransferRequest) *guaranteePB.GXStartRequest {
	return &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxTransferRequest{GxTransferRequest: transferRequest}}
}

func generateStartRequestExpire(expireRequest *guaranteePB.GXExpireRequest) *guaranteePB.GXStartRequest {
	return &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxExpireRequest{GxExpireRequest: expireRequest}}
}

func invokeStartFlowBase(t *testing.T, stub *cctest.MockStub, txID string, startRequest *guaranteePB.GXStartRequest) *guaranteePB.GXStartRequest {
	t.Helper()
	// marshal the payload
	startRequestBytes, err := ccutil.Marshal(startRequest)

	if err != nil {
		t.Fatalf("Count not marshal StartRequest: %s", err.Error())
	}

	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start flow: %s", string(res.Message))
	}

	var payload guaranteePB.GXStartRequest
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeStartFlowBaseExpectFailure(t *testing.T, stub *cctest.MockStub, txID string, startRequest *guaranteePB.GXStartRequest, status int32) {
	t.Helper()
	// marshal the payload
	startRequestBytes, err := ccutil.Marshal(startRequest)

	if err != nil {
		t.Fatalf("Count not marshal StartRequest: %s", err.Error())
	}

	args := [][]byte{[]byte(ccMethods.StartFlow), startRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != status {
		t.Fatalf("Expecting status %d, but got %d. Message %s", status, res.Status, string(res.Message))
	}
}

func invokeStartFlowIssue(t *testing.T, stub *cctest.MockStub, txID string, issueRequest *guaranteePB.GXIssueRequest) *guaranteePB.GXStartRequest {
	t.Helper()
	return invokeStartFlowBase(t, stub, txID, generateStartRequestIssue(issueRequest))
}

func invokeStartFlowAmend(t *testing.T, stub *cctest.MockStub, txID string, amendRequest *guaranteePB.GXAmendRequest) *guaranteePB.GXStartRequest {
	t.Helper()
	return invokeStartFlowBase(t, stub, txID, generateStartRequestAmend(amendRequest))
}

func invokeStartFlowCancel(t *testing.T, stub *cctest.MockStub, txID string, cancelRequest *guaranteePB.GXCancelRequest) *guaranteePB.GXStartRequest {
	t.Helper()
	return invokeStartFlowBase(t, stub, txID, generateStartRequestCancel(cancelRequest))
}

func invokeStartFlowDemand(t *testing.T, stub *cctest.MockStub, txID string, demandRequest *guaranteePB.GXDemandRequest) *guaranteePB.GXStartRequest {
	t.Helper()
	return invokeStartFlowBase(t, stub, txID, generateStartRequestDemand(demandRequest))
}

func invokeStartFlowPayWalk(t *testing.T, stub *cctest.MockStub, txID string, payWalkRequest *guaranteePB.GXPayWalkRequest) *guaranteePB.GXStartRequest {
	t.Helper()
	return invokeStartFlowBase(t, stub, txID, generateStartRequestPayWalk(payWalkRequest))
}

func invokeStartFlowTransfer(t *testing.T, stub *cctest.MockStub, txID string, transferRequest *guaranteePB.GXTransferRequest) *guaranteePB.GXStartRequest {
	t.Helper()
	return invokeStartFlowBase(t, stub, txID, generateStartRequestTransfer(transferRequest))
}

func invokeStartFlowExpire(t *testing.T, stub *cctest.MockStub, txID string, expireRequest *guaranteePB.GXExpireRequest) *guaranteePB.GXStartRequest {
	t.Helper()
	return invokeStartFlowBase(t, stub, txID, generateStartRequestExpire(expireRequest))
}

func invokeStartFlowIssueExpectFailure(t *testing.T, stub *cctest.MockStub, txID string, issueRequest *guaranteePB.GXIssueRequest, status int32) {
	t.Helper()
	invokeStartFlowBaseExpectFailure(t, stub, txID, generateStartRequestIssue(issueRequest), status)
}

func invokeStartFlowAmendExpectFailure(t *testing.T, stub *cctest.MockStub, txID string, amendRequest *guaranteePB.GXAmendRequest, status int32) {
	t.Helper()
	invokeStartFlowBaseExpectFailure(t, stub, txID, generateStartRequestAmend(amendRequest), status)
}

func invokeStartFlowCancelExpectFailure(t *testing.T, stub *cctest.MockStub, txID string, cancelRequest *guaranteePB.GXCancelRequest, status int32) {
	t.Helper()
	invokeStartFlowBaseExpectFailure(t, stub, txID, generateStartRequestCancel(cancelRequest), status)
}

func invokeStartFlowDemandExpectFailure(t *testing.T, stub *cctest.MockStub, txID string, demandRequest *guaranteePB.GXDemandRequest, status int32) {
	t.Helper()
	invokeStartFlowBaseExpectFailure(t, stub, txID, generateStartRequestDemand(demandRequest), status)
}

func invokeStartFlowPayWalkExpectFailure(t *testing.T, stub *cctest.MockStub, txID string, payWalkRequest *guaranteePB.GXPayWalkRequest, status int32) {
	t.Helper()
	invokeStartFlowBaseExpectFailure(t, stub, txID, generateStartRequestPayWalk(payWalkRequest), status)
}

func invokeStartFlowTransferExpectFailure(t *testing.T, stub *cctest.MockStub, txID string, transferRequest *guaranteePB.GXTransferRequest, status int32) {
	t.Helper()
	invokeStartFlowBaseExpectFailure(t, stub, txID, generateStartRequestTransfer(transferRequest), status)
}

func invokeStartFlowExpireExpectFailure(t *testing.T, stub *cctest.MockStub, txID string, expireRequest *guaranteePB.GXExpireRequest, status int32) {
	t.Helper()
	invokeStartFlowBaseExpectFailure(t, stub, txID, generateStartRequestExpire(expireRequest), status)
}

func invokeRecallFlow(t *testing.T, stub *cctest.MockStub, txID string, recallRequest *guaranteePB.GXRecallRequest) *guaranteePB.GXRecallRequest {
	t.Helper()
	recallRequestBytes, err := ccutil.Marshal(recallRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.RecallFlow), recallRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke RecallFlow: %s", string(res.Message))
	}

	var payload guaranteePB.GXRecallRequest
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeApproveFlow(t *testing.T, stub *cctest.MockStub, txID string, approveRequest *sharedPB.FlowActionRequest) *sharedPB.FlowActionRequest {
	t.Helper()
	approveRequestBytes, err := ccutil.Marshal(approveRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.ApproveFlow), approveRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke ApproveFlow: %s", string(res.Message))
	}

	var payload sharedPB.FlowActionRequest
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeRevokeApproveFlow(t *testing.T, stub *cctest.MockStub, txID string, revokeAction *sharedPB.FlowActionRequest) *sharedPB.FlowActionRequest {
	t.Helper()
	revokeActionBytes, err := ccutil.Marshal(revokeAction)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.RevokeAction), revokeActionBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke RevokeApproveFlow: %s", string(res.Message))
	}

	var payload sharedPB.FlowActionRequest
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeSearchEvents(t *testing.T, stub *cctest.MockStub, txID string, searchRequest *sharedPB.EventSearchRequest) *guaranteePB.GXEventSearchResponse {
	t.Helper()
	searchRequestBytes, err := ccutil.Marshal(searchRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.SearchEvents), searchRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke GetFlows: %s", string(res.Message))
	}

	var payload guaranteePB.GXEventSearchResponse
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeSearchFlows(t *testing.T, stub *cctest.MockStub, txID string, searchRequest *guaranteePB.GXFlowSearchRequest) *guaranteePB.GXFlowSearchResponse {
	t.Helper()
	searchRequestBytes, err := ccutil.Marshal(searchRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.SearchFlows), searchRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke GetFlows: %s", string(res.Message))
	}

	var payload guaranteePB.GXFlowSearchResponse
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeGetFlow(t *testing.T, stub *cctest.MockStub, txID string, request *sharedPB.FlowIDValue) *guaranteePB.GXStartRequest {
	t.Helper()
	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.GetFlow), requestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke GetFlow: %s", string(res.Message))
	}

	var payload guaranteePB.GXStartRequest
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeGetFlowActions(t *testing.T, stub *cctest.MockStub, txID string, request *sharedPB.FlowIDValue) *guaranteePB.GXFlowActionsResponse {
	t.Helper()
	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.GetFlowActions), requestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke GetFlowActions: %s", string(res.Message))
	}

	var payload guaranteePB.GXFlowActionsResponse
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeGet(t *testing.T, stub *cctest.MockStub, txID string, request *sharedPB.IDValue) *guaranteePB.GX {
	t.Helper()
	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.Get), requestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke Get: %s", string(res.Message))
	}

	var payload guaranteePB.GX
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeGetExpectFailure(t *testing.T, stub *cctest.MockStub, txID string, request *sharedPB.IDValue) {
	t.Helper()
	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.Get), requestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status == shim.OK {
		t.Fatalf("Expected invoke to fail, but it succeeded: %s", string(res.Message))
	}
}

func invokeSearch(t *testing.T, stub *cctest.MockStub, txID string, gxSearchRequest *guaranteePB.GXSearchRequest) *guaranteePB.GXSearchResponse {
	t.Helper()
	gxSearchRequestBytes, err := ccutil.Marshal(gxSearchRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.Search), gxSearchRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke Get: %s", string(res.Message))
	}

	var payload guaranteePB.GXSearchResponse
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeCancelFlow(t *testing.T, stub *cctest.MockStub, txID string, cancelRequest *sharedPB.FlowActionRequest) *sharedPB.FlowActionRequest {
	t.Helper()
	cancelRequestBytes, err := ccutil.Marshal(cancelRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.CancelFlow), cancelRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke CancelFlow: %s", string(res.Message))
	}

	var payload sharedPB.FlowActionRequest
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeRejectFlow(t *testing.T, stub *cctest.MockStub, txID string, rejectRequest *sharedPB.FlowActionRequest) *sharedPB.FlowActionRequest {
	t.Helper()
	rejectRequestBytes, err := ccutil.Marshal(rejectRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.RejectFlow), rejectRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke RejectFlow: %s", string(res.Message))
	}

	var payload sharedPB.FlowActionRequest
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

func invokeStartFlowIssueAndGetRequest(t *testing.T, stub *cctest.MockStub, txID string, issueRequest *guaranteePB.GXIssueRequest) *guaranteePB.GXIssueRequest {
	t.Helper()
	flowRes := invokeStartFlowIssue(t, stub, txID, issueRequest)
	flowID := flowRes.GetGxIssueRequest().GetId()
	// Get filled out GX with ID
	var startRequest guaranteePB.GXStartRequest
	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		t.Fatal(err.Error())
	}
	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		t.Fatal(err.Error())
	}

	return startRequest.GetGxIssueRequest()
}

// setupGuarantee invokes an issue StartRequest and all the required approvals. It then returns the guarantee
func setupGuarantee(t *testing.T, stub *cctest.MockStub, txID string, issueRequest *guaranteePB.GXIssueRequest) *guaranteePB.GX {
	t.Helper()
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	storedIssueRequest := invokeStartFlowIssueAndGetRequest(t, stub, txID, issueRequest)
	flowID := storedIssueRequest.GetId()

	// approve as beneficiary
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})

	// approve as issuer
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})

	// Now updated with GX_ID
	storedIssueRequest = invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID}).GetGxIssueRequest()

	// Test that Guarantee exists in state
	storedGx, err := get(stub, storedIssueRequest.GetGxId())
	if err != nil {
		t.Fatal(err.Error())
	}

	return storedGx
}

func checkFlowStatus(t *testing.T, actualFlowStatus sharedPB.FlowStatus, expectedFlowStatus sharedPB.FlowStatus) {
	t.Helper()
	if actualFlowStatus != expectedFlowStatus {
		t.Fatalf("Expected flow status %s, but got %s", sharedPB.FlowStatus_name[int32(expectedFlowStatus)], sharedPB.FlowStatus_name[int32(actualFlowStatus)])
	}
}

func checkFlowActionType(t *testing.T, actualFlowActionType sharedPB.FlowActionRequestType, expectedFlowActionType sharedPB.FlowActionRequestType) {
	t.Helper()
	if actualFlowActionType != expectedFlowActionType {
		t.Fatalf("Expected flow action type %s, but got %s", sharedPB.FlowActionRequestType_name[int32(expectedFlowActionType)], sharedPB.FlowActionRequestType_name[int32(actualFlowActionType)])
	}
}

func checkGuaranteeStatus(t *testing.T, actualGuaranteeStatus guaranteePB.GXStatus, expectedGuaranteeStatus guaranteePB.GXStatus) {
	t.Helper()
	if actualGuaranteeStatus != expectedGuaranteeStatus {
		t.Fatalf("Expected guarantee status %s, but got: %s", guaranteePB.GXStatus_name[int32(expectedGuaranteeStatus)], guaranteePB.GXStatus_name[int32(actualGuaranteeStatus)])
	}
}

// ValidateFlowStatus checks whether the status is valid otherwise it fails the test
func validateFlowStatus(t *testing.T, stub *cctest.MockStub, flowID string, status sharedPB.FlowStatus) {
	t.Helper()
	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		t.Fatal(err.Error())
	}

	var startRequest guaranteePB.GXStartRequest
	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		t.Fatal(err.Error())
	}

	baseRequest, err := getRequestFromStartRequest(&startRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	isCorrectStatus := baseRequest.GetStatus() == status
	if !isCorrectStatus {
		t.Fatal("Incorrect Flow Status")
	}
}
