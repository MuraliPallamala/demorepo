package gx

import (
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

func TestGetFlowActions(t *testing.T) {
	stub, _ := setup(t)

	cctest.SetMockStubCert(t, stub, appOrgPEM)
	initGX := generateExampleBasicGX()
	storedIssueRequest := invokeStartFlowIssueAndGetRequest(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})
	flowID := storedIssueRequest.GetId()

	// approve as beneficiary
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})

	// approve as issuer
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})

	// check stored actions
	flowActions := invokeGetFlowActions(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})
	expectedNumActions := 3 // 1 is from submit + 2 actions
	if len(flowActions.GetRequests()) != expectedNumActions {
		t.Fatalf("Expected %v actions, but got %v", expectedNumActions, len(flowActions.GetRequests()))
	}

	checkFlowActionType(t, flowActions.GetRequests()[0].GetFlowActionRequest().GetRequestType(), sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_SUBMIT)
	checkFlowActionType(t, flowActions.GetRequests()[1].GetFlowActionRequest().GetRequestType(), sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE)
	checkFlowActionType(t, flowActions.GetRequests()[2].GetFlowActionRequest().GetRequestType(), sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE)
}
