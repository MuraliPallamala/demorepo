package gx

import (
	"reflect"
	"sort"
	"testing"

	"github.com/gogo/protobuf/types"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
)

func TestSearchFlowsWithIssuer(t *testing.T) {
	stub, _ := setup(t)

	// Initiate start request
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	gx := generateExampleBasicGX()
	expectedFlows := []*guaranteePB.GXStartRequest{
		invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}),
		invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}),
		invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}),
	}

	// perform search
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	actualFlows := invokeSearchFlows(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXFlowSearchRequest{}).GetFlows()
	sortFlowsByCreatedAt(actualFlows)

	for i, expectedFlow := range expectedFlows {
		if !reflect.DeepEqual(expectedFlow, actualFlows[i]) {
			t.Fatalf("Error expected %v, to equal %v", actualFlows[i], expectedFlow)
		}
	}
}

func TestSearchFlowsWithApplicantBeneficiary(t *testing.T) {
	stub, _ := setup(t)

	// Initiate start request
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	gx := generateExampleBasicGX()
	expectedFlows := []*guaranteePB.GXStartRequest{
		invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}),
		invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}),
		invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}),
	}

	// perform search
	actualFlows := invokeSearchFlows(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXFlowSearchRequest{}).GetFlows()
	sortFlowsByCreatedAt(actualFlows)

	for i, expectedFlow := range expectedFlows {
		if !reflect.DeepEqual(expectedFlow, actualFlows[i]) {
			t.Fatalf("Error expected %v, to equal %v", actualFlows[i], expectedFlow)
		}
	}
}

func sortFlowsByCreatedAt(flows []*guaranteePB.GXStartRequest) {
	sort.Slice(flows, func(i, j int) bool {
		base1, _ := getRequestFromStartRequest(flows[i])
		base2, _ := getRequestFromStartRequest(flows[j])

		createdAt1, err := types.TimestampFromProto(base1.GetCreatedAt())
		if err != nil {
			return false
		}
		createdAt2, err := types.TimestampFromProto(base2.GetCreatedAt())
		if err != nil {
			return false
		}
		return createdAt1.Before(createdAt2)
	})
}
