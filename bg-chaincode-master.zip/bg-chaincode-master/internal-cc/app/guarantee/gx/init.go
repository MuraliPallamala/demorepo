package gx

import (
	"errors"
	"fmt"

	"github.com/gogo/protobuf/types"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// Init is the Init function for the guarantee chaincode
func (t *APICC) Init(stub *guaranteePB.ChaincodeStub, initRequest *guaranteePB.GXInitRequest) error {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Initialising with parameters %v\n", initRequest)
	err := t.applyConfiguration(stub, initRequest)
	if err != nil {
		return err
	}
	if initRequest.Migrate {
		migrationPurposeType := initRequest.GetMigrationPurposeType()
		if migrationPurposeType == "" {
			migrationPurposeType = "787659ec-f312-41f3-8741-d32a7fa48003"
		}
		ccutil.Logger.Debug("Starting migration of Gx Data")
		err = t.migrateData(stub, migrationPurposeType)
	}
	return err
}

func (t *APICC) applyConfiguration(stub *guaranteePB.ChaincodeStub, initRequest *guaranteePB.GXInitRequest) error {
	// Set Newco MSP ID
	newcoMspID := initRequest.GetNewcoMspId()
	if newcoMspID == "" {
		newcoMspID = "newco"
	}
	newcoMspIDValue := types.StringValue{Value: newcoMspID}
	newcoMspIDKey, err := ccutil.GenerateSystemPropertyKey(stub, ccutil.SPKeyNewcoMspID)
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, newcoMspIDKey, &newcoMspIDValue)
	if err != nil {
		return err
	}

	// Set Platform Channel ID
	platformChannel := initRequest.GetPlatformChannelId()
	if platformChannel == "" {
		platformChannel = "platform-channel"
	}
	platformChannelValue := types.StringValue{Value: platformChannel}
	platformChannelKey, err := ccutil.GenerateSystemPropertyKey(stub, guaranteeutil.SPKeyPlatformChannel)
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, platformChannelKey, &platformChannelValue)
	if err != nil {
		return err
	}

	// Set Profile Chaincode name
	profileCC := initRequest.GetProfileCc()
	if profileCC == "" {
		profileCC = "profile"
	}
	profileCCValue := types.StringValue{Value: profileCC}
	profileCCKey, err := ccutil.GenerateSystemPropertyKey(stub, guaranteeutil.SPKeyProfileCC)
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, profileCCKey, &profileCCValue)
	if err != nil {
		return err
	}

	// Set Prefix
	prefix := initRequest.GetPrefix()
	if prefix == "" {
		return errors.New("Prefix must be specified")
	}
	prefixValue := types.StringValue{Value: prefix}
	prefixKey, err := ccutil.GenerateSystemPropertyKey(stub, guaranteeutil.SPKeyPrefix)
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, prefixKey, &prefixValue)
	return err
}

// TODO remove all this code after migration

func (t *APICC) migrateData(stub *guaranteePB.ChaincodeStub, migrationPurposeType string) error {
	err := t.migrateGuarantees(stub, migrationPurposeType)
	if err != nil {
		return err
	}
	ccutil.Logger.Debug("Finished migrating guarantees. Migrating Gx requests now...")

	err = t.migrateRequests(stub, migrationPurposeType)
	ccutil.Logger.Debugf("Finished migrating guarantee requests. Error %v\n", err)
	return err
}

func (t *APICC) migrateGuarantees(stub *guaranteePB.ChaincodeStub, migrationPurposeType string) error {
	legacyGXs, err := t.getAllLegacyGX(stub)
	if err != nil {
		return err
	}
	for _, legacyGX := range legacyGXs {
		ccutil.Logger.Debugf("Migrating Gx %s | %v", legacyGX.GetId(), legacyGX.GetIssuedAt())
		gx := t.convertLegacyGx(*legacyGX, migrationPurposeType)
		// Put Guarantee into state
		gxKey, err := generateGXKey(stub, gx.GetId())
		if err != nil {
			return err
		}
		err = ccutil.PutStatePB(stub, gxKey, &gx)
		if err != nil {
			return err
		}
	}
	return nil
}

func (t *APICC) migrateRequests(stub *guaranteePB.ChaincodeStub, migrationPurposeType string) error {
	ccutil.Logger.Debug("Loading guarantee requests...")
	legacyReqs, err := t.getAllLegacyFlows(stub)
	ccutil.Logger.Debugf("Done - Error: %v\n", err)
	if err != nil {
		return err
	}
	for _, legacyReq := range legacyReqs {
		var err error
		switch rt := legacyReq.GetRequest().(type) {
		case *guaranteePB.LegacyGXStartRequest_GxIssueRequest:
			t.migrateIssue(stub, migrationPurposeType, legacyReq)
		case *guaranteePB.LegacyGXStartRequest_GxAmendRequest:
			t.migrateAmend(stub, migrationPurposeType, legacyReq)
		case *guaranteePB.LegacyGXStartRequest_GxCancelRequest:
			// Do nothing
		case *guaranteePB.LegacyGXStartRequest_GxDemandRequest:
			// Do nothing
		case *guaranteePB.LegacyGXStartRequest_GxPayWalkRequest:
			// Do nothing
		case *guaranteePB.LegacyGXStartRequest_GxTransferRequest:
			t.migrateTransfer(stub, migrationPurposeType, legacyReq)
		case *guaranteePB.LegacyGXStartRequest_GxExpireRequest:
			// Do nothing
		default:
			err = fmt.Errorf("Invalid Request Type %T", rt)
		}

		if err != nil {
			return err
		}
	}
	return nil
}

func (t *APICC) migrateIssue(stub *guaranteePB.ChaincodeStub, migrationPurposeType string, legacyReq *guaranteePB.LegacyGXStartRequest) error {
	legacyIssue := legacyReq.GetGxIssueRequest()
	ccutil.Logger.Debugf("Migrating Gx Issue Request %s | %v ...", legacyIssue.Id, legacyIssue.GetCreatedAt())
	issue := guaranteePB.GXIssueRequest{}
	issue.Id = legacyIssue.Id
	issue.GxId = legacyIssue.GxId
	issue.OrgIds = legacyIssue.OrgIds
	issue.Status = legacyIssue.Status
	issue.CreatedAt = legacyIssue.CreatedAt
	issue.CreatedBy = legacyIssue.CreatedBy
	issue.UpdatedAt = legacyIssue.UpdatedAt
	issue.UpdatedBy = legacyIssue.UpdatedBy
	issue.OffchainCreatedAt = legacyIssue.OffchainCreatedAt
	legacyGx := legacyIssue.GetGx()
	gx := t.convertLegacyGx(*legacyGx, migrationPurposeType)
	issue.Gx = &gx

	flowKey, err := ccutil.GenerateFlowKey(stub, issue.GetId())
	ccutil.Logger.Debugf("Finished. Error: %v\n", err)
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, flowKey, &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxIssueRequest{GxIssueRequest: &issue}})
	return err
}

func (t *APICC) migrateAmend(stub *guaranteePB.ChaincodeStub, migrationPurposeType string, legacyReq *guaranteePB.LegacyGXStartRequest) error {
	legacyAmend := legacyReq.GetGxAmendRequest()
	ccutil.Logger.Debugf("Migrating Gx Amend Request %s | %v ...", legacyAmend.Id, legacyAmend.GetCreatedAt())
	amend := guaranteePB.GXAmendRequest{}
	amend.Id = legacyAmend.Id
	amend.GxId = legacyAmend.GxId
	amend.Amount = legacyAmend.Amount
	amend.ExpiresAt = legacyAmend.ExpiresAt
	amend.ExpiresAtOpenEnded = legacyAmend.ExpiresAtOpenEnded
	amend.OrgIds = legacyAmend.OrgIds
	amend.Status = legacyAmend.Status
	amend.CreatedAt = legacyAmend.CreatedAt
	amend.CreatedBy = legacyAmend.CreatedBy
	amend.UpdatedAt = legacyAmend.UpdatedAt
	amend.UpdatedBy = legacyAmend.UpdatedBy

	legacyPurpose := legacyAmend.GetGxRentalPurpose()

	// Have to use gets as fields may be undefined
	purpose := map[string]*guaranteePB.GxPurposeElement{
		"propertyDetails": &guaranteePB.GxPurposeElement{
			ElementType: guaranteePB.GxPurposeElementType_MAP,
			MapValue: map[string]*guaranteePB.GxPurposeElement{
				"propertyName": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.GetPropertyName().GetValue()},
				},
				"shopNumber": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.GetShopNumber().GetValue()},
				},
			},
		},
		"propertyAddress": &guaranteePB.GxPurposeElement{
			ElementType: guaranteePB.GxPurposeElementType_MAP,
			MapValue: map[string]*guaranteePB.GxPurposeElement{
				"addressStreet": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.GetAddress().GetStreetAddress().GetValue()},
				},
				"addressSuburb": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.GetAddress().GetAddressLocality().GetValue()},
				},
				"addressPostcode": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.GetAddress().GetPostalCode().GetValue()},
				},
				"addressCountry": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.GetAddress().GetAddressCountry().GetValue()},
				},
				"addressState": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.GetAddress().GetAddressRegion().GetValue()},
				},
			},
		},
		"purpose": &guaranteePB.GxPurposeElement{
			ElementType: guaranteePB.GxPurposeElementType_MAP,
			MapValue: map[string]*guaranteePB.GxPurposeElement{
				"comment": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.GetFreeFormText().GetValue()},
				},
			},
		},
	}

	if legacyPurpose != nil {
		if legacyPurpose.PropertyName == nil && legacyPurpose.ShopNumber == nil {
			purpose["propertyDetails"] = nil
		} else {
			if legacyPurpose.PropertyName == nil {
				purpose["propertyDetails"].MapValue["propertyName"] = nil
			}
			if legacyPurpose.ShopNumber == nil {
				purpose["propertyDetails"].MapValue["shopNumber"] = nil
			}
		}
		if legacyPurpose.Address == nil {
			purpose["propertyAddress"] = nil
		} else {
			if legacyPurpose.Address.StreetAddress == nil {
				purpose["propertyAddress"].MapValue["addressStreet"] = nil
			}
			if legacyPurpose.Address.AddressLocality == nil {
				purpose["propertyAddress"].MapValue["addressSuburb"] = nil
			}
			if legacyPurpose.Address.PostalCode == nil {
				purpose["propertyAddress"].MapValue["addressPostcode"] = nil
			}
			if legacyPurpose.Address.AddressCountry == nil {
				purpose["propertyAddress"].MapValue["addressCountry"] = nil
			}
			if legacyPurpose.Address.AddressRegion == nil {
				purpose["propertyAddress"].MapValue["addressState"] = nil
			}
		}
		if legacyPurpose.FreeFormText == nil {
			purpose["purpose"] = nil
		}
		amend.Purpose = purpose
	} else {
		amend.Purpose = nil
	}

	flowKey, err := ccutil.GenerateFlowKey(stub, amend.GetId())
	ccutil.Logger.Debugf("Finished. Error: %v\n", err)
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, flowKey, &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxAmendRequest{GxAmendRequest: &amend}})
	return err
}

func (t *APICC) migrateTransfer(stub *guaranteePB.ChaincodeStub, migrationPurposeType string, legacyReq *guaranteePB.LegacyGXStartRequest) error {
	legacyTransfer := legacyReq.GetGxTransferRequest()
	ccutil.Logger.Debugf("Migrating Gx Transfer Request %s | %v ...\n", legacyTransfer.Id, legacyTransfer.GetCreatedAt())
	transfer := guaranteePB.GXTransferRequest{}
	transfer.Id = legacyTransfer.Id
	transfer.GxId = legacyTransfer.GxId
	transfer.Reason = legacyTransfer.Reason
	transfer.Beneficiaries = legacyTransfer.Beneficiaries
	transfer.OrgIds = legacyTransfer.OrgIds
	transfer.Status = legacyTransfer.Status
	transfer.NewGxId = legacyTransfer.NewGxId
	transfer.CreatedAt = legacyTransfer.CreatedAt
	transfer.CreatedBy = legacyTransfer.CreatedBy
	transfer.UpdatedAt = legacyTransfer.UpdatedAt
	transfer.UpdatedBy = legacyTransfer.UpdatedBy
	legacyGx := legacyTransfer.GetGx()
	gx := t.convertLegacyGx(*legacyGx, migrationPurposeType)
	transfer.Gx = &gx

	flowKey, err := ccutil.GenerateFlowKey(stub, transfer.GetId())
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, flowKey, &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxTransferRequest{GxTransferRequest: &transfer}})
	return err
}

func (t *APICC) getAllLegacyGX(stub *guaranteePB.ChaincodeStub) ([]*guaranteePB.LegacyGX, error) {
	iterator, err := generateGXIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var gxs []*guaranteePB.LegacyGX

	for iterator.HasNext() {
		gxKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		gxBytes := gxKV.GetValue()

		var gx guaranteePB.LegacyGX
		err = ccutil.Unmarshal(gxBytes, &gx)
		if err != nil {
			continue
			// return nil, err
		}

		gxs = append(gxs, &gx)
	}

	return gxs, nil
}

func (t *APICC) getAllLegacyFlows(stub *guaranteePB.ChaincodeStub) ([]*guaranteePB.LegacyGXStartRequest, error) {
	iterator, err := ccutil.GenerateFlowIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var flows []*guaranteePB.LegacyGXStartRequest

	for iterator.HasNext() {

		flowKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		flowBytes := flowKV.GetValue()
		var flow guaranteePB.LegacyGXStartRequest
		err = ccutil.Unmarshal(flowBytes, &flow)
		if err != nil {
			ccutil.Logger.Debugf("Cannot unmarshall GxRequest: %v", flowBytes)
			continue
			// return nil, err
		}

		flows = append(flows, &flow)
	}

	return flows, nil
}

func (t *APICC) convertLegacyGx(legacyGX guaranteePB.LegacyGX, migrationPurposeType string) guaranteePB.GX {
	gx := guaranteePB.GX{}
	gx.Id = legacyGX.Id
	gx.PurposeType = migrationPurposeType
	gx.Applicants = legacyGX.Applicants
	gx.Beneficiaries = legacyGX.Beneficiaries
	gx.Status = legacyGX.Status
	gx.Amount = legacyGX.Amount
	gx.BankReference = legacyGX.BankReference
	gx.ExpiresAt = legacyGX.ExpiresAt
	gx.PrevGxId = legacyGX.PrevGxId
	gx.ActiveFlows = legacyGX.ActiveFlows
	gx.TcId = legacyGX.TcId
	gx.IssuedAt = legacyGX.IssuedAt
	gx.UpdatedAt = legacyGX.UpdatedAt

	legacyPurpose := legacyGX.GetGxRentalPurpose()
	gx.Purpose = map[string]*guaranteePB.GxPurposeElement{
		"propertyDetails": &guaranteePB.GxPurposeElement{
			ElementType: guaranteePB.GxPurposeElementType_MAP,
			MapValue: map[string]*guaranteePB.GxPurposeElement{
				"propertyName": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.PropertyName},
				},
				"shopNumber": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.ShopNumber},
				},
			},
		},
		"propertyAddress": &guaranteePB.GxPurposeElement{
			ElementType: guaranteePB.GxPurposeElementType_MAP,
			MapValue: map[string]*guaranteePB.GxPurposeElement{
				"addressStreet": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.Address.StreetAddress},
				},
				"addressSuburb": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.Address.AddressLocality},
				},
				"addressPostcode": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.Address.PostalCode},
				},
				"addressCountry": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.Address.AddressCountry},
				},
				"addressState": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.Address.AddressRegion},
				},
			},
		},
		"purpose": &guaranteePB.GxPurposeElement{
			ElementType: guaranteePB.GxPurposeElementType_MAP,
			MapValue: map[string]*guaranteePB.GxPurposeElement{
				"comment": &guaranteePB.GxPurposeElement{
					ElementType: guaranteePB.GxPurposeElementType_STRING,
					StringValue: &types.StringValue{Value: legacyPurpose.FreeFormText},
				},
			},
		},
	}
	return gx
}
