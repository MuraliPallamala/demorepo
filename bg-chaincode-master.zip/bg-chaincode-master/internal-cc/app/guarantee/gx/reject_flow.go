package gx

import (
	"errors"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// RejectFlow rejects a flow
func (t *APICC) RejectFlow(stub *guaranteePB.ChaincodeStub, flowActionRequest *sharedPB.FlowActionRequest) (*sharedPB.FlowActionRequest, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Processing RejectFlow action %v\n", flowActionRequest)

	// Set ID
	flowActionRequest.Id = ccutil.GenerateFlowActionID(stub)
	ccutil.Logger.Infof("Action REJECT flow (id: %v, flow: %v)\n", flowActionRequest.Id, flowActionRequest.GetFlowId())

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}
	err = ccutil.SetCreatedMetadata(stub, flowActionRequest, info.organization.GetId())
	if err != nil {
		return nil, err
	}

	// Get Start Request
	var startRequest guaranteePB.GXStartRequest
	flowKey, err := ccutil.GenerateFlowKey(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	startBaseRequest, err := getRequestFromStartRequest(&startRequest)
	if err != nil {
		return nil, err
	}

	// check whether request can be rejected
	if !t.requestCanBeRejected(&startRequest) {
		return nil, errors.New("Error, request type cannot be rejected")
	}

	// Check if Flow is active
	if startBaseRequest.GetStatus() != sharedPB.FlowStatus_FLOW_ACTIVE {
		return nil, errors.New("Request is not active")
	}

	// Get Previous approvals
	actions, err := getGXFlowActions(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}

	// Check whether current creator is part of approval flow as they are the only ones allowed to reject
	allowedToApprove, err := isAllowedToApproveFlow(stub, &startRequest, actions, &info)
	if err != nil {
		return nil, err
	}
	if !allowedToApprove {
		return nil, errors.New("Organization is not allowed to reject request")
	}

	// TODO confirm that organization is allowed to reject after approving otherwise add check to make sure it hasn't approved

	// Set RequestType
	flowActionRequest.RequestType = sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_REJECT
	// Add reject request to flow
	err = t.addAction(stub, flowActionRequest.GetFlowId(), &guaranteePB.GXFlowActionRequest{Request: &guaranteePB.GXFlowActionRequest_FlowActionRequest{FlowActionRequest: flowActionRequest}})
	if err != nil {
		return nil, err
	}

	status, err := t.getRejectedStatus(stub, &startRequest, &info)
	if err != nil {
		return nil, err
	}
	// Update flow status to rejected or withdrawn
	setStatus(startBaseRequest, status)
	err = ccutil.PutStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	// Update GX active requests
	err = t.updateGXClearActiveRequestFlag(stub, &startRequest)
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return flowActionRequest, nil
}

func (t *APICC) getRejectedStatus(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, cInfo *creatorInfo) (sharedPB.FlowStatus, error) {
	return t.processWithdrawnStatus(stub, startRequest, cInfo, sharedPB.FlowStatus_FLOW_REJECTED)
}

func (t *APICC) processWithdrawnStatus(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, cInfo *creatorInfo, baseStatus sharedPB.FlowStatus) (sharedPB.FlowStatus, error) {
	requestType, err := getRequestType(startRequest)
	if err != nil {
		return sharedPB.FlowStatus_FLOW_ACTIVE, err
	}
	if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_ISSUE || requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_AMEND {
		var gx *guaranteePB.GX
		if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_ISSUE {
			gx = startRequest.GetGxIssueRequest().GetGx()
		} else {
			gx, err = get(stub, startRequest.GetGxAmendRequest().GetGxId())
			if err != nil {
				return sharedPB.FlowStatus_FLOW_ACTIVE, err
			}
		}

		if !isBeneficiary(gx, cInfo) {
			//  return withdrawn to hide status from beneficiary
			return sharedPB.FlowStatus_FLOW_WITHDRAWN, nil
		}
	}

	// return base status
	return baseStatus, nil
}

func (t *APICC) requestCanBeRejected(startRequest *guaranteePB.GXStartRequest) bool {
	// Currently only demand can't be rejected, but this could change in the future
	_, isDemand := startRequest.Request.(*guaranteePB.GXStartRequest_GxDemandRequest)
	return !isDemand
}
