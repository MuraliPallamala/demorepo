package gx

import (
	"errors"
	"reflect"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// RecallFlow recalls a started flow
func (t *APICC) RecallFlow(stub *guaranteePB.ChaincodeStub, recallRequest *guaranteePB.GXRecallRequest) (*guaranteePB.GXRecallRequest, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Processing RecallFlow request %v\n", recallRequest)

	// Set ID
	recallRequest.Id = ccutil.GenerateFlowActionID(stub)
	ccutil.Logger.Infof("Action RECALL flow (id: %v, flow: %v)\n", recallRequest.Id, recallRequest.GetFlowId())

	// Get stored start request and confirm it is of right type and status
	flow, err := getFlow(stub, recallRequest.GetFlowId())
	if err != nil {
		return nil, err
	}

	// Get original request
	baseOriginalRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		return nil, err
	}

	if baseOriginalRequest.GetStatus() != sharedPB.FlowStatus_FLOW_ACTIVE {
		return nil, errors.New("Flow is not active")
	}

	if reflect.TypeOf(flow) != reflect.TypeOf(recallRequest.GetUpdatedRequest()) {
		return nil, errors.New("Invalid StartRequest type for recall")
	}

	// TODO validate?

	// Process Transfer
	if _, ok := flow.Request.(*guaranteePB.GXStartRequest_GxTransferRequest); ok {
		// For transfer set Gx field as it won't be present for recall
		transferRequest := recallRequest.GetUpdatedRequest().GetGxTransferRequest()
		transferRequest.Gx = flow.GetGxTransferRequest().GetGx()
	}

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}

	// check that recalling org is the original organization
	if baseOriginalRequest.GetCreatedBy() != info.organization.GetId() {
		return nil, errors.New("Only creator of original request can recall")
	}

	// Set Metadata of request
	err = ccutil.SetCreatedMetadata(stub, recallRequest, info.organization.GetId())
	if err != nil {
		return nil, err
	}

	// Set Metadata of updated start request
	updatedRequest := recallRequest.GetUpdatedRequest()
	baseUpdatedRequest, err := getRequestFromStartRequest(updatedRequest)
	if err != nil {
		return nil, err
	}

	baseRequestElem := reflect.ValueOf(baseUpdatedRequest).Elem()
	baseRequestElem.FieldByName("CreatedBy").SetString(recallRequest.GetCreatedBy())
	baseRequestElem.FieldByName("CreatedAt").Set(reflect.ValueOf(recallRequest.GetCreatedAt()))
	err = ccutil.SetCreatedMetadata(stub, baseUpdatedRequest, info.organization.GetId())
	if err != nil {
		return nil, err
	}

	// process updated start request
	processUpdatedStartRequest(updatedRequest, flow)

	// Add action to state
	err = t.addAction(stub, recallRequest.GetFlowId(), &guaranteePB.GXFlowActionRequest{Request: &guaranteePB.GXFlowActionRequest_RecallRequest{RecallRequest: recallRequest}})
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return recallRequest, nil
}

func processUpdatedStartRequest(updatedRequest *guaranteePB.GXStartRequest, originalRequest *guaranteePB.GXStartRequest) error {
	// Handle unique data modifications
	switch updatedRequest.Request.(type) {
	case *guaranteePB.GXStartRequest_GxIssueRequest:
		// Add Guararantee ID (Same as original Guarantee ID)
		issueRequest := updatedRequest.GetGxIssueRequest()
		originalIssueRequest := originalRequest.GetGxIssueRequest()
		gx := issueRequest.GetGx()

		// Applicants (Same as original appliants)
		gx.Applicants = originalIssueRequest.GetGx().GetApplicants()

		// Beneficiaries (Same as original beneficiaries)
		gx.Beneficiaries = originalIssueRequest.GetGx().GetBeneficiaries()

		// Add Guarantee Request ID
		issueRequest.Id = originalIssueRequest.GetId()
	default:
		baseUpdatedRequest, err := getGXModifyRequestFromStartRequest(updatedRequest)
		if err != nil {
			return err
		}
		baseOriginalRequest, err := getGXModifyRequestFromStartRequest(originalRequest)
		if err != nil {
			return err
		}
		ccutil.SetID(baseUpdatedRequest, baseOriginalRequest.GetId())
		setGXID(baseUpdatedRequest, baseOriginalRequest.GetGxId())
	}
	return nil
}
