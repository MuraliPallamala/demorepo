package gx

import (
	"errors"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// DeferFlow adds a defer to a flow
func (t *APICC) DeferFlow(stub *guaranteePB.ChaincodeStub, flowActionRequest *sharedPB.FlowActionRequest) (*sharedPB.FlowActionRequest, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Processing DeferFlow action %v\n", flowActionRequest)

	// Set ID
	flowActionRequest.Id = ccutil.GenerateFlowActionID(stub)
	ccutil.Logger.Infof("Action DEFER flow (id: %v, flow: %v)\n", flowActionRequest.Id, flowActionRequest.GetFlowId())

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}
	creatorOrganizationID := info.organization.GetId()

	err = ccutil.SetCreatedMetadata(stub, flowActionRequest, creatorOrganizationID)
	if err != nil {
		return nil, err
	}

	// Checks that is issuer
	isIssuerRes, err := isIssuer(stub, &info)
	if err != nil {
		return nil, err
	}
	if !isIssuerRes {
		return nil, errors.New("Only issuer can defer requests")
	}

	// Get Start Request
	var startRequest guaranteePB.GXStartRequest
	flowKey, err := ccutil.GenerateFlowKey(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}

	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	baseRequest, err := getRequestFromStartRequest(&startRequest)
	if err != nil {
		return nil, err
	}

	// Check if Flow is active
	if baseRequest.GetStatus() != sharedPB.FlowStatus_FLOW_ACTIVE {
		return nil, errors.New("Request is not active")
	}

	// check whether request can be deferred
	if !t.requestCanBeDeferred(&startRequest) {
		return nil, errors.New("Error, request type cannot be deferred")
	}

	// check whether request has existing deferred action
	actions, err := getGXFlowActions(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}

	// only check last action
	if len(actions) > 0 {
		action := actions[len(actions)-1]
		if _, ok := action.Request.(*guaranteePB.GXFlowActionRequest_FlowActionRequest); ok {
			storedFlowActionRequest := action.GetFlowActionRequest()
			if storedFlowActionRequest.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_DEFER {
				return nil, errors.New("Error, request has already been deferred")
			}
		}
	}

	// Set RequestType
	flowActionRequest.RequestType = sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_DEFER
	// Add defer request to flow
	err = t.addAction(stub, flowActionRequest.GetFlowId(), &guaranteePB.GXFlowActionRequest{Request: &guaranteePB.GXFlowActionRequest_FlowActionRequest{FlowActionRequest: flowActionRequest}})
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return flowActionRequest, nil
}

func (t *APICC) requestCanBeDeferred(startRequest *guaranteePB.GXStartRequest) bool {
	_, isDemand := startRequest.Request.(*guaranteePB.GXStartRequest_GxDemandRequest)
	return isDemand
}
