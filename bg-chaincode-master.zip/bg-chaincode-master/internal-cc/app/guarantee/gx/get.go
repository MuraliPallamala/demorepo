package gx

import (
	"errors"
	"time"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"

	"github.com/gogo/protobuf/types"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

// Get retrieves an existing GX
func (t *APICC) Get(stub *guaranteePB.ChaincodeStub, idValue *sharedPB.IDValue) (*guaranteePB.GX, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Getting GX with ID %v\n", idValue)

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}

	gx, err := get(stub, idValue.GetValue())
	if err != nil {
		stub.SetResponseCode(404)
		return nil, err
	}

	hasAccessToGx, err := hasAccessToGx(stub, gx, &info)
	if err != nil {
		return nil, err
	}

	if !hasAccessToGx {
		stub.SetResponseCode(403)
		return nil, errors.New("Organization does not have permissions to access guarantee")
	}

	stub.SetResponseCode(200)
	return gx, nil
}

func get(stub shim.ChaincodeStubInterface, gxID string) (*guaranteePB.GX, error) {
	var gx guaranteePB.GX
	gxKey, err := generateGXKey(stub, gxID)
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, gxKey, &gx)
	if err != nil {
		return nil, err
	}
	return &gx, nil
}

func hasAccessToGx(stub shim.ChaincodeStubInterface, gx *guaranteePB.GX, cInfo *creatorInfo) (bool, error) {
	isIssuerRes, err := isIssuer(stub, cInfo)
	if err != nil {
		return false, err
	}
	if cInfo.organization.EntityType == profilePB.OrganizationEntityType_ORGANIZATION_CONSORTIUM || isIssuerRes {
		return true, nil
	}

	appBenList := append(gx.GetApplicants(), gx.GetBeneficiaries()...)
	if !ccutil.ContainsString(appBenList, cInfo.organization.GetId()) {
		return false, nil
	}

	allowedTimeRanges := cInfo.publicKey.GetAllowedTimeRanges()
	isActiveOrg := allowedTimeRanges[len(allowedTimeRanges)-1].GetExpiryDate() == nil

	if gx.Status == guaranteePB.GXStatus_GX_ACTIVE && isActiveOrg {
		// guarantee is active, and org is linked so add
		return true, nil
	}
	gxIssuedAt, err := types.TimestampFromProto(gx.GetIssuedAt())
	if err != nil {
		return false, err
	}

	// guarantee not active check if org has access
	for _, timeRange := range allowedTimeRanges {
		startDate, err := types.TimestampFromProto(timeRange.GetStartDate())
		if err != nil {
			return false, err
		}
		var expiryDate time.Time
		if timeRange.GetExpiryDate() != nil {
			expiryDate, err = types.TimestampFromProto(timeRange.GetExpiryDate())
			if err != nil {
				return false, err
			}
		} else {
			expiryDate = ccutil.MaxTime
		}

		if gxIssuedAt.After(startDate) && gxIssuedAt.Before(expiryDate) {
			// guarantee falls in key time range, so allow
			return true, nil
		}
	}
	return false, nil
}
