package gx

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

func TestRejectFlow(t *testing.T) {
	stub, _ := setup(t)

	cctest.SetMockStubCert(t, stub, appOrgPEM)
	initGX := generateExampleBasicGX()
	issueReq := invokeStartFlowIssueAndGetRequest(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})
	flowID := issueReq.GetId()

	// Test that creator can't reject
	rejectRequestBytes, err := ccutil.Marshal(&sharedPB.FlowActionRequest{FlowId: flowID})
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.RejectFlow), rejectRequestBytes}
	res := stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status == shim.OK {
		t.Fatal("Error expected only creator to not be able to reject")
	}

	// Test that approver can reject
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	res = stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke RejectFlow: %s", string(res.Message))
	}
	var payload sharedPB.FlowActionRequest
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}
	if payload.GetFlowId() != flowID {
		t.Fatalf("Expected reject flow ID to equal start flow ID, instead: start Flow ID %s, reject Flow ID %s", flowID, payload.GetFlowId())
	}

	// Test that flow is set to rejected
	flow, err := getFlow(stub, flowID)
	if err != nil {
		t.Fatal(err.Error())
	}
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		t.Fatal(err.Error())
	}
	checkFlowStatus(t, baseRequest.GetStatus(), sharedPB.FlowStatus_FLOW_REJECTED)

	// Test that reject action was added
	actionResponse, err := getFlowActions(stub, flowID)
	if err != nil {
		t.Fatal(err.Error())
	}
	actions := actionResponse.GetRequests()
	flowActionRequestWrapper, ok := actions[len(actions)-1].GetRequest().(*guaranteePB.GXFlowActionRequest_FlowActionRequest)
	if !ok {
		t.Fatal("Expected last action to be of type FlowActionRequest, but it was not")
	}
	flowActionRequest := flowActionRequestWrapper.FlowActionRequest
	checkFlowActionType(t, flowActionRequest.GetRequestType(), sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_REJECT)
}
