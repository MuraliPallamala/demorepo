package gx

import (
	"errors"
	"testing"
	"time"

	"github.com/gogo/protobuf/types"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

func TestStartFlowIssue(t *testing.T) {
	stub, _ := setup(t)

	// Initiate start request
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	gx := generateExampleBasicGX()
	flowRes := invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx})
	flowID := flowRes.GetGxIssueRequest().GetId()

	// Check that startRequest has been stored in state
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		t.Fatal(err.Error())
	}
	checkFlowStatus(t, baseRequest.GetStatus(), sharedPB.FlowStatus_FLOW_ACTIVE)

	// Check all fields of stored create request
	storedIssueRequest := flow.GetGxIssueRequest()
	if storedIssueRequest.GetId() != flowID {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", flowID, storedIssueRequest.GetId())
	}
	if storedIssueRequest.GetCreatedBy() != appOrgID {
		t.Fatalf("Error incorrect 'createdBy' of stored flow request, expected: %s, got: %s", appOrgID, storedIssueRequest.GetCreatedBy())
	}
}

func TestStartFlowAmend(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Initiate start request
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	flowRes := invokeStartFlowAmend(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXAmendRequest{GxId: gx.GetId(), Amount: 20})
	flowID := flowRes.GetGxAmendRequest().GetId()

	// Check that startRequest has been stored in state
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		t.Fatal(err.Error())
	}
	checkFlowStatus(t, baseRequest.GetStatus(), sharedPB.FlowStatus_FLOW_ACTIVE)

	// Check all fields of stored create request
	// TODO check all fields, only checking ID currently
	storedAmendRequest := flow.GetGxAmendRequest()
	if storedAmendRequest.GetId() != flowID {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", flowID, storedAmendRequest.GetId())
	}

	// Expect that issuing another amend results in failure
	invokeStartFlowAmendExpectFailure(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXAmendRequest{GxId: gx.GetId(), Amount: 20}, 403)
}

func TestStartFlowCancel(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Initiate start request
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	flowRes := invokeStartFlowCancel(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXCancelRequest{GxId: gx.GetId()})
	flowID := flowRes.GetGxCancelRequest().GetId()

	// Check that startRequest has been stored in state
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		t.Fatal(err.Error())
	}
	checkFlowStatus(t, baseRequest.GetStatus(), sharedPB.FlowStatus_FLOW_ACTIVE)

	// Check all fields of stored create request
	// TODO check all fields, only checking ID currently
	storedCancelRequest := flow.GetGxCancelRequest()
	if storedCancelRequest.GetId() != flowID {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", flowID, storedCancelRequest.GetId())
	}

	// Expect that issuing another cancel results in failure
	invokeStartFlowCancelExpectFailure(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXCancelRequest{GxId: gx.GetId()}, 403)
}

func TestStartFlowDemandFull(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Initiate start request
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	flowRes := invokeStartFlowDemand(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: gx.GetAmount().GetOutstanding()})
	flowID := flowRes.GetGxDemandRequest().GetId()

	// Check that startRequest has been stored in state
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		t.Fatal(err.Error())
	}
	checkFlowStatus(t, baseRequest.GetStatus(), sharedPB.FlowStatus_FLOW_ACTIVE)

	// Check all fields of stored create request
	// TODO check all fields, only checking ID currently
	storedDemandRequest := flow.GetGxDemandRequest()
	if storedDemandRequest.GetId() != flowID {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", flowID, storedDemandRequest.GetId())
	}

	// Expect that issuing another demand results in failure
	invokeStartFlowDemandExpectFailure(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: gx.GetAmount().GetOutstanding()}, 403)
}

func TestStartFlowDemandPartial(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Initiate start request
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	flowRes := invokeStartFlowDemand(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: gx.GetAmount().GetOutstanding() - 1})
	flowID := flowRes.GetGxDemandRequest().GetId()

	// Check that startRequest has been stored in state
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		t.Fatal(err.Error())
	}
	checkFlowStatus(t, baseRequest.GetStatus(), sharedPB.FlowStatus_FLOW_ACTIVE)

	// Check all fields of stored create request
	// TODO check all fields, only checking ID currently
	storedDemandRequest := flow.GetGxDemandRequest()
	if storedDemandRequest.GetId() != flowID {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", flowID, storedDemandRequest.GetId())
	}

	// Expect that issuing another demand results in failure
	invokeStartFlowDemandExpectFailure(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: gx.GetAmount().GetOutstanding() - 1}, 403)
}

func TestStartFlowPayWalk(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Initiate start request
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	flowRes := invokeStartFlowPayWalk(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXPayWalkRequest{GxId: gx.GetId()})
	flowID := flowRes.GetGxPayWalkRequest().GetId()

	// Check that startRequest has been stored in state
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		t.Fatal(err.Error())
	}
	checkFlowStatus(t, baseRequest.GetStatus(), sharedPB.FlowStatus_FLOW_APPROVED)

	// Check all fields of stored create request
	// TODO check all fields, only checking ID currently
	storedPayWalkRequest := flow.GetGxPayWalkRequest()
	if storedPayWalkRequest.GetId() != flowID {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", flowID, storedPayWalkRequest.GetId())
	}

	updatedGX, err := get(stub, gx.GetId())
	if err != nil {
		t.Fatal(err.Error())
	}

	checkGuaranteeStatus(t, updatedGX.GetStatus(), guaranteePB.GXStatus_GX_PAYWALKED)
}

func TestStartFlowTransfer(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Initiate start request
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	flowRes := invokeStartFlowTransfer(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXTransferRequest{GxId: gx.GetId()})
	flowID := flowRes.GetGxTransferRequest().GetId()

	// Check that startRequest has been stored in state
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		t.Fatal(err.Error())
	}
	checkFlowStatus(t, baseRequest.GetStatus(), sharedPB.FlowStatus_FLOW_ACTIVE)

	// Check all fields of stored create request
	// TODO check all fields, only checking ID currently
	storedTransferRequest := flow.GetGxTransferRequest()
	if storedTransferRequest.GetId() != flowID {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", flowID, storedTransferRequest.GetId())
	}

	// Expect that issuing another demand results in failure
	invokeStartFlowTransferExpectFailure(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXTransferRequest{GxId: gx.GetId()}, 403)
}

func TestStartFlowExpiredRequest(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	initGX.ExpiresAt = &types.Timestamp{} // Expired timestamp

	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})
	// Initiate start request
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	flowRes := invokeStartFlowExpire(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXExpireRequest{GxId: gx.GetId()})
	flowID := flowRes.GetGxExpireRequest().GetId()

	// Check that startRequest has been stored in state
	flow := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})
	baseRequest, err := getRequestFromStartRequest(flow)
	if err != nil {
		t.Fatal(err.Error())
	}
	checkFlowStatus(t, baseRequest.GetStatus(), sharedPB.FlowStatus_FLOW_APPROVED)

	// Check all fields of stored create request
	// TODO check all fields, only checking ID currently
	storedExpireRequest := flow.GetGxExpireRequest()
	if storedExpireRequest.GetId() != flowID {
		t.Fatalf("Error incorrect ID of stored flow request, expected: %s, got: %s", flowID, storedExpireRequest.GetId())
	}

	updatedGX, err := get(stub, gx.GetId())
	if err != nil {
		t.Fatal(err.Error())
	}

	checkGuaranteeStatus(t, updatedGX.GetStatus(), guaranteePB.GXStatus_GX_EXPIRED)
}

func TestStartFlowExpiredRequestWithOpenDemand(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()

	// Set expiry for 0.1 seconds in the future
	expiresAtTime := time.Now().Local().Add(time.Millisecond * time.Duration(100))
	expiresAtTimestamp, err := types.TimestampProto(expiresAtTime)
	if err != nil {
		t.Fatal(err.Error())
	}
	initGX.ExpiresAt = expiresAtTimestamp

	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Add Demand request
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	invokeStartFlowDemand(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: gx.GetAmount().GetOutstanding()})

	// sleep for 0.1 seconds so that guarantee is expired
	time.Sleep(time.Millisecond * time.Duration(100))

	// Initiate expire
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	startExpireRequest := &guaranteePB.GXStartRequest{Request: &guaranteePB.GXStartRequest_GxExpireRequest{
		GxExpireRequest: &guaranteePB.GXExpireRequest{GxId: gx.GetId()},
	}}

	// marshal the payload
	startExpireRequestBytes, err := ccutil.Marshal(startExpireRequest)

	if err != nil {
		t.Fatalf("Count not marshal StartRequest: %s", err.Error())
	}

	args := [][]byte{[]byte(ccMethods.StartFlow), startExpireRequestBytes}

	res := stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status == shim.OK {
		t.Fatal("Expected expire to fail since there's an open demand request")
	}

	updatedGX, err := get(stub, gx.GetId())
	if err != nil {
		t.Fatal(err.Error())
	}

	checkGuaranteeStatus(t, updatedGX.GetStatus(), guaranteePB.GXStatus_GX_ACTIVE)
}

func TestValidatePatternConstraint(t *testing.T) {
	// post code pattern
	constraint := &sharedPB.PatternConstraint{Pattern: "^[0-9]{4,4}$"}

	purposeElement := &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_STRING,
		StringValue: &types.StringValue{Value: "3000"},
	}

	err := validatePatternConstraint(purposeElement, constraint)
	if err != nil {
		t.Fatal(err.Error())
	}

	failingPurposeElement := &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_STRING,
		StringValue: &types.StringValue{Value: "30000"},
	}
	err = validatePatternConstraint(failingPurposeElement, constraint)
	if err == nil {
		t.Fatal(errors.New("Should've failed"))
	}
}

func TestValidateDateFormat(t *testing.T) {
	purposeElement := &guaranteePB.GxPurposeElement{
		ElementType: guaranteePB.GxPurposeElementType_STRING,
		StringValue: &types.StringValue{Value: "2019-02-18T00:58:28.058Z"},
	}

	fieldDefinition := &sharedPB.PurposeField{
		Type: sharedPB.PurposeFieldType_PFT_DATE,
		Name: "key",
	}

	fieldList := []*sharedPB.PurposeField{fieldDefinition}
	purpose := make(map[string]*guaranteePB.GxPurposeElement)
	purpose["key"] = purposeElement

	gx := &guaranteePB.GX{
		Purpose: purpose,
	}

	err := processPurposeFields(fieldList, gx.GetPurpose(), false)
	if err != nil {
		t.Fatal(err)
	}
	if gx.GetPurpose()["key"].GetStringValue().GetValue() != "2019-02-18T00:00:00.000Z" {
		t.Fatal("Failed to modifiy original purpose")
	}
}
