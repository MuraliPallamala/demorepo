package gx

import (
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// SearchFlows searches through flows and returns a subset
func (t *APICC) SearchFlows(stub *guaranteePB.ChaincodeStub, request *guaranteePB.GXFlowSearchRequest) (*guaranteePB.GXFlowSearchResponse, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Searching Flows, using search request: %v\n", request)

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}

	var flows []*guaranteePB.GXStartRequest
	if info.organization.GetEntityType() == profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY {
		flows, err = t.getAllFlowsWithOrgID(stub, info.organization.GetId())
		if err != nil {
			return nil, err
		}
	} else {
		flows, err = t.getAllFlows(stub)
		if err != nil {
			return nil, err
		}
	}

	if request.GetLimit() == 0 {
		request.Limit = 50
	}

	paginationResult, err := t.flowsSearchFilter(stub, flows, request, &info)
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return &guaranteePB.GXFlowSearchResponse{Flows: paginationResult.flows, Next: paginationResult.next}, nil
}

func (t *APICC) getAllFlows(stub *guaranteePB.ChaincodeStub) ([]*guaranteePB.GXStartRequest, error) {
	iterator, err := ccutil.GenerateFlowIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var flows []*guaranteePB.GXStartRequest

	for iterator.HasNext() {

		flowKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		flowBytes := flowKV.GetValue()

		var flow guaranteePB.GXStartRequest
		err = ccutil.Unmarshal(flowBytes, &flow)
		if err != nil {
			return nil, err
		}

		flows = append(flows, &flow)
	}

	return flows, nil
}

func (t *APICC) getAllFlowsWithOrgID(stub *guaranteePB.ChaincodeStub, orgID string) ([]*guaranteePB.GXStartRequest, error) {
	flows, err := t.getAllFlows(stub)
	if err != nil {
		return nil, err
	}

	filteredFlows := make([]*guaranteePB.GXStartRequest, 0)
	for _, flow := range flows {
		baseRequest, err := getRequestFromStartRequest(flow)
		if err != nil {
			return nil, err
		}
		orgIDs := baseRequest.GetOrgIds()
		if ccutil.ContainsString(orgIDs, orgID) {
			filteredFlows = append(filteredFlows, flow)
		}
	}
	return filteredFlows, nil
}

func (t *APICC) flowsSearchFilter(stub *guaranteePB.ChaincodeStub, flows []*guaranteePB.GXStartRequest, searchRequest *guaranteePB.GXFlowSearchRequest, cInfo *creatorInfo) (*flowPaginationResult, error) {
	var filteredFlows []*guaranteePB.GXStartRequest
	hasMore := true
	limit := int(searchRequest.GetLimit())
	var next = ""

	for hasMore && len(filteredFlows) < limit {
		couchResult, err := t.flowsCouchFilter(flows, searchRequest)
		if err != nil {
			return nil, err
		}

		if couchResult.next == "" {
			hasMore = false
		}

		timeKeyFilteredFlows, err := t.flowsTimebasedKeyFilter(stub, couchResult.flows, cInfo)
		if err != nil {
			return nil, err
		}

		filteredFlows = append(filteredFlows, timeKeyFilteredFlows...)

		if len(filteredFlows) > limit {
			limitBaseRequest, err := getRequestFromStartRequest(filteredFlows[limit])
			if err != nil {
				return nil, err
			}

			next = limitBaseRequest.GetId()

			filteredFlows = filteredFlows[0:limit]
		} else {
			next = couchResult.next
		}

		searchRequest.Start = next
	}

	return &flowPaginationResult{
		flows: filteredFlows,
		next:  next,
	}, nil
}

// flowsPaginationResult is the result of couchbased pagination
type flowPaginationResult struct {
	flows []*guaranteePB.GXStartRequest
	next  string
}

// TODO replace with couch queries
func (t *APICC) flowsCouchFilter(flows []*guaranteePB.GXStartRequest, searchRequest *guaranteePB.GXFlowSearchRequest) (*flowPaginationResult, error) {
	filteredFlows := make([]*guaranteePB.GXStartRequest, 0)
	limit := int(searchRequest.GetLimit())
	var next string

	foundStart := false
	for _, flow := range flows {
		baseRequest, err := getRequestFromStartRequest(flow)
		if err != nil {
			return nil, err
		}

		requestType, err := getRequestType(flow)
		if err != nil {
			return nil, err
		}

		// skip till start ID
		if searchRequest.GetStart() != "" && !foundStart {
			if baseRequest.GetId() == searchRequest.GetStart() {
				foundStart = true
			} else {
				continue
			}
		}

		if next != "" {
			break
		}

		if (searchRequest.GetStatus() == nil || baseRequest.GetStatus() == searchRequest.GetStatus().GetValue()) &&
			(searchRequest.GetRequestType() == nil || requestType == searchRequest.GetRequestType().GetValue()) &&
			(searchRequest.GetGxId() == "" || baseRequest.GetGxId() == searchRequest.GetGxId() ||
				(requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_TRANSFER && flow.GetGxTransferRequest().GetNewGxId() == searchRequest.GetGxId())) {

			if len(filteredFlows) < limit {
				filteredFlows = append(filteredFlows, flow)
			} else {
				next = baseRequest.GetId()
			}
		}
	}

	return &flowPaginationResult{
		flows: filteredFlows,
		next:  next,
	}, nil
}

func (t *APICC) flowsTimebasedKeyFilter(stub *guaranteePB.ChaincodeStub, flows []*guaranteePB.GXStartRequest, cInfo *creatorInfo) ([]*guaranteePB.GXStartRequest, error) {
	filteredFlows := make([]*guaranteePB.GXStartRequest, 0)
	for _, flow := range flows {
		hasAccessToFlow, err := hasAccessToFlow(stub, flow, cInfo)
		if err != nil {
			return nil, err
		}

		if hasAccessToFlow {
			filteredFlows = append(filteredFlows, flow)
		}
	}

	return filteredFlows, nil
}
