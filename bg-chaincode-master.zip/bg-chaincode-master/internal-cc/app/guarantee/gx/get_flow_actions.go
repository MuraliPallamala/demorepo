package gx

import (
	"errors"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// GetFlowActions gets all actions for a single flow
func (t *APICC) GetFlowActions(stub *guaranteePB.ChaincodeStub, flowIDValue *sharedPB.FlowIDValue) (*guaranteePB.GXFlowActionsResponse, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Getting actions for flow with ID %v\n", flowIDValue)

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}

	flow, err := getFlow(stub, flowIDValue.GetValue())
	if err != nil {
		stub.SetResponseCode(410)
		return nil, err
	}

	hasAccessToFlow, err := hasAccessToFlow(stub, flow, &info)
	if err != nil {
		stub.SetResponseCode(403)
		return nil, err
	}

	if !hasAccessToFlow {
		return nil, errors.New("Organization does not have permissions to access flow")
	}

	stub.SetResponseCode(200)
	return getFlowActions(stub, flowIDValue.GetValue())
}

func getFlowActions(stub shim.ChaincodeStubInterface, flowID string) (*guaranteePB.GXFlowActionsResponse, error) {
	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		return nil, err
	}

	flowStatusBytes, err := stub.GetState(flowKey)
	if err != nil {
		return nil, err
	}

	if len(flowStatusBytes) == 0 {
		return nil, fmt.Errorf("Flow %s does not exist", flowID)
	}

	actions, err := getGXFlowActions(stub, flowID)
	if err != nil {
		return nil, err
	}

	return &guaranteePB.GXFlowActionsResponse{Requests: actions}, nil
}
