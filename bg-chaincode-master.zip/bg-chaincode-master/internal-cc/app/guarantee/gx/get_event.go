package gx

import (
	"errors"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// GetEvent gets a GXEvent by ID
func (t *APICC) GetEvent(stub *guaranteePB.ChaincodeStub, idValue *sharedPB.IDValue) (*guaranteePB.GXEvent, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Getting Event with ID %v\n", idValue)

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}

	event, err := getEvent(stub, idValue.GetValue())
	if err != nil {
		stub.SetResponseCode(404)
		return nil, err
	}

	hasAccess, err := hasAccessToEvent(stub, event, &info)
	if err != nil {
		return nil, err
	}

	if !hasAccess {
		stub.SetResponseCode(403)
		return nil, errors.New("Organization does not have permissions to access guarantee event")
	}

	stub.SetResponseCode(200)
	return event, errors.New("Not Implemented")
}

func getEvent(stub shim.ChaincodeStubInterface, eventID string) (*guaranteePB.GXEvent, error) {
	var event guaranteePB.GXEvent
	eventKey, err := generateGXEventKey(stub, eventID)
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, eventKey, &event)
	if err != nil {
		return nil, err
	}
	return &event, nil
}

func hasAccessToEvent(stub shim.ChaincodeStubInterface, event *guaranteePB.GXEvent, cInfo *creatorInfo) (bool, error) {
	isIssuerRes, err := isIssuer(stub, cInfo)
	if err != nil {
		return false, err
	}

	if cInfo.organization.EntityType == profilePB.OrganizationEntityType_ORGANIZATION_CONSORTIUM ||
		isIssuerRes {
		return true, nil
	}
	return false, nil
}
