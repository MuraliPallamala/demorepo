package gx

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

func TestDeferFlow(t *testing.T) {
	stub, _ := setup(t)

	cctest.SetMockStubCert(t, stub, appOrgPEM)

	// Create demand request

	// Setup guarantee
	initGX := generateExampleBasicGX()
	gx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// Initiate start request
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	flowRes := invokeStartFlowDemand(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXDemandRequest{GxId: gx.GetId(), Amount: gx.GetAmount().GetOutstanding()})
	flowID := flowRes.GetGxDemandRequest().GetId()

	// Test that other parties can't defer
	deferRequestBytes, err := ccutil.Marshal(&sharedPB.FlowActionRequest{FlowId: flowID})
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.DeferFlow), deferRequestBytes}
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	res := stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status == shim.OK {
		t.Fatal("Error expected only issuer to be able to defer")
	}
	cctest.SetMockStubCert(t, stub, benOrgPEM)
	res = stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status == shim.OK {
		t.Fatal("Error expected only issuer to be able to defer")
	}
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	res = stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke DeferFlow: %s", string(res.Message))
	}

	// Test that correct flow ID is returned
	var payload sharedPB.FlowActionRequest
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}
	if payload.GetFlowId() != flowID {
		t.Fatalf("Expected cancel flow ID to equal start flow ID, instead: start Flow ID %s, cancel Flow ID %s", flowID, payload.GetFlowId())
	}

	// Test that defer action was added
	actionResponse, err := getFlowActions(stub, flowID)
	if err != nil {
		t.Fatal(err.Error())
	}
	actions := actionResponse.GetRequests()
	flowActionRequestWrapper, ok := actions[len(actions)-1].GetRequest().(*guaranteePB.GXFlowActionRequest_FlowActionRequest)
	if !ok {
		t.Fatal("Expected last action to be of type FlowActionRequest, but it was not")
	}
	flowActionRequest := flowActionRequestWrapper.FlowActionRequest
	checkFlowActionType(t, flowActionRequest.GetRequestType(), sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_DEFER)
}
