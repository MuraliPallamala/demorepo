package gx

import (
	"reflect"
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestSearchWithIssuer(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX1 := generateExampleBasicGX()
	initGX2 := generateExampleBasicGX()
	storedGX := []*guaranteePB.GX{
		setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX1}),
		setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX2}),
	}

	// check stored gx
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	gxList := invokeSearch(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXSearchRequest{
		Limit:   1000,
		OrderBy: &guaranteePB.GXSearchOrderByValue{Value: guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_ISSUED_AT},
	})

	for i, gx := range gxList.GetGxs() {
		if !reflect.DeepEqual(gx, storedGX[i]) {
			t.Fatalf("Error expected %v, to equal %v", storedGX[i], gx)
		}
	}
}

func TestSearchWithApplicantBeneficiary(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantees
	storedGX := make([]*guaranteePB.GX, 0)
	for i := 0; i < 5; i++ {
		gx := generateExampleBasicGX()
		storedGX = append(storedGX, setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}))
	}

	// check stored gx underneath applicant and beneficiary
	for _, orgPEM := range []string{appOrgPEM, benOrgPEM} {
		cctest.SetMockStubCert(t, stub, orgPEM)
		gxList := invokeSearch(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXSearchRequest{
			Limit:   1000,
			OrderBy: &guaranteePB.GXSearchOrderByValue{Value: guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_ISSUED_AT}})
		for i, gx := range gxList.GetGxs() {
			if !reflect.DeepEqual(gx, storedGX[i]) {
				t.Fatalf("Error expected %v, to equal %v", gx, storedGX[i])
			}
		}
	}

	// check that no gx are stored underneath non-relevant beneficiary
	for _, orgMeta := range [][]string{
		[]string{ben2OrgID, ben2OrgPEM},
	} {
		cctest.SetMockStubCert(t, stub, orgMeta[1])
		gxList := invokeSearch(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXSearchRequest{
			Limit:   1000,
			OrderBy: &guaranteePB.GXSearchOrderByValue{Value: guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_ISSUED_AT}})
		if len(gxList.GetGxs()) != 0 {
			t.Fatalf("Expected org %s to have no guarantees", orgMeta[0])
		}
	}
}

func TestSearchWithParentSub(t *testing.T) {
	stub, profileStub := setup(t)

	numActive := 5
	numFinshedBefore := 6
	numFinishedAfter := 7

	subOrgPem := cctest.AppBenPEM1
	parentOrgPEM := cctest.AppBenPEM4

	// Setup active guarantees guarantee
	for i := 0; i < numActive; i++ {
		gx := generateExampleBasicGX()

		cctest.SetMockStubCert(t, stub, subOrgPem)
		setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx})
	}

	// Setup Finished before
	for i := 0; i < numFinshedBefore; i++ {
		gx := generateExampleBasicGX()

		cctest.SetMockStubCert(t, stub, subOrgPem)
		storedGx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx})
		// Perform Pay Walk to close guarantees
		cctest.SetMockStubCert(t, stub, issuerOrgPEM)
		invokeStartFlowPayWalk(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXPayWalkRequest{GxId: storedGx.GetId()})
	}

	// link orgs
	cctest.SetMockStubCert(t, profileStub, subOrgPem)
	parentOrgKey, err := ccutil.GetPublicKeyPEMFromCertPEM(parentOrgPEM)
	if err != nil {
		t.Fatalf(err.Error())
	}
	activateKeyRequestBytes := profiletest.GenerateActivateKeyRequestBytes(t, parentOrgKey)
	args := [][]byte{[]byte(ccutil.CCMethods.Profile.Organization.ActivateKey), activateKeyRequestBytes}
	res := profileStub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to activate key: %s", string(res.Message))
	}

	// Setup finished after
	for i := 0; i < numFinishedAfter; i++ {
		gx := generateExampleBasicGX()

		cctest.SetMockStubCert(t, stub, subOrgPem)
		storedGx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx})
		// Perform Pay Walk to close guarantees
		cctest.SetMockStubCert(t, stub, issuerOrgPEM)
		invokeStartFlowPayWalk(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXPayWalkRequest{GxId: storedGx.GetId()})
	}

	// check correct amounts of requests are returned
	cctest.SetMockStubCert(t, stub, parentOrgPEM)
	gxList := invokeSearch(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXSearchRequest{
		Limit:   1000,
		OrderBy: &guaranteePB.GXSearchOrderByValue{Value: guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_ISSUED_AT}})

	expected := numActive + numFinishedAfter
	if len(gxList.GetGxs()) != expected {
		t.Fatalf("Wrong number of guarantees returned. Expected %d, Got %d", expected, len(gxList.GetGxs()))
	}
	if gxList.GetNext() != "" {
		t.Fatal("Expected Next to not be set")
	}

	// check correct amounts of requests are returned when using pagination
	pagination1 := invokeSearch(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXSearchRequest{Limit: 2})
	expected = 2
	if len(pagination1.GetGxs()) != expected {
		t.Fatalf("Wrong number of guarantees returned. Expected %d, Got %d", expected, len(pagination1.GetGxs()))
	}
	if pagination1.GetNext() == "" {
		t.Fatal("Expected Next to be set")
	}

	pagination2 := invokeSearch(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXSearchRequest{Start: pagination1.GetNext(), Limit: 1000})
	expected = numActive + numFinishedAfter - 2
	if len(pagination2.GetGxs()) != expected {
		t.Fatalf("Wrong number of guarantees returned. Expected %d, Got %d", expected, len(pagination2.GetGxs()))
	}
	if pagination2.GetNext() != "" {
		t.Fatal("Expected Next to not be set")
	}
}
