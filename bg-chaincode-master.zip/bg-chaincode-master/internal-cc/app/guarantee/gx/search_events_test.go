package gx

import (
	"reflect"
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

func TestSearchEvents(t *testing.T) {
	stub, _ := setup(t)

	// Initiate start request
	cctest.SetMockStubCert(t, stub, appOrgPEM)
	gx := generateExampleBasicGX()

	expectedFlows := []*guaranteePB.GXStartRequest{
		invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}),
		invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}),
		invokeStartFlowIssue(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx}),
	}

	// perform search
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	events := invokeSearchEvents(t, stub, cctest.GenerateMockTxID(""), &sharedPB.EventSearchRequest{}).GetEvents()

	if len(events) != len(expectedFlows) {
		t.Fatalf("Error expected %d events, but got %d", len(expectedFlows), len(events))
	}

	for i, event := range events {
		if !reflect.DeepEqual(event.GetStartFlowEvent().GetStartRequest(), expectedFlows[i]) {
			t.Fatalf("Error expected event payload %v, to equal %v", event.GetStartFlowEvent().GetStartRequest(), expectedFlows[i])
		}
	}
}
