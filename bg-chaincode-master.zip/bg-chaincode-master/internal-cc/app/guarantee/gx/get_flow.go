package gx

import (
	"errors"
	"time"

	"github.com/gogo/protobuf/types"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// GetFlow gets a single flow
func (t *APICC) GetFlow(stub *guaranteePB.ChaincodeStub, flowIDValue *sharedPB.FlowIDValue) (*guaranteePB.GXStartRequest, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Getting flow with ID %v\n", flowIDValue)

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}

	flow, err := getFlow(stub, flowIDValue.GetValue())
	if err != nil {
		stub.SetResponseCode(404)
		return nil, err
	}

	hasAccessToFlow, err := hasAccessToFlow(stub, flow, &info)
	if err != nil {
		stub.SetResponseCode(403)
		return nil, err
	}

	if !hasAccessToFlow {
		return nil, errors.New("Organization does not have permissions to access flow")
	}

	stub.SetResponseCode(200)
	return flow, nil
}

func getFlow(stub shim.ChaincodeStubInterface, flowID string) (*guaranteePB.GXStartRequest, error) {
	var startRequest guaranteePB.GXStartRequest

	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		return nil, err
	}

	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	return &startRequest, nil
}

func hasAccessToFlow(stub shim.ChaincodeStubInterface, startRequest *guaranteePB.GXStartRequest, cInfo *creatorInfo) (bool, error) {
	isIssuerRes, err := isIssuer(stub, cInfo)
	if err != nil {
		return false, err
	}
	if cInfo.organization.EntityType == profilePB.OrganizationEntityType_ORGANIZATION_CONSORTIUM || isIssuerRes {
		return true, nil
	}

	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		return false, err
	}

	if !ccutil.ContainsString(baseRequest.GetOrgIds(), cInfo.organization.GetId()) {
		return false, nil
	}

	allowedTimeRanges := cInfo.publicKey.GetAllowedTimeRanges()
	isActiveOrg := allowedTimeRanges[len(allowedTimeRanges)-1].GetExpiryDate() == nil

	if baseRequest.GetStatus() == sharedPB.FlowStatus_FLOW_ACTIVE && isActiveOrg {
		// flow is active, and org is linked so has access
		return true, nil
	}
	flowUpdatedAt, err := types.TimestampFromProto(baseRequest.GetUpdatedAt())
	if err != nil {
		return false, err
	}

	// flow not active check if org has access
	for _, timeRange := range allowedTimeRanges {
		startDate, err := types.TimestampFromProto(timeRange.GetStartDate())
		if err != nil {
			return false, err
		}
		var expiryDate time.Time
		if timeRange.GetExpiryDate() != nil {
			expiryDate, err = types.TimestampFromProto(timeRange.GetExpiryDate())
			if err != nil {
				return false, err
			}
		} else {
			expiryDate = ccutil.MaxTime
		}

		if flowUpdatedAt.After(startDate) && flowUpdatedAt.Before(expiryDate) {
			// guarantee falls in key time range, so allow
			return true, nil
		}
	}
	return false, nil
}
