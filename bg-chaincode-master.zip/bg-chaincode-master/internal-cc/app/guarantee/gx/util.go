package gx

import (
	"crypto/x509"
	"errors"
	"fmt"
	"reflect"

	proto "github.com/gogo/protobuf/proto"
	"github.com/gogo/protobuf/types"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
	"github.ibm.com/bhaesler/hyperledger-fabric-invoke-go/invoke"
)

var logger = shim.NewLogger("chaincode")

// APICC is a concrete implementation of the generated interface GXAPIInterface
type APICC struct{}

type gxRequestInterface interface {
	ccutil.RequestInterface
	GetGxId() string
	GetOrgIds() []string
	GetStatus() sharedPB.FlowStatus
}

type gxRequestMessage interface {
	proto.Message
	gxRequestInterface
}

// gxModifyRequestInterface is an interface for objects with metadata and an id
// TODO remove
type gxModifyRequestInterface interface {
	gxRequestInterface
}

// TODO remove
type gxModifyRequestMessage interface {
	proto.Message
	gxModifyRequestInterface
}

var channelToMspIDMap = map[string]string{
	"anz-channel":      "anz",
	"commbank_channel": "commbank",
	"nab-channel":      "nab",
	"westpac-channel":  "westpac",
}

func (t *APICC) addAction(stub *guaranteePB.ChaincodeStub, flowID string, action *guaranteePB.GXFlowActionRequest) error {
	seqNum, err := getNumberOfUpdates(stub, flowID)
	if err != nil {
		return err
	}
	// TODO generate flowActionKey based of ID, but make sortable
	flowActionKey, err := ccutil.GenerateFlowActionKey(stub, flowID, seqNum)
	if err != nil {
		return err
	}

	err = ccutil.PutStatePB(stub, flowActionKey, action)
	if err != nil {
		return err
	}

	// Emit event
	return t.storeAndEmitUpdateFlowEvent(stub, action)
}

func (t *APICC) storeAndEmitUpdateFlowEvent(stub *guaranteePB.ChaincodeStub, action *guaranteePB.GXFlowActionRequest) error {
	createdAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}

	event := &guaranteePB.GXEvent{
		Id:        stub.GetTxID(),
		CreatedAt: createdAt,
		Payload: &guaranteePB.GXEvent_UpdateFlowEvent{
			UpdateFlowEvent: &guaranteePB.UpdateFlowEvent{
				Action: action,
			},
		},
	}

	ccutil.Logger.Debugf("Storing+Emitting UpdateFlow Event %v\n", event)
	ccutil.Logger.Infof("Triggering EVENT <Update Flow> (id: %v)\n", event.Id)

	// Store Event
	err = t.storeGXEvent(stub, event)
	if err != nil {
		return err
	}

	// Emit Event
	err = stub.SetUpdateFlowEvent(event)
	return err
}

func (t *APICC) storeGXEvent(stub *guaranteePB.ChaincodeStub, event *guaranteePB.GXEvent) error {
	eventKey, err := generateGXEventKey(stub, event.GetId())
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, eventKey, event)
	return err
}

func (t *APICC) getPrefix(stub shim.ChaincodeStubInterface) (string, error) {
	prefixKey, err := ccutil.GenerateSystemPropertyKey(stub, guaranteeutil.SPKeyPrefix)
	if err != nil {
		return "", err
	}

	var prefixValue types.StringValue
	err = ccutil.GetStatePB(stub, prefixKey, &prefixValue)
	if err != nil {
		return "", err
	}

	return prefixValue.GetValue(), nil
}

func (t *APICC) getProfileCC(stub shim.ChaincodeStubInterface) (string, error) {
	profileCCKey, err := ccutil.GenerateSystemPropertyKey(stub, guaranteeutil.SPKeyProfileCC)
	if err != nil {
		return "", err
	}

	var profileCCValue types.StringValue
	err = ccutil.GetStatePB(stub, profileCCKey, &profileCCValue)
	if err != nil {
		return "", err
	}

	return profileCCValue.GetValue(), nil
}

func (t *APICC) getPlatformChannel(stub shim.ChaincodeStubInterface) (string, error) {
	platformChannelKey, err := ccutil.GenerateSystemPropertyKey(stub, guaranteeutil.SPKeyPlatformChannel)
	if err != nil {
		return "", err
	}

	var platformChannelValue types.StringValue
	err = ccutil.GetStatePB(stub, platformChannelKey, &platformChannelValue)
	if err != nil {
		return "", err
	}

	return platformChannelValue.GetValue(), nil
}

func (t *APICC) invokeProfileOrganizationGetViaPublicKey(stub shim.ChaincodeStubInterface, publicKeyPEM string) (*profilePB.OrganizationWithPublicKeyInfo, error) {
	publicKeyValueBytes, err := ccutil.Marshal(&profilePB.PublicKeyValue{Value: publicKeyPEM})
	if err != nil {
		return nil, err
	}
	profileCC, err := t.getProfileCC(stub)
	if err != nil {
		return nil, err
	}
	platformChannel, err := t.getPlatformChannel(stub)
	if err != nil {
		return nil, err
	}

	res := stub.InvokeChaincode(profileCC, [][]byte{[]byte(ccutil.CCMethods.Profile.Organization.GetViaPublicKey), publicKeyValueBytes}, platformChannel)
	if res.GetStatus() != shim.OK {
		return nil, errors.New(res.GetMessage())
	}
	var organizationWithPublicKey profilePB.OrganizationWithPublicKeyInfo
	ccutil.Unmarshal(res.GetPayload(), &organizationWithPublicKey)
	return &organizationWithPublicKey, nil
}

func (t *APICC) invokeProfileGetPurposeFormat(stub shim.ChaincodeStubInterface, formatID string) (*sharedPB.PurposeFormat, error) {
	profileCC, err := t.getProfileCC(stub)
	if err != nil {
		return nil, err
	}
	platformChannel, err := t.getPlatformChannel(stub)
	if err != nil {
		return nil, err
	}

	idValueBytes, err := ccutil.Marshal(&sharedPB.IDValue{Value: formatID})
	if err != nil {
		return nil, err
	}

	res := stub.InvokeChaincode(profileCC, [][]byte{[]byte(ccutil.CCMethods.Profile.PurposeFormat.Get), idValueBytes}, platformChannel)
	if res.GetStatus() != shim.OK {
		return nil, errors.New(res.GetMessage())
	}
	var purposeFormat sharedPB.PurposeFormat
	ccutil.Unmarshal(res.GetPayload(), &purposeFormat)
	return &purposeFormat, nil
}

func (t *APICC) invokeProfileTCGet(stub shim.ChaincodeStubInterface, id string) (*profilePB.TermsConditions, error) {
	idValueBytes, err := ccutil.Marshal(&sharedPB.IDValue{Value: id})
	if err != nil {
		return nil, err
	}

	profileCC, err := t.getProfileCC(stub)
	if err != nil {
		return nil, err
	}
	platformChannel, err := t.getPlatformChannel(stub)
	if err != nil {
		return nil, err
	}

	res := stub.InvokeChaincode(profileCC, [][]byte{[]byte(ccutil.CCMethods.Profile.TC.Get), idValueBytes}, platformChannel)
	if res.GetStatus() != shim.OK {
		return nil, errors.New(res.GetMessage())
	}
	var tc profilePB.TermsConditions
	ccutil.Unmarshal(res.GetPayload(), &tc)
	return &tc, nil
}

type creatorInfo struct {
	cert         *x509.Certificate
	organization *profilePB.Organization
	publicKey    *profilePB.OrganizationPublicKey
}

func (t *APICC) createCreatorInfo(stub shim.ChaincodeStubInterface) (creatorInfo, error) {
	creatorCert, err := invoke.GetCreatorCert(stub)
	if err != nil {
		return creatorInfo{}, err
	}
	publicKeyPEM, err := ccutil.GetPublicKeyPEMFromCert(creatorCert)
	if err != nil {
		return creatorInfo{}, err
	}

	organizationWithPublicKey, err := t.invokeProfileOrganizationGetViaPublicKey(stub, publicKeyPEM)
	if err != nil {
		return creatorInfo{}, err
	}

	// TODO extract to creator validation function
	if organizationWithPublicKey.GetOrganization().GetStatus() != profilePB.OrganizationStatus_ORGANIZATION_ACTIVE {
		return creatorInfo{}, errors.New("Organization is not active")
	}

	return creatorInfo{
		cert:         creatorCert,
		organization: organizationWithPublicKey.GetOrganization(),
		publicKey:    organizationWithPublicKey.GetPublicKey(),
	}, nil
}

func generateGXKey(stub shim.ChaincodeStubInterface, gxID string) (string, error) {
	return stub.CreateCompositeKey(guaranteeutil.OTGX, []string{gxID})
}

// generateGXIterator generates an interator over all gx
func generateGXIterator(stub shim.ChaincodeStubInterface) (shim.StateQueryIteratorInterface, error) {
	return stub.GetStateByPartialCompositeKey(guaranteeutil.OTGX, []string{})
}

func generateGXEventKey(stub shim.ChaincodeStubInterface, eventID string) (string, error) {
	return stub.CreateCompositeKey(guaranteeutil.OTGXEvents, []string{eventID})
}

// generateGXEventIterator generates an interator over all gx events
func generateGXEventIterator(stub shim.ChaincodeStubInterface) (shim.StateQueryIteratorInterface, error) {
	return stub.GetStateByPartialCompositeKey(guaranteeutil.OTGXEvents, []string{})
}

func getRequestFromStartRequest(startRequest *guaranteePB.GXStartRequest) (gxRequestMessage, error) {
	switch t := startRequest.GetRequest().(type) {
	case *guaranteePB.GXStartRequest_GxIssueRequest:
		return startRequest.GetGxIssueRequest(), nil
	case *guaranteePB.GXStartRequest_GxAmendRequest:
		return startRequest.GetGxAmendRequest(), nil
	case *guaranteePB.GXStartRequest_GxCancelRequest:
		return startRequest.GetGxCancelRequest(), nil
	case *guaranteePB.GXStartRequest_GxDemandRequest:
		return startRequest.GetGxDemandRequest(), nil
	case *guaranteePB.GXStartRequest_GxPayWalkRequest:
		return startRequest.GetGxPayWalkRequest(), nil
	case *guaranteePB.GXStartRequest_GxTransferRequest:
		return startRequest.GetGxTransferRequest(), nil
	case *guaranteePB.GXStartRequest_GxExpireRequest:
		return startRequest.GetGxExpireRequest(), nil
	default:
		return nil, fmt.Errorf("Invalid Request Type %T", t)
	}
}

func getGXModifyRequestFromStartRequest(startRequest *guaranteePB.GXStartRequest) (gxModifyRequestMessage, error) {
	switch t := startRequest.GetRequest().(type) {
	case *guaranteePB.GXStartRequest_GxAmendRequest:
		return startRequest.GetGxAmendRequest(), nil
	case *guaranteePB.GXStartRequest_GxCancelRequest:
		return startRequest.GetGxCancelRequest(), nil
	case *guaranteePB.GXStartRequest_GxDemandRequest:
		return startRequest.GetGxDemandRequest(), nil
	case *guaranteePB.GXStartRequest_GxPayWalkRequest:
		return startRequest.GetGxPayWalkRequest(), nil
	case *guaranteePB.GXStartRequest_GxTransferRequest:
		return startRequest.GetGxTransferRequest(), nil
	case *guaranteePB.GXStartRequest_GxExpireRequest:
		return startRequest.GetGxExpireRequest(), nil
	default:
		return nil, fmt.Errorf("Invalid Request Type %T", t)
	}
}

func getRequestFromGXFlowActionRequest(gxFlowActionRequest *guaranteePB.GXFlowActionRequest) (ccutil.RequestMessage, error) {
	switch t := gxFlowActionRequest.GetRequest().(type) {
	case *guaranteePB.GXFlowActionRequest_FlowActionRequest:
		return gxFlowActionRequest.GetFlowActionRequest(), nil
	case *guaranteePB.GXFlowActionRequest_RecallRequest:
		return gxFlowActionRequest.GetRecallRequest(), nil
	default:
		return nil, fmt.Errorf("Invalid Request Type %T", t)
	}
}

func getNumberOfUpdates(stub shim.ChaincodeStubInterface, flowID string) (int, error) {
	seqNum := 0
	iterator, err := ccutil.GenerateFlowActionIterator(stub, flowID)
	if err != nil {
		return 0, err
	}
	defer iterator.Close()
	for iterator.HasNext() {
		seqNum++
		_, err = iterator.Next()
		if err != nil {
			return 0, err
		}
	}

	return seqNum, err
}

func getActiveIndex(actions []*guaranteePB.GXFlowActionRequest) int {
	// Look for any recall requests
	i := len(actions) - 1
	for ; i > 0; i-- {
		action := actions[i]
		if _, ok := action.GetRequest().(*guaranteePB.GXFlowActionRequest_RecallRequest); ok {
			break
		}
	}
	if i == -1 {
		i = 0
	}
	return i
}

// countActiveApprovals counts, all approvals after the latest start request or recall
func countActiveApprovals(actions []*guaranteePB.GXFlowActionRequest) (int, error) {
	approvalCount := 0
	actionIDToSeqNumMap, err := generateActionIDToSeqNumMap(actions)
	if err != nil {
		return 0, err
	}
	// only uses actions after latest recall
	for _, action := range actions[getActiveIndex(actions):] {
		if x, ok := action.GetRequest().(*guaranteePB.GXFlowActionRequest_FlowActionRequest); ok {
			flowAction := x.FlowActionRequest
			if flowAction.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE {
				approvalCount++
			} else if flowAction.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_REVOKE && flowAction.GetActionId() != "" {
				seqNum, ok := actionIDToSeqNumMap[flowAction.GetActionId()]
				if !ok {
					return 0, errors.New("Error, invalid seqNum")
				}
				cancelTarget := actions[seqNum]
				if y, ok := cancelTarget.GetRequest().(*guaranteePB.GXFlowActionRequest_FlowActionRequest); ok &&
					y.FlowActionRequest.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE {
					approvalCount--
				}
			}
		}
	}
	return approvalCount, nil
}

// getGXFlowActions gets all actions for a flow
func getGXFlowActions(stub shim.ChaincodeStubInterface, flowID string) ([]*guaranteePB.GXFlowActionRequest, error) {
	var actions []*guaranteePB.GXFlowActionRequest

	iterator, err := ccutil.GenerateFlowActionIterator(stub, flowID)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	for iterator.HasNext() {
		actionKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		actionBytes := actionKV.GetValue()

		var action guaranteePB.GXFlowActionRequest
		err = ccutil.Unmarshal(actionBytes, &action)
		if err != nil {
			return nil, err
		}
		actions = append(actions, &action)
	}

	return actions, nil
}

func filterApprovals(actions []*guaranteePB.GXFlowActionRequest) ([]*sharedPB.FlowActionRequest, error) {
	var approvals []*sharedPB.FlowActionRequest
	for _, action := range actions {
		if x, ok := action.Request.(*guaranteePB.GXFlowActionRequest_FlowActionRequest); ok &&
			x.FlowActionRequest.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE {
			approvals = append(approvals, x.FlowActionRequest)
		}
	}
	return approvals, nil
}

// hasActivePreviouslyCreatedOrApprovedFlow checks whether the creator has previously created or approved a flow
func hasActivePreviouslyCreatedOrApprovedFlow(start ccutil.MetadataInterface, actions []*guaranteePB.GXFlowActionRequest, creatorOrganizationID string) (bool, error) {
	if start.GetCreatedBy() == creatorOrganizationID {
		return true, nil
	}

	return hasActivePreviouslyApprovedFlow(actions, creatorOrganizationID)
}

// hasActivePreviouslyApprovedFlow checks whether the creator has previously approved a flow
func hasActivePreviouslyApprovedFlow(actions []*guaranteePB.GXFlowActionRequest, creatorOrganizationID string) (bool, error) {
	actionIDToSeqNumMap, err := generateActionIDToSeqNumMap(actions)
	if err != nil {
		return false, err
	}
	approvalCount := 0
	for _, action := range actions[getActiveIndex(actions):] {
		if x, ok := action.GetRequest().(*guaranteePB.GXFlowActionRequest_FlowActionRequest); ok {
			flowAction := x.FlowActionRequest

			if flowAction.GetCreatedBy() == creatorOrganizationID {
				if flowAction.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE {
					approvalCount++
				} else if flowAction.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_REVOKE && flowAction.GetActionId() != "" {
					seqNum, ok := actionIDToSeqNumMap[flowAction.GetActionId()]
					if !ok {
						return false, errors.New("Error, invalid seqNum")
					}
					cancelTarget := actions[seqNum]
					if y, ok := cancelTarget.GetRequest().(*guaranteePB.GXFlowActionRequest_FlowActionRequest); ok &&
						y.FlowActionRequest.GetCreatedBy() == creatorOrganizationID &&
						y.FlowActionRequest.GetRequestType() == sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE {
						approvalCount--
					}
				}
			}
		}
	}

	return approvalCount > 0, nil
}

// setGXID sets the GxId of a request object
func setGXID(obj gxModifyRequestMessage, gxID string) {
	objElem := reflect.ValueOf(obj).Elem()
	objElem.FieldByName("GxId").SetString(gxID)
}

// setStatus sets the id of a request object
func setStatus(obj gxRequestInterface, status sharedPB.FlowStatus) {
	objElem := reflect.ValueOf(obj).Elem()
	objElem.FieldByName("Status").Set(reflect.ValueOf(status))
}

func validateGxDemand(gx *guaranteePB.GX, request *guaranteePB.GXDemandRequest) error {
	if request.GetAmount() <= 0 {
		return errors.New("Demand amount must be positive")
	}
	if request.GetAmount() > gx.GetAmount().GetOutstanding() {
		return fmt.Errorf("Demand amount %d demand amount exceeds gx amount outstanding %d", request.GetAmount(), gx.GetAmount().GetOutstanding())
	}
	return nil
}

func isIssuer(stub shim.ChaincodeStubInterface, cInfo *creatorInfo) (bool, error) {
	isConsortium, err := ccutil.IsConsortium(stub, cInfo.cert)
	if err != nil {
		return false, err
	}
	return !isConsortium, nil
}

func getRequestType(flow *guaranteePB.GXStartRequest) (guaranteePB.GXRequestType, error) {
	switch flow.GetRequest().(type) {
	case *guaranteePB.GXStartRequest_GxIssueRequest:
		return guaranteePB.GXRequestType_GX_REQUEST_TYPE_ISSUE, nil
	case *guaranteePB.GXStartRequest_GxAmendRequest:
		return guaranteePB.GXRequestType_GX_REQUEST_TYPE_AMEND, nil
	case *guaranteePB.GXStartRequest_GxCancelRequest:
		return guaranteePB.GXRequestType_GX_REQUEST_TYPE_CANCEL, nil
	case *guaranteePB.GXStartRequest_GxDemandRequest:
		return guaranteePB.GXRequestType_GX_REQUEST_TYPE_DEMAND, nil
	case *guaranteePB.GXStartRequest_GxPayWalkRequest:
		return guaranteePB.GXRequestType_GX_REQUEST_TYPE_PAY_WALK, nil
	case *guaranteePB.GXStartRequest_GxTransferRequest:
		return guaranteePB.GXRequestType_GX_REQUEST_TYPE_TRANSFER, nil
	case *guaranteePB.GXStartRequest_GxExpireRequest:
		return guaranteePB.GXRequestType_GX_REQUEST_TYPE_EXPIRE, nil
	}
	return guaranteePB.GXRequestType_GX_REQUEST_TYPE_ISSUE, errors.New("Unknown GX request type")
}

func requestTypeHasFlag(requestType guaranteePB.GXRequestType) bool {
	return (requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_AMEND ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_CANCEL ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_DEMAND ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_TRANSFER)
}

func isBeneficiary(gx *guaranteePB.GX, cInfo *creatorInfo) bool {
	return ccutil.ContainsString(gx.GetBeneficiaries(), cInfo.organization.GetId())
}

func (t *APICC) updateGXSetActiveRequestFlag(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest) error {
	return t.updateGXActiveRequestFlagHelper(stub, startRequest, true)
}

func (t *APICC) updateGXClearActiveRequestFlag(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest) error {
	return t.updateGXActiveRequestFlagHelper(stub, startRequest, false)
}

func (t *APICC) updateGXActiveRequestFlagHelper(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, set bool) error {
	requestType, err := getRequestType(startRequest)
	if err != nil {
		return err
	}

	// Do nothing if is not a multistep request on an existing guarantee
	if !(requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_AMEND ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_CANCEL ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_DEMAND ||
		requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_TRANSFER) {
		return nil
	}

	startBaseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		return err
	}

	gx, err := get(stub, startBaseRequest.GetGxId())
	if err != nil {
		return err
	}

	activeFlowsMask := ccutil.Bitmask(gx.GetActiveFlows())

	flag, err := t.getActiveRequestFlag(startRequest)
	if err != nil {
		return err
	}

	if set {
		activeFlowsMask.Set(flag)
	} else {
		activeFlowsMask.Clear(flag)
	}

	gx.ActiveFlows = uint32(activeFlowsMask)

	// Add Guarantee metadata
	timestamp, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}
	gx.UpdatedAt = timestamp

	// Put Guarantee into state
	gxKey, err := generateGXKey(stub, gx.GetId())
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, gxKey, gx)
	return err
}

func (t *APICC) getActiveRequestFlag(startRequest *guaranteePB.GXStartRequest) (ccutil.Bitmask, error) {
	var flag ccutil.Bitmask
	// handle setting updating activeRequest bitmask
	switch startRequest.Request.(type) {
	case *guaranteePB.GXStartRequest_GxAmendRequest:
		flag = guaranteeutil.AFAmend
	case *guaranteePB.GXStartRequest_GxCancelRequest:
		flag = guaranteeutil.AFCancel
	case *guaranteePB.GXStartRequest_GxDemandRequest:
		flag = guaranteeutil.AFDemand
	case *guaranteePB.GXStartRequest_GxTransferRequest:
		flag = guaranteeutil.AFTransfer
	default:
		return guaranteeutil.AFAmend, errors.New("Could not convert request to flag")
	}
	return flag, nil
}

func (t *APICC) generateGXIDFromFlowID(stub shim.ChaincodeStubInterface, flowID string) (string, error) {
	prefix, err := t.getPrefix(stub)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("%s%s", prefix, flowID), nil
}

func generateActionIDToSeqNumMap(actions []*guaranteePB.GXFlowActionRequest) (map[string]int, error) {
	actionIDToSeqNumMap := make(map[string]int)
	for i, action := range actions {
		var actionID string
		switch action.Request.(type) {
		case *guaranteePB.GXFlowActionRequest_FlowActionRequest:
			flowAction := action.GetFlowActionRequest()
			actionID = flowAction.GetId()
		case *guaranteePB.GXFlowActionRequest_RecallRequest:
			recallAction := action.GetRecallRequest()
			actionID = recallAction.GetId()
		default:
			return nil, errors.New("Unknown action type")
		}

		actionIDToSeqNumMap[actionID] = i
	}

	return actionIDToSeqNumMap, nil
}

func isGXExpired(stub shim.ChaincodeStubInterface, gx *guaranteePB.GX) (bool, error) {
	if gx.GetStatus() == guaranteePB.GXStatus_GX_EXPIRED {
		return true, nil
	} else if gx.GetStatus() == guaranteePB.GXStatus_GX_ACTIVE && gx.GetExpiresAt() != nil {
		gxExpiresAt, err := types.TimestampFromProto(gx.GetExpiresAt())
		if err != nil {
			return false, err
		}
		txTimestamp, err := ccutil.GetTxTimestamp(stub)
		if err != nil {
			return false, err
		}
		txTime, err := types.TimestampFromProto(txTimestamp)
		if err != nil {
			return false, err
		}

		activeFlowsBitmask := ccutil.Bitmask(gx.GetActiveFlows())
		if txTime.After(gxExpiresAt) && !activeFlowsBitmask.Has(guaranteeutil.AFDemand) {
			return true, nil
		}
	}
	return false, nil
}

func isGXActive(stub shim.ChaincodeStubInterface, gx *guaranteePB.GX) (bool, error) {
	if gx.GetStatus() != guaranteePB.GXStatus_GX_ACTIVE {
		return false, nil
	}
	isExpired, err := isGXExpired(stub, gx)
	return !isExpired, err
}
