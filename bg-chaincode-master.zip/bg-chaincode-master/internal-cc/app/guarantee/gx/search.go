package gx

import (
	"sort"
	"strings"
	"time"

	"github.com/gogo/protobuf/types"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// Search searchs guarantees and returns a subset
func (t *APICC) Search(stub *guaranteePB.ChaincodeStub, request *guaranteePB.GXSearchRequest) (*guaranteePB.GXSearchResponse, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Searching Guarantees, using search request: %v\n", request)

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}

	var gxs []*guaranteePB.GX
	if info.organization.GetEntityType() == profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY {
		gxs, err = t.getAllWithOrgID(stub, info.organization.GetId())
		if err != nil {
			return nil, err
		}
	} else {
		gxs, err = t.getAll(stub)
		if err != nil {
			return nil, err
		}
	}

	if request.GetLimit() == 0 {
		request.Limit = 50
	}

	err = t.gxSort(gxs, request)
	if err != nil {
		return nil, err
	}

	paginationResult, err := t.gxSearchFilter(stub, gxs, request, &info)
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return &guaranteePB.GXSearchResponse{Gxs: paginationResult.gxs, Next: paginationResult.next}, nil
}

func (t *APICC) getAll(stub *guaranteePB.ChaincodeStub) ([]*guaranteePB.GX, error) {
	iterator, err := generateGXIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var gxs []*guaranteePB.GX

	for iterator.HasNext() {
		gxKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		gxBytes := gxKV.GetValue()

		var gx guaranteePB.GX
		err = ccutil.Unmarshal(gxBytes, &gx)
		if err != nil {
			return nil, err
		}

		gxs = append(gxs, &gx)
	}

	return gxs, nil
}

func (t *APICC) getAllWithOrgID(stub *guaranteePB.ChaincodeStub, orgID string) ([]*guaranteePB.GX, error) {
	gxs, err := t.getAll(stub)
	if err != nil {
		return nil, err
	}

	filteredGxs := make([]*guaranteePB.GX, 0)
	for _, gx := range gxs {
		orgIDs := append(gx.GetApplicants(), gx.GetBeneficiaries()...)
		if ccutil.ContainsString(orgIDs, orgID) {
			filteredGxs = append(filteredGxs, gx)
		}
	}
	return filteredGxs, nil
}

// TODO replace with couch queries
func (t *APICC) gxSort(gxs []*guaranteePB.GX, searchRequest *guaranteePB.GXSearchRequest) error {
	if searchRequest.GetOrderBy() == nil {
		return nil
	}
	orderBy := searchRequest.GetOrderBy().GetValue()
	order := searchRequest.GetOrder()

	switch orderBy {
	case guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_ISSUED_AT:
		switch order {
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_ASC:
			sort.Slice(gxs, func(i, j int) bool {
				gxIssuedAt1, err := types.TimestampFromProto(gxs[i].GetIssuedAt())
				if err != nil {
					return false
				}
				gxIssuedAt2, err := types.TimestampFromProto(gxs[j].GetIssuedAt())
				if err != nil {
					return true
				}
				return gxIssuedAt1.Before(gxIssuedAt2)
			})
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_DESC:
			sort.Slice(gxs, func(i, j int) bool {
				gxIssuedAt1, err := types.TimestampFromProto(gxs[i].GetIssuedAt())
				if err != nil {
					return true
				}
				gxIssuedAt2, err := types.TimestampFromProto(gxs[j].GetIssuedAt())
				if err != nil {
					return false
				}
				return gxIssuedAt1.After(gxIssuedAt2)
			})
		default:
			// Do nothing
		}
	case guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_EXPIRED_AT:
		switch order {
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_ASC:
			sort.Slice(gxs, func(i, j int) bool {
				gxExpires1, err := types.TimestampFromProto(gxs[i].GetExpiresAt())
				if err != nil {
					return false
				}
				gxExpires2, err := types.TimestampFromProto(gxs[j].GetExpiresAt())
				if err != nil {
					return true
				}
				return gxExpires1.Before(gxExpires2)
			})
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_DESC:
			sort.Slice(gxs, func(i, j int) bool {
				gxExpires1, err := types.TimestampFromProto(gxs[i].GetExpiresAt())
				if err != nil {
					return true
				}
				gxExpires2, err := types.TimestampFromProto(gxs[j].GetExpiresAt())
				if err != nil {
					return false
				}
				return gxExpires1.After(gxExpires2)
			})
		default:
			// Do nothing
		}

	case guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_AMOUNT:
		switch order {
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_ASC:
			sort.Slice(gxs, func(i, j int) bool {
				return gxs[i].GetAmount().GetOutstanding() < gxs[j].GetAmount().GetOutstanding()
			})
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_DESC:
			sort.Slice(gxs, func(i, j int) bool {
				return gxs[i].GetAmount().GetOutstanding() > gxs[j].GetAmount().GetOutstanding()
			})
		default:
			// Do nothing
		}
	case guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_APPLICANT:
		switch order {
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_ASC:
			sort.Slice(gxs, func(i, j int) bool {
				return gxs[i].GetApplicants()[0] < gxs[j].GetApplicants()[0]
			})
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_DESC:
			sort.Slice(gxs, func(i, j int) bool {
				return gxs[i].GetApplicants()[0] > gxs[j].GetApplicants()[0]
			})
		default:
			// Do nothing
		}
	case guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_BENEFICIARY:
		switch order {
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_ASC:
			sort.Slice(gxs, func(i, j int) bool {
				return gxs[i].GetBeneficiaries()[0] < gxs[j].GetBeneficiaries()[0]
			})
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_DESC:
			sort.Slice(gxs, func(i, j int) bool {
				return gxs[i].GetBeneficiaries()[0] > gxs[j].GetBeneficiaries()[0]
			})
		}
	case guaranteePB.GXSearchOrderBy_GX_SEARCH_ORDER_BY_STATUS:
		switch order {
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_ASC:
			sort.Slice(gxs, func(i, j int) bool {
				return gxs[i].GetStatus().String() < gxs[j].GetStatus().String()
			})
		case guaranteePB.GXSearchOrder_GX_SEARCH_ORDER_DESC:
			sort.Slice(gxs, func(i, j int) bool {
				return gxs[i].GetStatus().String() > gxs[j].GetStatus().String()
			})
		default:
			// Do nothing
		}
	}

	return nil
}

func (t *APICC) gxSearchFilter(stub *guaranteePB.ChaincodeStub, gxs []*guaranteePB.GX, searchRequest *guaranteePB.GXSearchRequest, cInfo *creatorInfo) (*gxPaginationResult, error) {
	var filteredGXs []*guaranteePB.GX
	hasMore := true
	limit := int(searchRequest.GetLimit())
	var next = ""

	for hasMore && len(filteredGXs) < limit {
		couchResult, err := t.gxCouchFilter(gxs, searchRequest)
		if err != nil {
			return nil, err
		}

		if couchResult.next == "" {
			hasMore = false
		}

		timeKeyFilteredGXs, err := t.gxTimebasedKeyFilter(stub, couchResult.gxs, cInfo)
		if err != nil {
			return nil, err
		}

		filteredGXs = append(filteredGXs, timeKeyFilteredGXs...)

		if len(filteredGXs) > limit {
			next = filteredGXs[limit].GetId()
			filteredGXs = filteredGXs[0:limit]
		} else {
			next = couchResult.next
		}

		searchRequest.Start = next
	}

	return &gxPaginationResult{
		gxs:  filteredGXs,
		next: next,
	}, nil
}

// gxPaginationResult is the result of couchbased pagination
type gxPaginationResult struct {
	gxs  []*guaranteePB.GX
	next string
}

// TODO replace with couch queries
func (t *APICC) gxCouchFilter(gxs []*guaranteePB.GX, searchRequest *guaranteePB.GXSearchRequest) (*gxPaginationResult, error) {
	filteredGXs := make([]*guaranteePB.GX, 0)
	limit := int(searchRequest.GetLimit())
	var next string

	foundStart := false
	for _, gx := range gxs {

		// skip till start ID if specified
		if searchRequest.GetStart() != "" && !foundStart {
			if gx.GetId() == searchRequest.GetStart() {
				foundStart = true
			} else {
				continue
			}
		}

		if next != "" {
			break
		}

		var gxIssuedAt time.Time
		var searchIssuedAfter time.Time
		var searchIssuedBefore time.Time
		var gxExpiresAt time.Time
		var searchExpiredAfter time.Time
		var searchExpiredBefore time.Time
		var err error

		gxIssuedAt, err = types.TimestampFromProto(gx.GetIssuedAt())
		if err != nil {
			return nil, err
		}

		if searchRequest.GetIssuedAfter() != nil {
			searchIssuedAfter, err = types.TimestampFromProto(searchRequest.GetIssuedAfter())
			if err != nil {
				return nil, err
			}
		}

		if searchRequest.GetIssuedBefore() != nil {
			searchIssuedBefore, err = types.TimestampFromProto(searchRequest.GetIssuedBefore())
			if err != nil {
				return nil, err
			}
		}

		if gx.GetExpiresAt() != nil {

			gxExpiresAt, err = types.TimestampFromProto(gx.GetExpiresAt())
			if err != nil {
				return nil, err
			}
		}

		if searchRequest.GetExpiredAfter() != nil {
			searchExpiredAfter, err = types.TimestampFromProto(searchRequest.GetExpiredAfter())
			if err != nil {
				return nil, err
			}
		}

		if searchRequest.GetExpiredBefore() != nil {
			searchExpiredBefore, err = types.TimestampFromProto(searchRequest.GetExpiredBefore())
			if err != nil {
				return nil, err
			}
		}

		if (searchRequest.GetStatus() == nil || gx.GetStatus() == searchRequest.GetStatus().GetValue()) &&
			(searchRequest.GetOrgId() == "" || ccutil.ContainsString(append(gx.GetApplicants(), gx.GetBeneficiaries()...), searchRequest.GetOrgId())) &&
			(searchRequest.GetApplicantId() == "" || ccutil.ContainsString(gx.GetApplicants(), searchRequest.GetApplicantId())) &&
			(searchRequest.GetBeneficiaryId() == "" || ccutil.ContainsString(gx.GetBeneficiaries(), searchRequest.GetBeneficiaryId())) &&
			(searchRequest.GetIssuedAfter() == nil || gxIssuedAt.After(searchIssuedAfter)) &&
			(searchRequest.GetIssuedBefore() == nil || gxIssuedAt.Before(searchIssuedBefore)) &&
			(searchRequest.GetExpiredAfter() == nil || gx.GetExpiresAt() == nil || gxExpiresAt.After(searchExpiredAfter)) &&
			(searchRequest.GetExpiredBefore() == nil || (gx.GetExpiresAt() != nil && gxExpiresAt.Before(searchExpiredBefore))) &&
			(searchRequest.GetAmountGreaterThan() == 0 || gx.GetAmount().GetOutstanding() >= searchRequest.GetAmountGreaterThan()) &&
			(searchRequest.GetAmountSmallerThan() == 0 || gx.GetAmount().GetOutstanding() <= searchRequest.GetAmountSmallerThan()) &&
			(searchRequest.GetPurposeType() == "" || gx.GetPurposeType() == searchRequest.GetPurposeType()) &&
			(searchRequest.GetPurpose() == nil || t.validateSearchFilterPurpose(gx.GetPurpose(), searchRequest.GetPurpose())) {

			if len(filteredGXs) < limit {
				filteredGXs = append(filteredGXs, gx)
			} else {
				next = gx.GetId()
			}
		}
	}

	return &gxPaginationResult{
		gxs:  filteredGXs,
		next: next,
	}, nil
}

func (t *APICC) gxTimebasedKeyFilter(stub *guaranteePB.ChaincodeStub, gxs []*guaranteePB.GX, cInfo *creatorInfo) ([]*guaranteePB.GX, error) {
	filteredGxs := make([]*guaranteePB.GX, 0)
	for _, gx := range gxs {
		hasAccessToGx, err := hasAccessToGx(stub, gx, cInfo)
		if err != nil {
			return nil, err
		}

		if hasAccessToGx {
			filteredGxs = append(filteredGxs, gx)
		}
	}

	return filteredGxs, nil
}

func (t *APICC) validateSearchFilterPurpose(gxPurpose map[string]*guaranteePB.GxPurposeElement, searchPurpose map[string]*guaranteePB.GxPurposeElement) bool {
	for k, v := range searchPurpose {
		if gxPurpose[k] != nil {
			var match bool
			switch searchPurpose[k].GetElementType() {
			case guaranteePB.GxPurposeElementType_INT:
				match = v.GetIntValue().GetValue() == gxPurpose[k].GetIntValue().GetValue()
			case guaranteePB.GxPurposeElementType_DOUBLE:
				match = v.GetDoubleValue().GetValue() == gxPurpose[k].GetDoubleValue().GetValue()
			case guaranteePB.GxPurposeElementType_BOOL:
				match = v.GetBoolValue().GetValue() == gxPurpose[k].GetBoolValue().GetValue()
			case guaranteePB.GxPurposeElementType_STRING:
				match = v.GetStringValue().GetValue() == gxPurpose[k].GetStringValue().GetValue()
			case guaranteePB.GxPurposeElementType_MAP:
				match = t.validateSearchFilterPurpose(gxPurpose[k].GetMapValue(), v.GetMapValue())
			}

			if match == false {
				return false
			}

		} else {
			return false
		}
	}

	return true
}

func quoteContains(source string, target string) bool {
	if len(target) > 2 && target[0] == '"' && target[len(target)-1] == '"' {
		return source == target[1:len(target)-1]
	}
	return strings.Contains(source, target)
}
