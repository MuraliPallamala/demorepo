package gx

import "testing"

func TestGetFlow(t *testing.T) {
	// Happy path for GetFlow is fully tested in TestStartFlowIssue
	TestStartFlowIssue(t)
}
