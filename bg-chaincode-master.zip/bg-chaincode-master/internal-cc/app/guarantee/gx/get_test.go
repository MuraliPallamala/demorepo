package gx

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profiletest"
)

func TestGet(t *testing.T) {
	stub, _ := setup(t)

	// Setup guarantee
	initGX := generateExampleBasicGX()
	storedGX := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})

	// check stored gx
	gx := invokeGet(t, stub, cctest.GenerateMockTxID(""), &sharedPB.IDValue{Value: storedGX.GetId()})

	if gx.GetId() != storedGX.GetId() {
		t.Fatalf("Error incorrect GX ID. Expected %s, but got %s", storedGX.GetId(), gx.GetId())
	}
}

func TestGetWithParentSub(t *testing.T) {
	stub, profileStub := setup(t)

	numActive := 5
	numFinshedBefore := 6
	numFinishedAfter := 7

	activeIds := make([]string, 0)
	finishedBeforeIds := make([]string, 0)
	finishedAfterIds := make([]string, 0)

	subOrgPem := cctest.AppBenPEM1
	parentOrgPEM := cctest.AppBenPEM4

	// Setup active guarantees guarantee
	for i := 0; i < numActive; i++ {
		gx := generateExampleBasicGX()

		cctest.SetMockStubCert(t, stub, subOrgPem)
		storedGx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx})
		activeIds = append(activeIds, storedGx.GetId())
	}

	// Setup Finished before
	for i := 0; i < numFinshedBefore; i++ {
		gx := generateExampleBasicGX()

		cctest.SetMockStubCert(t, stub, subOrgPem)
		storedGx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx})
		finishedBeforeIds = append(finishedBeforeIds, storedGx.GetId())
		// Perform Pay Walk to close guarantees
		cctest.SetMockStubCert(t, stub, issuerOrgPEM)
		invokeStartFlowPayWalk(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXPayWalkRequest{GxId: storedGx.GetId()})
	}

	// link orgs
	cctest.SetMockStubCert(t, profileStub, subOrgPem)
	parentOrgKey, err := ccutil.GetPublicKeyPEMFromCertPEM(parentOrgPEM)
	if err != nil {
		t.Fatalf(err.Error())
	}
	activateKeyRequestBytes := profiletest.GenerateActivateKeyRequestBytes(t, parentOrgKey)
	args := [][]byte{[]byte(ccutil.CCMethods.Profile.Organization.ActivateKey), activateKeyRequestBytes}
	res := profileStub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to activate key: %s", string(res.Message))
	}

	// Setup finished after
	for i := 0; i < numFinishedAfter; i++ {
		gx := generateExampleBasicGX()

		cctest.SetMockStubCert(t, stub, subOrgPem)
		storedGx := setupGuarantee(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &gx})
		finishedAfterIds = append(finishedAfterIds, storedGx.GetId())
		// Perform Pay Walk to close guarantees
		cctest.SetMockStubCert(t, stub, issuerOrgPEM)
		invokeStartFlowPayWalk(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXPayWalkRequest{GxId: storedGx.GetId()})
	}

	// check expected guarantees that are active or created after linking can be retrieved
	cctest.SetMockStubCert(t, stub, parentOrgPEM)
	for _, gxID := range append(activeIds, finishedAfterIds...) {
		gx := invokeGet(t, stub, cctest.GenerateMockTxID(""), &sharedPB.IDValue{Value: gxID})

		if gx.GetId() != gxID {
			t.Fatalf("Error incorrect GX ID. Expected %s, but got %s", gxID, gx.GetId())
		}
	}

	// check guarantees that were completed before linking can't be retrieved
	for _, gxID := range finishedBeforeIds {
		invokeGetExpectFailure(t, stub, cctest.GenerateMockTxID(""), &sharedPB.IDValue{Value: gxID})
	}
}
