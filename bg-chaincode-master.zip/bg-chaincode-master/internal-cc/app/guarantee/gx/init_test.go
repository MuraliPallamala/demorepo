package gx

import (
	"fmt"
	"testing"

	"github.com/gogo/protobuf/types"
	"github.com/stretchr/testify/assert"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

// TODO remove this file once migration is complete
var migrationPurposeType = "abc1234"

func TestGxMigration(t *testing.T) {
	stub, _ := setup(t)

	// Add a legacy GX
	legacyGx := guaranteePB.LegacyGX{
		Id:            "guarantee1",
		Type:          guaranteePB.GXType_GX_COMMERCIAL_LEASE,
		Applicants:    []string{"applicant1"},
		Beneficiaries: []string{"beneficiary1"},
		Status:        guaranteePB.GXStatus_GX_ACTIVE,
		Amount:        &guaranteePB.GXAmount{Outstanding: 1234},
		BankReference: "abc1234",
		ExpiresAt:     &types.Timestamp{Nanos: 1, Seconds: 1},
		Purpose: &guaranteePB.LegacyGX_GxRentalPurpose{GxRentalPurpose: &guaranteePB.GXRentalPurpose{
			PropertyName: "example propertyName",
			ShopNumber:   "example shopNumber",
			FreeFormText: "example freeFormText",
			Address: &sharedPB.Address{
				StreetAddress:       "example street address",
				AddressLocality:     "example address locality",
				AddressRegion:       "example address region",
				AddressCountry:      "example address country",
				PostalCode:          "example postal code",
				PostOfficeBoxNumber: "example post office box number",
			},
		}},
		PrevGxId:    "prev gx id",
		ActiveFlows: 3150,
		TcId:        "example tc id",
		IssuedAt:    &types.Timestamp{Nanos: 2, Seconds: 1},
		UpdatedAt:   &types.Timestamp{Nanos: 3, Seconds: 1},
	}

	addLegacyGx(t, stub, legacyGx, cctest.GenerateMockTxID(""))

	// Migrate
	testCCInit(t, stub)

	// check stored gx
	gx := invokeGet(t, stub, cctest.GenerateMockTxID(""), &sharedPB.IDValue{Value: legacyGx.GetId()})

	validateGx(t, gx, &legacyGx)
}

func TestAmendRequestMigration(t *testing.T) {
	stub, _ := setup(t)

	// Add a legacy GX
	legAmend := guaranteePB.LegacyGXAmendRequest{
		Id:                 "amend1",
		GxId:               "gx Id 1",
		Amount:             10,
		ExpiresAt:          &types.Timestamp{Nanos: 1, Seconds: 1},
		ExpiresAtOpenEnded: true,
		OrgIds:             []string{"applicant1"},
		Status:             sharedPB.FlowStatus_FLOW_ACTIVE,
		CreatedAt:          &types.Timestamp{Nanos: 2, Seconds: 1},
		CreatedBy:          "createdBy123",
		UpdatedAt:          &types.Timestamp{Nanos: 3, Seconds: 1},
		UpdatedBy:          "updatedBy123",
		Purpose: &guaranteePB.LegacyGXAmendRequest_GxRentalPurpose{
			GxRentalPurpose: &guaranteePB.GXAmendRentalPurpose{
				PropertyName: &types.StringValue{Value: "example propertyName"},
				ShopNumber:   &types.StringValue{Value: "example shopNumber"},
				FreeFormText: &types.StringValue{Value: "example freeFormText"},
				Address: &guaranteePB.GXAmendAddress{
					StreetAddress:       &types.StringValue{Value: "example street address"},
					AddressLocality:     &types.StringValue{Value: "example address locality"},
					AddressRegion:       &types.StringValue{Value: "example address region"},
					AddressCountry:      &types.StringValue{Value: "example address country"},
					PostalCode:          &types.StringValue{Value: "example postal code"},
					PostOfficeBoxNumber: &types.StringValue{Value: "example post office box number"},
				},
			},
		},
	}

	legStartRequestAmend := guaranteePB.LegacyGXStartRequest{
		Request: &guaranteePB.LegacyGXStartRequest_GxAmendRequest{
			GxAmendRequest: &legAmend,
		},
	}

	addLegacyGxStartRequest(t, stub, &legStartRequestAmend, cctest.GenerateMockTxID(""))

	// Migrate
	testCCInit(t, stub)

	// check stored gx
	startRequestAmend := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: legAmend.GetId()})
	amend := startRequestAmend.GetGxAmendRequest()

	// Check unchanged fields
	assert.Equal(t, amend.Id, legAmend.Id)
	assert.Equal(t, amend.GxId, legAmend.GxId)
	assert.Equal(t, amend.Amount, legAmend.Amount)
	assert.Equal(t, amend.ExpiresAt, legAmend.ExpiresAt)
	assert.Equal(t, amend.ExpiresAtOpenEnded, legAmend.ExpiresAtOpenEnded)
	assert.Equal(t, amend.OrgIds, legAmend.OrgIds)
	assert.Equal(t, amend.Status, legAmend.Status)
	assert.Equal(t, amend.CreatedAt, legAmend.CreatedAt)
	assert.Equal(t, amend.CreatedBy, legAmend.CreatedBy)
	assert.Equal(t, amend.UpdatedAt, legAmend.UpdatedAt)
	assert.Equal(t, amend.UpdatedBy, legAmend.UpdatedBy)

	// Check purpose
	legPurpose := legAmend.GetGxRentalPurpose()
	assert.Equal(t, amend.Purpose["propertyDetails"].ElementType, guaranteePB.GxPurposeElementType_MAP)
	assert.Equal(t, amend.Purpose["propertyDetails"].MapValue["propertyName"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["propertyDetails"].MapValue["propertyName"].StringValue.Value, legPurpose.PropertyName.Value)
	assert.Equal(t, amend.Purpose["propertyDetails"].MapValue["shopNumber"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["propertyDetails"].MapValue["shopNumber"].StringValue.Value, legPurpose.ShopNumber.Value)
	assert.Equal(t, amend.Purpose["propertyAddress"].ElementType, guaranteePB.GxPurposeElementType_MAP)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressStreet"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressStreet"].StringValue.Value, legPurpose.Address.StreetAddress.Value)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressSuburb"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressSuburb"].StringValue.Value, legPurpose.Address.AddressLocality.Value)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressPostcode"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressPostcode"].StringValue.Value, legPurpose.Address.PostalCode.Value)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressCountry"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressCountry"].StringValue.Value, legPurpose.Address.AddressCountry.Value)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressState"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressState"].StringValue.Value, legPurpose.Address.AddressRegion.Value)
	assert.Equal(t, amend.Purpose["purpose"].ElementType, guaranteePB.GxPurposeElementType_MAP)
	assert.Equal(t, amend.Purpose["purpose"].MapValue["comment"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["purpose"].MapValue["comment"].StringValue.Value, legPurpose.FreeFormText.Value)
}

func TestAmendEmptyFieldsRequestMigration1(t *testing.T) {
	stub, _ := setup(t)

	// Add a legacy GX
	legAmend := guaranteePB.LegacyGXAmendRequest{
		Id:                 "amend1",
		GxId:               "gx Id 1",
		Amount:             10,
		ExpiresAt:          &types.Timestamp{Nanos: 1, Seconds: 1},
		ExpiresAtOpenEnded: true,
		OrgIds:             []string{"applicant1"},
		Status:             sharedPB.FlowStatus_FLOW_ACTIVE,
		CreatedAt:          &types.Timestamp{Nanos: 2, Seconds: 1},
		CreatedBy:          "createdBy123",
		UpdatedAt:          &types.Timestamp{Nanos: 3, Seconds: 1},
		UpdatedBy:          "updatedBy123",
		Purpose: &guaranteePB.LegacyGXAmendRequest_GxRentalPurpose{
			GxRentalPurpose: &guaranteePB.GXAmendRentalPurpose{
				Address: &guaranteePB.GXAmendAddress{
					StreetAddress: &types.StringValue{Value: "example street address"},
				},
			},
		},
	}

	legStartRequestAmend := guaranteePB.LegacyGXStartRequest{
		Request: &guaranteePB.LegacyGXStartRequest_GxAmendRequest{
			GxAmendRequest: &legAmend,
		},
	}

	addLegacyGxStartRequest(t, stub, &legStartRequestAmend, cctest.GenerateMockTxID(""))

	// Migrate
	testCCInit(t, stub)

	// check stored gx
	startRequestAmend := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: legAmend.GetId()})
	amend := startRequestAmend.GetGxAmendRequest()

	// Check unchanged fields
	assert.Equal(t, amend.Id, legAmend.Id)
	assert.Equal(t, amend.GxId, legAmend.GxId)
	assert.Equal(t, amend.Amount, legAmend.Amount)
	assert.Equal(t, amend.ExpiresAt, legAmend.ExpiresAt)
	assert.Equal(t, amend.ExpiresAtOpenEnded, legAmend.ExpiresAtOpenEnded)
	assert.Equal(t, amend.OrgIds, legAmend.OrgIds)
	assert.Equal(t, amend.Status, legAmend.Status)
	assert.Equal(t, amend.CreatedAt, legAmend.CreatedAt)
	assert.Equal(t, amend.CreatedBy, legAmend.CreatedBy)
	assert.Equal(t, amend.UpdatedAt, legAmend.UpdatedAt)
	assert.Equal(t, amend.UpdatedBy, legAmend.UpdatedBy)

	// Check purpose
	legPurpose := legAmend.GetGxRentalPurpose()
	assert.Nil(t, amend.Purpose["propertyDetails"])
	assert.Equal(t, amend.Purpose["propertyAddress"].ElementType, guaranteePB.GxPurposeElementType_MAP)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressStreet"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["propertyAddress"].MapValue["addressStreet"].StringValue.Value, legPurpose.Address.StreetAddress.Value)
	assert.Nil(t, amend.Purpose["propertyAddress"].MapValue["addressSuburb"])
	assert.Nil(t, amend.Purpose["propertyAddress"].MapValue["addressPostcode"])
	assert.Nil(t, amend.Purpose["propertyAddress"].MapValue["addressCountry"])
	assert.Nil(t, amend.Purpose["propertyAddress"].MapValue["addressState"])
	assert.Nil(t, amend.Purpose["purpose"])
}

func TestAmendEmptyFieldsRequestMigration2(t *testing.T) {
	stub, _ := setup(t)

	// Add a legacy GX
	legAmend := guaranteePB.LegacyGXAmendRequest{
		Id:                 "amend1",
		GxId:               "gx Id 1",
		Amount:             10,
		ExpiresAt:          &types.Timestamp{Nanos: 1, Seconds: 1},
		ExpiresAtOpenEnded: true,
		OrgIds:             []string{"applicant1"},
		Status:             sharedPB.FlowStatus_FLOW_ACTIVE,
		CreatedAt:          &types.Timestamp{Nanos: 2, Seconds: 1},
		CreatedBy:          "createdBy123",
		UpdatedAt:          &types.Timestamp{Nanos: 3, Seconds: 1},
		UpdatedBy:          "updatedBy123",
		Purpose: &guaranteePB.LegacyGXAmendRequest_GxRentalPurpose{
			GxRentalPurpose: &guaranteePB.GXAmendRentalPurpose{
				FreeFormText: &types.StringValue{Value: "example freeFormText"},
			},
		},
	}

	legStartRequestAmend := guaranteePB.LegacyGXStartRequest{
		Request: &guaranteePB.LegacyGXStartRequest_GxAmendRequest{
			GxAmendRequest: &legAmend,
		},
	}

	addLegacyGxStartRequest(t, stub, &legStartRequestAmend, cctest.GenerateMockTxID(""))

	// Migrate
	testCCInit(t, stub)

	// check stored gx
	startRequestAmend := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: legAmend.GetId()})
	amend := startRequestAmend.GetGxAmendRequest()

	// Check unchanged fields
	assert.Equal(t, amend.Id, legAmend.Id)
	assert.Equal(t, amend.GxId, legAmend.GxId)
	assert.Equal(t, amend.Amount, legAmend.Amount)
	assert.Equal(t, amend.ExpiresAt, legAmend.ExpiresAt)
	assert.Equal(t, amend.ExpiresAtOpenEnded, legAmend.ExpiresAtOpenEnded)
	assert.Equal(t, amend.OrgIds, legAmend.OrgIds)
	assert.Equal(t, amend.Status, legAmend.Status)
	assert.Equal(t, amend.CreatedAt, legAmend.CreatedAt)
	assert.Equal(t, amend.CreatedBy, legAmend.CreatedBy)
	assert.Equal(t, amend.UpdatedAt, legAmend.UpdatedAt)
	assert.Equal(t, amend.UpdatedBy, legAmend.UpdatedBy)

	// Check purpose
	legPurpose := legAmend.GetGxRentalPurpose()
	assert.Nil(t, amend.Purpose["propertyDetails"])
	assert.Nil(t, amend.Purpose["propertyAddress"])
	assert.Equal(t, amend.Purpose["purpose"].ElementType, guaranteePB.GxPurposeElementType_MAP)
	assert.Equal(t, amend.Purpose["purpose"].MapValue["comment"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, amend.Purpose["purpose"].MapValue["comment"].StringValue.Value, legPurpose.FreeFormText.Value)
}

// Should not change, but test just to ensure
func TestDemandRequestMigration(t *testing.T) {
	stub, _ := setup(t)

	// Add a legacy GX
	legDemand := guaranteePB.GXDemandRequest{
		Id:        "amend1",
		GxId:      "gx Id 1",
		Amount:    10,
		OrgIds:    []string{"applicant1"},
		Status:    sharedPB.FlowStatus_FLOW_ACTIVE,
		CreatedAt: &types.Timestamp{Nanos: 2, Seconds: 1},
		CreatedBy: "createdBy123",
		UpdatedAt: &types.Timestamp{Nanos: 3, Seconds: 1},
		UpdatedBy: "updatedBy123",
	}

	legStartRequestDemand := guaranteePB.LegacyGXStartRequest{
		Request: &guaranteePB.LegacyGXStartRequest_GxDemandRequest{
			GxDemandRequest: &legDemand,
		},
	}

	addLegacyGxStartRequest(t, stub, &legStartRequestDemand, cctest.GenerateMockTxID(""))

	// Migrate
	testCCInit(t, stub)

	// check stored gx
	startRequestDemand := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: legDemand.GetId()})
	demand := startRequestDemand.GetGxDemandRequest()

	// Check unchanged fields
	assert.Equal(t, demand.Id, legDemand.Id)
	assert.Equal(t, demand.GxId, legDemand.GxId)
	assert.Equal(t, demand.Amount, legDemand.Amount)
	assert.Equal(t, demand.OrgIds, legDemand.OrgIds)
	assert.Equal(t, demand.Status, legDemand.Status)
	assert.Equal(t, demand.CreatedAt, legDemand.CreatedAt)
	assert.Equal(t, demand.CreatedBy, legDemand.CreatedBy)
	assert.Equal(t, demand.UpdatedAt, legDemand.UpdatedAt)
	assert.Equal(t, demand.UpdatedBy, legDemand.UpdatedBy)
}

func TestIssueRequestMigration(t *testing.T) {
	stub, _ := setup(t)

	// Add a legacy Issue
	legIssue := guaranteePB.LegacyGXIssueRequest{
		Id:                "issue1",
		GxId:              "gx Id 1",
		OrgIds:            []string{"applicant1"},
		Status:            sharedPB.FlowStatus_FLOW_ACTIVE,
		CreatedAt:         &types.Timestamp{Nanos: 2, Seconds: 1},
		CreatedBy:         "createdBy123",
		UpdatedAt:         &types.Timestamp{Nanos: 3, Seconds: 1},
		UpdatedBy:         "updatedBy123",
		OffchainCreatedAt: &types.Timestamp{Nanos: 4, Seconds: 1},
		Gx: &guaranteePB.LegacyGX{
			Type:          guaranteePB.GXType_GX_COMMERCIAL_LEASE,
			Applicants:    []string{"applicant1"},
			Beneficiaries: []string{"beneficiary1"},
			Amount:        &guaranteePB.GXAmount{Outstanding: 1234},
			BankReference: "abc1234",
			ExpiresAt:     &types.Timestamp{Nanos: 1, Seconds: 1},
			Purpose: &guaranteePB.LegacyGX_GxRentalPurpose{GxRentalPurpose: &guaranteePB.GXRentalPurpose{
				PropertyName: "example propertyName",
				ShopNumber:   "example shopNumber",
				FreeFormText: "example freeFormText",
				Address: &sharedPB.Address{
					StreetAddress:       "example street address",
					AddressLocality:     "example address locality",
					AddressRegion:       "example address region",
					AddressCountry:      "example address country",
					PostalCode:          "example postal code",
					PostOfficeBoxNumber: "example post office box number",
				},
			}},
			PrevGxId:    "prev gx id",
			ActiveFlows: 3150,
			TcId:        "example tc id",
		},
	}

	legStartRequestIssue := guaranteePB.LegacyGXStartRequest{
		Request: &guaranteePB.LegacyGXStartRequest_GxIssueRequest{
			GxIssueRequest: &legIssue,
		},
	}

	addLegacyGxStartRequest(t, stub, &legStartRequestIssue, cctest.GenerateMockTxID(""))

	// Migrate
	testCCInit(t, stub)

	// check stored gx
	startRequestIssue := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: legIssue.GetId()})
	issue := startRequestIssue.GetGxIssueRequest()

	// Check unchanged fields
	assert.Equal(t, issue.Id, legIssue.Id)
	assert.Equal(t, issue.GxId, legIssue.GxId)
	assert.Equal(t, issue.OrgIds, legIssue.OrgIds)
	assert.Equal(t, issue.Status, legIssue.Status)
	assert.Equal(t, issue.CreatedAt, legIssue.CreatedAt)
	assert.Equal(t, issue.CreatedBy, legIssue.CreatedBy)
	assert.Equal(t, issue.UpdatedAt, legIssue.UpdatedAt)
	assert.Equal(t, issue.UpdatedBy, legIssue.UpdatedBy)
	assert.Equal(t, issue.OffchainCreatedAt, legIssue.OffchainCreatedAt)

	// Check GX
	validateGx(t, issue.GetGx(), legIssue.GetGx())
}

func TestTransferRequestMigration(t *testing.T) {
	stub, _ := setup(t)

	// Add a legacy Transfer
	legTransfer := guaranteePB.LegacyGXTransferRequest{
		Id:            "transfer1",
		GxId:          "gxId1",
		Reason:        "reason1",
		Beneficiaries: []string{"beneficiary1"},
		OrgIds:        []string{"applicant1"},
		Status:        sharedPB.FlowStatus_FLOW_ACTIVE,
		NewGxId:       "gxId2",
		CreatedAt:     &types.Timestamp{Nanos: 2, Seconds: 1},
		CreatedBy:     "createdBy123",
		UpdatedAt:     &types.Timestamp{Nanos: 3, Seconds: 1},
		UpdatedBy:     "updatedBy123",
		Gx: &guaranteePB.LegacyGX{
			Id:            "gxId1",
			Type:          guaranteePB.GXType_GX_COMMERCIAL_LEASE,
			Applicants:    []string{"applicant1"},
			Beneficiaries: []string{"beneficiary1"},
			Amount:        &guaranteePB.GXAmount{Outstanding: 1234},
			BankReference: "abc1234",
			ExpiresAt:     &types.Timestamp{Nanos: 1, Seconds: 1},
			Purpose: &guaranteePB.LegacyGX_GxRentalPurpose{GxRentalPurpose: &guaranteePB.GXRentalPurpose{
				PropertyName: "example propertyName",
				ShopNumber:   "example shopNumber",
				FreeFormText: "example freeFormText",
				Address: &sharedPB.Address{
					StreetAddress:       "example street address",
					AddressLocality:     "example address locality",
					AddressRegion:       "example address region",
					AddressCountry:      "example address country",
					PostalCode:          "example postal code",
					PostOfficeBoxNumber: "example post office box number",
				},
			}},
			PrevGxId:    "prev gx id",
			ActiveFlows: 3150,
			TcId:        "example tc id",
		},
	}

	legStartRequestTransfer := guaranteePB.LegacyGXStartRequest{
		Request: &guaranteePB.LegacyGXStartRequest_GxTransferRequest{
			GxTransferRequest: &legTransfer,
		},
	}

	addLegacyGxStartRequest(t, stub, &legStartRequestTransfer, cctest.GenerateMockTxID(""))

	// Migrate
	testCCInit(t, stub)

	// check stored gx
	startRequestTransfer := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: legTransfer.GetId()})
	transfer := startRequestTransfer.GetGxTransferRequest()

	// Check unchanged fields
	assert.Equal(t, transfer.Id, legTransfer.Id)
	assert.Equal(t, transfer.GxId, legTransfer.GxId)
	assert.Equal(t, transfer.Reason, legTransfer.Reason)
	assert.Equal(t, transfer.Beneficiaries, legTransfer.Beneficiaries)
	assert.Equal(t, transfer.OrgIds, legTransfer.OrgIds)
	assert.Equal(t, transfer.Status, legTransfer.Status)
	assert.Equal(t, transfer.NewGxId, legTransfer.NewGxId)
	assert.Equal(t, transfer.CreatedAt, legTransfer.CreatedAt)
	assert.Equal(t, transfer.CreatedBy, legTransfer.CreatedBy)
	assert.Equal(t, transfer.UpdatedAt, legTransfer.UpdatedAt)
	assert.Equal(t, transfer.UpdatedBy, legTransfer.UpdatedBy)

	// Check GX
	validateGx(t, transfer.GetGx(), legTransfer.GetGx())
}

func validateGx(t *testing.T, gx *guaranteePB.GX, legacyGX *guaranteePB.LegacyGX) {
	// Check unchanged fields
	assert.Equal(t, gx.Id, legacyGX.Id)
	assert.Equal(t, gx.Applicants, legacyGX.Applicants)
	assert.Equal(t, gx.Beneficiaries, legacyGX.Beneficiaries)
	assert.Equal(t, gx.Status, legacyGX.Status)
	assert.Equal(t, gx.Amount, legacyGX.Amount)
	assert.Equal(t, gx.BankReference, legacyGX.BankReference)
	assert.Equal(t, gx.ExpiresAt, legacyGX.ExpiresAt)
	assert.Equal(t, gx.PrevGxId, legacyGX.PrevGxId)
	assert.Equal(t, gx.ActiveFlows, legacyGX.ActiveFlows)
	assert.Equal(t, gx.TcId, legacyGX.TcId)
	assert.Equal(t, gx.PurposeType, migrationPurposeType)
	assert.Equal(t, gx.IssuedAt, legacyGX.IssuedAt)
	assert.Equal(t, gx.UpdatedAt, legacyGX.UpdatedAt)

	// Check purpose
	legacyPurpose := legacyGX.GetGxRentalPurpose()
	assert.Equal(t, gx.Purpose["propertyDetails"].ElementType, guaranteePB.GxPurposeElementType_MAP)
	assert.Equal(t, gx.Purpose["propertyDetails"].MapValue["propertyName"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, gx.Purpose["propertyDetails"].MapValue["propertyName"].StringValue.Value, legacyPurpose.PropertyName)
	assert.Equal(t, gx.Purpose["propertyDetails"].MapValue["shopNumber"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, gx.Purpose["propertyDetails"].MapValue["shopNumber"].StringValue.Value, legacyPurpose.ShopNumber)
	assert.Equal(t, gx.Purpose["propertyAddress"].ElementType, guaranteePB.GxPurposeElementType_MAP)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressStreet"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressStreet"].StringValue.Value, legacyPurpose.Address.StreetAddress)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressSuburb"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressSuburb"].StringValue.Value, legacyPurpose.Address.AddressLocality)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressPostcode"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressPostcode"].StringValue.Value, legacyPurpose.Address.PostalCode)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressCountry"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressCountry"].StringValue.Value, legacyPurpose.Address.AddressCountry)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressState"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, gx.Purpose["propertyAddress"].MapValue["addressState"].StringValue.Value, legacyPurpose.Address.AddressRegion)
	assert.Equal(t, gx.Purpose["purpose"].ElementType, guaranteePB.GxPurposeElementType_MAP)
	assert.Equal(t, gx.Purpose["purpose"].MapValue["comment"].ElementType, guaranteePB.GxPurposeElementType_STRING)
	assert.Equal(t, gx.Purpose["purpose"].MapValue["comment"].StringValue.Value, legacyPurpose.FreeFormText)
}

func testCCInit(t *testing.T, stub *cctest.MockStub) {
	cctest.PerformCCInit(t, stub, [][]byte{[]byte("init"), []byte(fmt.Sprintf(`{
		"prefix":"000002",
		"platformChannelId":"platform-channel",
		"profileCc":"profile",
		"newcoMspId":"newco",
		"migrationPurposeType": "%s",
		"migrate": true
	}`, migrationPurposeType))})
}

func addLegacyGx(t *testing.T, stub *cctest.MockStub, gx guaranteePB.LegacyGX, txID string) {
	t.Helper()
	// Put Guarantee into state
	gxKey, err := generateGXKey(stub, gx.GetId())
	if err != nil {
		t.Fatalf(err.Error())
	}
	stub.MockTransactionStart(txID)

	err = ccutil.PutStatePB(stub, gxKey, &gx)
	if err != nil {
		t.Fatalf(err.Error())
	}
	stub.MockTransactionEnd(txID)
}

func addLegacyGxStartRequest(t *testing.T, stub *cctest.MockStub, startRequest *guaranteePB.LegacyGXStartRequest, txID string) {
	t.Helper()

	baseRequest, err := getRequestFromLegacyStartRequest(startRequest)
	if err != nil {
		t.Fatal(err.Error())
	}

	// Put Guarantee into state
	flowKey, err := ccutil.GenerateFlowKey(stub, baseRequest.GetId())
	if err != nil {
		t.Fatalf(err.Error())
	}
	stub.MockTransactionStart(txID)

	err = ccutil.PutStatePB(stub, flowKey, startRequest)
	if err != nil {
		t.Fatalf(err.Error())
	}
	stub.MockTransactionEnd(txID)
}

func getRequestFromLegacyStartRequest(startRequest *guaranteePB.LegacyGXStartRequest) (gxRequestMessage, error) {
	switch t := startRequest.GetRequest().(type) {
	case *guaranteePB.LegacyGXStartRequest_GxIssueRequest:
		return startRequest.GetGxIssueRequest(), nil
	case *guaranteePB.LegacyGXStartRequest_GxAmendRequest:
		return startRequest.GetGxAmendRequest(), nil
	case *guaranteePB.LegacyGXStartRequest_GxCancelRequest:
		return startRequest.GetGxCancelRequest(), nil
	case *guaranteePB.LegacyGXStartRequest_GxDemandRequest:
		return startRequest.GetGxDemandRequest(), nil
	case *guaranteePB.LegacyGXStartRequest_GxPayWalkRequest:
		return startRequest.GetGxPayWalkRequest(), nil
	case *guaranteePB.LegacyGXStartRequest_GxTransferRequest:
		return startRequest.GetGxTransferRequest(), nil
	case *guaranteePB.LegacyGXStartRequest_GxExpireRequest:
		return startRequest.GetGxExpireRequest(), nil
	default:
		return nil, fmt.Errorf("Invalid Request Type %T", t)
	}
}
