package gx

import (
	"fmt"
	"regexp"
	"time"

	"github.com/pkg/errors"

	"github.com/gogo/protobuf/types"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// StartFlow starts a flow
func (t *APICC) StartFlow(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest) (*guaranteePB.GXStartRequest, error) {

	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Processing StartFlow request %v\n", startRequest)
	ccutil.Logger.Info("Request CREATE flow\n")

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}
	allowedToInitiate, err := t.isAllowedToInitiateFlow(stub, startRequest, info)
	if err != nil {
		return nil, err
	}
	if !allowedToInitiate {
		return nil, errors.New("Organization is not allowed to initiate flow")
	}

	// Validates and transforms request
	err = t.processStartRequest(stub, startRequest, info)
	if err != nil {
		return nil, err
	}

	// Get flow ID
	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		return nil, err
	}
	flowID := baseRequest.GetId()

	// Finish flow and emit events
	err = t.finishStartFlow(stub, flowID, startRequest, &info)
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return startRequest, nil
}

func (t *APICC) isAllowedToInitiateFlow(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, cInfo creatorInfo) (bool, error) {
	switch startRequest.Request.(type) {
	case *guaranteePB.GXStartRequest_GxExpireRequest:
		return true, nil
	case *guaranteePB.GXStartRequest_GxPayWalkRequest:
		isIssuerRes, err := isIssuer(stub, &cInfo)
		if err != nil {
			return false, err
		}
		return cInfo.organization.GetEntityType() == profilePB.OrganizationEntityType_ORGANIZATION_ISSUER && isIssuerRes, nil

	default:
		return cInfo.organization.EntityType == profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY, nil
	}
}

func (t *APICC) validatePurpose(stub *guaranteePB.ChaincodeStub, formatID string, purpose map[string]*guaranteePB.GxPurposeElement, isAmend bool) error {
	format, err := t.invokeProfileGetPurposeFormat(stub, formatID)

	if err != nil {
		return err
	}

	// validate sub-section, returns either error or nil
	err = validatePurposeFields(format.GetPurposeField(), purpose, isAmend)
	if err == nil {
		err = processPurposeFields(format.GetPurposeField(), purpose, isAmend)
		if err != nil {
			return err
		}
	}
	return err
}

// this function will update any purpose elements containing dates and truncate the time and add midnight instead
func processPurposeFields(fields []*sharedPB.PurposeField, purpose map[string]*guaranteePB.GxPurposeElement, isAmend bool) error {
	for _, field := range fields {
		// skip missing entries
		_, contained := purpose[field.GetName()]
		if contained {
			// special handling for complex objects and dates
			if field.GetType() == sharedPB.PurposeFieldType_PFT_OBJECT {
				err := processPurposeFields(field.GetSubFields(), purpose[field.GetName()].GetMapValue(), isAmend)
				if err != nil {
					return err
				}
			} else if field.GetType() == sharedPB.PurposeFieldType_PFT_DATE {
				updatedDate, err := truncateTimeFromDateTime(purpose[field.GetName()].GetStringValue().GetValue())
				if err != nil {
					return err
				}
				purpose[field.GetName()].GetStringValue().Value = updatedDate
			}
		}

	}

	return nil
}

// formats a given date string by just extracting the date and setting the time to midnight (ISO format)
func truncateTimeFromDateTime(dateTimeString string) (string, error) {
	if len(dateTimeString) < 11 {
		ccutil.Logger.Debugf("Datetime too short: %v\n", dateTimeString)
		return "", errors.New("Datetime must have at least 11 characters in string representation")
	}
	res := dateTimeString[0:11] + "00:00:00.000Z"
	return res, nil
}

func validatePurposeFields(fields []*sharedPB.PurposeField, purpose map[string]*guaranteePB.GxPurposeElement, isAmend bool) error {
	for _, field := range fields {
		purposeElement, contained := purpose[field.GetName()]

		if field.GetType() == sharedPB.PurposeFieldType_PFT_OBJECT {
			// this is a complex key, check if present in payload
			if !isAmend && !field.GetOptional() {
				// field nees to be in purpose
				if !contained {
					return fmt.Errorf("Field %s is required", field.GetName())
				}
			}

			if contained {
				err := validatePurposeFields(field.GetSubFields(), purposeElement.GetMapValue(), isAmend)
				if err != nil {
					return err
				}
			}
		} else {
			// check if the field is provided if required
			if isAmend && !contained {
				continue
			}
			if !isAmend && !field.GetOptional() && !contained {
				return fmt.Errorf("Field %s is required", field.GetName())
			}

			if contained {
				// check if constraints are not violated
				for _, constraint := range field.GetPurposeConstraints() {
					err := validatePurposeConstraint(constraint, field, purpose)
					if err != nil {
						return err
					}
				}

				if field.GetType() == sharedPB.PurposeFieldType_PFT_DATE {
					// validate date format
					err := validatePurposeDate(purpose[field.GetName()])
					if err != nil {
						return err
					}
				}
			}
		}
	}
	return nil
}

func validatePurposeDate(dateValue *guaranteePB.GxPurposeElement) error {
	if dateValue.GetElementType() != guaranteePB.GxPurposeElementType_STRING {
		return errors.New("Dates need to be send as string values")
	}

	_, err := time.Parse(time.RFC3339, dateValue.GetStringValue().GetValue())
	if err != nil {
		return err
	}
	return nil
}

func validatePurposeConstraint(constraint *sharedPB.PurposeConstraint, field *sharedPB.PurposeField, purpose map[string]*guaranteePB.GxPurposeElement) error {
	var err error
	switch constraint.GetConstraint().(type) {
	case *sharedPB.PurposeConstraint_OneOfConstraint:
		err = validateOneOfConstraint(purpose[field.GetName()], constraint.GetOneOfConstraint())
	case *sharedPB.PurposeConstraint_MinValueConstraint:
		err = validateMinValueConstraint(purpose[field.GetName()], constraint.GetMinValueConstraint())
	case *sharedPB.PurposeConstraint_MaxValueConstraint:
		err = validateMaxValueConstraint(purpose[field.GetName()], constraint.GetMaxValueConstraint())
	case *sharedPB.PurposeConstraint_PatternConstraint:
		err = validatePatternConstraint(purpose[field.GetName()], constraint.GetPatternConstraint())
	default:
		err = nil
	}

	return err
}

func validateOneOfConstraint(purposeElement *guaranteePB.GxPurposeElement, constraint *sharedPB.OneOfConstraint) error {
	valid := false
	for _, val := range constraint.GetAvailableValues() {
		if purposeElement.GetStringValue().GetValue() == val {
			valid = true
		}
	}

	if valid == false {
		return errors.New("Field validation failed because a OneOf constraint is not fulfilled")
	}
	return nil
}

func validateMinValueConstraint(purposeElement *guaranteePB.GxPurposeElement, constraint *sharedPB.MinValueConstraint) error {
	valid := false
	if purposeElement.GetElementType() == guaranteePB.GxPurposeElementType_INT {
		if constraint.GetIncludeMin() {
			valid = purposeElement.GetIntValue().GetValue() >= constraint.GetMinValue()
		} else {
			valid = purposeElement.GetIntValue().GetValue() > constraint.GetMinValue()
		}
	} else if purposeElement.GetElementType() == guaranteePB.GxPurposeElementType_DOUBLE {
		if constraint.GetIncludeMin() {
			valid = purposeElement.GetDoubleValue().GetValue() >= float64(constraint.GetMinValue())
		} else {
			valid = purposeElement.GetDoubleValue().GetValue() > float64(constraint.GetMinValue())
		}
	}
	if !valid {
		return errors.New("Failed to validate min value constraint")
	}
	return nil
}

func validateMaxValueConstraint(purposeElement *guaranteePB.GxPurposeElement, constraint *sharedPB.MaxValueConstraint) error {
	valid := false
	if purposeElement.GetElementType() == guaranteePB.GxPurposeElementType_INT {
		if constraint.GetIncludeMax() {
			valid = purposeElement.GetIntValue().GetValue() <= constraint.GetMaxValue()
		} else {
			valid = purposeElement.GetIntValue().GetValue() < constraint.GetMaxValue()
		}
	} else if purposeElement.GetElementType() == guaranteePB.GxPurposeElementType_DOUBLE {
		if constraint.GetIncludeMax() {
			valid = purposeElement.GetDoubleValue().GetValue() <= float64(constraint.GetMaxValue())
		} else {
			valid = purposeElement.GetDoubleValue().GetValue() < float64(constraint.GetMaxValue())
		}
	}
	if !valid {
		return errors.New("Failed to validate max value constraint")
	}
	return nil
}

func validatePatternConstraint(purposeElement *guaranteePB.GxPurposeElement, constraint *sharedPB.PatternConstraint) error {
	match, err := regexp.MatchString(constraint.GetPattern(), purposeElement.GetStringValue().GetValue())

	if err != nil {
		return err
	}
	if !match {
		return errors.New("Failed to validate pattern constraint")
	}
	return nil
}

func (t *APICC) processStartRequest(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, info creatorInfo) error {
	// Set Flow ID and Metadata
	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		return err
	}

	err = ccutil.SetCreatedMetadata(stub, baseRequest, info.organization.GetId())
	if err != nil {
		return err
	}

	err = ccutil.SetUpdatedMetadata(stub, baseRequest, info.organization.GetId())
	if err != nil {
		return err
	}

	var flowID string
	if baseRequest.GetId() == "" {
		flowID = ccutil.GenerateFlowID(stub)
		// Sets startRequest.Request.ID
		ccutil.SetID(baseRequest, flowID)
	} else {
		flowID = baseRequest.GetId()

		// TODO validate that ID is of correct format
		if !validateFlowIDFormat(flowID) {
			return fmt.Errorf("Invalid flow ID specified %s", flowID)
		}
	}

	// Check if flow with ID already exists
	existingFlow, _ := t.GetFlow(stub, &sharedPB.FlowIDValue{Value: flowID})

	// Expect error as we don't want flow to exist
	if existingFlow != nil {
		return fmt.Errorf("Cannot create flow, as flow with ID %s already exists", flowID)
	}

	requestType, err := getRequestType(startRequest)
	if err != nil {
		return err
	}

	var gx *guaranteePB.GX
	if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_ISSUE {
		issueRequest := startRequest.GetGxIssueRequest()
		gx = issueRequest.GetGx()

		// validate purpose format
		err = t.validatePurpose(stub, gx.GetPurposeType(), gx.GetPurpose(), false)
		if err != nil {
			return err
		}
	} else {
		gx, err = get(stub, baseRequest.GetGxId())
		if err != nil {
			return err
		}
		// Check that gx is active
		active, err := isGXActive(stub, gx)
		if err != nil {
			return err
		}
		if !active &&
			!(requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_EXPIRE && gx.GetStatus() == guaranteePB.GXStatus_GX_ACTIVE) {
			return fmt.Errorf("Cannot create flow, as GX %s is not active", gx.GetId())
		}

		if requestType == guaranteePB.GXRequestType_GX_REQUEST_TYPE_AMEND {
			err = t.validatePurpose(stub, gx.GetPurposeType(), startRequest.GetGxAmendRequest().GetPurpose(), true)
			if err != nil {
				return err
			}
		}
	}

	err = t.ensureSameRequestTypeDoesNotExist(stub, gx, startRequest)
	if err != nil {
		return err
	}

	// Sets startRequest.Request
	ccutil.SetID(baseRequest, flowID)

	// Handle unique data modifications and validations
	switch startRequest.Request.(type) {
	case *guaranteePB.GXStartRequest_GxIssueRequest:
		issueRequest := startRequest.GetGxIssueRequest()

		// checks that valid TC ID is specified
		tc, err := t.invokeProfileTCGet(stub, issueRequest.GetGx().GetTcId())
		if err != nil {
			return errors.Wrap(err, "Error validating TC")
		}
		if tc.GetScope() != profilePB.TermsConditionsScope_BANK_GUARANTEE {
			return fmt.Errorf("TC is of invalid scope, was expecting %s", profilePB.TermsConditionsScope_BANK_GUARANTEE)
		}

		issueRequest.OrgIds = append(gx.GetApplicants(), gx.GetBeneficiaries()...)
		issueRequest.Status = sharedPB.FlowStatus_FLOW_ACTIVE
	case *guaranteePB.GXStartRequest_GxAmendRequest:
		amendRequest := startRequest.GetGxAmendRequest()
		amendRequest.OrgIds = append(gx.GetApplicants(), gx.GetBeneficiaries()...)
		amendRequest.Status = sharedPB.FlowStatus_FLOW_ACTIVE
	case *guaranteePB.GXStartRequest_GxCancelRequest:
		cancelRequest := startRequest.GetGxCancelRequest()
		cancelRequest.OrgIds = append(gx.GetApplicants(), gx.GetBeneficiaries()...)
		cancelRequest.Status = sharedPB.FlowStatus_FLOW_ACTIVE
	case *guaranteePB.GXStartRequest_GxDemandRequest:
		demandRequest := startRequest.GetGxDemandRequest()
		// only beneficiary can demand
		if !ccutil.ContainsString(gx.GetBeneficiaries(), info.organization.GetId()) {
			return errors.New("Only beneficiaries can demand")
		}

		err = validateGxDemand(gx, demandRequest)
		if err != nil {
			return err
		}
		demandRequest.OrgIds = gx.GetBeneficiaries()
		demandRequest.Status = sharedPB.FlowStatus_FLOW_ACTIVE
	case *guaranteePB.GXStartRequest_GxTransferRequest:
		transferRequest := startRequest.GetGxTransferRequest()
		transferRequest.Gx = gx
		transferRequest.OrgIds = append(
			gx.GetApplicants(),
			append(gx.GetBeneficiaries(), transferRequest.GetBeneficiaries()...)...,
		)
		transferRequest.Status = sharedPB.FlowStatus_FLOW_ACTIVE
	case *guaranteePB.GXStartRequest_GxPayWalkRequest:
		payWalkRequest := startRequest.GetGxPayWalkRequest()
		payWalkRequest.OrgIds = append(gx.GetApplicants(), gx.GetBeneficiaries()...)
		payWalkRequest.Status = sharedPB.FlowStatus_FLOW_ACTIVE
	case *guaranteePB.GXStartRequest_GxExpireRequest:
		expireRequest := startRequest.GetGxExpireRequest()
		expireRequest.OrgIds = append(gx.GetApplicants(), gx.GetBeneficiaries()...)
		expireRequest.Status = sharedPB.FlowStatus_FLOW_ACTIVE
	default:
		return errors.New("Invalid request type")
	}
	return nil
}

func (t *APICC) finishStartFlow(stub *guaranteePB.ChaincodeStub, flowID string, startRequest *guaranteePB.GXStartRequest, cInfo *creatorInfo) error {
	// Get flow ID
	baseRequest, err := getRequestFromStartRequest(startRequest)
	if err != nil {
		return err
	}

	// Add submit action
	var submitActionCreatedAt *types.Timestamp

	// Cater for offchain createdAt time for issue requests
	if _, ok := startRequest.Request.(*guaranteePB.GXStartRequest_GxIssueRequest); ok {
		issueRequest := startRequest.GetGxIssueRequest()
		if issueRequest.OffchainCreatedAt != nil {
			submitActionCreatedAt = issueRequest.GetOffchainCreatedAt()
		}
	}
	if submitActionCreatedAt == nil {
		submitActionCreatedAt = baseRequest.GetCreatedAt()
	}

	submitAction := guaranteePB.GXFlowActionRequest{
		Request: &guaranteePB.GXFlowActionRequest_FlowActionRequest{
			FlowActionRequest: &sharedPB.FlowActionRequest{
				Id:        flowID,
				FlowId:    flowID,
				CreatedAt: submitActionCreatedAt,
				CreatedBy: baseRequest.GetCreatedBy(),
			},
		},
	}

	err = t.addAction(stub, flowID, &submitAction)
	if err != nil {
		return err
	}

	// cases where no approvals are needed
	switch startRequest.Request.(type) {
	case *guaranteePB.GXStartRequest_GxPayWalkRequest:
		return t.finishFlow(stub, startRequest, nil, cInfo)
	case *guaranteePB.GXStartRequest_GxExpireRequest:
		return t.finishFlow(stub, startRequest, nil, cInfo)
	default:
		// Do nothing
	}

	// Update GX active requests
	err = t.updateGXSetActiveRequestFlag(stub, startRequest)
	if err != nil {
		return err
	}

	// cases where there are additional approvals
	flowKey, err := ccutil.GenerateFlowKey(stub, flowID)
	if err != nil {
		return err
	}
	err = ccutil.PutStatePB(stub, flowKey, startRequest)
	if err != nil {
		return err
	}

	// Emit event
	return t.storeAndEmitStartFlowEvent(stub, startRequest)
}

func (t *APICC) ensureSameRequestTypeDoesNotExist(stub *guaranteePB.ChaincodeStub, gx *guaranteePB.GX, startRequest *guaranteePB.GXStartRequest) error {
	requestType, err := getRequestType(startRequest)
	if err != nil {
		return err
	}
	if requestTypeHasFlag(requestType) {
		valid, err := t.validateSameRequestTypeDoesNotExist(gx, startRequest)
		if err != nil {
			return err
		}
		if !valid {
			stub.SetResponseCode(403)
			return fmt.Errorf("Cannot create %s request as gx %s already has an active %s", requestType, gx.GetId(), requestType)
		}
	}
	return nil
}

func (t *APICC) validateSameRequestTypeDoesNotExist(gx *guaranteePB.GX, startRequest *guaranteePB.GXStartRequest) (bool, error) {
	requestFlag, err := t.getActiveRequestFlag(startRequest)
	if err != nil {
		return false, err
	}

	gxBitmask := ccutil.Bitmask(gx.GetActiveFlows())
	return !gxBitmask.Has(requestFlag), nil
}

func (t *APICC) storeAndEmitStartFlowEvent(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest) error {
	createdAt, err := ccutil.GetTxTimestamp(stub)
	if err != nil {
		return err
	}

	event := &guaranteePB.GXEvent{
		Id:        stub.GetTxID(),
		CreatedAt: createdAt,
		Payload: &guaranteePB.GXEvent_StartFlowEvent{
			StartFlowEvent: &guaranteePB.StartFlowEvent{
				StartRequest: startRequest,
			},
		},
	}

	ccutil.Logger.Debugf("Storing+Emitting StartFlow Event %v\n", event)
	ccutil.Logger.Infof("Triggering EVENT <Start Flow> (id: %v)\n", event.Id)

	// Store Event
	err = t.storeGXEvent(stub, event)
	if err != nil {
		return err
	}

	// Emit Event
	err = stub.SetStartFlowEvent(event)
	return err
}

func validateFlowIDFormat(flowID string) bool {
	return len(flowID) == 36
}
