package gx

import (
	"errors"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// SearchEvents searches through flows and returns a subset
func (t *APICC) SearchEvents(stub *guaranteePB.ChaincodeStub, request *sharedPB.EventSearchRequest) (*guaranteePB.GXEventSearchResponse, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Searching Events, using search request: %v\n", request)

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}

	if info.organization.GetEntityType() == profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY {
		return nil, errors.New("This endpoint is for consortium/issuer only")
	}

	events, err := getAllEventsWeakTyping(stub)
	if err != nil {
		return nil, err
	}

	if request.GetLimit() == 0 {
		request.Limit = 50
	}

	ccutil.EventSort(events)

	paginationResult, err := ccutil.EventSearchFilter(stub, events, request)
	if err != nil {
		return nil, err
	}

	gxEvents, err := eventInterfacesToGXEvents(paginationResult.Events)
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return &guaranteePB.GXEventSearchResponse{Events: gxEvents, Next: paginationResult.Next}, nil
}

func getAllEventsWeakTyping(stub *guaranteePB.ChaincodeStub) ([]ccutil.EventInterface, error) {
	iterator, err := generateGXEventIterator(stub)
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var events []ccutil.EventInterface

	for iterator.HasNext() {
		eventKV, err := iterator.Next()
		if err != nil {
			return nil, err
		}
		eventBytes := eventKV.GetValue()

		var event guaranteePB.GXEvent
		err = ccutil.Unmarshal(eventBytes, &event)
		if err != nil {
			ccutil.Logger.Debug("Skipping event due to error during unmarshal operation")
			continue
			// return nil, err
		}

		events = append(events, &event)
	}

	return events, nil
}

func gxEventsToEventInterfaces(gxEvents []*guaranteePB.GXEvent) []ccutil.EventInterface {
	events := make([]ccutil.EventInterface, len(gxEvents))
	for i, v := range gxEvents {
		events[i] = ccutil.EventInterface(v)
	}
	return events
}

func eventInterfacesToGXEvents(events []ccutil.EventInterface) ([]*guaranteePB.GXEvent, error) {
	gxEvents := make([]*guaranteePB.GXEvent, len(events))
	for i, v := range events {
		var ok bool
		gxEvents[i], ok = v.(*guaranteePB.GXEvent)
		if !ok {
			return nil, errors.New("Could not serialize GxEvent")
		}
	}
	return gxEvents, nil
}
