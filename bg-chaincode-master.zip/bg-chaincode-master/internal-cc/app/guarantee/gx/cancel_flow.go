package gx

import (
	"errors"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// CancelFlow cancels a flow
func (t *APICC) CancelFlow(stub *guaranteePB.ChaincodeStub, flowActionRequest *sharedPB.FlowActionRequest) (*sharedPB.FlowActionRequest, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Processing CancelFlow action %v\n", flowActionRequest)

	// Set ID
	flowActionRequest.Id = ccutil.GenerateFlowActionID(stub)
	ccutil.Logger.Infof("Action CANCEL flow (id: %v, flow: %v)\n", flowActionRequest.Id, flowActionRequest.GetFlowId())

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}
	creatorOrganizationID := info.organization.GetId()

	err = ccutil.SetCreatedMetadata(stub, flowActionRequest, creatorOrganizationID)
	if err != nil {
		return nil, err
	}

	// Get Start Request
	var startRequest guaranteePB.GXStartRequest
	flowKey, err := ccutil.GenerateFlowKey(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}
	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	startBaseRequest, err := getRequestFromStartRequest(&startRequest)
	if err != nil {
		return nil, err
	}

	// Check if Flow is active
	if startBaseRequest.GetStatus() != sharedPB.FlowStatus_FLOW_ACTIVE {
		return nil, errors.New("Request is not active")
	}

	// Check whether current creator is creator of the start request as they are the only ones allowed to cancel
	if creatorOrganizationID != startBaseRequest.GetCreatedBy() {
		return nil, errors.New("Error only flow creator can cancel flow")
	}

	// Set RequestType
	flowActionRequest.RequestType = sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_CANCEL
	// Add cancel request to flow
	err = t.addAction(stub, flowActionRequest.GetFlowId(), &guaranteePB.GXFlowActionRequest{Request: &guaranteePB.GXFlowActionRequest_FlowActionRequest{FlowActionRequest: flowActionRequest}})
	if err != nil {
		return nil, err
	}

	// Update flow status to cancelled or withdrawn
	status, err := t.getCancelledStatus(stub, &startRequest, &info)
	if err != nil {
		return nil, err
	}

	setStatus(startBaseRequest, status)
	err = ccutil.PutStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	// Update GX active requests
	err = t.updateGXClearActiveRequestFlag(stub, &startRequest)
	if err != nil {
		return nil, err
	}

	stub.SetResponseCode(200)
	return flowActionRequest, nil
}

func (t *APICC) getCancelledStatus(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, cInfo *creatorInfo) (sharedPB.FlowStatus, error) {
	return t.processWithdrawnStatus(stub, startRequest, cInfo, sharedPB.FlowStatus_FLOW_CANCELLED)
}
