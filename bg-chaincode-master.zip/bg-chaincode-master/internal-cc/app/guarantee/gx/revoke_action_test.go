package gx

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

func TestRevokeAction(t *testing.T) {
	stub, _ := setup(t)

	cctest.SetMockStubCert(t, stub, appOrgPEM)
	initGX := generateExampleBasicGX()
	issueReq := invokeStartFlowIssueAndGetRequest(t, stub, cctest.GenerateMockTxID(""), &guaranteePB.GXIssueRequest{Gx: &initGX})
	flowID := issueReq.GetId()

	// Switch to Ben
	cctest.SetMockStubCert(t, stub, benOrgPEM)

	// Test that you can't revoke with wrong ID
	revokeActionBytes, err := ccutil.Marshal(&sharedPB.FlowActionRequest{FlowId: flowID, ActionId: "123124"})
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.RevokeAction), revokeActionBytes}
	res := stub.MockInvoke(cctest.GenerateMockTxID(""), args)
	if res.Status == shim.OK {
		t.Fatal("Expected test to fail as approve action doesn't exist")
	}

	// Approve flow
	invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})

	// check stored actions
	flowActions := invokeGetFlowActions(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID})

	// Extract approve action
	approveAction := flowActions.GetRequests()[1].GetFlowActionRequest()

	// Test that you can revoke the approve action
	invokeRevokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID, ActionId: approveAction.GetId()})

	// Test that you can reapprove after revoking
	invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})

	// Test that issuer can approve as well
	cctest.SetMockStubCert(t, stub, issuerOrgPEM)
	invokeApproveFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowActionRequest{FlowId: flowID})

	// Now updated with GX_ID
	storedIssueRequest := invokeGetFlow(t, stub, cctest.GenerateMockTxID(""), &sharedPB.FlowIDValue{Value: flowID}).GetGxIssueRequest()

	// Test that Guarantee exists in state
	storedGX, err := get(stub, storedIssueRequest.GetGxId())
	if err != nil {
		t.Fatal(err.Error())
	}

	// TODO check all fields match up, currently only checking ID
	if storedGX.GetId() != storedIssueRequest.GetGxId() {
		t.Fatalf("Error incorrect ID of stored gx, expected: %s, got: %s", storedIssueRequest.GetGxId(), storedGX.GetId())
	}
	checkGuaranteeStatus(t, storedGX.GetStatus(), guaranteePB.GXStatus_GX_ACTIVE)
}
