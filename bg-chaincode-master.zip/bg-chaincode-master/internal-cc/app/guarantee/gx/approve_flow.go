package gx

import (
	"errors"
	"fmt"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/guaranteeutil"
)

// ApproveFlow adds an approval to a flow
func (t *APICC) ApproveFlow(stub *guaranteePB.ChaincodeStub, flowActionRequest *sharedPB.FlowActionRequest) (*sharedPB.FlowActionRequest, error) {
	guaranteeutil.Setup()

	ccutil.Logger.Debugf("Processing ApproveFlow action %v\n", flowActionRequest)

	// Set ID
	flowActionRequest.Id = ccutil.GenerateFlowActionID(stub)
	ccutil.Logger.Infof("Action APPROVE flow (id: %v, flow: %v)\n", flowActionRequest.Id, flowActionRequest.GetFlowId())

	info, err := t.createCreatorInfo(stub)
	if err != nil {
		return nil, err
	}
	err = ccutil.SetCreatedMetadata(stub, flowActionRequest, info.organization.GetId())
	if err != nil {
		return nil, err
	}

	// Get Start Request (implicitly an approval)
	flowKey, err := ccutil.GenerateFlowKey(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}

	var startRequest guaranteePB.GXStartRequest
	err = ccutil.GetStatePB(stub, flowKey, &startRequest)
	if err != nil {
		return nil, err
	}

	baseRequest, err := getRequestFromStartRequest(&startRequest)
	if err != nil {
		return nil, err
	}

	// Check if Flow is active
	if baseRequest.GetStatus() != sharedPB.FlowStatus_FLOW_ACTIVE {
		return nil, errors.New("Request is not active")
	}

	// Get actions
	actions, err := getGXFlowActions(stub, flowActionRequest.GetFlowId())
	if err != nil {
		return nil, err
	}

	// Check if creator is allowed to approve
	allowedToApprove, err := isAllowedToApproveFlow(stub, &startRequest, actions, &info)
	if err != nil {
		return nil, err
	}
	if !allowedToApprove {
		return nil, errors.New("Organization is not allowed to approve request")
	}

	// Set RequestType
	flowActionRequest.RequestType = sharedPB.FlowActionRequestType_FLOW_ACTION_REQUEST_APPROVE

	// Do additional processing TODO move to different method
	if _, ok := startRequest.Request.(*guaranteePB.GXStartRequest_GxTransferRequest); ok {
		// Add new GX ID if is transfer
		newGXID, err := t.generateGXIDFromFlowID(stub, startRequest.GetGxTransferRequest().GetId())
		if err != nil {
			return nil, err
		}
		flowActionRequest.NewGxId = newGXID
	}

	// Write approval to state and emit event
	newAction := &guaranteePB.GXFlowActionRequest{Request: &guaranteePB.GXFlowActionRequest_FlowActionRequest{FlowActionRequest: flowActionRequest}}
	err = t.addAction(stub, flowActionRequest.GetFlowId(), newAction)
	if err != nil {
		return nil, err
	}
	actions = append(actions, newAction)

	// Finish flow if is issuer as issuer is always last approval, and has passed the aproval check
	if info.organization.GetEntityType() == profilePB.OrganizationEntityType_ORGANIZATION_ISSUER {
		err := t.finishFlow(stub, &startRequest, actions, &info)
		if err != nil {
			return nil, err
		}
	}

	stub.SetResponseCode(200)
	return flowActionRequest, nil
}

func isAllowedToApproveFlow(stub *guaranteePB.ChaincodeStub, startRequest *guaranteePB.GXStartRequest, actions []*guaranteePB.GXFlowActionRequest, cInfo *creatorInfo) (bool, error) {
	switch t := startRequest.Request.(type) {
	case *guaranteePB.GXStartRequest_GxIssueRequest:
		return isAllowedToApproveIssueFlow(stub, startRequest.GetGxIssueRequest(), actions, cInfo)
	case *guaranteePB.GXStartRequest_GxAmendRequest:
		return isAllowedToApproveStandardFlow(stub, startRequest.GetGxAmendRequest(), actions, cInfo)
	case *guaranteePB.GXStartRequest_GxDemandRequest:
		return isAllowedToApproveDemandFlow(stub, startRequest.GetGxDemandRequest(), actions, cInfo)
	case *guaranteePB.GXStartRequest_GxCancelRequest:
		return isAllowedToApproveCancelFlow(stub, startRequest.GetGxCancelRequest(), actions, cInfo)
	case *guaranteePB.GXStartRequest_GxTransferRequest:
		return isAllowedToApproveTransferFlow(stub, startRequest.GetGxTransferRequest(), actions, cInfo)
	default:
		return false, fmt.Errorf("Invalid Request Type %T", t)
	}
}

func isAllowedToApproveStandardFlow(stub *guaranteePB.ChaincodeStub, request gxModifyRequestInterface, actions []*guaranteePB.GXFlowActionRequest, cInfo *creatorInfo) (bool, error) {
	if prevApprovedFlow, err := hasActivePreviouslyCreatedOrApprovedFlow(request, actions, cInfo.organization.GetId()); prevApprovedFlow || err != nil {
		return false, err
	}

	gx, err := get(stub, request.GetGxId())
	if err != nil {
		return false, err
	}

	appBenList := append(gx.GetApplicants(), gx.GetBeneficiaries()...)
	numApprovals, err := countActiveApprovals(actions)
	if err != nil {
		return false, err
	}
	return checkApproveStandardFlowRequiredCount(stub, appBenList, numApprovals, cInfo)
}

func isAllowedToApproveCancelFlow(stub *guaranteePB.ChaincodeStub, request gxModifyRequestInterface, actions []*guaranteePB.GXFlowActionRequest, cInfo *creatorInfo) (bool, error) {
	if prevApprovedFlow, err := hasActivePreviouslyCreatedOrApprovedFlow(request, actions, cInfo.organization.GetId()); prevApprovedFlow || err != nil {
		return false, err
	}

	gx, err := get(stub, request.GetGxId())
	if err != nil {
		return false, err
	}

	var appBenAllowedToApproveList []string

	if ccutil.ContainsString(gx.GetBeneficiaries(), request.GetCreatedBy()) {
		appBenAllowedToApproveList = gx.GetBeneficiaries()
	} else {
		appBenAllowedToApproveList = append(gx.GetApplicants(), gx.GetBeneficiaries()...)
	}

	numApprovals, err := countActiveApprovals(actions)
	if err != nil {
		return false, err
	}
	return checkApproveStandardFlowRequiredCount(stub, appBenAllowedToApproveList, numApprovals, cInfo)
}

func isAllowedToApproveDemandFlow(stub *guaranteePB.ChaincodeStub, request gxModifyRequestInterface, actions []*guaranteePB.GXFlowActionRequest, cInfo *creatorInfo) (bool, error) {
	if prevApprovedFlow, err := hasActivePreviouslyCreatedOrApprovedFlow(request, actions, cInfo.organization.GetId()); prevApprovedFlow || err != nil {
		return false, err
	}

	gx, err := get(stub, request.GetGxId())
	if err != nil {
		return false, err
	}

	numApprovals, err := countActiveApprovals(actions)
	if err != nil {
		return false, err
	}
	return checkApproveDemandFlowRequiredCount(stub, gx.GetBeneficiaries(), numApprovals, cInfo)
}

func isAllowedToApproveIssueFlow(stub *guaranteePB.ChaincodeStub, request *guaranteePB.GXIssueRequest, actions []*guaranteePB.GXFlowActionRequest, cInfo *creatorInfo) (bool, error) {
	if prevApprovedFlow, err := hasActivePreviouslyCreatedOrApprovedFlow(request, actions, cInfo.organization.GetId()); prevApprovedFlow || err != nil {
		return false, err
	}

	gx := request.GetGx()

	appBenList := append(gx.GetApplicants(), gx.GetBeneficiaries()...)
	numApprovals, err := countActiveApprovals(actions)
	if err != nil {
		return false, err
	}
	return checkApproveStandardFlowRequiredCount(stub, appBenList, numApprovals, cInfo)
}

func isAllowedToApproveTransferFlow(stub *guaranteePB.ChaincodeStub, request *guaranteePB.GXTransferRequest, actions []*guaranteePB.GXFlowActionRequest, cInfo *creatorInfo) (bool, error) {
	if prevApprovedFlow, err := hasActivePreviouslyCreatedOrApprovedFlow(request, actions, cInfo.organization.GetId()); prevApprovedFlow || err != nil {
		return false, err
	}

	gx, err := get(stub, request.GetGxId())
	if err != nil {
		return false, err
	}

	// Get unique beneficiaries
	commonBenMap := make(map[string]bool)
	for _, ben := range append(gx.GetBeneficiaries(), request.GetBeneficiaries()...) {
		commonBenMap[ben] = true
	}
	commonBenList := make([]string, len(commonBenMap))
	i := 0
	for ben := range commonBenMap {
		commonBenList[i] = ben
		i++
	}

	var appBenAllowedToApproveList []string

	if ccutil.ContainsString(gx.GetBeneficiaries(), request.GetCreatedBy()) {
		// Applicant does not need to approve if beneficiary initiated
		appBenAllowedToApproveList = commonBenList
	} else {
		appBenAllowedToApproveList = append(gx.GetApplicants(), commonBenList...)
	}
	numApprovals, err := countActiveApprovals(actions)
	if err != nil {
		return false, err
	}

	return checkApproveStandardFlowRequiredCount(stub, appBenAllowedToApproveList, numApprovals, cInfo)
}

func checkApproveStandardFlowRequiredCount(stub *guaranteePB.ChaincodeStub, appBenList []string, numApprovals int, cInfo *creatorInfo) (bool, error) {
	organization := cInfo.organization
	requiredAppBenCount := len(appBenList)

	isIssuerRes, err := isIssuer(stub, cInfo)
	if err != nil {
		return false, err
	}

	return ((numApprovals+1 < requiredAppBenCount &&
		organization.GetEntityType() == profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY &&
		ccutil.ContainsString(appBenList, organization.GetId())) ||
		(numApprovals+1 == requiredAppBenCount && isIssuerRes)), nil
}

func checkApproveDemandFlowRequiredCount(stub *guaranteePB.ChaincodeStub, benList []string, numApprovals int, cInfo *creatorInfo) (bool, error) {
	organization := cInfo.organization
	requiredBenCount := len(benList)

	isIssuerRes, err := isIssuer(stub, cInfo)
	if err != nil {
		return false, err
	}

	return ((numApprovals+1 < requiredBenCount &&
		organization.GetEntityType() == profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY &&
		ccutil.ContainsString(benList, organization.GetId())) ||
		(numApprovals+1 == requiredBenCount && isIssuerRes)), nil
}
