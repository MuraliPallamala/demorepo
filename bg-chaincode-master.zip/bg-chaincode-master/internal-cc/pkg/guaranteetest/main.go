package guaranteetest

import (
	"testing"

	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	guaranteePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/guarantee"
)

// SetupChaincodeMockStub initialises a MockStub with the profile chaincode and an example certificate
func SetupChaincodeMockStub(t *testing.T, profileStub *cctest.MockStub, gxAPICC guaranteePB.GXAPIInterface) *cctest.MockStub {
	t.Helper()
	// create an instance of the weave struct that satisfies the chaincode stub interface
	cc := guaranteePB.New(gxAPICC)

	stub := cctest.NewMockStub("guarantee", &cc)

	// set channel ID
	stub.ChannelID = "anz-channel"

	// set default cert
	cctest.SetMockStubCert(t, stub, cctest.ANZPEM)

	// chaincode init
	cctest.PerformCCInit(t, stub, [][]byte{[]byte("init"), []byte(`{
		"prefix":"000002",
		"platformChannelId":"platform-channel",
		"profileCc":"profile",
		"newcoMspId":"newco"
	}`)})

	// set profile chaincode as invokable
	stub.MockPeerChaincode("profile/platform-channel", profileStub)

	return stub
}
