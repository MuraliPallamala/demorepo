package cctest

import (
	"container/list"

	"github.com/hyperledger/fabric/core/chaincode/shim"

	pb "github.com/hyperledger/fabric/protos/peer"
)

// MockStub is an extension of the regular fabric mock stub with extra methods
type MockStub struct {
	*shim.MockStub

	// arguments the stub was called with
	args [][]byte

	// A pointer back to the chaincode that will invoke this, set by constructor.
	// If a peer calls this stub, the chaincode will be invoked from here.
	cc shim.Chaincode

	// mocked Creator
	Creator []byte

	// registered list of other MockStub chaincodes that can be called from this MockStub
	Invokables map[string]*MockStub

	// mocked signedProposal
	signedProposal *pb.SignedProposal

	// event that's been set
	Event MockEvent
}

// MockEvent is a mock structure for an Event (name, payload) pair
type MockEvent struct {
	Name    string
	Payload []byte
}

// GetCreator returns the creator for the stub
func (stub *MockStub) GetCreator() ([]byte, error) {

	return stub.Creator, nil
}

// NewMockStub is a Constructor to Init the internal State map
func NewMockStub(name string, cc shim.Chaincode) *MockStub {
	s := new(MockStub)

	s.MockStub = shim.NewMockStub(name, cc)
	s.cc = cc
	s.Invokables = make(map[string]*MockStub)
	s.Keys = list.New()

	return s
}

// MockPeerChaincode registers a peer chaincode with this MockStub
// invokableChaincodeName is the name or hash of the peer
// otherStub is a MockStub of the peer, already intialised
func (stub *MockStub) MockPeerChaincode(invokableChaincodeName string, otherStub *MockStub) {
	stub.Invokables[invokableChaincodeName] = otherStub
}

// InvokeChaincode calls a peered chaincode.
// E.g. stub1.InvokeChaincode("stub2Hash", funcArgs, channel)
// Before calling this make sure to create another MockStub stub2, call stub2.MockInit(uuid, func, args)
// and register it with stub1 by calling stub1.MockPeerChaincode("stub2Hash", stub2)
func (stub *MockStub) InvokeChaincode(chaincodeName string, args [][]byte, channel string) pb.Response {
	// Internally we use chaincode name as a composite name
	if channel != "" {
		chaincodeName = chaincodeName + "/" + channel
	}
	// TODO "args" here should possibly be a serialized pb.ChaincodeInput
	otherStub := stub.Invokables[chaincodeName]
	//	function, strings := getFuncArgs(args)
	res := otherStub.MockInvoke(stub.TxID, args)
	return res
}

// GetArgs retrieves the arguments
func (stub *MockStub) GetArgs() [][]byte {
	return stub.args
}

// GetStringArgs retrieves the arguments as strings
func (stub *MockStub) GetStringArgs() []string {
	args := stub.GetArgs()
	strargs := make([]string, 0, len(args))
	for _, barg := range args {
		strargs = append(strargs, string(barg))
	}
	return strargs
}

// GetFunctionAndParameters retrieves the function name and arguments as strings
func (stub *MockStub) GetFunctionAndParameters() (function string, params []string) {
	allargs := stub.GetStringArgs()
	function = ""
	params = []string{}
	if len(allargs) >= 1 {
		function = allargs[0]
		params = allargs[1:]
	}
	return
}

// MockInit initialises this chaincode, also starts and ends a transaction.
func (stub *MockStub) MockInit(uuid string, args [][]byte) pb.Response {
	stub.args = args
	stub.MockTransactionStart(uuid)
	res := stub.cc.Init(stub)
	stub.MockTransactionEnd(uuid)
	return res
}

// MockInvoke invokes this chaincode, also starts and ends a transaction.
func (stub *MockStub) MockInvoke(uuid string, args [][]byte) pb.Response {
	stub.args = args
	stub.MockTransactionStart(uuid)
	res := stub.cc.Invoke(stub)
	stub.MockTransactionEnd(uuid)
	return res
}

// MockInvokeWithSignedProposal invokes this chaincode, also starts and ends a transaction.
func (stub *MockStub) MockInvokeWithSignedProposal(uuid string, args [][]byte, sp *pb.SignedProposal) pb.Response {
	stub.args = args
	stub.MockTransactionStart(uuid)
	stub.signedProposal = sp
	res := stub.cc.Invoke(stub)
	stub.MockTransactionEnd(uuid)
	return res
}

// SetEvent sets the current event payload
func (stub *MockStub) SetEvent(name string, payload []byte) error {
	stub.Event = MockEvent{Name: name, Payload: payload}
	return nil
}
