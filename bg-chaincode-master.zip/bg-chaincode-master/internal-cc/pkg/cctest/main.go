package cctest

import (
	"math/rand"
	"testing"

	proto "github.com/gogo/protobuf/proto"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	mspprotos "github.com/hyperledger/fabric/protos/msp"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

/*
cctest is a Test Utility Package
*/

// ConsortiumPEM is an example public certificate in pem format (Development)
var ConsortiumPEM = `
-----BEGIN CERTIFICATE-----
MIIB+DCCAZ6gAwIBAgIQQPWR7DguAQzqV8Gk/5LBnzAKBggqhkjOPQQDAjBdMQsw
CQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNU2FuIEZy
YW5jaXNjbzEOMAwGA1UEChMFbmV3Y28xETAPBgNVBAMTCGNhLm5ld2NvMB4XDTE4
MDUyODAxMDY1NFoXDTI4MDUyNTAxMDY1NFowUDELMAkGA1UEBhMCVVMxEzARBgNV
BAgTCkNhbGlmb3JuaWExFjAUBgNVBAcTDVNhbiBGcmFuY2lzY28xFDASBgNVBAMM
C0FkbWluQG5ld2NvMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEJNQmeknMVLCf
5LcScPPxP8lc7hI+Wi++r9gaVpZcGJumhJPyzKVZq+MzmazWugnJEwrjLvA4OLMy
563URgTl8aNNMEswDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwKwYDVR0j
BCQwIoAgj7dYLldhHkbqU0CdZi+ZEwiSEeoGRn/uIofc2zZNuCUwCgYIKoZIzj0E
AwIDSAAwRQIhAKcLr77fCxL0eOcgWA/lasycYyv1MpJrDjBmI3I8jASLAiAG8FAi
YJ5bqFOzjFXqnO7jSzqili3wcoaJLYidW2X5CQ==
-----END CERTIFICATE-----`

// ConsortiumPEM is an example public certificate in pem format (IBP)
// var ConsortiumPEM = `
// -----BEGIN CERTIFICATE-----
// MIICWzCCAgGgAwIBAgIUKv9UKj8YXvKrwlF0DJPkzf9Si5IwCgYIKoZIzj0EAwIw
// RTEoMAkGA1UECxMCY2EwCgYDVQQLEwNpYnAwDwYDVQQLEwhQZWVyT3JnMTEZMBcG
// A1UEAxMQYWRtaW5QZWVyT3JnMUNBMTAeFw0xODEyMDUwMTM0MDBaFw0xOTEyMDUw
// MTM5MDBaMEUxLDANBgNVBAsTBmNsaWVudDAKBgNVBAsTA2licDAPBgNVBAsTCFBl
// ZXJPcmcxMRUwEwYDVQQDEwxuZXdjby1hZG1pbjIwWTATBgcqhkjOPQIBBggqhkjO
// PQMBBwNCAARnjLmUIPJF1DBxH7E809ALyXC77CH+QR005eJg69RBxJHnAV6iRS64
// tFi0I6U9FIQd0VtRXYjpZw+6++QE3cfJo4HOMIHLMA4GA1UdDwEB/wQEAwIHgDAM
// BgNVHRMBAf8EAjAAMB0GA1UdDgQWBBRJfp0SHylZhOdIIslwVzfZFptIGjAfBgNV
// HSMEGDAWgBS01NYVYeDAx5Fn8bWCKxCx1KgBhTBrBggqAwQFBgcIAQRfeyJhdHRy
// cyI6eyJoZi5BZmZpbGlhdGlvbiI6ImlicC5QZWVyT3JnMSIsImhmLkVucm9sbG1l
// bnRJRCI6Im5ld2NvLWFkbWluMiIsImhmLlR5cGUiOiJjbGllbnQifX0wCgYIKoZI
// zj0EAwIDSAAwRQIhAJahM3q9ma7Mo3qL6rB2ynq3qIJBOuFoRrfrKj4GN32IAiAc
// sYbwuvjtxAUoIwOey/N5mtjr4+/mHcT5mWjGuRe+Hw==
// -----END CERTIFICATE-----
// `

// ANZPEM is an example public certificate in pem format
var ANZPEM = `
-----BEGIN CERTIFICATE-----
MIIB8zCCAZmgAwIBAgIRAImxF3CHzxq5gH3MMAKrDv8wCgYIKoZIzj0EAwIwWTEL
MAkGA1UEBhMCVVMxEzARBgNVBAgTCkNhbGlmb3JuaWExFjAUBgNVBAcTDVNhbiBG
cmFuY2lzY28xDDAKBgNVBAoTA2FuejEPMA0GA1UEAxMGY2EuYW56MB4XDTE4MDUy
ODAxMDY1NFoXDTI4MDUyNTAxMDY1NFowTjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
CkNhbGlmb3JuaWExFjAUBgNVBAcTDVNhbiBGcmFuY2lzY28xEjAQBgNVBAMMCUFk
bWluQGFuejBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IABG3Z+1bDVZ3bNfrU9QRW
qUNrBYNudeo2Pi4d9ozrBZT15D9GgjW0yjhe1XVBiO+yE8L/YjYW5dO/ytt5/cp2
PXGjTTBLMA4GA1UdDwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMCsGA1UdIwQkMCKA
INQXXyXeB2dRp3r9oL292TLW+9fE4k+rmQdlasjBOopRMAoGCCqGSM49BAMCA0gA
MEUCIQDcMBkcwXZaVHipa2aZGARysnjjW2hC31/Xn2tqRxHcaAIgK05BW9cZtyQw
XKRvP0E/e25LGDIxTBwOowsMvvPLrqM=
-----END CERTIFICATE-----`

// CommbankPEM is an example public certificate in pem format
var CommbankPEM = `
-----BEGIN CERTIFICATE-----
MIICADCCAaegAwIBAgIQHwpG0ktbKxw0sE15G9AdVjAKBggqhkjOPQQDAjBjMQsw
CQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNU2FuIEZy
YW5jaXNjbzERMA8GA1UEChMIY29tbWJhbmsxFDASBgNVBAMTC2NhLmNvbW1iYW5r
MB4XDTE4MDUyODAxMDY1NFoXDTI4MDUyNTAxMDY1NFowUzELMAkGA1UEBhMCVVMx
EzARBgNVBAgTCkNhbGlmb3JuaWExFjAUBgNVBAcTDVNhbiBGcmFuY2lzY28xFzAV
BgNVBAMMDkFkbWluQGNvbW1iYW5rMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE
2SxLJlBanf4nbV8GAPyWbulIxRP5wsjsvte/h84eEJ89HAhq6kBV3KsKGntem8uO
gn6P+vkPwvN2YKeB1zdbdqNNMEswDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQC
MAAwKwYDVR0jBCQwIoAg44MwMmkExe2fwUzPVCJQPNpIzJItklTDNEpfDrwnANkw
CgYIKoZIzj0EAwIDRwAwRAIgRpMLLA6V99QXmWmqAB6EUHl8oWJr/nj44NhrcfUd
PngCIGhKpjzmS41GqdupIUW5mKNLKOOcXVd36Uj8p1XVGTM+
-----END CERTIFICATE-----`

// NABPEM is an example public certificate in pem format
var NABPEM = `
-----BEGIN CERTIFICATE-----
MIIB8zCCAZmgAwIBAgIRAKWrSEP89Rmpxwn4dJMT7/wwCgYIKoZIzj0EAwIwWTEL
MAkGA1UEBhMCVVMxEzARBgNVBAgTCkNhbGlmb3JuaWExFjAUBgNVBAcTDVNhbiBG
cmFuY2lzY28xDDAKBgNVBAoTA25hYjEPMA0GA1UEAxMGY2EubmFiMB4XDTE4MDUy
ODAxMDY1NFoXDTI4MDUyNTAxMDY1NFowTjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
CkNhbGlmb3JuaWExFjAUBgNVBAcTDVNhbiBGcmFuY2lzY28xEjAQBgNVBAMMCUFk
bWluQG5hYjBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IABFZ+56z8EySDgIapLWFk
jviJ4fkVlKo3iBhjUmWlMXB08jt+MTdVJ76HWNpnpPW2fQ9UmfDyArZmLv5GQxpb
BoijTTBLMA4GA1UdDwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMCsGA1UdIwQkMCKA
IA9jWA32f1tJnWmTc6uETlr3sxFulMafC98d6gdx64PdMAoGCCqGSM49BAMCA0gA
MEUCIQCnuCvlDUzu5SbA0TiMUd2mgpbBQ1PPn0othlCx0lIKTwIgb8b6b9rD63lf
a0JNblhPGpLD4VTbRpEeDbU9Ilzut44=
-----END CERTIFICATE-----`

// WestpacPEM is an example public certificate in pem format
var WestpacPEM = `
-----BEGIN CERTIFICATE-----
MIIB/jCCAaSgAwIBAgIQZaSjrnY9IltGWo7AR2LYqDAKBggqhkjOPQQDAjBhMQsw
CQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNU2FuIEZy
YW5jaXNjbzEQMA4GA1UEChMHd2VzdHBhYzETMBEGA1UEAxMKY2Eud2VzdHBhYzAe
Fw0xODA1MjgwMTA2NTRaFw0yODA1MjUwMTA2NTRaMFIxCzAJBgNVBAYTAlVTMRMw
EQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1TYW4gRnJhbmNpc2NvMRYwFAYD
VQQDDA1BZG1pbkB3ZXN0cGFjMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE/u4W
klv2gCdND2qFwDzVoZMRNC0Qus6svsq0Ax34beFQXlaldkLuv5P18IXW7oAAZLoM
+cgA0ZtrdCGP6UeFE6NNMEswDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAw
KwYDVR0jBCQwIoAgP+wy/JQq6vXKCAFqoSqDEWnxqWPib+QyZ9/5OmF7lfIwCgYI
KoZIzj0EAwIDSAAwRQIhAPDDOFLUS3AYDkbWpW7yEB6YCOtJ7K5iZkWOPyaExD0A
AiBEGsDlxKl25vVKSFSXbrfjOQRabGxvsgFxGrbhwb5N2Q==
-----END CERTIFICATE-----`

// AppBenPEM1 is an example public certificate in pem format
var AppBenPEM1 = `
-----BEGIN CERTIFICATE-----
MIICVDCCAfoCCQDHDIMm2vKjTTAKBggqhkjOPQQDAjCBsTELMAkGA1UEBhMCSUwx
DzANBgNVBAgMBk9yZWdvbjERMA8GA1UEBwwIUG9ydGxhbmQxDjAMBgNVBAoMBW5l
d2NvMRMwEQYDVQQDDApDb21tb25OYW1lMRIwEAYDVQQqDAlHaXZlbk5hbWUxETAP
BgNVBAQMCFN1cmVOYW1lMSEwHwYJKoZIhvcNAQkBFhJlbWFpbEBhZGRyZXNzcy5j
b20xDzANBgNVBAUTBjEyMzQ1NjAeFw0xOTAxMDIwMjQ4MTNaFw0yMTAxMDEwMjQ4
MTNaMIGxMQswCQYDVQQGEwJJTDEPMA0GA1UECAwGT3JlZ29uMREwDwYDVQQHDAhQ
b3J0bGFuZDEOMAwGA1UECgwFbmV3Y28xEzARBgNVBAMMCkNvbW1vbk5hbWUxEjAQ
BgNVBCoMCUdpdmVuTmFtZTERMA8GA1UEBAwIU3VyZU5hbWUxITAfBgkqhkiG9w0B
CQEWEmVtYWlsQGFkZHJlc3NzLmNvbTEPMA0GA1UEBRMGMTIzNDU2MFkwEwYHKoZI
zj0CAQYIKoZIzj0DAQcDQgAEv86BdvKi0AHSBQ4HtOMtmHqMblqR2HmaCsBFNqvy
vWqnUoSrnyPZx7DEyFdZoJrR6tEcDV9J9N+N5ltDPDHgiTAKBggqhkjOPQQDAgNI
ADBFAiBe4lUmAl1rqJRkjfG0v7BLJ4mWiixZnREhhlppC4R8cgIhAPvBBg5m2TOW
K+1fZogCcn1d8gH/W1isF6Yk0XlpEayF
-----END CERTIFICATE-----`

// AppBenPEM2 is an example public certificate in pem format
var AppBenPEM2 = `
-----BEGIN CERTIFICATE-----
MIICUzCCAfoCCQCOXSYOw67ogjAKBggqhkjOPQQDAjCBsTELMAkGA1UEBhMCSUwx
DzANBgNVBAgMBk9yZWdvbjERMA8GA1UEBwwIUG9ydGxhbmQxDjAMBgNVBAoMBW5l
d2NvMRMwEQYDVQQDDApDb21tb25OYW1lMRIwEAYDVQQqDAlHaXZlbk5hbWUxETAP
BgNVBAQMCFN1cmVOYW1lMSEwHwYJKoZIhvcNAQkBFhJlbWFpbEBhZGRyZXNzcy5j
b20xDzANBgNVBAUTBjEyMzQ1NjAeFw0xOTAxMDIwMjUwMzhaFw0yMTAxMDEwMjUw
MzhaMIGxMQswCQYDVQQGEwJJTDEPMA0GA1UECAwGT3JlZ29uMREwDwYDVQQHDAhQ
b3J0bGFuZDEOMAwGA1UECgwFbmV3Y28xEzARBgNVBAMMCkNvbW1vbk5hbWUxEjAQ
BgNVBCoMCUdpdmVuTmFtZTERMA8GA1UEBAwIU3VyZU5hbWUxITAfBgkqhkiG9w0B
CQEWEmVtYWlsQGFkZHJlc3NzLmNvbTEPMA0GA1UEBRMGMTIzNDU2MFkwEwYHKoZI
zj0CAQYIKoZIzj0DAQcDQgAEqP7TXIRhRlAeGcO09snK8+IobH1RYqs4PK63d0LW
HdBoQfguhz+2a3Ug4LPfHqJTRxhG0pEcT+YAqoB3JmVonjAKBggqhkjOPQQDAgNH
ADBEAiBQs50N2gqdNHFlOQqWEXo7zeVScY+X4wGXLAd4JhRyigIgKmurXmOQKVe4
APIK3+ZLt+rZpWXkkopaD9Nz5cvKGZ8=
-----END CERTIFICATE-----`

// AppBenPEM3 is an example public certificate in pem format
var AppBenPEM3 = `
-----BEGIN CERTIFICATE-----
MIICVTCCAfoCCQC5a4O5TtTwIzAKBggqhkjOPQQDAjCBsTELMAkGA1UEBhMCSUwx
DzANBgNVBAgMBk9yZWdvbjERMA8GA1UEBwwIUG9ydGxhbmQxDjAMBgNVBAoMBW5l
d2NvMRMwEQYDVQQDDApDb21tb25OYW1lMRIwEAYDVQQqDAlHaXZlbk5hbWUxETAP
BgNVBAQMCFN1cmVOYW1lMSEwHwYJKoZIhvcNAQkBFhJlbWFpbEBhZGRyZXNzcy5j
b20xDzANBgNVBAUTBjEyMzQ1NjAeFw0xOTAxMDIwMjUwNTlaFw0yMTAxMDEwMjUw
NTlaMIGxMQswCQYDVQQGEwJJTDEPMA0GA1UECAwGT3JlZ29uMREwDwYDVQQHDAhQ
b3J0bGFuZDEOMAwGA1UECgwFbmV3Y28xEzARBgNVBAMMCkNvbW1vbk5hbWUxEjAQ
BgNVBCoMCUdpdmVuTmFtZTERMA8GA1UEBAwIU3VyZU5hbWUxITAfBgkqhkiG9w0B
CQEWEmVtYWlsQGFkZHJlc3NzLmNvbTEPMA0GA1UEBRMGMTIzNDU2MFkwEwYHKoZI
zj0CAQYIKoZIzj0DAQcDQgAE9+iuOmV73L4hNKiElp/tbeqxmWot2tXW/yGAKe1L
pfuFSxXgWBQcaACuOBNi9ymacrQjrI66MZJt8jWfN6BA+jAKBggqhkjOPQQDAgNJ
ADBGAiEArptnbTeHhukYXeDQlBBqo+H2eVYdg8+mBB9GHimdjFoCIQCMlfUTggLa
cV655mHJy8z6F8XP9uv7B9TYitdugzdEfg==
-----END CERTIFICATE-----`

// AppBenPEM4 is an example public certificate in pem format
var AppBenPEM4 = `
-----BEGIN CERTIFICATE-----
MIICUzCCAfoCCQDuOhknNV47/TAKBggqhkjOPQQDAjCBsTELMAkGA1UEBhMCSUwx
DzANBgNVBAgMBk9yZWdvbjERMA8GA1UEBwwIUG9ydGxhbmQxDjAMBgNVBAoMBW5l
d2NvMRMwEQYDVQQDDApDb21tb25OYW1lMRIwEAYDVQQqDAlHaXZlbk5hbWUxETAP
BgNVBAQMCFN1cmVOYW1lMSEwHwYJKoZIhvcNAQkBFhJlbWFpbEBhZGRyZXNzcy5j
b20xDzANBgNVBAUTBjEyMzQ1NjAeFw0xOTAxMDIwMjUxMTZaFw0yMTAxMDEwMjUx
MTZaMIGxMQswCQYDVQQGEwJJTDEPMA0GA1UECAwGT3JlZ29uMREwDwYDVQQHDAhQ
b3J0bGFuZDEOMAwGA1UECgwFbmV3Y28xEzARBgNVBAMMCkNvbW1vbk5hbWUxEjAQ
BgNVBCoMCUdpdmVuTmFtZTERMA8GA1UEBAwIU3VyZU5hbWUxITAfBgkqhkiG9w0B
CQEWEmVtYWlsQGFkZHJlc3NzLmNvbTEPMA0GA1UEBRMGMTIzNDU2MFkwEwYHKoZI
zj0CAQYIKoZIzj0DAQcDQgAE8KlsmW0ZBaVZRZVkNu9aZ7sL1MzU/Y0L8mDzgrJk
TL4LTmHuN3lv2idrD5Fvzi79TJuZWiXYKHN1+cN2EnXQuDAKBggqhkjOPQQDAgNH
ADBEAiBcuutVuAAWmSNEvGWR3GK1cPlsGxzmDR26HHY+BAtmogIgAhsHmmssLzvh
M9MHalNKFz4x4goRjfFu0Sdwn7ZKa7U=
-----END CERTIFICATE-----`

// SetMockStubCert sets the certificate of a MockStub
func SetMockStubCert(t *testing.T, stub *MockStub, pem string) {
	t.Helper()
	creator, err := GenerateCreatorCert(pem)
	if err != nil {
		t.Fatalf("Count not create certificate: %s", err.Error())
	}

	stub.Creator = creator
}

// PerformCCInit is a helper function to run Init to initial any required data
func PerformCCInit(t *testing.T, stub *MockStub, args [][]byte) {
	t.Helper()
	res := stub.MockInit(GenerateMockTxID(""), args)
	if res.Status != shim.OK {
		t.Errorf("DefaultChaincode Init failed: %s", res.Message)
		t.FailNow()
	}
}

// GenerateMockTxID generates a mock tx ID
func GenerateMockTxID(prefix string) string {
	if prefix == "" {
		prefix = "Tx"
	}

	mockTxID := prefix + randSeq(64-len(prefix))
	return mockTxID
}

var letters = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

func randSeq(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letters[rand.Intn(len(letters))]
	}
	return string(b)
}

// GenerateCreatorCert generates a marshalled mspprotos.SerializedIdentity from a pem certificate
func GenerateCreatorCert(certPEM string) ([]byte, error) {
	id := mspprotos.SerializedIdentity{
		Mspid:   "example_org",
		IdBytes: []byte(certPEM),
	}

	return proto.Marshal(&id)
}

// GenerateFlowActionRequestBytes generates an example FlowActionRequest and serializes it to json in byte form
func GenerateFlowActionRequestBytes(t *testing.T, flowID string) []byte {
	t.Helper()
	request := &sharedPB.FlowActionRequest{FlowId: flowID}

	// marshal the payload
	requestString, err := ccutil.Marshal(request)

	if err != nil {
		t.Fatalf("Could not marshal StartRequest: %s", err.Error())
	}

	return []byte(requestString)
}
