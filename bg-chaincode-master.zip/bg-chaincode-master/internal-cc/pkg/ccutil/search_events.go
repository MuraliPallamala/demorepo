package ccutil

import (
	"sort"
	"time"

	"github.com/gogo/protobuf/types"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

// EventInterface is an interface for Events
type EventInterface interface {
	GetId() string
	GetCreatedAt() *types.Timestamp
}

// EventSort sorts an array of events
// TODO replace with couch queries
func EventSort(events []EventInterface) {
	sort.Slice(events, func(i, j int) bool {
		createdAtI, err := types.TimestampFromProto(events[i].GetCreatedAt())
		if err != nil {
			return false
		}
		createdAtJ, err := types.TimestampFromProto(events[j].GetCreatedAt())
		if err != nil {
			return true
		}
		return createdAtI.Before(createdAtJ)
	})
}

// EventSearchFilter filters an array of events
// TODO replace with couch queries
func EventSearchFilter(stub shim.ChaincodeStubInterface, events []EventInterface, searchRequest *sharedPB.EventSearchRequest) (*EventPaginationResult, error) {
	return eventCouchFilter(events, searchRequest)
}

// EventPaginationResult is the result of couchbased pagination
type EventPaginationResult struct {
	Events []EventInterface
	Next   string
}

// TODO replace with couch queries
func eventCouchFilter(events []EventInterface, searchRequest *sharedPB.EventSearchRequest) (*EventPaginationResult, error) {
	filteredEvents := make([]EventInterface, 0)
	limit := int(searchRequest.GetLimit())
	var next string

	foundStart := false
	for _, event := range events {

		// skip till start ID if specified
		if searchRequest.GetStart() != "" && !foundStart {
			if event.GetId() == searchRequest.GetStart() {
				foundStart = true
			} else {
				continue
			}
		}

		if next != "" {
			break
		}

		var eventCreatedAt time.Time
		var searchCreatedAfter time.Time
		var err error

		eventCreatedAt, err = types.TimestampFromProto(event.GetCreatedAt())
		if err != nil {
			return nil, err
		}

		if searchRequest.GetCreatedAfter() != nil {
			searchCreatedAfter, err = types.TimestampFromProto(searchRequest.GetCreatedAfter())
			if err != nil {
				return nil, err
			}
		}

		if searchRequest.GetCreatedAfter() == nil || eventCreatedAt.After(searchCreatedAfter) {
			if len(filteredEvents) < limit {
				filteredEvents = append(filteredEvents, event)
			} else {
				next = event.GetId()
			}
		}
	}

	return &EventPaginationResult{
		Events: filteredEvents,
		Next:   next,
	}, nil
}
