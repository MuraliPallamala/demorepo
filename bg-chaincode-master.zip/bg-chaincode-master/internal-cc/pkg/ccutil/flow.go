package ccutil

import (
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
)

// GenerateFlowID uses txId[0:36] to generate an ID
func GenerateFlowID(stub shim.ChaincodeStubInterface) string {
	// TODO potentially format to match uuid format
	// Note since we are only using the first 36 characters of the txID this is not guaranteed to be unique.
	return fmt.Sprintf("%s", stub.GetTxID()[:36])
}

// GenerateFlowActionID is currently identical to GenerateFlowActionId
func GenerateFlowActionID(stub shim.ChaincodeStubInterface) string {
	return GenerateFlowID(stub)
}

// GenerateFlowKey generates the key for storing a flow
func GenerateFlowKey(stub shim.ChaincodeStubInterface, flowID string) (string, error) {
	return stub.CreateCompositeKey(OTFlow, []string{flowID})
}

// GetFlowIDFromFlowKey extracts a FlowKey from a FlowID
func GetFlowIDFromFlowKey(stub shim.ChaincodeStubInterface, flowKey string) (string, error) {
	_, attributes, err := stub.SplitCompositeKey(flowKey)
	if err != nil {
		return "", err
	}
	return attributes[0], nil
}

// GenerateFlowActionKey generates the key to use for flow action requests. NOTE currently assumes num >= 0 && num < 1000000
func GenerateFlowActionKey(stub shim.ChaincodeStubInterface, flowID string, num int) (string, error) {
	return stub.CreateCompositeKey(OTFlowAction, []string{flowID, fmt.Sprintf("%06d", num)})
}

// GenerateFlowActionIterator generates an interator over all actions of a flow. Note this does not include the intial request
func GenerateFlowActionIterator(stub shim.ChaincodeStubInterface, flowID string) (shim.StateQueryIteratorInterface, error) {
	return stub.GetStateByPartialCompositeKey(OTFlowAction, []string{flowID})
}

// GenerateFlowIterator generates an interator over all flows
func GenerateFlowIterator(stub shim.ChaincodeStubInterface) (shim.StateQueryIteratorInterface, error) {
	return stub.GetStateByPartialCompositeKey(OTFlow, []string{})
}
