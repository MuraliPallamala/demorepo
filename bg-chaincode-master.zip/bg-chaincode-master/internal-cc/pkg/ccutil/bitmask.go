package ccutil

// Bitmask is a bitmask datastructure storing up to 32 flags
type Bitmask uint32

// Set sets the flag to true
func (b *Bitmask) Set(flag Bitmask) {
	*b = *b | flag
}

// Clear sets the flag to false
func (b *Bitmask) Clear(flag Bitmask) {
	*b = *b &^ flag
}

// Toggle toggles the flag
func (b *Bitmask) Toggle(flag Bitmask) {
	*b = *b ^ flag
}

// Has checks whether the flag exists
func (b Bitmask) Has(flag Bitmask) bool {
	return b&flag != 0
}
