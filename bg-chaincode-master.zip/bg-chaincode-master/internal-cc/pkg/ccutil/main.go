package ccutil

import (
	"crypto/ecdsa"
	"crypto/x509"
	"encoding/binary"
	"encoding/pem"
	"errors"
	"hash/fnv"
	"reflect"
	"strconv"
	"sync"
	"time"

	"fmt"
	"log"
	"os"

	proto "github.com/gogo/protobuf/proto"
	"github.com/gogo/protobuf/types"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	mspprotos "github.com/hyperledger/fabric/protos/msp"
)

const (
	// OTSystemProperties is the ObjectType for System Properties
	OTSystemProperties = "SYSTEM_PROPERTIES"
)

const (
	// SPKeyNewcoMspID is the SystemProperty key for the newco MSP IP value
	SPKeyNewcoMspID = "newcoMspID"
)

// initialize a logger
var logger = log.New(os.Stdout, "CCLOG: ", log.Ldate|log.Ltime|log.Lshortfile)

// OrganizationMethodsType is a type for the methods of the OrganizationAPI
type OrganizationMethodsType struct {
	StartFlow       string
	ApproveFlow     string
	CancelFlow      string
	RejectFlow      string
	AdminUpdate     string
	Get             string
	GetViaPublicKey string
	Deactivate      string
	Activate        string
	Search          string
	SearchFlows     string
	GetFlow         string
	GetFlowActions  string
	GetPublicKeys   string
	ActivateKey     string
	DeactivateKey   string
	SearchEvents    string
	GetEvent        string
}

// TCMethodsType is a type for the methods of the TermsConditionsAPI
type TCMethodsType struct {
	Get    string
	Search string
	Create string
	Update string
}

// GXMethodsType is a type for the methods of the GXAPI
type GXMethodsType struct {
	StartFlow      string
	RecallFlow     string
	ApproveFlow    string
	RevokeAction   string
	CancelFlow     string
	RejectFlow     string
	DeferFlow      string
	Search         string
	Get            string
	SearchFlows    string
	GetFlow        string
	GetFlowActions string
	SearchEvents   string
	GetEvent       string
}

// PurposeFormatMethodsType is a type for the methods of the purpose format API
type PurposeFormatMethodsType struct {
	Create string
	Get    string
	GetAll string
}

// ProfileCCMethodsType is a type for the methods of the Profile Chaincode
type ProfileCCMethodsType struct {
	Organization  OrganizationMethodsType
	TC            TCMethodsType
	PurposeFormat PurposeFormatMethodsType
}

// GuaranteeCCMethodsType is a type for the methods of the Guarantee Chaincode
type GuaranteeCCMethodsType struct {
	GX GXMethodsType
}

// PurposeFormatCCMethodsType is a type for the methods of the profile chaincode related to purpose formats
type PurposeFormatCCMethodsType struct {
	PurposeFormat PurposeFormatMethodsType
}

// CCMethodsType is a type for the methods of all chaincodes
type CCMethodsType struct {
	Profile       ProfileCCMethodsType
	Guarantee     GuaranteeCCMethodsType
	PurposeFormat PurposeFormatCCMethodsType
}

// CCMethods are the methods for all chaincodes
var CCMethods = CCMethodsType{
	Profile: ProfileCCMethodsType{
		Organization: OrganizationMethodsType{
			StartFlow:       "organizationAPI.startFlow",
			ApproveFlow:     "organizationAPI.approveFlow",
			CancelFlow:      "organizationAPI.cancelFlow",
			RejectFlow:      "organizationAPI.rejectFlow",
			Get:             "organizationAPI.get",
			GetViaPublicKey: "organizationAPI.getViaPublicKey",
			Deactivate:      "organizationAPI.deactivate",
			Activate:        "organizationAPI.activate",
			AdminUpdate:     "organizationAPI.adminUpdate",
			Search:          "organizationAPI.search",
			SearchFlows:     "organizationAPI.searchFlows",
			GetFlow:         "organizationAPI.getFlow",
			GetFlowActions:  "organizationAPI.getFlowActions",
			GetPublicKeys:   "organizationAPI.getPublicKeys",
			ActivateKey:     "organizationAPI.activateKey",
			DeactivateKey:   "organizationAPI.deactivateKey",
			SearchEvents:    "organizationAPI.searchEvents",
			GetEvent:        "organizationAPI.getEvent",
		},
		TC: TCMethodsType{
			Get:    "termsConditionsAPI.get",
			Search: "termsConditionsAPI.search",
			Create: "termsConditionsAPI.create",
			Update: "termsConditionsAPI.update",
		},
		PurposeFormat: PurposeFormatMethodsType{
			Create: "purposeFormatsAPI.create",
			Get:    "purposeFormatsAPI.get",
			GetAll: "purposeFormatsAPI.getAll",
		},
	},
	Guarantee: GuaranteeCCMethodsType{
		GX: GXMethodsType{
			StartFlow:      "gXAPI.startFlow",
			RecallFlow:     "gXAPI.recallFlow",
			ApproveFlow:    "gXAPI.approveFlow",
			RevokeAction:   "gXAPI.revokeAction",
			CancelFlow:     "gXAPI.cancelFlow",
			RejectFlow:     "gXAPI.rejectFlow",
			DeferFlow:      "gXAPI.deferFlow",
			Search:         "gXAPI.search",
			Get:            "gXAPI.get",
			SearchFlows:    "gXAPI.searchFlows",
			GetFlow:        "gXAPI.getFlow",
			GetFlowActions: "gXAPI.getFlowActions",
			SearchEvents:   "gXAPI.searchEvents",
			GetEvent:       "gXAPI.getEvent",
		},
	},
}

// MaxTime is the maximum possible time in Golang for which comparisons work see https://stackoverflow.com/questions/25065055/what-is-the-maximum-time-time-in-go
var MaxTime = time.Unix(1<<63-62135596801, 999999999)

// ConsortiumMSPID is the MSP ID of the bank consortium
const ConsortiumMSPID = "newco"

const (
	// OTFlow is the ObjectType for Flow
	OTFlow = "CC_FLOW"
	// OTFlowAction is the ObjectType for FlowAction
	OTFlowAction = "CC_FLOW_ACTION"
	// OTFlowStatus is the ObjectType for FlowStatus
	OTFlowStatus = "CC_FLOW_STATUS"
)

// IdentifiedInterface is an interface for structures with an id
type IdentifiedInterface interface {
	GetId() string
}

// IdentifiedMessage is an interface for protubuf messages with an id
type IdentifiedMessage interface {
	proto.Message
	GetId() string
}

// MetadataInterface is an interface for structures with metadata
type MetadataInterface interface {
	GetCreatedBy() string
	GetCreatedAt() *types.Timestamp
	GetUpdatedBy() string
	GetUpdatedAt() *types.Timestamp
}

// MetadataMessage is an interface for protobuf messages with an metadata
type MetadataMessage interface {
	proto.Message
	MetadataInterface
}

// RequestInterface is an interface for structs with metadata and an id
type RequestInterface interface {
	IdentifiedInterface
	MetadataInterface
}

// RequestMessage is an interface for protobuf messages with an metadata and an id
type RequestMessage interface {
	proto.Message
	RequestInterface
}

// Logger is the logger for the application
var Logger = shim.NewLogger("cc")
var loggingIsSetup = false
var logMux = sync.Mutex{}

// SetupLogging configures the Loggers
// Note 1.3 adds support for environment variables, so this function will likely be made obsolete
func SetupLogging() {
	if !loggingIsSetup {
		logMux.Lock()
		defer logMux.Unlock()
		shim.SetLoggingLevel(shim.LogError)
		// logLevel, err := shim.LogLevel(os.Getenv("LOGGING_LEVEL"))
		// if err != nil {
		// 	//TODO change default to LogInfo, as LogDebug is potentially vunerable to Log forging
		// 	Logger.SetLevel(shim.LogDebug)
		// 	Logger.SetLevel(shim.LogInfo)
		// 	return
		// }
		Logger.SetLevel(shim.LogInfo)
		loggingIsSetup = true
	}
}

// GenerateSystemPropertyKey generates a system property key from an ID
func GenerateSystemPropertyKey(stub shim.ChaincodeStubInterface, id string) (string, error) {
	return stub.CreateCompositeKey(OTSystemProperties, []string{id})
}

// IsConsortium determines if the current user is from the consortium organisation
func IsConsortium(stub shim.ChaincodeStubInterface, creatorCert *x509.Certificate) (bool, error) {
	newcoMspIDKey, err := GenerateSystemPropertyKey(stub, SPKeyNewcoMspID)
	if err != nil {
		return false, err
	}

	var newcoMspIDValue types.StringValue
	err = GetStatePB(stub, newcoMspIDKey, &newcoMspIDValue)
	if err != nil {
		return false, err
	}

	if len(creatorCert.Issuer.Organization) == 1 {
		// TODO refactor out underneath a dev flag
		// DEV ONLY
		return creatorCert.Issuer.Organization[0] == newcoMspIDValue.GetValue(), nil
	}

	// TODO make dynamic, remove hard coding
	return ContainsString(creatorCert.Issuer.OrganizationalUnit, newcoMspIDValue.GetValue()), nil
}

// GetCreatorPEM gets the pem string of the transaction creator
func GetCreatorPEM(stub shim.ChaincodeStubInterface) (string, error) {
	// get the creator identity from the stub
	creatorBytes, err := stub.GetCreator()
	if err != nil {
		return "", err
	}

	// deserialise the identity from the protobuf encoding
	var id mspprotos.SerializedIdentity
	if err = proto.Unmarshal(creatorBytes, &id); err != nil {
		return "", err
	}
	return string(id.IdBytes), nil
}

// PEMToCert converts a pem string to an x509.Certificate object
func PEMToCert(certPEM string) (*x509.Certificate, error) {
	block, _ := pem.Decode([]byte(certPEM))
	if block == nil {
		return nil, errors.New("Error Decoding pem")
	}
	return x509.ParseCertificate(block.Bytes)
}

// GetPublicKeyPEMFromCert converts an x509.Certificate to a public key pem
func GetPublicKeyPEMFromCert(cert *x509.Certificate) (string, error) {
	ecdsaPublicKey := cert.PublicKey.(*ecdsa.PublicKey)

	publicKeyBytes, err := x509.MarshalPKIXPublicKey(ecdsaPublicKey)
	if err != nil {
		return "", err
	}

	pubPem := pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: publicKeyBytes})

	return string(pubPem), nil
}

// GetPublicKeyPEMFromCertPEM converts an x509.Certificate pem to public key pem
func GetPublicKeyPEMFromCertPEM(certPEM string) (string, error) {
	cert, err := PEMToCert(certPEM)
	if err != nil {
		return "", err
	}
	pubPEM, err := GetPublicKeyPEMFromCert(cert)
	if err != nil {
		return "", err
	}

	return pubPEM, nil
}

// GetStatePB gets and unmarshals a marshalled protobuf message from the state
func GetStatePB(stub shim.ChaincodeStubInterface, key string, x proto.Message) error {
	valueBytes, err := stub.GetState(key)
	if err != nil {
		return err
	}

	if len(valueBytes) == 0 {
		return fmt.Errorf("Key %s does not exist", key)
	}

	return Unmarshal(valueBytes, x)
}

// PutStatePB marshals and puts a protobuf message into the state
func PutStatePB(stub shim.ChaincodeStubInterface, key string, value proto.Message) error {
	valueBytes, err := Marshal(value)
	if err != nil {
		return err
	}
	return stub.PutState(key, valueBytes)
}

// GetStateInt gets an int from the state. Notes that the int is assumed to be 32bit or less
func GetStateInt(stub shim.ChaincodeStubInterface, key string) (int, error) {
	valueBytes, err := stub.GetState(key)
	if err != nil {
		return 0, err
	}

	if len(valueBytes) == 0 {
		return 0, fmt.Errorf("Key %s does not exist", key)
	}

	return int(binary.LittleEndian.Uint32(valueBytes)), nil
}

// PutStateInt puts an int into the state. Notes that the int is assumed to be 32bit or less
func PutStateInt(stub shim.ChaincodeStubInterface, key string, value int) error {
	bs := make([]byte, 4)
	binary.LittleEndian.PutUint32(bs, uint32(value))
	return stub.PutState(key, bs)
}

// GetTxTimestamp retrieves the transactions timestamp and converts it to a standard protobuf timestamp
func GetTxTimestamp(stub shim.ChaincodeStubInterface) (*types.Timestamp, error) {
	txTimestamp, err := stub.GetTxTimestamp()
	if err != nil {
		return &types.Timestamp{}, err
	}

	return &types.Timestamp{
		Seconds: txTimestamp.Seconds,
		Nanos:   txTimestamp.Nanos,
	}, nil
}

// SetID sets the id of a request object
func SetID(obj IdentifiedInterface, id string) {
	objElem := reflect.ValueOf(obj).Elem()
	objElem.FieldByName("Id").SetString(id)
}

// SetCreatedMetadata sets the createdBy and createdAt of a protobuf message to the creator of the transaction and the transaction timestamp
func SetCreatedMetadata(stub shim.ChaincodeStubInterface, message MetadataInterface, creatorOrganizationID string) error {
	timestamp, err := GetTxTimestamp(stub)
	if err != nil {
		return err
	}

	messageElem := reflect.ValueOf(message).Elem()
	messageElem.FieldByName("CreatedBy").SetString(creatorOrganizationID)
	messageElem.FieldByName("CreatedAt").Set(reflect.ValueOf(timestamp))
	return nil
}

// SetFlowResultCreatedMetadata sets the createdBy and createdAt of a protobuf message to the creator of the start flow request and the final transaction timestamp
func SetFlowResultCreatedMetadata(stub shim.ChaincodeStubInterface, startRequest MetadataInterface, message MetadataInterface) error {
	timestamp, err := GetTxTimestamp(stub)
	if err != nil {
		return err
	}

	messageElem := reflect.ValueOf(message).Elem()
	messageElem.FieldByName("CreatedBy").SetString(startRequest.GetCreatedBy())
	messageElem.FieldByName("CreatedAt").Set(reflect.ValueOf(timestamp))
	return nil
}

// SetUpdatedMetadata sets the updatedBy and updatedAt of a protobuf message to the creator of the transaction and the transaction timestamp
func SetUpdatedMetadata(stub shim.ChaincodeStubInterface, message MetadataInterface, creatorOrganizationID string) error {
	timestamp, err := GetTxTimestamp(stub)
	if err != nil {
		return err
	}

	messageElem := reflect.ValueOf(message).Elem()
	messageElem.FieldByName("UpdatedBy").SetString(creatorOrganizationID)
	messageElem.FieldByName("UpdatedAt").Set(reflect.ValueOf(timestamp))
	return nil
}

// SetFlowResultUpdatedMetadata sets the updatedBy and updatedAt of a protobuf message to the creator of the start flow request and the final transaction timestamp
func SetFlowResultUpdatedMetadata(stub shim.ChaincodeStubInterface, startRequest MetadataInterface, message MetadataInterface) error {
	timestamp, err := GetTxTimestamp(stub)
	if err != nil {
		return err
	}

	messageElem := reflect.ValueOf(message).Elem()
	messageElem.FieldByName("UpdatedBy").SetString(startRequest.GetCreatedBy())
	messageElem.FieldByName("UpdatedAt").Set(reflect.ValueOf(timestamp))
	return nil
}

// ContainsString checks whether itme is in slice
func ContainsString(slice []string, item string) bool {
	for _, x := range slice {
		if x == item {
			return true
		}
	}
	return false
}

// Marshal marshal protobuf
// This is a helper method to centralize the conversions of proto.Message
// We can change how we want this to be converted into []bytes
// For example, we could convert into a JSON string and then into []bytes
// For now, it is just converting the proto.Message into []bytes
func Marshal(p proto.Message) ([]byte, error) {
	return proto.Marshal(p)
}

// Unmarshal unmarshal into protobuf
// This is a helper method to centralize the conversions to proto.Message
// We may change later how we want this to convert []bytes into proto.Message
func Unmarshal(b []byte, p proto.Message) error {
	return proto.Unmarshal(b, p)
}

// Hash hashs a string to a uint32
func Hash(s string) uint32 {
	h := fnv.New32a()
	h.Write([]byte(s))
	return h.Sum32()
}

// HashS hashs a string to a string
func HashS(s string) string {
	return strconv.FormatUint(uint64(Hash(s)), 10)
}
