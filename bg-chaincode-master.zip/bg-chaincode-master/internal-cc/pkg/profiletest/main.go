package profiletest

import (
	"testing"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/cctest"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	profilePB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/profile"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/profileutil"
)

var ccMethods = ccutil.CCMethods.Profile

// LinkPEMOrganizationID links a per certificate to an organizationID by storing a link in the chaincode state
func LinkPEMOrganizationID(stub *cctest.MockStub, certPEM string, organizationID string) error {
	txID := cctest.GenerateMockTxID("")
	stub.MockTransactionStart(txID)
	defer stub.MockTransactionEnd(txID)
	cert, err := ccutil.PEMToCert(certPEM)
	if err != nil {
		return err
	}

	return profileutil.LinkCertificateToOrganizationID(stub, cert, organizationID)
}

// SetupChaincodeMockStub initialises a MockStub with the profile chaincode and an example certificate
func SetupChaincodeMockStub(t *testing.T, organizationAPICC profilePB.OrganizationAPIInterface, purposeAPICC profilePB.PurposeFormatsAPIInterface, termsConditionsAPICC profilePB.TermsConditionsAPIInterface) *cctest.MockStub {
	t.Helper()
	// create an instance of the weave struct that satisfies the chaincode stub interface
	cc := profilePB.New(organizationAPICC, purposeAPICC, termsConditionsAPICC)

	stub := cctest.NewMockStub("profile", &cc)

	// set channel ID
	stub.ChannelID = "platform-channel"

	// set default cert
	cctest.SetMockStubCert(t, stub, cctest.ConsortiumPEM)

	// chaincode init
	cctest.PerformCCInit(t, stub, [][]byte{[]byte("init"), []byte("{\"newcoMspId\":\"newco\"}")})
	return stub
}

// GenerateIDValueBytes generates the bytes of an example IDValue message
func GenerateIDValueBytes(t *testing.T, id string) []byte {
	t.Helper()
	request := &sharedPB.IDValue{Value: id}

	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatalf("Could not marshal GetRequest: %s", err.Error())
	}

	return requestBytes
}

// GenerateExampleOrganization generates an example organization
func GenerateExampleOrganization(id string) profilePB.Organization {
	return profilePB.Organization{
		Id:         id,
		EntityName: "Example Org",
		EntityType: profilePB.OrganizationEntityType_ORGANIZATION_APPLICANT_OR_BENEFICIARY,
		BusinessId: "acn:12345678",
		Address:    &sharedPB.Address{StreetAddress: "123 Example Street"},
		Status:     profilePB.OrganizationStatus_ORGANIZATION_ACTIVE,
	}
}

// GenerateStartRequestCreateBytes generates the bytes for a Create StartRequest
func GenerateStartRequestCreateBytes(t *testing.T, createRequest *profilePB.OrganizationCreateRequest) []byte {
	t.Helper()
	startRequest := &profilePB.OrganizationStartRequest{Request: &profilePB.OrganizationStartRequest_CreateRequest{CreateRequest: createRequest}}
	// marshal the payload
	startRequestString, err := ccutil.Marshal(startRequest)
	startRequestBytes := []byte(startRequestString)

	if err != nil {
		t.Fatalf("Count not marshal StartRequest: %s", err.Error())
	}

	return startRequestBytes
}

// GeneratePurposeFormatBytes generates the bytes for a purpose format
func GeneratePurposeFormatBytes(t *testing.T, createRequest *sharedPB.PurposeFormat) []byte {
	t.Helper()
	createRequestString, err := ccutil.Marshal(createRequest)
	if err != nil {
		t.Fatalf("Could not marshall purpose format: %s", err.Error())
	}

	createRequestBytes := []byte(createRequestString)
	return createRequestBytes
}

// GenerateStartRequestProfileChangeBytes generates the bytes for a Create ProfileChange
func GenerateStartRequestProfileChangeBytes(t *testing.T, profileChangeRequest *profilePB.OrganizationProfileChangeRequest) []byte {
	t.Helper()
	startRequest := &profilePB.OrganizationStartRequest{Request: &profilePB.OrganizationStartRequest_ProfileChangeRequest{ProfileChangeRequest: profileChangeRequest}}

	// marshal the payload
	startRequestString, err := ccutil.Marshal(startRequest)
	startRequestBytes := []byte(startRequestString)

	if err != nil {
		t.Fatalf("Could not marshal StartRequest: %s", err.Error())
	}

	return startRequestBytes
}

// GenerateSearchRequestBytes generates the bytes for a SearchRequest
func GenerateSearchRequestBytes(t *testing.T, businessID string, entityName string, status *profilePB.OrganizationStatusValue) []byte {
	t.Helper()
	searchRequest := profilePB.OrganizationSearchRequest{
		BusinessId: businessID,
		EntityName: entityName,
		Status:     status,
	}
	searchRequestString, err := ccutil.Marshal(&searchRequest)
	searchRequestBytes := []byte(searchRequestString)

	if err != nil {
		t.Fatalf("Could not marshal searchRequest: %s", err.Error())
	}
	return searchRequestBytes
}

// GenerateOrganizationFlowsRequestBytes generates the bytes for an OrganizationFlowsSearchRequest
func GenerateOrganizationFlowsRequestBytes(t *testing.T, organizationID string, status string) []byte {
	t.Helper()
	request := &profilePB.OrganizationFlowsSearchRequest{OrganizationId: organizationID, Status: nil}

	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatalf("Could not marshal OrganizationFlowsSearchRequest: %s", err.Error())
	}

	return requestBytes
}

// GenerateFlowIDValueBytes generates the bytes for a FlowIDValue
func GenerateFlowIDValueBytes(t *testing.T, flowID string) []byte {
	request := &sharedPB.FlowIDValue{Value: flowID}

	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatalf("Could not marshal FlowHistoryRequest: %s", err.Error())
	}

	return requestBytes
}

// GenerateActivateKeyRequestBytes generates the bytes for an ActivateKeyRequest
func GenerateActivateKeyRequestBytes(t *testing.T, key string) []byte {
	request := &profilePB.ActivateKeyRequest{Key: key}

	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatalf("Could not marshal ActivateKeyRequest: %s", err.Error())
	}

	return requestBytes
}

// GenerateDeactivateKeyRequestBytes generates the bytes for a DeactivateKeyRequest
func GenerateDeactivateKeyRequestBytes(t *testing.T, key string) []byte {
	request := &profilePB.DeactivateKeyRequest{Key: key}

	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatalf("Could not marshal DeactivateKeyRequest: %s", err.Error())
	}

	return requestBytes
}

// GeneratePublicKeyValueBytes generates the bytes for a PublicKeyValue
func GeneratePublicKeyValueBytes(t *testing.T, key string) []byte {
	request := &profilePB.PublicKeyValue{Value: key}

	requestBytes, err := ccutil.Marshal(request)
	if err != nil {
		t.Fatalf("Could not marshal DeactivateKeyRequest: %s", err.Error())
	}

	return requestBytes
}

// InvokePurposeFormatCreate creates a new purpose format in the mock stub
func InvokePurposeFormatCreate(t *testing.T, stub *cctest.MockStub, txID string, purposeFormat *sharedPB.PurposeFormat) sharedPB.FlowIDValue {
	t.Helper()
	bytes := GeneratePurposeFormatBytes(t, purposeFormat)
	args := [][]byte{[]byte(ccMethods.PurposeFormat.Create), bytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to create purpose format: %s", string(res.Message))
	}

	var createPayload sharedPB.FlowIDValue
	err := ccutil.Unmarshal(res.GetPayload(), &createPayload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return createPayload
}

// InvokeOrganizationStartFlowCreate invokes an Organization Create StartRequest
func InvokeOrganizationStartFlowCreate(t *testing.T, stub *cctest.MockStub, txID string, createRequest *profilePB.OrganizationCreateRequest) sharedPB.FlowIDValue {
	t.Helper()
	startRequestBytes := GenerateStartRequestCreateBytes(t, createRequest)
	args := [][]byte{[]byte(ccMethods.Organization.StartFlow), startRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start create flow: %s", string(res.Message))
	}

	var createFlowPayload sharedPB.FlowIDValue
	err := ccutil.Unmarshal(res.GetPayload(), &createFlowPayload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return createFlowPayload
}

// InvokeOrganizationStartFlowProfileChange invokes an Organization ProfileChange StartRequest
func InvokeOrganizationStartFlowProfileChange(t *testing.T, stub *cctest.MockStub, txID string, profileChangeRequest *profilePB.OrganizationProfileChangeRequest) sharedPB.FlowIDValue {
	t.Helper()
	startRequestBytes := GenerateStartRequestProfileChangeBytes(t, profileChangeRequest)
	args := [][]byte{[]byte(ccMethods.Organization.StartFlow), startRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start profile change flow: %s", string(res.Message))
	}

	var profileChangeFlowPayload sharedPB.FlowIDValue
	err := ccutil.Unmarshal(res.GetPayload(), &profileChangeFlowPayload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return profileChangeFlowPayload
}

// InvokeTCCreate invokes the creation of a TC
func InvokeTCCreate(t *testing.T, stub *cctest.MockStub, txID string, tc *profilePB.TermsConditions) sharedPB.IDValue {
	t.Helper()

	// marshal the payload
	tcBytes, err := ccutil.Marshal(tc)
	if err != nil {
		t.Fatalf("Count not marshal tc: %s", err.Error())
	}

	args := [][]byte{[]byte(ccMethods.TC.Create), tcBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to start create flow: %s", string(res.Message))
	}

	var createPayload sharedPB.IDValue
	err = ccutil.Unmarshal(res.GetPayload(), &createPayload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return createPayload
}

// InvokeSearchEvents invokes the searching of events on the profile chaincode
func InvokeSearchEvents(t *testing.T, stub *cctest.MockStub, txID string, searchRequest *sharedPB.EventSearchRequest) *profilePB.OrganizationEventSearchResponse {
	t.Helper()
	searchRequestBytes, err := ccutil.Marshal(searchRequest)
	if err != nil {
		t.Fatal(err.Error())
	}
	args := [][]byte{[]byte(ccMethods.Organization.SearchEvents), searchRequestBytes}

	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to invoke GetFlows: %s", string(res.Message))
	}

	var payload profilePB.OrganizationEventSearchResponse
	err = ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatal(err.Error())
	}

	return &payload
}

// InvokeOrganizationGet invokes the retrieval of an organization
func InvokeOrganizationGet(t *testing.T, stub *cctest.MockStub, txID string, organizationID string) *profilePB.Organization {
	t.Helper()
	args := [][]byte{[]byte(ccMethods.Organization.Get), GenerateIDValueBytes(t, organizationID)}
	// Test for successful invoke of get organization
	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to get organization: %s", string(res.Message))
	}

	// Check all fields of the organization
	var payload profilePB.Organization
	err := ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatalf(err.Error())
	}
	return &payload
}

// InvokeOrganizationDeactivate invokes the deactivation of an organization
func InvokeOrganizationDeactivate(t *testing.T, stub *cctest.MockStub, txID string, organizationID string) *profilePB.Organization {
	t.Helper()
	args := [][]byte{[]byte(ccMethods.Organization.Deactivate), GenerateIDValueBytes(t, organizationID)}
	// Test for successful invoke of get organization
	res := stub.MockInvoke(txID, args)
	if res.Status != shim.OK {
		t.Fatalf("Failed to deactivate organization: %s", string(res.Message))
	}

	// Check all fields of the organization
	var payload profilePB.Organization
	err := ccutil.Unmarshal(res.GetPayload(), &payload)
	if err != nil {
		t.Fatalf(err.Error())
	}
	return &payload
}

// InvokeOrganizationActivate invokes the activation of an organization
func InvokeOrganizationActivate(t *testing.T, stub *cctest.MockStub, txID string, organizationID string) *profilePB.Organization {
    t.Helper()
    args := [][]byte{[]byte(ccMethods.Organization.Activate), GenerateIDValueBytes(t, organizationID)}
    // Test for successful invoke of get organization
    res := stub.MockInvoke(txID, args)
    if res.Status != shim.OK {
        t.Fatalf("Failed to activate organization: %s", string(res.Message))
    }

    // Check all fields of the organization
    var payload profilePB.Organization
    err := ccutil.Unmarshal(res.GetPayload(), &payload)
    if err != nil {
        t.Fatalf(err.Error())
    }
    return &payload
}

// ValidateFlowStatus checks whether the status is valid otherwise it fails the test
func ValidateFlowStatus(t *testing.T, stub *cctest.MockStub, flowID string, status sharedPB.FlowStatus) {
	t.Helper()
	isCorrectStatus, err := profileutil.CheckFlowStatus(stub, flowID, status)
	if err != nil {
		t.Fatal(err.Error())
	}
	if !isCorrectStatus {
		t.Fatal("Incorrect Flow Status")
	}
}
