package guaranteeutil

import "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"

const (
	// OTGX is the ObjectType for Guarantees
	OTGX = "GUARANTEE_GX"
	// OTGXEvents is the ObjectType for Guarantee Events
	OTGXEvents = "GUARANTEE_GX_EVENTS"
)

const (
	// AFAmend is the Active Flow Flag for Amend
	AFAmend ccutil.Bitmask = 1
	// AFCancel is the Active Flow Flag for Cancel
	AFCancel = 2
	// AFDemand is the Active Flow Flag for Demand
	AFDemand = 4
	// AFTransfer is the Active Flow Flag for Transfer
	AFTransfer = 8
)

const (
	// SPKeyPrefix is the prefix used for all guarantees on the channel
	SPKeyPrefix = "prefix"
	// SPKeyPlatformChannel is the ID of the Platform Channel
	SPKeyPlatformChannel = "platformChanel"
	// SPKeyProfileCC is the ID of the Profile chaincode
	SPKeyProfileCC = "profile"
)

// Setup sets up the guarantee chaincode
func Setup() {
	ccutil.SetupLogging()
}
