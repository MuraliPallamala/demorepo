package profileutil

import (
	"crypto/x509"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/ccutil"
	sharedPB "github.ibm.com/bank-guarantees/bg-chaincode/internal-cc/pkg/gen/shared"
)

const (
	// OTID is the ObjectType for Public Key ID
	OTID = "PROFILE_ID"
	// OTOrganization is the ObjectType for Organizations
	OTOrganization = "PROFILE_ORGANIZATION"
	// OTTermsConditions is the ObjectType for Terms and Conditions
	OTTermsConditions = "PROFILE_TERMS_CONDITIONS"
	// OTOrganizationPublicKeyMap is the ObjectType for a map of public keys of an organization
	OTOrganizationPublicKeyMap = "PROFILE_PUBLIC_KEY_MAP"
	// OTPurposeFormat type prefix for purpose formats
	OTPurposeFormat = "PURPOSE_FORMAT"
	// OTOrganizationEvents  is the ObjectType for Organization Events
	OTOrganizationEvents = "PROFILE_ORGANIZATION_EVENTS"
)

// GenerateLinkKey generates the key used to linking a public key to an organizationID
func GenerateLinkKey(stub shim.ChaincodeStubInterface, publicKeyString string) (string, error) {
	return stub.CreateCompositeKey(OTID, []string{publicKeyString})
}

// GetOrganizationIDFromCert retrieves the organizationID linked to the certificate
func GetOrganizationIDFromCert(stub shim.ChaincodeStubInterface, cert *x509.Certificate) (string, error) {
	publicKeyPEM, err := ccutil.GetPublicKeyPEMFromCert(cert)
	if err != nil {
		return "", err
	}
	return GetOrganizationIDFromPublicKey(stub, publicKeyPEM)
}

// GetOrganizationIDFromPublicKey retrieves the organizationID linked to the public key
func GetOrganizationIDFromPublicKey(stub shim.ChaincodeStubInterface, publicKeyPEM string) (string, error) {
	linkKey, err := GenerateLinkKey(stub, publicKeyPEM)
	if err != nil {
		return "", err
	}
	creatorOrgIDBytes, err := stub.GetState(linkKey)
	if err != nil {
		return "", err
	}
	if len(creatorOrgIDBytes) == 0 {
		return "", fmt.Errorf("Key %s does not exist", publicKeyPEM)
	}

	return string(creatorOrgIDBytes), nil
}

// LinkPublicKeyStringToOrganizationID links a publicKeyString to an OrganizationID via the state
func LinkPublicKeyStringToOrganizationID(stub shim.ChaincodeStubInterface, publicKeyString string, organizationID string) error {
	linkKey, err := GenerateLinkKey(stub, publicKeyString)
	if err != nil {
		return err
	}
	return stub.PutState(linkKey, []byte(organizationID))
}

// LinkCertificateToOrganizationID links a x509.Certificate to an OrganizationID via the state
func LinkCertificateToOrganizationID(stub shim.ChaincodeStubInterface, cert *x509.Certificate, organizationID string) error {
	publicKeyString, err := ccutil.GetPublicKeyPEMFromCert(cert)
	if err != nil {
		return err
	}
	return LinkPublicKeyStringToOrganizationID(stub, publicKeyString, organizationID)
}

// GenerateFlowStatusKey generates the key for storing a flow status
func GenerateFlowStatusKey(stub shim.ChaincodeStubInterface, flowID string) (string, error) {
	return stub.CreateCompositeKey(ccutil.OTFlowStatus, []string{flowID})
}

// GetFlowStatus gets the status of a particular flow
func GetFlowStatus(stub shim.ChaincodeStubInterface, flowID string) (sharedPB.FlowStatus, error) {
	statusKey, err := GenerateFlowStatusKey(stub, flowID)
	if err != nil {
		return sharedPB.FlowStatus_FLOW_CANCELLED, err
	}

	flowStatusInt, err := ccutil.GetStateInt(stub, statusKey)
	if err != nil {
		return sharedPB.FlowStatus_FLOW_CANCELLED, err
	}

	return sharedPB.FlowStatus(flowStatusInt), nil
}

// CheckFlowStatus checks whether the status of a particular flow is
func CheckFlowStatus(stub shim.ChaincodeStubInterface, flowID string, status sharedPB.FlowStatus) (bool, error) {
	storedStatus, err := GetFlowStatus(stub, flowID)
	if err != nil {
		return false, err
	}

	return storedStatus == status, nil
}

// Setup sets up the profile chaincode
func Setup() {
	ccutil.SetupLogging()
}
