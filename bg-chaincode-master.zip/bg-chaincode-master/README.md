# bg-chaincode
Chaincode repository for Bank Guarantees containing the actual Go implementation 

## Note

We are attempting to follow something close to https://github.com/golang-standards/project-layout
However, there are notable deviations due to constraints around how chaincode is deployed.
Notably the vendor folder is copied into the cmds and the internal folder is name internal-cc

## Development

### Pre-requisites
- Go https://golang.org/doc/install
- Dep https://github.com/golang/dep
- weave-cc-go https://github.ibm.com/aur-blockchain/weave-cc-go

github.ibm.com is accessible via https. https://github.ibm.com/settings/tokens

```
git config --global url."https://<YOUR_GITHUB_TOKEN>:@github.ibm.com/".insteadOf "https://github.ibm.com/"
```

Fabric 1.4 must be cloned into `$GOPATH/src/github.com/hyperledger/fabric`

```
$ git clone -b release-1.4 https://github.com/hyperledger/fabric.git $GOPATH/src/github.com/hyperledger/fabric
```

gometalinter

```
$ go get -u gopkg.in/alecthomas/gometalinter.v2
$ gometalinter.v2 --install --update
```

### Setup


Clone bg-chaincode into `$GOPATH/src/github.ibm.com/bank-guarantees/bg-chaincode`

```
$ git clone git@github.ibm.com:bank-guarantees/bg-chaincode.git $GOPATH/src/github.ibm.com/bank-guarantees/bg-chaincode
```

Cd into directory

```
$ cd $GOPATH/src/github.ibm.com/bank-guarantees/bg-chaincode
```

Clone bg-chaincode-model into directory of choice

```
$ git clone git@github.ibm.com:bank-guarantees/bg-chaincode-model.git <YOUR_BG_CHAINCODE_MODEL_PATH>
```

Generate weave code

```
$ BG_CHAINCODE_MODEL_PATH=<YOUR_BG_CHAINCODE_MODEL_PATH> make generate-models
```

Add dependencies

```
$ go get ./...
```

Add githooks

```
$ git config core.hooksPath .githooks
```
