# Introduction
Contains tools and files needed to bring up the bank-guarantees network

## Running locally (development mode):

### Prerequisites
- Docker https://www.docker.com/get-docker
- Minikube https://github.com/kubernetes/minikube
  - Note that 0.28 seems to have bugged volume mounting on OSX, so install 0.27 https://github.com/kubernetes/minikube/releases/tag/v0.27.0
  - If you would like to use the hyperkit driver, filepath volume mounting currently doesn't work, but there is a workaround https://github.com/kubernetes/minikube/issues/2481
  Run `scp -ri "$(minikube ssh-key)" "$PWD" docker@$(minikube ip):/tmp` in `bg-network` directory and modify `bg-network/setups/dev/start.sh` to have `BG_ENV_ASSETS=/tmp/bg-network/assets`
- Kubectl https://kubernetes.io/docs/tasks/tools/install-kubectl/#install-kubectl
- Nodejs https://nodejs.org/en/download/
- Nodemon https://nodemon.io/
- All Prerequisites of https://github.ibm.com/bank-guarantees/bg-chaincode

### Setup

Clone bg-network into directory of choice

```
$ git clone git@github.ibm.com:bank-guarantees/bg-network.git <YOUR_BG_NETWORK_PATH>
```

Setup chaincode for development, see https://github.ibm.com/bank-guarantees/bg-chaincode

Start Docker and Minikube

### Deploy:

Launch bg-network in dev mode

```
$ setups/dev/start.sh
```

### Clean
Clean bg-network dev mode

```
$ setups/dev/clean.sh
```

## Migration Notes

- Terminate `./run-chaincode.sh` in bg-network
- Terminate `npm run dev` in bg-mock-ibp
- Modify `run-chaincode.sh` and `common-fabric-network-dev.json` - replace v0 with v1
    - `run-chaincode.sh` inside the `for peer` loops (2x)
    - `common-fabric-network-dev.json` inside the `chaincodes` key (2x)
- Switch to your upgrade branch (e.g. `feature/purpose-format`) for bg-chaincode-model, bg-chaincode and bg-api.
    - Run `make clean build` on bg-chaincode-model
    - Run `make generate-models` on bg-chaincode
    - Run `mvn clean install` on bg-api
- Run `./run-chaincode.sh` in bg-network (check for errors)
- Run `npm run upgrade` in bg-mock-ibp (check for errors)
- Run `npm run dev` in bg-mock-ibp
- Run bg-api components
