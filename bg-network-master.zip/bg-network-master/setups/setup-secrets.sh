source .secrets

# Login to docker
docker login -u $DOCKER_USERNAME -p $DOCKER_PASSWORD $DOCKER_SERVER
kubectl create secret docker-registry bg-docker-cred --docker-server=$DOCKER_SERVER --docker-username=$DOCKER_USERNAME --docker-password=$DOCKER_PASSWORD --docker-email=$DOCKER_EMAIL
