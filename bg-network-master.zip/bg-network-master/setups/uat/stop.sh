#!/bin/bash

# This script is used to stop a specific deployment of the bank guarantee platform.
# The script first sources some utility functions into the environment, then it checks
# whether thare are existing containers running, and it shuts them down.
#



S_CURRENT_DIR=$(pwd)

echo "A. Preparing the Operating Environment"
echo "-------------------------------------------------------------------------"

# environment setup
source env-setup.sh



mkdir -p ${S_BG_PROFILES}
cd  ${S_BG_PROFILES}
for LS_PROFILE_FILE in $(ls -r *.yaml)
do
   echo "  - kubectl delete -f ${LS_PROFILE_FILE}"
   kubectl delete -f ${LS_PROFILE_FILE}
 done

echo ""
echo ""

