#!/bin/bash

# This script starts up a version of the bank guarantees network for production environments
# NOTE: This script does not include any fabric components, since it's expected that they will run outside Kubernetes
