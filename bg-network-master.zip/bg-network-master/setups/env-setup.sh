#!/bin/bash

# This script setups the environment for the deployment
# of the Bank Guarantees solution. It defines a set of common
# variables and functions that are used by in the various
# phases of the deployment process.
#
# The script is meant to be sourced by the update script
# so that all the scripts that follow are configured to
# execute their function.

# Here we have to export the variables so that we can reference
# these variables in scripts that are executed in subshells that
# are invoked by the script that sources this script.
#
export S_BG_ROOT=${1:-"/opt/dlt"}
export S_BG_ROOT_DATA=${S_BG_ROOT}/data
export S_BG_ROOT_SETUP=${S_BG_ROOT}/setup
export S_BG_ROOT_LOGS=${S_BG_ROOT}/logs
export S_BG_TEMPLATES=${S_BG_ROOT_SETUP}/templates
export S_BG_PROFILES=${S_BG_ROOT}/runtime
export S_BG_ENV_PATH=$(pwd)/.env
export S_BG_ENV_PREFIX="BG_ENV_"
export S_BG_ENV_PREFIX_PATTERN="${S_BG_ENV_PREFIX}*"
export S_BG_ENV_VERSION_PEDIGREE=$(pwd)/.pedigree

export BG_ENV_ROOT_LOGS=${S_BG_ROOT_LOGS}
export BG_ENV_ROOT_DATA=${S_BG_ROOT_DATA}
export BG_ENV_DOCKER_TAG=${BG_ENV_DOCKER_TAG:-"latest"}
export BG_ENV_JACOCO_OPTS=${BG_ENV_JACOCO_OPTS:-""}
export BG_ENV_API_MEMORY=${BG_ENV_API_MEMORY:-"-Xmx256m"}
export BG_ENV_FABRIC_TARGET=${BG_ENV_FABRIC_TARGET:-"${BG_ENV_ROOT_DATA}/mock-ibp/network"}

# This function logs a debug message conditionally. The function checks for
# the existence of the environment variable BG_ENV_DEBUG and if defined does
# print to the console a debug message, which is the only argument that is
# passed to the function.
#
#
function log_debug() {

  if [ ! -z ${BG_ENV_DEBUG} ]; then
    echo "[DEBUG] - ${1:-<null>}"
  fi

}

# sed that supports OSX and Linux from https://stackoverflow.com/a/38595160/541430
function sedi () {
    sed --version >/dev/null 2>&1 && sed -i -- "$@" || sed -i "" "$@"
}

# This function copies into the path that is passed as first argument 
# all the files that are identified by the following arguments. 
#
#
function copy_profiles() {
  local LS_TARGET_PATH=$1
  
  echo "Copying Static Profiles to ${LS_PROFILE_PATH}"

  for LS_PROFILE_PATH in $(echo "${@:2}"); do
    
    local LS_PROFILE=$(basename $LS_PROFILE_PATH)
    echo "   - copying $LS_PROFILE ..." 
    cp -rf ${LS_PROFILE_PATH} ${LS_TARGET_PATH}/${LS_PROFILE}
  
  done

}


# This function takes two arguments: the original source file and the target
# file and uses sed to replace all the environment variables that occurr in
# the source file with their corresponding values (if mapped) in the target
# file.
#
# - $1 source file containing the text with the occurrence of the variables.
# - $2 name of the target file.
# - $3 environment variable prefix that is used to select those environment
#      variables that will be used for applying the substitution.
#
function process_profile() {

  local LS_SOURCE_PROFILE=$1
  local LS_TARGET_PROFILE=$2
  local LS_VAR_PREFIX=$3
  local LS_VAR_EXPANSION=$(eval 'echo ${!'$LS_VAR_PREFIX'*}')

  # NOTE: This is a bit tricky...
  #       - echo ${!X*} prints the list of the variable names that start with X
  #       - we don't want to hard-code the prefix, ideally we would like to have ${!$X*} where X stores the prefix
  #       - bash does not really like that and flags a bad substitution
  #       - hence, we construct the equivalent of ${!X*} by substituting $X in a string that than we pass to eval
  #       - it then becomes eval 'echo ${!'$X'*}'
  #       - we run this in a subshell so that we can return it by doing $(eval 'echo ${!'$X'*}')
  #       - this generates the list of variable names we need, to use in the for statement.
  #       -.... boom.
  #
  local LS_VAR_EXPANSION=$(eval 'echo ${!'$LS_VAR_PREFIX'*}')

  log_debug "[Prefix: ${LS_VAR_PREFIX}, Variables: ${LS_VAR_EXPANSION}]"
  cp $LS_SOURCE_PROFILE $LS_TARGET_PROFILE

  if [ -z "${LS_VAR_EXPANSION}" ]; then

    echo "[WARNING] Environment set is empty! - No substitution."
  else
    for LS_VAR_NAME in ${LS_VAR_EXPANSION}
    do

      # NOTE: we have implemented the capability of encoding the content of a variable in base64
      #       if the template does require that. This is primarily done for secrets. To make This
      #       work we need to first find occurrences of the variable that rquire the base64 encoding
      #       and replace those first, otherwise we would not be able to replace them later.
      #

      # NOTE: there is a difference here between ${LS_VAR_NAME} and ${!LS_VAR_NAME}, the first will be returning
      #       the name of the variable, while the other other one will return its correposinfing value.
      #

      log_debug "(${LS_VAR_NAME}/base64 => base64(${LS_VAR_NAME})): sed -i '' 's|\${'$LS_VAR_NAME'}|'$(echo -n ${LS_VAR_NAME} | base64 | tr -d \\n)'|g' ${LS_TARGET_PROFILE}"
      sedi 's|\${'$LS_VAR_NAME'/base64}|'$(echo -n ${!LS_VAR_NAME} | base64 | tr -d \\n)'|g' ${LS_TARGET_PROFILE}

      log_debug "(${LS_VAR_NAME} => ${LS_VAR_NAME}): sed -i '' 's|\${'$LS_VAR_NAME'}|'${LS_VAR_NAME}'|g' ${LS_TARGET_PROFILE}"
      sedi 's|\${'$LS_VAR_NAME'}|'${!LS_VAR_NAME}'|g' ${LS_TARGET_PROFILE}

    done
  fi
}

echo -n test | base64 | tr -d \\n

# This function loads the environment settings and injects in the environment
# all the variables that are stored in the local environment file. This file
# is meant to be located in the target environment and it is designed to store
# those parameters that would specialize a kubernetes template for the specific
# environment in which the corresponding profile will need to run.
#
function load_environment_settings() {

  echo "============ Preparing Bank Guarantees Environment ============="
  echo " - Bank Guarantees Root                :   ${S_BG_ROOT}"
  echo " - Bank Guarantees Setup Root          :   ${S_BG_ROOT_SETUP}"
  echo " - Bank Guarantees Profiles            :   ${S_BG_PROFILES}"
  echo " - Bank Guarantees Templates           :   ${S_BG_TEMPLATES}"
  echo " - Bank Guarantees Data Root           :   ${S_BG_ROOT_DATA}"
  echo " - Bank Guarantees Log Root            :   ${S_BG_ROOT_LOGS}"
  echo " - Bank Guarantees Env File            :   ${S_BG_ENV_PATH}"
  echo " - Bank Guarantees Env Prefix          :   ${S_BG_ENV_PREFIX}"
  echo " - Bank Guarantees Env Prefix Pattern  :   ${S_BG_ENV_PREFIX_PATTERN}"
  echo ""

  echo "- Checking Environment Settings...."

  # NOTE: because we have set -u (somewhere up in the script call hierarchy)
  #       if we try to reference a variable that is not bound yet we will get
  #       an "unbound variable error", using the form ${VAR_NAME:-} will allow
  #       us to test whether VAR_NAME is defined without triggering the error,
  #       by using the default operator, we expand the variable to "" if it
  #       is unset or empty, which is what we want in this case. Alternatively,
  #       we could use the other for ${VAR_NAME-} which supplies the default
  #       value only if it is not defined, and not if it is empty. In our case
  #       both would do the job.
  #
  if [ ! -z "${BG_ENV_LOADED:-}" ]; then

    echo "   - Environment parameters have been loaded (BG_ENV_NAME: ${BG_ENV_NAME})"
    for LS_ENV_NAME in $(env | awk -F '=' '{ print $1 }')
    do
      if [[ ${LS_ENV_NAME} == ${S_BG_ENV_PREFIX_PATTERN} ]]; then
        echo "      - ${LS_ENV_NAME}:        ${!LS_ENV_NAME}"
      fi
    done
    export HAS_ENV_FILE=true
  else
    if [ -f ${S_BG_ENV_PATH} ]; then
      echo "   - Environment file is PRESENT"
      echo "   - cat ${S_BG_ENV_PATH}"
      echo "----------------------------------------"
      cat ${S_BG_ENV_PATH}
      echo "----------------------------------------"
      echo "   - source ${S_BG_ENV_PATH}"
      source ${S_BG_ENV_PATH}
      export HAS_ENV_FILE=true
    else
      echo "   - Environment file is MISSING"
      export HAS_ENV_FILE=false
    fi
  fi
  echo ""

  echo "- Checking Version Information..."
  if [ ! -f ${S_BG_ENV_VERSION_PEDIGREE} ]; then
    echo "   - [WARN] Version file is MISSING (file: ${S_BG_ENV_VERSION_PEDIGREE})"
  else
    echo "   - Version file is PRESENT (file: ${S_BG_ENV_VERSION_PEDIGREE})"
    echo "----------------------------------------------------"
    cat ${S_BG_ENV_VERSION_PEDIGREE}
    echo "----------------------------------------------------"
    echo "   - source ${S_BG_ENV_VERSION_PEDIGREE}"
    source ${S_BG_ENV_VERSION_PEDIGREE}
  fi
  echo ""
  echo "========================= [DONE] =========================="
}

# This function prepares the profile files that are stored in a specific
# folder. The function expects a variable number of parameters:
#
# - $1         :   the environment variable prefix used to select those
#                  variables in the environment that will be used for
#                  the substitution.
# - $2         :   the folder containing the profile files.
# - $3...$n    :   all the profile files that need to be processed without
#                  the template extension.
#
# The function will first check whether for any given profile file there
# exist the corresponding template, and if so it will invoke the function
# process_profile.
#
function prepare_profiles() {
  local LS_CURRENT_DIR=$(pwd)
  local LS_VAR_PREFIX=$1
  local LS_DEST_FOLDER=$2

  local LS_COUNTER=0
  
  for LS_PROFILE_PATH in $(echo "${@:3}"); do
    local LS_PROFILE=$(basename $LS_PROFILE_PATH)
    echo "   - processing $LS_PROFILE ..."
    process_profile ${LS_PROFILE_PATH} ${LS_DEST_FOLDER}/${LS_PROFILE} ${LS_VAR_PREFIX} 
    # if [[ "${LS_COUNTER}" -gt 2 ]]; then
    #  wait
    #  LS_COUNTER=0
    # fi
    # LS_COUNTER=$((LS_COUNTER+1))
  done
  wait

  echo ""
}

export -f log_debug
export -f process_profile
export -f prepare_profiles
export -f copy_profiles
export -f sedi

# We invoke the load environment settings so that we are sure that all the
# information is properly setup.
#
#
load_environment_settings


