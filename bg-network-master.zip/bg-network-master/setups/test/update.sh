#!/bin/bash

# This script is used to update a specific deployment of the bank guarantee platform.
# Th script first sources some utility functions into the environment, then it checks
# whether thare are existing containers running, it shuts them down and recreate the
# deployment.
#



S_CURRENT_DIR=$(pwd)

echo "A. Preparing the Operating Environment"
echo "-------------------------------------------------------------------------"

# environment setup
source env-setup.sh



mkdir -p ${S_BG_PROFILES}
cd  ${S_BG_PROFILES}
for LS_PROFILE_FILE in $(ls -r *.yaml)
do
   echo "  - kubectl delete -f ${LS_PROFILE_FILE}"
   kubectl delete -f ${LS_PROFILE_FILE}
   echo "  -  mv ${LS_PROFILE_FILE} ${LS_PROFILE_FILE}.bkp"
   mv ${LS_PROFILE_FILE} ${LS_PROFILE_FILE}.bkp
done

cd ${S_CURRENT_DIR}

echo ""
echo ""


echo "B. Processing the Kubernets Profiles"
echo "-------------------------------------------------------------------------"

copy_profiles ${S_BG_PROFILES} ${S_BG_TEMPLATES}/static/*.yaml
prepare_profiles ${S_BG_ENV_PREFIX}  ${S_BG_PROFILES} ${S_BG_TEMPLATES}/*.yaml

echo ""
echo ""


echo "C. Deploying the Kubernetes Profiles"
echo "-------------------------------------------------------------------------"
cd  ${S_BG_PROFILES}
for LS_PROFILE_FILE in $(ls -1 *.yaml)
do
  echo "   - kubectl create -f  ${LS_PROFILE_FILE}"
  kubectl create -f  ${LS_PROFILE_FILE}
done


echo ""
echo ""
