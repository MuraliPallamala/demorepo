#!/usr/bin/env bash
#


cd "$(dirname "$0")"

# This piece checks whether the environment has been setup properly otherwise it runs
# the environment setup script, that pulls the variables and the required bash functions 
# into the shell environment where this script is executing. 
#
# If the file is not found, it terminates the script.
#
if [ -z "${HAS_ENV_FILE}" ]; then

     echo "#######################################################"
     echo "##             ENVIRONMENT NOT SETUP                 ##"
     echo "##---------------------------------------------------##"
     echo "## trying to source:  ../env-setup.sh                ##"
     echo "##                                                   ##"
     
     if [ ! -f "../env-setup.sh" ]; then
     
         echo "## ERROR: ../env-setup.sh NOT FOUND.                 ##"
         echo "##---------------------------------------------------##"
         echo "## script will exit (1)                              ##"
         echo "#######################################################"
         echo ""
 
         exit 1
     else
         echo "## OK: script found, sourcing into the environment   ##"
         echo "#######################################################"
         echo ""

         source ../env-setup.sh
     fi
fi

# clean up old config
rm -rf  ${S_BG_PROFILES}
mkdir -p ${S_BG_PROFILES}

# create mounting points for log folders
mkdir -p ${S_BG_TEMPLATES} 
declare -a MOUNTS=("admin" "user" "anz" "testissuer" "westpac" "commbank")
for MOUNT in "${MOUNTS[@]}"
do
  mkdir -p ${BG_ENV_ROOT_LOGS}/${MOUNT}/api
  mkdir -p ${BG_ENV_ROOT_LOGS}/${MOUNT}/service-api
  mkdir -p ${BG_ENV_ROOT_DATA}/${MOUNT}/conf
  mkdir -p ${BG_ENV_ROOT_DATA}/${MOUNT}/conf/ibp
done

# This is the location of the common scripts that are shared across environments.
# This is primarily for the location of the fabric that is shared across the DEV
# TEST and internal QA environment.
#
# By default, we set this to an empty variable and if we find it as a directory
# in the parent folder we process these profiles together with those specific to
# the environment by passing them as an argument to "prepare_profiles"
#
S_COMMON=

# Here we check that the common folder exist and if we do find the common folder
# we include the filter *.yaml to capture those files that need to be processed.
#
if [ -d "$(pwd)/../common/templates" ]; then
  S_COMMON=../common/templates/*.yaml
fi 


# compile templates

copy_profiles ${S_BG_PROFILES} ${S_COMMON} ${S_BG_TEMPLATES}/static/*.yaml
prepare_profiles ${S_BG_ENV_PREFIX} ${S_BG_PROFILES} ${S_BG_TEMPLATES}/*.yaml

