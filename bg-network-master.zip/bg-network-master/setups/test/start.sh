#!/bin/bash

# This script starts up a version of the bank guarantees network for test environments
cd "$(dirname "$0")"

# This piece checks whether the environment has been setup properly otherwise it runs
# the environment setup script, that pulls the variables and the required bash functions
# into the shell environment where this script is executing.
#
# If the file is not found, it terminates the script.
#
if [ -z "${HAS_ENV_FILE}" ]; then

     echo "#######################################################"
     echo "##             ENVIRONMENT NOT SETUP                 ##"
     echo "##---------------------------------------------------##"
     echo "## trying to source:  ../env-setup.sh                ##"
     echo "##                                                   ##"

     if [ ! -f "../env-setup.sh" ]; then

         echo "## ERROR: ../env-setup.sh NOT FOUND.                 ##"
         echo "##---------------------------------------------------##"
         echo "## script will exit (1)                              ##"
         echo "#######################################################"
         echo ""

         exit 1
     else
         echo "## OK: script found, sourcing into the environment   ##"
         echo "#######################################################"
         echo ""

         source ../env-setup.sh
     fi
fi

# Compile network templates
source compile.sh

echo "Deploying the Kubernetes Profiles under ${S_BG_PROFILES}"
echo "-------------------------------------------------------------------------"
cd  ${S_BG_PROFILES}
for LS_PROFILE_FILE in $(ls -1 *.yaml)
do
  echo "   - kubectl create -f  ${LS_PROFILE_FILE}"
  kubectl create -f  ${LS_PROFILE_FILE}
done
