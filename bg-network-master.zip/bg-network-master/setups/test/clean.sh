#!/bin/bash

# This script cleans up a version of the bank guarantees network for test environments

cd "$(dirname "$0")"

# This piece checks whether the environment has been setup properly otherwise it runs
# the environment setup script, that pulls the variables and the required bash functions
# into the shell environment where this script is executing.
#
# If the file is not found, it terminates the script.
#
if [ -z "${HAS_ENV_FILE}" ]; then

     echo "#######################################################"
     echo "##             ENVIRONMENT NOT SETUP                 ##"
     echo "##---------------------------------------------------##"
     echo "## trying to source:  ../env-setup.sh                ##"
     echo "##                                                   ##"

     if [ ! -f "../env-setup.sh" ]; then

         echo "## ERROR: ../env-setup.sh NOT FOUND.                 ##"
         echo "##---------------------------------------------------##"
         echo "## script will exit (1)                              ##"
         echo "#######################################################"
         echo ""

         exit 1
     else
         echo "## OK: script found, sourcing into the environment   ##"
         echo "#######################################################"
         echo ""

         source ../env-setup.sh
     fi
fi

# Deletes all the secrets, services and deployments according to the order
# determined by the number at the start of the filenames.
echo "Deleting the Kubernetes Profiles under ${S_BG_PROFILES}"
echo "-------------------------------------------------------------------------"
for LS_PROFILE_FILE in $(ls  ${S_BG_PROFILES}/*.yaml)
do
  echo "   - kubectl delete -f  ${LS_PROFILE_FILE}"
  kubectl delete -f  ${LS_PROFILE_FILE}
done

# Removes the chaincode development peer container and the associated
# images.
eval $(minikube docker-env) || true
docker rm $(docker ps -a | grep dev-.*peer | awk '{print $1}')
docker rmi -f $(docker images | grep ^dev-.*peer | awk '{print $3}')
eval $(minikube docker-env -u) || true
