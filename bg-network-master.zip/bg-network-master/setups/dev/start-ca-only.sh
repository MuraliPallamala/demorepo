#!/bin/bash

# This script starts up a version of the bank guarantees network for test environments
cd "$(dirname "$0")"

# environment setup
source ../env-setup.sh

# compile templates
./compile.sh

# Create services
kubectl create -f dist/newco-fabric-service.yaml --selector='app=newco-ca'
kubectl create -f dist/anz-fabric-service.yaml --selector='app=anz-ca'
kubectl create -f dist/commbank-fabric-service.yaml --selector='app=commbank-ca'
kubectl create -f dist/testissuer-fabric-service.yaml --selector='app=testissuer-ca'
kubectl create -f dist/westpac-fabric-service.yaml --selector='app=westpac-ca'

# Create deployments
kubectl create -f dist/510-admin-fabric-deployment.yaml --selector='app=newco-ca'
kubectl create -f dist/512-anz-fabric-deployment.yaml --selector='app=anz-ca'
kubectl create -f dist/513-commbank-fabric-deployment.yaml --selector='app=commbank-ca'
kubectl create -f dist/514-testissuer-fabric-deployment.yaml --selector='app=testissuer-ca'
kubectl create -f dist/515-westpac-fabric-deployment.yaml --selector='app=westpac-ca'
