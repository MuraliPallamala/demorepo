(
    cd $GOPATH/src/github.ibm.com/bank-guarantees/bg-chaincode

    on_sigint() { kill ${PIDS[*]} && kill $$; }
    on_sigusr2() { kill ${PIDS[*]} && kill -SIGUSR2 $$; }

    count=0
    if [ -z "${MINIKUBE_IP}" ]; then
      which minikube
      if [ "$?" -eq 0 ]; then
        MINIKUBE_IP=$(minikube ip)
      else
        MINIKUBE_IP=$(ifconfig | grep 'inet 9.' | tr -s ' ' | xargs | cut -d ' ' -f2)
      fi
    fi
    peers=( $MINIKUBE_IP:30102 $MINIKUBE_IP:30202 $MINIKUBE_IP:30302 $MINIKUBE_IP:30402 $MINIKUBE_IP:30502 )

    go build -o guarantee ./cmd/guarantee/main.go
    go build -o profile ./cmd/profile/main.go

    for peer in "${peers[@]}"; do
      CORE_PEER_ADDRESS=$peer CORE_CHAINCODE_ID_NAME=guarantee:v1 ./guarantee &
      PIDS[$count]=$!
      count=$((count+1))
    done

    for peer in "${peers[@]}"; do
      CORE_PEER_ADDRESS=$peer CORE_CHAINCODE_ID_NAME=profile:v1 ./profile &
      PIDS[$count]=$!
      count=$((count+1))
    done

    trap on_sigint SIGINT
    trap on_sigusr2 SIGUSR2

    wait
)
