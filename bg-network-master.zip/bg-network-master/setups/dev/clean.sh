#!/bin/bash

# This script cleans up a version of the bank guarantees network for test environments
cd "$(dirname "$0")"

# Deletes all the secrets, services and deployments according to the order
# determined by the number at the start of the filenames.
echo "Deleting the Kubernetes Profiles under ${S_BG_PROFILES}"
echo "-------------------------------------------------------------------------"
for LS_PROFILE_FILE in $(ls  dist/*.yaml)
do
  echo "   - kubectl delete -f  ${LS_PROFILE_FILE}"
  kubectl delete -f  ${LS_PROFILE_FILE}
done

eval $(minikube docker-env)
docker rm $(docker ps -a | grep dev-.*peer | awk '{print $1}')
docker rmi -f $(docker images | grep ^dev-.*peer | awk '{print $3}')

which minikube
if [ "$?" -eq 0 ]; then
  eval $(minikube docker-env -u)
fi

rm $HOME/.bg_fabric_up || true
