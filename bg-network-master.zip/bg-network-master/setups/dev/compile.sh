#!/usr/bin/env bash

cd "$(dirname "$0")"

# environment setup
source ../env-setup.sh
BG_ENV_ASSETS=$(cd ../../assets && pwd)
# BG_ENV_ASSETS=/tmp/bg-network/assets # For hyperkit users while https://github.com/kubernetes/minikube/issues/2481 exists
BG_ENV_FABRIC_TARGET=$BG_ENV_ASSETS/local-fabric-conf/network
BG_ENV_NETWORK=$(cd ../../ && pwd)

# clean up old config
rm -rf dist
mkdir dist

# compile templates
prepare_profiles ${S_BG_ENV_PREFIX} dist ../common/templates/*.yaml templates/*.yaml
