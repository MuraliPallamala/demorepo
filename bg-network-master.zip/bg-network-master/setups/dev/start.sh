#!/bin/bash
#set -e

# This script starts up a version of the bank guarantees network for test environments
cd "$(dirname "$0")"

# environment setup
source ../env-setup.sh

# compile templates
./compile.sh

echo "Deploying the Kubernetes Profiles under ${S_BG_PROFILES}"
echo "-------------------------------------------------------------------------"
#cd  ${S_BG_PROFILES}
for LS_PROFILE_FILE in $(ls -1 dist/*.yaml)
do
  echo "   - kubectl create -f  ${LS_PROFILE_FILE}"
  kubectl create -f  ${LS_PROFILE_FILE}
done

echo "Waiting till Peers are ready"
peerPorts=( 30102 30202 30302 30402 30502 )

which minikube
if [ "$?" -eq 0 ]; then
  minikubeIp=$(minikube ip)
else
  minikubeIp=$(ifconfig | grep 'inet 9.' | tr -s ' ' | xargs | cut -d ' ' -f2)
fi
for peerPort in "${peerPorts[@]}"; do
  while ! nc -z $minikubeIp $peerPort; do sleep 1; done
done

touch $HOME/.bg_fabric_up

./watch-chaincode.sh
