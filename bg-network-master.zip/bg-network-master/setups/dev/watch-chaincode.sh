cd "$(dirname "$0")"

nodemon --exec "bash ./run-chaincode.sh" --delay 1 --watch $GOPATH/src/github.ibm.com/bank-guarantees/bg-chaincode -e go
