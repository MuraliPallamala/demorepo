# Keycloak Configuration

This repository contains a customisation of the Keycloak docker image from https://hub.docker.com/r/jboss/keycloak/.

## Configuring and Customising the Keycloak Installation

The following enviroment variables need to be defined to start a Keycloak container and their specifications can be found at https://hub.docker.com/r/jboss/keycloak/.

- `DB_VENDOR`
- `DB_DATABASE`
- `DB_ADDR`
- `DB_PORT`
- `DB_USER`
- `DB_PASSWORD`
- `KEYCLOAK_USER`
- `KEYCLOAK_PASSWORD`
- `PROXY_ADDRESS_FORWARDING`

In order to setup HTTPS for Keycloak server, Keycloak relies on a Java Keystore mounted onto the image located at:
`opt/jboss/keycloak/standalone/configuration/security/keycloak.jks`

In order to setup Mutual TLS for Keycloak server, Keycloak relies on a Java Truststore mounted onto the image located at:
`opt/jboss/keycloak/standalone/configuration/security/truststore.jks`

Also, to enable Mutual TLS, the following variables need to be set to true:
- `TLS_MA` (true|false, default: false): used to enable/disable the TLS mutual authentication configuration for Keycloak. When this flag is enabled, the NginX container will require a client certificat and key to connect to keycloak.

You need to pass in the keystore and truststore password by specifying the following environment variable:
- `KEYSTORE_PASSWORD`: this is used to access the Java keystore containing the TLS server certificate that identifies the server within an HTTPS connection.
- `TRUSTSTORE_PASSWORD`: this is used to access the Java truststore containing the CA certificate that is used to validate client certificates within an HTTPS connection.



## Configuring and Customising the NginX Reverse Proxy


The NginX instance for Keycloak relies on the bank-guarantees/nginx component (https://github.ibm.com/bank-guarantees/nginx), but it replaces the `api.template` for the `keycloak.template`.

By doing that, it eliminates the need of defining the environment variables related to the `api.template` from nginx project which are:
- `TMPL_API_URL`
- `TMPL_UPSTREAM_CA_FILEPATH`
- `TMPL_MAX_CLIENT_BODY_SIZE`
- `TMPL_RATE_LIMIT_BURST`
- `TMPL_RATE_LIMIT_IN_REQUESTS_PER_SECOND`


On the other hand, because it introduces `keycloack.template`, it requires that we specify the following environment variables:

- `TLS_MA` (true|false, default: false): used to enable/disable the TLS mutual authentication configuration for Keycloak. When this flag is enabled, the NginX container will require a client certificat and key to connect to keycloak. 
- `TMPL_CLIENT_PREFIX`: this is used to uniform the names for our deployment. The variable is used to compose the name of the client certificate used by NginX.
- `TMPL_KEYCLOAK_URL`: similar purpose of `TMPL_API_URL` but using Keycloak server URL, obviously.
- `TMPL_KEYCLOAK_HOST_NAME`: this variable replaces the need of specifying: `TMPL_UPSTREAM_CA_FILEPATH`, `TMPL_UPSTREAM_CLIENTCERT_FILEPATH`, `TMPL_UPSTREAM_CLIENTCERT_KEY_FILEPATH` and `SSL_CLIENT_CERT_AUTHENTICATION`. The first three variables are automatically derived from the host name as follows:
   - `TMPL_UPSTREAM_CA_FILEPATH`: `/etc/nginx/certs/${TMPL_KEYCLOAK_HOST_NAME}.ca.pem`
   - `TMPL_UPSTREAM_CLIENTCERT_FILEPATH`: `/etc/nginx/certs/${TMPL_CLIENT_PREFIX}${TMPL_KEYCLOAK_HOST_NAME}.CLIENT.pem`
   - `TMPL_UPSTREAM_CLIENTCERT_KEY_FILEPATH`: `/etc/nginx/certs/${TMPL_CLIENT_PREFIX}${TMPL_KEYCLOAK_HOST_NAME}.CLIENT.key`
   - `SSL_CLIENT_CERT_AUTHENTICATION`: `true`

**NOTE:** this is just a semantic mapping, since the `keycloak.template` file does not uses the environment variables that the base NginX image uses in `api.template`, but replaces them with this derivation logic, that yelds the same configuration result by only specifing one environment variable. On the other hand, it does remove the flexibility that we have in the base image to switch on/off these features. Furthermore, it also imposes a certain convention on the location and the expected names that certificates and keys need to have.

 
# Getting the System Up and Runnning

To bring the system up and running for a local test you simply need to add the DNS mapping:

```
   127.0.0.1	mozumbo.dlt.res.ibm.com
```

to your local `/etc/hosts` (or equivalent for Windows systems) and run:

```
   make start
```

The first command will provide a mapping to resolve the fully qualified name exposed by the `NginX` container in the certificate to your local machine, while the second command brings entire system up by performing the following operations:

- building the NginX and Keycloak images (i.e. targets `build-nginx` and `build-keycloak`)
- generating the required crypto material for the TLS connection to the NginX container (i.e. `cd nginx && make certs`)
- copying the required crypto material into the `mounts/nginx/certs/` folder.
- generating the required crypto material for the upstram TLS connection to the Keycloak container (i.e. `cd keycloak && make test`)
- copying the required crypto material into the `mounts/nginx/certs/` folder and `mounts/keycloak/security` folder`.
- running `docker-compose up` to start the system (see `docker-compose.yaml`).

Once both containers have successfully initialised, you can access the NginX container by entering in the browser `https://mozumbo.dlt.res.ibm.com` and to verify that the upstream connection to Keycloak works you can enter the following url:

```
   https://mozumbo.dlt.res.ibm.com/auth/realms/master
```  

This will cause NginX to initialise establish the upstream connection and provid information about the master realm, in JSON format. If the connection is successful, you should see something as follows:

```
{"realm":"master","public_key":"...<base64-string>...","token-service":"https://mozumbo.dlt.res.ibm.com/auth/realms/master/protocol/openid-connect","account-service":"https://mozumbo.dlt.res.ibm.com/auth/realms/master/account","tokens-not-before":0}
```

You can also, directly connect to Keycloak by entering in the browser `https://localhost:8443/auth/realms/master`. If you want to use this approach, you may want to add the following mapping to the `/etc/hosts` file:

```
   127.0.0.1    keycloak.mozumbo.dlt.res.ibm.com
```

and access the instance by using its fully qualified name.  If the keycloak instance is configured with `TLS_MA=true` the `start` target has also copied the client certificate and key into a P12 bundle under the `mounts/keycloak/` folder. The default password to access this certificate is `p4ssW0rd`. This aspect, as any other aspect of the certificaate creation setup can be changed, by either modifying the `docker-compose.yaml` or the `Makefile`.  In this particular case, to change the P12 bundle password, it is sufficient to define in th `env` section of the `keycloak` service the variable: `CLIENT_CERTIFICATE_P12_PASSWORD`.


