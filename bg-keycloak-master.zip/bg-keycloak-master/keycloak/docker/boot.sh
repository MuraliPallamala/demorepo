#!/bin/bash

# This script checks whether a Java Keystore has been mounted onto the image
# and if not it creates a self-signed certificate and a kystore so that the
# server can run HTTPS.

DEFAULT_KEYSTORE_PASSWORD=k3y5t0r3
DEFAULT_TRUSTSTORE_PASSWORD=tru5t5t0r3
DEFAULT_P12_KEYSTORE_PASSWORD=p4ssW0rd

BOOT_TEST=${BOOT_TEST:-false}

KEYCLOAK_DOCKER_ENTRYPOINT=/opt/jboss/docker-entrypoint.sh
KEYCLOAK_ROOT=${KEYCLOAK_ROOT:-/opt/jboss/keycloak}
KEYCLOAK_TEMP=${KEYCLOAK_ROOT}/tmp
KEYCLOAK_CONFIGURATION=${KEYCLOAK_ROOT}/standalone/configuration
KEYCLOAK_SECURITY=${KEYCLOAK_CONFIGURATION}/security
KEYSTORE_PATH=${KEYCLOAK_SECURITY}/keycloak.jks
TRUSTSTORE_PATH=${KEYCLOAK_SECURITY}/truststore.jks

TLS_MA=${TLS_MA:-false}


CERTIFICATE_COUNTRY=${CERTIFICATE_COUNTRY:-AU}
CERTIFICATE_STATE=${CERTIFICATE_STATE:-Victoria}
CERTIFICATE_LOCATION=${CERTIFICATE_LOCATION:-Melbourne}
CERTIFICATE_ORGANIZATION=${CERTIFICATE_ORGANIZATION:-IBM}
CERTIFICATE_ORGANIZATIONAL_UNIT=${CERTIFICATE_ORGANIZATIONAL_UNIT:-"Blockchain"}
CERTIFICATE_COMMON_NAME=${CERTIFICATE_COMMON_NAME:-services-core.dlt.res.ibm.com}
CERTIFICATE_SUBJECT="/C=${CERTIFICATE_COUNTRY}/ST=${CERTIFICATE_STATE}/L=${CERTIFICATE_LOCATION}/O=${CERTIFICATE_ORGANIZATION}/OU=${CERTIFICATE_ORGANIZATIONAL_UNIT}/CN=${CERTIFICATE_COMMON_NAME}"


CERTIFICATE_PATH=${KEYCLOAK_TEMP}/${CERTIFICATE_COMMON_NAME}.pem
CERTIFICATE_KEY_PATH=${KEYCLOAK_TEMP}/${CERTIFICATE_COMMON_NAME}.key
CERTIFICATE_CSR_PATH=${KEYCLOAK_TEMP}/${CERTIFICATE_COMMON_NAME}.csr
CERTIFICATE_KEYSTORE_ALIAS=cert
CERTIFICATE_KEYSTORE_P12=${KEYCLOAK_TEMP}/${CERTIFICATE_COMMON_NAME}.p12

function check_ok {

  if [[ "$?" -ne 0 ]]; then
    echo ""
    echo "[ERROR] - $1 (exit code: $2)";
    echo ""
    exit $2
  fi
}


mkdir -p ${KEYCLOAK_TEMP}
check_ok "Could not create temp directory: ${KEYCLOAK_TEMP}" 1


mkdir -p ${KEYCLOAK_SECURITY}
check_ok "Could not create directory: ${KEYCLOAK_SECURITY}" 1

echo "1. Checking for Keystore..."

if [ ! -f "${KEYSTORE_PATH}" ]; then
  
  echo "  - Keystore file NOT FOUND (path: ${KEYSTORE_PATH})"

  if [ -z "${KEYSTORE_PASSWORD}" ]; then
	  
    echo "  - Environment variable KEYSTORE_PASSWORD is NOT DEFINED, exporting a new variable."
    export KEYSTORE_PASSWORD=${DEFAULT_KEYSTORE_PASSWORD}

  else
    
    echo "  - Environment variable KEYSTORE_PASSWORD is defined."
  fi
  
  echo "  - Creating the server certificate.."
  echo "     - Country                :  ${CERTIFICATE_COUNTRY}"
  echo "     - State                  :  ${CERTIFICATE_STATE}"
  echo "     - Location               :  ${CERTIFICATE_LOCATION}"
  echo "     - Organization           :  ${CERTIFICATE_ORGANIZATION}"
  echo "     - Organizational Unit    :  ${CERTIFICATE_ORGANIZATIONAL_UNIT}" 
  echo "     - Common Name            :  ${CERTIFICATE_COMMON_NAME}"   
  echo ""

  CA_CERTIFICATE_COMMON_NAME=${CERTIFICATE_COMMON_NAME}.ca
  CA_CERTIFICATE_PATH=${KEYCLOAK_TEMP}/${CA_CERTIFICATE_COMMON_NAME}.pem
  CA_CERTIFICATE_KEY_PATH=${KEYCLOAK_TEMP}/${CA_CERTIFICATE_COMMON_NAME}.key
  CA_CERTIFICATE_SERIAL_PATH=${KEYCLOAK_TEMP}/${CA_CERTIFICATE_COMMON_NAME}.srl
  CA_CERTIFICATE_SUBJECT="/C=${CERTIFICATE_COUNTRY}/ST=${CERTIFICATE_STATE}/L=${CERTIFICATE_LOCATION}/O=${CERTIFICATE_ORGANIZATION}/OU=${CERTIFICATE_ORGANIZATIONAL_UNIT}/CN=${CA_CERTIFICATE_COMMON_NAME}"

  echo "     - (CA Certificate)              openssl req -x509 -nodes -newkey rsa:4096 -days 365 -subj \"${CA_CERTIFICATE_SUBJECT}\" -keyout ${CA_CERTIFICATE_KEY_PATH} -out ${CA_CERTIFICATE_PATH}" 
  openssl req -x509 -nodes -newkey rsa:4096 -days 365 -subj "${CA_CERTIFICATE_SUBJECT}" -keyout ${CA_CERTIFICATE_KEY_PATH} -out ${CA_CERTIFICATE_PATH}
  check_ok "Could not create CA certificate." 2

  echo "     - (Certificate Key)             openssl genrsa -out ${CERTIFICATE_KEY_PATH} 4096"
  openssl genrsa -out ${CERTIFICATE_KEY_PATH} 4096
  check_ok "Could not create certificate key." 3

  echo "     - (Certificate Signing Request) openssl req -new -key ${CERTIFICATE_KEY_PATH} -out ${CERTIFICATE_CSR_PATH} -subj \"${CERTIFICATE_SUBJECT}\""
  openssl req -new -key ${CERTIFICATE_KEY_PATH} -out ${CERTIFICATE_CSR_PATH} -subj "${CERTIFICATE_SUBJECT}"
  check_ok "Could not create certificate signing request." 4
  
  echo "     - (Certificate)                 openssl x509 -req -days 365 -in ${CERTIFICATE_CSR_PATH} -CA ${CA_CERTIFICATE_PATH} -CAkey ${CA_CERTIFICATE_KEY_PATH} -CAcreateserial -CAserial ${CA_CERTIFICATE_SERIAL_PATH} -out ${CERTIFICATE_PATH}"
  openssl x509 -req -days 365 -in ${CERTIFICATE_CSR_PATH} -CA ${CA_CERTIFICATE_PATH} -CAkey ${CA_CERTIFICATE_KEY_PATH} -CAcreateserial -CAserial ${CA_CERTIFICATE_SERIAL_PATH} -out ${CERTIFICATE_PATH}
  check_ok "Could not generate server  certificate." 5

  echo "  - Exporting certificate and key as P12 Keystore.."
  echo "     - openssl pkcs12 -export -in ${CERTIFICATE_PATH} -inkey ${CERTIFICATE_KEY_PATH} -out ${CERTIFICATE_KEYSTORE_P12} -name ${CERTIFICATE_KEYSTORE_ALIAS} -password pass:*******"
  openssl pkcs12 -export -in ${CERTIFICATE_PATH} -inkey ${CERTIFICATE_KEY_PATH} -out ${CERTIFICATE_KEYSTORE_P12} -name ${CERTIFICATE_KEYSTORE_ALIAS} -password pass:${KEYSTORE_PASSWORD}
  check_ok "Could not export certificate as a P12 bundle." 6 
  
  echo ""
  
  # NOTE: the certificate key password, must be the same of the keystore password, otherwise when
  #       the java runtime loads the keystore it won't be able to open up the key.
  #
  echo "  - Importing Certificates into  Java Keystore..."
  echo "    - (P12 Bundle)	keytool -importkeystore -deststorepass ********** -destkeypass ********** -destkeystore ${KEYSTORE_PATH} -srckeystore ${CERTIFICATE_KEYSTORE_P12} -srcstoretype PKCS12 -srcstorepass ************ -alias ${CERTIFICATE_KEYSTORE_ALIAS}"
  keytool -importkeystore -deststorepass ${KEYSTORE_PASSWORD} -destkeypass ${KEYSTORE_PASSWORD} -destkeystore ${KEYSTORE_PATH} -srckeystore ${CERTIFICATE_KEYSTORE_P12} -srcstoretype PKCS12 -srcstorepass ${KEYSTORE_PASSWORD} -alias ${CERTIFICATE_KEYSTORE_ALIAS}
  check_ok "Could not import P12 bundle into the java keystore." 7

  echo "    - (CA Certificate)  keytool -import -file ${CA_CERTIFICATE_PATH} -keystore ${KEYSTORE_PATH} -storetype JKS -storepass **********  -noprompt"
  keytool -import -file ${CA_CERTIFICATE_PATH} -keystore ${KEYSTORE_PATH} -storetype JKS -storepass ${KEYSTORE_PASSWORD} -noprompt
  check_ok "Could not import CA certificate into the java keystore." 8

else

  echo "  - Keystore file FOUND (path: ${KEYSTORE_PATH})."

fi

echo "  - Verify content of the Java Keystore: ${KEYSTORE_PATH} ..."
echo "    - keytool -list -v -keystore ${KEYSTORE_PATH} -storepass *************** | grep \"${CERTIFICATE_COMMON_NAME}\""
keytool -list -v -keystore ${KEYSTORE_PATH} -storepass ${KEYSTORE_PASSWORD} | grep "${CERTIFICATE_COMMON_NAME}"
check_ok "Could not verify the content of the keystore." 9

echo "" 
echo "2. Checking setup for TLS mutual authentication..."
echo "   - TLS_MA is set to: ${TLS_MA}"

if [ "${TLS_MA}" = "true" ]; then
  echo "   - Enabling TLS mutual authentication..."

  echo "   - Checking for truststore password: TRUSTSTORE_PASSWORD..."
  if [ -z "${TRUSTSTORE_PASSWORD}" ]; then
    echo "   - Environment variable NOT DEFINED, exporting default truststore password..."
    export TRUSTSTORE_PASSWORD=${DEFAULT_TRUSTSTORE_PASSWORD}
  else
    echo "   - Environment variable found."
  fi	  

  echo "   - Checking for truststore: ${TRUSTSTORE_PATH} ..."
  if [ -f "${TRUSTSTORE_PATH}" ]; then
    echo "   - Truststore file FOUND, skipping generation of client certificate chain."
  else
    echo "   - Trustore file NOT FOUND, generating client certificate chain..."
    
    
    CLIENT_CA_CERTIFICATE_COMMON_NAME="${CERTIFICATE_COMMON_NAME}.CLIENT.ca"
    CLIENT_CA_CERTIFICATE_SUBJECT="/C=${CERTIFICATE_COUNTRY}/ST=${CERTIFICATE_STATE}/L=${CERTIFICATE_LOCATION}/O=${CERTIFICATE_ORGANIZATION}/OU=${CERTIFICATE_ORGANIZATIONAL_UNIT}/CN=${CLIENT_CA_CERTIFICATE_COMMON_NAME}"
   
    CLIENT_CA_CERTIFICATE_KEY_PATH=${KEYCLOAK_TEMP}/${CLIENT_CA_CERTIFICATE_COMMON_NAME}.key
    CLIENT_CA_CERTIFICATE_PATH=${KEYCLOAK_TEMP}/${CLIENT_CA_CERTIFICATE_COMMON_NAME}.pem
    CLIENT_CA_CERTIFICATE_SERIAL_PATH=${KEYCLOAK_TEMP}/${CLIENT_CA_CERTIFICATE_COMMON_NAME}.srl


    echo "   - Generating CA root for client certificates.."
    echo "     - Country                :  ${CERTIFICATE_COUNTRY}"
    echo "     - State                  :  ${CERTIFICATE_STATE}"
    echo "     - Location               :  ${CERTIFICATE_LOCATION}"
    echo "     - Organization           :  ${CERTIFICATE_ORGANIZATION}"
    echo "     - Organizational Unit    :  ${CERTIFICATE_ORGANIZATIONAL_UNIT}" 
    echo "     - Common Name            :  ${CERTIFICATE_COMMON_NAME}"   
    echo ""

    echo "     - (Private Key) openssl genrsa -out ${CLIENT_CA_CERTIFICATE_KEY_PATH} 4096"
    openssl genrsa -out ${CLIENT_CA_CERTIFICATE_KEY_PATH} 4096
    check_ok "Could not create CA root key." 10

    echo "     - (Certificate) openssl req -x509 -sha256 -new -nodes -key ${CLIENT_CA_CERTIFICATE_KEY_PATH} -days 365 -out ${CLIENT_CA_CERTIFICATE_PATH} -subj \"${CLIENT_CA_CERTIFICATE_SUBJECT}\""
    openssl req -x509 -sha256 -new -nodes -key ${CLIENT_CA_CERTIFICATE_KEY_PATH} -days 365 -out ${CLIENT_CA_CERTIFICATE_PATH} -subj "${CLIENT_CA_CERTIFICATE_SUBJECT}"
    check_ok "Could not create CA root certificate." 11

    echo "   - Importing the certificate into the trust store..."
    echo "     - keytool -import -rfc -alias clientca   -file ${CLIENT_CA_CERTIFICATE_PATH} -keystore ${TRUSTSTORE_PATH} -storetype JKS -storepass ************* -keypass ************** -noprompt"
    keytool -import -rfc -alias clientca -file ${CLIENT_CA_CERTIFICATE_PATH} -keystore ${TRUSTSTORE_PATH} -storetype JKS -storepass ${TRUSTSTORE_PASSWORD} -keypass ${TRUSTSTORE_PASSWORD} -noprompt
    check_ok "Could not import the CA root into trust store." 12

    CLIENT_CERTIFICATE_COMMON_NAME="${CERTIFICATE_COMMON_NAME}.CLIENT"
    CLIENT_CERTIFICATE_SUBJECT="/C=${CERTIFICATE_COUNTRY}/ST=${CERTIFICATE_STATE}/L=${CERTIFICATE_LOCATION}/O=${CERTIFICATE_ORGANIZATION}/OU=${CERTIFICATE_ORGANIZATIONAL_UNIT}/CN=${CLIENT_CERTIFICATE_COMMON_NAME}"

    CLIENT_CERTIFICATE_CSR_PATH=${KEYCLOAK_TEMP}/${CLIENT_CERTIFICATE_COMMON_NAME}.csr
    CLIENT_CERTIFICATE_KEY_PATH=${KEYCLOAK_TEMP}/${CLIENT_CERTIFICATE_COMMON_NAME}.key
    CLIENT_CERTIFICATE_PATH=${KEYCLOAK_TEMP}/${CLIENT_CERTIFICATE_COMMON_NAME}.pem
    CLIENT_CERTIFICATE_P12_PATH=${KEYCLOAK_SECURITY}/${CLIENT_CERTIFICATE_COMMON_NAME}.p12
    CLIENT_CERTIFICATE_P12_PASSWORD=${CLIENT_CERTIFICATE_P12_PASSWORD:-${DEFAULT_P12_KEYSTORE_PASSWORD}}
    CLIENT_CERTIFICATE_ALIAS=${CLIENT_CERTIFICATE_COMMON_NAME} 


    echo "   - Generating a sample client certificate...."
    
    echo "     - generating the certificate private key.."
    echo "       - openssl genrsa -out ${CLIENT_CERTIFICATE_KEY_PATH} 4096"
    openssl genrsa -out ${CLIENT_CERTIFICATE_KEY_PATH} 4096
    check_ok "Could not create private key, for sample client certificate." 13
    
    echo "     - generating the CSR.."
    echo "       - openssl req -new -key ${CLIENT_CERTIFICATE_KEY_PATH} -out ${CLIENT_CERTIFICATE_CSR_PATH} -subj \"${CLIENT_CERTIFICATE_SUBJECT}\""
    openssl req -new -key ${CLIENT_CERTIFICATE_KEY_PATH} -out ${CLIENT_CERTIFICATE_CSR_PATH} -subj "${CLIENT_CERTIFICATE_SUBJECT}"
    check_ok "Could not create CSR for sample client certificte." 14

    echo "     - generating the client certificate.."
    echo "       - openssl x509 -req -days 365 -in ${CLIENT_CERTIFICATE_CSR_PATH} -CA ${CLIENT_CA_CERTIFICATE_PATH} -CAkey ${CLIENT_CA_CERTIFICATE_KEY_PATH} -CAcreateserial -CAserial ${CLIENT_CA_CERTIFICATE_SERIAL_PATH} -out ${CLIENT_CERTIFICATE_PATH}"
    openssl x509 -req -days 365 -in ${CLIENT_CERTIFICATE_CSR_PATH} -CA ${CLIENT_CA_CERTIFICATE_PATH} -CAkey ${CLIENT_CA_CERTIFICATE_KEY_PATH} -CAcreateserial -CAserial ${CLIENT_CA_CERTIFICATE_SERIAL_PATH} -out ${CLIENT_CERTIFICATE_PATH}
    check_ok "Could not create sample client certificate." 15

    echo "     - exporting the certificate and key in P12 format.."
    echo "       - openssl pkcs12 -export -in ${CLIENT_CERTIFICATE_PATH} -inkey ${CLIENT_CERTIFICATE_KEY_PATH} -out ${CLIENT_CERTIFICATE_P12_PATH} -name ${CLIENT_CERTIFICATE_ALIAS} -password pass:***************"
    openssl pkcs12 -export -in ${CLIENT_CERTIFICATE_PATH} -inkey ${CLIENT_CERTIFICATE_KEY_PATH} -out ${CLIENT_CERTIFICATE_P12_PATH} -name ${CLIENT_CERTIFICATE_ALIAS} -password pass:${CLIENT_CERTIFICATE_P12_PASSWORD}
    check_ok "Could not export client certificate into P12 bundle." 16
 
  fi

  echo "  - Verify content of the Java trust store: ${TRUSTSTORE_PATH} ..."
  echo "    - keytool -list -v -keystore ${TRUSTSTORE_PATH} -storepass *************** | grep \"${CERTIFICATE_COMMON_NAME}\""
  keytool -list -v -keystore ${TRUSTSTORE_PATH} -storepass ${TRUSTSTORE_PASSWORD} | grep "${CERTIFICATE_COMMON_NAME}"
  check_ok "Could not verify the content of the trust store." 17


  KEYCLOAK_CONFIGURATION_SOURCE="standalone-tls-ma.xml.template" 

else

  echo "   - Skipping TLS mutual authentication setup..."
  KEYCLOAK_CONFIGURATION_SOURCE="standalone.xml.template"

fi 


echo "   - Updating Keycloak configuration.."
echo "     - ${KEYCLOAK_CONFIGURATION}/${KEYCLOAK_CONFIGURATION_SOURCE} ==> ${KEYCLOAK_CONFIGURATION}/standalone.xml"
cp ${KEYCLOAK_CONFIGURATION}/${KEYCLOAK_CONFIGURATION_SOURCE} ${KEYCLOAK_CONFIGURATION}/standalone.xml
check_ok "Could not copy Keycloak configuration file." 18

echo ""

if [ "${BOOT_TEST}" = "false" ]; then

  echo ""
  echo "3. Yelding control to main process.."
  echo "   - exec ${KEYCLOAK_DOCKER_ENTRYPOINT} -b 0.0.0.0"

  exec ${KEYCLOAK_DOCKER_ENTRYPOINT} -b 0.0.0.0

else
  
  echo "3. Skipping Keycloak start-up (BOOT_TEST: ${BOOT_TEST}).."
  echo ""

fi
