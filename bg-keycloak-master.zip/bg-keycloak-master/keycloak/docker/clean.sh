#!/bin/bash

KEYCLOAK_ROOT="/opt/jboss/keycloak"
KEYCLOAK_TEMP="${KEYCLOAK_ROOT}/tmp"
KEYCLOAK_CONF="${KEYCLOAK_ROOT}/standalone/configuration"


echo "1. Removing temporary files.."
echo "   - rm ${KEYCLOAK_TEMP}/*"
rm ${KEYCLOAK_TEMP}/*


echo ""
echo "2. Removing keystore files.."
echo "   - rm  ${KEYCLOAK_CONF}/security/*"
rm ${KEYCLOAK_CONF}/security/*

echo ""
echo "3. Removing configuration files.."
echo "   - rm ${KEYCLOAK_CONF}/standalone.xml" 

rm ${KEYCLOAK_CONF}/standalone.xml

echo ""
echo "4. Done"
echo ""

