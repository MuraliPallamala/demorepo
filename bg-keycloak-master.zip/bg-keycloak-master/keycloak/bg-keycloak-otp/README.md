Custom API Module To Set User's OTP Seed
========================================

1. Build the JAR
```
mvn clean install

```
2. Download Keycloak so that we can install the module in it

```
export KEYCLOAK_DIST=4.0.0.Final
export KEYCLOAK_HOME=./keycloak-$KEYCLOAK_DIST
wget https://downloads.jboss.org/keycloak/$KEYCLOAK_DIST/keycloak-$KEYCLOAK_DIST.tar.gz
tar -xzf keycloak-$KEYCLOAK_DIST.tar.gz
```

3. Deploy the jar as a module by running:

```
$KEYCLOAK_HOME/bin/jboss-cli.sh --command="module remove --name=com.ibm.au.bgx.keycloak.bg-keycloak-otp"
$KEYCLOAK_HOME/bin/jboss-cli.sh --command="module add --name=com.ibm.au.bgx.keycloak.bg-keycloak-otp --resources=target/bg-keycloak-otp-0.1.0.jar --dependencies=org.keycloak.keycloak-core,org.keycloak.keycloak-server-spi,org.keycloak.keycloak-server-spi-private,org.keycloak.keycloak-services,javax.ws.rs.api"

```
    
4. Then registering the provider by editing `$KEYCLOAK_HOME/standalone/configuration/standalone.xml` 
and adding the module to the providers element (under `<subsystem xmlns="urn:jboss:domain:keycloak-server:1.1">`):

```
    <providers>
        ...
        <provider>module:com.ibm.au.bgx.keycloak.bg-keycloak-otp</provider>
    </providers>

OR

sed -i -- 's/classpath:${jboss.home.dir}\/providers\/\*/classpath:${jboss.home.dir}\/providers\/*<\/provider>\
                <provider>module:com.ibm.au.bgx.keycloak.bg-keycloak-otp/g' $KEYCLOAK_HOME/standalone/configuration/standalone.xml

```

5. Then start (or restart) the server. 
```
$KEYCLOAK_HOME/bin/standalone.sh

```
6 Add admin user in a separate terminal after Keyclok has started

```
$KEYCLOAK_HOME/bin/add-user-keycloak.sh -r master -u admin -p <password> 

```

7. Once started open [http://localhost:8080/auth/realms/master/otp] and you should see the message _OTP API is available for realm 'master'_.
You can also invoke the endpoint for other realms by replacing `master` with the realm name in the above url.

8. In order to set a user's OTP seed under realm, make a `PUT` request to [http://localhost:8080/auth/realms/{realm}/otp/users/{user_id}].

9. In order to delete a user's OTP seed under realm, make a `DELETE` request to [http://localhost:8080/auth/realms/{realm}/otp/users/{user_id}].

Note: As a temporary measure, the APIs need access token from master realm to authorize the operation.
