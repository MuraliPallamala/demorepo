package com.ibm.au.bgx.keycloak;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.http.HttpStatus;
import org.keycloak.Config;
import org.keycloak.credential.CredentialModel;
import org.keycloak.forms.login.freemarker.model.TotpBean;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserCredentialModel;
import org.keycloak.models.UserModel;
import org.keycloak.models.cache.UserCache;
import org.keycloak.models.utils.Base32;
import org.keycloak.models.utils.CredentialValidation;
import org.keycloak.services.managers.AppAuthManager;
import org.keycloak.services.managers.AuthenticationManager.AuthResult;
import org.keycloak.services.managers.RealmManager;
import org.keycloak.services.resource.RealmResourceProvider;
import org.keycloak.storage.UserStorageManager;

/**
 * This is used to remotely set OTP seed for a given user in a given realm
 *
 * @author Lenin Mehedy <lenin.mehedy@au1.ibm.com>
 */
public class OtpResourceProvider implements RealmResourceProvider {

    public static final Logger LOGGER = Logger.getLogger(OtpResourceProvider.class.getName());

    private static final String ERROR_USER_NOT_FOUND = "User '%s' does not exist.";

    private static final String ERROR_AUTHENTICATION_REQUIRED = "Authentication by master realm is required.";

    private static final String KEY_OTP_ENCODED_SECRET = "secret";

    private static final String KEY_OTP_TOKEN = "token";

    private KeycloakSession session;

    public OtpResourceProvider(KeycloakSession session) {
        this.session = session;
    }

    public Object getResource() {
        return this;
    }

    @GET
    @Produces("text/plain; charset=utf-8")
    public String get() {
        return String
            .format("OTP API is available for realm '%s'", session.getContext().getRealm().getId());
    }

    /**
     * Get OTP setup for the user base on the realms OTPPolicy setup
     */
    @GET
    @Path("/users/{user_id}/setup")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSetup(
        @PathParam("user_id") String userId
    ) {

        try {
            // We need the user be authenticated using master realm
            // Ideally authenticated user should have role to managed other users
            if (this.isAuthenticatedByMasterRealm() == null) {
                throw new NotAuthorizedException(ERROR_AUTHENTICATION_REQUIRED);
            }

            RealmModel realm = session.getContext().getRealm();

            // Get the user
            UserStorageManager userStorageManager = new UserStorageManager(session);
            UserModel user = userStorageManager.getUserById(userId, realm);
            if (user == null) {
                throw new IllegalArgumentException(String.format(ERROR_USER_NOT_FOUND, userId));
            }

            TotpBean totpBean = new TotpBean(
                session,
                realm,
                user,
                session.getContext().getUri().getRequestUriBuilder());

            return Response.ok().entity(totpBean).build();

        } catch (Exception e) {
            return this.prepareErrorResponse(e);
        }
    }

    /**
     * This method is used to set the OTP seed of an user
     *
     * The OTP type should be already set in the realm, and the seed need to be a valid OTP seed
     * base on the OTP type
     *
     * Full API endpoint: "PUT /auth/realms/{realm}/otp/users/{user_id}
     *
     * It requires the payload to contain base32 encoded secret as defined by `totpSecretEncoded` in
     * the response
     */
    @PUT
    @Path("/users/{user_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateOtp(
        @PathParam("user_id") String userId,
        final Map<String, String> payload) {

        try {

            // We need the user be authenticated using master realm
            // Ideally authenticated user should have role to managed other users
            if (this.isAuthenticatedByMasterRealm() == null) {
                throw new NotAuthorizedException(ERROR_AUTHENTICATION_REQUIRED);
            }

            // Payload validation
            if (payload == null
                || !payload.containsKey(KEY_OTP_ENCODED_SECRET)
                || payload.get(KEY_OTP_ENCODED_SECRET) == null
                || payload.get(KEY_OTP_ENCODED_SECRET).equals("")
                || !payload.containsKey(KEY_OTP_TOKEN)
                || payload.get(KEY_OTP_TOKEN) == null
                || payload.get(KEY_OTP_TOKEN).equals("")) {

                throw new IllegalArgumentException(String
                    .format("Payload must contain values for '%s' and '%s'.",
                        KEY_OTP_ENCODED_SECRET, KEY_OTP_TOKEN));
            }

            String otpSecretEncoded = payload.get(KEY_OTP_ENCODED_SECRET).trim().replaceAll("\\s+", "");
            String otpToken = payload.get(KEY_OTP_TOKEN).trim().replaceAll("\\s+", "");

            LOGGER.log(Level.INFO, String.format("Setting OTP for user '%s', with secret '%s' and token: '%s'", userId, otpSecretEncoded, otpToken));

            if (otpSecretEncoded.matches("^.*[^A-Z0-7].*$")) {
                throw new IllegalArgumentException(
                    "Secret cannot be null and must be a Base32 encoded string.");
            }

            // convert Base32 secret
            String otpSecret = new String(Base32.decode(otpSecretEncoded));
            if (otpSecret.equals("") || otpSecret.matches("^.*[^a-zA-Z0-9].*$")) {
                throw new IllegalArgumentException(
                    "Secret cannot be empty or contain non-alphanumeric characters.");
            }

            RealmModel realm = session.getContext().getRealm();

            // validate OTP secret and token
            if (!CredentialValidation.validOTP(realm, otpToken, otpSecret)) {
                throw new IllegalArgumentException("OTP token is not valid for the given secret.");
            }

            // Get the user
            UserStorageManager userStorageManager = new UserStorageManager(session);
            UserModel user = userStorageManager.getUserById(userId, realm);
            if (user == null) {
                throw new IllegalArgumentException(String.format(ERROR_USER_NOT_FOUND, userId));
            }

            // Setup the credential
            UserCredentialModel credentials = new UserCredentialModel();
            credentials.setType(realm.getOTPPolicy().getType());
            credentials.setValue(otpSecret);

            // Store the credential
            session.userCredentialManager().updateCredential(realm, user, credentials);

            // remove user from cache
            UserCache userCache = session.userCache();
            if (userCache != null) {
                userCache.evict(realm, user);
            }

            return Response.noContent().build();

        } catch (Exception e) {
            return this.prepareErrorResponse(e);
        }
    }

    /**
     * This method is used to delete the OTP seed of an user
     *
     * Full API endpoint: "DELETE /auth/realms/{realm}/otp/users/{user_id}
     */
    @DELETE
    @Path("/users/{user_id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteOtp(@PathParam("user_id") String userId) {

        try {
            // We need the user be authenticated using master realm
            // Ideally authenticated user should have role to managed other users
            if (this.isAuthenticatedByMasterRealm() == null) {
                throw new NotAuthorizedException(ERROR_AUTHENTICATION_REQUIRED);
            }

            RealmModel realm = session.getContext().getRealm();

            // Get the user
            UserStorageManager userStorageManager = new UserStorageManager(session);
            UserModel user = userStorageManager.getUserById(userId, realm);
            if (user == null) {
                throw new IllegalArgumentException(String.format(ERROR_USER_NOT_FOUND, userId));
            }

            // Find the OTP credentials of the user
            CredentialModel credentials = null;
            List<CredentialModel> creds = session.userCredentialManager()
                .getStoredCredentials(realm, user);

            for (CredentialModel cred : creds) {
                if (cred.getType().equals(realm.getOTPPolicy().getType())) {
                    credentials = cred;
                    break;
                }
            }

            if (credentials != null) {
                // Remove the OTP credential of the user
                session.userCredentialManager()
                    .removeStoredCredential(realm, user, credentials.getId());

                // remove user from cache
                UserCache userCache = session.userCache();
                if (userCache != null) {
                    userCache.evict(realm, user);
                }
            }

            return Response.noContent().build();

        } catch (Exception e) {
            return this.prepareErrorResponse(e);
        }
    }

    public void close() {
        // nothing to do
    }

    /**
     * Helper function to authenticate using master realm
     */
    private AuthResult isAuthenticatedByMasterRealm() {
        final RealmManager realmManager = new RealmManager(session);
        final RealmModel adminRealm = realmManager.getRealm(Config.getAdminRealm());
        if (adminRealm == null) {
            throw new NotFoundException("Admin realm couldn't be found for authorization");
        }

        return new AppAuthManager().authenticateBearerToken(session, adminRealm);
    }

    private Response prepareErrorResponse(Exception e) {

        String error = e.getMessage();

        int status = HttpStatus.SC_INTERNAL_SERVER_ERROR;

        if (e instanceof IllegalArgumentException) {
            status = HttpStatus.SC_BAD_REQUEST;
        } else if (e instanceof NotAuthorizedException) {
            status = HttpStatus.SC_UNAUTHORIZED;
            error = ((NotAuthorizedException) e).getChallenges().get(0).toString();
        }

        Map<String, String> resp = new HashMap<String, String>();
        resp.put("error", error);

        return Response.status(status)
            .entity(resp)
            .build();
    }
}
