# KeyCloak Server Custom Image

This repository contains the customised settings of the federated identity server Keycloak. This repository contains the definition of the theme used for Keycloack to align with the look and feel of the Bank Guarantee DLT Platform portals and other additional modules that have been implemented to facilitate the interaction with the server by the Bank Guarantees DLT Platform APIs (primarily user management).

The repository builds a KeyCloak imag that already embeds the custom theme. The build is controlled via `make` and the `Makefile  contains the following targets:

- `all`: invokes the `build` target that builds the KeyCloak image.
- `bundle/dlt.zip`: this target is used as a dependency by the `build` target and it is used to prepare the zip file that contains the custom theme for KeyCloak.
- `build`: builds the docker image of the customised KeyCloak server (based on 4.0.0.Final).
- `start`: starts an instance of the KeyCloak server for local testing (name: bg-keycloak).
- `stop`: stops and removes (if any) a running container of KeyCloak (name: bg-keycloak).
- `clean`: cleans all the build artifacts (zip file and docker image).
- `test`: run the container initialization script to verify that the initializaiton process works correctly. This generates a collection of files under `./test/` directory that can be inspected. 

**NOTE**: the Docker image created in this repository depends on `$(DOCKER_REGISTRY)/keycloack:4.0.0.Patched` which is the image `jboss/keycloak:4.0.0.Final` rebuilt to upgrade operating system packages and remove image vulnerabilities.

## Image Configuration

This image has been designd to work out of the box with TLS, and the capability of optionally enable TLS-MA. This means that the server expects at least a TLS certificate to initialise the SSL connection with the clients. If not provided the boot script is designed to automatically create a self-signed certificates with values that can either be specified as configuration parameters or left to their default values. In order to determine whether during container initialisation it is necessary to generate a TLS certificate for the server the script looks for the file: `/opt/jboss/keycloak/standalone/configuration/security/keycloak.jks`. If the file is present, the script assumes it contains the required TLS certificate, otherwise it proceeds to create a keystore with the required cryptographic content in it. A similar approach is used to setup the mutual authentication:

- the initialisation script first checks whether the environment variable `TLS_MA` is defined and set to `true`
- if the test is successful it looks for a truststore in the location `/opt/jboss/keycloak/standalone/configuration/security/keycloak.jks`
- if the truststore is found, then the script assumes that it contains the required CA for verifying the client certificates
- if the truststore is not found, the script generates a keystore to use as truststore and the required certificates (the CA used to verify the client certificates is automatically added to the keystore, while a sample client certificate to use is left in the same directory)..

The following environment variables are:

- `KEYSTORE_PASSWORD`: this is the value of the password used to protect the keystore containing the TLS server certificate. If not set, this environment variable is set to `k3y5t0r3`
- `CERTIFICATE_COUNTRY` : this is the value of the country field that is used to generate the certificate (both client and server and associated CAs). If not set, this environment variable is set to `AU`
- `CERTIFICATE_STATE` : this is the value of the state field that is used to generate the certificate (both client and server and associated CAs). If not set, this environment variable it set to `Victoria`
- `CERTIFICATE_LOCATION` : this is the value of the location field that is used to generate the certificate (both client and server and associated CAs). If not set, this environment variable is set to `Melbourne`
- `CERTIFICATE_ORGANIZATION` : this is the value of the organization field that is used to generate the certificate (both client and server and associated CAs). If not set, this environment variable it set to `IBM`
- `CERTIFICATE_ORGANIZATIONAL_UNIT` : this is the value of the organizational unit field that is used to generate the certificate (both client and server and associated CAs). If not set, this environment variable is set to `Blockchain`
- `CERTIFICATE_COMMON_NAME` : this is the value of the common name attribute that is used to generate the TLS certificate. This value is also used to generate CA for the client certificate and the sample client certificate (i.e. *common-name*.CLIENT.ca, and *common-name*.CLIENT). If not set, this environment variable it set to `services-core.dlt.res.ibm.com` 
- `TLS_MA`: this is a boolean value indicating whether the initialisation script should configure the keycloak container to use client certificates. The default value is `false`, if the setup of client certificates is used, set this variable to `true`
- `TRUSTSTORE_PASSWORD`: this is the value of the password used to protect the truststore containing the CA of the client certificate. If not set, this environment variable is set to `tru5t5t0r3`

If you have set up the keycloak container with TLS_MA you can test the configuraiton by issuing the following command:

```
openssl s_client -CAfile ${CERTIFICATE_COMMON_NAME}.ca.pem -cert ${CERTIFICATE_COMMON_NAME}.CLIENT.pem -key ${CERTIFICATE_COMMON_NAME}.CLIENT.key -connet https://${CERTIFICATE_COMMON_NAME}:8443 -msg
```

To obtain the `${CERTIFICATE_COMMON_NAME}.*` files simply run `make test` and this will generate the required files in the `./test/tmp` directory.
