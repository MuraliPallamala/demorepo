# Notes

This directory contains the file system portion that will be mounted as volumes for the NginX and Keycloak containers for local execution.

- The `nginx` folder contains the directories that are mounted by the NginX container (HTML root, and certificate folders).
- The `keycloak` folder contains the directories that are mounted by the Keycloak container (key and trust store folders).

Some of these  folders are dinamically populated by executing `make start`, while others are checked in the source control because they store static content.


