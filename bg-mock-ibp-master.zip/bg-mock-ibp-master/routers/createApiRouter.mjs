import KoaRouter from "koa-router"
import fs from "fs"
import { getCommonConfigPath, getOrgConfigPath } from "../util/configFinder"
import getIBPPayload from "../util/genIBPPayload"

export default apiParams => {
    const { substitutionMap } = apiParams
    const apiRouter = new KoaRouter()

    apiRouter
        .get("/network/status", async ctx => {
            if (apiParams.ready) {
                ctx.status = 200
                ctx.body = { status: "Network is ready" }
            } else {
                ctx.status = 503
                ctx.body = { status: "Network is still bootstrapping" }
            }
        })
        .get("/network/:org", async ctx => {
            const { org } = ctx.params

            const commonConfigPath = getCommonConfigPath()
            const orgConfigPath = getOrgConfigPath(org)
            if (!fs.existsSync(orgConfigPath)) {
                throw new Error(
                    `Error: Organisation "${
                        org
                    }" does not have a network config file`
                )
            }

            ctx.body = getIBPPayload(
                commonConfigPath,
                orgConfigPath,
                substitutionMap
            )
        })
        .get("/ready", async ctx => {
            ctx.status = 200
            ctx.body = { message: "Mock IBP started" }
        })

    return apiRouter
}
