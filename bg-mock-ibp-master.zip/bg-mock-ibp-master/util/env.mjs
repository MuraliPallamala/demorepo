import path from "path"
import { execSync } from "child_process"

export const NB_MODE = process.env.NB_MODE || "test"
// Loading the environment port with default fallbacks
export const PORT = process.env.PORT || 9000
export const BG_NETWORK_PATH = process.env.BG_NETWORK_PATH
    ? path.resolve(__dirname, "..", process.env.BG_NETWORK_PATH)
    : path.join(__dirname, "../../bg-network")

function getMinikubeIp() {
    if (NB_MODE !== "dev") {
        return "minikube-ip-not-specified"
    }

    return (
        process.env.MINIKUBE_IP ||
        execSync(
            "minikube ip 2> /dev/null || ifconfig | grep 'inet 9.' | tr -s ' ' | xargs | cut -d ' ' -f2"
        )
            .toString()
            .trim()
    )
}

export const MINIKUBE_IP = getMinikubeIp()
export const NEWCO_FABRIC_CA =
    process.env.NEWCO_FABRIC_CA || `${MINIKUBE_IP}:30104`
export const ANZ_FABRIC_CA = process.env.ANZ_FABRIC_CA || `${MINIKUBE_IP}:30204`
export const COMMBANK_FABRIC_CA =
    process.env.COMMBANK_FABRIC_CA || `${MINIKUBE_IP}:30304`
export const TESTISSUER_FABRIC_CA =
    process.env.TESTISSUER_FABRIC_CA || `${MINIKUBE_IP}:30404`
export const WESTPAC_FABRIC_CA =
    process.env.WESTPAC_FABRIC_CA || `${MINIKUBE_IP}:30504`
