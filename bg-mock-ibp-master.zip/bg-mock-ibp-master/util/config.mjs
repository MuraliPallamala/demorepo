/* eslint import/prefer-default-export:0 */
import {
    MINIKUBE_IP,
    NEWCO_FABRIC_CA,
    ANZ_FABRIC_CA,
    COMMBANK_FABRIC_CA,
    TESTISSUER_FABRIC_CA,
    WESTPAC_FABRIC_CA
} from "./env"

export const substitutionMap = {
    minikubeIp: MINIKUBE_IP,
    NEWCO_FABRIC_CA,
    ANZ_FABRIC_CA,
    COMMBANK_FABRIC_CA,
    TESTISSUER_FABRIC_CA,
    WESTPAC_FABRIC_CA
}
