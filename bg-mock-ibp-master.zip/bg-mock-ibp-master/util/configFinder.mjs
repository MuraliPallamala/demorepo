import path from "path"
import { NB_MODE, BG_NETWORK_PATH } from "./env"

export function getCommonConfigPath() {
    return path.resolve(
        BG_NETWORK_PATH,
        `./assets/local-fabric-conf/common-fabric-network-${NB_MODE}.json`
    )
}

export function getOrgConfigPath(org) {
    return path.resolve(
        BG_NETWORK_PATH,
        `./assets/local-fabric-conf/${org}-fabric-network-${NB_MODE}.json`
    )
}
