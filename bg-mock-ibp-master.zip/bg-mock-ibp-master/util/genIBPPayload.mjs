import _ from "lodash/fp"
import { loadNetworkConfig } from "../scripts/networkBootstrap"

const deleteNestedObjKey = key => obj => {
    Object.values(obj).forEach(value => {
        delete value[key]
    })
    return obj
}

function formatChannels(commonConfig, orgNetworkConfig) {
    return _.flow(
        _.cloneDeep,
        _.filter(channel =>
            channel.peers.some(peerId =>
                orgNetworkConfig.peers.includes(peerId)
            )
        ),
        _.map(_.omit(["tx"])),
        _.map(channel => {
            const peersObj = {}
            channel.peers.forEach(peerId => {
                if (orgNetworkConfig.peers.includes(peerId)) {
                    peersObj[peerId] = {
                        endorsingPeer: true,
                        chaincodeQuery: true,
                        ledgerQuery: true,
                        eventSource: true
                    }
                }
            })
            channel.peers = peersObj
            return channel
        }),
        _.map(channel => {
            channel.chaincodes = _.flow(_.keyBy("id"), _.mapValues("version"))(
                commonConfig.chaincodes
            )
            return channel
        }),
        _.keyBy("name"),
        deleteNestedObjKey("name")
    )(commonConfig.channels)
}

function formatOrganisations(commonConfig, orgNetworkConfig) {
    return _.flow(
        _.cloneDeep,
        _.filter(organization => organization.mspId === orgNetworkConfig.mspId),
        _.map(organization => {
            organization.peers = _.flow(_.map(peer => peer.url.split("//")[1]))(
                organization.peers
            )
            return organization
        }),
        _.map(organization => ({
            ...organization,
            mspid: organization.mspId,
            certificateAuthorities: orgNetworkConfig.extra.certificateAuthorities.map(
                ca => ca.id
            ),
            signedCert: null,
            "x-uploadedSignedCerts": []
        })),
        _.map(organization => {
            delete organization.mspId
            return organization
        }),
        _.keyBy("mspid")
    )(commonConfig.organizations)
}

function formatOrderers(commonConfig, orgNetworkConfig) {
    return _.flow(
        _.cloneDeep,
        _.map(organization => organization.orderers || []),
        _.flatten,
        _.map(orderer => ({
            ...orderer,
            id: orderer.url.split("//")[1],
            grpcOptions: {},
            tlsCACerts: null
        })),
        _.keyBy("id"),
        deleteNestedObjKey("id")
    )(commonConfig.organizations)
}

function formatPeers(commonConfig, orgNetworkConfig) {
    return _.flow(
        _.cloneDeep,
        _.map(organisation => ({
            ...organisation,
            peers: (organisation.peers || []).map(peer => ({
                ...peer,
                id: peer.url.split("//")[1],
                grpcOptions: {},
                tlsCACerts: null,
                "x-mspid": organisation.mspId,
                "x-ledgerDbType": "levelDB"
            }))
        })),
        _.map(organization => organization.peers || []),
        _.flatten,
        _.filter(peer => peer["x-mspid"] === orgNetworkConfig.mspId),
        _.map(peer => ({ ...peer })),
        _.keyBy("id"),
        deleteNestedObjKey("id")
    )(commonConfig.organizations)
}

function formatCertificateAuthorities(orgNetworkConfig) {
    return _.flow(
        _.cloneDeep,
        _.map(ca => ({
            ...ca,
            httpOptions: { verify: false },
            tlsCACerts: null,
            caName: `${orgNetworkConfig.mspId}CA`,
            "x-mspid": orgNetworkConfig.mspId
        })),
        _.keyBy("id"),
        deleteNestedObjKey("id")
    )(orgNetworkConfig.extra.certificateAuthorities)
}

export default function genIBPPayload(
    commonNetworkConfigPath,
    orgNetworkConfigPath,
    substitutionMap
) {
    const commonConfig = loadNetworkConfig(
        commonNetworkConfigPath,
        substitutionMap
    )
    const orgNetworkConfig = loadNetworkConfig(
        orgNetworkConfigPath,
        substitutionMap
    )
    return {
        name: "BG_Local_Network",
        "x-networkId": "N/A",
        "x-type": "hlfv1",
        description: "Connection Profile for an IBM Blockchain Network",
        version: "1.1.0",
        client: {
            organization: orgNetworkConfig.mspId
        },
        channels: formatChannels(commonConfig, orgNetworkConfig),
        organizations: formatOrganisations(commonConfig, orgNetworkConfig),
        orderers: formatOrderers(commonConfig, orgNetworkConfig),
        peers: formatPeers(commonConfig, orgNetworkConfig),
        certificateAuthorities: formatCertificateAuthorities(orgNetworkConfig)
    }
}
