# bg-mock-ibp
A mock IBP service for development and testing

## Running locally:

### Prerequisites
- Nodejs https://nodejs.org/en/download/
- All Prerequisites of https://github.ibm.com/bank-guarantees/bg-network
- All Prerequisites of https://github.ibm.com/bank-guarantees/bg-chaincode

### Setup

Setup chaincode for development, see https://github.ibm.com/bank-guarantees/bg-chaincode
Lauch dev mode of bg-network see https://github.ibm.com/bank-guarantees/bg-network

Install components

```
$ make install
```

### Deploy

Start bg-mock-ibp in development mode

```
$ BG_NETWORK_PATH=<YOUR_BG_NETWORK_PATH> npm run dev
```
