const _ = require("lodash/fp")
const lodashOO = require("lodash")

const fs = require("fs")
const path = require("path")
const FabricClient = require("fabric-client")
const User = require("fabric-client/lib/User")

const { mapValues } = lodashOO

Promise.almost = r => Promise.all(r.map(p => (p.catch ? p.catch(e => e) : p)))

function makeNetworkConfigRelativePathsAbsolute(config, refPath, key) {
    const makeAbsoluteFilePathKeys = [
        "genesisBlock",
        "tx",
        "tlsca",
        "keystore",
        "signcerts"
    ]
    if (makeAbsoluteFilePathKeys.includes(key)) {
        if (_.isArray(config)) {
            return config.map(string => path.resolve(refPath, string))
        }
        return path.resolve(refPath, config)
    }
    if (!_.isObject(config)) {
        return config
    }
    if (_.isArray(config)) {
        return config.map(elem =>
            makeNetworkConfigRelativePathsAbsolute(elem, refPath)
        )
    }
    return mapValues(config, (v, k) =>
        makeNetworkConfigRelativePathsAbsolute(v, refPath, k)
    )
}

function substituteVariables(configString, substitutionMap) {
    let result = configString
    Object.entries(substitutionMap).forEach(([key, value]) => {
        result = result.replace(new RegExp(`\\\${${key}}`, "g"), value)
    })
    return result
}

function loadNetworkConfig(filepath, substitutionMap) {
    const dirpath = filepath.substring(
        0,
        Math.max(filepath.lastIndexOf("/"), filepath.lastIndexOf("\\"))
    )
    const config = JSON.parse(
        substituteVariables(
            fs.readFileSync(filepath).toString(),
            substitutionMap
        )
    )
    return makeNetworkConfigRelativePathsAbsolute(config, dirpath)
}

function parseOrganizationsJSONForOrderer(
    organizationsJSON,
    ordererId,
    client
) {
    const ordererFilterLambda = ordererJSON =>
        ordererJSON.url.includes(ordererId)
    const ordererOrganizationJSON = organizationsJSON.find(
        organizationJSON =>
            organizationJSON.orderers &&
            organizationJSON.orderers.find(ordererFilterLambda)
    )
    const ordererPeerJSON = ordererOrganizationJSON.orderers.find(
        ordererFilterLambda
    )

    return client.newOrderer(ordererPeerJSON.url)
}

async function clientSetup(
    commonNetworkConfigPath,
    organizationsJSON,
    orgNetworkConfigJSON,
    channelsJSON
) {
    const own = {
        admins: [],
        members: [],
        peers: []
    }

    const organizations = []
    const channels = []

    const { mspId, users } = orgNetworkConfigJSON

    const keystoreFileName = fs.readdirSync(users[0].keystore)[0]
    const signCertFileName = fs.readdirSync(users[0].signcerts)[0]

    const privateKeyPEM = fs
        .readFileSync(path.join(users[0].keystore, keystoreFileName))
        .toString()
    const signedCertPEM = fs
        .readFileSync(path.join(users[0].signcerts, signCertFileName))
        .toString()

    own.config = {
        cryptoSuite: FabricClient.newCryptoSuite(),
        mspId
    }

    const { cryptoSuite } = own.config

    const client = FabricClient.loadFromConfig(commonNetworkConfigPath)
    client.loadFromConfig(orgNetworkConfigJSON)

    client.setCryptoSuite(cryptoSuite)

    try {
        // eslint-disable-next-line consistent-return
        const userArray = orgNetworkConfigJSON.users.map(async userJSON => {
            const key = await cryptoSuite.importKey(privateKeyPEM, {
                ephemeral: !cryptoSuite._cryptoKeyStore
            })

            const user = new User({
                name: userJSON.username,
                roles: [userJSON.role]
            })
            user.setCryptoSuite(client.getCryptoSuite())
            await user.setEnrollment(key, signedCertPEM, mspId)
            client.setUserContext(user, true)

            if (userJSON.role === "admin") {
                return user
            }
        })

        own.admins = await Promise.all(userArray)

        organizationsJSON.forEach(async organizationJSON => {
            const { tlsca: tlscaPath } = organizationJSON
            const peersJSON = organizationJSON.peers || []
            const organization = {
                peers: []
            }

            let tlscaPem
            if (tlscaPath) {
                tlscaPem = Buffer.from(fs.readFileSync(tlscaPath)).toString()
            }
            peersJSON.forEach(async peerJSON => {
                const connectionOpts = tlscaPem
                    ? {
                          pem: tlscaPem,
                          "ssl-target-name-override":
                              peerJSON["server-hostname"]
                      }
                    : {}

                const peerId = peerJSON.url.split("//")[1]

                const peer = client.newPeer(peerJSON.url, connectionOpts)

                if (orgNetworkConfigJSON.peers.includes(peerId)) {
                    own.peers.push(peer)
                }
                organization.peers.push(peer)
            })
            organizations.push(organization)
        })
    } catch (error) {
        console.error(error)
    }

    return { own, channels, organizations, client }
}

async function installChaincode(
    organizations,
    client,
    channelsJSON,
    chaincodesJSON,
    endorsementPolicyJSON,
    organizationsJSON,
    orgNetworkConfigJSON
) {
    const allPeers = _.flatten(
        organizations.map(organization => organization.peers)
    )
    const installPromises = []

    chaincodesJSON.forEach(async chaincodeJSON => {
        const requestInstall = new Promise((resolve, reject) => {
            const chaincodeInstallRequest = {
                targets: allPeers,
                chaincodePath: chaincodeJSON.path,
                chaincodeId: chaincodeJSON.id,
                chaincodeVersion: chaincodeJSON.version
            }
            client
                .installChaincode(chaincodeInstallRequest)
                .then(res => {
                    resolve(res)
                })
                .catch(err => reject(err))
        })
        installPromises.push(requestInstall)
    })
    await Promise.almost(installPromises)

    const orderers = {}
    await Promise.all(
        channelsJSON.map(async channelJSON => {
            const channel = client.newChannel(channelJSON.name)
            const { orderers: ordererIds } = channelJSON
            const ordererId = ordererIds[0]
            let orderer

            if (orderers[ordererId]) {
                orderer = orderers[ordererId]
            } else {
                orderer = parseOrganizationsJSONForOrderer(
                    organizationsJSON,
                    ordererId,
                    client
                )
            }

            const channelConfigEnvelope = fs.readFileSync(channelJSON.tx)
            const channelConfig = client.extractChannelConfig(
                channelConfigEnvelope
            )
            const signature = client.signChannelConfig(channelConfig)

            const channelRequest = {
                config: channelConfig,
                signatures: [signature],
                name: channelJSON.name,
                orderer,
                txId: client.newTransactionID()
            }

            let connected = false
            const maxOrdererRetryTimes = 30

            for (let i = 0; i < maxOrdererRetryTimes; i++) {
                try {
                    // eslint-disable-next-line no-await-in-loop
                    await client
                        .createChannel(channelRequest)
                        .then((connected = true))
                        .catch(e => e)
                } catch (error) {
                    console.error(error)
                    if (error.message.includes("BAD_REQUEST")) {
                        connected = true
                        break
                    }
                    const ordererRetryWait = 1000 * (i + 1)
                    // eslint-disable-next-line no-await-in-loop
                    await new Promise(resolve =>
                        setTimeout(resolve, ordererRetryWait)
                    )
                }
            }
            if (!connected) {
                console.error(`Could not connect to Orderer ${ordererId}`)
            }

            channel.initialize({ discover: true }).catch(err => {
                if (
                    !(
                        err.message.includes("access denied") ||
                        err.message.includes("no peers")
                    )
                ) {
                    console.error(err)
                }
            })

            const channelPeers = []
            allPeers.forEach(peer => {
                const peerId = peer.getUrl().split("//")[1]
                if (
                    orgNetworkConfigJSON.peers.includes(peerId) &&
                    channelJSON.peers.includes(peerId)
                ) {
                    channelPeers.push(peer)
                    channel.addPeer(peer)
                }
            })

            const txId = client.newTransactionID()

            const request = {
                txId,
                orderer
            }

            const genesisBlock = await channel
                .getGenesisBlock(request)
                .catch(e => e)

            const promises = []
            promises.push(new Promise(resolve => setTimeout(resolve, 10000)))

            if (channelPeers.length >= 1 && genesisBlock) {
                try {
                    const joinRequest = {
                        targets: channelPeers,
                        txId: client.newTransactionID(),
                        block: genesisBlock
                    }

                    const joinPromise = await channel.joinChannel(joinRequest)
                    promises.push(joinPromise)
                } catch (err) {
                    if (!err.message.includes("FORBIDDEN")) {
                        console.error()
                    }
                }
            }

            await Promise.all(promises)

            const joinedChannelPeers = await channel.getPeers()
            const joinedPeers = await Promise.all(
                joinedChannelPeers.map(channelPeer => channelPeer.getPeer())
            )
            const peerToRemove = joinedPeers.find(peer =>
                peer.getName().includes("newco-peer")
            )

            if (peerToRemove) {
                channel.removePeer(peerToRemove)
            }

            return channel
        })
    )

    channelsJSON.forEach(channelJSON => {
        const channelChaincodesJSON = channelJSON.chaincodes
        channelChaincodesJSON.forEach(async channelChaincodeJSON => {
            const chaincodeJSON = chaincodesJSON.find(
                ({ id }) => id === channelChaincodeJSON.id
            )

            const channel = client.getChannel(channelJSON.name)
            const transactionId = client.newTransactionID(true)
            const deployId = transactionId.getTransactionID()

            const channelPeers = await channel.getPeers()
            const targets = await Promise.all(
                channelPeers.map(channelPeer => channelPeer.getPeer())
            )

            const chaincodeInstantiateRequest = {
                chaincodeId: channelChaincodeJSON.id,
                chaincodeVersion: chaincodeJSON.version,
                targets,
                fcn: channelChaincodeJSON.instantiate.fcn,
                args: channelChaincodeJSON.instantiate.args,
                txId: transactionId,
                "endorsement-policy":
                    endorsementPolicyJSON[
                        channelChaincodeJSON.endorsementPolicy
                    ]
            }

            const result = await channel
                .sendInstantiateProposal(chaincodeInstantiateRequest, 60000)
                .catch(e => e)
            const proposalResponses = result[0]
            const proposal = result[1]
            let allGood = true
            // eslint-disable-next-line no-restricted-syntax, guard-for-in
            for (const i in proposalResponses) {
                let oneGood = false
                if (
                    proposalResponses &&
                    proposalResponses[i].response &&
                    proposalResponses[i].response.status === 200
                ) {
                    oneGood = true
                }
                allGood += oneGood
            }

            if (proposalResponses && allGood) {
                const { mspId } = orgNetworkConfigJSON
                const promises = []
                const eventHubs = channel.getChannelEventHubsForOrg(mspId)
                if (eventHubs.length >= 1) {
                    console.debug(
                        `ChannelEventHub ${eventHubs[0].getPeerAddr()} for channel ${
                            channelJSON.name
                        }`
                    )
                }
                eventHubs.forEach(eventHub => {
                    const instantiateEventPromise = new Promise(
                        (resolve, reject) => {
                            const eventTimeout = setTimeout(() => {
                                eventHub.disconnect()
                            }, 3 * 60000)
                            eventHub.registerTxEvent(
                                deployId,
                                (tx, code, blockNum) => {
                                    console.info(
                                        "The chaincode instantiate transaction has been committed on peer %s",
                                        eventHub.getPeerAddr()
                                    )
                                    clearTimeout(eventTimeout)

                                    if (code !== "VALID") {
                                        const message = `The chaincode instantiate transaction was invalid, code: ${
                                            code
                                        }`
                                        reject(new Error(message))
                                    } else {
                                        const message =
                                            "The chaincode instantiate transaction was valid."
                                        resolve(message)
                                    }
                                },
                                err => {
                                    clearTimeout(eventTimeout)
                                    reject(err)
                                },
                                { unregister: true, disconnect: true }
                            )

                            eventHub.connect()
                        }
                    )
                    promises.push(instantiateEventPromise)
                })

                const { orderers: ordererIds } = channelJSON
                const ordererId = ordererIds[0]
                let orderer

                if (orderers[ordererId]) {
                    orderer = orderers[ordererId]
                } else {
                    orderer = parseOrganizationsJSONForOrderer(
                        organizationsJSON,
                        ordererId,
                        client
                    )
                }
                const ordererRequest = {
                    orderer,
                    txId: transactionId,
                    proposalResponses,
                    proposal
                }
                const sendPromise = channel
                    .sendTransaction(ordererRequest)
                    .catch(e => console.error(e))
                promises.push(sendPromise)

                const results = await Promise.all(promises).catch(e => e)
            }
        })
    })

    const endorsementPolicies = {}

    channelsJSON.forEach(channelJSON => {
        const channelChaincodesJSON = channelJSON.chaincodes
        const channelEndorsementPolicies = {}
        channelChaincodesJSON.forEach(chaincodeJSON => {
            channelEndorsementPolicies[chaincodeJSON.id] =
                endorsementPolicyJSON[chaincodeJSON.endorsementPolicy]
        })
        endorsementPolicies[channelJSON.name] = channelEndorsementPolicies
    })

    return {
        endorsementPolicies,
        chaincodes: _.keyBy(o => o.id)(chaincodesJSON)
    }
}

async function networkBootstrap(
    commonNetworkConfigPath,
    orgNetworkConfigPath,
    substitutionMap
) {
    const {
        channels: channelsJSON,
        chaincodes: chaincodesJSON,
        endorsementPolicy: endorsementPolicyJSON,
        organizations: organizationsJSON
    } = loadNetworkConfig(commonNetworkConfigPath, substitutionMap)
    const orgNetworkConfigJSON = loadNetworkConfig(
        orgNetworkConfigPath,
        substitutionMap
    )
    const {
        own: { admins, config },
        channels,
        organizations,
        client
    } = await clientSetup(
        commonNetworkConfigPath,
        organizationsJSON,
        orgNetworkConfigJSON,
        channelsJSON
    )
    const { endorsementPolicies, chaincodes } = installChaincode(
        organizations,
        client,
        channelsJSON,
        chaincodesJSON,
        endorsementPolicyJSON || {},
        organizationsJSON,
        orgNetworkConfigJSON
    )

    return {
        admins,
        config,
        channels,
        endorsementPolicies,
        chaincodes
    }
}

networkBootstrap.loadNetworkConfig = loadNetworkConfig

module.exports = { loadNetworkConfig, networkBootstrap }
