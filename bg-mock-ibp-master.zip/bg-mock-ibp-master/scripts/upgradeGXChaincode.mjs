/* eslint no-await-in-loop:0 */
import _ from "lodash/fp"
import { networkBootstrap } from "../scripts/networkBootstrap"
import { getCommonConfigPath, getOrgConfigPath } from "../util/configFinder"
import { substitutionMap } from "../util/config"

function getNetworks() {
    const commonConfigPath = getCommonConfigPath()
    const orgConfigPaths = [
        getOrgConfigPath("newco"),
        getOrgConfigPath("testissuer"),
        getOrgConfigPath("anz"),
        getOrgConfigPath("commbank"),
        getOrgConfigPath("westpac")
    ]

    return Promise.all(
        orgConfigPaths.map(orgConfigPath =>
            networkBootstrap(commonConfigPath, orgConfigPath, substitutionMap)
        )
    )
}

async function installChaincode(peers, chaincodesConfig, admin) {
    return Promise.all(
        chaincodesConfig.map(chaincodeConfig =>
            admin
                .installChaincode({
                    targets: peers,
                    chaincodeId: chaincodeConfig.id,
                    chaincodeVersion: chaincodeConfig.version,
                    chaincodePath: chaincodeConfig.path,
                    chaincodeType: chaincodeConfig.chaincodeType
                })
                .catch(error => {
                    // ignore already installed error
                    if (!error.message.match(/\(chaincode [^\b]+ exists\)/)) {
                        throw error
                    }
                })
        )
    )
}

async function installChaincodeOntoNetworks(networks) {
    // Install Chaincode
    await Promise.all(
        networks.map(network => {
            const { admin } = network.admins

            const gxChannels = Object.values(network.channels)
            const peers = _.flow(_.flatten, _.uniqBy(peer => peer.getUrl()))(
                gxChannels.map(channel =>
                    channel.getPeers().filter(peer => peer.getEventHubManager)
                )
            )

            return installChaincode(
                peers,
                Object.values(network.chaincodes),
                admin
            )
        })
    )
}

const prefixMapping = {
    "testissuer-channel": "000000",
    "anz-channel": "000001",
    "commbank-channel": "000002",
    "westpac-channel": "000003"
}

async function upgradeGuaranteeChaincode(bankNetworks) {
    for (let i = 0; i < bankNetworks.length; i++) {
        const network = bankNetworks[i]
        const gxChaincode = network.chaincodes.guarantee
        // each bank only has a single channel for itself
        const bankChannel = Object.values(network.channels).find(
            channel => channel.getName() !== "platform-channel"
        )
        const { admin } = network.admins
        console.log(
            "Migrating",
            bankChannel.getName(),
            "with prefix",
            prefixMapping[bankChannel.getName()]
        )

        await admin.upgradeChaincode(bankChannel, {
            chaincodeId: gxChaincode.id,
            chaincodeVersion: gxChaincode.version,
            fcn: "init",
            args: [
                `{"prefix":"${
                    prefixMapping[bankChannel.getName()]
                }", "platformChannelId":"platform-channel", "profileCc":"profile", "newcoMspId":"newco", "migrate": true}`
            ]
        })
    }
}
async function upgradeProfileChaincode(newcoNetwork) {
    const profileChaincode = newcoNetwork.chaincodes.profile
    // each bank only has a single channel for itself
    const platformChannel = Object.values(newcoNetwork.channels).find(
        channel => channel.getName() === "platform-channel"
    )
    const { admin } = newcoNetwork.admins

    //

    await admin.upgradeChaincode(platformChannel, {
        chaincodeId: profileChaincode.id,
        chaincodeVersion: profileChaincode.version,
        fcn: "init",
        args: ['{"newcoMspId":"newco"}']
    })
}

console.log("Getting networks")
getNetworks()
    .then(async networks => {
        const [newcoNetwork, ...bankNetworks] = networks
        if (process.env.DONT_INSTALL !== "true") {
            await installChaincodeOntoNetworks(networks)
            console.log("Installed Profile+Guarantee Chaincodes")
        }
        await upgradeGuaranteeChaincode(bankNetworks)
        console.log("Upgraded Guarantee Chaincodes")
        await upgradeProfileChaincode(newcoNetwork)
        console.log("Upgraded Profile Chaincodes")

        // Should ideally exit by itself, bug with networkBootstrap
        process.exit(0)
    })
    .catch(error => {
        console.error("Upgrade Error:", error)
        // Bootstrapping failed, force exit
        process.exit(1)
    })
