import Koa from "koa"
import cors from "@koa/cors"
import http from "http"
import koaBodyParser from "koa-bodyparser"
import * as fs from "fs"
import { networkBootstrap } from "./scripts/networkBootstrap"
import createApiRouter from "./routers/createApiRouter"
import { getCommonConfigPath, getOrgConfigPath } from "./util/configFinder"
import { PORT } from "./util/env"
import { substitutionMap } from "./util/config"

const app = new Koa()
const server = http.createServer(app.callback())

// cross origin resource sharing
app.use(
    cors({
        origin: "*"
    })
)
// mount parser for applicaton/json content
app.use(koaBodyParser())

app.use(async (ctx, next) => {
    try {
        await next()
    } catch (err) {
        ctx.status = err.status || 500
        ctx.body = err.message
        ctx.app.emit("error", err, ctx)
    }
})

function networkBootstrapAll() {
    const commonConfigPath = getCommonConfigPath()
    const orgConfigPaths = [
        getOrgConfigPath("newco"),
        getOrgConfigPath("anz"),
        getOrgConfigPath("commbank"),
        getOrgConfigPath("testissuer"),
        getOrgConfigPath("westpac")
    ]

    return Promise.all(
        orgConfigPaths.map(orgConfigPath =>
            networkBootstrap(commonConfigPath, orgConfigPath, substitutionMap)
        )
    )
}

const apiParams = { ready: false, substitutionMap }

if (process.env.SKIP_NETWORK_BOOTSTRAP !== "true") {
    console.log("Starting network bootstrap...")
    networkBootstrapAll()
        .then(() => {
            apiParams.ready = true
            fs.closeSync(fs.openSync(".mock_ibp_up", "w"))
        })
        .catch(error => {
            console.error("Bootstrapping Error:", error)
            // Bootstrapping failed, force exit
            process.exit(1)
        })
} else {
    console.log("---NetworkBootstrap Skipped---")
}

/*
 * API endpoints
 */
const apiRouter = createApiRouter(apiParams)

app.use(apiRouter.routes())

// Start the app
server.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`)
})
