# Issuing a Bank Guarantee

The process of issuing a bank guarantee within the Platform can be initiated through a variety of methods as detailed below:

- Applicant initiated issue request
- Beneficiary initiated issue request
- Issuer initiated issue request

<br/>

## Applicant Initiated Issue Request
An Applicant initiated issue request requires the Applicant’s organisation, as well as the Beneficiary and Issuer to come to consensus regarding the variable terms of the bank guarantee.  

### Applicant Initiated Issue Request (Sole-Approval Model)

A user within the sole approver model is able to initiate a request by clicking the ‘+’ icon on the top righthand corner of their dashboard as seen in Figure 141.

<p style="text-align: center;"><sup>Figure 141. Entering the new request screen</sup></p>

To initiate an issuance request, click ‘Start a Bank Guarantee Request’ within the New Request menu (Figure 142). 

<p style="text-align: center;"><sup>Figure 142. Starting a new bank guarantee request</sup></p>

To complete the request form, enter details of Parties Involved and Guarantee Details. The Guarantee Details will depend on the Purpose Type that is selected. The Platform may hold multiple purpose types depending on the variety of guarantees that are being used for the Platform. In Figure 143, we see a blank Guarantee Form. 

<p style="text-align: center;"><sup>Figure 143. Initiating a bank guarantee request</sup></p>

Figure 144 below is an example of a completed Bank Guarantee request form. The Applicant, in this case ‘Test Organisation’ can visualise the request with the status ‘Pending’ as the request has been sent to the Beneficiary to approve or reject.

<p style="text-align: center;"><sup>Figure 144. Successfully initiated bank guarantee request</sup></p>

We will now switch to *Some Company* who is the Beneficiary in this example. *Some Company* will be able to visualise the request within their ‘Needs Action’ tab as seen in Figure 145.

<p style="text-align: center;"><sup>Figure 145. Receiving a Bank Guarantee request</sup></p>

Upon entering the request, a user of the Beneficiary’s organisation is required to review the request and decide whether they will REJECT or APPROVE (Figure 146). 

<p style="text-align: center;"><sup>Figure 146. Reviewing a bank guarantee request</sup></p>

Should the Beneficiary reject the bank guarantee request, they will be prompted to enter optional reasoning for rejection as per Figure 147 to complete the rejection. 

<p style="text-align: center;"><sup>Figure 147. Entering an optional rejection reason and confirming your rejection</sup></p>

Should the Beneficiary approve the bank guarantee request, they will receive visual confirmation of their action via the bank guarantee stepper as seen in Figure 148.

<p style="text-align: center;"><sup>Figure 148. Beneficiary approval of a bank guarantee request</sup></p>

Upon approval by the Beneficiary, the request is passed to the Issuer. The Issuer will either APPROVE or REJECT the request.  

<br/>

### Applicant Initiated Issue Request (4-Eye Model)

![Figure 153](Figure153.png) 
<p style="text-align: center;"><sup>Figure 153. Example of a 4-eye approval model in an issuance process</sup></p>

Upon approval by the Beneficiary, the request is passed to the Issuer. The Issuer will receive a ‘Needs Action’ notification to the request (Figure 169).

![Figure 169](Figure169.png) 
<p style="text-align: center;"><sup>Figure 169. Guarantee issuance needs action</sup></p>

Entering the request will require the Issuers Proposer to review the request with option to add an Issuer Reference number and decide whether they will REJECT or APPROVE (Figure 170).

![Figure 170](Figure170.png) 
<p style="text-align: center;"><sup>Figure 170. Actioning the pending request</sup></p>

Rejecting the request will optionally require the Proposer to select a reason for rejection (Figure 171) to be sent to the Applicant.

![Figure 171](Figure171.png) 
<p style="text-align: center;"><sup>Figure 171. Optional rejection reason dialog</sup></p>

Should the Proposer approve the bank guarantee request, they will receive visual confirmation of their action via the bank guarantee stepper as seen in (Figure 172).

![Figure 172](Figure172.png) 
<p style="text-align: center;"><sup>Figure 172. Approving the request</sup></p>

The request will then be required to be reviewed by an Approver within the Issuer’s organisation. The Issuer will receive a ‘Needs Action’ notification regarding the pending request as shown in (Figure 173). 

![Figure 173](Figure173.png) 
<p style="text-align: center;"><sup>Figure 173. Guarantee issuance needs action</sup></p>

The Approver can REJECT or APPROVE the pending the request as seen in (Figure 174).

![Figure 174](Figure174.png) 
<p style="text-align: center;"><sup>Figure 174. Actioning the pending request</sup></p>

Rejecting the request will optionally require the Approver to select a reason for rejection (Figure 175) to be sent to the Applicant.

![Figure 175](Figure175.png) 
<p style="text-align: center;"><sup>Figure 175. Optional rejection reason dialog</sup></p>

Should the Issuer’s Approver approve the request, they will receive visual confirmation of their action via confirmation of the bank guarantee status now reading ‘Approved’ as seen in (Figure 176).

![Figure 176](Figure176.png) 
<p style="text-align: center;"><sup>Figure 176. Confirmation of approved bank guarantee</sup></p>

<br/>

## Beneficiary Initiated Issue Request 

### Beneficiary Initiated Issue Request (Sole-Approval Model)
### Beneficiary Initiated Issue Request (4-Eye Model)

## Issuer Initiated Issue Request
### Issuer Initiated Issue Request (Sole-Approval Model)
### Issuer Initiated Issue Request (4-Eye Model)


<video width="320" height="240" controls>
<source src="movie.mp4" type="video/mp4">
<source src="movie.ogg" type="video/ogg">
Your browser does not support the video tag.
</video>
