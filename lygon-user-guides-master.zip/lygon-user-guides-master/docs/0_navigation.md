# Navigation
## An Introduction to Bank Guarantees

Portal navigation is achieved consistently across all the portals by the use of two key design elements: a *side panel* on the left of the screen, an *action bar* placed in the header of the portal on the right side, and a *drop-down menu* positioned as the rightmost element in the action bar.

The example below provides a view of these navigation elements in the Lygon User portal.

<p style="text-align: center;"><img src="/1.0.png" style="text-align: center" alt="Figure 0"/></p>
<p style="text-align: center;"><sup>Figure 0. Navigating with the Lygon User Portal</sup></p>

<p style="text-align: center;"><sup>Table 1. Lygon User portal functionality</sup></p>

column 1 | column 2
- | -
1. Title bar. The title bar functions as a quick view for the user to visualise the organisation in which they are operating within. | 2. The notification section is positioned in all portals as the first element in the side panel. This implicitly conveys its importance in the categorisation of the items without disrupting user operations
3. Notifications which require action are flagged in the side panel under the “Needs Action” item. When there is a notification that needs action, the aggregated number of these notifications will appear to capture the attention of the user that can easily detect the change. | 4. Provides a view of all pending requests that require an action from the organisation.
5. All guarantees that have completed their final approval process  | 6. A quick access view of all currently active organisations within the Platform
7. Views of all currently expiring bank guarantees across the 1, 2 and 3 month cycle | 8. A quick view of all Expired bank guarantee requests
9. A quick access view of all bank guarantees which have been cancelled and are now no longer valid | 10. A quick access view of all bank guarantees that have been transferred to another beneficiary
Content | 
  | Content
