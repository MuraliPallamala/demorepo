# USER MANAGEMENT AND ACCOUNT MAINTENANCE 
INVITING A USER TO YOUR ORGANISATION
Administrator’s within the Platform can onboard additional users to their organisation. This function is accessed within User Management, located within Settings as shown in Figure 15. 

<p style="text-align: center;"><img src="/2.15.png" style="text-align: center" alt="Figure 2.15"/></p>
<p style="text-align: center;"> <sup>Figure 15. Entering User Management</sup> </p>

Upon entering ‘User Management’, an Administrator will be able to initiate the onboarding of additional users by clicking ‘ADD USER’ (Figure 16) within the ‘MANAGE ACTIVE USERS’ heading.

 
<p style="text-align: center;"><img src="/2.16.png" style="text-align: center" alt="Figure 2.16"/></p>
<p style="text-align: center;"> <sup>Figure 16. Organisation specific platform URL and unique code identifier</sup> </p>

A pop-up dialog will appear to the screen which the Administrator will be required to enter the basic information of the new user. Clicking submit will send an email notification to the user which requires the PIN (Figure 17) to also be shared to them via an alternative method. 


<p style="text-align: center;"><img src="/2.17.png" style="text-align: center" alt="Figure 2.17"/></p>
<p style="text-align: center;"> <sup>Figure 17. Onboarding PIN for the additional user</sup> </p>

The additional user will receive an email invitation to the Platform with a link to follow and will be required to enter the PIN which was provided to them by the Administrator. 

# DELETING A USER FROM YOUR ORGANISATION
An Administrator can delete users from their organisation. This process is conducted via User Management, accessed via Settings (Figure 18). 

<p style="text-align: center;"><img src="/2.18.png" style="text-align: center" alt="Figure 2.18"/></p>
<p style="text-align: center;"> <sup>Figure 18. Accessing User Management</sup> </p>

The User Management page allows for a full view of all users within an organisation. Should the Administrator wish to unblock a user, click the   icon shown in Figure 19. 

<p style="text-align: center;"><img src="/2.19.png" style="text-align: center" alt="Figure 2.19"/></p>
<p style="text-align: center;"> <sup>Figure 19. Deleting a user</sup> </p>

The Administrator will be prompted to click ‘SUBMIT’ on the dialog box.

The removed user will no longer appear in the ‘Manage Active Users’ list. Instead, the user will be displayed in the “Removed Users” tab. The removed user will receive an email stating that they have been deleted from the Platform.


# PASSWORD MAINTENANCE 

The Platform requires a minimum length of 8 characters for a password, which must include a variety of character values. These include the presence of at least one:

•	One upper case letter
•	One lower case letter
•	One numerical digit
•	One special character

# CHANGING YOUR PASSWORD 
To initiate a password change, a user within the Platform can initiate the update via ‘My Username and Password’ within their ‘My Profile’, then clicking ‘EDIT’ to update their password.
 
# RESET YOUR PASSWORD
Password reset functionality is also available within the Platform in the Log In screen. To initiate a password reset, select ‘Forgot Password?’ and enter the registered email address.

The Platform will automatically send the user a password reset email to the registered email that is active in that organization portal. This email will contain a password reset link. Clicking the link will redirect the user to update their password within the Platform.

The Platform does not allow recent passwords (to a requirement of the previous three that have been registered) to be used again. Once you have entered your new password, click ‘SUBMIT’.


2 FACTOR AUTHENTICATION (2FA)
2 Factor Authentication is an extra layer of security that is known as "multi factor authentication".  
The Platform currently supports 2 Factor Authentication via Google Authenticator and FreeOTP. 

SETTING UP 2 FACTOR AUTHENTICATION
To set up 2 Factor Authentication, enter your settings and click ‘Configure 2 Factor Authentication’ and toggle the slider to ‘On’.

Turning two factor authentication on will randomly generate a unique QR code for your user profile. Using FreeOTP or Google Authenticator, scan the QR code as shown in Figure 20.

<p style="text-align: center;"><img src="/2.20.png" style="text-align: center" alt="Figure 2.20"/></p>
<p style="text-align: center;"> <sup>Figure 20. Scanning your QR Code</sup> </p>

Upon scanning and adding the QR code to your authentication service, please enter the generated code to complete the 2 Factor Authentication process and click VERIFY as shown in Figure 21. 

<p style="text-align: center;"><img src="/2.21.png" style="text-align: center" alt="Figure 2.21"/></p>
<p style="text-align: center;"> <sup>Figure 21. Verifying your generated QR Code</sup> </p>


## UPDATING YOUR ORGANISATION DETAILS

## INITIATING A REQUEST TO CHANGE ORGANISATION DETAILS
The Administrator of an organisation can make updates to their company details to ensure their public records match that within in the system. To update company details, the Administrator will select ‘Organisation Details & Primary User’ in the Settings.

<p style="text-align: center;"><img src="/2.22.png" style="text-align: center" alt="Figure 2.22"/></p>
<p style="text-align: center;"> <sup>Figure 22. Entering your Organisation Settings</sup> </p>

Clicking ‘EDIT’ will allow changes to be made to the organisation profile as shown in Figure 23.

<p style="text-align: center;"><img src="/2.23.png" style="text-align: center" alt="Figure 2.23"/></p>
<p style="text-align: center;"> <sup>Figure 23. Organisation Details</sup> </p>

The Administrator will only be able to adjust the Legal Entity Name and Registered Address of the organisation, as shown in Figure 24. The ABN/ACN number is not editable as the Platform ensures that the ABN/ACN’s of organisations remain static within the Platform.

<p style="text-align: center;"><img src="/2.24.png" style="text-align: center" alt="Figure 2.24"/></p>
<p style="text-align: center;"> <sup>Figure 24. Changing your organisation details</sup> </p>

Clicking ‘SAVE’ will allow changes to be recorded for review by Lygon Administrator, the inflight request can be edited or cancelled at any time before Lygon Admin approval.

## PARENT/ SUBSIDIARY RELATIONSHIPS WITHIN THE PLATFORM

The Platform allows for large organisations to have greater visibility and/or control over the bank guarantees of their subsidiary organisations. The pilot solution caters for relationship structures of a single level of depth, this means a structure can only allow for a single parent and potentially multiple subsidiaries. 

## INITIATING A PARENT/ SUBSIDIARY RELATIONSHIP
Any organisation can initiate a parent/ subsidiary relationship with another organisation through their Organisation Details & Primary User menu within their Settings. 

Once an Administrator is in this menu, they can begin the process by clicking ‘+ ADD RELATIONSHIP’ as shown in Figure 25.

<p style="text-align: center;"><img src="/2.25.png" style="text-align: center" alt="Figure 2.25"/></p>
<p style="text-align: center;"> <sup>Figure 25. Initiating a Parent/ Subsidiary Relationship Request</sup> </p>

Upon completion of the required information, click ‘Submit’ and the request will be saved and sent to the added organisation. 

The parent/subsidiary organisation’s Administrator, will receive the request within their Organisation Details & Primary User menu and can choose to ‘REJECT’ or ‘APPROVE’ the request. 

## REMOVING A PARENT/ SUBSIDIARY RELATIONSHIP
To initiate the removal of a parent/subsidiary relationship, the organisation’s Administrator will access the Organisation Details & Primary User under the SETTINGS menu, view the current relationship and click ‘REVOKE’ (Figure 26) and clicking Submit. 

<p style="text-align: center;"><img src="/2.26.png" style="text-align: center" alt="Figure 2.26"/></p>
<p style="text-align: center;"> <sup>Figure 26. Revoking a Parent/ Subsidiary Relationship</sup> </p>

Figure 27 shows that the requesting organisation’s current revoke request is ‘awaiting approval’ by the other organisation. 

<p style="text-align: center;"><img src="/2.27.png" style="text-align: center" alt="Figure 2.27"/></p>
<p style="text-align: center;"> <sup>Figure 27. Confirmation of request to revoke relationship</sup> </p>

The parent organisation will receive a needs action where the administrator will be required to either ‘REJECT’ or ‘APPROVE’ the revoke request. 

Upon approval, the organization Administrator receives visual confirmation with the previous relationship no longer being visible to either organisation.


