# Lygon Manual for Users

Welcome to the documentation for Lygon!

## Purpose
The purpose of this document is to provide guidance for the Lygon Platform Pilot in terms of operating within the Platform.

The Bank Guarantees project has the objective of developing a minimum viable product (MVP) for a solution that applies distributed ledger technologies to address challenges in the procurement and management of Bank Guarantees among Issuers, Beneficiaries and Applicants. The MVP will manage the recording, amendment and closing of Bank Guarantees with the banking industry. It does not itself form the financial instrument, but rather the management of the instrument during its life cycle.

The main objective towards this user manual is to provide clarity when operating within the MVP environment, and demonstrate the sequencing of actions to perform a business process. 

## Intended Audience
This document is primarily targeted towards the business stakeholders of the Lygon Platform (the ‘Platform’) and the users who will be operating within this environment. 

Reading this document will allow for users to operate their functions, regardless of their organisation or role within the Platform, by adhering to the sequencing steps outlined within.

For more information about Lygon, visit our homepage at [https://www.lygon.io](https://www.lygon.io)
