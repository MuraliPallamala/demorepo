# BANK GUARANTEES AND THE LYGON PLATFORM

A bank guarantee is an independent undertaking by a bank, on behalf of its customer, to pay a named beneficiary in the event the customer fails to fulfil their contractual obligations with that beneficiary. The obligation to pay is unconditional and can be made on presentation of a simple claim / demand by the beneficiary, without regard to the customer’s performance or non-performance of the underlying contract.
 
<p style="text-align: center;"><img src="/2.28.png" style="text-align: center" alt="Figure 28"/></p>
<p style="text-align: center;"> <sup>Figure 28. Simplified concept map of a bank guarantee issuance process</sup> </p>

The use of the Platform therefore can be broken into four categories.
1.	Issue – A binding agreement made between the Applicant, Issuer and Beneficiary to create the financial instrument.
2.	Amend – A change in the business relationship between the Applicant and Beneficiary that must be reflected within the instrument.
3.	Cancel – Abandoning the current instrument due to a change in the business relationship between the Applicant and Beneficiary
4.	Demand – A demand payment being made against an instrument due to an Applicant’s failure to meet their contractual obligations
The ability for users to create actions within these categories is dependent on the user’s role within the Platform, and the organisation in which requests have been initiated.  


## ISSUING A BANK GUARANTEE

The process of issuing a bank guarantee within the Platform can be initiated through a variety of methods as detailed below:
•	Applicant initiated issue request
•	Beneficiary initiated issue request
•	Issuer initiated issue request

<p style="text-align: center;"><img src="/2.29.png" style="text-align: center" alt="Figure 29"/></p>
<p style="text-align: center;"> <sup>Figure 29. Applicant initiated issue request</sup> </p>


<p style="text-align: center;"><img src="/2.30.png" style="text-align: center" alt="Figure 30"/></p>
<p style="text-align: center;"> <sup>Figure 30. Beneficiary initiated issue request</sup> </p>


<p style="text-align: center;"><img src="/2.31.png" style="text-align: center" alt="Figure 31"/></p>
<p style="text-align: center;"> <sup>Figure 31. Issuer initiated issue request</sup> </p>

## APPLICANT INITITATED ISSUE REQUEST
An Applicant initiated issue request requires the Applicant’s organisation, as well as the Beneficiary and Issuer to come to consensus regarding the variable terms of the bank guarantee.  






## APPLICANT INITIATED ISSUE REQUEST (SOLE APPROVER MODEL)
The example below will highlight a structure where ALL organisations adhere towards the SOLE APPROVER MODEL. It should be noted however that different organisations may adhere to different approval models. To cater for these different scenarios both approval models should be considered. 

<p style="text-align: center;"><img src="/2.32.png" style="text-align: center" alt="Figure 32"/></p>
<p style="text-align: center;"> <sup>Figure 32. Example of a sole approver model in an issuance process</sup> </p>


A user within the sole approver model can initiate a request by clicking the ‘+’ icon on the top righthand corner of their dashboard as seen in Figure 33.

 <p style="text-align: center;"><img src="/2.33.png" style="text-align: center" alt="Figure 33"/></p>
<p style="text-align: center;"> <sup>Figure 33. Entering the new request screen</sup> </p>

To initiate an issuance request, click ‘Start a Bank Guarantee Request’ within the New Request menu (Figure 34). 

 <p style="text-align: center;"><img src="/2.34.png" style="text-align: center" alt="Figure 34"/></p>
<p style="text-align: center;"> <sup>Figure 34. Starting a new bank guarantee request</sup> </p>

To complete the request form, the organisation will be required to enter details of Parties Involved and Guarantee Details. The Guarantee Details will depend on the Purpose Type that is selected. The Platform may hold multiple purpose types depending on the variety of guarantees that are being used for the Platform. 

Below is an example of a submitted bank guarantee form. The bank guarantee status is ‘Pending’ as the request has been sent to the Beneficiary to approve or reject.

  <p style="text-align: center;"><img src="/2.35.png" style="text-align: center" alt="Figure 35"/></p>
<p style="text-align: center;"> <sup>Figure 35. Successfully initiated bank guarantee request</sup> </p>

We will now switch to Some Company who is the Beneficiary in this example. Some Company can access the request from the ‘Needs Action’ tab in the portal. Upon entering the request, a user of the Beneficiary’s organisation is required to review the request and decide whether they will REJECT or APPROVE.

Should the Beneficiary approve the bank guarantee request, they will receive visual confirmation of their action via the bank guarantee stepper as seen in Figure 36.

<p style="text-align: center;"><img src="/2.36.png" style="text-align: center" alt="Figure 36"/></p>
<p style="text-align: center;"> <sup>Figure 36. Beneficiary approval of a bank guarantee request</sup> </p>

Upon approval by the Beneficiary, the request is passed to the Issuer. The Issuer will either APPROVE or REJECT the request, thereby finalising the issuance of the bank guarantee request. 


## APPLICANT INITIATED ISSUE REQUEST (4-EYE MODEL)

The example below will highlight a structure where ALL organisations adhere towards 4-EYE MODEL. It should be noted however that different organisations may adhere to different approval models. To cater for these different scenarios both approval models should be considered during the issuance lifecycle. 

 <p style="text-align: center;"><img src="/2.37.png" style="text-align: center" alt="Figure 37"/></p>
<p style="text-align: center;"> <sup>Figure 37. Example of a 4-eye approval model in an issuance process</sup> </p>

A user within the 4-eye approval model with proposer rights can initiate a request by clicking the ‘+’ icon on the top righthand corner of their dashboard as seen in Figure 38.

 <p style="text-align: center;"><img src="/2.38.png" style="text-align: center" alt="Figure 38"/></p>
<p style="text-align: center;"> <sup>Figure 38. Entering the new request screen</sup> </p>

To initiate an issuance request, click ‘Start a Bank Guarantee Request’ within the New Request menu (Figure 39). 

 <p style="text-align: center;"><img src="/2.39.png" style="text-align: center" alt="Figure 39"/></p>
<p style="text-align: center;"> <sup>Figure 39. Starting a new bank guarantee request</sup> </p>

To complete the request form, the organisation will be required to enter details of Parties Involved and Guarantee Details. The Guarantee Details will depend on the Purpose Type that is selected. The Platform may hold multiple purpose types depending on the variety of guarantees that are being used for the Platform. 

After filling out the bank guarantee request form, the request will be initiated and will require reviewal by an Approver within the Applicant’s organisation as seen in Figure 40. 

 <p style="text-align: center;"><img src="/2.40.png" style="text-align: center" alt="Figure 40"/></p>
<p style="text-align: center;"> <sup>Figure 40. Issue request initiated</sup> </p>

The Applicant’s Approver can access the pending request through the ‘Pending Requests Tab’ or via ‘All Guarantees’ tab in their portal. From here they can REJECT or APPROVE the pending the request as seen in Figure 41.

 <p style="text-align: center;"><img src="/2.41.png" style="text-align: center" alt="Figure 41"/></p>
<p style="text-align: center;"> <sup>Figure 41. Reviewing the initiated request internally</sup> </p>

Approving the request will complete the Applicant’s role within the Bank Guarantee request. The bank guarantee status is ‘Pending’ as the request has been sent to the Beneficiary to approve or reject (Figure 42).

 <p style="text-align: center;"><img src="/2.42.png" style="text-align: center" alt="Figure 42"/></p>
<p style="text-align: center;"> <sup>Figure 42. Successfully applicant approved bank guarantee initiation request </sup> </p>

The Proposer within the Beneficiary organisation, in this case Some Company, will then receive a ‘Needs Action’ notification to the request. Upon entering the request, the Beneficiary’s Proposer will be required to review the request and decide whether they will REJECT or APPROVE the request.

Should the Beneficiary’s Proposer approve the request, they will receive visual confirmation of their action via the bank guarantee stepper as seen in (Figure 43).

 <p style="text-align: center;"><img src="/2.43.png" style="text-align: center" alt="Figure 43"/></p>
<p style="text-align: center;"> <sup>Figure 43. Visual confirmation of Approval via the Proposer</sup> </p>

The request will then be required to be reviewed by an Approver within the Beneficiary’s organisation. The Beneficiary’s Approver can access the pending request through the ‘Needs Action’ tab in their portal. From here the Beneficiary’s approver can REJECT or APPROVE the request (Figure 44).

 <p style="text-align: center;"><img src="/2.44.png" style="text-align: center" alt="Figure 44"/></p>
<p style="text-align: center;"> <sup>Figure 44. Actioning the pending request</sup> </p>

Should the Beneficiary’s Approver approve the request, they will receive visual confirmation of their action via the bank guarantee stepper as seen in (Figure 45).

 <p style="text-align: center;"><img src="/2.45.png" style="text-align: center" alt="Figure 45"/></p>
<p style="text-align: center;"> <sup>Figure 45. Approving the requestigure</sup> </p>

Upon approval by the Beneficiary, the request is passed to the Issuer. The Issuer will either APPROVE or REJECT the request. 

## BENEFICIARY INITIATED ISSUE REQUEST
A Beneficiary initiated issue request requires the Beneficiary’s organisation, as well as the Applicant and Issuer to come to consensus regarding the variable terms of the bank guarantee. 

## BENEFICIARY INITITIATED ISSUE REQUEST (SOLE APPROVER MODEL)
The example below will highlight a structure where ALL organisations adhere towards the SOLE APPROVER MODEL. 

 <p style="text-align: center;"><img src="/2.46.png" style="text-align: center" alt="Figure 46"/></p>
<p style="text-align: center;"> <sup>Figure 46. Example of a sole approver model in an issuance process</sup> </p>

A user within the sole approver model can initiate a request by clicking the ‘+’ icon on the top righthand corner of their dashboard as seen in Figure 47.

 <p style="text-align: center;"><img src="/2.47.png" style="text-align: center" alt="Figure 47"/></p>
<p style="text-align: center;"> <sup>Figure 47. Entering the new request screen</sup> </p>

To initiate an issuance request, click ‘Start a Bank Guarantee Request’ within the New Request menu (Figure 48). 

 <p style="text-align: center;"><img src="/2.48.png" style="text-align: center" alt="Figure 48"/></p>
<p style="text-align: center;"> <sup>Figure 48. Starting a new bank guarantee request</sup> </p>

Below is an example of a submitted bank guarantee form. The bank guarantee status is ‘Pending’ as the request has been sent to the Applicant to approve or reject. 

 <p style="text-align: center;"><img src="/2.49.png" style="text-align: center" alt="Figure 49"/></p>
<p style="text-align: center;"> <sup>Figure 49. Successfully initiated bank guarantee request</sup> </p>


The Applicant, Example Organisation, can access the request from the ‘Needs Action’ tab. Upon entering the request, a user of the Applicant’s organisation is required to review the request and decide whether they will REJECT or APPROVE (Figure 50).

 <p style="text-align: center;"><img src="/2.50.png" style="text-align: center" alt="Figure 50"/></p>
<p style="text-align: center;"> <sup>Figure 50. Reviewing a bank guarantee request</sup> </p>


Upon approval by the Applicant, the request is passed to the Issuer. The Issuer will either APPROVE or REJECT the request, thereby finalising the issuance of the bank guarantee request.

## BENEFICIARY INITITIATED ISSUE REQUEST (4-EYE MODEL)
The example below will highlight a structure where ALL organisations adhere towards 4-EYE MODEL. 

 <p style="text-align: center;"><img src="/2.51.png" style="text-align: center" alt="Figure 51"/></p>
<p style="text-align: center;"> <sup>Figure 51. Example of a 4-eye approval model in an issuance process</sup> </p>


A user with Proposer rights within the Beneficiary’s organisation with the 4-eye approval model can initiate a request by clicking the ‘+’ icon on the top righthand corner of their dashboard as seen in Figure 52.

 <p style="text-align: center;"><img src="/2.52.png" style="text-align: center" alt="Figure 52"/></p>
<p style="text-align: center;"> <sup>Figure 52. Entering the new request screen</sup> </p>


To initiate an issuance request, click ‘Start a Bank Guarantee Request’ within the New Request menu (Figure 53). 

 <p style="text-align: center;"><img src="/2.53.png" style="text-align: center" alt="Figure 53"/></p>
<p style="text-align: center;"> <sup>Figure 53. Starting a new bank guarantee request</sup> </p>


To complete the request form, the organisation will be required to enter details of Parties Involved and Guarantee Details. The Guarantee Details will depend on the Purpose Type that is selected. The Platform may hold multiple purpose types depending on the variety of guarantees that are being used for the Platform. 

Please note that an Issuer cannot be selected for a Beneficiary-initiated bank guarantee.

After submitting the form, an Approver within the Beneficiary’s organization will be required to review the request. The Beneficiary’s Approver can access the request via their Pending Requests tab in their portal whereby they can REJECT or APPROVE the pending the request.

Below is an example of a submitted bank guarantee form. Note that for a Beneficiary-initiated issue request, Example Organisation selects themselves as the Beneficiary. The bank guarantee status is ‘Pending’ as the request has been sent to the Applicant to approve or reject. 


 <p style="text-align: center;"><img src="/2.54.png" style="text-align: center" alt="Figure 54"/></p>
<p style="text-align: center;"> <sup>Figure 54. Successfully approved bank guarantee initiation request</sup> </p>


The Proposer of the Applicant’s organization can access the request via the ‘Needs Action’ tab or within their ‘Pending Requests’ tab. Upon entering the request, the Applicant’s Proposer is required to review the request, select an Issuer and decide whether they will REJECT or APPROVE (Figure 55) the request. 

 <p style="text-align: center;"><img src="/2.55.png" style="text-align: center" alt="Figure 55"/></p>
<p style="text-align: center;"> <sup>Figure 55. Viewing an inflight request</sup> </p>


If the request is approved, it will need to be reviewed by an Approver within the Applicant’s organisation. The Applicant’s Approver can access the request within their ‘Pending Requests’ tab in their portal to REJECT or APPROVE.

Upon approval by the Applicant, the request is passed to the Issuer. The Issuer will either APPROVE or REJECT the request, thereby finalising the bank guarantee issuance request.


## ISSUER INITITATED ISSUE REQUEST
An Issuer initiated issue request occurs as pre-population on behalf of the Applicant. This occurs in the instance in which an Issuer would wish to perform a function on behalf of the Applicant to assist them in populating the issue request. The pre-population function is not required to adhere to the approval model of the Issuer as there is no commitment from them to honour the pre-population. This therefore means that regardless of the approval model of the organisation, the pre-population request will only be required to be initiated before being sent to the Applicant for validation. It should also be noted that this function does not ensure that the request is approved by the Issuer as they have initiated the process. The Issuer is still required to verify the request against their internal processes. 





## ISSUER INITITIATED ISSUE REQUEST (SOLE APPROVER MODEL)	

The example below highlights a structure where ALL organisations adhere towards the SOLE APPROVER MODEL. Figure 56 displays the process where an Issuer initiates on behalf of an Applicant. Please note that the Issuer is still required to approve the bank guarantee after the Applicant and Beneficiary have made their approvals for the bank guarantee to be issued. 

 <p style="text-align: center;"><img src="/2.56.png" style="text-align: center" alt="Figure 56"/></p>
<p style="text-align: center;"> <sup>Figure 56. Example of a sole approver model in an Issuer initiated issuance process</sup> </p>



Once the Issuer has initiated the Bank Guarantee request on behalf of the Applicant ‘Some Company’, the Prefill Request will be forwarded to the Applicant. A user in Some Company will be able to access the request through the ‘Needs Action’ item in their portal.

Upon entering the request, a user of Some Company is required to review the prefill request from the Issuer and decide whether they will REJECT ISSUE REQUEST or ACCEPT ISSUE REQUEST, shown in Figure 57.

 <p style="text-align: center;"><img src="/2.57.png" style="text-align: center" alt="Figure 57"/></p>
<p style="text-align: center;"> <sup>Figure 57. Reviewing a Bank Guarantee Prefill Request</sup> </p>


Should the Applicant reject the bank guarantee prefill request by clicking reject issue request and confirming rejection (Figure 58). The screen will then refresh and highlight the rejected guarantee pre-fill request (Figure 59).

 <p style="text-align: center;"><img src="/2.58.png" style="text-align: center" alt="Figure 58"/></p>
<p style="text-align: center;"> <sup>Figure 58. Entering an optional rejection reason and confirming your rejection</sup> </p>


 
 <p style="text-align: center;"><img src="/2.59.png" style="text-align: center" alt="Figure 59"/></p>
<p style="text-align: center;"> <sup>Figure 59. Rejected prefill issuance request</sup> </p>


Should the Applicant approve the prefill request, they are able to make amendments to the bank guarantee form based on their needs. Upon completing these amendments, the Applicant can either ‘REJECT ISSUE REQUEST’ or ‘ACCEPT ISSUE REQUEST’ on New Guarantee page. Should the Applicant approve the bank guarantee prefill request, they will receive visual confirmation of their action via the bank guarantee stepper as shown in Figure 60.

 <p style="text-align: center;"><img src="/2.60.png" style="text-align: center" alt="Figure 60"/></p>
<p style="text-align: center;"> <sup>Figure 60. Applicant approval of a bank guarantee request</sup> </p>


Upon approval by the Applicant, the request is passed to the Beneficiary, Test Organisation. The Beneficiary will be able to visualise the request within their ‘Needs Action’ notification. Entering the request will require the Beneficiary user to review the request and decide whether they will REJECT or APPROVE.

Should the Beneficiary approve the bank guarantee request, they will receive visual confirmation
of their action via the bank guarantee stepper as shown in Figure 61 with Issuer approval as the next step.

 <p style="text-align: center;"><img src="/2.61.png" style="text-align: center" alt="Figure 61"/></p>
<p style="text-align: center;"> <sup>Figure 61. Confirmation of pending bank guarantee</sup> </p>


Upon approval by the Beneficiary, the request is passed to the Issuer. The Issuer will either APPROVE or REJECT the request, thereby finalising the bank guarantee issuance request.

## ISSUER INITITIATED ISSUE REQUEST (4-EYE APPROVER MODEL)

The example below will highlight a structure where ALL organisations adhere towards 4-EYE MODEL. Figure 62 displays the process where an Issuer initiates on behalf of an Applicant. Please note that the Issuer is still required to approve the bank guarantee after the Applicant and Beneficiary have made their approvals for the bank guarantee to be issued.

<p style="text-align: center;"><img src="/2.62.png" style="text-align: center" alt="Figure 62"/></p>
<p style="text-align: center;"> <sup>Figure 62. Example of a four-eye approver model in an Issuer initiated issuance process</sup> </p>
 


Once the Issuer has initiated the Bank Guarantee request on behalf of the Applicant ‘Some Company’, the Prefill Request will be forwarded to the Applicant. A Proposer within Some Company will receive a ‘Needs Action’ notification to the Issuer initiated bank guarantee prefill request.

Upon entering the request, a user of the Applicant’s organisation is required to review the prefill request from the Issuer and decide whether they will REJECT ISSUE REQUEST or ACCEPT ISSUE REQUEST, shown in Figure 57.

 <p style="text-align: center;"><img src="/2.63.png" style="text-align: center" alt="Figure 63"/></p>
<p style="text-align: center;"> <sup>Figure 63. Reviewing a Bank Guarantee Prefill Request</sup> </p>


Should the Applicant reject the bank guarantee prefill request by clicking reject issue request and confirming the rejection (Figure 58). The screen will then refresh and highlight the rejected guarantee pre-fill request (Figure 59).

 <p style="text-align: center;"><img src="/2.64.png" style="text-align: center" alt="Figure 64"/></p>
<p style="text-align: center;"> <sup>Figure 64. Confirming your rejection</sup> </p>


 
<p style="text-align: center;"><img src="/2.65.png" style="text-align: center" alt="Figure 65"/></p>
<p style="text-align: center;"> <sup>Figure 65. Rejected prefill issuance request</sup> </p>



Should the Applicant’s Proposer approve the prefill request, they are able to make amendments to the bank guarantee form based on their needs. Upon completing these amendments, the Applicant’s Proposer can either ‘REJECT ISSUE REQUEST’ or ‘ACCEPT ISSUE REQUEST’.

The request will then be required to be reviewed by an Approver within the Applicant’s organisation. This can be accessed through the ‘Needs Action’ tab in the portal whereby the Applicant’s Approver can REJECT or APPROVE the pending request. 

Should the Applicant’s Approver approve the request, they will receive visual confirmation of their action via the bank guarantee stepper as seen in (Figure 66).

 <p style="text-align: center;"><img src="/2.66.png" style="text-align: center" alt="Figure 66"/></p>
<p style="text-align: center;"> <sup>Figure 66.  Applicant Approver approves Bank Guarantee Prefill Request</sup> </p>


Upon approval by the Applicant, the request is passed to the Beneficiary Proposer. The Beneficiary Proposer can access the request through the ‘Needs Action’ tab in the portal. Entering the request will require the Issuer’s Proposer to review the request and decide whether they will REJECT or APPROVE (Figure 67).

 <p style="text-align: center;"><img src="/2.67.png" style="text-align: center" alt="Figure 67"/></p>
<p style="text-align: center;"> <sup>Figure 67.  Bank Guarantee Request for Beneficiary Proposer</sup> </p>



The request will then be required to be reviewed by an Approver within the Beneficiary’s organisation. The Beneficiary’s Approver can access the pending request through the ‘Needs Action’ tab in the portal whereby they can APPROVE or REJECT the request as seen in (Figure 68).

 <p style="text-align: center;"><img src="/2.68.png" style="text-align: center" alt="Figure 68"/></p>
<p style="text-align: center;"> <sup>Figure 68. Bank Guarantee Request for Beneficiary Approver</sup> </p>


The request will then be forwarded to the Issuer for review. The Issuer will either APPROVE or REJECT the request, thereby finalising the bank guarantee issuance request.


## AMENDING A BANK GUARANTEE

An amendment to an active bank guarantee can be made by all participating parties. Fields that can be amended in a bank guarantee is dependent on the Purpose Type of the Guarantee. Typically, the Details fields (address, optional comments) and Values fields (expiry, maximum amount) can be amended.

Amendment flows adhere to the following business logic throughout all the models and follow the identical logic of an issuance request as shown in Figure 69, Figure 70, Figure 71. As such, the amendment flow within the subsections APPLICANT OR BENEFICIARY INITIATED AMEND REQUEST

## AMENDING A BANK GUARANTEE REQUEST (SOLE APPROVER MODEL) and AMENDING A BANK GUARANTEE REQUEST (4-EYE APPROVER MODEL) should be considered identical, as the flows which would be adhered to are nearly identical, bar which organisation initiates the request. 

 <p style="text-align: center;"><img src="/2.69.png" style="text-align: center" alt="Figure 69"/></p>
<p style="text-align: center;"> <sup>Figure 69. Applicant initiated issue request</sup> </p>


 
 <p style="text-align: center;"><img src="/2.70.png" style="text-align: center" alt="Figure 70"/></p>
<p style="text-align: center;"> <sup>Figure 70. Beneficiary initiated issue request</sup> </p>



 <p style="text-align: center;"><img src="/2.71.png" style="text-align: center" alt="Figure 71"/></p>
<p style="text-align: center;"> <sup>Figure 71. Issuer initiated issue request</sup> </p>



## APPLICANT OR BENEFICIARY INITIATED AMEND REQUEST

## AMENDING A BANK GUARANTEE REQUEST (SOLE APPROVER MODEL)

For a Sole-Eye Approver Model, the Manager can initiate a bank guarantee amendment via the Guarantee Details page in the ‘Action’ panel as seen in Figure 72. 

 <p style="text-align: center;"><img src="/2.72.png" style="text-align: center" alt="Figure 72"/></p>
<p style="text-align: center;"> <sup>Figure 72. Initiate Amendment on the Bank Guarantee Details page</sup> </p>


The ‘Amend Guarantee’ page will allow the Manager to make the necessary changes to the fields that are amendable.  Clicking ‘Amend Bank Guarantee’ will process the request and refresh the page to see and move the request to the next Organisation. In this example, the Beneficiary can see their requested amendment with the Applicant being the next party required for review and approval (Figure 73). 

<p style="text-align: center;"><img src="/2.73.png" style="text-align: center" alt="Figure 73"/></p>
<p style="text-align: center;"> <sup>Figure 73. Applicant initiated Bank Guarantee Amendment in Progress </sup> </p>



The Applicant is able to view that a current Bank Guarantee is in an Active Request status of ‘Amend’ via the ‘All Guarantees’ tab, the ‘Needs Action’ tab or the ‘Pending Requests’ tab in their portal. After accessing the guarantee amendment request, the Applicant can review the highlighted amended fields and action a REJECT or APPROVE as seen in Figure 74.

 <p style="text-align: center;"><img src="/2.74.png" style="text-align: center" alt="Figure 74"/></p>
<p style="text-align: center;"> <sup>Figure 74. Bank Guarantee Amendment Approval Request</sup> </p>


Approving the Amendment will result in confirmation of the Approval by the Applicant and the stepper showing the Issuer Approval as the next step (Figure 75). 

 <p style="text-align: center;"><img src="/2.75.png" style="text-align: center" alt="Figure 75"/></p>
<p style="text-align: center;"> <sup>Figure 75. Confirmation of Beneficiary Approved Bank Guarantee Amend Request</sup> </p>


The Issuer will then approve or reject the Bank Guarantee Amendment request after reviewing the changes, thereby finalising the amendment request. 

## AMENDING A BANK GUARANTEE REQUEST (4-EYE APPROVER MODEL)

Within this example we will be operating a Beneficiary initiated scenario. Both Applicant initiated, and Beneficiary initiated scenarios adhere to the same methodology, with the sole difference being the initiating party. Please consider this as you proceed below. 

Within a Four-Eye Approver Model, the Proposer can initiate a bank guarantee amendment via the Guarantee Details page as seen in Figure 76.

 <p style="text-align: center;"><img src="/2.76.png" style="text-align: center" alt="Figure 76"/></p>
<p style="text-align: center;"> <sup>Figure 76. Initiate Amendment in Bank Guarantees Details Page</sup> </p>


The ‘Amend Guarantee’ page will allow the Proposer to make the necessary changes to the fields that are amendable.  In the example shown (Figure 77) the Applicant is changing the Amount in Guarantee Details. 

 <p style="text-align: center;"><img src="/2.77.png" style="text-align: center" alt="Figure 77"/></p>
<p style="text-align: center;"> <sup>Figure 77. Amend Bank Guarantee page</sup> </p>


Clicking ‘Amend Bank Guarantee’ will process the request and move the request to the Approver for review as seen in the stepper in Figure 78.

 <p style="text-align: center;"><img src="/2.78.png" style="text-align: center" alt="Figure 78"/></p>
<p style="text-align: center;"> <sup>Figure 78. Proposer approval of a Bank Guarantee Amendment Request</sup> </p>


The Approver will be able to access the amended item via the ‘Pending Requests’ tab in their portal. Here, the Approver can review the highlighted amendment fields and choose to REJECT or APPROVE the amendment request (Figure 79).

 <p style="text-align: center;"><img src="/2.79.png" style="text-align: center" alt="Figure 79"/></p>
<p style="text-align: center;"> <sup>Figure 79. Reviewing a Bank Guarantee Amend Request as an Approver</sup> </p>


Approving the amendment will result in confirmation of the approval by the organisations approver and the stepper showing the next organisation, the Beneficiary as the next required organisation (Figure 80).

 <p style="text-align: center;"><img src="/2.80.png" style="text-align: center" alt="Figure 80"/></p>
<p style="text-align: center;"> <sup>Figure 80. Approver approval of a Bank Guarantee Amendment Request</sup> </p>


The Beneficiary’s Proposer will receive a ‘Needs Action’ notification stating that an Amend request is currently inflight. The Beneficiary’s Proposer will be required to review the amend request and either ‘APPROVE’ or ‘REJECT’. Approving the request as a Proposer visibly shows confirmation, with the request requiring review by the organisation’s Approver before moving forward as seen in Figure 81.

 <p style="text-align: center;"><img src="/2.81.png" style="text-align: center" alt="Figure 81"/></p>
<p style="text-align: center;"> <sup>Figure 81. Proposer approval of a Bank Guarantee Amendment Request</sup> </p>



The Approver is next able to action the Amend Request by reviewing the amended fields and actioning a REJECT or APPROVE as seen in Figure 82.

 <p style="text-align: center;"><img src="/2.82.png" style="text-align: center" alt="Figure 82"/></p>
<p style="text-align: center;"> <sup>Figure 82. Reviewing a Bank Guarantee Amend Request as an Approver</sup> </p>


Clicking ‘APPROVE’ will process the request and move the request to the Issuer as seen in the stepper in Figure 83.

 <p style="text-align: center;"><img src="/2.83.png" style="text-align: center" alt="Figure 83"/></p>
<p style="text-align: center;"> <sup>Figure 83. Approver approval of a Bank Guarantee Amendment Request</sup> </p>


Upon approval by the Beneficiary, the Issuer will then approve or reject the Bank Guarantee Amendment request after reviewing the changes, thereby completing the amendment request. 

## ISSUER INITITIATED AMEND REQUEST

An Issuer initiated amend request occurs as pre-population on behalf of the Applicant. This occurs in the instance in which an Issuer would wish to perform a function on behalf of the Applicant to assist them in populating the amend request. The pre-population function is not required to adhere to the approval model of the Issuer as there is no commitment from them to honour the pre-population. This therefore means that regardless of the approval model of the organisation, the pre-population request will only be required to be initiated before being sent to the Applicant for validation. It should also be noted that this function does not ensure that the request is approved by the Issuer as they have initiated the process. The Issuer is still required to verify the request against their internal processes. 

For this instance, the following example will take reference to all organisations adhering to the SOLE APPROVER MODEL. 

## AMENDING A BANK GUARANTEE REQUEST (SOLE APPROVER MODEL)

An Issuer may initiate an amendment prefill request on behalf of the Applicant. The Issuer will fill out the Bank Guarantee Amend request and then forward it to the Applicant to either reject, approve or amend. Please note: Issuer must also approve the request even after initiating the request on behalf of the Applicant.

Once an issuer has initiated an amendment prefill request on behalf of the Applicant, the Applicant will receive a ‘Needs Action’ notification in their portal.

Upon the Applicant opening the Needs Action item on the guarantee amendment request, the Applicant will be displayed with the Bank Guarantee Details page showing a prefill request from the Issuer (Figure 84). To review the prefill request, click on the ‘Accept Amend Prefill’ 

 <p style="text-align: center;"><img src="/2.84.png" style="text-align: center" alt="Figure 84"/></p>
<p style="text-align: center;"> <sup>Figure 84. Applicant receiving Prefill Amend Request from Issuer</sup> </p>


The Applicant will be able to make any additional changes to the amend prefill request or decide to ‘Reject Amend Prefill or proceed with ‘Accept Amend Prefill’. 

If the Applicant decides to reject the amend prefill request, they may do so by clicking ‘REJECT AMEND REQUEST’. The bank guarantee will remain in ‘Active’ status with all the details remaining as is. 

If the Applicant decides to proceed with the amend prefill request, the bank guarantee will move in to ‘Amend in Progress’ status as shown in Figure 85. The amended fields will be shown in the ‘View Current Request’ panel, and the stepper will display the beneficiary as the next approval step.

 <p style="text-align: center;"><img src="/2.85.png" style="text-align: center" alt="Figure 85"/></p>
<p style="text-align: center;"> <sup>Figure 85. Applicant approved amend request </sup> </p>


The Beneficiary will now receive a ‘Needs Action’ item for ‘Guarantee Amendment Initiated’. Upon opening the needs action item, the beneficiary can review the amended fields (Figure 86) and decide to ‘REJECT’ or ‘APPROVE’ the amendment.

 <p style="text-align: center;"><img src="/2.86.png" style="text-align: center" alt="Figure 86"/></p>
<p style="text-align: center;"> <sup>Figure 86. Beneficiary reviewing amend request</sup> </p>


If the beneficiary decides to approve the amendment and clicks ‘APPROVE’, the approval will go through to the Issuer for final approval as shown in the stepper in Figure 87.

 <p style="text-align: center;"><img src="/2.87.png" style="text-align: center" alt="Figure 87"/></p>
<p style="text-align: center;"> <sup>Figure 87. Beneficiary approved amend request</sup> </p>



The Issuer will either APPROVE or REJECT the pending request thereby completing the guarantee amendment request.


## CANCELLATION OF A BANK GUARANTEE

A bank guarantee may be cancelled to reflect changes in agreement between an Applicant and Beneficiary. The cancellation request can be initiated by the Applicant, Beneficiary or the Issuer.

## APPLICANT/BENEFICIARY INITIATED CANCELLATION REQUEST

## CANCELLING A BANK GUARANTEE REQUEST (SOLE APPROVER MODEL)

To initiate a cancellation of a Bank Guarantee, a Manager within the organisation will be required to click ‘CANCEL’ as seen in (Figure 88).

 <p style="text-align: center;"><img src="/2.88.png" style="text-align: center" alt="Figure 88"/></p>
<p style="text-align: center;"> <sup>Figure 88. Bank guarantee cancellation request</sup> </p>



Upon initiating the Cancellation request, the Beneficiary will receive a notification to review and either ‘REJECT’ or ‘APPROVE’ the Cancellation request.

Upon Beneficiary approval, the Issuer will receive a notification to either ‘REJECT’ or ‘APPROVE’ the Cancellation request.

## CANCELLING A BANK GUARANTEE REQUEST (4-EYE APPROVER MODEL)

To initiate a cancellation of a Bank Guarantee, a Proposer within the organisation will be required to click ‘CANCEL’ as seen in (Figure 89). In this example, the Beneficiary is initiating the cancellation, therefore the approval will only be needed from the Beneficiary Approver and the Issuer.

 <p style="text-align: center;"><img src="/2.89.png" style="text-align: center" alt="Figure 89"/></p>
<p style="text-align: center;"> <sup>Figure 89. Initiating a Bank guarantee cancellation request</sup> </p>


A pop-up dialog will appear to confirm the cancellation with optional cancellation reason; the Approver will receive a notification to either ‘REJECT’ or ‘APPROVE’ the pending cancellation request.

Upon approval by the Approver, the Issuer will receive a notification to either ‘REJECT’ or ‘APPROVE’ the pending cancellation request.

After Issuer approves the request the Bank Guarantee Status will change to Cancelled.

 <p style="text-align: center;"><img src="/2.90.png" style="text-align: center" alt="Figure 90"/></p>
<p style="text-align: center;"> <sup>Figure 90. Cancelled Bank Guarantee Request</sup> </p>


ISSUER INITIATED CANCELLATION REQUEST
An Issuer initiated cancellation request occurs as pre-population on behalf of the Applicant. This occurs in the instance in which an Issuer would wish to perform a function on behalf of the Applicant to assist them in populating the cancellation request. The Issuer is still required to verify the request against their internal processes.

## ISSUER INITIATED BANK GUARANTEE CANCELLING REQUEST (SOLE APPROVER MODEL)

The Issuer will initiate the Cancelation request for the Applicant.

The Applicant will receive a notification to either ‘REJECT CANCEL PREFILL’ or ‘ACCEPT CANCEL PREFILL’ (Figure 91).

 <p style="text-align: center;"><img src="/2.91.png" style="text-align: center" alt="Figure 91"/></p>
<p style="text-align: center;"> <sup>Figure 91. Bank guarantee cancellation request</sup> </p>


Should the Applicant accept the cancel prefill, they will be prompted to enter a cancellation reason to be sent along with the request (Figure 92). 

 <p style="text-align: center;"><img src="/2.92.png" style="text-align: center" alt="Figure 92"/></p>
<p style="text-align: center;"> <sup>Figure 92. Entering a Cancellation reason</sup> </p>



The bank guarantee will display a ‘Cancel in Progress’ status and show that the Beneficiary is next in line for approval of the cancellation.

Upon approving the Cancellation request, the Beneficiary will receive a notification to review and either ‘REJECT’ or ‘APPROVE’ the cancellation request.

Upon Beneficiary approval, the Issuer will receive a notification to review and either ‘REJECT’ or ‘APPROVE’ the cancellation request.

## DEMAND OF A BANK GUARANTEE
The Platform allows for the beneficiary to submit a demand payment request (full or partial amount) on an active bank guarantee when there is a default by the applicant. The demand request will be received by the Issuer, in which they can select to Defer or to approve the demand request. This flow is reflected below.

It is important to note that within the Demand of a Bank Guarantee, the roles are reversed regarding ‘Approval’ and ‘Deferral’. As payment of a bank guarantee is an irrefutable obligation by an Issuer, deferring payment requires dual approval whilst approving the payment of guarantee requires single approval. It is important to keep this in mind within the process of the Platform, as payment and eventual closure of a Bank Guarantee can have additional impacts on external procedures. The Issuer should only select ‘Mark as Paid’ for the Demand, once the Beneficiary has been paid outside the system. The Applicant of the bank guarantee will see that the bank guarantee is in ‘Active’ status until the demand has been completed. They will have no visibility on when there is a demand in progress.

## BENEFICIARY SUBMITTING A PARTIAL DEMAND PAYMENT REQUEST (4-EYE APPROVAL MODEL)

To submit a partial demand payment, the Beneficiary’s Proposer will be required to select an active Bank Guarantee within the ‘All Guarantees’ page and enter the Guarantee Details page as shown in Figure 93. The Beneficiary will then click ‘Demand’ in the Actions panel.

 <p style="text-align: center;"><img src="/2.93.png" style="text-align: center" alt="Figure 93"/></p>
<p style="text-align: center;"> <sup>Figure 93. Bank Guarantee Details page</sup> </p>


Upon clicking ‘DEMAND’, A pop-up will appear on the screen to select the amount of the bank guarantee to demand. Once the amount has been determined, the beneficiary can click ‘Proceed with Demand’.

 <p style="text-align: center;"><img src="/2.94.png" style="text-align: center" alt="Figure 94"/></p>
<p style="text-align: center;"> <sup>Figure 94. Entering the Demand amount for a bank guarantee</sup> </p>


Beneficiary’s Approver will review and approve this DEMAND.  

The Approver will be required to either ‘APPROVE’ OR REJECT’ the Demand request as seen in Figure 95.

 <p style="text-align: center;"><img src="/2.95.png" style="text-align: center" alt="Figure 95"/></p>
<p style="text-align: center;"> <sup>Figure 95. Reviewing the initiated request internally</sup> </p>


Upon approving the request, the bank guarantee will refresh to highlight the Approvers approval against the demand request.

The Issuer will receive a notification and see the demanded amount against the Bank Guarantee with the ability to select two options; to either ‘Defer’ or ‘Mark as Paid’.




## BENEFICIARY SUBMITTING A FULL DEMAND PAYMENT REQUEST (4-EYE APPROVAL MODEL)

To submit a full demand payment, the Beneficiary’s Proposer will be required to select an active Bank Guarantee within the ‘All Guarantees’ page and enter the Guarantee Details page as shown in Figure 96. 

 <p style="text-align: center;"><img src="/2.96.png" style="text-align: center" alt="Figure 96"/></p>
<p style="text-align: center;"> <sup>Figure 96. Bank Guarantee Details page</sup> </p>


Upon clicking ‘DEMAND’, A pop-up will appear on the screen to select the amount of the bank guarantee to demand. 

 <p style="text-align: center;"><img src="/2.97.png" style="text-align: center" alt="Figure 97"/></p>
<p style="text-align: center;"> <sup>Figure 97. Entering the Demand amount for a bank guarantee</sup> </p>


The Bank Guarantee Details page has updated to show that there is a ‘Demand in Progress’ and the demanded amount is highlighted within the stepper (Figure 98) with the Beneficiary’s Approver required to approve the demand request. 

 <p style="text-align: center;"><img src="/2.98.png" style="text-align: center" alt="Figure 98"/></p>
<p style="text-align: center;"> <sup>Figure 98. Partial Demand submitted by the Beneficiary</sup> </p>


The Approver will be required to either ‘APPROVE’ OR REJECT’ the Demand request. Upon approving the request, the bank guarantee will refresh to highlight the Approvers approval against the demand request (Figure 99).

 <p style="text-align: center;"><img src="/2.99.png" style="text-align: center" alt="Figure 99"/></p>
<p style="text-align: center;"> <sup>Figure 99. Approving an inflight demand request</sup> </p>


The Issuer will now receive a Needs Action item to approve or reject the demand on the Bank Guarantee.
 
## TRANSFER OF A BANK GUARANTEE

The Platform allows for ACTIVE Bank Guarantees to be transferred between Beneficiaries should the need arise. This process can be initiated by either the Applicant, Beneficiary or Issuer, however the differences in flows should be noted. 

 <p style="text-align: center;"><img src="/2.100.png" style="text-align: center" alt="Figure 100"/></p>
<p style="text-align: center;"> <sup>Figure 100. Applicant-Initiated Transfer Request</sup> </p>



 <p style="text-align: center;"><img src="/2.101.png" style="text-align: center" alt="Figure 101"/></p>
<p style="text-align: center;"> <sup>Figure 101. Issuer-Initiated Transfer Request</sup> </p>



 <p style="text-align: center;"><img src="/2.102.png" style="text-align: center" alt="Figure 102"/></p>
<p style="text-align: center;"> <sup>Figure 102. Beneficiary-Initiated Transfer Request</sup> </p>



## APPLICANT INITIATED TRANSFER REQUEST
An Applicant initiated transfer request requires the Applicant’s organisation, as well as the original Beneficiary, future Beneficiary and Issuer to come to consensus regarding the transfer a bank guarantee.

## RANSFERRING A BANK GUARANTEE TO A NEW BENEFICIARY (SOLE APPROVER MODEL)
There are instances where a bank guarantee may transfer from one beneficiary to a new beneficiary. The bank guarantee details page allows for this transfer to be made as shown in the ‘Actions’ panel in Figure 103.

 <p style="text-align: center;"><img src="/2.103.png" style="text-align: center" alt="Figure 2.103"/></p>
<p style="text-align: center;"> <sup>Figure 103. Initiating a Transfer of a bank guarantee </sup> </p>


A Transfer Guarantee form will appear with the current details of the bank guarantee. Once completed, ‘Transfer Bank Guarantee’ is clicked (Figure 104).

 <p style="text-align: center;"><img src="/2.104.png" style="text-align: center" alt="Figure 104"/></p>
<p style="text-align: center;"> <sup>Figure 104. Bank Guarantee Transfer Form</sup> </p>


The Bank Guarantee Details page will now show that there is a ‘Transfer in Progress’ status with the new beneficiary details visible within the stepper. The current beneficiary will be next to approve the transfer of the bank guarantee as shown in the stepper in Figure 105.  

 <p style="text-align: center;"><img src="/2.105.png" style="text-align: center" alt="Figure 105"/></p>
<p style="text-align: center;"> <sup>Figure 105. Bank guarantee transfer initiated by Applicant</sup> </p>



The current beneficiary will receive a needs action to review the Guarantee Transfer request (Figure 106) In the example below, the current beneficiary is ‘Example Organisation’ who will be transferring the bank guarantee to ‘Some Company’.

 <p style="text-align: center;"><img src="/2.106.png" style="text-align: center" alt="Figure 106"/></p>
<p style="text-align: center;"> <sup>Figure 106. Needs Action item for Guarantee Transfer</sup> </p>


Upon opening the Needs Action item, the bank guarantee transfer request will display within the stepper. In the example below, the current beneficiary is Example Organisation (Figure 107). If the current beneficiary accepts the transfer, clicking the ‘Approve’ button will confirm the bank guarantee transfer. 

 <p style="text-align: center;"><img src="/2.107.png" style="text-align: center" alt="Figure 107"/></p>
<p style="text-align: center;"> <sup>Figure 107. Approving a Bank Guarantee Transfer Request</sup> </p>


Clicking ‘Approve’ will show that the new beneficiary will be next to approve as shown in Figure 108

 <p style="text-align: center;"><img src="/2.108.png" style="text-align: center" alt="Figure 108"/></p>
<p style="text-align: center;"> <sup>Figure 108. Transfer sent to new beneficiary</sup> </p>



The new beneficiary will receive a needs action to review the Guarantee Transfer request (Figure 109) In the example below, the new beneficiary is ‘Some Company’.

 <p style="text-align: center;"><img src="/2.109.png" style="text-align: center" alt="Figure 109"/></p>
<p style="text-align: center;"> <sup>Figure 109. Needs Action item for Guarantee Transfer</sup> </p>


Upon opening the Needs Action item, the bank guarantee transfer request will display under the beneficiary field the old beneficiary details. If the new beneficiary approves, clicking the ‘Approve’ button will confirm the bank guarantee transfer.

<p style="text-align: center;"><img src="/2.110.png" style="text-align: center" alt="Figure 110"/></p>
<p style="text-align: center;"> <sup>Figure 110. Reviewing a Bank Guarantee Transfer Request</sup> </p> 



The Issuer will then receive the bank guarantee transfer approval request and cam review and APPROVE or REJECT.

## TRANSFERRING A BANK GUARANTEE TO A NEW BENEFICIARY (4-EYE APPROVAL MODEL)
There are instances where a bank guarantee may transfer from one beneficiary to a new beneficiary. The bank guarantee details page allows for this transfer to be initiated by a Proposer within the ‘Actions’ panel in Figure 111.

 <p style="text-align: center;"><img src="/2.111.png" style="text-align: center" alt="Figure 111"/></p>
<p style="text-align: center;"> <sup>Figure 111. Initiating a Transfer of a bank guarantee </sup> </p>


A Transfer Guarantee form will appear with the current details of the bank guarantee. The beneficiary, ‘Example Organisation’, can select a new beneficiary, ‘Some Company’ as the beneficiary for this bank guarantee. Below this field there is an option to select a ‘Novation Reason’. Once completed, ‘Transfer Bank Guarantee’ is clicked (Figure 112).

 <p style="text-align: center;"><img src="/2.112.png" style="text-align: center" alt="Figure 112"/></p>
<p style="text-align: center;"> <sup>Figure 112. Bank Guarantee Transfer Form</sup> </p>


The Bank Guarantee Details page will now show that there a ‘Transfer’ status with the new beneficiary details visible within the stepper. The Approver within that organisation is required to validate the request as seen in Figure 113.  

 <p style="text-align: center;"><img src="/2.113.png" style="text-align: center" alt="Figure 113"/></p>
<p style="text-align: center;"> <sup>Figure 113. Bank guarantee transfer initiated by the Proposer</sup> </p>


The Approver will be able to view the transfer request via their ‘Pending Guarantees’ tab, which upon entering will require the Approver to validate the request by either clicking ‘REJECT’ or ‘APPROVE’.
 
 <p style="text-align: center;"><img src="/2.114.png" style="text-align: center" alt="Figure 114"/></p>
<p style="text-align: center;"> <sup>Figure 114. Reviewing a Transfer request as an Approver</sup> </p>


Approval of the transfer is validated within the stepper with the next approval required being from the current beneficiary (Figure 115).

 <p style="text-align: center;"><img src="/2.115.png" style="text-align: center" alt="Figure 115"/></p>
<p style="text-align: center;"> <sup>Figure 115. Approving the transfer request as an Approver</sup> </p>


The proposer of the current beneficiary will receive a ‘Needs Action’ from which they can review the Transfer request (Figure 116). 

 <p style="text-align: center;"><img src="/2.116.png" style="text-align: center" alt="Figure 116"/></p>
<p style="text-align: center;"> <sup>Figure 116. Needs Action item for Guarantee Transfer</sup> </p>


Upon entering the request, the Proposer will be required to validate the request by either clicking ‘REJECT’ or ‘APPROVE’ (Figure 117).

 <p style="text-align: center;"><img src="/2.117.png" style="text-align: center" alt="Figure 117"/></p>
<p style="text-align: center;"> <sup>Figure 117. Reviewing the transfer request as a Proposer</sup> </p>


Approval of the transfer by the Proposer is validated within the stepper with the next approval required being from the Approver (Figure 118).

<p style="text-align: center;"><img src="/2.118.png" style="text-align: center" alt="Figure 118"/></p>
<p style="text-align: center;"> <sup>Figure 118. Approval of the Transfer request as a Proposer</sup> </p>
 

The Approver of the current beneficiary will receive a ‘Needs Action’ from which they can review the Transfer request (Figure 119). 

 <p style="text-align: center;"><img src="/2.119.png" style="text-align: center" alt="Figure 119"/></p>
<p style="text-align: center;"> <sup>Figure 119. Needs Action item for Guarantee Transfer</sup> </p>


Upon entering the request, the Approver will be required to validate the request by either clicking ‘REJECT’ or ‘APPROVE’ (Figure 120).

<p style="text-align: center;"><img src="/2.120.png" style="text-align: center" alt="Figure 120"/></p>
<p style="text-align: center;"> <sup>Figure 120. Reviewing the transfer request as an Approver</sup> </p>


Approval of the transfer by the Approver is validated within the stepper with the next approval required being from the new beneficiary (Figure 121).

 <p style="text-align: center;"><img src="/2.121.png" style="text-align: center" alt="Figure 121"/></p>
<p style="text-align: center;"> <sup>Figure 121. Approval of the Transfer request as an Approver</sup> </p>


The proposer of the new beneficiary will receive a ‘Needs Action’ from which they can review the Transfer request (Figure 122). 

 <p style="text-align: center;"><img src="/2.122.png" style="text-align: center" alt="Figure 122"/></p>
<p style="text-align: center;"> <sup>Figure 122. Needs Action item for Guarantee Transfer</sup> </p>


Upon entering the request, the Proposer will be required to validate the request by either clicking ‘REJECT’ or ‘APPROVE’ (Figure 123).

 <p style="text-align: center;"><img src="/2.123.png" style="text-align: center" alt="Figure 123"/></p>
<p style="text-align: center;"> <sup>Figure 123. Reviewing the transfer request as a Proposer</sup> </p>


Approval of the transfer by the Proposer is validated within the stepper with the next approval required being from the Approver (Figure 124).

 <p style="text-align: center;"><img src="/2.124.png" style="text-align: center" alt="Figure 124"/></p>
<p style="text-align: center;"> <sup>Figure 124. Approval of the Transfer request as a Proposer</sup> </p>


The Approver of the new beneficiary will receive a ‘Needs Action’ from which they can review the Transfer request (Figure 125). 

 <p style="text-align: center;"><img src="/2.125.png" style="text-align: center" alt="Figure 125"/></p>
<p style="text-align: center;"> <sup>Figure 125. Needs Action item for Guarantee Transfer</sup> </p>


Upon entering the request, the Approver will be required to validate the request by either clicking ‘REJECT’ or ‘APPROVE’ (Figure 126).

 <p style="text-align: center;"><img src="/2.126.png" style="text-align: center" alt="Figure 126"/></p>
<p style="text-align: center;"> <sup>Figure 126. Reviewing the transfer request as an Approver</sup> </p>


Approval of the transfer by the Approver is validated within the stepper with the next approval required being from the new beneficiary (Figure 127).

 <p style="text-align: center;"><img src="/2.127.png" style="text-align: center" alt="Figure 127"/></p>
<p style="text-align: center;"> <sup>Figure 127. Approval of the Transfer request as an Approver</sup> </p>


The Issuer will receive a notification to APPROVE or REJECT the transfer request. 

## BENEFICIARY INITIATED TRANSFER REQUEST
A Beneficiary initiated transfer request requires the Beneficiary, future Beneficiary and Issuer to come to consensus regarding the transfer a bank guarantee.  

## TRANSFERRING A BANK GUARANTEE TO A NEW BENEFICIARY (SOLE APPROVER MODEL)
There are instances where a bank guarantee may transfer from one beneficiary to a new beneficiary. The bank guarantee details page allows for this transfer to be made as shown in the ‘Actions’ panel in Figure 128.

 <p style="text-align: center;"><img src="/2.128.png" style="text-align: center" alt="Figure 128"/></p>
<p style="text-align: center;"> <sup>Figure 128. Initiating a Transfer of a bank guarantee </sup> </p>


A Transfer Guarantee form will appear with the current details of the bank guarantee. Once completed, ‘Transfer Bank Guarantee’ is clicked.

The new beneficiary will receive a notification to review and approve the request.


The Issuer will then receive the bank guarantee transfer approval request notification.

If the Issuer approves the bank guarantee transfer request, the bank guarantee will change to ‘Transferred’ status. 

## TRANSFERRING A BANK GUARANTEE TO A NEW BENEFICIARY (4-EYE MODEL)
There are instances where a bank guarantee may transfer from one beneficiary to a new beneficiary. The bank guarantee details page allows for this transfer to be initiated by the Proposer as shown in the ‘Actions’ panel in Figure 129.

 <p style="text-align: center;"><img src="/2.129.png" style="text-align: center" alt="Figure 129"/></p>
<p style="text-align: center;"> <sup>Figure 129. Initiating a Transfer of a bank guarantee </sup> </p>


A Transfer Guarantee form will appear with the current details of the bank guarantee. Once completed, ‘Transfer Bank Guarantee’ is clicked and the Proposer can view the inflight Bank Guarantee Transfer request (Figure 130). 

 <p style="text-align: center;"><img src="/2.130.png" style="text-align: center" alt="Figure 130"/></p>
<p style="text-align: center;"> <sup>Figure 130. Inflight Bank Guarantee Transfer request</sup> </p>


The Bank Guarantee Details page will now show that there is a ‘Transfer in Progress’ status with the new beneficiary details visible within the stepper. The Beneficiary’s Approver will be required to review and approve the request. 

The new beneficiary will receive a notification to review and approve the request.
Clicking the ‘APPROVE’ button will send the request to the Approver within the new beneficiary’s organisation.

The new beneficiary’s Approver will be required review and approve the request.

The Issuer will receive a notification to review and approve the transfer.

Should the Issuers Proposer approve the Bank Guarantee Transfer, the request will move to the Approver to validate.

The Issuer’s Approver will be required to review and approve the transfer.

If the Issuer approves the bank guarantee transfer request, the bank guarantee will change to ‘Transferred’ status. 

## PAY AND WALK 

An Issuer may decide to terminate associations with an Applicant by paying out the amount outstanding on a bank guarantee to the Beneficiary and closing the guarantee. In this circumstance the Issuer can complete the Pay and Walk process without the approvals of the other organisations within the Bank Guarantee, thereby closing the instrument. Please note, the Issuer should only click ‘Pay and Walk’ after the Beneficiary has been paid outside the system.

## PAY AND WALK (SOLE APPROVER MODEL)

Once the Pay & Walk is confirmed by the Issuer, the status of the bank guarantee will display as ‘Pay & Walk’ and the bank guarantee will no longer be open. This action is not reversible once initiated.

The Applicant and Beneficiary will receive an in-platform notification that the Pay and Walk on the bank guarantee has been successfully completed.


## REVOKING INTERNAL APPROVAL (4-Eye Approval)

In a 4-Eye approval model, the Proposer or the Approver of the organisation may revoke internal of a bank guarantee request.

## PROPOSER REVOKING INTERNAL APPROVAL 
In the example below (Figure 131) Some Company’s Proposer, John Smith, has approved the internal review as the Beneficiary from an Applicant initiated bank guarantee issuance. Once the Proposer has approved, the option to ‘Revoke Internal Approval’ displays.

 <p style="text-align: center;"><img src="/2.131.png" style="text-align: center" alt="Figure 131"/></p>
<p style="text-align: center;"> <sup>Figure 131. Revoking an Internal Approval </sup> </p>


Clicking ‘Revoke Internal Approval’ will allow the Applicant proposer to Approve or Reject the issuance request.

## APPROVER REVOKING INTERNAL APPROVAL 
In the example below Some Company’s Approver, Thomas Watson has received the internal review from the Proposer and is now at the stage or approving or rejecting the request. The Approver also has the option to ‘Revoke Internal Approval’ so that the review goes back to the Proposer. 

Once the Revoke has been initiated and confirmed, Some Company’s Proposer, John Smith, will now see that the bank guarantee request requires internal review again, as shown in Figure 132

 <p style="text-align: center;"><img src="/2.132.png" style="text-align: center" alt="Figure 132"/></p>
<p style="text-align: center;"> <sup>Figure 132. Applicant Proposer reviews issuance request after approval was revoked</sup> </p>



## REVOKE ORGANISATIONAL APPROVAL

After an organisation has approved an issuance request, the Proposer or the Approver can ‘Revoke Organisation’s Approval’ as shown in Figure 133

 <p style="text-align: center;"><img src="/2.133.png" style="text-align: center" alt="Figure 133"/></p>
<p style="text-align: center;"> <sup>Figure 133. Revoking Organisation’s Approval </sup> </p>


## CANCELLING A REQUEST

During a bank guarantee request, an organisation may decide to cancel a request that they have initiated. For example, an Applicant Proposer initiates a bank guarantee issuance request and decides after initiation to cancel their request. The Platform will allow for the user to select two options, to ‘Cancel Request’ and ‘Cancel Request and use as a Template’ as shown in Figure 134.

 <p style="text-align: center;"><img src="/2.134.png" style="text-align: center" alt="Figure 134"/></p>
<p style="text-align: center;"> <sup>Figure 134. Option to Cancel Request for a Bank Guarantee Issuance</sup> </p>


By clicking ‘Cancel’, the bank guarantee request will become ‘Cancelled’ status. In the Events Timeline there will be a new event ‘Guarantee Issuance Cancelled’.

## USE AS TEMPLATE

In the instance where one of the parties of a bank guarantee would like to submit another guarantee with similar information to a previous bank guarantee, the option to ‘Use as Template’ is available.

To begin, open a Guarantee that has been initiated in the past and find the action to ‘Use as Template’ (Figure 135)

 <p style="text-align: center;"><img src="/2.135.png" style="text-align: center" alt="Figure 135"/></p>
<p style="text-align: center;"> <sup>Figure 135. Using a Bank Guarantee as a Template</sup> </p>


Upon clicking this action, a bank guarantee request form will display with all the same details of the chosen bank guarantee, as shown in Figure 136


 <p style="text-align: center;"><img src="/2.136.png" style="text-align: center" alt="Figure 136"/></p>
<p style="text-align: center;"> <sup>Figure 136. Creating a Bank Guarantee from a template</sup> </p>


